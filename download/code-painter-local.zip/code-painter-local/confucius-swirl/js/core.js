'use strict';
// ─────────────────────────────────────────────────────────────
//  Core: canvas state, noise, easing, and hand-inked primitives.
//  Every outline is re-jittered 12x per second ("line boil") so the
//  code-drawn frames breathe like hand-traced cels.
// ─────────────────────────────────────────────────────────────
const W = 1920, H = 1080, FPS = 24, TAU = Math.PI * 2;
const DURATION = 68.0;
const AUDIO_END = 62.74;

let c = null;                 // active 2D context (swapped for offscreen buffers)
const G = { t: 0, boil: 0, js: 1 };   // js = local->screen scale, keeps ink width constant
const LW = 4.4;               // main ink (screen px)
const LW2 = 2.4;              // detail ink
const BOIL = 1.35;            // line boil amplitude (screen px)

const PAL = {
  ink: '#110e19', deep: '#0c1744', navy: '#1b2c79', cobalt: '#2658da', blue: '#3a7cf0',
  sky: '#62a0f6', ice: '#b8d3fb', lav: '#9198de', lavD: '#6167b6', lavL: '#c5c7ef',
  cream: '#f6e8ca', paper: '#fff5df', white: '#fdf8ec',
  orange: '#f08a2c', orangeD: '#c7591c', gold: '#f3be4c', rust: '#9a3d1d', red: '#d6432b',
  olive: '#8d9c3e', green: '#4f9356', greenD: '#2e694a', teal: '#3f9294', tealD: '#266a78',
  skin: '#efbb92', skinD: '#c97d55', skinL: '#fbd9b8', tan: '#d99a70', tanD: '#b06a45',
  beard: '#ebe8f3', beardD: '#a9abcd', pine: '#141c3a'
};

// ── math ─────────────────────────────────────────────────────
const clamp = (v, a = 0, b = 1) => v < a ? a : v > b ? b : v;
const lerp = (a, b, t) => a + (b - a) * t;
const seg = (t, a, b) => clamp((t - a) / (b - a));
const sm = t => t * t * (3 - 2 * t);
const eio = t => t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
const eout = t => 1 - Math.pow(1 - t, 3);
const ein = t => t * t * t;
const backOut = t => { const k = 1.70158; return 1 + (k + 1) * Math.pow(t - 1, 3) + k * Math.pow(t - 1, 2); };
const onTwos = t => Math.floor(t * 12) / 12;   // cel timing for character acting

function hash1(n) { const s = Math.sin(n * 127.1 + 311.7) * 43758.5453123; return s - Math.floor(s); }
function hash2(x, y) { const s = Math.sin(x * 127.1 + y * 311.7 + 74.7) * 43758.5453123; return s - Math.floor(s); }
function noise1(x) { const i = Math.floor(x), f = x - i; return lerp(hash1(i), hash1(i + 1), f * f * (3 - 2 * f)); }
function noise2(x, y) {
  const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy;
  const ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
  return lerp(lerp(hash2(ix, iy), hash2(ix + 1, iy), ux), lerp(hash2(ix, iy + 1), hash2(ix + 1, iy + 1), ux), uy);
}
function rng(seed) {
  let s = (Math.imul(seed | 0, 2654435761) >>> 0) || 1;
  return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
const rot2 = (x, y, a) => [x * Math.cos(a) - y * Math.sin(a), x * Math.sin(a) + y * Math.cos(a)];
const dir = a => [Math.sin(a), Math.cos(a)];      // angle 0 = straight down, +a swings toward +x

// ── transform stack that tracks ink scale ────────────────────
const JS_STACK = [];
function push(x = 0, y = 0, s = 1, r = 0, fx = 1) {
  c.save(); JS_STACK.push(G.js);
  c.translate(x, y); if (r) c.rotate(r);
  if (s !== 1 || fx !== 1) c.scale(s * fx, s);
  G.js *= s;
}
function pop() { c.restore(); G.js = JS_STACK.pop(); }

// ── inked paths ──────────────────────────────────────────────
function jitterPts(pts, amp) {
  if (amp <= 0) return pts;
  const f = 0.017 * G.js, b = G.boil * 13.37;
  return pts.map(p => [
    p[0] + (noise2(p[0] * f + b, p[1] * f) - 0.5) * 2 * amp,
    p[1] + (noise2(p[0] * f - 5.2, p[1] * f + b) - 0.5) * 2 * amp]);
}
function tracePath(pts, closed = true, smooth = true, boil = BOIL) {
  const P = jitterPts(pts, boil / G.js), n = P.length;
  c.beginPath();
  if (n < 2) return;
  c.moveTo(P[0][0], P[0][1]);
  if (!smooth || n < 3) {
    for (let i = 1; i < n; i++) c.lineTo(P[i][0], P[i][1]);
    if (closed) c.closePath();
    return;
  }
  const g = i => closed ? P[(i + n) % n] : P[Math.max(0, Math.min(n - 1, i))];
  const m = closed ? n : n - 1;
  for (let i = 0; i < m; i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    c.bezierCurveTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6,
      p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1]);
  }
  if (closed) c.closePath();
}
function fillStroke(fill, lw = LW, stroke = PAL.ink) {
  if (fill) { c.fillStyle = fill; c.fill(); }
  if (lw) { c.lineWidth = lw / G.js; c.strokeStyle = stroke; c.lineJoin = 'round'; c.lineCap = 'round'; c.stroke(); }
}
function shape(pts, fill, lw = LW, o = {}) {
  tracePath(pts, o.closed !== false, o.smooth !== false, o.boil ?? BOIL);
  fillStroke(fill, lw, o.stroke);
}
function line(pts, lw = LW2, col = PAL.ink, o = {}) {
  tracePath(pts, false, o.smooth !== false, o.boil ?? BOIL);
  c.lineWidth = lw / G.js; c.strokeStyle = col; c.lineCap = 'round'; c.lineJoin = 'round'; c.stroke();
}
// outlined limb: ink stroke then colour stroke on the same path
function tube(pts, w, fill, lw = LW, o = {}) {
  tracePath(pts, false, o.smooth ?? pts.length > 2, o.boil ?? BOIL);
  c.lineCap = o.cap || 'round'; c.lineJoin = 'round';
  if (lw) { c.strokeStyle = PAL.ink; c.lineWidth = w + 2 * lw / G.js; c.stroke(); }
  c.strokeStyle = fill; c.lineWidth = w; c.stroke();
}
function clipPts(pts, o = {}) { tracePath(pts, true, o.smooth !== false, o.boil ?? BOIL); c.clip(); }
function ellPts(x, y, rx, ry, n = 24, a0 = 0, a1 = TAU, rot = 0) {
  const pts = [];
  const closed = Math.abs(a1 - a0 - TAU) < 1e-6;
  const cnt = closed ? n : n + 1;
  for (let i = 0; i < cnt; i++) {
    const a = a0 + (a1 - a0) * i / n;
    const [px, py] = rot2(Math.cos(a) * rx, Math.sin(a) * ry, rot);
    pts.push([x + px, y + py]);
  }
  return pts;
}
function circ(x, y, r, fill, lw = LW, o = {}) {
  const n = Math.max(10, Math.min(44, Math.round(r * G.js / 5)));
  shape(ellPts(x, y, r, r, n), fill, lw, o);
}
function ell(x, y, rx, ry, fill, lw = LW, rot = 0, o = {}) {
  const n = Math.max(12, Math.min(48, Math.round(Math.max(rx, ry) * G.js / 5)));
  shape(ellPts(x, y, rx, ry, n, 0, TAU, rot), fill, lw, o);
}
function transPts(pts, dx, dy, s = 1, ax = 0, ay = 0) {
  return pts.map(p => [ax + (p[0] - ax) * s + dx, ay + (p[1] - ay) * s + dy]);
}

// Union of circles with one shared outline (foam, bubbles, mist)
function blobs(list, fill, lw = LW, shade = null, shadeOff = [0.25, 0.3]) {
  const w = lw / G.js;
  c.fillStyle = PAL.ink;
  c.beginPath(); for (const b of list) { c.moveTo(b[0] + b[2] + w, b[1]); c.arc(b[0], b[1], b[2] + w, 0, TAU); } c.fill();
  c.fillStyle = fill;
  c.beginPath(); for (const b of list) { c.moveTo(b[0] + b[2], b[1]); c.arc(b[0], b[1], b[2], 0, TAU); } c.fill();
  if (shade) {
    c.save();
    c.beginPath(); for (const b of list) { c.moveTo(b[0] + b[2], b[1]); c.arc(b[0], b[1], b[2], 0, TAU); } c.clip();
    c.fillStyle = shade;
    c.beginPath();
    for (const b of list) {
      const x = b[0] + b[2] * shadeOff[0] * 2.2, y = b[1] + b[2] * shadeOff[1] * 2.2;
      c.moveTo(x + b[2] * 0.85, y); c.arc(x, y, b[2] * 0.85, 0, TAU);
    }
    c.fill();
    c.restore();
  }
}

// ── patterns ─────────────────────────────────────────────────
const _pat = {};
function stripePat(key, cols, widths, angleDeg = 0, scale = 1) {
  if (!_pat[key]) {
    const total = widths.reduce((a, b) => a + b, 0);
    const cv = document.createElement('canvas'); cv.width = total; cv.height = 8;
    const x = cv.getContext('2d'); let px = 0;
    widths.forEach((w, i) => { x.fillStyle = cols[i % cols.length]; x.fillRect(px, 0, w, 8); px += w; });
    _pat[key] = cv;
  }
  const p = c.createPattern(_pat[key], 'repeat');
  p.setTransform(new DOMMatrix().rotate(angleDeg).scale(scale));
  return p;
}

// ── film finish: grain + vignette ────────────────────────────
const _grain = [];
function makeGrain() {
  for (let k = 0; k < 4; k++) {
    const cv = document.createElement('canvas'); cv.width = cv.height = 256;
    const x = cv.getContext('2d'); const id = x.createImageData(256, 256); const r = rng(99 + k);
    for (let i = 0; i < 256 * 256; i++) {
      const v = r();
      if (v < 0.07) { const l = r() < 0.5 ? 20 : 250; id.data[i * 4] = l; id.data[i * 4 + 1] = l; id.data[i * 4 + 2] = l + 5; id.data[i * 4 + 3] = 38 + r() * 40; }
    }
    x.putImageData(id, 0, 0); _grain.push(cv);
  }
}
function filmFinish() {
  if (!_grain.length) makeGrain();
  const r = rng(G.boil * 7 + 3);
  c.save();
  c.globalAlpha = 0.55;
  const p = c.createPattern(_grain[G.boil % 4], 'repeat');
  p.setTransform(new DOMMatrix().translate(r() * 256, r() * 256));
  c.fillStyle = p; c.fillRect(0, 0, W, H);
  c.globalAlpha = 1;
  const g = c.createRadialGradient(W / 2, H / 2, H * 0.45, W / 2, H / 2, H * 1.08);
  g.addColorStop(0, 'rgba(10,12,40,0)'); g.addColorStop(1, 'rgba(10,12,40,0.38)');
  c.fillStyle = g; c.fillRect(0, 0, W, H);
  c.restore();
}
