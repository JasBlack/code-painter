'use strict';
// ─────────────────────────────────────────────────────────────
//  Recreation engine: shared toolkit for re-drawing the t-shirt
//  artworks (style-reel/shirt_refs/sNN.jpg) in code.
//
//  A piece registers itself:   REC.register('s11', { w, h, draw(E) { ... } })
//  and draws in its own pixel space (w×h = the reference's size).
//
//  E.out            main 2D context (already scaled; draw in piece px)
//  E.w, E.h         piece size;  E.S output scale
//  E.relief()       start a relief painting -> RP (see below)
//  E.mat(o)         material: {dif, spec, shin, metal, rim, ao, grain, iri, bump, emis, wrap, coat, tint:[r,g,b]}
//  E.fx(glsl, U)    fullscreen GLSL -> canvas (w×h). glsl defines `vec3 fx(vec2 uv, vec2 px)`;
//                   helpers available: hash, vnoise, fbm, iri; uniforms uRes, uT + your own floats/vec
//  E.blur(canvas, px) / E.bloom(amount, px, filter) / E.grain(a) / E.vignette(a, col)
//  helpers (global): P(pts,closed,smooth) Path2D, blob(), ragged(), lock(), star(), rrect(), ellPts (core.js), rng, noise2, clamp, lerp
//
//  RP — relief painter (albedo buffer + height/material buffer, piece px):
//    RP.a, RP.h               raw contexts (albedo / height). Height colour = hc(h, m)
//    RP.dome(path, alb, h0, dh, wd, m)     inflated fill: edge h0 -> plateau h0+dh over wd px
//    RP.flat(path, alb, h, m)             flat fill at height h
//    RP.paint(path, alb)                  albedo only (height untouched)
//    RP.pipe(path, wd, alb, h0, dh, m)    round tube along a path
//    RP.groove(path, wd, alb, top, depth, m, albA)  engraved channel
//    RP.bead(x, y, r, alb, h0, dh, m)     sphere
//    RP.shade(cfg)            light it and draw into E.out. cfg: { mats:[...up to 8], light:[x,y,z], lc, amb,
//                              envTop, envHor, envBot, envK:[horizonGlow, softboxes, zFade, 0], shadow:[dx,dy,str,k],
//                              rimC, rimD:[dx,dy,dirAmt] (fresnel rim, times material rim),
//                              l2:[x,y,z,power], l2c:[r,g,b] (additive coloured 2nd light, times material rim),
//                              r1, r2 (height blur px), k:[0, .65, .35, normalStrength ~30 subtle .. 200 round] }
//  Height values 0..1; material ids 0..7 (0 is usually unlit/flat albedo).
// ─────────────────────────────────────────────────────────────
const REC = { pieces: {}, register(id, def) { this.pieces[id] = def; } };

// ── path helpers ─────────────────────────────────────────────
function P(pts, closed = true, smooth = true) {
  const p = new Path2D(), n = pts.length;
  if (n < 2) return p;
  p.moveTo(pts[0][0], pts[0][1]);
  if (!smooth || n < 3) { for (let i = 1; i < n; i++) p.lineTo(pts[i][0], pts[i][1]); if (closed) p.closePath(); return p; }
  const g = i => closed ? pts[(i + n) % n] : pts[Math.max(0, Math.min(n - 1, i))];
  const m = closed ? n : n - 1;
  for (let i = 0; i < m; i++) {
    const p0 = g(i - 1), p1 = g(i), p2 = g(i + 1), p3 = g(i + 2);
    p.bezierCurveTo(p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6, p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6, p2[0], p2[1]);
  }
  if (closed) p.closePath();
  return p;
}
function circleP(x, y, r) { const p = new Path2D(); p.arc(x, y, Math.max(0.01, r), 0, Math.PI * 2); return p; }
function ellipseP(x, y, rx, ry, rot = 0) { const p = new Path2D(); p.ellipse(x, y, Math.max(0.01, rx), Math.max(0.01, ry), rot, 0, Math.PI * 2); return p; }
function rrect(x, y, w, h, r) { const p = new Path2D(); p.roundRect(x, y, w, h, r); return p; }
// wobbly closed blob
function blob(x, y, rx, ry, seed, n = 14, amp = 0.25, rot = 0) {
  const r = rng(seed), pts = [];
  for (let i = 0; i < n; i++) {
    const a = i / n * Math.PI * 2, k = 1 + (r() - 0.5) * 2 * amp;
    const px = Math.cos(a) * rx * k, py = Math.sin(a) * ry * k;
    pts.push([x + px * Math.cos(rot) - py * Math.sin(rot), y + px * Math.sin(rot) + py * Math.cos(rot)]);
  }
  return pts;
}
// spikes along edges [from,to) of a polygon, pointing outward
function ragged(pts, from, to, step, amp, seed) {
  let A = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; A += p[0] * q[1] - q[0] * p[1]; }
  const sgn = A > 0 ? -1 : 1, r = rng(seed), out = [];
  for (let i = 0; i < pts.length; i++) {
    out.push(pts[i]);
    if (i < from || i >= to) continue;
    const a = pts[i], b = pts[(i + 1) % pts.length], L = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1;
    const k = Math.max(2, Math.round(L / step)), nx = sgn * (b[1] - a[1]) / L, ny = -sgn * (b[0] - a[0]) / L;
    for (let j = 1; j < k; j++) { const u = j / k, off = j % 2 ? amp * (0.5 + r() * 0.9) : -amp * 0.25 * r(); out.push([a[0] + (b[0] - a[0]) * u + nx * off, a[1] + (b[1] - a[1]) * u + ny * off]); }
  }
  return out;
}
// tapered ribbon around a centreline (w0 at root -> 0 at tip; pass w1 for a blunt end)
function lock(cl, w0, w1 = 0, pw = 0.8) {
  const L = [], R = [], n = cl.length;
  for (let i = 0; i < n; i++) {
    const p = cl[i], a = cl[Math.max(0, i - 1)], b = cl[Math.min(n - 1, i + 1)];
    let dx = b[0] - a[0], dy = b[1] - a[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
    const w = (w1 + (w0 - w1) * Math.pow(1 - i / (n - 1), pw)) / 2;
    L.push([p[0] - dy * w, p[1] + dx * w]); R.push([p[0] + dy * w, p[1] - dx * w]);
  }
  return [...L, ...R.reverse()];
}
function star(x, y, r0, r1, n, rot = 0) {
  const pts = [];
  for (let i = 0; i < n * 2; i++) { const a = rot + i / (n * 2) * Math.PI * 2, r = i % 2 ? r1 : r0; pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r]); }
  return pts;
}
// height colour: R = integer part, B = fraction (16-bit precision survives linear blur); G = material id
const hc = (hv, m) => { const v = clamp(hv) * 255, i = Math.min(255, Math.floor(v)); return `rgb(${i},${m * 32},${Math.round((v - i) * 255)})`; };
function hex2rgb(h) { const n = parseInt(h.slice(1), 16); return [(n >> 16) & 255, (n >> 8) & 255, n & 255]; }
function mixHex(a, b, t) {
  const A = hex2rgb(a), B = hex2rgb(b), f = v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, '0');
  return '#' + f(A[0] + (B[0] - A[0]) * t) + f(A[1] + (B[1] - A[1]) * t) + f(A[2] + (B[2] - A[2]) * t);
}
function rgbaHex(h, a) { const [r, g, b] = hex2rgb(h); return `rgba(${r},${g},${b},${a})`; }

// ── WebGL2 core ──────────────────────────────────────────────
const GLX = (() => {
  const SD = { cv: null, gl: null, progs: {}, tex: {}, fbo: {}, fext: false };
  const VS = `#version 300 es
void main(){ vec2 p = vec2(float((gl_VertexID << 1) & 2), float(gl_VertexID & 2)); gl_Position = vec4(p * 2.0 - 1.0, 0.0, 1.0); }`;
  const HDR = `#version 300 es
precision highp float;
uniform vec2 uRes;
uniform float uT;
out vec4 o;
float hash(vec2 p){ p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vnoise(vec2 p){ vec2 i = floor(p), f = fract(p); vec2 u = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), u.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), u.x), u.y); }
float fbm(vec2 p){ float s = 0., a = .5; for (int i = 0; i < 5; i++){ s += a * vnoise(p); p = p * 2.03 + 17.1; a *= .5; } return s; }
vec3 iri(float x){ return 0.5 + 0.5 * cos(6.2832 * (x + vec3(0., .33, .67))); }
`;
  function gl_() {
    if (SD.gl && !SD.gl.isContextLost()) return SD.gl;
    SD.cv = document.createElement('canvas'); SD.cv.width = 16; SD.cv.height = 16;
    const gl = SD.cv.getContext('webgl2', { preserveDrawingBuffer: true, antialias: false, alpha: false, depth: false, stencil: false, premultipliedAlpha: false });
    if (!gl) throw new Error('rec: WebGL2 unavailable');
    SD.gl = gl; SD.progs = {}; SD.tex = {}; SD.fbo = {};
    SD.fext = !!gl.getExtension('EXT_color_buffer_float');
    gl.getExtension('OES_texture_float_linear');
    return gl;
  }
  function compile(gl, type, src) {
    const s = gl.createShader(type);
    gl.shaderSource(s, src); gl.compileShader(s);
    if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error('rec shader: ' + gl.getShaderInfoLog(s));
    return s;
  }
  function prog(key, fs) {
    const gl = gl_();
    if (SD.progs[key]) return SD.progs[key];
    const p = gl.createProgram();
    gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, VS));
    gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, HDR + fs));
    gl.linkProgram(p);
    if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error('rec link: ' + gl.getProgramInfoLog(p));
    const U = {}, n = gl.getProgramParameter(p, gl.ACTIVE_UNIFORMS);
    for (let i = 0; i < n; i++) { const info = gl.getActiveUniform(p, i); U[info.name.replace(/\[0\]$/, '')] = { loc: gl.getUniformLocation(p, info.name), type: info.type }; }
    return (SD.progs[key] = { p, U });
  }
  function set(P_, name, v) {
    const gl = SD.gl, u = P_.U[name];
    if (!u) return;
    const a = typeof v === 'number' ? [v] : v.flat(2);
    switch (u.type) {
      case gl.FLOAT: gl.uniform1fv(u.loc, a); break;
      case gl.FLOAT_VEC2: gl.uniform2fv(u.loc, a); break;
      case gl.FLOAT_VEC3: gl.uniform3fv(u.loc, a); break;
      case gl.FLOAT_VEC4: gl.uniform4fv(u.loc, a); break;
      case gl.INT: case gl.SAMPLER_2D: gl.uniform1iv(u.loc, a.map(x => x | 0)); break;
    }
  }
  function upload(key, src) {
    const gl = gl_();
    let T = SD.tex[key];
    if (!T) {
      T = SD.tex[key] = gl.createTexture();
      gl.bindTexture(gl.TEXTURE_2D, T);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
      gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    }
    gl.bindTexture(gl.TEXTURE_2D, T);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
    gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, src);
    gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, false);
    return T;
  }
  function fbo(key, w, h) {
    const gl = gl_();
    let F = SD.fbo[key];
    if (F && F.w === w && F.h === h) return F;
    if (F) { gl.deleteTexture(F.tex); gl.deleteFramebuffer(F.fb); }
    const tex = gl.createTexture();
    gl.bindTexture(gl.TEXTURE_2D, tex);
    if (SD.fext) gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA16F, w, h, 0, gl.RGBA, gl.HALF_FLOAT, null);
    else gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA8, w, h, 0, gl.RGBA, gl.UNSIGNED_BYTE, null);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
    gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
    const fb = gl.createFramebuffer();
    gl.bindFramebuffer(gl.FRAMEBUFFER, fb);
    gl.framebufferTexture2D(gl.FRAMEBUFFER, gl.COLOR_ATTACHMENT0, gl.TEXTURE_2D, tex, 0);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return (SD.fbo[key] = { tex, fb, w, h });
  }
  function pass(key, fs, target, w, h, U, T) {
    const gl = gl_(), Pp = prog(key, fs);
    if (target) gl.bindFramebuffer(gl.FRAMEBUFFER, fbo(target, w, h).fb);
    else { if (SD.cv.width !== w || SD.cv.height !== h) { SD.cv.width = w; SD.cv.height = h; } gl.bindFramebuffer(gl.FRAMEBUFFER, null); }
    gl.viewport(0, 0, w, h);
    gl.useProgram(Pp.p);
    let unit = 0;
    for (const k in T || {}) { gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, T[k]); set(Pp, k, unit); unit++; }
    set(Pp, 'uRes', [w, h]);
    for (const k in U || {}) set(Pp, k, U[k]);
    gl.drawArrays(gl.TRIANGLES, 0, 3);
    gl.bindFramebuffer(gl.FRAMEBUFFER, null);
    return target ? SD.fbo[target].tex : SD.cv;
  }
  return { pass, upload, gl_, fext: () => SD.fext };
})();

// ── relief lighting ──────────────────────────────────────────
const FS_BLUR = `
uniform sampler2D uTex; uniform vec2 uDir; uniform vec2 uR; uniform float uFirst;
void main(){
  vec2 px = 1. / uRes, p = gl_FragCoord.xy * px;
  float s1 = 0., s2 = 0., ws = 0.;
  for (int i = -7; i <= 7; i++) {
    float f = float(i) / 7., w = exp(-f * f * 2.6);
    vec4 a = texture(uTex, p + uDir * px * f * uR.x);
    vec4 b = texture(uTex, p + uDir * px * f * uR.y);
    s1 += (uFirst > .5 ? a.r + a.b / 255. : a.r) * w; s2 += (uFirst > .5 ? b.r + b.b / 255. : b.g) * w; ws += w;
  }
  o = vec4(s1 / ws, s2 / ws, 0., 1.);
}`;
const FS_SHADE = `
uniform sampler2D uAlb, uHgt, uBl;
uniform vec4 uK;
uniform vec3 uL, uLc, uAmb, uRimC, uRimD, uL2c; uniform vec4 uL2;
uniform vec3 uEnvTop, uEnvHor, uEnvBot; uniform vec4 uEnvK;
uniform vec4 uM0[8]; uniform vec4 uM1[8]; uniform vec4 uM2[8]; uniform vec4 uMC[8];
uniform vec4 uShadow;
float Hs(vec2 p){ vec4 b = texture(uBl, p); return uK.y * b.r + uK.z * b.g; }
vec3 env(vec3 r){
  float y = r.y;
  vec3 sky = mix(uEnvHor, uEnvTop, smoothstep(0.02, 0.85, y));
  vec3 gnd = mix(uEnvHor * 0.45 + uEnvBot * 0.55, uEnvBot, smoothstep(-0.02, -0.55, y));
  vec3 c = mix(gnd, sky, smoothstep(-0.025, 0.025, y));
  c += uEnvK.x * exp(-abs(y + 0.04) * 38.);
  c += uEnvK.y * smoothstep(0.90, 0.965, dot(r, normalize(vec3(-0.55, 0.55, 0.63))));
  c += uEnvK.y * 0.55 * smoothstep(0.93, 0.985, dot(r, normalize(vec3(0.62, 0.3, 0.72))));
  c = mix(c, uEnvBot * 0.6 + uEnvHor * 0.4, smoothstep(0.75, 1.0, r.z) * uEnvK.z);
  return c;
}
void main(){
  vec2 px = 1. / uRes, p = gl_FragCoord.xy * px, q = gl_FragCoord.xy;
  vec4 A = texture(uAlb, p), R = texture(uHgt, p), B = texture(uBl, p);
  int m = clamp(int(R.g * 255. / 32. + .5), 0, 7);
  vec4 M0 = uM0[m], M1 = uM1[m], M2 = uM2[m], MC = uMC[m];
  float h = uK.y * B.r + uK.z * B.g + uK.x * (R.r + R.b / 255.);
  float hx = Hs(p + vec2(px.x, 0.)) - Hs(p - vec2(px.x, 0.));
  float hy = Hs(p + vec2(0., px.y)) - Hs(p - vec2(0., px.y));
  vec3 n = normalize(vec3(-hx * uK.w * M2.x, -hy * uK.w * M2.x, 1.));
  if (M1.z > 0.) {
    float g1 = vnoise(q * 0.09) - .5, g2 = vnoise(q * 0.09 + 31.7) - .5;
    n = normalize(n + M1.z * vec3(g1 + (hash(q) - .5) * .35, g2 + (hash(q + 7.13) - .5) * .35, 0.));
  }
  vec3 alb = A.rgb, col;
  if (M0.x <= 0. && M0.w <= 0.) col = alb * (1.0 + M2.y);
  else {
    vec3 L = normalize(uL), V = vec3(0, 0, 1);
    float ndl = dot(n, L), wrap = M2.z;
    float dif = clamp((ndl + wrap) / (1. + wrap), 0., 1.);
    float cav = clamp((B.g - B.r) * M1.y * 10., 0., 1.);
    float ao = 1. - cav * 0.8;
    float sh = 1.;
    if (uShadow.z > 0.) {
      float hs = texture(uBl, p + uShadow.xy * px).g, h0 = B.g;
      sh = 1. - uShadow.z * clamp((hs - h0) * uShadow.w, 0., 1.);
    }
    vec3 Hv = normalize(L + V);
    float sp = pow(max(dot(n, Hv), 0.), M0.z) * M0.y;
    vec3 r = reflect(-V, n);
    vec3 e = env(r);
    float fr = pow(1. - clamp(n.z, 0., 1.), 3.);
    vec3 dcol = alb * (uAmb + uLc * dif * sh) * ao * M0.x;
    vec3 mcol = e * alb * MC.rgb * mix(1., ao, 0.6) * mix(1., sh, 0.5);
    col = mix(dcol, mcol, M0.w);
    col += e * M2.w * (0.05 + 0.95 * fr) * ao;
    col += sp * uLc * mix(1., sh, 0.8);
    vec2 nd = normalize(n.xy + 1e-5);
    float rimSide = clamp(dot(nd, normalize(uRimD.xy + 1e-5)) * .5 + .5, 0., 1.);
    col += uRimC * M1.x * pow(1. - clamp(n.z, 0., 1.), 1.6) * mix(1., pow(rimSide, 2.5) * 2., uRimD.z);
    col += uL2c * M1.x * pow(max(dot(n, normalize(uL2.xyz)), 0.), max(uL2.w, 0.5)) * mix(1., sh, 0.3);
    col += iri(fr * 1.6 + h * 2.5 + uT * 0.05) * M1.w * (0.25 + fr);
    col += alb * M2.y;
  }
  o = vec4(col, 1.);
}`;
function mat(o = {}) {
  return [
    [o.dif ?? 0, o.spec ?? 0, o.shin ?? 30, o.metal ?? 0],
    [o.rim ?? 0, o.ao ?? 0, o.grain ?? 0, o.iri ?? 0],
    [o.bump ?? 1, o.emis ?? 0, o.wrap ?? 0, o.coat ?? 0],
    [...(o.tint || [1, 1, 1]), 1]
  ];
}

// ── engine instance ──────────────────────────────────────────
function makeEngine(canvas, w, h, S) {
  const out = canvas.getContext('2d', { willReadFrequently: true });
  const W2 = Math.round(w * S), H2 = Math.round(h * S);
  canvas.width = W2; canvas.height = H2;
  out.setTransform(S, 0, 0, S, 0, 0);
  const newCanvas = () => { const c2 = document.createElement('canvas'); c2.width = W2; c2.height = H2; return c2; };
  const E = { out, w, h, S, canvas, mat, newCanvas };

  E.relief = () => {
    const A = newCanvas(), Hc = newCanvas();
    // (CPU-backed: as GPU canvases the relief buffers could be silently wiped mid-drawing — flat, unlit domes)
    const a = A.getContext('2d', { willReadFrequently: true }), hx = Hc.getContext('2d', { willReadFrequently: true });
    for (const x of [a, hx]) { x.fillStyle = '#000'; x.fillRect(0, 0, W2, H2); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; }
    const sc = () => { const m = hx.getTransform(); return Math.hypot(m.a, m.b); };
    const RP = { a, h: hx, A, H: Hc };
    RP.dome = (path, alb, h0, dh, wd, m) => {
      if (alb) { a.fillStyle = alb; a.fill(path); }
      const steps = Math.min(90, Math.max(2, Math.ceil(wd * sc() / 0.9)));
      hx.save(); hx.clip(path);
      hx.fillStyle = hc(h0 + dh, m); hx.fill(path);
      for (let k = steps - 1; k >= 1; k--) {
        const u = k / steps, uu = (k - 0.5) / steps;
        hx.lineWidth = 2 * wd * u; hx.strokeStyle = hc(h0 + dh * Math.sqrt(1 - (1 - uu) * (1 - uu)), m); hx.stroke(path);
      }
      hx.restore();
    };
    RP.flat = (path, alb, hv, m) => { if (alb) { a.fillStyle = alb; a.fill(path); } hx.fillStyle = hc(hv, m); hx.fill(path); };
    RP.paint = (path, alb) => { a.fillStyle = alb; a.fill(path); };
    RP.pipe = (path, wd, alb, h0, dh, m) => {
      if (alb) { a.lineWidth = wd; a.strokeStyle = alb; a.stroke(path); }
      const steps = Math.min(40, Math.max(2, Math.ceil(wd * 0.5 * sc() / 0.9)));
      for (let k = 0; k < steps; k++) {
        const u = 1 - k / steps, uu = 1 - (k + 0.5) / steps;
        hx.lineWidth = wd * u; hx.strokeStyle = hc(h0 + dh * Math.sqrt(1 - uu * uu), m); hx.stroke(path);
      }
    };
    RP.groove = (path, wd, alb, top, depth, m, albA = 0.8) => {
      if (alb) { a.save(); a.globalAlpha *= albA; a.lineWidth = wd * 0.7; a.strokeStyle = alb; a.stroke(path); a.restore(); }
      const steps = Math.min(24, Math.max(2, Math.ceil(wd * 0.5 * sc() / 0.9)));
      for (let k = 0; k < steps; k++) { const u = 1 - k / steps; hx.lineWidth = wd * u; hx.strokeStyle = hc(top - depth * Math.sqrt(1 - u * u + 0.02), m); hx.stroke(path); }
    };
    RP.bead = (x, y, r, alb, h0, dh, m) => RP.dome(circleP(x, y, r), alb, h0, dh ?? Math.min(0.35, r * 0.012 + 0.05), r, m);
    RP.shade = (cfg) => {
      const k = S;
      const C = Object.assign({
        r1: 1.6, r2: 7, k: [0, 0.65, 0.35, 34], light: [-0.55, 0.62, 0.56], lc: [1, 1, 1], amb: [0.2, 0.2, 0.22],
        envTop: [1, 0.99, 0.96], envHor: [0.42, 0.42, 0.44], envBot: [0.02, 0.02, 0.025], envK: [0.7, 1.3, 0.45, 0],
        shadow: [-5, 5, 0.7, 7], rimC: [0, 0, 0], rimD: [0, 1, 0], l2: [1, 0, 0.3, 1], l2c: [0, 0, 0], t: 0
      }, cfg);
      const mats = C.mats.concat(Array(Math.max(0, 8 - C.mats.length)).fill(mat({})));
      const tA = GLX.upload('alb', A), tH = GLX.upload('hgt', Hc);
      const b1 = GLX.pass('blur', FS_BLUR, 'bA', W2, H2, { uDir: [1, 0], uR: [C.r1 * k, C.r2 * k], uFirst: 1 }, { uTex: tH });
      const tB = GLX.pass('blur', FS_BLUR, 'bB', W2, H2, { uDir: [0, 1], uR: [C.r1 * k, C.r2 * k], uFirst: 0 }, { uTex: b1 });
      const res = GLX.pass('shade', FS_SHADE, null, W2, H2, {
        uT: C.t, uK: [C.k[0], C.k[1], C.k[2], C.k[3] * k], uL: C.light, uLc: C.lc, uAmb: C.amb, uRimC: C.rimC, uRimD: C.rimD, uL2: C.l2, uL2c: C.l2c,
        uEnvTop: C.envTop, uEnvHor: C.envHor, uEnvBot: C.envBot, uEnvK: C.envK, uShadow: [C.shadow[0] * k, C.shadow[1] * k, C.shadow[2], C.shadow[3]],
        uM0: mats.map(m => m[0]), uM1: mats.map(m => m[1]), uM2: mats.map(m => m[2]), uMC: mats.map(m => m[3])
      }, { uAlb: tA, uHgt: tH, uBl: tB });
      out.save(); out.setTransform(1, 0, 0, 1, 0, 0); out.drawImage(res, 0, 0); out.restore();
    };
    return RP;
  };

  // fullscreen GLSL -> canvas (copy, so repeated fx calls don't alias)
  let fxN = 0;
  E.fx = (glsl, U = {}) => {
    const key = 'fx' + (fxN++) + ':' + glsl.length;
    let decl = '';
    for (const k in U) {
      const v = U[k], n = typeof v === 'number' ? 1 : v.length;
      decl += `uniform ${n === 1 ? 'float' : 'vec' + n} ${k};\n`;
    }
    const fs = decl + glsl + `\nvoid main(){ vec2 px = gl_FragCoord.xy; vec2 uv = vec2(px.x, uRes.y - px.y) / uRes; o = vec4(fx(uv, vec2(uv.x * ${w.toFixed(1)}, uv.y * ${h.toFixed(1)})), 1.); }`;
    const res = GLX.pass(key, fs, null, W2, H2, U, {});
    const c2 = newCanvas(); c2.getContext('2d').drawImage(res, 0, 0);
    return c2;
  };
  E.draw = (cv, alpha = 1, op = 'source-over') => { out.save(); out.setTransform(1, 0, 0, 1, 0, 0); out.globalAlpha = alpha; out.globalCompositeOperation = op; out.drawImage(cv, 0, 0, W2, H2); out.restore(); };
  E.snapshot = () => { const c2 = newCanvas(); c2.getContext('2d').drawImage(canvas, 0, 0); return c2; };
  E.blur = (cv, px) => { const c2 = newCanvas(), x = c2.getContext('2d'); x.filter = `blur(${px * S}px)`; x.drawImage(cv, 0, 0); return c2; };
  E.bloom = (amount = 0.3, px = 12, filt = 'brightness(0.9) contrast(1.6)') => {
    const c2 = newCanvas(), x = c2.getContext('2d'); x.filter = `${filt} blur(${px * S}px)`; x.drawImage(canvas, 0, 0);
    E.draw(c2, amount, 'screen');
  };
  E.grain = (amt = 0.06, seed = 1) => {
    const g = document.createElement('canvas'); g.width = 256; g.height = 256;
    const x = g.getContext('2d'), id = x.createImageData(256, 256), r = rng(seed);
    for (let i = 0; i < 65536; i++) { const v = 128 + (r() - 0.5) * 255; id.data[i * 4] = id.data[i * 4 + 1] = id.data[i * 4 + 2] = v; id.data[i * 4 + 3] = 255; }
    x.putImageData(id, 0, 0);
    out.save(); out.setTransform(1, 0, 0, 1, 0, 0); out.globalAlpha = amt; out.globalCompositeOperation = 'overlay';
    out.fillStyle = out.createPattern(g, 'repeat'); out.fillRect(0, 0, W2, H2); out.restore();
  };
  E.vignette = (a = 0.3, col = '0,0,0', inner = 0.5, outer = 1.0) => {
    const g = out.createRadialGradient(w / 2, h / 2, Math.min(w, h) * inner * 0.5, w / 2, h / 2, Math.hypot(w, h) * outer * 0.5);
    g.addColorStop(0, `rgba(${col},0)`); g.addColorStop(1, `rgba(${col},${a})`);
    out.fillStyle = g; out.fillRect(0, 0, w, h);
  };
  return E;
}
