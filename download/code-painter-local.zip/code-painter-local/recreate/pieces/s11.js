'use strict';
// s11 — "Violet clay, orange rim-light": a violet clay slab of bumps and
// incised doodles, an indigo rim band, flat orange ground.
REC.register('s11', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a;
    // orange ground (unlit, material 0)
    const g = a.createLinearGradient(700, 0, 1024, 1024);
    g.addColorStop(0, '#f28c0b'); g.addColorStop(1, '#ea7708');
    R.flat(rrect(-10, -10, 1044, 1044, 0), g, 0.0, 0);

    // indigo rim band with a bright blue inner edge
    const band = [[690, -40], [996, -40], [980, 80], [938, 210], [893, 350], [860, 470], [824, 590], [774, 700], [716, 820], [668, 930], [634, 1064], [420, 1064]];
    const bgd = a.createLinearGradient(0, 0, 0, 1024); bgd.addColorStop(0, '#5a46cc'); bgd.addColorStop(0.5, '#3a2ea8'); bgd.addColorStop(1, '#2a2090');
    R.dome(P(band), bgd, 0.02, 0.2, 60, 2);
    const edge = [[824, -30], [812, 0], [800, 90], [788, 128], [770, 230], [751, 320], [738, 420], [720, 492], [702, 545], [680, 610], [656, 672], [628, 736], [602, 800], [578, 860], [548, 920], [504, 962], [470, 1064]];
    R.pipe(P(edge.map(([x, y]) => [x + 26, y]), false), 22, '#2255c0', 0.1, 0.1, 2);

    // violet slab
    const slab = [[-40, -40], ...edge.map(([x, y]) => [x + 10, y]), [-40, 1064]];
    const sg = a.createRadialGradient(220, 180, 0, 220, 180, 1000);
    sg.addColorStop(0, '#a898f4'); sg.addColorStop(0.3, '#8c7cf0'); sg.addColorStop(0.62, '#7664e6'); sg.addColorStop(0.85, '#5a44cc'); sg.addColorStop(1, '#40309a');
    R.dome(P(slab), sg, 0.06, 0.26, 150, 4);
    { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(E.S, 0, 0, E.S, 0, 0); x.strokeStyle = '#2a1030'; x.lineWidth = 110; x.lineJoin = 'round';
      x.stroke(P(edge.map(([ex, ey]) => [ex - 40, ey]), false));
      a.save(); a.clip(P(slab)); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = 0.75; a.filter = `blur(${22 * E.S}px)`; a.drawImage(c, 0, 0); a.restore(); }
    R.groove(P(edge, false), 7, '#140c30', 0.22, 0.05, 1, 0.9);

    // raised top-right lobe with brain-maze texture; its lower-right rim catches the orange light
    const lobe = [[520, -40], [812, -40], [804, 30], [790, 92], [764, 146], [724, 184], [664, 202], [604, 198], [562, 172], [532, 124], [520, 60]];
    const lg = a.createLinearGradient(540, 40, 780, 140); lg.addColorStop(0, '#6c56e8'); lg.addColorStop(0.5, '#4a3aae'); lg.addColorStop(1, '#3a2c8c');
    R.dome(P(lobe), lg, 0.3, 0.2, 70, 1);
    const mz = rng(11);
    for (let i = 0; i < 110; i++) {
      let x = 540 + mz() * 240, y = mz() * 180; const pts = [[x, y]];
      let ang = mz() * 6.28;
      for (let k = 0; k < 6; k++) { ang += (mz() - 0.5) * 2.2; x += Math.cos(ang) * 8; y += Math.sin(ang) * 8; pts.push([x, y]); }
      if (y > 170 || x > 770) continue;
      R.groove(P(pts, false), 4, '#2c2270', 0.5, 0.012, 2, 0.6);
    }
    R.groove(P(lobe.slice(1, 9), false), 9, '#120a2a', 0.3, 0.08, 1, 0.95);

    // bumps: [x, y, rx, ry, rot, height]
    const bumps = [[40, 166, 72, 62, 0, 0.1], [300, 166, 62, 58, 0, 0.1], [672, 328, 57, 57, 0, 0.14], [240, 542, 78, 90, 0, 0.16],
      [598, 506, 95, 62, -0.12, 0.14], [488, 632, 90, 40, 0.1, 0.1], [556, 688, 44, 40, 0, 0.09], [92, 724, 110, 112, 0, 0.2],
      [416, 808, 118, 112, 0, 0.2], [350, 995, 72, 70, 0, 0.14]];
    for (const [x, y, rx, ry, rot, dh] of bumps) {
      const p = ellipseP(x, y, rx, ry, rot);
      const mm = x < 340 || y > 950 ? 5 : 1;
      R.dome(p, '#6654d8', 0.3, dh * 1.8, Math.min(rx, ry) * 1.0, mm);
      R.groove(p, 6, '#130b2e', 0.31, 0.05, mm, 0.95);
    }
    // donut ear
    const dn = ellipseP(506, 276, 58, 56);
    R.dome(dn, '#5f47dc', 0.3, 0.24, 56, 1);
    R.groove(dn, 6, '#130b2e', 0.31, 0.05, 1, 0.95);
    R.dome(ellipseP(496, 268, 20, 17, 0.3), '#4b35c0', 0.36, -0.08, 14, 1);
    R.groove(P([[478, 250], [492, 262], [510, 262], [516, 282]], false), 5, '#130b2e', 0.44, 0.03, 1);

    // nose squiggle
    R.pipe(P([[112, 270], [128, 262], [148, 270], [166, 262], [186, 272]], false), 22, '#7058e4', 0.34, 0.06, 1);
    R.groove(P([[108, 280], [150, 284], [190, 278]], false), 4, '#130b2e', 0.36, 0.02, 1, 0.7);

    // brows
    R.groove(P([[12, 72], [50, 64], [88, 72]], false), 7, '#130b2e', 0.32, 0.04, 1);
    R.groove(P([[204, 96], [250, 72], [296, 66]], false), 12, '#1c1450', 0.32, 0.04, 1);

    // clay worm figure between the bumps (a lumpy "y")
    R.pipe(P([[212, 650], [220, 690], [230, 728], [238, 758]], false), 30, '#6c54e0', 0.33, 0.1, 1);
    R.pipe(P([[236, 754], [262, 750], [284, 744], [300, 736]], false), 28, '#6c54e0', 0.33, 0.1, 1);
    R.pipe(P([[238, 758], [241, 800], [233, 840], [216, 870], [200, 884]], false), 34, '#6c54e0', 0.33, 0.1, 1);
    R.groove(P([[204, 660], [212, 700], [222, 740]], false), 4, '#130b2e', 0.36, 0.03, 1);
    R.groove(P([[190, 896], [214, 892], [236, 872], [258, 830], [262, 790], [300, 770], [318, 752]], false), 5, '#130b2e', 0.34, 0.03, 1);

    // tongue lip (black line crossing into the lump)
    R.groove(P([[400, 636], [440, 628], [500, 640], [560, 660]], false), 5, '#130b2e', 0.4, 0.03, 1);
    R.groove(P([[476, 578], [482, 600], [506, 604]], false), 5, '#130b2e', 0.36, 0.03, 1);

    // hairline doodles
    const dashes = [[[92, 104], [98, 126]], [[380, 92], [412, 150], [436, 222]], [[470, 124], [498, 150], [520, 196]], [[540, 138], [566, 162]],
      [[214, 326], [218, 346]], [[346, 286], [350, 302]], [[392, 294], [398, 312]], [[308, 338], [330, 362]], [[306, 370], [320, 392]],
      [[72, 400], [90, 422]], [[380, 418], [388, 446]], [[456, 440], [462, 470]], [[486, 452], [492, 486]], [[372, 494], [376, 530]],
      [[466, 504], [470, 540]], [[4, 420], [10, 450]], [[14, 836], [4, 858]], [[40, 930], [44, 956]], [[132, 870], [150, 894]],
      [[176, 954], [186, 978]], [[270, 924], [262, 944]], [[296, 936], [300, 956]], [[124, 848], [196, 846]], [[60, 72], [30, 70]]];
    for (const d of dashes) R.groove(P(d, false), 6, '#140c30', 0.33, 0.04, 1, 0.95);
    // orange stripe at the bottom left
    R.pipe(P([[104, 936], [114, 980], [122, 1030]], false), 9, '#f08a10', 0.33, 0.04, 3);

    // corner shading: bottom-left falls into shadow, top-left edge less hot
    { const cg = a.createRadialGradient(0, 1060, 0, 0, 1060, 260); cg.addColorStop(0, 'rgba(18,10,70,0.8)'); cg.addColorStop(1, 'rgba(18,10,70,0)');
      a.save(); a.clip(P(slab)); a.fillStyle = cg; a.fillRect(0, 760, 300, 264);
      const tg = a.createRadialGradient(0, 0, 0, 0, 0, 120); tg.addColorStop(0, 'rgba(70,50,190,0.6)'); tg.addColorStop(1, 'rgba(70,50,190,0)'); a.fillStyle = tg; a.fillRect(0, 0, 130, 130); a.restore(); }
    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 16, grain: 0.05, wrap: 0.15, rim: 1.4, ao: 0.4 }),   // 1 violet clay
        E.mat({ dif: 1, spec: 0.08, shin: 8, grain: 0.3, wrap: 0.2, rim: 0 }),                 // 2 rough indigo band
        E.mat({ dif: 1, spec: 0.3, shin: 20, emis: 0.3, wrap: 0.3, rim: 0.4 }),                 // 3 orange paint
        E.mat({ dif: 1, spec: 0.3, shin: 16, grain: 0.05, wrap: 0.15, rim: 0.15, ao: 0.4 }),  // 4 slab body (little orange spill)
        E.mat({ dif: 1, spec: 0.3, shin: 16, grain: 0.05, wrap: 0.15, rim: 0.45, ao: 0.4 })   // 5 left bumps (far from the orange light)
      ],
      light: [-0.65, 0.6, 0.42], lc: [1.25, 1.2, 1.2], amb: [0.2, 0.16, 0.3],
      rimC: [0.45, 0.12, 0], rimD: [1, -0.2, 1], l2: [1, -0.2, -0.12, 1.1], l2c: [1.6, 0.4, -0.3], r1: 3, r2: 9, k: [0, 0.6, 0.4, 170],
      shadow: [-6, 6, 0.55, 6]
    });
    E.grain(0.05, 3);
  }
});
