'use strict';
// s31 — "Op-art transmission": black/white concentric rings and zebra-striped planes, a white
// starburst on a black starfield, a slanted rainbow bar with a heartbeat trace, a grey jet
// and periscope, and a grey control deck with blue/orange windows.
REC.register('s31', {
  w: 1024, h: 1024,
  draw(E) {
    const W = 1024, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const INK = '#060e16', PAPER = '#eef0f3', GREY = '#a6a9b0', GREYD = '#5c616a';
    // hatch a region with parallel bands (angle a, period p, duty d)
    const hatch = (path, a, p, d, c, bg) => clipped(path, () => {
      if (bg) fill(path, bg);
      const ca = Math.cos(a), sa = Math.sin(a);
      for (let k = -60; k < 60; k++) {
        const off = k * p, x0 = 512 + -sa * off, y0 = 512 + ca * off;
        fill(poly([[x0 - ca * 1500, y0 - sa * 1500], [x0 + ca * 1500, y0 + sa * 1500], [x0 + ca * 1500 - sa * p * d, y0 + sa * 1500 + ca * p * d], [x0 - ca * 1500 - sa * p * d, y0 - sa * 1500 + ca * p * d]]), c);
      }
    });

    // ── concentric op-art rings (base) ──
    // rings centred at the bar's left end; they tighten towards the edges (period 32 -> ~21)
    const rings = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float d = length(p - vec2(470., 511.));
      float ph = d / 32. + .000042 * pow(max(0., d - 250.), 2.) + .08 * (fbm(p * .008) - .5);
      float v = sin(6.2832 * (ph - 1.172)) + (vnoise(p * .3) - .5) * .25;
      return vec3(mix(.03, .94, smoothstep(-.1, .1, v))); }`);
    E.draw(rings);

    // ── top-left: horizontal zebra field ──
    const tl = poly([[0, 26], [490, 26], [492, 300], [420, 320], [330, 350], [240, 380], [150, 400], [60, 420], [0, 430]]);
    clipped(tl, () => { fill(tl, PAPER); for (let y = 36; y < 440; y += 13.3) fill(P([[0, y], [500, y + 1], [500, y + 7.6], [0, y + 6.6]], true, false), INK); });
    // curved striped hills on the lower part of the field
    const hill = P([[40, 360], [120, 322], [220, 300], [330, 290], [430, 300], [492, 300], [480, 380], [360, 400], [220, 420], [90, 430], [30, 420]]);
    hatch(hill, -0.12, 18, 0.5, INK, '#d8dade');
    // grey planks with diagonal hatching
    const plank = (pts, a) => { const pth = poly(pts); fill(pth, GREY); hatch(pth, a, 22, 0.45, '#1a2028'); stroke(pth, INK, 3); };
    plank([[0, 150], [500, 16], [500, 58], [0, 208]], -1.0);
    plank([[20, 232], [396, 178], [400, 208], [20, 262]], -1.1);
    plank([[250, 140], [480, 110], [490, 140], [260, 170]], -0.9);
    // the knife / feather at the top
    const knife = poly([[248, 16], [330, 22], [420, 38], [510, 62], [560, 84], [500, 78], [400, 52], [300, 30]]);
    fill(knife, '#50565e'); hatch(knife, -1.2, 10, 0.5, INK); stroke(knife, INK, 2);
    // glasses
    for (const [x, y] of [[62, 322], [160, 318]]) {
      const ln = ellipseP(x, y, 46, 34, 0);
      hatch(ln, -1.2, 18, 0.5, INK, PAPER); stroke(ln, GREYD, 7);
    }
    stroke(P([[108, 318], [114, 312]], false), GREYD, 6);

    // ── top right: black starfield with a white starburst ──
    const sky = poly([[486, 0], [1024, 0], [1024, 432], [512, 432], [500, 360], [488, 300]]);
    clipped(sky, () => {
      fill(sky, '#05080c');
      const sr = rng(31);
      for (let i = 0; i < 260; i++) fill(circleP(486 + sr() * 540, sr() * 432, 0.6 + sr() * 1.6), 'rgba(240,244,250,0.9)');
      const cx = 730, cy = 180;
      for (let i = 0; i < 90; i++) {
        const a = sr() * Math.PI * 2, r0 = 30 + sr() * 50, r1 = r0 + 100 + sr() * 240, wd = 4 + sr() * 12;
        stroke(P([[cx + Math.cos(a) * r0, cy + Math.sin(a) * r0], [cx + Math.cos(a) * r1, cy + Math.sin(a) * r1]], false), PAPER, wd * (sr() < 0.5 ? 1 : 0.5));
      }
      fill(P(star(cx, cy, 170, 70, 40, 0.1)), PAPER); fill(P(blob(cx, cy, 130, 110, 7, 30, 0.3)), PAPER);
      for (let i = 0; i < 40; i++) { const a = sr() * 6.28, r = 20 + sr() * 90; fill(ellipseP(cx + Math.cos(a) * r, cy + Math.sin(a) * r, 2 + sr() * 6, 1 + sr() * 2, a), INK); }
      // short dashes around the burst
      for (let i = 0; i < 70; i++) { const a = sr() * 6.28, r = 150 + sr() * 150; stroke(P([[cx + Math.cos(a) * r, cy + Math.sin(a) * r], [cx + Math.cos(a) * (r + 8), cy + Math.sin(a) * (r + 8)]], false), PAPER, 2); }
      stroke(P([[486, 110], [600, 40], [700, 0]], false), PAPER, 10);
      stroke(P([[800, 360], [900, 300], [1024, 250]], false), PAPER, 6);
    });
    // white dragon-like streak from the burst to the left
    const drag = P(ragged([[366, 262], [400, 246], [440, 226], [500, 200], [560, 176], [640, 160], [700, 150], [780, 160], [760, 230], [700, 250], [640, 262], [580, 280], [520, 300], [460, 312], [410, 310], [380, 302], [360, 284]], 0, 17, 10, 7, 12), true, false);
    fill(drag, PAPER);
    const dr = rng(8);
    clipped(drag, () => { for (let i = 0; i < 60; i++) fill(ellipseP(380 + dr() * 380, 180 + dr() * 130, 2 + dr() * 7, 1 + dr() * 2, dr() * 0.4), INK); });
    stroke(drag, INK, 3);
    fill(ellipseP(384, 284, 12, 9, 0), INK); fill(circleP(386, 282, 3), PAPER);

    // ── slanted rainbow bar with a heartbeat trace ──
    const bar = poly([[510, 432], [1024, 432], [1024, 548], [466, 572]]);
    clipped(bar, () => {
      const cols = ['#2285d0', '#36a6d5', '#4ab777', '#58bb5e', '#f1ed3f', '#fba034', '#f25a37', '#e94441', '#de285a', '#c60e81', '#873e9e', '#762f98', '#2d399a', '#243274', '#4a5aa8', '#6e86c0'];
      for (let i = 0; i < cols.length; i++) { const x = 440 + i * 36; fill(poly([[x + 40, 420], [x + 80, 420], [x + 40, 590], [x, 590]]), cols[i]); }
    });
    const hb = [[470, 506]];
    for (let x = 480; x < 960; x += 8) { const beat = (x - 530) % 90; hb.push([x, 506 + (beat > 0 && beat < 20 ? (beat < 8 ? -16 : beat < 14 ? 14 : -4) : 0)]); }
    stroke(P(hb, false, false), '#f8f8fa', 2);
    // striped grey dome at the bar's right end
    const dome = P([[944, 560], [952, 490], [980, 452], [1024, 440], [1024, 570]]);
    hatch(dome, -1.1, 14, 0.5, '#3a4048', '#b8bcc3'); stroke(dome, INK, 3);

    // ── grey jet, periscope tower, cockpit ring ──
    const jet = P([[244, 673], [333, 618], [467, 584], [622, 573], [778, 584], [889, 566], [967, 551], [956, 607], [778, 629], [622, 623], [489, 640], [367, 668], [278, 680]]);
    fill(jet, GREY); stroke(jet, INK, 4);
    clipped(jet, () => { for (let i = 0; i < 16; i++) stroke(P([[300 + i * 40, 690], [330 + i * 40, 580]], false), 'rgba(60,64,72,0.6)', 2); fill(poly([[244, 673], [460, 620], [470, 650], [278, 680]]), '#7a7e86'); });
    const tower = poly([[860, 548], [900, 548], [906, 640], [852, 640]]);
    fill(tower, '#8a8e96'); stroke(tower, INK, 3);
    stroke(P([[880, 548], [884, 520]], false), INK, 8); stroke(P([[872, 640], [900, 640]], false), INK, 3);
    for (let y = 560; y < 640; y += 14) stroke(P([[856, y], [904, y]], false), '#4a4e56', 2);
    stroke(P([[668, 628], [830, 708]], false), '#8a8e96', 22); stroke(P([[668, 628], [830, 708]], false), INK, 3);
    fill(circleP(868, 730, 54), '#9a9ea6'); stroke(circleP(868, 730, 54), INK, 4);
    fill(circleP(872, 732, 38), '#4db3d8'); stroke(circleP(872, 732, 38), INK, 3);
    for (let i = 0; i < 8; i++) { const a = -2.4 + i * 0.25; stroke(P([[872 + Math.cos(a) * 30, 732 + Math.sin(a) * 30], [872 + Math.cos(a) * 36, 732 + Math.sin(a) * 36]], false), INK, 2); }
    fill(circleP(880, 742, 5), INK);

    // ── long diagonal wing to the bottom right ──
    const wing = poly([[540, 790], [640, 770], [800, 820], [1024, 880], [1024, 930], [800, 890], [620, 840]]);
    hatch(wing, 0.28, 12, 0.55, '#20262e', '#8e929a'); stroke(wing, INK, 3);

    // ── control deck: slanted roof, panel with dials and windows ──
    const roof = poly([[0, 712], [220, 700], [480, 690], [700, 700], [710, 740], [540, 790], [0, 800]]);
    fill(roof, '#8a8e96');
    clipped(roof, () => { for (let i = 0; i < 30; i++) stroke(P([[i * 26, 800], [i * 26 + 30, 700]], false), '#4a4e56', 2); fill(poly([[0, 770], [540, 760], [540, 800], [0, 800]]), '#6a6e76'); });
    stroke(roof, INK, 4);
    stroke(P([[280, 730], [300, 722], [320, 734], [340, 724], [360, 736], [380, 726], [400, 738], [420, 730]], false), '#3050d0', 3);
    stroke(P([[290, 752], [310, 744], [330, 756], [350, 746], [370, 758], [390, 750]], false), '#e8402c', 3);
    const panel = poly([[0, 800], [630, 800], [640, 950], [0, 952]]);
    fill(panel, INK);
    const box = (x, y, w, h, c = '#9a9ea6') => { const b = rrect(x, y, w, h, 6); fill(b, c); stroke(b, INK, 3); return b; };
    box(0, 806, 100, 140); box(110, 810, 56, 126);
    for (const [x, y] of [[18, 824], [52, 824]]) { stroke(circleP(x, y, 10), '#f06030', 4); }
    fill(circleP(56, 874, 34), '#d8dade'); stroke(circleP(56, 874, 34), INK, 3); stroke(P([[56, 874], [30, 852]], false), INK, 4);
    fill(circleP(138, 842, 10), '#4db3d8'); fill(circleP(138, 900, 12), '#f06030');
    const vent = box(172, 806, 64, 136, '#4a4e56'); clipped(vent, () => { for (let y = 810; y < 942; y += 9) stroke(P([[176, y], [232, y]], false), '#a8acb3', 3); });
    const win = (x, y, w, h, seed) => {
      const b = box(x, y, w, h, '#0a121c'); const wr = rng(seed);
      clipped(rrect(x + 6, y + 6, w - 12, h - 12, 4), () => {
        fill(rrect(x, y, w, h, 0), '#0a121c');
        for (let i = 0; i < 9; i++) fill(poly([[x + 8 + i * (w / 9), y + 10], [x + 20 + i * (w / 9), y + 10], [x + 26 + i * (w / 9), y + 40], [x + 14 + i * (w / 9), y + 40]]), '#4ab0e0');
        for (let i = 0; i < 26; i++) { const px = x + 12 + wr() * (w - 24), py = y + 50 + wr() * (h - 60); if (wr() < 0.6) fill(circleP(px, py, 3 + wr() * 5), '#f05028'); else stroke(P([[px, py], [px + 10, py - 6], [px + 18, py + 2]], false), wr() < 0.5 ? '#f05028' : '#3a90e0', 3); }
      });
    };
    win(244, 812, 166, 134, 5);
    win(438, 828, 184, 116, 6);

    // ── bottom horizontal stripes ──
    const bot = poly([[0, 950], [1024, 940], [1024, 1024], [0, 1024]]);
    clipped(bot, () => { fill(bot, '#8e929a'); for (let y = 944; y < 1030; y += 12) fill(poly([[0, y], [1024, y - 4], [1024, y + 3], [0, y + 7]]), '#262c34'); });
    // lower right: horizontal stripes under the wing
    const br2 = poly([[640, 880], [1024, 940], [1024, 950], [640, 952]]);
    hatch(br2, 0, 12, 0.5, '#2a3038', '#a8acb3');

    // ── top rainbow strip ──
    const strip = poly([[0, 0], [390, 0], [386, 28], [0, 28]]);
    clipped(strip, () => {
      const g = o.createLinearGradient(0, 0, 390, 0);
      [['#58bb5e', 0], ['#f1ed3f', 0.1], ['#fba034', 0.22], ['#f25a37', 0.34], ['#de285a', 0.48], ['#c60e81', 0.58], ['#873e9e', 0.7], ['#3a5ad0', 0.84], ['#2285d0', 1]].forEach(([c, t]) => g.addColorStop(t, c));
      fill(strip, g);
      for (let i = 0; i < 20; i++) stroke(P([[i * 20, 0], [i * 20, 28]], false), 'rgba(0,0,0,0.06)', 1);
    });

    E.draw(E.blur(E.snapshot(), 0.6), 0.5);
    E.grain(0.025, 31);
  }
});
