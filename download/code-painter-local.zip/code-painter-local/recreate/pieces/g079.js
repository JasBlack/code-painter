'use strict';
// g079 — "Orange coral totem": a clay collage on periwinkle — an orange coral with two pale-blue eyes, a white card
// with a ghost face, a grey striped wave, a cork scrap with a gold lizard and speckled grey blobs full of zebra spirals.
REC.register('g079', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const shadowOf = (paths, blur = 12, alpha = 0.55, dx = -10, dy = 14) => soft(x => { x.fillStyle = '#3a3878'; x.translate(dx, dy); for (const p of paths) x.fill(p); }, blur, alpha);

    // ── textures ──
    const spiralTex = pat(E.fx(`
      float sp(vec2 p, vec2 c, float per, float k){ vec2 d = p - c; float r = length(d), an = atan(d.y, d.x);
        float s = (r + 1.2 * sin(an * 5. + r * 0.08) + 4. * (vnoise(p * 0.06) - .5)) / per - k * an / 6.2832; return fract(s); }
      vec3 fx(vec2 uv, vec2 p){
        float f = 0.;
        vec2 c1 = vec2(105., 570.), c2 = vec2(186., 757.), c3 = vec2(505., 735.), c4 = vec2(478., 830.), c5 = vec2(385., 510.);
        if (length(p - c1) < 60.) f = sp(p, c1, 9.5, 1.);
        else if (length(p - c2) < 60.) f = sp(p, c2, 9.5, 1.);
        else if (length(p - c4) < 42.) f = sp(p, c4, 8.5, 1.);
        else if (length(p - c5) < 45.) f = sp(p, c5, 9., 1.);
        else f = sp(p, c3, 12., 1.);
        float w = smoothstep(0.42, 0.5, f) * smoothstep(0.98, 0.9, f);
        return mix(vec3(.03,.03,.035), vec3(.97,.97,.96), w); }`));
    const speck = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.72,.71,.70) * (0.97 + 0.05 * vnoise(p * 0.05));
      vec2 g = floor(p / 9.); vec2 f = fract(p / 9.) - .5; float h = hash(g), r = 0.08 + 0.3 * hash(g + 3.);
      c = mix(c, vec3(.05), step(0.82, h) * smoothstep(r + 0.04, r, length(f + (vec2(hash(g + 5.), hash(g + 7.)) - .5) * 0.4)));
      return c; }`));
    const cork = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.62,.57,.49) * (0.88 + 0.22 * vnoise(p * 0.6)) ;
      c = mix(c, vec3(.32,.26,.18), step(0.93, hash(floor(p / 1.6))) * 0.8);
      c = mix(c, vec3(.86,.80,.70), step(0.95, hash(floor(p / 1.6) + 4.)) * 0.7);
      return c; }`));
    const silver = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.06); float m = smoothstep(0.48, 0.51, n) * (1. - smoothstep(0.55, 0.58, n));
      float n2 = fbm(p * 0.09 + 7.); m = max(m, smoothstep(0.55, 0.58, n2) * (1. - smoothstep(0.62, 0.65, n2)));
      vec3 c = mix(vec3(.46,.46,.46), vec3(.76,.76,.75), m);
      c *= 0.92 + 0.12 * hash(floor(p * 1.5));
      return c; }`));
    const wave = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(520., 205.);
      float s = dot(q, vec2(0.62, 0.78)) + 10. * sin(dot(q, vec2(-0.78, 0.62)) * 0.02) ;
      float f = fract(s / 13.);
      vec3 c = mix(vec3(.75,.72,.69), vec3(.56,.53,.50), smoothstep(0.55, 0.65, f) * smoothstep(0.95, 0.85, f));
      c = mix(c, vec3(.25), step(0.985, hash(floor(p / 3.))) * 0.6);
      return c; }`));

    // ── periwinkle ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 726, 1024, [[0, '#7477be'], [0.5, '#7376bf'], [1, '#6f73bc']]), 0, 0);

    // ── white card with ghost face + black pixels ──
    const CARD = P([[360, 300], [400, 220], [470, 198], [575, 190], [598, 194], [612, 214], [616, 240], [616, 290], [698, 290], [698, 782], [360, 782]], true, false);
    shadowOf([CARD], 14, 0.5, -12, 12);
    R.dome(CARD, '#eceae8', 0.04, 0.03, 6, 1);
    soft(x => { x.fillStyle = 'rgba(120,118,118,0.85)'; x.fill(ellipseP(528, 277, 28, 18, 0)); x.fill(circleP(545, 322, 17));
      x.strokeStyle = 'rgba(120,118,118,0.8)'; x.lineWidth = 11; x.stroke(P([[425, 410], [455, 378], [490, 372], [520, 352]], false)); x.stroke(P([[455, 378], [452, 350]], false)); x.lineWidth = 8; x.stroke(P([[490, 372], [505, 395]], false)); }, 6, 1);
    for (const [x0, y0, x1, y1] of [[590, 308, 625, 355], [618, 285, 697, 392], [618, 390, 656, 430]]) R.flat(rrect(x0, y0, x1 - x0, y1 - y0, 0), '#060606', 0.05, 0);
    F(rrect(624, 300, 70, 86, 0), lin(0, 300, 0, 386, [[0, '#101010'], [1, '#2a2a2a']]));
    R.pipe(P([[630, 340], [645, 318], [668, 322], [680, 340], [664, 356], [640, 352], [636, 332], [656, 330], [672, 348]], false), 7, '#b89062', 0.08, 0.05, 3);
    F(ellipseP(632, 372, 7, 3, -0.4), '#3a9a5a');
    keep();

    // ── grey striped wave ──
    const WAVE = P([[245, 302], [292, 262], [335, 222], [382, 180], [425, 150], [445, 150], [468, 168], [494, 194], [524, 206], [470, 214], [430, 242], [396, 282], [364, 330], [340, 385], [330, 400]]);
    shadowOf([WAVE], 10, 0.35, -8, 10);
    R.dome(WAVE, wave, 0.06, 0.05, 12, 3);
    // lilac dome behind the eyes
    const DOME = P([[232, 440], [236, 380], [262, 334], [300, 320], [340, 334], [368, 370], [378, 420], [378, 448]]);
    R.dome(DOME, '#6c70ba', 0.05, 0.04, 20, 3);
    keep();

    // ── grey antler ──
    const ANT = [[[188, 305], [175, 260], [160, 228], [148, 204]], [[175, 262], [192, 230], [198, 200]], [[180, 285], [140, 278], [108, 272]], [[166, 240], [138, 232]]];
    shadowOf(ANT.map(p => P(p, false)), 8, 0.0);
    soft(x => { x.strokeStyle = '#3a3878'; x.lineWidth = 22; for (const p of ANT) x.stroke(P(p.map(([u, v]) => [u - 8, v + 10]), false)); }, 8, 0.45);
    R.h.save(); R.h.globalCompositeOperation = 'lighten';
    for (const p of ANT) { R.dome(P(lock(p, 22, 14, 1)), '#7c807a', 0.06, 0.05, 6, 3); const e = p[p.length - 1]; R.dome(P(star(e[0], e[1], 9, 4, 3, -1.57)), '#7c807a', 0.06, 0.05, 4, 3); }
    R.h.restore();
    { const q = rng(3); for (let i = 0; i < 18; i++) F(circleP(130 + q() * 70, 210 + q() * 90, 0.8 + q() * 1.2), '#30302e'); }

    // ── silver coral block with the black hollow ──
    const BLK = rrect(245, 425, 196, 190, 16);
    shadowOf([BLK], 10, 0.45);
    R.dome(BLK, silver, 0.08, 0.05, 8, 4);
    R.flat(P([[262, 560], [292, 546], [330, 560], [362, 598], [400, 590], [425, 575], [440, 600], [440, 635], [262, 635]]), '#050505', 0.08, 0);
    R.dome(circleP(385, 510, 40), '#f4f4f2', 0.1, 0.04, 6, 2);
    R.flat(circleP(385, 510, 35), spiralTex, 0.13, 2);
    R.dome(ellipseP(415, 530, 14, 17, 0.3), '#0a0a0a', 0.12, 0.06, 8, 4);
    R.dome(P(blob(382, 598, 13, 10, 4, 10, 0.3)), '#c88070', 0.1, 0.04, 5, 3);
    keep();

    // ── light-blue shelf, olive slab, bottom speckled blob ──
    const SHELF = P([[45, 668], [62, 650], [100, 640], [70, 600], [80, 560], [130, 560], [140, 600], [130, 634], [560, 632], [562, 664], [540, 670], [150, 674], [112, 690], [104, 722], [88, 714], [72, 686]]);
    shadowOf([SHELF], 10, 0.5);
    const OLIVE = P([[110, 690], [640, 690], [645, 850], [560, 850], [110, 850]], true, false);
    R.flat(OLIVE, '#45473a', 0.03, 0);
    R.dome(SHELF, '#a2b4b6', 0.06, 0.06, 10, 3);
    R.groove(P([[175, 655], [240, 652], [300, 656]], false), 6, '#8aa0c0', 0.12, 0.03, 3);
    R.groove(P([[430, 655], [500, 650], [545, 652]], false), 6, '#8aa0c0', 0.12, 0.03, 3);
    const BLOB = P([[150, 800], [158, 740], [190, 706], [250, 704], [300, 722], [330, 760], [348, 800], [390, 790], [430, 760], [455, 712], [470, 690], [530, 668], [584, 684], [612, 704], [650, 708], [672, 740], [660, 778], [622, 798], [596, 832], [612, 860], [584, 880], [520, 874], [470, 884], [420, 890], [380, 884], [330, 892], [270, 900], [200, 893], [160, 864]]);
    shadowOf([BLOB], 14, 0.5, -10, 16);
    R.dome(BLOB, speck, 0.06, 0.12, 30, 3);
    // spirals
    const spiral = (x, y, r, rim = 5) => { R.dome(P(blob(x, y, r, r, Math.round(x + y), 18, 0.03)), '#f6f6f4', 0.14, 0.05, 8, 2); R.flat(circleP(x, y, r - rim), spiralTex, 0.17, 2); };
    spiral(105, 570, 54, 6);
    spiral(186, 757, 52, 6);
    spiral(505, 735, 88, 8);
    spiral(478, 830, 38, 5);
    R.dome(circleP(408, 873, 14), '#4a4a4c', 0.12, 0.06, 6, 4);
    R.dome(ellipseP(485, 862, 22, 13, -0.1), '#f6eeb0', 0.14, 0.05, 8, 2);
    R.dome(ellipseP(418, 708, 10, 18, 0), '#f2e8a8', 0.12, 0.05, 6, 2);
    keep();

    // ── cork scrap with paper bits and a gold lizard ──
    F(P([[420, 490], [468, 480], [470, 560], [428, 560]], true, false), '#f45e0e');
    F(P([[438, 480], [478, 476], [476, 494], [440, 500]], true, false), '#2c9c6c');
    R.flat(P([[436, 540], [476, 540], [482, 632], [440, 632]], true, false), '#efe6b2', 0.08, 0);
    const CORK = P([[430, 470], [470, 456], [492, 440], [530, 428], [556, 410], [586, 416], [592, 440], [564, 470], [574, 504], [566, 540], [576, 580], [560, 612], [520, 630], [480, 628], [458, 610], [470, 570], [455, 540], [470, 505], [448, 492]]);
    shadowOf([CORK], 10, 0.5);
    R.dome(CORK, cork, 0.1, 0.06, 10, 3);
    clipA(CORK, () => { for (let i = 0; i < 6; i++) K(P([[536 + i * 8, 452], [560 + i * 8, 418]], false), i % 2 ? '#f4f4f4' : '#101010', 4); });
    const LIZ = [[[500, 430], [505, 470], [512, 500], [505, 530], [490, 556], [470, 568]], [[505, 470], [530, 460], [545, 448]], [[505, 470], [482, 462], [470, 448]], [[505, 530], [540, 530], [555, 520]], [[495, 548], [470, 545], [458, 532]]];
    for (const p of LIZ) R.pipe(P(p, false), 12, '#c8b276', 0.16, 0.05, 2);
    R.dome(ellipseP(526, 560, 11, 15, 0.1), '#f8f6f2', 0.18, 0.05, 6, 2);
    R.dome(ellipseP(502, 600, 18, 14, -0.2), '#f88c5c', 0.18, 0.05, 8, 2);
    keep();

    // ── orange coral with eyes ──
    const OR = '#f26814';
    const BR = [
      [[238, 220], [234, 280], [230, 340], [228, 400], [228, 470], [234, 540], [244, 600], [250, 640]],
      [[236, 250], [256, 232], [268, 222]], [[236, 262], [212, 250], [206, 238]], [[236, 230], [232, 214]], [[264, 228], [272, 218]],
      [[229, 420], [180, 418], [130, 414], [82, 412], [55, 416]], [[130, 414], [118, 388], [104, 360]], [[118, 388], [138, 365]], [[95, 413], [84, 440], [86, 458]],
      [[150, 416], [140, 450], [128, 468]], [[230, 350], [200, 344], [170, 334], [140, 330]], [[170, 334], [150, 312], [128, 300]], [[200, 344], [190, 322]],
      [[232, 470], [196, 468]], [[233, 500], [262, 497], [282, 492]], [[262, 497], [270, 515]], [[234, 520], [200, 524], [180, 540]], [[200, 524], [196, 548]],
      [[232, 300], [256, 292]], [[240, 590], [270, 580]]
    ];
    const BASE = P([[214, 560], [262, 560], [272, 600], [312, 622], [290, 640], [258, 652], [232, 690], [214, 660], [190, 640], [154, 630], [200, 606]], true);
    soft(x => { x.strokeStyle = '#3a3878'; x.fillStyle = '#3a3878'; x.lineWidth = 26; x.translate(-10, 12); for (const p of BR) x.stroke(P(p, false)); x.fill(BASE); }, 9, 0.5);
    // flat bevelled cut-out: union of ribbons (heights combined with 'lighten')
    R.h.save(); R.h.globalCompositeOperation = 'lighten';
    R.dome(BASE, OR, 0.1, 0.07, 7, 2);
    BR.forEach((p, i) => { const w = i === 0 ? 28 : 22; R.dome(P(i === 0 ? lock(p.slice().reverse(), 58, 26, 1.6) : lock(p, w, w * 0.9, 1)), OR, 0.1, 0.07, 7, 2);
      const e = p[p.length - 1]; R.dome(circleP(e[0], e[1], w * 0.5), OR, 0.1, 0.07, 7, 2); });
    R.h.restore();
    keep();
    // eyes
    const eye = (x, y) => {
      soft(z => { z.fillStyle = '#3a3878'; z.fill(ellipseP(x - 8, y + 12, 33, 43, 0)); }, 8, 0.45);
      R.dome(ellipseP(x, y, 33, 43, 0), lin(0, y - 43, 0, y + 43, [[0, '#a8bce0'], [0.62, '#b0c2e2'], [0.74, '#f0d8c0'], [1, '#f2d6bc']]), 0.2, 0.06, 12, 3);
      R.dome(circleP(x, y, 21), '#a89ae8', 0.24, 0.02, 4, 3);
      R.dome(circleP(x, y, 14), '#dc6a52', 0.26, 0.03, 6, 3);
      for (let k = 0; k < 16; k++) { const an = k / 16 * Math.PI * 2; K(P([[x + Math.cos(an) * 23, y + Math.sin(an) * 23], [x + Math.cos(an) * 28, y + Math.sin(an) * 28]], false), '#101018', 2.2); }
    };
    eye(178, 355); eye(266, 352);
    R.dome(P([[238, 386], [262, 384], [272, 400], [274, 440], [262, 458], [246, 450], [240, 420]]), lin(240, 380, 275, 460, [[0, '#a6bcdc'], [1, '#98b0d4']]), 0.2, 0.08, 10, 3);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.7, spec: 0.15, shin: 20, wrap: 0.6, ao: 0.3, emis: 0.36 }),                                   // 1 card
        E.mat({ dif: 0.85, spec: 0.9, shin: 60, wrap: 0.5, ao: 0.4, coat: 0.15, emis: 0.5 }),                        // 2 glossy clay
        E.mat({ dif: 0.85, spec: 0.35, shin: 25, wrap: 0.6, ao: 0.4, emis: 0.3 }),                                   // 3 matte clay
        E.mat({ dif: 0.8, spec: 0.8, shin: 50, wrap: 0.5, ao: 0.5, emis: 0.42 })                                       // 4 silver / black gloss
      ],
      light: [0.45, 0.62, 0.64], lc: [0.78, 0.78, 0.8], amb: [0.3, 0.3, 0.33],
      envTop: [1.0, 1.0, 1.05], envHor: [0.55, 0.55, 0.65], envBot: [0.25, 0.25, 0.4], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.06, 0.06, 0.1], rimD: [0, 1, 0], r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [4, 6, 0.35, 7]
    });
    E.grain(0.025, 79);
  }
});
