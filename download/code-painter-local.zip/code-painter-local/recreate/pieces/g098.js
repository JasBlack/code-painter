'use strict';
// g098 — "Ghosts in the pink gallery": blurred silver ghosts drift through a pop-art museum — a pink ceiling with a
// starry black panel, a zebra-wave ribbon and spirals, framed paintings, a black spiral wall and pink vitrines.
REC.register('g098', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const flat = (path, c) => R.flat(path, c, 0, 0);
    const poly = pts => P(pts, true, false);
    const sm = pts => P(pts, true, true);
    const blurA = (px, fn) => { a.save(); a.filter = `blur(${px * S}px)`; fn(); a.restore(); };
    const fillA = (path, c) => { a.fillStyle = c; a.fill(path); };
    const rr = rng(98);

    // ── walls & ceiling ──
    flat(rrect(-10, -10, 746, 1044, 0), '#c6c2ea');
    flat(poly([[-10, -10], [240, 210], [240, 300], [-10, 300]]), '#d3cfcc');
    flat(poly([[440, 90], [736, 80], [736, 340], [440, 340]]), '#d0cec6');
    const ceil = poly([[-10, -10], [736, -10], [736, 98], [690, 100], [600, 110], [520, 118], [500, 135], [470, 150], [448, 165], [384, 182], [304, 200], [232, 214], [-10, 4]]);
    flat(ceil, '#fc8ebb');
    // starry black ceiling panel with a pink ornate frame
    const panel = poly([[140, -10], [706, -10], [692, 16], [262, 140], [246, 124]]);
    flat(poly([[128, -10], [722, -10], [700, 26], [264, 152], [234, 128]]), '#e0609a');
    flat(panel, '#050406');
    clipA(panel, () => {
      for (let i = 0; i < 40; i++) {
        const x = 160 + rr() * 520, y = rr() * 120, c = ['#f4f060', '#f070c0', '#ffffff', '#a0a0b0', '#e0e0e8', '#ffe040'][i % 6];
        a.save(); a.translate(x, y); a.rotate(rr() * 3); a.fillStyle = c; a.fillRect(-6, -3, 6 + rr() * 10, 4 + rr() * 6); a.restore();
      }
    });
    a.strokeStyle = '#f8b0d0'; a.lineWidth = 2; a.setLineDash([3, 4]); a.stroke(P([[240, 132], [262, 146], [700, 20]], false, false)); a.setLineDash([]);

    // ── lavender mural behind the ribbon ──
    flat(sm([[-10, 250], [100, 262], [250, 270], [330, 230], [420, 170], [520, 150], [580, 200], [600, 330], [560, 470], [300, 470], [-10, 470]]), lin(0, 160, 0, 470, [[0, '#4a54b8'], [0.3, '#7a80d8'], [0.6, '#b4b0ee'], [1, '#c6bfee']]));
    blurA(12, () => fillA(sm([[330, 200], [420, 150], [540, 150], [560, 240], [480, 300], [380, 290]]), 'rgba(40,50,160,0.8)'));
    // yellow panel and blue painting
    flat(poly([[106, 306], [292, 298], [296, 398], [110, 404]]), '#fef400');
    flat(poly([[288, 290], [392, 280], [394, 380], [292, 384]]), lin(290, 280, 390, 380, [[0, '#3a68d0'], [0.5, '#5a40c0'], [1, '#e04080']]));
    for (let i = 0; i < 12; i++) { a.strokeStyle = ['#ffffff', '#f04080', '#202060'][i % 3]; a.lineWidth = 2; a.beginPath(); const x = 290 + rr() * 100, y = 285 + rr() * 90; a.moveTo(x, y); a.lineTo(x + (rr() - 0.5) * 50, y + (rr() - 0.5) * 30); a.stroke(); }
    // floor of the mural room
    flat(sm([[240, 400], [520, 390], [560, 440], [520, 470], [240, 470]]), '#b8a8e2');
    // framed paintings
    const frame = (x, y, w, h, inner, fc = '#b88a30') => {
      R.flat(rrect(x, y, w, h, 2), fc, 0.06, 1);
      R.flat(rrect(x + w * 0.08, y + h * 0.08, w * 0.84, h * 0.84, 1), inner, 0.04, 0);
    };
    frame(393, 200, 106, 90, lin(393, 200, 500, 290, [[0, '#1a3a7a'], [0.5, '#c04060'], [1, '#2a2a5a']]), '#4a3a50');
    frame(440, 278, 60, 62, lin(440, 278, 500, 340, [[0, '#3a5a8a'], [1, '#a0a0b0']]), '#6a4a3a');
    frame(390, 305, 46, 42, '#3a4a6a', '#6a4a3a');
    frame(430, 340, 46, 56, lin(430, 340, 476, 396, [[0, '#e0a040'], [1, '#a04060']]), '#8a6a2a');
    frame(395, 360, 34, 40, '#2a2a40', '#6a4a3a');
    frame(564, 364, 102, 136, lin(564, 364, 666, 500, [[0, '#2a3a5a'], [0.4, '#6a6070'], [0.7, '#2a3060'], [1, '#c0a080']]), '#c89a38');
    frame(674, 350, 60, 76, lin(674, 350, 734, 426, [[0, '#c08060'], [1, '#e0b090']]), '#c89a38');
    frame(674, 428, 60, 64, lin(674, 428, 734, 492, [[0, '#806040'], [1, '#e0c070']]), '#c89a38');
    // gallery figures in the mural
    fillA(sm([[332, 300], [352, 296], [360, 330], [372, 380], [362, 420], [340, 424], [330, 380], [320, 340]]), '#141420');
    fillA(circleP(344, 300, 12), '#e8c0a0');
    fillA(sm([[506, 280], [526, 276], [540, 300], [548, 360], [540, 420], [520, 420], [508, 360], [496, 310]]), '#d84040');
    fillA(sm([[510, 300], [530, 300], [536, 340], [514, 344]]), '#40a040');
    fillA(sm([[476, 330], [500, 320], [540, 330], [550, 360], [520, 380], [500, 410], [480, 410], [470, 370]]), '#f070b0');
    R.flat(rrect(332, 370, 30, 40, 2), '#a02020', 0.04, 0);

    // ── zebra ribbon and spiral (top right) ──
    const XS = [-20, 0, 30, 70, 110, 160, 210, 255, 300, 350, 400, 450, 500, 550, 600], YC = [262, 262, 266, 240, 219, 245, 267, 262, 246, 222, 198, 168, 140, 140, 160], HW = [56, 56, 54, 36, 24, 26, 28, 26, 22, 21, 20, 20, 20, 28, 45];
    const glArr = v => v.map(x => x.toFixed(1)).join(',');
    const ribbonP = sm([...XS.map((x, i) => [x, YC[i] - HW[i]]), [640, 120], [640, 220], ...XS.slice().reverse().map((x, i) => [x, YC[XS.length - 1 - i] + HW[XS.length - 1 - i]])]);
    const zeb = pat(E.fx(`
      float XS[15] = float[15](${glArr(XS)}); float YC[15] = float[15](${glArr(YC)}); float HW[15] = float[15](${glArr(HW)});
      vec3 fx(vec2 uv, vec2 p){
        float yc = YC[14], hw = HW[14];
        for (int i = 0; i < 14; i++) if (p.x >= XS[i] && p.x < XS[i + 1]) { float t = (p.x - XS[i]) / (XS[i + 1] - XS[i]); t = t * t * (3. - 2. * t); yc = mix(YC[i], YC[i + 1], t); hw = mix(HW[i], HW[i + 1], t); }
        float v = (p.y - yc) / hw;
        float s = cos(v * 2.5 * 3.14159);
        vec3 c = mix(vec3(.04), vec3(.96), smoothstep(-.2, .2, s));
        c = mix(c, vec3(.97), smoothstep(0.7, 0.75, abs(v)));
        // big spiral swirl
        vec2 d = p - vec2(679., 214.);
        float r = length(d) * (1. + 0.08 * sin(4. * atan(d.y, d.x) + 0.5)), an = atan(d.y, d.x);
        float sw = sin((r / 15. + an / 6.2832) * 6.2832);
        vec3 c2 = mix(vec3(.04), vec3(.96), smoothstep(-.2, .2, sw));
        float k = smoothstep(560., 600., p.x);
        return mix(c, c2, k); }`));
    flat(ribbonP, zeb);
    const swirl = sm([[560, 140], [590, 100], [650, 92], [736, 90], [736, 336], [690, 330], [630, 320], [590, 290], [570, 240], [556, 190]]);
    flat(swirl, zeb);
    R.dome(circleP(679, 214, 23), rad(670, 208, 2, 22, [[0, '#fff0f8'], [1, '#f0b0d8']]), 0.1, 0.08, 14, 2);
    blurA(4, () => { a.fillStyle = '#f8e070'; a.fill(poly([[690, 200], [736, 168], [736, 190], [694, 214]])); });

    // ── lower wall left (pale blue) and dark gallery right ──
    flat(poly([[-10, 470], [460, 470], [470, 560], [460, 800], [-10, 800]]), lin(0, 470, 0, 800, [[0, '#c8cdee'], [1, '#b3cfe6']]));
    flat(poly([[470, 505], [600, 502], [736, 500], [736, 1034], [600, 1034], [600, 912], [470, 884], [470, 760], [500, 700], [496, 600]]), '#120e12');
    clipA(sm([[452, 520], [736, 500], [736, 1034], [480, 1034]]), () => { for (let i = 0; i < 300; i++) { a.fillStyle = `rgba(255,255,255,${0.2 + rr() * 0.6})`; a.fillRect(460 + rr() * 280, 500 + rr() * 530, 1.2, 1.2); } });
    // big black-and-white spiral on the dark wall
    const big = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(686., 650.); float r = length(d), an = atan(d.y, d.x);
      float v = sin((r / 34. + an / 6.2832 * 0.5) * 6.2832); return mix(vec3(.03), vec3(.97, .96, .92), smoothstep(-.15, .15, v)); }`));
    flat(circleP(686, 650, 136), big);
    // sunset painting (left middle)
    flat(poly([[180, 560], [440, 548], [440, 700], [190, 700]]), lin(0, 556, 0, 700, [[0, '#f0d0c8'], [0.25, '#f8a088'], [0.4, '#f06050'], [0.5, '#e81818'], [0.8, '#e02020'], [1, '#f05050']]));
    blurA(3, () => fillA(circleP(268, 606, 34), '#ffffff'));
    flat(poly([[196, 556], [440, 540], [440, 560], [196, 576]]), '#f8f0f0');
    // black rail
    a.strokeStyle = '#0a0808'; a.lineWidth = 7; a.beginPath(); a.moveTo(208, 556); a.lineTo(736, 504); a.stroke();
    // wavy spirals
    const wavy = (cx, cy, rx, ry, per) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = (p - vec2(${cx}., ${cy}.)) / vec2(${rx}., ${ry}.); float r = length(d), an = atan(d.y, d.x);
      r *= 1. + 0.06 * sin(5. * an) + 0.04 * sin(9. * an + 1.);
      float v = sin((r * ${per}. + an / 6.2832) * 6.2832); return mix(vec3(.03), vec3(.98), smoothstep(-.2, .2, v)); }`));
    // framed paintings lower right
    frame(470, 532, 94, 112, lin(470, 532, 564, 644, [[0, '#d8b080'], [0.5, '#7a4a3a'], [1, '#c09060']]), '#c89a38');
    frame(505, 694, 52, 56, lin(505, 694, 557, 750, [[0, '#a04050'], [1, '#e0a070']]), '#b08a38');
    frame(482, 494, 50, 18, '#f0e040', '#202020');

    // ── ghosts (soft silver silhouettes) ──
    const ghostL = sm([[150, 300], [178, 304], [188, 336], [180, 362], [206, 380], [214, 420], [236, 450], [256, 470], [244, 482], [222, 470], [200, 450], [204, 500], [206, 560], [210, 600], [212, 660], [204, 720], [196, 790], [156, 796], [170, 740], [170, 680], [160, 630], [146, 604], [130, 640], [116, 700], [104, 780], [60, 800], [70, 740], [84, 660], [96, 580], [96, 500], [84, 470], [56, 452], [60, 438], [96, 440], [108, 400], [130, 366], [132, 330]]);
    blurA(16, () => fillA(ghostL, 'rgba(236,244,255,0.95)'));
    blurA(5, () => fillA(ghostL, '#e8eaf4'));
    blurA(16, () => {
      for (const c of [[[120, 384], [176, 384], [196, 450], [186, 540], [146, 566], [112, 500]], [[170, 600], [198, 640], [198, 720], [176, 770], [166, 700]], [[110, 600], [140, 610], [120, 700], [100, 760], [96, 680]], [[150, 318], [172, 322], [172, 352], [150, 354]]])
        fillA(sm(c), 'rgba(140,142,160,0.5)');
    });
    blurA(3, () => { a.strokeStyle = 'rgba(255,255,255,0.9)'; a.lineWidth = 5; a.stroke(P([[140, 312], [134, 340], [110, 390], [98, 450], [100, 520], [92, 600]], false, true)); });
    const ghostC = sm([[384, 404], [404, 410], [410, 450], [440, 470], [470, 480], [460, 530], [440, 560], [450, 640], [430, 720], [400, 780], [350, 780], [330, 700], [340, 620], [330, 560], [320, 500], [350, 470], [366, 440]]);
    blurA(12, () => fillA(ghostC, lin(0, 400, 0, 780, [[0, 'rgba(50,50,56,0.97)'], [0.45, 'rgba(76,76,84,0.95)'], [1, 'rgba(120,118,128,0.9)']])));
    blurA(10, () => fillA(sm([[340, 600], [380, 580], [420, 620], [410, 700], [370, 740], [340, 700]]), 'rgba(220,222,232,0.55)'));
    blurA(6, () => { fillA(circleP(392, 604, 12), '#ffffff'); });
    // white noodle across the room
    blurA(3, () => { a.strokeStyle = 'rgba(236,240,250,0.95)'; a.lineWidth = 26; a.lineCap = 'round'; a.stroke(P([[200, 500], [240, 470], [290, 420], [330, 380], [380, 360], [440, 380], [500, 410], [540, 440], [520, 470]], false, true)); });
    blurA(8, () => fillA(sm([[200, 480], [260, 470], [300, 520], [280, 560], [220, 560], [190, 530]]), 'rgba(200,220,240,0.9)'));
    blurA(10, () => fillA(sm([[420, 640], [500, 620], [560, 660], [570, 740], [540, 790], [470, 790], [430, 740]]), 'rgba(176,180,190,0.85)'));
    blurA(2, () => { a.strokeStyle = 'rgba(236,236,244,0.95)'; a.lineWidth = 16; a.stroke(P([[540, 600], [570, 580], [596, 556], [604, 536], [590, 524], [574, 534]], false, true)); });
    for (const [x, y, r] of [[336, 522, 10], [444, 586, 11]]) fillA(circleP(x, y, r), '#050405');

    for (const [x, y, rx, ry, n] of [[156, 652, 42, 50, 6], [252, 726, 40, 46, 6], [252, 482, 24, 30, 4], [292, 508, 10, 13, 2]]) {
      flat(sm(blob(x, y, rx, ry, x, 16, 0.06)), wavy(x, y, rx, ry, n));
    }
    // ── left figure (dark navy woman) ──
    R.dome(sm([[-10, 470], [22, 462], [42, 486], [40, 520], [56, 548], [78, 576], [92, 606], [80, 614], [60, 592], [52, 640], [48, 720], [50, 800], [12, 800], [10, 720], [-10, 700]]), lin(0, 470, 60, 800, [[0, '#2a2a50'], [0.5, '#141430'], [1, '#202048']]), 0.1, 0.1, 16, 1);
    fillA(poly([[6, 540], [22, 524], [30, 548], [38, 528], [44, 560], [10, 566]]), '#f0e040');
    fillA(poly([[10, 580], [40, 580], [36, 640], [14, 640]]), '#e8e8e8');

    // ── mannequin (right) ──
    const man = sm([[640, 590], [664, 594], [672, 630], [660, 664], [680, 700], [690, 760], [676, 820], [690, 880], [684, 960], [676, 1034], [610, 1034], [612, 960], [604, 880], [616, 820], [604, 760], [614, 700], [630, 664], [620, 630]]);
    R.dome(man, lin(600, 0, 700, 0, [[0, '#2a2a30'], [0.5, '#5a5a62'], [1, '#2a2a32']]), 0.1, 0.25, 30, 2);
    // small figures
    R.dome(sm([[444, 712], [462, 706], [476, 730], [474, 800], [466, 830], [450, 830], [444, 790], [436, 740]]), '#1a1a2a', 0.1, 0.06, 6, 2);
    R.dome(circleP(442, 660, 18), '#4a4a50', 0.1, 0.06, 8, 2);
    a.strokeStyle = '#e0c060'; a.lineWidth = 3; a.beginPath(); a.moveTo(500, 680); a.lineTo(590, 600); a.stroke();

    // ── pink vitrines ──
    // tall pedestal
    R.flat(poly([[400, 712], [470, 724], [470, 900], [400, 900]]), lin(400, 0, 470, 0, [[0, '#f478b0'], [1, '#fc90c0']]), 0.2, 1);
    R.flat(poly([[360, 760], [400, 712], [400, 900], [360, 900]]), '#e8609c', 0.2, 1);
    // left display case: rim, glass, front band; lower case with dark relic box
    R.flat(poly([[-10, 800], [330, 780], [440, 830], [440, 880], [600, 912], [596, 1034], [-10, 1034]]), '#f8a4cc', 0.2, 1);
    const glass = poly([[10, 822], [330, 806], [364, 850], [-10, 935]]);
    R.flat(glass, lin(0, 800, 0, 940, [[0, '#9a9c98'], [1, '#b0b0aa']]), 0.22, 1);
    clipA(glass, () => {
      for (let i = 0; i < 26; i++) { const x = 10 + rr() * 330, y = 826 + rr() * 90; a.fillStyle = ['#2a2420', '#5a3a2a', '#a07050', '#1a1a1a'][i % 4]; a.fill(ellipseP(x, y, 10 + rr() * 16, 5 + rr() * 6, rr())); }
    });
    R.flat(poly([[-10, 948], [433, 836], [433, 878], [-10, 992]]), lin(0, 836, 0, 992, [[0, '#fcb4d6'], [1, '#f070b0']]), 0.24, 1);
    R.flat(poly([[90, 1010], [240, 926], [436, 882], [420, 1004]]), '#3a2418', 0.24, 1);
    R.flat(poly([[118, 1000], [250, 934], [424, 896], [410, 994]]), lin(0, 900, 0, 1000, [[0, '#4a4a4c'], [1, '#2a2a2c']]), 0.25, 1);
    R.dome(sm([[250, 930], [320, 912], [360, 944], [330, 984], [270, 986]]), '#1a1a20', 0.26, 0.05, 8, 1);
    R.dome(sm([[330, 912], [380, 904], [400, 920], [360, 930]]), '#a06040', 0.26, 0.04, 6, 1);
    R.flat(poly([[440, 924], [500, 912], [526, 932], [470, 946]]), '#f8e8c0', 0.26, 1);
    R.flat(poly([[384, 970], [460, 954], [476, 986], [400, 1000]]), '#202028', 0.26, 1);
    R.flat(poly([[330, 1012], [430, 998], [440, 1034], [330, 1034]]), '#f4f4f0', 0.26, 1);
    R.flat(poly([[440, 880], [600, 912], [596, 1034], [450, 1034]]), lin(0, 880, 0, 1034, [[0, '#fdd8ea'], [1, '#f8b8d8']]), 0.22, 1);
    // right pink side table edge
    R.flat(poly([[694, 880], [736, 872], [736, 904], [694, 900]]), '#fcb0d0', 0.2, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 20, wrap: 0.5, ao: 0.3, emis: 0.05 }),          // 1 painted / plastic
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, ao: 0.4, coat: 0.12 })            // 2 glossy
      ],
      light: [-0.5, 0.6, 0.65], lc: [0.6, 0.6, 0.62], amb: [0.55, 0.55, 0.56],
      envTop: [1, 1, 1], envHor: [0.6, 0.6, 0.66], envBot: [0.2, 0.2, 0.25], envK: [0.15, 0.8, 0.3, 0],
      r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.4, 7]
    });
    E.grain(0.04, 98);
  }
});
