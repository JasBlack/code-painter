'use strict';
// g097 — "Chrome puddle on coral": a glossy iridescent blue-violet puddle rimmed in black, held between a hot-pink
// slick and a coral blob dotted with teal studs, chrome beads and zebra spirals, under a black-and-white ring field.
REC.register('g097', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const flat = (path, c) => R.flat(path, c, 0, 0);
    const sm = pts => P(pts, true, true);
    const blurA = (px, fn) => { a.save(); a.filter = `blur(${px * S}px)`; fn(); a.restore(); };

    // ring / spiral fields (centre, period, spiral amount, wobble)
    const rings = (cx, cy, per, spi, wob, sx = 1, sy = 1, soft = 0.25) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)})) * vec2(${sx.toFixed(3)}, ${sy.toFixed(3)});
      float an = atan(d.y, d.x), r = length(d);
      r *= 1. + ${wob.toFixed(3)} * sin(4. * an + r * 0.01) + ${(wob * 0.6).toFixed(3)} * sin(7. * an - r * 0.02);
      r += ${(wob * 60).toFixed(2)} * (fbm(p * 0.012) - 0.5);
      float ph = r / ${per.toFixed(2)} + ${spi.toFixed(2)} * an / 6.2832;
      float v = sin(ph * 6.2832);
      float w = smoothstep(-${soft.toFixed(2)}, ${soft.toFixed(2)}, v);
      return mix(vec3(.035, .03, .035), vec3(.95, .95, .93), w); }`));

    // eccentric ring field: ring n has radius p*n + q*n^2 around centre c + n*D (fitted to the reference)
    const ecc = (cx, cy, p, q, dx, dy, off, sy = 1, soft = 0.3) => pat(E.fx(`vec3 fx(vec2 uv, vec2 px){
      vec2 d = (px - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)})) * vec2(1., ${sy.toFixed(3)});
      float an = atan(d.y, d.x);
      d *= 1. + 0.035 * sin(4. * an + length(d) * 0.012) + 0.02 * sin(7. * an);
      float f = length(d) / ${p.toFixed(3)};
      for (int i = 0; i < 24; i++) f = length(d - vec2(${dx.toFixed(3)}, ${dy.toFixed(3)}) * f) / (${p.toFixed(3)} + ${q.toFixed(3)} * f);
      f += 0.25 * (fbm(px * 0.02) - 0.5);
      float v = sin((f + ${off.toFixed(3)}) * 6.2832);
      return mix(vec3(.035, .03, .035), vec3(.95, .95, .93), smoothstep(-${soft.toFixed(2)}, ${soft.toFixed(2)}, v)); }`));

    // ── background: blue-grey textured slab, white left edge ──
    flat(rrect(-10, -10, 746, 1044, 0), lin(0, 300, 0, 1024, [[0, '#c4c2c6'], [0.45, '#a6a2ae'], [0.7, '#8a98b4'], [1, '#5a72a4']]));
    flat(rrect(380, 900, 360, 130, 0), lin(0, 900, 0, 1024, [[0, '#4a6496'], [1, '#3a5288']]));
    blurA(8, () => { a.fillStyle = 'rgba(236,236,232,0.9)'; a.fillRect(-10, 300, 26, 740); });
    const gr = rng(97);
    for (let i = 0; i < 900; i++) { a.fillStyle = gr() < 0.5 ? 'rgba(255,255,255,0.12)' : 'rgba(30,40,70,0.12)'; a.fillRect(gr() * 726, 300 + gr() * 724, 1 + gr() * 3, 1 + gr() * 2); }
    // glowing orange specks on the left
    for (const [x, y, r] of [[62, 590, 11], [98, 780, 14], [106, 912, 10], [203, 1000, 10], [40, 1000, 5]]) {
      blurA(r * 0.7, () => { a.fillStyle = 'rgba(250,150,90,0.8)'; a.fill(circleP(x, y, r * 1.6)); });
      a.fillStyle = rad(x, y, 0, r, [[0, '#fff4c0'], [0.4, '#ffb050'], [1, 'rgba(240,90,40,0.6)']]); a.fill(circleP(x, y, r));
    }
    for (const [x, y, rx, ry] of [[46, 720, 26, 14], [84, 856, 22, 12], [30, 690, 12, 8]]) R.dome(ellipseP(x, y, rx, ry, 0.3), '#d8d8e4', 0.04, 0.03, 8, 2);

    // ── black & white ring field (top right) ──
    const fieldP = sm([[280, -10], [736, -10], [712, 120], [704, 300], [690, 330], [600, 330], [520, 300], [470, 290], [430, 300], [330, 300], [300, 250], [290, 120]]);
    R.flat(fieldP, ecc(590.4, 177, 13.77, 0.502, -3.42, -0.54, 0.02, 1, 0.5), 0.02, 0);
    R.flat(sm([[704, 50], [736, 40], [736, 300], [700, 300], [706, 180]]), lin(0, 40, 0, 300, [[0, '#2a2840'], [0.3, '#4a5888'], [1, '#546992']]), 0.02, 0);
    // ochre patch
    R.flat(sm([[436, 180], [452, 196], [462, 250], [480, 284], [520, 296], [552, 330], [540, 372], [500, 380], [470, 350], [440, 320], [432, 260]]), '#b8861c', 0.03, 0);
    // red wood slab (right)
    const wood = sm([[700, 290], [736, 280], [736, 720], [650, 700], [634, 560], [640, 420], [646, 350]]);
    R.flat(wood, lin(640, 300, 736, 700, [[0, '#d8400e'], [0.5, '#c63412'], [1, '#8a1e0e']]), 0.02, 0);
    clipA(wood, () => { const wr = rng(5); for (let i = 0; i < 70; i++) { a.strokeStyle = wr() < 0.5 ? 'rgba(120,20,5,0.5)' : 'rgba(255,120,60,0.35)'; a.lineWidth = 1 + wr() * 2; const x = 630 + wr() * 110, y = 280 + wr() * 440; a.beginPath(); a.moveTo(x, y); a.lineTo(x - 30 + wr() * 10, y + 50 + wr() * 30); a.stroke(); } });
    // black pool (right, behind the ring disc)
    flat(sm([[640, 590], [736, 580], [736, 1000], [700, 990], [660, 900], [620, 760]]), '#060405');

    // ── top-left: orange melt over the pink slick ──
    flat(sm([[-10, -10], [300, -10], [300, 60], [200, 72], [100, 80], [-10, 70]]), lin(0, 0, 300, 0, [[0, '#f66c48'], [0.5, '#f46e5c'], [1, '#f47284']]));
    const pink = sm([[-10, 60], [100, 72], [200, 64], [300, 50], [320, 120], [300, 250], [290, 300], [200, 360], [140, 420], [120, 520], [118, 620], [150, 700], [120, 720], [100, 640], [80, 520], [60, 420], [20, 360], [-10, 330]]);
    R.dome(pink, lin(0, 0, 300, 700, [[0, '#f46ab8'], [0.5, '#f470c4'], [1, '#f068c0']]), 0.06, 0.06, 30, 1);
    // pink drips onto the ring field
    for (const p of [[[280, -10], [330, -10], [336, 60], [322, 120], [306, 150], [292, 100]], [[414, 66], [436, 54], [462, 56], [484, 70], [474, 96], [466, 150], [472, 228], [462, 258], [452, 230], [446, 150], [436, 104], [418, 90]], [[556, -10], [700, -10], [708, 40], [700, 88], [680, 100], [662, 80], [640, 42], [600, 26], [566, 16]]])
      R.dome(sm(p), '#f470c4', 0.08, 0.08, 14, 1);
    R.dome(ellipseP(450, 74, 22, 16, 0), '#f6a8d0', 0.14, 0.04, 10, 1);
    // dark slot + holes in the pink
    R.groove(P([[208, 34], [206, 110]], false, false), 26, '#070508', 0.06, 0.05, 1, 1);
    a.fillStyle = '#b07018'; a.fill(ellipseP(207, 52, 8, 16, 0));
    for (const [x, y, r] of [[137, 237, 12], [190, 268, 8], [148, 335, 8], [215, 197, 9], [265, 150, 9], [108, 315, 5], [80, 150, 4], [110, 210, 4], [240, 330, 5], [260, 200, 4]]) R.dome(circleP(x, y, r), '#0a0608', 0.0, 0.02, 3, 1);
    // small spiral in the pink
    R.dome(circleP(82, 322, 25), '#121012', 0.1, 0.04, 6, 3);
    R.dome(circleP(82, 322, 21), rings(82, 322, 5.5, 1, 0.02), 0.12, 0.04, 8, 3);

    // bottom-right ring disc on the black pool
    flat(ellipseP(556, 866, 134, 136, 0), '#08070a');
    R.dome(ellipseP(574, 848, 130, 136, 0), ecc(570, 846, 19, 0.15, 0.8, 3.2, 0.0, 0.93), 0.08, 0.06, 20, 3);
    R.dome(ellipseP(570, 846, 46, 56, -0.35), '#f064c4', 0.16, 0.08, 20, 1);
    // ── coral blob ──
    const coral = sm([[480, 340], [520, 304], [600, 316], [636, 344], [646, 410], [628, 460], [660, 502], [694, 522], [694, 560], [662, 590], [644, 640], [640, 712], [600, 726], [540, 722], [500, 742], [482, 800], [472, 862], [452, 904], [400, 935], [300, 952], [200, 956], [140, 930], [118, 860], [122, 770], [150, 730], [230, 722], [320, 716], [380, 684], [420, 620], [440, 560], [490, 470], [500, 390]]);
    R.dome(coral, '#f46a62', 0.06, 0.1, 40, 1);
    // spirals on the coral
    for (const [x, y, r, per] of [[222, 832, 76, 9.5], [577, 385, 40, 7]]) {
      R.dome(circleP(x, y, r + 4), '#2a1416', 0.1, 0.04, 6, 3);
      R.dome(circleP(x, y, r), rings(x, y, per, 1, 0.03), 0.12, 0.04, 10, 3);
    }
    // studs: coral bumps with teal wells
    for (const [x, y, r] of [[545, 488, 46], [520, 660, 42], [395, 785, 42]]) {
      R.dome(circleP(x, y, r), '#f2625c', 0.12, 0.12, r * 0.7, 1);
      R.dome(circleP(x, y, r * 0.36), '#c43a3c', 0.2, 0.02, 4, 1);
      R.dome(circleP(x, y, r * 0.27), rad(x - 3, y - 3, 1, r * 0.27, [[0, '#7af0f0'], [0.6, '#10c0c4'], [1, '#08808a']]), 0.18, 0.02, 4, 4);
    }
    R.dome(circleP(500, 572, 30), '#f2625c', 0.1, 0.1, 20, 1);
    // pink pills
    R.dome(rrect(568, 596, 64, 126, 32), '#f462be', 0.14, 0.14, 26, 1);
    R.dome(ellipseP(660, 532, 32, 28, 0), '#f466be', 0.14, 0.12, 20, 1);
    R.dome(rrect(364, 906, 92, 140, 46), '#f25cbe', 0.12, 0.14, 34, 1);
    // black holes
    for (const [x, y, r] of [[368, 640, 22], [470, 740, 19], [396, 670, 8], [410, 690, 5]]) R.dome(circleP(x, y, r), '#030203', 0.06, 0.0, 2, 0);
    // engraved scribbles
    a.strokeStyle = '#a8343a'; a.lineWidth = 1.5;
    for (const [x, y] of [[590, 545], [470, 630], [300, 760]]) { const sr = rng(x); a.beginPath(); a.moveTo(x, y); for (let i = 0; i < 8; i++) a.lineTo(x + (sr() - 0.5) * 40, y + (sr() - 0.5) * 30); a.stroke(); }

    // ── chrome puddle ──
    const pud = sm([[165, 385], [210, 352], [262, 318], [300, 300], [380, 296], [440, 304], [480, 330], [500, 380], [500, 450], [480, 500], [450, 540], [430, 580], [418, 620], [396, 642], [376, 670], [352, 700], [320, 714], [270, 712], [230, 722], [188, 718], [158, 698], [134, 650], [124, 580], [124, 500], [136, 440]]);
    R.dome(pud, '#080608', 0.06, 0.08, 10, 3);
    a.strokeStyle = '#e8eef4'; a.lineWidth = 2.5; a.stroke(pud);
    const inner = sm([[172, 398], [214, 366], [264, 332], [302, 314], [380, 310], [436, 318], [470, 340], [488, 384], [488, 448], [470, 494], [440, 532], [418, 574], [406, 612], [384, 634], [364, 662], [344, 690], [318, 702], [270, 700], [230, 708], [192, 704], [168, 688], [146, 646], [138, 580], [138, 500], [150, 446]]);
    const liq = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.008 + vec2(3.1, 7.7));
      vec3 c = mix(vec3(.31, .41, .80), vec3(.36, .33, .84), smoothstep(.35, .65, n));
      c = mix(c, vec3(.30, .32, .58), smoothstep(390., 470., p.x) * (1. - smoothstep(520., 600., p.y)) * 0.8);
      c = mix(c, vec3(.40, .31, .82), smoothstep(540., 620., p.y) * 0.8);
      c = mix(c, vec3(.34, .33, .52), smoothstep(640., 700., p.y) * 0.6);
      return c; }`));
    R.dome(sm([[170, 392], [212, 360], [263, 326], [300, 307], [380, 303], [438, 311], [474, 335], [494, 382], [494, 449], [475, 497], [445, 536], [424, 577], [412, 616], [390, 638], [370, 666], [348, 695], [319, 708], [270, 706], [230, 715], [190, 711], [163, 693], [140, 648], [131, 580], [131, 500], [143, 443]]), '#a0a6be', 0.08, 0.06, 6, 5);
    R.dome(inner, liq, 0.1, 0.1, 40, 4);
    // highlights: pale Y, left sheen, cyan glows
    const yP = sm([[268, 345], [300, 322], [350, 318], [395, 330], [402, 360], [390, 390], [368, 398], [346, 396], [340, 420], [362, 438], [396, 430], [410, 452], [400, 472], [370, 478], [342, 470], [320, 482], [306, 512], [296, 540], [284, 544], [278, 518], [286, 470], [294, 430], [288, 400], [272, 380]]);
    const lP = sm([[150, 440], [180, 420], [214, 424], [232, 460], [222, 500], [232, 530], [214, 560], [186, 566], [160, 542], [146, 490]]);
    clipA(inner, () => {
      blurA(9, () => { a.lineWidth = 16; a.strokeStyle = 'rgba(40,200,250,0.9)'; a.stroke(yP); a.stroke(lP); a.fillStyle = 'rgba(40,200,250,0.8)'; a.fill(sm([[196, 548], [260, 548], [300, 566], [270, 584], [210, 580]])); });
      blurA(2, () => { a.fillStyle = '#dcf6f6'; a.fill(yP); a.fillStyle = '#f4fefe'; a.fill(lP); });
    });
    // mint splash
    R.flat(sm([[150, 628], [176, 622], [200, 640], [222, 650], [232, 680], [236, 706], [212, 700], [194, 690], [176, 704], [166, 680], [156, 656]]), '#8ccdcb', 0.2, 1);

    // ── chrome beads ──
    for (const [x, y, r] of [[455, 298, 14], [442, 378, 10], [512, 590, 18], [440, 727, 22], [322, 298, 9], [247, 367, 8], [158, 461, 9], [292, 619, 4]])
      R.bead(x, y, r, rad(x - r * 0.35, y - r * 0.4, 0, r * 1.3, [[0, '#ffffff'], [0.25, '#e0e8f4'], [0.6, '#8898c0'], [0.85, '#4a5a88'], [1, '#2a3450']]), 0.2, Math.min(0.2, r * 0.012 + 0.05), 5);
    a.strokeStyle = '#dde6f0'; a.lineWidth = 3;
    a.stroke(P([[455, 312], [456, 340], [446, 368]], false, true));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.45, ao: 0.4, coat: 0.12 }),           // 1 glossy plastic
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.3 }),                        // 2 matte specks
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.05 }),            // 3 printed spirals
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.4, ao: 0.3, coat: 0.25, iri: 0.15 }),  // 4 liquid puddle
        E.mat({ dif: 1, spec: 1.3, shin: 90, wrap: 0.5, ao: 0.1, coat: 0.3, emis: 0.2 })   // 5 chrome beads / rim
      ],
      light: [-0.5, 0.6, 0.65], lc: [0.7, 0.7, 0.72], amb: [0.5, 0.5, 0.52],
      envTop: [1, 1, 1], envHor: [0.6, 0.62, 0.7], envBot: [0.15, 0.15, 0.22], envK: [0.2, 1.0, 0.3, 0],
      r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.5, 7]
    });
    E.grain(0.04, 97);
  }
});
