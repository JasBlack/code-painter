'use strict';
// g028 — "Glossy pill cosmos": a glossy black relief body edged in rainbow, set with coral sand panels, cream
// pills, zebra spirals, a white stone ball, a bubbly grey column, a slate-teal blob and a dotted porthole.
REC.register('g028', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, op = 'source-over', al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalCompositeOperation = op; a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const dots = (path, n, seed, col, r0, r1) => clipA(path, () => { const r = rng(seed); a.fillStyle = col; for (let i = 0; i < n; i++) { a.beginPath(); a.arc(r() * 726, r() * 1024, r0 + r() * (r1 - r0), 0, 6.283); a.fill(); } });
    const BLK = '#25232a', SAL = '#f27c6a', CRM = '#f6eaa6', WH = '#f4f4f2';

    // ── textures ──
    const zebL = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(250., 440.);
      float r = length(d) + 5. * sin(atan(d.y, d.x) * 7.) + 6. * (fbm(p * 0.012) - .5);
      float s = sin(6.2832 * (r / mix(10., 14., smoothstep(80., 300., r)) + uPh));
      return mix(vec3(.13, .125, .14), vec3(.96), smoothstep(0.3, 0.5, s)); }`, { uPh: 0.66 });
    const spiral = (cx, cy, per, turns) => E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)});
      float r = length(d), a = atan(d.y, d.x);
      float s = sin(6.2832 * (r / ${per.toFixed(1)} - a / 6.2832 * ${turns.toFixed(1)}));
      return mix(vec3(.08), vec3(.97), smoothstep(-0.1, 0.25, s)); }`);
    const sand = E.fx(`vec3 fx(vec2 uv, vec2 p){ return vec3(0.9 + 0.2 * hash(floor(p * 0.9))); }`);
    const stone = E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.05) * 0.6 + 0.4 * hash(floor(p * 0.7)); return vec3(0.75 + 0.3 * n); }`);
    const purp = E.fx(`vec3 fx(vec2 uv, vec2 p){ float t = clamp((p.x - 180.) / 170. + (p.y - 640.) / 400., 0., 1.);
      return mix(vec3(.95, .12, .95), vec3(.33, .25, .85), t); }`);
    const rainbow = E.fx(`vec3 fx(vec2 uv, vec2 p){ float t = clamp((p.x - 60.) / 140. + 0.25 * sin(p.y * 0.05), 0., 1.);
      vec3 c = mix(vec3(1., .92, .1), vec3(.2, .92, .3), smoothstep(0., .35, t));
      c = mix(c, vec3(.1, .85, .95), smoothstep(.35, .65, t)); c = mix(c, vec3(.25, .3, .95), smoothstep(.65, .95, t));
      return c; }`);

    // ── space background ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#050505', 0, 0);
    for (const [x, y, r] of [[66, 46, 6], [42, 36, 3], [22, 208, 9], [14, 296, 8], [30, 120, 2], [60, 170, 2], [40, 250, 2]]) R.flat(circleP(x, y, r), '#f4f4f4', 0, 0);
    R.paint(P([[0, 166], [20, 140], [48, 98], [36, 100], [10, 134], [0, 148]]), '#ed2a8a');

    // ── glossy black body ──
    const bodyPts = [[150, -20], [746, -20], [746, 1044], [-20, 1044], [-10, 600], [10, 520], [28, 460], [54, 400], [80, 340], [100, 280], [104, 200], [104, 120], [116, 60], [134, 10]];
    const body = P(bodyPts, true, true);
    // rainbow rim (painted on the background just outside the body edge)
    const rim = P([[112, 210], [108, 260], [92, 310], [66, 370], [40, 430], [20, 490], [4, 550], [-8, 620]], false, true);
    for (const [w, c] of [[50, '#ff1e2c'], [40, '#ff8a2a'], [30, '#ffe21a']]) { a.lineWidth = w; a.strokeStyle = c; a.lineCap = 'round'; a.stroke(rim); }
    R.dome(body, BLK, 0.04, 0.22, 90, 1);
    // painted left rim highlights (yellow / cyan reflections)
    soft(x => { x.lineWidth = 6; x.strokeStyle = '#ffe23a'; x.stroke(P([[30, 600], [18, 700], [14, 820], [16, 940]], false)); x.strokeStyle = '#3ad8f4'; x.lineWidth = 7; x.stroke(P([[6, 780], [4, 880], [8, 960]], false)); }, 2, 0.9);

    // zebra stripes down the left flank
    const zebP = P([[86, 268], [150, 262], [214, 296], [212, 336], [178, 380], [140, 420], [110, 480], [84, 560], [64, 640], [56, 760], [60, 892], [36, 892], [22, 800], [20, 650], [30, 530], [50, 430], [70, 340]]);
    R.flat(zebP, '#222026', 0.2, 5);
    clipA(zebP, () => img(zebL));

    // ── top: grey cap, cream bead, coral patch ──
    R.dome(P([[118, 70], [130, 20], [160, -10], [270, -10], [262, 50], [240, 70], [200, 80], [150, 86]]), '#6e6f74', 0.2, 0.08, 14, 4);
    R.dome(P([[160, 60], [200, 70], [250, 64], [262, 110], [250, 150], [200, 140], [170, 110]]), '#e88078', 0.2, 0.06, 8, 2);
    R.bead(150, 28, 24, CRM, 0.28, 0.1, 3);
    // white stone ball
    R.dome(circleP(165, 192, 80), '#e6e5e0', 0.2, 0.32, 80, 4);
    // bubbly grey column
    const col = P([[244, -10], [440, -10], [446, 120], [440, 240], [400, 262], [330, 290], [262, 318], [208, 302], [212, 250], [240, 190], [246, 100]]);
    R.dome(col, '#4a4a50', 0.22, 0.04, 8, 4);
    { const r = rng(28); for (let i = 0; i < 420; i++) { const x = 216 + r() * 226, y = -5 + r() * 320; if (a.isPointInPath(col, x * S, y * S)) R.bead(x, y, 4 + r() * 8, r() < 0.5 ? '#76767c' : '#86868c', 0.24 + r() * 0.04, 0.06, 4); } }
    // grey stone slab (right) with a zebra spiral recess
    const slab = P([[480, -10], [746, -10], [746, 400], [720, 450], [640, 500], [604, 504], [600, 440], [640, 380], [660, 330], [600, 284], [540, 262], [470, 252], [432, 236], [430, 170], [460, 140], [470, 60]], true, false);
    R.dome(slab, '#56575e', 0.2, 0.04, 6, 4);
    clipA(slab, () => img(stone, 'multiply', 0.9));
    const rec = ellipseP(668, 112, 166, 146, 0.05);
    R.dome(rec, '#1a1a1e', 0.16, 0.03, 5, 1);
    const recIn = ellipseP(670, 114, 160, 140, 0.05);
    R.flat(recIn, null, 0.18, 5);
    clipA(recIn, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float r = length((p - vec2(660., 128.)) * vec2(1., 1.08));
      float s = sin(6.2832 * (25. * log(1. + 0.01 * r) + uPh));
      return mix(vec3(.1), vec3(.95), smoothstep(-0.05, 0.3, s)); }`, { uPh: 0.75 })));

    // ── middle coral panel with pills, dots and a zebra spiral ──
    const sal1 = P([[214, 380], [250, 334], [320, 312], [400, 292], [470, 284], [560, 286], [632, 300], [660, 330], [652, 392], [620, 424], [560, 440], [500, 466], [470, 488], [400, 500], [330, 506], [280, 516], [240, 504], [216, 462], [206, 420]]);
    R.dome(sal1, SAL, 0.24, 0.05, 10, 2);
    clipA(sal1, () => img(sand, 'multiply', 1));
    dots(sal1, 70, 12, '#fbf4f0', 1.5, 4.5);
    R.paint(P([[560, 380], [600, 368], [610, 384], [570, 400]]), '#1e1c22');
    // white wavy drip band under the coral panel
    const band1 = P([[100, 604], [140, 576], [200, 540], [240, 522], [300, 514], [360, 508], [420, 498], [470, 478], [520, 452], [570, 436], [620, 416], [630, 432], [580, 452], [530, 472], [480, 494], [430, 512], [370, 524], [310, 530], [250, 540], [200, 560], [150, 592], [110, 616]]);
    R.dome(band1, WH, 0.24, 0.05, 6, 5);
    a.lineWidth = 10; a.strokeStyle = WH; a.stroke(band1); R.pipe(band1, 10, null, 0.24, 0.04, 5);
    // black gloss ball with a white eye
    R.bead(197, 420, 40, '#1a181e', 0.26, 0.2, 1);
    R.dome(circleP(182, 420, 16), '#f6f6f6', 0.42, 0.05, 6, 5);
    // rainbow puddle
    const rb = P([[56, 504], [72, 462], [96, 420], [112, 394], [126, 414], [136, 446], [168, 452], [192, 436], [204, 462], [170, 478], [132, 482], [112, 510], [80, 532]]);
    R.dome(rb, '#ffffff', 0.22, 0.06, 10, 7);
    clipA(rb, () => img(rainbow));
    // zebra spiral disc
    R.dome(circleP(395, 455, 74), '#18161c', 0.26, 0.08, 10, 1);
    R.flat(circleP(395, 455, 62), null, 0.34, 5);
    clipA(circleP(395, 455, 62), () => img(spiral(395, 455, 13, 1)));
    // pills
    const pill = (x, y, rx, ry, rot) => R.dome(ellipseP(x, y, rx, ry, rot), CRM, 0.3, 0.12, Math.min(rx, ry) * 0.9, 3);
    pill(300, 405, 50, 32, -0.08); pill(505, 355, 48, 36, -0.35); pill(515, 553, 34, 58, 0.1); pill(60, 540, 30, 48, 0.6);
    pill(320, 865, 56, 41, -0.2); pill(90, 845, 35, 33, 0.3); pill(38, 785, 17, 42, 0);
    // magenta bits
    for (const [x, y, rx, ry] of [[440, 566, 14, 16], [538, 432, 16, 9], [458, 620, 8, 10]]) R.dome(ellipseP(x, y, rx, ry, 0), '#f020c8', 0.28, 0.04, 5, 5);

    // ── lower-left coral panel: violet blob + yellow sponge ──
    const sal2 = P([[82, 640], [100, 592], [150, 572], [230, 562], [300, 574], [346, 600], [352, 676], [322, 702], [280, 722], [230, 750], [170, 780], [130, 800], [100, 770], [86, 720]]);
    R.dome(sal2, SAL, 0.24, 0.05, 10, 2);
    clipA(sal2, () => img(sand, 'multiply', 1));
    dots(sal2, 30, 13, '#fbf4f0', 1.5, 4);
    const vio = P([[180, 600], [210, 576], [270, 574], [330, 586], [348, 620], [340, 664], [300, 690], [250, 700], [210, 696], [184, 668]]);
    R.dome(vio, '#ffffff', 0.27, 0.04, 8, 2);
    clipA(vio, () => img(purp));
    const spg = P([[94, 662], [110, 644], [136, 634], [150, 606], [172, 614], [188, 642], [186, 680], [176, 714], [150, 742], [122, 756], [100, 730]]);
    R.dome(spg, '#f8e214', 0.27, 0.04, 6, 2);
    for (const [x, y, r] of [[146, 686, 18], [122, 646, 8], [120, 735, 9], [168, 650, 6], [110, 700, 5]]) R.flat(circleP(x, y, r), '#f39018', 0.27, 2);
    // second white band
    const band2 = P([[124, 800], [150, 772], [200, 752], [260, 728], [320, 700], [380, 670], [440, 646], [500, 626], [514, 638], [470, 654], [420, 674], [362, 702], [300, 728], [240, 752], [190, 772], [150, 796]]);
    R.dome(band2, WH, 0.24, 0.05, 6, 5);
    a.lineWidth = 12; a.strokeStyle = WH; a.stroke(band2); R.pipe(band2, 12, null, 0.24, 0.04, 5);
    // slate-teal blob
    const teal = P([[140, 850], [150, 800], [200, 772], [260, 744], [320, 720], [380, 694], [440, 658], [500, 642], [530, 650], [536, 700], [516, 736], [480, 738], [450, 752], [420, 770], [390, 796], [350, 796], [320, 792], [290, 800], [262, 804], [240, 840], [228, 880], [210, 900], [170, 898], [146, 880]]);
    R.dome(teal, '#6f949b', 0.24, 0.12, 22, 6);
    // silver ring
    R.dome(circleP(482, 856, 45), '#d4d0c8', 0.22, 0.12, 20, 3);
    R.dome(circleP(484, 858, 26), '#4a4446', 0.18, 0.02, 6, 1);

    // ── right porthole with white dots ──
    R.dome(circleP(700, 790, 160), '#2a282e', 0.12, 0.16, 50, 1);
    R.dome(circleP(706, 792, 108), '#0e0d10', 0.1, 0.03, 10, 1);
    for (let i = 0; i < 9; i++) { const t = Math.PI * (0.55 + i * 0.12); R.bead(706 + Math.cos(t) * 78, 792 + Math.sin(t) * 104, 13, '#f6f6f6', 0.2, 0.06, 5); }
    for (const [x, y, r] of [[666, 592, 12], [702, 568, 11], [720, 520, 9]]) R.bead(x, y, r, '#f6f6f6', 0.3, 0.06, 5);

    // scattered white dots on the body
    for (const [x, y, r] of [[240, 348, 9], [330, 352, 6], [475, 276, 6], [360, 308, 5], [574, 302, 6], [598, 334, 5], [590, 622, 9], [560, 776, 7], [406, 826, 9], [145, 902, 9], [70, 926, 7], [130, 966, 5], [178, 1004, 14], [540, 996, 11], [708, 494, 8], [244, 492, 6], [70, 598, 6], [74, 715, 6], [150, 615, 6], [212, 666, 8], [602, 486, 4], [560, 690, 7], [418, 690, 5], [300, 806, 4], [254, 914, 4]])
      R.bead(x, y, r, '#f6f6f6', 0.26, 0.05, 5);
    // red glow bottom-right
    R.dome(P([[700, 990], [746, 980], [746, 1044], [690, 1044]]), '#e8202a', 0.1, 0.05, 6, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.3, shin: 70, wrap: 0.2, coat: 0.35, ao: 0.6, rim: 0.4 }),         // 1 black gloss body
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.5, grain: 0.25, ao: 0.4 }),                  // 2 coral sand / sponge
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.4, coat: 0.08, ao: 0.4 }),                   // 3 cream pills / ring
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.4, grain: 0.35, ao: 0.8 }),                 // 4 grey stone
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.5, coat: 0.05, ao: 0.3, emis: 0.1 }),        // 5 white paint
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.4, coat: 0.06, ao: 0.5 }),                   // 6 slate teal
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.4, coat: 0.15, emis: 0.2, iri: 0.2 })        // 7 rainbow
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.7, 0.7, 0.72], amb: [0.42, 0.42, 0.44],
      envTop: [1.1, 1.1, 1.12], envHor: [0.35, 0.35, 0.38], envBot: [0.04, 0.04, 0.05], envK: [0.5, 1.3, 0.4, 0],
      rimC: [0.15, 0.15, 0.18], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [-5, 7, 0.6, 7]
    });
    E.grain(0.03, 28);
  }
});
