'use strict';
// g030 — "Pearl spiral reactor": glossy cream bead-chains coil around a chrome button on a glowing black
// field, with holographic foil patches, a white reaction-diffusion maze with two target spirals, a pale-blue
// leopard-holed shelf below and iridescent bubbles drifting top-left.
REC.register('g030', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipH = (path, fn) => { R.h.save(); R.h.clip(path); fn(); R.h.restore(); };
    const img = (ctx, cv, op = 'source-over', al = 1) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalCompositeOperation = op; ctx.globalAlpha = al; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    // resample a smooth path into evenly spaced points
    const along = (pts, step) => {
      const out = []; let carry = 0;
      for (let i = 0; i < pts.length - 1; i++) {
        const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], L = Math.hypot(x1 - x0, y1 - y0);
        let t = carry; while (t < L) { out.push([x0 + (x1 - x0) * t / L, y0 + (y1 - y0) * t / L, Math.atan2(y1 - y0, x1 - x0)]); t += step; }
        carry = t - L;
      }
      return out;
    };
    const CRM = '#e2d2c6';
    const beads = (pts, step, rx, ry, h0) => { for (const [x, y, ang] of along(pts, step)) R.dome(ellipseP(x, y, rx, ry, ang), CRM, h0, 0.2, Math.min(rx, ry), 1); };

    // ── black field, beige panel, soft green light ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#070606', 0, 0);
    R.flat(P([[-10, 44], [60, 40], [100, 66], [150, 92], [210, 104], [260, 112], [200, 160], [120, 230], [70, 330], [60, 450], [80, 560], [110, 640], [-10, 660]]), '#d4cdc5', 0, 0);
    soft(x => { x.fillStyle = '#8aa08a'; x.fill(rrect(282, -20, 80, 150, 34)); }, 20, 1);
    // white halo glow around the inner coil and the hub
    soft(x => {
      x.strokeStyle = '#fff6ea'; x.lineWidth = 150;
      x.stroke(P([[520, 382], [470, 345], [420, 330], [370, 326], [320, 326], [270, 336], [235, 358], [205, 392], [190, 430], [185, 470], [192, 520], [205, 565], [228, 605], [262, 640], [310, 660], [360, 662], [410, 658], [455, 640], [490, 618], [510, 600]], false));
      x.fillStyle = '#fff6ea'; x.fill(circleP(375, 488, 105));
      x.lineWidth = 40; x.stroke(P([[62, 560], [48, 500], [45, 420], [52, 370], [66, 330], [90, 285], [125, 250], [185, 192], [260, 158], [340, 146]], false));
      x.fill(ellipseP(170, 650, 70, 50, 0.3)); x.fill(ellipseP(520, 470, 40, 70, 0));
    }, 16, 1);
    soft(x => { x.strokeStyle = '#070606'; x.lineWidth = 34; x.stroke(P([[114, 570], [104, 480], [106, 400], [124, 330], [160, 278], [212, 240], [280, 222], [350, 222], [420, 240], [480, 254], [530, 284]], false));
      x.fillStyle = '#070606'; x.fill(circleP(445, 560, 26)); }, 10, 0.9);

    // ── right maze with two target spirals (albedo + raised height) ──
    const maze = P([[548, -10], [746, -10], [746, 744], [600, 744], [540, 736], [520, 700], [534, 650], [564, 600], [598, 560], [600, 480], [618, 440], [606, 400], [572, 360], [550, 300], [520, 244], [470, 216], [420, 206], [360, 202], [300, 206], [284, 180], [290, 124], [330, 102], [390, 84], [440, 62], [480, 36], [520, 12]], true, true);
    // maze channels: fitted per-tile stripe phases (measured offline), procedural rings outside the fit
    const mz = `const vec2 ZC[51] = vec2[51](vec2(492., 32.), vec2(556., 32.), vec2(620., 32.), vec2(684., 32.), vec2(748., 32.), vec2(492., 96.), vec2(556., 96.), vec2(620., 96.), vec2(684., 96.), vec2(748., 96.), vec2(492., 160.), vec2(556., 160.), vec2(620., 160.), vec2(684., 160.), vec2(748., 160.), vec2(492., 224.), vec2(556., 224.), vec2(620., 224.), vec2(684., 224.), vec2(748., 224.), vec2(492., 288.), vec2(556., 288.), vec2(620., 288.), vec2(684., 288.), vec2(748., 288.), vec2(556., 352.), vec2(620., 352.), vec2(684., 352.), vec2(748., 352.), vec2(620., 416.), vec2(684., 416.), vec2(748., 416.), vec2(620., 480.), vec2(684., 480.), vec2(748., 480.), vec2(620., 544.), vec2(684., 544.), vec2(748., 544.), vec2(556., 608.), vec2(620., 608.), vec2(684., 608.), vec2(748., 608.), vec2(492., 672.), vec2(556., 672.), vec2(620., 672.), vec2(684., 672.), vec2(748., 672.), vec2(556., 736.), vec2(620., 736.), vec2(684., 736.), vec2(748., 736.));
const float ZK[306] = float[306](-0.923, 2.637, 3.064, -0.491, 0.983, -0.733, 2.400, 1.343, 3.117, -1.408, 0.497, 0.784, 0.059, -0.819, -3.372, 0.188, -0.565, -1.256, 2.196, -0.526, 3.695, -1.176, -0.052, 0.376, 0.840, -0.046, 3.810, 0.842, 0.080, -0.097, -5.083, 2.244, 2.303, 1.165, 0.647, -0.874, 8.582, 2.013, 3.095, -1.412, 1.669, -0.731, 3.453, 1.270, 3.925, -0.189, 0.973, -0.285, -7.215, -0.592, 4.340, -1.848, 0.295, 0.598, 3.895, -1.724, 3.968, -0.712, -1.017, 0.928, -1.071, -2.248, -1.709, -1.719, 0.506, 0.000, 5.216, 3.345, 1.682, -1.255, 2.489, -1.660, -1.108, 2.563, 3.539, -0.164, 3.004, -0.712, -1.137, -0.340, 4.951, -3.436, 1.200, 0.481, 5.221, -4.409, 3.571, -2.566, -2.979, -0.266, 4.370, 0.486, 0.079, 0.972, -0.271, -0.097, 10.473, 3.577, -0.013, 2.459, 0.155, -0.346, 1.408, 4.984, 0.448, 1.471, 0.905, -1.644, 7.614, 2.810, 5.053, -0.835, 1.403, -0.496, -2.479, -8.021, -0.450, -2.450, -8.332, -2.787, -2.196, -4.555, -0.715, 8.599, -1.755, -1.629, 5.207, 3.365, -1.534, 0.864, -1.726, -1.659, 4.236, -4.547, 1.599, -0.671, 0.297, 0.292, -6.112, 0.922, 4.553, 3.349, -1.762, -1.380, 5.987, 5.666, 1.974, 3.230, -4.696, 0.131, 1.843, 0.290, -0.536, 0.117, 7.375, -0.394, 2.222, -2.678, 2.020, 1.622, -1.729, -0.231, 3.590, 0.219, 3.537, 1.355, -0.657, -0.807, 1.309, -3.532, -3.578, -2.484, 0.864, -0.475, -0.636, -2.677, 1.094, -0.294, -0.932, -1.436, -5.402, 3.895, -0.881, -0.057, 0.591, 1.364, 0.250, -7.302, 3.267, -9.575, 1.575, -0.256, 0.639, 2.289, 0.506, -2.096, 1.722, 1.096, 0.785, 2.713, 2.267, -2.723, 1.095, -0.908, -3.771, -6.942, 3.379, -10.491, 2.082, -0.582, 0.210, 2.024, 4.464, -2.135, 1.855, 1.172, -6.179, -0.592, 4.322, -2.895, -0.290, 2.215, 0.955, -1.065, 3.664, 0.737, -1.672, 1.756, 5.241, -2.691, -2.800, -3.057, -0.962, 2.714, -4.647, 3.886, 4.257, -1.416, 3.731, -1.921, 3.521, 2.657, -5.182, 1.183, 4.194, 2.161, 1.778, -6.667, 2.440, -3.758, -4.170, -2.594, 0.891, 0.062, 2.467, 0.871, -3.139, 0.130, 0.517, 2.571, 0.645, 4.025, -0.156, 0.064, 1.445, -6.002, 0.193, -0.901, -1.253, 2.381, 5.686, -4.031, -3.023, -0.062, 0.418, -0.497, 2.020, 4.408, 1.712, 0.047, -1.512, 2.060, -1.034, -4.983, 3.243, 0.667, 0.692, -0.481, 0.090, -3.808, 4.278, 2.939, 0.841, 0.059, -4.455, -0.275, 0.849, -1.681, -0.266, 0.086, 5.303, 0.339, 0.138, 0.754, -0.636, 0.482);
vec2 zvw(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 51; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.247);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.283 * ph); ws += w; }
  return vec2(s / ws, ws); }
      float mzf(vec2 p){
        float d1 = length(p - vec2(675.6, 227.3)) * 1.1178 - 0.96 + uP1 * 20.5, d2 = length(p - vec2(648.6, 653.7)) * 1.168 + 4.39 + uP2 * 20.5;   // fitted ring centres / periods
        float k = 70., h = clamp(0.5 + 0.5 * (d2 - d1) / k, 0., 1.);
        float d = mix(d2, d1, h) - k * h * (1. - h);
        d += smoothstep(110., 260., min(d1, d2)) * (46. * vnoise(p * 0.006) + 10. * sin(p.y * 0.012 + p.x * 0.005));
        float bias = 0.6 * exp(-dot(p - vec2(380., 150.), p - vec2(380., 150.)) / 7000.);   // the white slab where the outer arc docks
        vec2 q = mat2(0.955, 0.296, -0.296, 0.955) * (p - vec2(390., 150.)) / vec2(105., 60.);
        float slab = 1. - smoothstep(0.85, 1.05, length(q));
        float w = smoothstep(0.45 - bias, 0.65 - bias, 0.5 + 0.5 * cos(6.2832 * (d / 20.5 + uPh)));
        vec2 z = zvw(p); w = mix(w, 1. - smoothstep(-0.2, 0.2, z.x), smoothstep(0.2, 0.6, z.y) * smoothstep(60., 100., min(d1, d2)));
        return max(slab, w); }`;
    const MPH = { uPh: 0, uP1: 0, uP2: 0 };
    const mzA = E.fx(mz + `vec3 fx(vec2 uv, vec2 p){ float w = mzf(p); return mix(vec3(.03), vec3(.93, .9, .91), w); }`, MPH);
    const mzH = E.fx(mz + `vec3 fx(vec2 uv, vec2 p){ float w = mzf(p); return vec3(floor((0.04 + 0.16 * w) * 255.) / 255., 64. / 255., 0.); }`, MPH);
    clipA(maze, () => img(a, mzA)); clipH(maze, () => img(R.h, mzH));
    soft(x => { x.strokeStyle = '#fff4e8'; x.lineWidth = 30; x.stroke(maze); }, 10, 0.7);
    R.pipe(maze, 14, '#ece6e2', 0.12, 0.1, 2);
    R.flat(P([[548, 336], [600, 330], [652, 352], [668, 400], [672, 470], [664, 520], [628, 530], [606, 480], [590, 430], [560, 400]]), '#070606', 0.04, 0);
    for (const [x, y, rx, ry, t] of [[410, 110, 12, 14, 0.3], [418, 156, 24, 14, -0.4], [471, 184, 10, 13, 0], [498, 196, 12, 11, 0.4], [366, 148, 9, 12, 0]]) R.flat(P(blob(x, y, rx, ry, x + y, 8, 0.2, t)), '#0a0808', 0.06, 0);
    R.flat(P([[410, 222], [470, 220], [505, 240], [500, 268], [440, 262], [405, 246]]), '#070606', 0.04, 0);
    soft(x => { x.lineWidth = 46; x.lineCap = 'round'; x.strokeStyle = '#070606'; x.stroke(P([[140, 690], [230, 716], [330, 726], [420, 722], [490, 706]], false)); }, 8, 1);

    // ── outer bead arc ──
    beads([[96, 606], [62, 560], [48, 500], [45, 420], [52, 370], [66, 330], [90, 285], [125, 250], [150, 222], [185, 192], [220, 172], [260, 158], [296, 150]], 33, 24, 36, 0.18);
    R.dome(ellipseP(112, 622, 44, 40, 0), CRM, 0.18, 0.22, 40, 1);

    // ── inner bead coil ──
    beads([[520, 382], [470, 345], [420, 330], [370, 326], [320, 326], [270, 336], [235, 358], [205, 392], [190, 430], [185, 470], [192, 520], [205, 565], [228, 605], [262, 640], [310, 660], [360, 662], [410, 658], [455, 640], [490, 618], [510, 600]], 30, 21, 24, 0.2);
    // hub: cream torus, black well, chrome button
    R.dome(circleP(377, 492, 94), CRM, 0.2, 0.22, 44, 1);
    R.dome(circleP(377, 492, 48), '#120d0c', 0.12, 0.03, 6, 0);
    R.dome(circleP(377, 492, 40), '#8a8c94', 0.2, 0.06, 5, 3);
    R.dome(circleP(377, 492, 32), '#405a8a', 0.24, 0.14, 30, 3);

    // ── holographic foil patches with bristle fringes ──
    const holo = E.fx(`vec3 fx(vec2 uv, vec2 p){ float t = fbm(p * 0.012) * 2.2 + p.y * 0.004 + 0.4 * sin(p.x * 0.03);
      vec3 c = iri(t); c = mix(c, vec3(.7, 1., .3), 0.25 * smoothstep(0.4, 0.8, fbm(p * 0.02 + 3.)));
      return clamp(c * 1.15 + 0.08, 0., 1.); }`);
    const hL = P([[248, 362], [290, 356], [330, 368], [372, 360], [402, 372], [396, 394], [352, 402], [322, 424], [330, 472], [346, 522], [336, 574], [312, 600], [290, 588], [270, 556], [254, 518], [244, 470], [240, 420]]);
    const hR = P(blob(545, 485, 56, 72, 5, 14, 0.1));
    const bristle = (path, cx, cy, n, seed) => { const r = rng(seed); a.strokeStyle = '#5a4a40'; a.lineWidth = 1;
      for (let i = 0; i < n; i++) { const t = r() * 6.283, rr = 60 + r() * 80, x = cx + Math.cos(t) * rr, y = cy + Math.sin(t) * rr;
        a.beginPath(); a.moveTo(x, y); a.lineTo(x + Math.cos(t) * 8, y + Math.sin(t) * 8); a.stroke(); } };
    const holoG = E.fx(`vec3 fx(vec2 uv, vec2 p){ float t = fbm(p * 0.014) * 2.4 + p.y * 0.005;
      vec3 c = mix(iri(t), vec3(.3, .92, .45), 0.5);
      c = mix(c, vec3(.9, .9, .84), 0.4 * smoothstep(0.55, 0.75, fbm(p * vec2(0.05, 0.02) + 9.)));
      return clamp((c - 0.5) * 1.7 + 0.42, 0., 1.); }`);
    for (const [pth, cx, cy, sd, hv] of [[hL, 300, 470, 3, holoG], [hR, 545, 485, 4, holo]]) {
      a.save(); a.lineWidth = 16; a.setLineDash([1, 3]); a.strokeStyle = '#6a5a50'; a.stroke(pth); a.restore();
      R.dome(pth, '#ffffff', 0.26, 0.05, 8, 4);
      clipA(pth, () => img(a, hv));
    }

    // ── small spiral discs, black drops ──
    const spiralCv = (cx, cy, per) => E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(${cx}., ${cy}.); float s = sin(6.2832 * (length(d) / ${per} - atan(d.y, d.x) / 6.2832));
      return mix(vec3(.25, .22, .22), vec3(.86, .82, .8), smoothstep(-0.3, 0.3, s)); }`);
    for (const [x, y, r, per] of [[215, 645, 52, '6.'], [155, 345, 21, '4.'], [213, 303, 15, '4.']]) {
      R.dome(circleP(x, y, r), '#c8c0bc', 0.26, 0.06, r * 0.4, 5);
      clipA(circleP(x, y, r), () => img(a, spiralCv(x, y, per)));
    }
    { const r = rng(8); a.strokeStyle = '#5a4a40'; a.lineWidth = 1; for (let i = 0; i < 90; i++) { const t = r() * 6.283, x = 215 + Math.cos(t) * 54, y = 645 + Math.sin(t) * 54; a.beginPath(); a.moveTo(x, y); a.lineTo(x + Math.cos(t) * 8, y + Math.sin(t) * 8); a.stroke(); } }
    for (const [x, y, rx, ry] of [[255, 298, 10, 10], [430, 588, 22, 26], [516, 616, 22, 24], [30, 604, 10, 10], [423, 551, 7, 7]]) R.dome(ellipseP(x, y, rx, ry, 0), '#0c0a0c', 0.24, 0.1, Math.min(rx, ry), 2);

    // ── pale-blue leopard shelf (bottom) ──
    const shelfTop = [[-10, 622], [30, 630], [60, 645], [100, 690], [150, 724], [200, 746], [250, 752], [320, 770], [400, 788], [480, 800], [560, 806], [620, 806], [680, 776], [746, 760]];
    const shelf = P([...shelfTop, [746, 1044], [-10, 1044]]);
    const holes = `float hol(vec2 p){
        vec2 q = p + 10. * vec2(fbm(p * 0.02), fbm(p * 0.02 + 5.)) ;
        vec2 g = floor(q / 50.), f = q / 50. - g; float m = 9.;
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) {
          vec2 c = vec2(float(i), float(j)), r = vec2(hash(g + c), hash(g + c + 7.3));
          vec2 d = c + 0.15 + 0.7 * r - f; d.x *= 0.85;
          m = min(m, length(d) / (0.31 + 0.12 * hash(g + c + 2.1))); }
        return 1. - smoothstep(0.9, 1.05, m); }`;
    const shA = E.fx(holes + `vec3 fx(vec2 uv, vec2 p){ float hh = hol(p);
      vec3 base = mix(vec3(.54, .63, .88), vec3(.38, .45, .7), smoothstep(0.4, 0.7, fbm(p * 0.008 + 1.)));
      return mix(base, vec3(.02, .02, .04), hh); }`);
    const shH = E.fx(holes + `vec3 fx(vec2 uv, vec2 p){ float hh = hol(p); return vec3(floor((0.3 - 0.22 * hh) * 255.) / 255., 64. / 255., 0.); }`);
    clipA(shelf, () => img(a, shA)); clipH(shelf, () => img(R.h, shH));
    // smooth glossy lip along the top of the shelf (no holes)
    { const r = rng(12), lower = shelfTop.map(([x, y], i) => [x, y + 58 + r() * 36 + (x < 160 ? 50 : 0)]).reverse();
      const lip = P([...shelfTop.map(([x, y]) => [x, y - 2]), ...lower], true, true);
      R.dome(lip, '#bcc2e0', 0.26, 0.08, 18, 2);
      clipA(lip, () => { a.save(); a.globalAlpha = 0.5; a.filter = `blur(${10 * S}px)`; a.fillStyle = '#8fa4dc'; for (let i = 0; i < 10; i++) a.fill(ellipseP(r() * 726, 640 + r() * 200, 40 + r() * 60, 10 + r() * 10, 0)); a.restore(); }); }
    R.dome(P([[300, 800], [330, 784], [350, 820], [320, 834], [292, 826]]), '#e6d8d0', 0.3, 0.06, 10, 1);
    R.dome(P([[640, 760], [670, 730], [700, 740], [716, 780], [690, 800], [650, 800]]), '#e6d8d0', 0.24, 0.12, 20, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 45, wrap: 0.45, coat: 0.18, ao: 0.6, rim: 0.4 }),       // 1 cream beads
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.35, coat: 0.2, ao: 0.4, emis: 0.05 }),       // 2 glossy white / black
        E.mat({ dif: 0.5, metal: 0.7, spec: 1.2, shin: 80, rim: 0.3, ao: 0.3, emis: 0.1 }),       // 3 chrome
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.4, coat: 0.12, emis: 0.2 }),                 // 4 holo foil
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.4, ao: 0.6 })                                // 5 spiral discs
      ],
      light: [-0.35, 0.55, 0.76], lc: [0.7, 0.68, 0.66], amb: [0.42, 0.4, 0.4],
      envTop: [1.1, 1.06, 1.0], envHor: [0.5, 0.46, 0.44], envBot: [0.08, 0.07, 0.07], envK: [0.4, 1.2, 0.4, 0],
      rimC: [0.5, 0.42, 0.36], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-4, 6, 0.5, 6]
    });

    // ── iridescent bubbles + specks (over the lit relief) ──
    const bub = (x, y, r) => {
      const g = o.createRadialGradient(x, y, r * 0.6, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.05)'); g.addColorStop(0.7, 'rgba(120,200,255,0.35)'); g.addColorStop(0.85, 'rgba(255,120,220,0.6)'); g.addColorStop(1, 'rgba(255,255,255,0.9)');
      o.fillStyle = g; o.fill(circleP(x, y, r));
      o.fillStyle = 'rgba(255,255,255,0.9)'; o.fill(ellipseP(x - r * 0.35, y - r * 0.4, r * 0.25, r * 0.15, -0.6));
    };
    for (const [x, y, r] of [[125, 35, 25], [50, 173, 17], [87, 122, 11], [113, 145, 11], [200, 52, 8], [272, 62, 5], [168, 120, 5], [10, 20, 38]]) bub(x, y, r);
    const sr = rng(30); o.fillStyle = '#f4ece0';
    for (let i = 0; i < 40; i++) { const x = 230 + sr() * 400, y = 180 + sr() * 560; o.beginPath(); o.arc(x, y, 0.8 + sr() * 1.6, 0, 6.283); o.fill(); }
    E.bloom(0.12, 10);
    E.grain(0.03, 30);
  }
});
