'use strict';
// s22 — "Pewter ape in orbit": a pitted pewter ape mask with a red contour line, a pink-chrome
// snout and hard black-and-white facial creases, a blue lobe and a chrome ball, floating in
// a starfield of coloured pebbles in front of a big red planet.
REC.register('s22', {
  w: 1024, h: 947,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const r = rng(22);
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; if (blur) a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const fillP = (x, pts, col) => { x.fillStyle = col; x.fill(P(pts)); };
    const line = (x, pts, w, col) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(P(pts, false)); };

    // ── space + red planet ──
    R.flat(rrect(-10, -10, 1044, 967, 0), '#020206', 0, 0);
    soft(x => {
      for (let i = 0; i < 1400; i++) {
        const sx = r() * 1024, sy = r() * 947, rad = 0.4 + Math.pow(r(), 4) * 1.8, hue = r();
        x.fillStyle = hue < 0.5 ? `rgba(230,235,255,${0.3 + r() * 0.6})` : hue < 0.7 ? `rgba(120,200,255,${0.3 + r() * 0.6})` : hue < 0.85 ? `rgba(255,150,200,${0.3 + r() * 0.5})` : `rgba(255,220,120,${0.3 + r() * 0.5})`;
        x.beginPath(); x.arc(sx, sy, rad, 0, 6.283); x.fill();
      }
    }, 0.3);
    soft(x => {
      const g = x.createRadialGradient(520, 40, 40, 600, -40, 390);
      g.addColorStop(0, '#f08a8e'); g.addColorStop(0.45, '#ff6266'); g.addColorStop(0.85, '#ff5458'); g.addColorStop(1, '#f0484e');
      x.fillStyle = g; x.beginPath(); x.arc(600, -40, 388, 0, 6.283); x.fill();
    }, 1.5);
    // pebbles / gems
    const peb = (x, y, rr, col, hi = '#ffffff') => {
      R.dome(P(blob(x, y, rr, rr * (0.75 + r() * 0.3), x * 7 + y, 10, 0.18, r() * 3)), col, 0.05, 0.12 + rr * 0.004, rr * 0.8, 2);
    };
    for (const [x, y, rr, c] of [[40, 340, 18, '#b89a90'], [25, 402, 16, '#e8e4dc'], [52, 452, 18, '#ece8e0'], [160, 122, 12, '#f0ece4'], [210, 152, 9, '#e8a0b0'], [118, 110, 7, '#e8e0f0'],
      [55, 128, 9, '#3a9a8a'], [936, 256, 15, '#e0dcc8'], [944, 380, 18, '#9a9aa4'], [912, 382, 10, '#c05030'], [712, 452, 15, '#e8dcc8'], [722, 662, 30, '#a0703a'], [955, 692, 18, '#f0ecdc'],
      [826, 792, 34, '#b89040'], [884, 762, 12, '#f0f0f0'], [972, 512, 15, '#e0708a'], [160, 912, 18, '#e8d060'], [440, 902, 14, '#e8d070'], [380, 922, 9, '#e06090'], [770, 620, 8, '#3aa0d0'],
      [900, 60, 12, '#6a30a0'], [100, 195, 9, '#c060c0'], [105, 245, 8, '#40a0a0'], [780, 850, 10, '#4a90c0'], [650, 600, 9, '#3aa0b0'], [860, 520, 7, '#e0e0e0'], [990, 340, 14, '#40c0a0'],
      [30, 200, 8, '#e0e0e0'], [860, 700, 8, '#3080c0'], [330, 900, 10, '#e0c040'], [960, 60, 8, '#e8e8ff'], [700, 820, 9, '#d0d0e0'], [60, 520, 10, '#e0e0f0'], [980, 900, 12, '#d08a40']]) peb(x, y, rr, c);
    // purple iridescent bubble top-left
    R.dome(P(blob(195, 40, 62, 50, 3, 12, 0.12)), '#6a3ab0', 0.1, 0.3, 40, 3);

    // ── the mask ──
    const mask = [[270, 20], [330, 4], [420, 2], [520, 30], [610, 80], [680, 150], [720, 230], [738, 320], [740, 420], [730, 520], [710, 600], [690, 650], [672, 700],
      [640, 714], [600, 732], [520, 762], [430, 800], [340, 830], [260, 836], [200, 815], [140, 780], [90, 740], [60, 690], [50, 640], [60, 590], [90, 550], [100, 500],
      [110, 440], [125, 380], [140, 320], [165, 260], [200, 190], [225, 120], [245, 60]];
    const mg = a.createLinearGradient(100, 0, 740, 800);
    mg.addColorStop(0, '#8a96a2'); mg.addColorStop(0.35, '#7a8088'); mg.addColorStop(0.6, '#5c5c5c'); mg.addColorStop(0.85, '#44423e'); mg.addColorStop(1, '#34322e');
    R.dome(P(mask), mg, 0.06, 0.3, 80, 1);
    // blue lobe lower-left
    const bl = a.createLinearGradient(40, 580, 150, 740); bl.addColorStop(0, '#2a9ef0'); bl.addColorStop(1, '#0a6cc8');
    R.dome(P([[50, 640], [60, 590], [100, 560], [140, 570], [152, 640], [142, 720], [112, 760], [70, 730]]), bl, 0.2, 0.2, 40, 4);
    // left helmet strap
    R.pipe(P([[240, 70], [205, 170], [172, 270], [146, 370], [124, 470], [112, 540]], false), 28, '#8a96a0', 0.3, 0.1, 1);

    // inner face panel inside the red contour
    const contour = [[240, 115], [330, 135], [420, 160], [480, 186], [530, 230], [562, 282], [575, 335], [568, 385], [548, 440], [522, 485], [508, 540], [494, 585],
      [468, 632], [420, 680], [350, 712], [270, 722], [200, 702], [162, 660], [148, 600], [152, 520], [172, 440], [196, 360], [212, 280], [226, 190]];
    const cg = a.createLinearGradient(0, 110, 0, 730); cg.addColorStop(0, '#8a929a'); cg.addColorStop(0.6, '#6a7076'); cg.addColorStop(1, '#4a4c4e');
    R.dome(P(contour), cg, 0.34, 0.08, 30, 1);
    soft(x => { x.strokeStyle = '#2a2622'; x.lineWidth = 22; x.stroke(P(contour)); }, 9, 0.5);
    a.save(); a.strokeStyle = '#d83c3c'; a.lineWidth = 4.5; a.stroke(P(contour)); a.restore();

    // face planes (white) + black trenches
    const white = [
      [[300, 342], [360, 338], [420, 344], [436, 362], [400, 368], [330, 368], [296, 360]],
      [[236, 392], [290, 386], [320, 400], [316, 440], [270, 446], [240, 430]],
      [[196, 440], [250, 450], [300, 450], [350, 460], [356, 510], [330, 556], [270, 560], [220, 540], [196, 500]],
      [[176, 562], [230, 556], [286, 570], [300, 610], [270, 640], [210, 640], [180, 614]],
      [[250, 280], [300, 270], [330, 290], [300, 312], [256, 314]]
    ];
    for (const pts of white) R.dome(P(pts), '#e4eaf0', 0.42, 0.1, 22, 2);
    const K = '#060506';
    const blk = [
      ['p', [[250, 330], [300, 318], [370, 320], [440, 330], [440, 344], [370, 338], [300, 340], [258, 352]]],
      ['p', [[300, 396], [360, 392], [430, 398], [436, 420], [380, 426], [320, 440], [306, 420]]],
      ['s', [[190, 404], [214, 430], [250, 450]], 14],
      ['p', [[230, 460], [270, 468], [296, 500], [292, 540], [262, 548], [236, 520]]],
      ['p', [[158, 500], [196, 506], [228, 530], [234, 556], [196, 560], [162, 540]]],
      ['s', [[206, 600], [250, 612], [296, 612], [340, 598]], 12],
      ['s', [[170, 646], [230, 664], [300, 668], [360, 650]], 14],
      ['s', [[340, 400], [356, 450], [352, 510], [336, 560], [346, 610]], 12],
      ['s', [[260, 250], [300, 236], [340, 244]], 8]
    ];
    soft(x => {
      for (const b of blk) { if (b[0] === 's') line(x, b[1], b[2], K); else fillP(x, b[1], K); }
      fillE(x, 366, 382, 26, 8, -0.1, '#b0a080'); fillE(x, 368, 382, 8, 6, 0, '#1a1410');
    }, 5, 1);
    { const hx = R.h; hx.save(); hx.fillStyle = hc(0.36, 3); hx.strokeStyle = hc(0.36, 3);
      for (const b of blk) { if (b[0] === 's') { hx.lineWidth = b[2]; hx.stroke(P(b[1], false)); } else hx.fill(P(b[1])); } hx.restore(); }
    // pitted right cheek
    R.dome(P([[360, 460], [440, 440], [490, 480], [500, 560], [470, 620], [400, 640], [352, 600], [346, 520]]), '#80888e', 0.4, 0.06, 20, 1);
    for (let i = 0; i < 46; i++) { const px = 356 + r() * 140, py = 450 + r() * 180; if (Math.hypot((px - 425) / 75, (py - 545) / 95) > 1) continue; R.groove(circleP(px, py, 4 + r() * 4), 4, '#3a3e42', 0.46, 0.05, 1, 0.8); }
    // lower rim bands
    R.pipe(P([[160, 690], [240, 730], [340, 740], [430, 712], [500, 660]], false), 22, '#7a8690', 0.4, 0.08, 1);
    R.pipe(P([[200, 770], [300, 790], [400, 772], [490, 730]], false), 16, '#6a747c', 0.36, 0.08, 1);
    // snout (pink chrome) with nostril
    const sg = a.createLinearGradient(130, 290, 250, 400); sg.addColorStop(0, '#c89088'); sg.addColorStop(0.5, '#a07068'); sg.addColorStop(1, '#6a5060');
    R.dome(ellipseP(188, 344, 62, 50, -0.3), sg, 0.4, 0.2, 40, 5);
    R.flat(ellipseP(206, 322, 14, 9, -0.4), '#1a1012', 0.5, 3);
    soft(x => { fillE(x, 204, 378, 30, 10, -0.2, '#6a50e0'); fillE(x, 160, 326, 20, 9, -0.4, '#f0d0c8'); }, 5, 0.9);

    // holes, eye rings, pins on the pewter
    const hole = (x, y, rr, h = 0.3) => { R.dome(circleP(x, y, rr * 1.45), null, h, 0.04, rr * 0.45, 1); R.flat(circleP(x, y, rr), '#07070a', h - 0.12, 3); };
    for (const [x, y, rr] of [[435, 245], [470, 238], [393, 270], [517, 367], [515, 415], [535, 500], [570, 530], [627, 238], [300, 240], [240, 150], [305, 170], [290, 200],
      [540, 580], [505, 620], [600, 560], [480, 110]].map(([x, y]) => [x, y, 6 + r() * 6])) hole(x, y, rr);
    hole(605, 455, 20); hole(260, 790, 18);
    R.flat(circleP(505, 290, 28), '#08080a', 0.24, 3); R.pipe(circleP(505, 290, 14), 8, '#f2f2ee', 0.36, 0.06, 6); R.flat(circleP(505, 290, 7), '#050505', 0.3, 3);
    R.flat(P([[620, 280], [660, 250], [712, 240], [720, 290], [690, 336], [640, 336]]), '#08080a', 0.2, 3);
    R.bead(658, 312, 15, '#d8dce0', 0.3, 0.14, 6);
    R.bead(668, 400, 18, '#b8c0c8', 0.36, 0.14, 6); R.groove(circleP(668, 400, 22), 5, '#2a2a2e', 0.4, 0.04, 1, 0.8);
    R.bead(342, 104, 12, '#b0b8c0', 0.36, 0.12, 6); R.bead(300, 78, 8, '#b0b8c0', 0.36, 0.1, 6);
    // glossy black nose lump + lower loop band
    R.dome(ellipseP(640, 515, 42, 18, 0.1), '#141418', 0.36, 0.14, 16, 7);
    R.pipe(P([[570, 640], [610, 700], [660, 712], [694, 690]], false), 24, '#9aa2aa', 0.36, 0.1, 1);
    R.groove(P([[550, 612], [600, 668], [670, 684]], false), 8, '#1a1a1e', 0.42, 0.06, 1, 0.9);

    // chrome ball
    const cb = a.createRadialGradient(630, 820, 10, 655, 850, 84);
    cb.addColorStop(0, '#e0eaf4'); cb.addColorStop(0.4, '#8aa0b4'); cb.addColorStop(0.75, '#3a4250'); cb.addColorStop(1, '#c09a70');
    R.dome(circleP(655, 850, 82), cb, 0.1, 0.5, 82, 6);

    // soft tone painting: cool highlights, warm bronze rims, dark depths
    soft(x => { fillE(x, 420, 60, 150, 40, 0.2, '#b0c8dc'); fillE(x, 640, 300, 60, 150, 0, '#a8b8c8'); fillE(x, 180, 250, 30, 100, 0.3, '#a0b4c8'); }, 30, 0.5);
    soft(x => { fillE(x, 700, 620, 50, 90, 0.3, '#5a4834'); fillE(x, 420, 800, 180, 30, -0.2, '#4a3c30'); fillE(x, 100, 740, 50, 40, 0, '#6a5440'); fillE(x, 720, 420, 30, 120, 0, '#4a4a4a'); }, 30, 0.6);
    soft(x => { fillE(x, 400, 740, 190, 70, -0.15, '#121214'); fillE(x, 250, 220, 80, 90, 0, '#3a4048'); fillE(x, 250, 520, 60, 110, 0, '#4a6a84'); }, 36, 0.75);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.6, shin: 26, wrap: 0.3, ao: 1.0, metal: 0.2, rim: 0.9, coat: 0.05, emis: 0.05 }),     // 1 pewter
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.6, rim: 0.4, emis: 0.22 }),                                // 2 white planes / pebbles
        E.mat({ dif: 1, spec: 0.3, shin: 40, ao: 0.5 }),                                                                 // 3 holes, bubble
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, ao: 0.4, coat: 0.15, rim: 0.4, emis: 0.25 }),                  // 4 blue plastic
        E.mat({ dif: 0.6, metal: 0.5, spec: 1.0, shin: 60, rim: 0.6, emis: 0.15 }),                                     // 5 pink chrome snout
        E.mat({ metal: 0.7, dif: 0.4, spec: 1.2, shin: 80, rim: 0.5, emis: 0.1 }),                                      // 6 chrome
        E.mat({ dif: 0.6, spec: 1.4, shin: 90, coat: 0.3, rim: 0.4 })                                                   // 7 glossy black
      ],
      light: [-0.55, 0.6, 0.5], lc: [0.8, 0.8, 0.84], amb: [0.18, 0.19, 0.22], l2: [0.6, -0.6, 0.35, 3], l2c: [0.45, 0.3, 0.16],
      envTop: [0.95, 0.96, 1.0], envHor: [0.55, 0.56, 0.6], envBot: [0.3, 0.25, 0.2], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.5, 0.4, 0.28], rimD: [0.4, -0.5, 0.5], r1: 2.5, r2: 10, k: [0, 0.6, 0.4, 150], shadow: [8, -8, 0.55, 5]
    });
    E.bloom(0.12, 10);
    E.draw(E.blur(E.snapshot(), 0.8), 1);
    E.grain(0.03, 22);
  }
});
