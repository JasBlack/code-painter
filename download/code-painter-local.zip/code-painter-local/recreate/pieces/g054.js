'use strict';
// g054 — "Orange gremlin's T-square": an inked collage in a yellow-edged card — an orange arm and creature
// with blue and orange hoses, a spotted white pillow, a black T-square, a lacy net blob with a red bar,
// a tilted dashboard, a truss tower, a fur ball, a wire globe and a zebra-striped floor on a glowing grey ground.
REC.register('g054', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (fn, blur, alpha = 1) => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x); o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore(); };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const poly = pts => P(pts, true, false);
    const INK = '#0c0c0e', OR = '#f07408', ORd = '#c85406';
    // white spiky splash around a shape
    const spikes = (cx, cy, rx, ry, rot, n, len, seed, a0 = 0, a1 = 6.283) => {
      const q = rng(seed);
      for (let i = 0; i < n; i++) {
        const an = a0 + (a1 - a0) * q(), ca = Math.cos(an), sa = Math.sin(an);
        const ex = cx + (ca * rx * Math.cos(rot) - sa * ry * Math.sin(rot)), ey = cy + (ca * rx * Math.sin(rot) + sa * ry * Math.cos(rot));
        const nx = ex - cx, ny = ey - cy, L = Math.hypot(nx, ny), ux = nx / L, uy = ny / L, ln = len * (0.4 + q());
        const px = -uy, py = ux, bw = 4.5 + q() * 4, bend = (q() - 0.5) * 0.5;
        const tx = ex + (ux + px * bend) * ln, ty = ey + (uy + py * bend) * ln;
        const sp = P([[ex - ux * 4 + px * bw, ey - uy * 4 + py * bw], [ex + ux * ln * 0.5 + px * bw * 0.45, ey + uy * ln * 0.5 + py * bw * 0.45], [tx, ty],
          [ex + ux * ln * 0.5 - px * bw * 0.45, ey + uy * ln * 0.5 - py * bw * 0.45], [ex - ux * 4 - px * bw, ey - uy * 4 - py * bw]], true, true);
        K(sp, '#1a1a1e', 2.2); F(sp, '#ffffff');
        F(circleP(tx, ty, 2.6), '#ffffff');
      }
    };

    // ── card: white page + glowing grey ground ──
    F(rrect(0, 0, 726, 1024, 0), '#fefefe');
    const card = P([[40, 72], [62, 62], [64, 42], [664, 42], [666, 62], [690, 72], [690, 952], [668, 960], [666, 978], [62, 978], [60, 960], [40, 952]], true, false);
    F(card, '#7a7c82');
    C(card, () => {
      F(card, lin(0, 0, 726, 0, [[0, '#a8a9ad'], [0.35, '#5c5f66'], [0.7, '#56585e'], [1, '#9aa2b0']]));
      soft(x => {
        fe(x, 60, 640, 70, 110, 0, '#ff3a2a'); fe(x, 90, 560, 60, 50, 0, '#ffa060'); fe(x, 40, 720, 40, 40, 0, '#ff3020');
        fe(x, 680, 660, 70, 110, 0, '#e0309a'); fe(x, 640, 760, 80, 60, 0, '#8a38d8'); fe(x, 560, 720, 60, 40, 0, '#6a48c8');
        fe(x, 650, 230, 60, 90, 0, '#e8f0ff'); fe(x, 600, 60, 70, 40, 0, '#c8ccd4'); fe(x, 90, 260, 60, 90, 0, '#c4c4c8');
        fe(x, 380, 260, 60, 50, 0, '#3c3e44'); fe(x, 600, 870, 120, 60, 0, '#4a4248');
      }, 50, 1);
    });

    // ── zebra ball (top left) + blue hose ──
    const zball = circleP(178, 110, 74);
    C(zball, () => F(zball, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = sin(6.2832 * (p.x + 0.25 * p.y + 8. * sin(p.y * 0.04)) / 26.); return mix(vec3(.04), vec3(.96), smoothstep(-0.1, 0.1, s)); }`))));
    K(zball, INK, 2);
    const hose = P([[50, 64], [56, 110], [70, 160], [100, 210], [140, 236], [190, 244], [228, 232]], false);
    K(hose, INK, 52); K(hose, '#1828c8', 48);
    for (let i = 0; i <= 30; i++) {
      const t = i / 30, pts = [[50, 64], [56, 110], [70, 160], [100, 210], [140, 240], [190, 248], [230, 236]];
      const k = Math.min(5, Math.floor(t * 6)), u = t * 6 - k, a = pts[k], b = pts[k + 1];
      const x = a[0] + (b[0] - a[0]) * u, y = a[1] + (b[1] - a[1]) * u, dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy), nx = -dy / L * 23, ny = dx / L * 23;
      K(P([[x - nx, y - ny], [x + nx * 0.3, y + ny * 0.3 + 2], [x + nx, y + ny]], false), '#0a0e60', 2.5);
    }
    // ── orange arm + hand ──
    const arm = P([[100, 46], [148, 46], [170, 80], [214, 120], [262, 128], [304, 138], [344, 162], [366, 188], [356, 192], [330, 176], [340, 196], [322, 204], [318, 222], [306, 232],
      [292, 214], [270, 204], [234, 196], [210, 180], [176, 152], [130, 110]]);
    F(arm, OR); K(arm, INK, 2.5);
    for (const seg of [[[262, 150], [320, 168], [344, 182]], [[270, 162], [326, 186]], [[262, 178], [318, 198]]]) K(P(seg, false), INK, 1.5);
    K(P([[176, 100], [210, 140]], false), ORd, 5);

    // ── dashboard device ──
    soft(x => { x.fillStyle = '#ffffff'; x.fill(poly([[560, 60], [600, 70], [610, 150], [580, 250], [530, 240]])); }, 10, 0.5);
    spikes(556, 150, 40, 100, 0.3, 22, 26, 4, -1.2, 1.4);
    const dev = poly([[290, 46], [588, 48], [508, 224], [272, 124]]);
    F(dev, '#5c5c60'); K(dev, INK, 3);
    const scr = poly([[298, 54], [546, 54], [496, 170], [284, 112]]);
    F(scr, '#0a0a0e');
    C(scr, () => { const q = rng(11); for (let i = 0; i < 40; i++) F(circleP(300 + q() * 240, 56 + q() * 110, 0.6 + q() * 1.2), '#e8e8e8'); });
    F(poly([[546, 54], [588, 48], [508, 224], [496, 170]]), '#8a8a8e');
    K(circleP(468, 92, 22), '#e8e8e8', 2.5); K(P([[468, 92], [476, 80]], false), '#e83028', 2); K(P([[468, 92], [458, 98]], false), '#e83028', 2);
    for (let k = 0; k < 5; k++) { const x = 350 + k * 18, y = 112 + k * 7; F(rrect(x - 7, y - 8, 14, 15, 3), '#2a6ae8'); K(rrect(x - 4, y - 4, 8, 7, 1), '#e8f0ff', 1.2); }
    F(rrect(426, 142, 15, 15, 3), '#b8b8bc');
    for (let k = 0; k < 9; k++) K(rrect(300 + k * 22, 120 + k * 9, 12, 9, 3), '#38383c', 1.5);
    F(P([[360, 56], [376, 52], [384, 62], [370, 68]]), '#f05a10');
    for (const [x, y, sz] of [[396, 90, 8], [494, 132, 8], [440, 70, 5], [506, 118, 4]]) F(P(star(x, y, sz, sz * 0.3, 4, 0.3)), '#f4f4f4');

    // ── white spotted pillow ──
    const pil = P([[222, 210], [270, 212], [352, 232], [372, 262], [356, 330], [320, 400], [270, 470], [210, 520], [150, 548], [110, 536], [88, 490], [96, 420], [116, 352], [150, 290], [184, 238]]);
    spikes(222, 382, 124, 170, 0.42, 85, 36, 7, 0.9, 3.4);
    F(pil, '#ececee');
    C(pil, () => soft(x => { fe(x, 120, 440, 50, 120, 0.3, '#b4b8c4'); fe(x, 300, 260, 70, 30, 0.2, '#ffffff'); fe(x, 230, 300, 50, 40, 0, '#d8dae0'); }, 22, 0.9));
    K(pil, INK, 2.5);
    C(pil, () => { const q = rng(13); for (let i = 0; i < 70; i++) F(ellipseP(110 + q() * 250, 220 + q() * 320, 2 + q() * 2.5, 4 + q() * 3, 0.6 + q() * 0.6), '#a8701c'); });

    // ── lace net blob + red bar ──
    const net = P([[470, 248], [540, 250], [600, 290], [630, 360], [634, 450], [622, 540], [584, 600], [520, 616], [454, 596], [410, 550], [372, 470], [352, 400], [372, 320], [416, 268]]);
    spikes(495, 430, 134, 180, 0.08, 70, 28, 9);
    F(net, '#f4f4f4');
    C(net, () => F(net, pat(E.fx(`vec2 h2(vec2 q){ return vec2(hash(q), hash(q + 17.3)); }
      vec3 fx(vec2 uv, vec2 p){
        vec2 q = p / 15. + 0.6 * vec2(fbm(p * 0.03), fbm(p * 0.03 + 4.)), g = floor(q), f = fract(q); float d1 = 9., d2 = 9.; vec2 id = g;
        for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) { vec2 o = vec2(float(i), float(j)), c = o + 0.1 + 0.8 * h2(g + o) - f; float d = dot(c, c);
          if (d < d1) { d2 = d1; d1 = d; id = g + o; } else if (d < d2) d2 = d; }
        float e = sqrt(d2) - sqrt(d1);
        float pk = hash(id + 5.);
        vec2 cc = p - vec2(480., 450.);
        float near = smoothstep(150., 40., length(cc * vec2(1.0, 0.75)));
        vec3 cell = mix(vec3(.66, .66, .68), vec3(.92, .55, .56), step(0.8 - 0.55 * near, pk));
        cell = mix(cell, vec3(.98, .7, .62), near * 0.3);
        vec3 c = mix(cell, vec3(.97), smoothstep(0.2, 0.3, e));
        float edge = smoothstep(0.14, 0.2, e) * (1. - smoothstep(0.2, 0.26, e));
        return mix(c, vec3(.35), edge * 0.8); }`))));
    soft(x => { fe(x, 480, 470, 60, 100, -0.35, '#ffe0a0'); }, 30, 0.5);
    K(net, '#3a3a3e', 2);
    const bar = poly([[448, 388], [494, 368], [568, 540], [522, 560]]);
    soft(x => { x.fillStyle = '#ff8a40'; x.fill(bar); }, 12, 0.8);
    F(bar, '#f41c18'); K(bar, INK, 2);
    for (const [x, y, rr] of [[470, 402, 8], [494, 430, 13], [480, 470, 12], [520, 485, 7], [512, 520, 9], [536, 512, 10]]) F(circleP(x, y, rr), '#f8f070');
    F(circleP(582, 302, 4), '#ff4040');

    // ── T-square ──
    const stem = poly([[300, 456], [380, 424], [496, 698], [456, 730], [412, 724]]);
    F(stem, '#050506');
    F(poly([[456, 690], [496, 698], [456, 730], [412, 724]]), '#1a1a1e');
    F(poly([[148, 480], [488, 308], [500, 340], [156, 530]]), '#060607');
    F(poly([[148, 480], [488, 308], [496, 326], [152, 500]]), '#b8b8ba');
    K(poly([[148, 480], [488, 308], [500, 340], [156, 530]]), INK, 2);
    K(P([[440, 340], [478, 322]], false), '#e8e8ea', 1.5);

    // ── orange creature + cup + hose ──
    const body = P([[104, 640], [112, 604], [140, 586], [178, 588], [206, 596], [222, 568], [226, 534], [262, 536], [260, 590], [266, 650], [266, 700], [246, 734], [206, 746], [174, 734],
      [156, 700], [134, 680], [112, 670]]);
    F(body, OR); K(body, INK, 2.5);
    C(body, () => soft(x => { fe(x, 220, 700, 40, 46, 0, '#c84a04'); fe(x, 130, 650, 26, 18, 0, '#c84a04'); }, 10, 0.6));
    for (const seg of [[[150, 640], [180, 660], [200, 700]], [[114, 632], [140, 620]], [[206, 600], [212, 640]]]) K(P(seg, false), INK, 1.5);
    const ohose = P([[340, 700], [380, 702], [412, 680], [430, 640], [434, 600], [440, 560], [452, 536]], false);
    K(ohose, INK, 36); K(ohose, '#f08a30', 32);
    { const pts = [[340, 700], [380, 702], [412, 680], [430, 640], [434, 600], [440, 560], [452, 536]];
      for (let i = 0; i < 28; i++) { const t = i / 28 * 6, k = Math.floor(t), u = t - k, a = pts[k], b = pts[k + 1], x = a[0] + (b[0] - a[0]) * u, y = a[1] + (b[1] - a[1]) * u, dx = b[0] - a[0], dy = b[1] - a[1], L = Math.hypot(dx, dy);
        K(P([[x - dy / L * 15, y + dx / L * 15], [x + dy / L * 15, y - dx / L * 15]], false), '#fff4e8', 2.5); } }
    const fur = rng(17);
    for (let i = 0; i < 70; i++) { const an = -2.2 + fur() * 2.8, rr = 14 + fur() * 20; K(P([[458, 538], [458 + Math.cos(an) * rr, 538 + Math.sin(an) * rr]], false), i % 9 ? '#141010' : '#6a3a20', 2); }
    soft(x => { fe(x, 462, 530, 18, 14, 0, '#fff0a0'); }, 6, 0.9);
    const cup = rrect(256, 546, 104, 156, 12);
    F(cup, '#f4f4f4'); F(rrect(266, 560, 84, 136, 6), '#f68a28'); K(cup, INK, 2.5);
    F(ellipseP(308, 562, 50, 14, 0), '#f8f0e8'); K(ellipseP(308, 562, 50, 14, 0), INK, 2); F(ellipseP(306, 562, 22, 7, 0), '#f08a30'); F(circleP(300, 562, 3), INK);
    for (let k = 0; k < 8; k++) K(P([[278, 600 + k * 11], [338, 600 + k * 11]], false), '#5a2a06', 1.2);
    // hand on the T
    const hand = P([[206, 502], [212, 474], [226, 456], [246, 446], [262, 452], [270, 474], [292, 482], [306, 498], [302, 520], [282, 536], [254, 544], [226, 538]]);
    F(hand, OR); K(hand, INK, 2);
    for (const seg of [[[246, 452], [244, 486]], [[270, 474], [262, 500]], [[230, 500], [270, 506], [296, 500]]]) K(P(seg, false), INK, 1.4);

    // ── truss tower ──
    o.save(); o.translate(620, 530); o.rotate(0.13);
    F(rrect(-24, -250, 48, 510, 4), '#2a2624');
    C(rrect(-24, -250, 48, 510, 4), () => {
      const q = rng(19);
      for (let y = -240; y < 250; y += 22) { const c = q() < 0.3 ? '#f09020' : '#5a5048'; F(circleP(-8, y, 6), c); F(circleP(9, y + 11, 6), q() < 0.3 ? '#f09020' : '#4a4440'); F(circleP(-8, y - 2, 2), '#e8e8e8'); }
      F(rrect(-4, -150, 10, 260, 3), '#e08a28');
      for (let y = -250; y < 260; y += 24) { K(P([[-24, y], [24, y + 24]], false), '#e8e8ea', 1.8); K(P([[24, y], [-24, y + 24]], false), '#e8e8ea', 1.8); K(P([[-24, y], [24, y]], false), '#e8e8ea', 1.5); }
    });
    K(P([[-24, -250], [-24, 260]], false), '#f0f0f2', 3); K(P([[24, -250], [24, 260]], false), '#f0f0f2', 3);
    F(rrect(-28, -276, 56, 40, 6), '#b4b4b8'); K(rrect(-28, -276, 56, 40, 6), INK, 2); F(rrect(-28, -264, 56, 8, 2), '#d8d8dc');
    F(rrect(-30, 248, 60, 14, 6), '#d8d8dc'); K(rrect(-30, 248, 60, 14, 6), INK, 1.5);
    o.restore();

    // ── zebra floor ──
    const zf = P([[40, 704], [130, 700], [250, 714], [330, 740], [400, 770], [440, 800], [460, 880], [440, 978], [40, 978]], true, false);
    C(zf, () => F(zf, pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(720., 320.);
      float w = 4. * sin(p.y * 0.09 + p.x * 0.03) + 9. * (fbm(p * 0.015) - .5);
      float kink = 8. * step(0., sin(p.x * 0.025 - p.y * 0.04)) * smoothstep(780., 860., p.y);
      float ph = (length(q) + w + kink) / 21.;
      float s = sin(6.2832 * ph);
      return mix(vec3(.02), vec3(.97), smoothstep(-0.08, 0.08, s)); }`))));

    // ── fur ball + wire globe ──
    const fb = rng(21);
    F(ellipseP(490, 800, 74, 42, -0.1), '#060606');
    for (let i = 0; i < 260; i++) { const an = fb() * 6.283, rx = 70 * Math.cos(an), ry = 40 * Math.sin(an), x = 490 + rx, y = 800 + ry, L = 6 + fb() * 14;
      K(P([[x, y], [x + Math.cos(an) * L, y + Math.sin(an) * L]], false), i % 5 ? '#0e0e0e' : '#4a4a4a', 1.4); }
    soft(x => { fe(x, 438, 778, 20, 14, 0, '#ffffff'); fe(x, 544, 828, 20, 14, 0, '#ffffff'); }, 4, 0.95);
    const globe = circleP(500, 1014, 182);
    C(poly([[-10, -10], [736, -10], [736, 976], [-10, 976]]), () => {
      F(globe, 'rgba(60,60,66,0.5)');
      C(globe, () => {
        for (let k = -6; k <= 6; k++) { const ry = 182 * Math.abs(k) / 6.5; K(ellipseP(500, 1014, 182, ry + 4, 0), '#1a1a1c', 9); K(ellipseP(500, 1014, 182, ry + 4, 0), k % 2 ? '#d0d0d4' : '#a4a4aa', 6); }
        for (let k = -5; k <= 5; k++) { const rx = 182 * Math.abs(k) / 5.5; o.save(); o.translate(500, 1014); o.rotate(-0.3); K(ellipseP(0, 0, rx + 3, 182, 0), '#1a1a1c', 9); K(ellipseP(0, 0, rx + 3, 182, 0), k % 2 ? '#c4c4c8' : '#9a9aa0', 6); o.restore(); }
      });
      K(globe, INK, 2.5);
    });

    // ── yellow card edge ──
    K(card, '#f8ec48', 5); K(card, '#fbf4b4', 2);
    E.grain(0.03, 54);
  }
});
