'use strict';
// g040 — "Hooded pilgrims, ring wall": black-hooded figures with porcelain faces stand on grass
// before a glossy white wall pierced with sky and a lake view, studded with op-art ring targets,
// a staring eye, grey pebbles and a drifting black lace of smoke.
REC.register('g040', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const W = 726, H = 1024, rr = rng(40);
    const WALL = '#dcdadb', BLACK = '#0a0a0c';
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const area = pts => { let A = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; A += p[0] * q[1] - q[0] * p[1]; } return A; };
    const orient = (pts, cw) => (area(pts) > 0) === cw ? pts : pts.slice().reverse();
    // wobbly ring path (op-art target rings)
    const ring = (cx, cy, r, sx, sy, seed, wob) => {
      const pts = [], n = Math.max(24, Math.round(r * 0.6)), q = rng(seed), ph1 = q() * 6.3, ph2 = q() * 6.3;
      for (let i = 0; i < n; i++) { const t = i / n * Math.PI * 2, k = 1 + wob * (Math.sin(3 * t + ph1) * 0.6 + Math.sin(7 * t + ph2) * 0.4); pts.push([cx + Math.cos(t) * r * k * sx, cy + Math.sin(t) * r * k * sy]); }
      return P(pts);
    };
    const target = (cx, cy, rmax, step, sx, sy, seed, wob, h0, outline) => {
      const base = ring(cx, cy, rmax + step * 0.6, sx, sy, seed, wob);
      R.dome(base, '#08080a', h0, 0.03, 6, 1);
      for (let r = step * 0.7; r <= rmax; r += step) R.pipe(ring(cx, cy, r, sx, sy, seed, wob * Math.min(1, r / 60)), step * 0.56, '#f2f2f2', h0 + 0.02, 0.05, 1);
      if (outline) R.pipe(base, 5, WALL, h0, 0.06, 1);
    };

    // ── what lies behind the wall: sky, lake view, grass ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#c4d4e2', 0, 0);
    const skyHole = [[212, 150], [204, 92], [222, 42], [258, 10], [300, -12], [452, -12], [446, 60], [420, 118], [382, 166], [330, 190], [270, 196], [232, 180]];
    const lakeHole = [[424, 360], [460, 346], [520, 336], [600, 340], [660, 344], [700, 350], [700, 420], [660, 470], [600, 500], [540, 510], [470, 504], [436, 480], [418, 420]];
    { const g = a.createLinearGradient(0, 0, 0, 200); g.addColorStop(0, '#a8c4e0'); g.addColorStop(1, '#d0dce6'); a.fillStyle = g; a.fill(P(skyHole)); }
    soft(x => { x.fillStyle = '#f6dfd4'; x.fill(ellipseP(360, 140, 80, 22, -0.2)); x.fill(ellipseP(300, 175, 60, 14, 0)); x.fill(ellipseP(330, 60, 40, 8, 0)); x.fill(ellipseP(400, 100, 40, 14, 0)); }, 4, 0.95);
    soft(x => { x.fillStyle = '#e8f0f6'; x.fill(ellipseP(250, 70, 40, 12, 0)); }, 6, 0.8);
    { const lk = P(lakeHole);
      clipA(lk, () => {
        const g = a.createLinearGradient(0, 340, 0, 400); g.addColorStop(0, '#c4d4e2'); g.addColorStop(1, '#d6dee6'); a.fillStyle = g; a.fillRect(410, 330, 300, 80);
        a.fillStyle = '#7890b4'; a.fill(P([[410, 420], [440, 405], [500, 398], [560, 388], [610, 380], [650, 384], [700, 378], [710, 420]], true, false));
        a.fillStyle = '#5a7090'; a.fill(P([[540, 420], [600, 396], [640, 392], [700, 386], [710, 420]], true, false));
        a.fillStyle = '#6a7890'; a.fillRect(410, 418, 300, 10);
        const w = a.createLinearGradient(0, 428, 0, 510); w.addColorStop(0, '#9aa4b0'); w.addColorStop(1, '#6a6870'); a.fillStyle = w; a.fillRect(410, 428, 300, 90);
        for (let i = 0; i < 8; i++) { a.fillStyle = i % 2 ? 'rgba(120,150,90,0.6)' : 'rgba(220,220,225,0.5)'; a.fillRect(410, 432 + i * 6 + rr() * 3, 300, 2); }
        for (let i = 0; i < 40; i++) { a.fillStyle = 'rgba(40,40,50,0.5)'; a.fillRect(410 + rr() * 300, 460 + rr() * 50, 20 + rr() * 40, 1); }
      }); }

    // ── the porcelain wall with its holes ──
    const wall = new Path2D();
    wall.addPath(P(orient([[-10, -10], [736, -10], [736, 880], [560, 880], [480, 800], [300, 808], [262, 836], [200, 842], [100, 848], [-10, 852]], true), true, false));
    wall.addPath(P(orient(skyHole, false)));
    wall.addPath(P(orient(lakeHole, false)));
    R.dome(wall, WALL, 0.08, 0.12, 30, 1);
    clipA(wall, () => soft(x => {
      x.fillStyle = '#a8a6ae'; x.fill(ellipseP(250, 260, 80, 40, 0)); x.fill(ellipseP(520, 300, 60, 50, 0)); x.fill(ellipseP(60, 520, 40, 60, 0));
    }, 30, 0.5));

    // grey stains / blobs on the wall
    const greyBlob = P([[104, 300], [140, 270], [190, 262], [230, 280], [260, 300], [300, 300], [340, 280], [356, 300], [330, 330], [270, 340], [250, 380], [210, 398], [150, 396], [110, 370], [96, 330]]);
    R.dome(greyBlob, '#7c788a', 0.1, 0.03, 10, 2);
    for (const [x, y, rx, ry, sd] of [[60, 440, 34, 22, 1], [372, 470, 26, 18, 2], [220, 540, 20, 30, 3]]) R.dome(P(blob(x, y, rx, ry, sd, 10, 0.25)), '#8a8898', 0.1, 0.03, 8, 2);
    // glossy grey pebbles
    for (const [x, y, rx, ry] of [[112, 500, 32, 36], [432, 292, 33, 35], [432, 192, 25, 28], [370, 672, 35, 48]]) {
      R.dome(ellipseP(x, y, rx, ry, 0.2), '#8c8898', 0.14, 0.14, Math.min(rx, ry), 3);
    }
    // little black holes
    for (const [x, y, r] of [[187, 416, 12], [297, 383, 8], [110, 712, 6], [210, 716, 5], [408, 665, 6], [460, 632, 9], [395, 513, 6], [545, 332, 7], [268, 352, 5]]) {
      R.groove(circleP(x, y, r), 5, '#9a989c', 0.16, 0.05, 1); R.flat(circleP(x, y, r), '#050505', 0.06, 0);
    }

    // ── op-art ring targets ──
    target(709, 127, 236, 13, 1, 0.76, 11, 0.05, 0.1, true);
    R.dome(circleP(709, 127, 18), '#f0eeee', 0.2, 0.06, 8, 1); R.dome(circleP(712, 127, 10), '#060606', 0.26, 0.02, 4, 1); R.bead(708, 122, 3, '#ffffff', 0.3, 0.02, 1);
    { const clip = P([[500, 470], [600, 446], [736, 430], [736, 720], [640, 720], [540, 700], [500, 640], [494, 560]]);
      a.save(); a.clip(clip); R.h.save(); R.h.clip(clip);
      target(790, 600, 290, 13, 1, 0.75, 12, 0.03, 0.1, false);
      R.h.restore(); a.restore();
      R.pipe(clip, 6, WALL, 0.1, 0.08, 1); }
    target(370, 407, 40, 7, 1, 1, 13, 0.04, 0.12, true);
    target(148, 655, 48, 8, 1, 1, 14, 0.05, 0.12, true);
    target(162, 785, 55, 8, 1, 1, 15, 0.05, 0.12, true);
    target(60, 872, 42, 8, 1, 0.8, 16, 0.04, 0.12, true);

    // ── the eye ──
    R.bead(65, 145, 37, '#f2f0f0', 0.14, 0.2, 1);
    R.dome(circleP(64, 142, 21), '#060608', 0.34, 0.03, 6, 3);
    R.bead(56, 132, 5, '#ffffff', 0.38, 0.03, 1);

    // ── grass, rocks, red reeds ──
    const grass = P([[-10, 852], [100, 848], [200, 842], [262, 836], [300, 808], [480, 798], [560, 806], [580, 900], [520, 910], [300, 940], [100, 980], [-10, 1000]]);
    const gcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * vec2(0.05, 0.012)), b = hash(floor(p * vec2(0.5, 0.12)));
      vec3 c = mix(vec3(.3,.34,.22), vec3(.66,.71,.5), n);
      c = mix(c, vec3(.72,.76,.56), step(0.8, b) * 0.6);
      return c * (0.75 + 0.35 * smoothstep(1000., 820., p.y)); }`);
    R.flat(grass, null, 0.04, 0);
    clipA(grass, () => img(gcv));
    for (const [x, y, rx, ry] of [[140, 900, 50, 22], [210, 940, 60, 26], [70, 965, 50, 20], [300, 880, 40, 18], [350, 830, 60, 22], [420, 880, 50, 26], [260, 840, 30, 12], [470, 830, 40, 14], [20, 930, 30, 16]])
      R.dome(P(blob(x, y, rx, ry, x + y, 12, 0.18)), '#5a5452', 0.06, 0.1, Math.min(rx, ry), 4);
    for (let i = 0; i < 70; i++) { const x = 280 + rr() * 210, y = 800 - rr() * 10, L = 20 + rr() * 70, an = -1.57 + (rr() - 0.5) * 0.7;
      R.pipe(P([[x, y], [x + Math.cos(an) * L, y + Math.sin(an) * L]], false), 2, rr() < 0.6 ? '#d06048' : '#c8b0a8', 0.12, 0.02, 4); }

    // ── left figure: brown robe, black hood ──
    const robeL = P([[-10, 420], [20, 412], [40, 450], [44, 520], [70, 560], [90, 640], [100, 760], [96, 836], [-10, 840]]);
    R.dome(robeL, '#24120a', 0.14, 0.14, 30, 4);
    R.paint(P([[0, 440], [20, 450], [30, 560], [20, 700], [0, 760]]), '#5a2a16');
    R.dome(P([[-10, 412], [24, 410], [42, 440], [40, 520], [20, 560], [-10, 560]]), '#050505', 0.18, 0.1, 16, 5);
    R.dome(ellipseP(20, 480, 14, 34, 0), '#e8e4e4', 0.24, 0.08, 10, 1);
    R.dome(P([[30, 560], [60, 552], [70, 580], [50, 600], [30, 590]]), '#c8a898', 0.24, 0.06, 8, 4);
    R.dome(P([[70, 576], [130, 576], [140, 584], [100, 592], [70, 596]]), '#202024', 0.24, 0.04, 6, 5);
    R.dome(rrect(30, 534, 18, 36, 6), '#b0b8c4', 0.26, 0.06, 6, 3);

    // ── centre figure ──
    const fig = P([[300, 426], [334, 440], [356, 476], [366, 526], [392, 556], [412, 538], [432, 520], [442, 548], [404, 600], [386, 640], [390, 720], [396, 800], [206, 802], [212, 700], [226, 646], [204, 626], [184, 612], [196, 570], [228, 536], [244, 480], [266, 442]]);
    R.dome(fig, '#0b0b0d', 0.16, 0.18, 30, 5);
    for (const cl of [[[290, 560], [280, 660], [276, 790]], [[340, 600], [348, 700], [352, 790]], [[250, 600], [238, 700], [236, 790]]]) R.groove(P(cl, false), 6, '#1e1e24', 0.34, 0.06, 5);
    R.dome(P([[276, 486], [296, 474], [318, 486], [322, 520], [312, 548], [296, 552], [284, 536], [272, 512]]), '#f0eeee', 0.32, 0.1, 12, 1);
    R.dome(P([[256, 586], [290, 576], [330, 576], [360, 564], [366, 584], [340, 604], [300, 600], [268, 610], [254, 600]]), '#f0eeee', 0.36, 0.1, 10, 1);
    R.pipe(circleP(377, 585, 7), 6, '#f0eeee', 0.38, 0.05, 1);
    R.dome(P([[244, 636], [262, 630], [278, 646], [270, 664], [252, 664], [242, 652]]), '#e8d8cc', 0.36, 0.06, 8, 4);
    // brass bottle
    R.dome(P([[404, 500], [436, 500], [440, 520], [420, 556], [404, 548], [398, 520]]), '#8a6020', 0.34, 0.1, 10, 6);
    R.pipe(P([[426, 500], [430, 476]], false), 8, '#b08030', 0.4, 0.06, 6);
    R.dome(P([[430, 572], [470, 566], [478, 578], [460, 588], [432, 586]]), '#f0eeee', 0.36, 0.08, 8, 1);

    // ── right figure with the pointing white hand ──
    const figR = P([[640, 480], [690, 470], [736, 480], [736, 890], [570, 890], [580, 760], [600, 640], [610, 560]]);
    R.dome(figR, '#0b0b0d', 0.16, 0.18, 30, 5);
    R.dome(P([[644, 512], [670, 500], [700, 512], [704, 560], [690, 604], [664, 608], [648, 580], [640, 540]]), '#f0eeee', 0.32, 0.12, 14, 1);
    const hand = P([[440, 690], [470, 683], [505, 688], [560, 684], [620, 680], [648, 690], [642, 722], [612, 760], [588, 790], [570, 812], [552, 832], [526, 844], [498, 842], [480, 828], [474, 800], [480, 770], [492, 742], [500, 714], [470, 708], [444, 704]]);
    R.dome(hand, '#f4e8e0', 0.3, 0.16, 26, 1);
    for (const x of [500, 522, 544]) R.groove(P([[x + 10, 770], [x + 4, 810], [x - 2, 840]], false), 4, '#c8b0a8', 0.44, 0.04, 1);
    R.groove(P([[470, 696], [500, 698]], false), 2, '#c8b0a8', 0.44, 0.02, 1);

    // ── bottom: white band and dark pool ──
    R.flat(P([[240, 980], [400, 950], [520, 935], [600, 925], [736, 905], [736, 1040], [240, 1040]]), '#08080c', 0.04, 0);
    { const g = a.createLinearGradient(0, 900, 0, 1024); g.addColorStop(0, 'rgba(40,40,70,0)'); g.addColorStop(1, 'rgba(40,40,70,0.6)'); clipA(P([[290, 940], [736, 870], [736, 1040], [290, 1040]]), () => { a.fillStyle = g; a.fillRect(290, 860, 450, 180); }); }
    R.pipe(P([[-20, 1040], [60, 1024], [130, 1006], [220, 975], [320, 948], [420, 930], [520, 914], [620, 896], [740, 878]], false), 66, '#e4e2e4', 0.14, 0.14, 1);
    R.pipe(P([[-20, 848], [60, 842], [120, 840]], false), 12, '#e8e6e8', 0.12, 0.06, 1);

    // ── black lace smoke drifting down from the top ──
    { const lace = [[236, 0], [214, 22], [190, 40], [170, 70], [150, 100], [132, 130], [118, 170], [100, 200], [64, 216], [36, 236], [20, 280], [12, 330], [8, 380]];
      const lace2 = [[106, 206], [136, 236], [176, 270], [204, 318], [226, 380], [240, 430], [246, 470]];
      soft(x => { for (const L of [lace, lace2]) for (let i = 0; i < L.length - 1; i++) { const p = L[i], q = L[i + 1];
        for (let k = 0; k < 6; k++) { const u = k / 6, cx = p[0] + (q[0] - p[0]) * u + (rr() - 0.5) * 30, cy = p[1] + (q[1] - p[1]) * u + (rr() - 0.5) * 30;
          x.fillStyle = rr() < 0.5 ? '#5a5a62' : '#8a8a92'; x.fill(circleP(cx, cy, 5 + rr() * 9)); } } }, 3, 0.75);
      a.strokeStyle = '#060608'; a.fillStyle = '#060608';
      for (const L of [lace, lace2]) for (let i = 0; i < L.length - 1; i++) {
        const p = L[i], q = L[i + 1];
        for (let k = 0; k < 22; k++) { const u = k / 22, x = p[0] + (q[0] - p[0]) * u + (rr() - 0.5) * 18, y = p[1] + (q[1] - p[1]) * u + (rr() - 0.5) * 18;
          a.lineWidth = 1.2 + rr(); a.beginPath(); a.arc(x, y, 1.5 + rr() * 2.5, 0, 6.283); a.stroke(); if (rr() < 0.4) a.fill(circleP(x + 2, y + 2, 1.2)); }
      } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 0.9, shin: 60, wrap: 0.35, ao: 0.5, coat: 0.3, rim: 0.2 }),        // 1 porcelain
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.4 }),                                // 2 matte stain
        E.mat({ dif: 0.9, spec: 1.1, shin: 70, wrap: 0.2, ao: 0.4, coat: 0.35 }),                  // 3 glossy pebble
        E.mat({ dif: 1, spec: 0.2, shin: 15, wrap: 0.4, ao: 0.5, grain: 0.15 }),                   // 4 rock / cloth / skin
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.2, ao: 0.4, coat: 0.25, rim: 0.3 }),          // 5 black satin
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.2, shin: 50, ao: 0.4, tint: [1.1, 0.9, 0.6] })       // 6 brass
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.85, 0.85, 0.86], amb: [0.36, 0.36, 0.38],
      envTop: [1.05, 1.05, 1.08], envHor: [0.55, 0.56, 0.6], envBot: [0.1, 0.1, 0.12], envK: [0.4, 1.1, 0.2, 0],
      rimC: [0.25, 0.27, 0.32], rimD: [0, 1, 0], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 90], shadow: [-4, 6, 0.55, 7]
    });
    E.grain(0.03, 40);
  }
});
