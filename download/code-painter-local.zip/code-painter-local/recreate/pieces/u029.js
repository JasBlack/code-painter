'use strict';
// u029 — "Shark ghosts' starry cave": a grey clay cloud-mountain with a zebra-ponchoed cyclops robot, an oil-slick
// portal in a gold-rimmed star cave full of grinning hooded ghosts, over a lavender field of black leopard spots.
REC.register('u029', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };

    // ── textures ──
    const STARS = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = vec3(.035, .027, .04);
        c = mix(c, vec3(.11, .19, .26), smoothstep(260., 40., length((p - vec2(690., 40.)) * vec2(1., 1.3))) * .9);
        vec2 g = floor(p / 6.), f = fract(p / 6.) - .5; float h = hash(g);
        vec2 o = vec2(hash(g + 3.1), hash(g + 7.7)) - .5;
        c += step(.82, h) * smoothstep(.22, .05, length(f - o * .5)) * vec3(.9, .9, .95) * (.4 + .6 * hash(g + 9.));
        vec2 G = floor(p / 23.), F = fract(p / 23.) - .5; float H = hash(G + 11.);
        vec2 O = vec2(hash(G + 5.1), hash(G + 2.7)) - .5;
        c += step(.75, H) * smoothstep(.1, .03, length(F - O * .6)) * vec3(1.);
        return c; }`);
    const SLICK = E.fx(`
      vec3 pal(float t){ t = fract(t) * 4.;
        vec3 c0 = vec3(.96, .46, .76), c1 = vec3(.99, .95, .46), c2 = vec3(.30, .80, .76), c3 = vec3(.46, .46, .88);
        return t < 1. ? mix(c0, c1, smoothstep(0., 1., t)) : t < 2. ? mix(c1, c2, smoothstep(1., 2., t)) : t < 3. ? mix(c2, c3, smoothstep(2., 3., t)) : mix(c3, c0, smoothstep(3., 4., t)); }
      vec3 fx(vec2 uv, vec2 p){
        vec2 d = p - vec2(492., 492.); float ca = cos(.62), sa = sin(.62);
        vec2 q = vec2(d.x * ca - d.y * sa, d.x * sa + d.y * ca);
        float r = length(q / vec2(220., 58.));
        float ph = r * 3.4 + (fbm(p * .02) - .5) * 1.1 + .15 * sin(q.x * .06);
        vec3 c = pal(-ph);
        float ring = length(p - vec2(458., 546.));
        c = mix(c, vec3(.92, .9, .95), .5 * smoothstep(.5, 1., sin(ring * .7)) * smoothstep(24., 12., ring));
        return c; }`);
    const ZEB = E.fx(`
      const vec2 ZC[12] = vec2[12](vec2(460., 237.), vec2(524., 237.), vec2(588., 237.), vec2(652., 237.), vec2(460., 301.), vec2(524., 301.), vec2(588., 301.), vec2(652., 301.), vec2(460., 365.), vec2(524., 365.), vec2(588., 365.), vec2(652., 365.));
      const float ZK[72] = float[72](-6.2696, 4.3814, 2.8709, 0.2469, 0.1678, -1.2412, -2.3478, 4.8165, 2.5236, 0.1659, -0.8762, -0.5732, 0.1874, 5.7305, -0.2849, -0.5031, -3.1709, 2.9493, -5.7575, 0.4729, 3.7830, -0.9407, 4.3768, -0.3866, 1.1258, 4.4499, 1.8374, -0.0755, -0.1638, -0.1942, 0.0089, -4.4976, -1.7295, -0.0873, 0.1607, 0.4468, -1.0990, 4.1629, 1.0663, -0.8898, -1.9670, -0.4645, 0.5888, -0.4244, 0.8900, -4.8394, 0.4036, -1.6560, 1.4513, 0.4633, 0.6883, 0.4148, 1.3558, 0.9393, 0.9205, 4.2929, 0.5778, -0.0567, -0.1331, -1.6611, 5.5480, 3.0536, 1.0600, -1.3534, -1.7837, 0.0890, -0.1283, -2.0397, 2.2754, -5.9731, -2.2278, 3.4534);
      float zv(vec2 p){ float s = 0., ws = 1e-4;
        for (int i = 0; i < 12; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2478);
          float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
          s += w * cos(6.2832 * ph); ws += w; }
        return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.80, .80, .83), vec3(.22, .22, .25), smoothstep(-.25, .25, zv(p))); }`);

    // ── sky, lavender field and spot field ──
    img(STARS);
    fill(poly([[0, 318], [726, 318], [726, 1024], [0, 1024]]), lin(0, 320, 0, 1024, [[0, '#b2bad0'], [0.12, '#a6b2da'], [0.6, '#a2b0dc'], [1, '#9cacdc']]));
    const SPOT = sm([[726, 430], [702, 440], [692, 520], [694, 600], [688, 660], [670, 694], [640, 720], [600, 738], [540, 752], [480, 768], [420, 786], [360, 806], [310, 828], [262, 852], [215, 868], [170, 892], [120, 926], [70, 964], [30, 994], [0, 1008], [0, 1030], [740, 1030], [740, 430]]);
    // cave
    const CAVE = sm([[590, 343], [640, 348], [664, 362], [672, 420], [680, 480], [686, 540], [690, 600], [686, 650], [674, 684], [650, 708], [610, 728], [560, 743], [500, 758], [440, 776], [390, 794], [340, 812], [300, 831], [262, 850], [226, 862], [204, 852], [206, 826], [224, 800], [244, 772], [252, 740], [300, 700], [350, 640], [378, 590], [384, 530], [398, 470], [438, 420], [488, 386], [540, 360]]);

    // ── clay masses ──
    const CLAY = sm([[0, 252], [18, 240], [36, 262], [56, 300], [82, 318], [116, 318], [150, 300], [176, 262], [198, 202], [218, 184], [248, 194], [268, 178], [278, 146], [300, 108], [316, 60], [340, 30], [376, 18], [406, 30], [424, 62], [442, 96], [472, 100], [500, 112], [560, 120], [612, 134], [652, 138], [684, 160], [694, 186], [726, 190], [726, 330], [700, 344], [668, 352], [600, 343], [540, 360], [488, 386], [438, 420], [398, 470], [384, 530], [378, 590], [350, 640], [300, 700], [252, 740], [236, 780], [228, 812], [190, 834], [120, 836], [56, 822], [32, 786], [44, 744], [66, 706], [50, 668], [42, 620], [48, 584], [64, 556], [76, 528], [64, 492], [72, 450], [98, 404], [128, 356], [140, 340], [100, 346], [50, 344], [0, 340]]);
    R.dome(CLAY, '#a2a2a9', 0.05, 0.2, 40, 1);
    clipA(CLAY, () => {
      soft(x => { x.fillStyle = '#c4c4cc'; x.fill(sm([[0, 252], [18, 240], [36, 262], [56, 300], [82, 318], [116, 318], [150, 300], [176, 262], [198, 202], [218, 184], [250, 196], [240, 260], [200, 320], [140, 340], [60, 340], [0, 334]])); }, 10, 1);
      soft(x => { x.fillStyle = '#bcbcc4'; x.fill(poly([[640, 190], [726, 180], [726, 330], [660, 340], [650, 260]])); }, 14, 1);
      soft(x => { x.fillStyle = '#c4c4cc'; x.fill(sm([[40, 760], [80, 720], [140, 720], [200, 740], [232, 790], [210, 830], [120, 836], [50, 820]])); }, 14, 1);
      soft(x => { x.fillStyle = '#8e8e96'; x.fill(sm([[60, 580], [150, 568], [260, 572], [330, 600], [300, 680], [240, 720], [140, 700], [70, 660]])); }, 18, 0.6);
    });
    // cumulus bumps: soft height swells blended into the clay (so the lumps merge like cloud)
    const swell = (x, y, rr, ht) => {
      const g = R.h.createRadialGradient(x, y, 0, x, y, rr), c = hc(ht, 1).replace('rgb(', 'rgba(');
      [[0, 1], [0.35, 0.85], [0.7, 0.35], [1, 0]].forEach(([t, al]) => g.addColorStop(t, c.replace(')', `,${al})`)));
      R.h.fillStyle = g; R.h.fill(circleP(x, y, rr));
    };
    R.h.save(); R.h.clip(CLAY);
    { const r = rng(29); for (let i = 0; i < 120; i++) {
      const y = 24 + r() * 320, half = 30 + (y - 20) * 0.62, x = 360 + (r() - 0.5) * 2 * Math.min(half, 160);
      const rr = 16 + r() * 26; swell(x, y, rr, 0.3 + r() * 0.12);
    } }
    { const r = rng(7); for (let i = 0; i < 50; i++) swell(r() * 270, 236 + r() * 90, 12 + r() * 18, 0.26 + r() * 0.08); }
    { const r = rng(17); for (let i = 0; i < 40; i++) swell(60 + r() * 330, 380 + r() * 330, 20 + r() * 30, 0.26 + r() * 0.05); }
    R.h.restore();
    // stalagmite + lower ghost lump
    R.dome(sm([[130, 680], [150, 640], [168, 626], [184, 650], [200, 700], [222, 750], [232, 800], [180, 812], [120, 800], [110, 740]]), '#d2d2d8', 0.15, 0.12, 22, 1);
    { const r = rng(4); for (let i = 0; i < 30; i++) R.bead(150 + r() * 70, 650 + r() * 140, 5 + r() * 9, null, 0.2, 0.05, 1); }
    // raised drawing lines on the figure
    for (const l of [[[136, 470], [138, 455], [148, 450], [152, 462], [146, 476], [144, 500]], [[204, 350], [196, 380], [210, 420], [236, 418], [244, 440], [236, 500], [228, 530]], [[200, 354], [230, 330], [270, 324], [300, 330]], [[270, 338], [290, 300], [320, 290], [360, 300]], [[248, 420], [240, 470], [232, 540]]])
      R.pipe(P(l, false), 9, '#cfd0d6', 0.25, 0.05, 1);
    // zebra arm fringe on the figure
    R.dome(sm([[340, 332], [404, 330], [402, 400], [390, 462], [300, 462], [296, 440], [322, 400]]), '#62626a', 0.12, 0.05, 10, 1);
    for (let k = 0; k < 4; k++) R.pipe(P([[352 + k * 16, 330], [342 + k * 17, 372], [326 + k * 19, 414], [306 + k * 21, 452]], false), 11, '#d2d2d8', 0.15, 0.07, 1);

    // ── robot ──
    const PONCHO = sm([[430, 236], [470, 212], [520, 205], [570, 205], [620, 212], [648, 240], [660, 300], [652, 330], [610, 328], [560, 326], [510, 334], [470, 342], [440, 330], [428, 290]]);
    R.dome(sm([[436, 330], [480, 334], [540, 326], [600, 330], [620, 350], [580, 366], [520, 384], [470, 396], [440, 380]]), '#9e9ea6', 0.12, 0.12, 16, 1);
    R.dome(PONCHO, null, 0.18, 0.14, 26, 1);
    clipA(PONCHO, () => img(ZEB));
    R.dome(sm([[452, 214], [480, 196], [500, 202], [490, 230], [460, 236]]), '#b8b8be', 0.3, 0.1, 10, 1);
    R.dome(sm([[580, 150], [620, 136], [664, 140], [686, 156], [690, 178], [670, 196], [630, 202], [596, 196]]), '#c8c8ce', 0.25, 0.14, 18, 2);
    R.bead(668, 172, 6, '#1a1214', 0.42, 0.04, 3); fill(circleP(668, 172, 2.4), '#e03030');
    R.dome(sm([[502, 216], [496, 170], [500, 128], [516, 104], [545, 94], [574, 104], [592, 128], [602, 170], [600, 216]]), '#a8aab0', 0.28, 0.16, 22, 2);
    R.dome(P([[537, 96], [545, 72], [553, 96]], true, false), '#c0c0c6', 0.35, 0.1, 4, 2);
    R.dome(rrect(510, 166, 84, 16, 5), '#7c7e86', 0.4, 0.04, 4, 2);
    R.dome(sm([[516, 186], [588, 186], [592, 218], [512, 218]]), '#8a8c94', 0.3, 0.06, 6, 2);
    R.bead(565, 199, 8, '#121014', 0.4, 0.04, 3);
    R.bead(543, 146, 26, '#d8d8de', 0.4, 0.12, 2);
    for (const [rr, c] of [[22, '#2a2a30'], [18, '#d0d0d6'], [14, '#202026'], [10, '#c8c8d0'], [6, '#141216']]) fill(circleP(543, 146, rr), c);
    fill(circleP(543, 146, 3), '#e03838');

    // ── cave interior ──
    R.flat(CAVE, null, 0, 0);
    clipA(CAVE, () => {
      img(STARS);
      // rubble: grey rocks packed into three zones
      const r = rng(11);
      for (const Z of [[[222, 770], [248, 704], [300, 652], [350, 600], [386, 552], [404, 600], [384, 650], [344, 690], [300, 724], [268, 766], [238, 800]],
        [[386, 560], [440, 584], [520, 594], [560, 586], [550, 630], [520, 650], [470, 646], [416, 640], [380, 620]],
        [[392, 470], [420, 420], [470, 392], [530, 376], [590, 354], [614, 366], [600, 392], [560, 404], [500, 412], [440, 440], [404, 490]],
        [[330, 640], [380, 600], [420, 640], [440, 670], [380, 690]]]) {
        const zp = poly(Z);
        for (let y = 340; y < 820; y += 15) for (let x = 210; x < 670; x += 15) {
          const cx = x + (r() - 0.5) * 8, cy = y + (r() - 0.5) * 8;
          if (!a.isPointInPath(zp, cx * S, cy * S)) continue;
          const s = 6 + r() * 5, n = 5 + (r() * 3 | 0), pts = [];
          for (let k = 0; k < n; k++) { const an = k / n * 6.283 + r() * 0.5, rr = s * (0.7 + r() * 0.5); pts.push([cx + Math.cos(an) * rr, cy + Math.sin(an) * rr]); }
          R.dome(poly(pts), mixHex('#6a6a72', '#dcdce2', 0.45 + r() * 0.5), 0.15, 0.05, 3, 1);
        }
      }
      for (let i = 0; i < 26; i++) { const x = 600 + r() * 60, y = 370 + r() * 160, s = 4 + r() * 6; R.dome(poly([[x - s, y], [x, y - s], [x + s, y + s * 0.3], [x - s * 0.2, y + s]]), '#c8c8d0', 0.15, 0.04, 2, 1); }
    });
    // oil-slick portal with serrated white rim
    const RIM = []; for (let k = 0; k < 96; k++) { const an = k / 96 * 6.283, rr = k % 2 ? 1.06 : 1; RIM.push([492 + Math.cos(an) * 134 * rr * Math.cos(-0.62) - Math.sin(an) * 70 * rr * Math.sin(-0.62), 492 + Math.cos(an) * 134 * rr * Math.sin(-0.62) + Math.sin(an) * 70 * rr * Math.cos(-0.62)]); }
    R.flat(poly(RIM), '#dcdce2', 0.12, 1);
    const SL = ellipseP(492, 492, 122, 58, -0.62);
    R.flat(SL, null, 0.12, 0);
    clipA(SL, () => img(SLICK));

    // ── hooded shark ghosts ──
    const ghost = (x, y, w, hb, mouthW, seed) => {
      const body = sm([[x - w * 0.5, y + hb], [x - w * 0.52, y + 20], [x - w * 0.46, y - 12], [x - w * 0.3, y - 34], [x, y - 44], [x + w * 0.3, y - 34], [x + w * 0.46, y - 12], [x + w * 0.52, y + 20], [x + w * 0.5, y + hb]]);
      R.dome(body, '#b2b2b8', 0.2, 0.22, w * 0.35, 1);
      R.pipe(P([[x - w * 0.48, y + 34], [x, y + 40], [x + w * 0.48, y + 34]], false), 7, '#b0b0b6', 0.4, 0.05, 1);
      R.dome(P([[x - 7, y - 40], [x, y - 70], [x + 7, y - 40]], true, false), '#c8c8d0', 0.42, 0.06, 4, 1);
      const M = ellipseP(x - 4, y + 8, mouthW * 0.5, mouthW * 0.28, 0);
      R.flat(M, '#0c0a0c', 0.3, 0);
      clipA(M, () => {
        for (let k = 0; k < 9; k++) {
          const tx = x - 4 - mouthW * 0.45 + k * mouthW * 0.11;
          fill(poly([[tx - 3.5, y + 8 - mouthW * 0.3], [tx + 3.5, y + 8 - mouthW * 0.3], [tx, y + 8 - mouthW * 0.05]]), '#ececf0');
          fill(poly([[tx - 3, y + 8 + mouthW * 0.3], [tx + 3, y + 8 + mouthW * 0.3], [tx + 1, y + 8 + mouthW * 0.06]]), '#ececf0');
        }
      });
      fill(ellipseP(x - mouthW * 0.28, y - 12, 5, 4, 0), '#2a2a30'); fill(ellipseP(x + mouthW * 0.2, y - 12, 5, 4, 0), '#2a2a30');
    };
    ghost(598, 546, 80, 160, 50, 1);
    ghost(512, 690, 78, 64, 52, 2);
    ghost(420, 708, 78, 76, 52, 3);
    ghost(330, 768, 78, 96, 54, 4);

    // ── black leopard spots and polka dots ──
    fill(SPOT, '#b4b7c6');
    R.flat(SPOT, null, 0, 0);
    const D = [[59, 397, 12, 12, 1.49], [14, 418, 12, 12, 1.25], [50, 465, 9, 9, 0.52], [710, 474, 13, 17, 0.26], [713, 549, 12, 33, 0.16], [14, 533, 10, 10, 0.55], [15, 579, 11, 11, 1.94], [721, 601, 5, 9, 0.12], [706, 650, 16, 25, 0.66], [28, 673, 10, 10, 0.27], [74, 706, 20, 20, 2.17], [717, 707, 8, 22, 3.02], [678, 731, 18, 41, 2.6], [597, 760, 23, 43, 1.03], [471, 778, 12, 20, 2.9], [675, 796, 14, 23, 2.3], [519, 798, 19, 24, 0.7], [426, 813, 15, 32, 0.14], [719, 817, 7, 34, 0.03], [615, 829, 29, 33, 0.52], [385, 822, 10, 22, 0.27], [183, 823, 11, 19, 1.46], [468, 829, 13, 16, 2.51], [545, 849, 18, 28, 0.24], [8, 844, 9, 10, 0.34], [673, 851, 15, 21, 0.78], [498, 872, 14, 25, 0.07], [342, 872, 19, 27, 0.26], [449, 889, 22, 31, 2.79], [131, 873, 10, 23, 2.0], [390, 878, 15, 26, 0.6], [582, 906, 18, 36, 2.74], [698, 906, 23, 39, 0.82], [43, 892, 14, 18, 2.77], [632, 899, 12, 20, 3.08], [293, 917, 18, 32, 2.79], [532, 949, 22, 37, 0.39], [7, 917, 8, 11, 0.05], [394, 944, 19, 33, 0.19], [233, 943, 19, 25, 0.94], [463, 957, 23, 42, 0.99], [342, 956, 18, 28, 0.1], [182, 967, 15, 34, 3.02], [638, 967, 20, 27, 2.06], [704, 990, 17, 36, 2.77], [259, 996, 22, 51, 1.17], [572, 999, 23, 33, 0.87], [140, 1008, 17, 27, 1.73], [389, 1012, 12, 23, 1.74], [327, 1014, 10, 21, 1.56], [501, 1014, 11, 18, 1.77], [635, 1018, 5, 33, 1.63], [78, 1018, 6, 13, 1.48], [446, 1018, 6, 18, 1.62]];
    D.forEach(([x, y, rx, ry, an], i) => fill(sm(blob(x, y, rx * 1.04, ry * 1.04, i + 3, 12, 0.1, an)), '#0e0c10'));
    // cave lip: black streak running off to the bottom-left
    fill(sm(lock([[230, 860], [196, 878], [168, 896], [140, 916], [112, 934], [86, 952], [60, 970], [34, 990], [8, 1004], [-10, 1014]], 26, 10)), '#0e0c10');
    { const r = rng(13); for (let i = 0; i < 9; i++) { const t = i / 8, x = 210 - t * 210, y = 868 + t * 140; fill(sm(blob(x, y + (r() - 0.5) * 6, 8 + r() * 8, 6 + r() * 6, 40 + i, 10, 0.2)), '#0e0c10'); } }
    fill(poly([[0, 990], [40, 990], [70, 1024], [0, 1024]]), '#141812');

    // ── shading ──
    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.5, ao: 0.6 }),        // 1 grey clay
        E.mat({ dif: 0.9, spec: 0.6, shin: 40, wrap: 0.3, metal: 0.3, coat: 0.15, ao: 0.4 }),  // 2 robot plastic
        E.mat({ dif: 1, spec: 1, shin: 80, coat: 0.3 }),                     // 3 black gloss
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.62, 0.62, 0.64], amb: [0.52, 0.52, 0.55],
      envTop: [0.95, 0.95, 0.97], envHor: [0.5, 0.5, 0.54], envBot: [0.12, 0.12, 0.14], envK: [0.2, 0.6, 0, 0],
      r1: 2, r2: 9, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.35, 8]
    });

    // ── after-light: gold cave rim, halo, glow streak, tree ──
    const LIP = P([[600, 344], [640, 348], [664, 362], [672, 420], [680, 480], [686, 540], [690, 600], [686, 650], [674, 684], [650, 708], [610, 728], [560, 743], [500, 758], [440, 776], [390, 794], [340, 812], [300, 831], [262, 850], [226, 862], [204, 852], [206, 826], [224, 800]], false);
    soft(x => stroke(LIP, 'rgba(225,235,255,0.9)', 26, x), 12, 0.8, 'screen', o);
    soft(x => stroke(LIP, '#a86a3a', 6, x), 2, 0.9, 'source-over', o);
    soft(x => stroke(LIP, '#ffe6c0', 2, x), 1, 0.8, 'source-over', o);
    // horizontal light streak
    soft(x => { x.fillStyle = 'rgba(200,220,255,0.75)'; x.fill(ellipseP(190, 548, 230, 16, 0)); }, 12, 1, 'screen', o);
    soft(x => { x.fillStyle = 'rgba(240,248,255,1)'; x.fill(ellipseP(200, 548, 200, 4, 0)); x.fill(ellipseP(390, 546, 30, 8, 0)); }, 3, 1, 'screen', o);
    soft(x => { x.fillStyle = 'rgba(230,240,255,0.8)'; x.fill(circleP(108, 345, 14)); }, 8, 0.8, 'screen', o);
    // dead tree
    { const r = rng(5);
      const br = (x, y, an, len, wd, d) => {
        if (d > 6 || len < 4) return;
        const x2 = x + Math.cos(an) * len, y2 = y + Math.sin(an) * len;
        stroke(P([[x, y], [x2, y2]], false), d < 2 ? '#6a3a2a' : '#8a5440', wd, o);
        const n = 2 + (r() < 0.4 ? 1 : 0);
        for (let k = 0; k < n; k++) br(x2, y2, an + (r() - 0.5) * 1.6, len * (0.62 + r() * 0.2), wd * 0.7, d + 1);
      };
      br(150, 330, -1.75, 34, 4, 0); br(150, 320, -2.5, 30, 3, 1); br(160, 300, -0.9, 30, 3, 1); br(215, 245, -1.2, 22, 3, 1); br(205, 255, -0.4, 26, 2.5, 1); }
    // coral tuft on the right
    { const r = rng(9); for (let i = 0; i < 60; i++) { const x = 690 + r() * 36, y = 300 + r() * 110; stroke(P([[x, y], [x + (r() - 0.5) * 10, y - 8 - r() * 10]], false), 'rgba(240,240,244,0.8)', 1.2, o); } }
    E.grain(0.04, 3);
  }
});
