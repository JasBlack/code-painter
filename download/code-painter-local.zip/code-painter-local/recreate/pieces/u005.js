'use strict';
// u005 — "Gilded night collage": a burnt-edged card of night sky — a blue-iris eye in a brown frame, a gold orb,
// a zebra sock, a gilded garlic bulb, a lime-yellow drop, gold drips, an orange swoosh and a lavender star trail.
REC.register('u005', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), open = pts => P(pts, false, true);
    const fill = (path, c) => { a.fillStyle = c; a.fill(path); };
    const stroke = (path, c, w) => { a.strokeStyle = c; a.lineWidth = w; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };

    // ── night sky with stars, and the burnt-edged card ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.03, .02, .02);
      vec2 g = floor(p / 4.), f = fract(p / 4.) - .5; float h = hash(g);
      c += step(.93, h) * smoothstep(.5, .1, length(f)) * (.3 + .6 * hash(g + 2.7));
      return c; }`));
    // rounded rectangle outline with a torn, wobbly edge
    const torn = (x0, y0, x1, y1, r, amp, f, seed) => {
      const pts = [], L = [[x0 + r, y0, 1, 0], [x1 - r, y0, 0, 0], [x1, y0 + r, 0, 1], [x1, y1 - r, 0, 0], [x1 - r, y1, -1, 0], [x0 + r, y1, 0, 0], [x0, y1 - r, 0, -1], [x0, y0 + r, 0, 0]];
      const cs = [[x1 - r, y0 + r, -Math.PI / 2], [x1 - r, y1 - r, 0], [x0 + r, y1 - r, Math.PI / 2], [x0 + r, y0 + r, Math.PI]];
      const side = (ax, ay, bx, by) => { const n = Math.ceil(Math.hypot(bx - ax, by - ay) / 5); for (let i = 0; i < n; i++) pts.push([ax + (bx - ax) * i / n, ay + (by - ay) * i / n]); };
      const corner = (cx, cy, a0) => { for (let i = 0; i < 12; i++) { const t = a0 + i / 12 * Math.PI / 2; pts.push([cx + Math.cos(t) * r, cy + Math.sin(t) * r]); } };
      side(x0 + r, y0, x1 - r, y0); corner(...cs[0]); side(x1, y0 + r, x1, y1 - r); corner(...cs[1]);
      side(x1 - r, y1, x0 + r, y1); corner(...cs[2]); side(x0, y1 - r, x0, y0 + r); corner(...cs[3]);
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      return pts.map(([x, y]) => { const d = Math.hypot(x - cx, y - cy), k = amp * ((noise2(x * f + seed, y * f) - 0.5) * 2 + (noise2(x * f * 4, y * f * 4 + seed) - 0.5) * 0.6);
        return [x + (x - cx) / d * k, y + (y - cy) / d * k]; });
    };
    const OUT = P(torn(2, 12, 724, 1014, 52, 7, 0.03, 3), true, false), IN = P(torn(15, 28, 711, 998, 48, 4, 0.04, 9), true, false);
    fill(OUT, '#e6dabc');
    soft(x => { x.strokeStyle = '#4a2a14'; x.lineWidth = 4; x.stroke(OUT); }, 1.5, 0.8);
    soft(x => { x.strokeStyle = '#3a2210'; x.lineWidth = 8; x.stroke(IN); }, 2.5, 0.9);

    clipA(IN, () => {
      fill(rrect(0, 0, 726, 1024, 0), '#070404');
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){
        vec3 c = vec3(.03, .02, .02);
        vec2 g = floor(p / 4.), f = fract(p / 4.) - .5; float h = hash(g + 9.);
        c += step(.93, h) * smoothstep(.5, .1, length(f)) * (.3 + .6 * hash(g + 2.7));
        return c; }`));
      const sr = rng(5);
      for (let i = 0; i < 150; i++) { const r = sr() < 0.85 ? 1.2 + sr() * 2 : 3 + sr() * 4; fill(circleP(20 + sr() * 690, 30 + sr() * 970, r), sr() < 0.7 ? '#fff8e8' : '#f0d898'); }

      // blue sky, top left
      const SKY = sm([[438, 28], [232, 28], [200, 45], [94, 36], [40, 60], [14, 98], [14, 350], [70, 328], [130, 292], [185, 242], [225, 186], [262, 142], [300, 112], [355, 106], [405, 86], [430, 60]]);
      fill(SKY, lin(14, 300, 430, 30, [[0, '#2c46b0'], [0.5, '#3462dc'], [1, '#3878ea']]));
      stroke(open([[14, 360], [80, 338], [140, 302], [192, 256], [228, 206], [256, 166], [290, 130], [320, 118]]), '#2c2cb0', 24);
      // dark goo blob with the pink ribbons
      fill(sm([[198, 132], [212, 106], [246, 96], [262, 72], [290, 76], [300, 100], [326, 112], [344, 136], [300, 152], [262, 150], [226, 150]]), '#0c0a1c');
      stroke(open([[18, 100], [36, 58], [90, 38], [160, 33], [218, 36]]), '#f08ab4', 10);
      stroke(open([[118, 56], [92, 62], [76, 80], [72, 108]]), '#f08ab4', 12);
      stroke(open([[96, 120], [150, 127], [210, 120], [262, 112]]), '#f08ab4', 18);
      stroke(open([[232, 162], [262, 140], [290, 122]]), '#f05aa0', 12);
      fill(sm([[276, 140], [292, 128], [312, 134], [316, 152], [298, 160], [280, 156]]), '#d8c8a0');
      // pines
      const pine = (x, y, w, hgt) => { const p = [[x, y]]; for (let k = 1; k <= 8; k++) { const t = k / 8; p.push([x + w * t * 0.5, y + hgt * t - 6], [x + w * t * 0.32, y + hgt * t]); }
        p.push([x + 3, y + hgt + 10], [x - 3, y + hgt + 10]); for (let k = 8; k >= 1; k--) { const t = k / 8; p.push([x - w * t * 0.32, y + hgt * t], [x - w * t * 0.5, y + hgt * t - 6]); } return poly(p); };
      fill(pine(94, 190, 74, 140), '#06060a'); fill(pine(36, 252, 52, 90), '#06060a');
      // top-right sky, tree and branch
      fill(sm([[520, 28], [690, 28], [708, 50], [700, 70], [600, 74], [540, 86]]), '#3a74e4');
      fill(pine(525, 26, 70, 70), '#06060a');
      stroke(open([[585, 72], [610, 52], [636, 34]]), '#3a2a24', 3); stroke(open([[648, 62], [660, 52], [690, 58]]), '#5a6a8a', 4);

      // lime grass sweep
      const GR = sm([[442, 28], [505, 28], [496, 62], [470, 92], [432, 116], [392, 132], [356, 140], [352, 124], [392, 100], [422, 66]]);
      fill(GR, '#c8e6a0');
      clipA(GR, () => { for (let i = 0; i < 26; i++) stroke(open([[350 + i * 7, 150], [380 + i * 7, 100], [430 + i * 6, 40]]), '#6a9a48', 1.4); });
      // grey rock with a black porthole
      const ROCK = sm([[712, 215], [655, 210], [550, 180], [520, 172], [440, 152], [450, 132], [534, 78], [662, 64], [700, 70], [712, 120]]);
      fill(ROCK, lin(450, 80, 700, 210, [[0, '#9a96a2'], [1, '#86828e']]));
      fill(circleP(674, 136, 40), '#050406');
      { const hr = rng(8); for (let i = 0; i < 12; i++) fill(circleP(650 + hr() * 50, 112 + hr() * 50, 1 + hr() * 1.5), '#f0f0f0'); }

      // big orange swoosh
      const SW = open([[612, 290], [628, 380], [642, 480], [646, 580], [630, 660], [596, 712], [540, 752], [480, 790], [450, 850], [400, 905], [330, 940], [250, 945], [160, 930], [120, 850], [100, 760], [100, 690], [112, 640], [96, 560], [90, 470], [88, 400]]);
      stroke(SW, '#e8441c', 46);
      stroke(open([[170, 940], [226, 944], [300, 934], [370, 916], [420, 898], [452, 864], [466, 830]]), '#e04018', 54);
      fill(ellipseP(310, 932, 66, 42, -0.15), '#e04018');

      // flowing wood hair on the right
      const HAIR = sm([[555, 222], [600, 226], [640, 222], [690, 230], [712, 225], [712, 690], [696, 740], [668, 800], [634, 870], [606, 930], [584, 990], [576, 986], [592, 910], [620, 830], [648, 750], [664, 690], [650, 600], [636, 520], [628, 450], [642, 400], [630, 350], [615, 300], [582, 282], [560, 260]]);
      fill(HAIR, '#c4a984');
      clipA(HAIR, () => { const hr = rng(21); for (let i = 0; i < 70; i++) { const x0 = 550 + hr() * 170, dx = -20 - hr() * 60; stroke(open([[x0, 220], [x0 + 6, 500], [x0 + dx * 0.6, 760], [x0 + dx, 1000]]), hr() < 0.5 ? 'rgba(110,80,56,0.8)' : 'rgba(236,224,200,0.8)', 0.8 + hr() * 1.4); } });
      soft(x => { x.fillStyle = lin(700, 690, 700, 880, [[0, '#f0e070'], [0.15, '#e8e4f0'], [1, '#d8d4ec']], x); x.fill(sm([[690, 690], [726, 680], [726, 890], [650, 880], [640, 800], [660, 740]])); }, 4);
      const TREE = []; { const tr = rng(77); for (let i = 0; i <= 22; i++) { const y = 812 + i * 9; TREE.push([660 - i * 2.6 + (i % 2 ? -16 : 6) * tr(), y]); } TREE.push([726, 1010], [726, 900], [700, 830]); }
      fill(poly(TREE), '#0a0c08');
      // wood plank
      const PL = sm([[440, 192], [480, 184], [540, 186], [600, 200], [642, 214], [650, 236], [600, 233], [540, 236], [470, 230], [452, 214]]);
      fill(PL, '#b09072');
      clipA(PL, () => { for (let i = 0; i < 9; i++) stroke(open([[440, 190 + i * 6], [540, 192 + i * 5.5], [650, 210 + i * 3]]), 'rgba(80,56,40,0.7)', 1.2); });
      stroke(open([[372, 186], [430, 182], [480, 186]]), '#5a4030', 8);
      // brown wood strip on the far left
      const LW = poly([[14, 352], [80, 332], [92, 390], [86, 462], [14, 470]]);
      fill(LW, '#6a3c2a'); clipA(LW, () => { for (let i = 0; i < 9; i++) stroke(open([[10 + i * 10, 470], [30 + i * 10, 400], [40 + i * 10, 330]]), '#3a1e14', 2); });
      // blue patches low left and the blue puddle at the bottom
      fill(sm([[10, 480], [40, 500], [60, 540], [40, 560], [10, 556]]), '#3a48b0');
      fill(sm([[18, 624], [32, 668], [28, 730], [16, 815], [12, 700]]), '#4a58c0');
      stroke(open([[232, 380], [228, 430], [236, 480]]), '#3040c0', 18);
      soft(x => { x.fillStyle = '#6194e6'; x.fill(sm([[64, 990], [87, 958], [123, 945], [167, 947], [224, 972], [228, 1005], [60, 1005]])); }, 3);

      // brown frame round the eye
      const FR = sm([[312, 318], [500, 312], [552, 328], [566, 480], [566, 640], [548, 660], [430, 708], [330, 746], [306, 730], [304, 540]]);
      stroke(FR, '#a0643e', 30);
      stroke(sm([[326, 334], [496, 330], [546, 344], [552, 480], [552, 630], [538, 646], [428, 692], [334, 728], [320, 720], [318, 540]]), 'rgba(220,235,245,0.85)', 2);
      // mauve haze
      soft(x => { x.fillStyle = rad(465, 548, 78, [[0, '#8a4a70'], [0.6, '#7a4868'], [1, 'rgba(90,70,110,0)'], ], x); x.fill(circleP(465, 548, 80)); }, 8);
      // the eye
      const EYE = sm([[338, 424], [370, 404], [404, 398], [440, 404], [470, 424], [440, 446], [404, 452], [370, 446]]);
      { const lr = rng(3); for (let i = 0; i < 70; i++) { const t = i / 70 * Math.PI * 2, x = 404 + Math.cos(t) * 64, y = 425 + Math.sin(t) * 26; stroke(open([[404 + Math.cos(t) * 58, 425 + Math.sin(t) * 22], [x + Math.cos(t) * 6, y + Math.sin(t) * 8]]), '#f4f0e0', 1.2); } }
      fill(EYE, '#f2e468');
      clipA(EYE, () => { fill(circleP(402, 424, 26), '#3a6ee0'); fill(circleP(402, 424, 18), '#4a86f0'); fill(circleP(398, 420, 7), '#060608'); });
      stroke(EYE, '#3a3020', 2);
      // grey fur tuft
      const FUR = sm([[520, 312], [548, 306], [576, 322], [586, 352], [576, 400], [562, 460], [554, 516], [540, 522], [530, 490], [520, 420], [514, 360]]);
      fill(FUR, '#b4b4bc'); clipA(FUR, () => { for (let i = 0; i < 40; i++) stroke(open([[512, 306 + i * 6], [530, 300 + i * 6.5], [550, 308 + i * 6], [580, 300 + i * 6.5]]), '#707078', 1); });
      // lavender star trail
      const TR = open([[628, 436], [614, 520], [606, 600], [596, 660], [560, 700], [510, 736], [462, 776], [404, 822], [334, 858], [274, 880]]);
      soft(x => { x.strokeStyle = '#7a6cd8'; x.lineWidth = 26; x.stroke(TR); }, 2, 0.95);
      { const pr = rng(12); for (let i = 0; i < 900; i++) { const t = pr(), k = Math.floor(t * 9), u = t * 9 - k; const p0 = [[628, 436], [614, 520], [606, 600], [596, 660], [560, 700], [510, 736], [462, 776], [404, 822], [334, 858], [274, 880]];
        const x = p0[k][0] + (p0[k + 1][0] - p0[k][0]) * u + (pr() - 0.5) * 34, y = p0[k][1] + (p0[k + 1][1] - p0[k][1]) * u + (pr() - 0.5) * 30; fill(circleP(x, y, 1 + pr() * 1.6), pr() < 0.5 ? '#a090f0' : '#4a3aa0'); } }

      // zebra sock
      const ZS = sm([[96, 396], [140, 410], [200, 404], [232, 394], [238, 470], [214, 504], [176, 524], [152, 566], [142, 624], [150, 664], [118, 642], [96, 600], [76, 556], [70, 520], [90, 480], [94, 440]]);
      fill(ZS, '#f4f2f0');
      clipA(ZS, () => { for (let i = -20; i < 30; i++) stroke(open([[40, 300 + i * 22], [140, 360 + i * 22], [260, 440 + i * 22]]), '#0a0808', 7.5); });
      // grey chain snake
      const SN = open([[6, 470], [40, 462], [80, 470], [110, 490], [130, 512], [148, 526]]);
      stroke(SN, '#4a6470', 20); stroke(SN, '#d0dde2', 15);
      { const cr = rng(2); for (let i = 0; i < 70; i++) { const t = i / 70, x = 6 + t * 142, y = 466 + t * 60 * t; fill(circleP(x, y - 4 + cr() * 8, 1.6), '#6a8088'); } }
      // pink tube
      stroke(open([[268, 288], [264, 400], [262, 512]]), '#f0a2c8', 30);
      stroke(open([[258, 300], [254, 400], [252, 500]]), 'rgba(255,230,240,0.8)', 5);
    });

    // ── glossy objects (relief) ──
    const ins = fn => { a.save(); R.h.save(); a.clip(IN); R.h.clip(IN); fn(); a.restore(); R.h.restore(); };
    ins(() => {
      // pale blue goo cloud
      const CLOUD = sm([[208, 227], [235, 244], [289, 240], [341, 222], [400, 218], [415, 225], [409, 238], [366, 249], [278, 250], [247, 262], [240, 270], [243, 297], [256, 322], [277, 319], [300, 291], [417, 282], [471, 270], [487, 259], [495, 243], [477, 233], [456, 218], [465, 198], [367, 202], [386, 175], [322, 172], [277, 181], [212, 195]]);
      R.dome(CLOUD, lin(200, 180, 480, 300, [[0, '#9cb4c8'], [0.5, '#b8cfe0'], [1, '#8aa6c0']]), 0.05, 0.12, 14, 2);
      R.dome(sm([[324, 172], [420, 166], [500, 172], [518, 182], [500, 186], [420, 184], [330, 182]]), '#f4f6f8', 0.2, 0.04, 4, 2);
      // gold orb
      R.dome(circleP(165, 338, 79), rad(140, 300, 120, [[0, '#fcf2dc'], [0.5, '#ecdcbc'], [1, '#bca482']]), 0.1, 0.3, 70, 5);
      { const gr = rng(31); for (let i = 0; i < 70; i++) { const t = gr() * 6.28, r = Math.sqrt(gr()) * 60; R.paint(circleP(165 + Math.cos(t) * r, 320 + Math.sin(t) * r * 0.8, 1 + gr() * 2), gr() < 0.5 ? '#6a5430' : '#f8f0d8'); } }
      R.paint(ellipseP(106, 384, 9, 6, 0.6), '#f8f070'); R.paint(ellipseP(214, 376, 8, 10, 0.3), '#f8f070');
      // gilded garlic bulb
      const GAR = sm([[255, 478], [230, 500], [190, 520], [160, 545], [145, 580], [143, 620], [155, 655], [185, 672], [250, 676], [310, 668], [338, 645], [342, 600], [330, 555], [300, 520], [270, 495]]);
      R.dome(GAR, lin(150, 500, 340, 670, [[0, '#fcf4e2'], [0.5, '#f0e4c8'], [1, '#d0bc98']]), 0.1, 0.25, 50, 5);
      for (let i = 0; i < 16; i++) { const t = (i + 0.5) / 16, xb = 150 + t * 188; R.groove(open([[252, 486], [252 + (xb - 252) * 0.6, 560], [xb, 640], [xb * 0.9 + 24, 664]]), 2, '#8a7050', 0.42, 0.04, 5, 0.8); }
      // lime-yellow drop
      const LEM = sm([[330, 665], [300, 700], [285, 740], [270, 800], [245, 860], [200, 905], [150, 925], [100, 930], [65, 935], [44, 942], [52, 924], [38, 898], [28, 850], [26, 800], [36, 760], [62, 720], [100, 690], [150, 670], [200, 662], [260, 655], [300, 655]]);
      R.dome(LEM, rad(140, 780, 200, [[0, '#f4f5c4'], [0.6, '#eef0b8'], [1, '#c4c88e']]), 0.08, 0.3, 60, 2);
      soft(x => { x.strokeStyle = '#ffffff'; x.lineWidth = 9; x.stroke(open([[232, 772], [212, 818], [186, 850], [158, 864]])); }, 1.2);
      R.dome(circleP(280, 676, 12), '#080606', 0.36, 0.02, 3, 2);
      // gold drip
      const DR = sm([[346, 560], [380, 554], [420, 578], [442, 620], [470, 640], [505, 640], [516, 654], [490, 668], [450, 672], [420, 692], [410, 724], [404, 772], [394, 778], [390, 728], [382, 734], [380, 800], [366, 806], [362, 742], [346, 722], [340, 680], [344, 620]]);
      R.dome(DR, lin(340, 560, 500, 800, [[0, '#c8b890'], [0.4, '#e4d8b8'], [0.7, '#a8946c'], [1, '#d8c8a0']]), 0.1, 0.18, 16, 3);
      // yellow ball, black ball and gold beads
      R.dome(circleP(532, 828, 66), '#fae25c', 0.1, 0.06, 10, 4);
      R.dome(circleP(612, 380, 38), '#0a0808', 0.1, 0.25, 30, 2);
      R.dome(circleP(604, 380, 11), '#f8f8f8', 0.36, 0.02, 4, 0);
      for (const [x, y, r] of [[580, 452, 9], [602, 456, 9], [602, 482, 9], [588, 550, 9], [626, 590, 10], [522, 616, 10], [510, 682, 10], [490, 735, 10], [520, 740, 8], [418, 822, 12], [324, 840, 12], [664, 480, 10], [640, 762, 7], [508, 912, 7]])
        R.bead(x, y, r, '#c8b080', 0.1, 0.25, 3);
      for (const [x, y0, y1] of [[546, 700, 752], [578, 698, 744], [458, 876, 950]]) { R.pipe(open([[x, y0], [x + 2, y1 - 8]]), 12, '#c0a878', 0.1, 0.15, 3); R.bead(x + 2, y1 - 6, 9, '#d8c8a0', 0.1, 0.2, 3); }
    });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.6, spec: 0.9, shin: 40, metal: 0.7, wrap: 0.3, ao: 0.3, coat: 0.15, tint: [1, 0.85, 0.6] }),   // 1 gold
        E.mat({ dif: 1, spec: 0.7, shin: 60, wrap: 0.5, ao: 0.2, coat: 0.12 }),                                     // 2 gloss
        E.mat({ dif: 0.8, spec: 0.8, shin: 50, metal: 0.4, wrap: 0.5, ao: 0.2, coat: 0.15, tint: [1, 0.95, 0.85] }), // 3 pale gold
        E.mat({ dif: 1, spec: 0.3, shin: 30, wrap: 0.8, emis: 0.15 }),                                               // 4 flat paint ball
        E.mat({ dif: 0.9, spec: 0.7, shin: 30, metal: 0.15, wrap: 0.7, ao: 0.3, coat: 0.1, tint: [1, 0.92, 0.75] }),  // 5 pale gold leaf
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.5, 0.5],
      envTop: [1, 0.97, 0.9], envHor: [0.6, 0.55, 0.5], envBot: [0.1, 0.08, 0.06], envK: [0.4, 1.0, 0, 0],
      r1: 3, r2: 9, k: [0, 0.6, 0.4, 90], shadow: [-4, 6, 0.4, 8]
    });
    E.grain(0.04, 5);
  }
});
