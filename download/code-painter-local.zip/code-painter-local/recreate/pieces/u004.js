'use strict';
// u004 — "Clay ram-horn cyclops": a puffy white clay head with a segmented ram's-horn crest and an ammonite
// spiral round a chrome eye, gold, mint and violet paint on black gloss, over a zebra floor in a streaked starfield.
REC.register('u004', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const hfx = (body, m) => E.fx(`${body}
      vec3 fx(vec2 uv, vec2 p){ float h = clamp(hgt(p), 0., 1.) * 255.; return vec3(floor(h) / 255., ${(m * 32 / 255).toFixed(5)}, fract(h)); }`);

    // ── streaked starfield ──
    img(E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = vec3(.035, .03, .03);
        vec2 g = floor(p / 5.), f = fract(p / 5.) - .5; float h = hash(g);
        vec2 o = vec2(hash(g + 3.1), hash(g + 7.7)) - .5;
        c += step(.9, h) * smoothstep(.55, .1, length(f - o * .5)) * (.35 + .6 * hash(g + 1.3));
        vec2 d = vec2(.966, -.259), n = vec2(.259, .966);
        float u = dot(p, d), v = dot(p, n), row = floor(v / 26.), rv = fract(v / 26.) * 26. - 13. - (hash(vec2(row, 4.)) - .5) * 16.;
        float cu = floor((u + hash(vec2(row, 9.)) * 400.) / 150.), fu = fract((u + hash(vec2(row, 9.)) * 400.) / 150.);
        float on = step(.5, hash(vec2(row, cu))), len = .3 + .6 * hash(vec2(cu, row + 2.));
        float seg = smoothstep(0., .05, fu) * smoothstep(len, len - .3, fu);
        c += on * seg * smoothstep(1.3, .2, abs(rv)) * vec3(.85, .82, .8) * (.4 + .6 * hash(vec2(cu + 5., row)));
        c += vec3(.12, .26, .14) * exp(-pow((p.x - 345.) / 22., 2.)) * smoothstep(170., 0., p.y);
        return c; }`));
    // nebula wisps and the rainbow oval at the top
    soft(x => { x.fillStyle = 'rgba(150,145,140,0.5)'; x.fill(ellipseP(70, 6, 95, 24, 0.05)); }, 10, 0.8);
    soft(x => { x.fillStyle = lin(600, 20, 726, 20, [[0, '#7c8a96'], [0.4, '#d0a0d8'], [0.6, '#5a8af0'], [0.8, '#f0e060'], [1, '#f04040']], x); x.fill(ellipseP(662, 26, 66, 30, -0.15)); }, 5, 0.9);

    // ── left rainbow arc and gold band ──
    const arc = (r, col, wd, blur, al) => soft(x => { x.strokeStyle = col; x.lineWidth = wd; x.beginPath(); x.arc(420, 520, r, Math.PI * 0.93, Math.PI * 1.27); x.stroke(); }, blur, al);
    arc(410, '#e83a1a', 22, 6, 0.9); arc(404, '#f4a020', 12, 3, 1); arc(398, '#fff2c8', 8, 1.5, 1);
    R.flat(sm([[86, 436], [53, 520], [15, 592], [0, 611], [0, 652], [43, 582], [101, 470], [95, 447]]), '#da9c44', 0.02, 4);
    R.flat(poly([[75, 303], [0, 450], [0, 458], [80, 310]]), '#d89a46', 0.02, 4);

    // ── right rainbow sheet with yellow-green streaks ──
    const RB = sm([[668, 520], [726, 500], [726, 925], [596, 925], [606, 860], [626, 760], [650, 650]]);
    clipAH(RB, () => {
      a.fillStyle = lin(560, 760, 726, 700, [[0, '#f8f0f0'], [0.12, '#e050c8'], [0.3, '#5a50e8'], [0.42, '#f8f6f4'], [0.55, '#f8e048'], [0.68, '#f07a20'], [0.82, '#e034b8'], [1, '#4a48e0']]); a.fill(RB);
      const SG = sm([[648, 690], [690, 700], [726, 730], [726, 925], [700, 925], [655, 860], [632, 780]]);
      a.fillStyle = '#b4c88c'; a.fill(SG);
      const sr = rng(44); a.lineWidth = 1.6;
      for (let i = 0; i < 90; i++) { const x0 = 630 + sr() * 100, y0 = 640 + sr() * 280; a.strokeStyle = ['#e8f070', '#3a8a50', '#f8f8e0', '#6ab0c0', '#d8b040'][i % 5]; a.beginPath(); a.moveTo(x0, y0); a.lineTo(x0 + 16, y0 + 50); a.stroke(); }
    });

    // ── glowing stars and little planets ──
    for (const [x, y, r] of [[95, 122, 10], [618, 163, 17], [525, 86, 10], [40, 318, 15], [705, 232, 10], [700, 372, 17], [77, 558, 10], [107, 682, 12], [43, 737, 17], [38, 838, 10], [12, 555, 5], [228, 97, 6]]) {
      soft(x2 => { x2.fillStyle = 'rgba(255,210,170,0.5)'; x2.fill(circleP(x, y, r * 1.45)); }, r * 0.45, 0.9);
      a.fillStyle = rad(x, y, r, [[0, '#fffaf2'], [0.75, '#f8ecdc'], [1, '#e8c8a8']]); a.fill(circleP(x, y, r));
    }
    for (const [x, y, r] of [[60, 213, 17], [124, 172, 12], [700, 595, 10], [640, 884, 8]]) {
      soft(x2 => { x2.fillStyle = 'rgba(255,240,220,0.8)'; x2.fill(circleP(x, y, r * 1.6)); }, r * 0.6, 0.8);
      a.fillStyle = rad(x - r * 0.3, y - r * 0.3, r * 1.3, [[0, '#f0f8ff'], [0.4, '#40a0e0'], [0.7, '#e8b860'], [1, '#2050a0']]); a.fill(circleP(x, y, r));
    }

    // ── zebra floor (fitted stripe phases) ──
    const ZB = `const float ZBC[209] = float[209](-11.857,-10.461,-9.197,-8.199,-7.482,-7.093,-6.876,-6.934,-6.650,-6.047,-5.342,-4.690,-4.084,-3.340,-2.380,-1.366,-0.457,0.311,1.004,-11.629,-10.201,-8.789,-7.581,-6.817,-6.319,-6.074,-4.819,-4.663,-3.685,-3.229,-2.730,-2.200,-1.822,-1.517,-1.295,-1.113,-0.921,-0.707,-11.266,-9.945,-8.497,-6.924,-6.353,-5.285,-6.001,-2.063,-2.480,-1.382,-1.275,-0.947,-0.190,0.004,-0.583,-1.284,-1.785,-2.036,-2.157,-10.617,-9.522,-8.397,-6.607,-6.131,-4.514,-4.504,-4.108,-1.428,-1.041,0.204,0.724,1.808,2.515,0.444,-1.324,-2.351,-2.778,-2.937,-9.653,-8.646,-7.392,-6.285,-5.502,-4.314,-2.878,-2.932,-1.564,-0.388,0.454,1.339,2.515,5.164,1.913,-1.091,-2.402,-2.718,-2.675,-8.372,-7.632,-6.408,-6.253,-4.993,-4.036,-2.569,-1.721,-1.350,0.065,0.913,3.071,1.917,5.152,5.315,0.245,-1.282,-1.371,-1.190,-7.019,-6.307,-5.721,-5.091,-4.538,-3.085,-2.011,-0.376,0.366,1.082,2.747,0.816,3.593,5.159,3.715,1.742,1.606,1.513,1.430,-5.924,-5.520,-4.790,-4.081,-3.103,-2.591,-1.296,-0.472,0.557,0.867,0.951,3.449,2.618,4.730,6.782,6.846,5.896,5.284,4.933,-4.537,-4.497,-3.897,-3.133,-2.534,-1.579,-0.976,0.029,0.853,1.970,3.114,3.120,5.638,3.544,6.480,9.233,9.389,9.209,9.190,-3.749,-3.513,-2.996,-2.296,-1.372,-1.050,-0.267,0.414,1.242,1.814,2.690,4.130,4.520,6.716,3.835,8.689,11.188,12.645,13.939,-2.877,-2.426,-2.084,-1.706,-1.408,-1.151,0.004,1.194,2.314,4.076,4.162,4.102,4.661,7.450,6.973,8.718,12.019,15.516,18.835);
float zb(vec2 p){ vec2 u = clamp((p - vec2(0.0, 770.0)) / vec2(40.0000, 31.7500), vec2(0.), vec2(15.999, 7.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZBC[(i.y + b) * 19 + i.x + a] * bx[a] * by[b];
  return f; }`;
    const ZEB = sm([[0, 885], [60, 862], [120, 822], [200, 798], [300, 792], [400, 786], [460, 800], [500, 838], [522, 880], [560, 920], [600, 925], [600, 1030], [0, 1030]]);
    const zcol = E.fx(`${ZB}
      vec3 fx(vec2 uv, vec2 p){ float v = cos(6.2832 * zb(p)); float s = smoothstep(-.15, .15, v);
        float gl = .12 * smoothstep(.55, .8, fbm(p * vec2(.02, .05)));
        return mix(vec3(.06, .055, .06) + gl, vec3(.88, .85, .82), s); }`);
    const zh = hfx(`${ZB}
      float hgt(vec2 p){ float v = cos(6.2832 * zb(p)); return 0.04 + 0.004 * smoothstep(-.2, .3, v) + .05 * fbm(p * vec2(.012, .006)); }`, 6);
    clipAH(ZEB, () => { img(zcol); img(zh, R.h); });
    soft(x => { x.fillStyle = 'rgba(255,240,200,0.85)'; x.fill(ellipseP(360, 796, 110, 16, -0.05)); }, 12);
    // floor checker at the bottom right
    const FL = poly([[560, 925], [726, 912], [726, 1030], [560, 1030]]);
    clipAH(FL, () => {
      R.flat(FL, '#0c0a0c', 0.02, 2);
      for (let i = -6; i < 10; i++) R.flat(poly([[560 + i * 34, 925], [578 + i * 34, 925], [638 + i * 34, 1030], [620 + i * 34, 1030]]), '#dcd6d0', 0.025, 2);
    });
    // white clay blobs on the left of the floor
    R.dome(sm([[-10, 838], [30, 842], [55, 858], [62, 884], [44, 902], [-10, 906]]), '#d6d0cc', 0.06, 0.1, 14, 1);

    // ── black gloss body ──
    const BODY = sm([[545, 280], [580, 300], [600, 340], [610, 390], [625, 440], [630, 500], [622, 560], [618, 615], [640, 648], [655, 690], [650, 740], [628, 800], [612, 860], [600, 925], [578, 940], [550, 912], [522, 875], [512, 845], [470, 828], [440, 800], [396, 778], [350, 762], [315, 728], [290, 700], [275, 670], [290, 620], [400, 610], [480, 598], [510, 550], [528, 480], [520, 440], [575, 450], [590, 420], [585, 360], [565, 320]]);
    R.dome(BODY, '#141012', 0.08, 0.2, 30, 2);
    // creases and glossy folds
    clipAH(BODY, () => {
      for (const c of [[[600, 600], [575, 680], [560, 760], [570, 840]], [[520, 720], [470, 760], [430, 790]], [[640, 660], [620, 720], [600, 790]], [[555, 300], [585, 360], [600, 420]]])
        R.pipe(P(c, false), 18, '#1e1a1c', 0.2, 0.1, 2);
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = step(.88, hash(floor(p / 1.2))) * smoothstep(.5, .75, fbm(p * .012));
        return vec3(s * .5); }`), a);
    });
    // white clay feet
    R.dome(sm([[528, 878], [556, 880], [562, 920], [576, 940], [640, 940], [690, 950], [702, 968], [690, 984], [620, 988], [560, 992], [500, 990], [482, 972], [500, 950], [522, 940], [526, 905]]), '#d8d2ce', 0.1, 0.12, 16, 1);
    // violet speckle cloud spilling down-right of the eye
    const VC = sm([[505, 468], [532, 478], [556, 512], [578, 552], [566, 596], [530, 618], [470, 616], [440, 606], [470, 590], [498, 560], [508, 520]]);
    soft(x => { x.fillStyle = '#7840c8'; x.fill(VC); }, 2, 0.95);
    clipAH(VC, () => { const vr = rng(19); for (let i = 0; i < 700; i++) { a.fillStyle = vr() < 0.6 ? '#4a2090' : '#b498f0'; a.fillRect(440 + vr() * 140, 468 + vr() * 150, 1.6, 1.6); } });
    // white tree silhouettes in the dark under the face
    { const tr = rng(23); for (let i = 0; i < 14; i++) { const x = 236 + tr() * 100, y = 650 + tr() * 90, h = 14 + tr() * 22, pts = [[x, y]];
      for (let k = 1; k <= 5; k++) { const w = k / 5 * h * 0.35; pts.push([x + w, y + k / 5 * h - 2], [x + w * 0.4, y + k / 5 * h]); }
      for (let k = 5; k >= 1; k--) { const w = k / 5 * h * 0.35; pts.push([x - w * 0.4, y + k / 5 * h], [x - w, y + k / 5 * h - 2]); }
      R.paint(P(pts, true, false), 'rgba(214,208,204,0.7)'); } }
    // mint green mouth
    R.dome(sm([[332, 635], [354, 652], [365, 670], [401, 688], [452, 703], [516, 716], [547, 710], [560, 697], [545, 670], [505, 647], [476, 640], [446, 625], [400, 629], [345, 625]]), '#46ec82', 0.22, 0.03, 6, 5);

    // ── gold paint behind the head ──
    const GA = sm([[354, 214], [404, 263], [411, 281], [407, 304], [434, 330], [475, 357], [504, 399], [524, 434], [560, 443], [582, 430], [582, 374], [575, 336], [548, 296], [493, 243], [465, 231], [399, 213]]);
    R.flat(GA, '#dc9e40', 0.1, 4);
    R.flat(sm([[150, 657], [136, 695], [165, 696], [176, 714], [174, 740], [188, 732], [213, 740], [213, 762], [231, 762], [233, 755], [221, 715], [199, 702], [185, 684]]), '#dca446', 0.06, 4);
    R.flat(sm([[124, 723], [81, 821], [119, 805], [140, 772], [138, 754]]), '#dca446', 0.06, 4);

    // ── white clay face plate ──
    const clay = '#dad1cd';
    const FACE = sm([[150, 240], [230, 222], [300, 208], [350, 215], [395, 250], [408, 300], [440, 335], [480, 365], [518, 440], [528, 490], [518, 545], [500, 562], [478, 598], [440, 606], [385, 607], [330, 612], [292, 618], [280, 650], [262, 680], [238, 712], [180, 680], [142, 644], [122, 600], [124, 576], [148, 562], [135, 510], [112, 470], [100, 420], [90, 380], [100, 330]]);
    soft(x => { x.strokeStyle = 'rgba(240,170,110,0.9)'; x.lineWidth = 10; x.stroke(FACE); }, 6, 0.8);
    R.dome(FACE, clay, 0.12, 0.1, 22, 1);
    // lower clay mass with the hollow dot
    const LOW = sm([[236, 712], [280, 736], [320, 752], [350, 766], [390, 778], [400, 795], [130, 798], [140, 762], [126, 716], [140, 700], [166, 702], [175, 742], [196, 732], [212, 768], [228, 766]]);
    R.dome(LOW, clay, 0.1, 0.08, 14, 1);
    R.dome(sm([[133, 700], [163, 700], [172, 716], [170, 748], [150, 762], [134, 740], [128, 716]]), clay, 0.14, 0.08, 10, 1);
    R.dome(circleP(150, 716, 12), '#0c0a0a', 0.1, -0.06, 6, 2);
    // finger-like lobe at the left edge
    R.dome(sm([[150, 560], [124, 576], [120, 600], [136, 622], [152, 612], [160, 585]]), clay, 0.2, 0.06, 10, 1);

    // ── ammonite spiral disc ──
    const CX = 384, CY = 470;
    soft(x => { x.fillStyle = 'rgba(60,50,50,0.6)'; x.fill(circleP(CX + 6, CY + 10, 146)); }, 10, 0.5);
    R.dome(circleP(CX, CY, 144), clay, 0.2, 0.06, 12, 1);
    for (let i = 0; i < 22; i++) {
      const t = i / 22 * Math.PI * 2 - 0.3, x = CX + Math.cos(t) * 116, y = CY + Math.sin(t) * 114;
      R.dome(ellipseP(x, y, 30, 17, t), mixHex(clay, '#cec5c2', (i % 3) * 0.2), 0.22, 0.06, 14, 1);
    }
    for (let i = 0; i < 16; i++) {
      const t = i / 16 * Math.PI * 2 + 0.2, x = CX + 14 + Math.cos(t) * 74, y = CY + 6 + Math.sin(t) * 72;
      R.dome(ellipseP(x, y, 22, 14, t), clay, 0.25, 0.06, 12, 1);
    }
    R.dome(circleP(CX + 26, CY + 14, 54), clay, 0.28, 0.05, 10, 1);
    // violet speckled halo round the eye
    const HALO = new Path2D(); HALO.addPath(circleP(414, 484, 72)); HALO.addPath(circleP(414, 484, 47));
    clipAH(circleP(414, 484, 74), () => {
      a.save(); a.clip(HALO, 'evenodd');
      const vr = rng(9); a.fillStyle = '#7a42c8'; a.fill(circleP(414, 484, 74));
      for (let i = 0; i < 1500; i++) { const t = vr() * 6.283, rr = 44 + vr() * 32; a.fillStyle = vr() < 0.7 ? '#5a28b0' : '#a080e8'; a.fillRect(414 + Math.cos(t) * rr, 484 + Math.sin(t) * rr, 1.8, 1.8); }
      a.restore();
    });
    // white fringe under the eye
    { const fr = rng(17); for (let i = 0; i < 26; i++) { const x = 380 + i * 2.4 + fr() * 2, L = 50 + fr() * 45; R.pipe(P([[x, 512], [x + (fr() - 0.5) * 6, 512 + L * 0.5], [x + (fr() - 0.5) * 8, 512 + L]], false), 3, i % 4 ? '#ece6ea' : '#b8a8e0', 0.36, 0.03, 1); } }
    // chrome eye button
    R.dome(circleP(410, 485, 40), '#4a4848', 0.34, 0.06, 6, 3);
    for (let i = 0; i < 36; i++) { const t = i / 36 * Math.PI * 2; R.bead(410 + Math.cos(t) * 36, 485 + Math.sin(t) * 36, 2.6, '#c8c0b8', 0.4, 0.03, 3); }
    R.dome(circleP(410, 485, 30), rad(400, 472, 40, [[0, '#a8a8b0'], [1, '#3a3a40']]), 0.4, 0.08, 14, 3);
    R.dome(circleP(410, 486, 13), '#202024', 0.42, 0.04, 5, 3);
    R.dome(circleP(410, 486, 6), '#060606', 0.38, 0.01, 3, 2);

    // ── segmented ram's-horn crest ──
    const CL = [[178, 252], [215, 215], [265, 190], [320, 175], [380, 170], [440, 178], [495, 198], [545, 228], [588, 265], [622, 310], [645, 365], [657, 425], [660, 490], [657, 555], [652, 610], [656, 652]];
    const outerRing = P(lock(CL, 60, 58), true, true);
    soft(x => { x.strokeStyle = 'rgba(250,170,100,0.95)'; x.lineWidth = 16; x.stroke(outerRing); }, 8, 0.85);
    // resample the centreline and stack puffy lobes along it
    const pts = []; { const pc = P(CL, false); for (let i = 0; i < CL.length - 1; i++) for (let k = 0; k < 8; k++) { const t = k / 8, p0 = CL[i], p1 = CL[i + 1]; pts.push([p0[0] + (p1[0] - p0[0]) * t, p0[1] + (p1[1] - p0[1]) * t]); } pts.push(CL[CL.length - 1]); }
    let acc = 0, last = pts[0]; const lobes = [pts[0]];
    for (const p of pts) { acc += Math.hypot(p[0] - last[0], p[1] - last[1]); last = p; if (acc >= 44) { lobes.push(p); acc = 0; } }
    R.dome(outerRing, clay, 0.18, 0.08, 16, 1);
    lobes.forEach((p, i) => {
      const q = lobes[Math.min(lobes.length - 1, i + 1)], o = lobes[Math.max(0, i - 1)], ang = Math.atan2(q[1] - o[1], q[0] - o[0]);
      R.dome(ellipseP(p[0], p[1], 27, 30, ang), mixHex(clay, '#e4ddd8', (i % 2) * 0.5), 0.22, 0.07, 26, 1);
    });

    // ── visor band, gloss block and chrome nozzle ──
    const VIS = poly([[72, 348], [110, 312], [160, 283], [215, 255], [268, 232], [276, 248], [240, 274], [212, 302], [200, 340], [150, 358], [112, 385], [96, 390]]);
    R.dome(VIS, '#3a363c', 0.32, 0.03, 4, 2);
    R.pipe(P([[74, 346], [112, 310], [162, 281], [216, 253], [268, 232]], false), 3, '#e8e4e8', 0.36, 0.02, 2);
    R.dome(sm([[110, 386], [150, 360], [200, 344], [206, 382], [196, 420], [176, 446], [140, 452], [118, 436]]), '#0e0c0e', 0.3, 0.1, 14, 2);
    R.dome(sm([[116, 392], [152, 384], [160, 414], [154, 446], [118, 450], [108, 420]]), lin(110, 390, 150, 450, [[0, '#f4f4f8'], [0.45, '#8a8a94'], [0.7, '#c8c8d0'], [1, '#f0f0f4']]), 0.38, 0.08, 10, 3);
    R.dome(ellipseP(124, 432, 9, 7, 0.3), '#c82020', 0.44, 0.02, 3, 5);
    R.dome(poly([[86, 422], [116, 404], [122, 434], [98, 432]]), lin(90, 410, 120, 434, [[0, '#d8d8de'], [1, '#606068']]), 0.44, 0.04, 5, 3);

    // ── little marks on the face ──
    const ink = '#141012';
    for (const [x0, y0, x1, y1] of [[218, 326], [230, 322], [242, 320]].map(([x, y]) => [x, y, x + 3, y + 16])) R.groove(P([[x0, y0], [x1, y1]], false), 4, ink, 0.22, 0.04, 1, 1);
    R.groove(P([[256, 330], [290, 320]], false), 4, ink, 0.22, 0.04, 1, 1);
    R.groove(P([[184, 422], [188, 442]], false), 4, ink, 0.22, 0.04, 1, 1); R.groove(P([[194, 420], [198, 440]], false), 4, ink, 0.22, 0.04, 1, 1);
    for (const [x, y, r] of [[215, 383, 11], [183, 482, 7], [215, 580, 9], [342, 302, 10]]) R.dome(circleP(x, y, r), ink, 0.16, -0.05, 4, 2);
    R.groove(P([[345, 296], [356, 290]], false), 3, ink, 0.22, 0.03, 1, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.18, shin: 14, wrap: 0.55, ao: 0.5, coat: 0.03 }),              // 1 white clay
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.2, ao: 0.3, coat: 0.6 }),                 // 2 black gloss
        E.mat({ dif: 0.5, spec: 1.2, shin: 90, metal: 0.8, ao: 0.2, coat: 0.3 }),              // 3 chrome
        E.mat({ dif: 1, spec: 0.3, shin: 40, wrap: 0.5, emis: 0.1 }),                          // 4 gold paint
        E.mat({ dif: 1, spec: 0.6, shin: 50, wrap: 0.6, emis: 0.2, coat: 0.1 }),               // 5 green / red gloss
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.4, ao: 0.2, coat: 0.3, bump: 0.6 }),      // 6 glossy zebra fabric
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.48, 0.48],
      envTop: [0.95, 0.95, 0.95], envHor: [0.5, 0.48, 0.5], envBot: [0.05, 0.05, 0.05], envK: [0.4, 1.0, 0, 0],
      r1: 3, r2: 9, k: [0, 0.6, 0.4, 110], shadow: [-5, 7, 0.5, 8]
    });
    E.grain(0.03, 4);
  }
});
