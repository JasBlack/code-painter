'use strict';
// s18 — "Liquid gold grin": a molten gold / chrome relief — a row of capsule
// teeth, fangs and cross-shaped lumps — with pools of glossy blue enamel,
// reflecting a warm studio; the lower-left drifts out of focus.
REC.register('s18', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h;
    const rad = (x, y, r, c, al = 1, sx = 1, sy = 1, rot = 0) => {
      a.save(); a.translate(x, y); a.rotate(rot); a.scale(sx, sy);
      const g = a.createRadialGradient(0, 0, 0, 0, 0, r); g.addColorStop(0, rgbaHex(c, al)); g.addColorStop(0.55, rgbaHex(c, al * 0.75)); g.addColorStop(1, rgbaHex(c, 0));
      a.fillStyle = g; a.fillRect(-r, -r, 2 * r, 2 * r); a.restore();
    };
    // ── reflection map (albedo) : warm cream base with soft tonal masses ──
    a.fillStyle = '#a89a80'; a.fillRect(0, 0, 1024, 1024);
    hx.fillStyle = hc(0.05, 1); hx.fillRect(0, 0, 1024, 1024);
    const blobs = [
      // blues / blue-greys
      [60, 70, 110, '#5f80b0'], [60, 200, 70, '#6a7c98'], [450, 60, 70, '#7a93bb'], [200, 580, 110, '#98bce0', 1, 1, 0.9], [120, 470, 60, '#9cb6d4', 0.8],
      [200, 720, 90, '#bcc4d2'], [60, 830, 90, '#b0b0b8'], [450, 820, 120, '#4e6a88', 1, 1.3, 0.6], [330, 760, 70, '#8aa8cc', 0.9], [30, 880, 50, '#9ab8dc', 0.7],
      [700, 200, 70, '#34466c'], [960, 1010, 70, '#4a68a8'],
      // dark / brown masses
      [190, 60, 80, '#34384a'], [570, 200, 70, '#474941'], [830, 190, 90, '#5a3a28', 1, 1.4, 0.8], [960, 200, 80, '#9a541f', 0.9], [900, 120, 90, '#3a2518', 1, 1.5, 0.6, -0.1],
      [64, 460, 70, '#7a523d'], [320, 450, 70, '#6a5038'], [700, 450, 70, '#84643d'], [40, 560, 50, '#3c2014'], [60, 660, 90, '#8a6048', 1, 1, 1.2],
      [420, 600, 100, '#5a4430', 1, 1.3, 0.55, 0.45], [960, 580, 80, '#553524'], [880, 620, 60, '#2e2219'], [832, 700, 70, '#7a5238'],
      [700, 830, 80, '#664530'], [832, 830, 80, '#5e5950'], [330, 930, 80, '#8e4b25'], [460, 960, 90, '#6a4030'], [960, 900, 70, '#5c4738'], [380, 250, 60, '#6a5036'],
      // creams / silvers
      [320, 70, 70, '#e2d2af'], [330, 140, 50, '#f0e2c4'], [180, 300, 60, '#d6c4a6'], [40, 290, 50, '#cac6bc'], [200, 450, 60, '#c8b5a4'],
      [560, 440, 150, '#d8ccb0', 1, 1.4, 0.7, 0.3], [690, 520, 90, '#d6ceb8'], [832, 420, 90, '#bcbcb4', 1, 0.8, 1.3], [960, 60, 70, '#c9c1b3'], [950, 500, 50, '#b8b8b0'],
      [600, 760, 80, '#3c2d21', 0.9], [700, 740, 70, '#54402c', 0.9], [960, 710, 60, '#ac7e56'], [100, 1000, 80, '#d8d8d6'],
      // golds
      [80, 960, 90, '#e0c18e', 1, 1.2, 0.8], [200, 950, 80, '#ddccb4'], [200, 840, 70, '#bda27d'], [150, 900, 60, '#d8a848', 0.8], [650, 860, 50, '#c8a060', 0.7]];
    blobs.push([200, 560, 120, '#8cb8f0', 1, 1.15, 0.95], [150, 200, 90, '#4a74b8', 1, 1, 1.3], [30, 40, 60, '#6090d0'],
      [420, 940, 140, '#5a3420', 1, 1.4, 0.7], [620, 780, 90, '#3c2d21', 0.8, 1.5, 0.5], [880, 780, 110, '#6a4a2a', 0.9, 1, 1.3], [980, 640, 70, '#a06030', 0.8],
      [60, 600, 70, '#70472f'], [40, 800, 70, '#b2bed1'], [250, 790, 60, '#b9bdc8'],
      [900, 60, 100, '#3a2a20'], [830, 210, 80, '#4a3020'], [300, 180, 120, '#d8d4cc', 0.8], [450, 210, 80, '#c8c4bc', 0.7], [100, 400, 110, '#6a4c38', 0.8],
      [150, 650, 100, '#c0a890', 0.7], [900, 640, 100, '#4a3424', 0.9], [880, 420, 90, '#5a4830', 0.7]);
    for (const b of blobs) rad(...b);

    // ── relief ──
    const GOLD = '#d8c8a8', OR = '#c87a22';
    const rim = (path, w = 10) => { a.save(); a.lineJoin = 'round'; a.strokeStyle = OR; a.lineWidth = w; a.stroke(path); a.restore(); };
    const lump = (path, h0, dh, wd, col = GOLD, m = 1) => { if (col) { a.save(); a.fillStyle = col; a.globalAlpha = 0.55; a.fill(path); a.restore(); } rim(path); R.dome(path, null, h0, dh, wd, m); };
    const tube = (pts, w, h0 = 0.08, dh = 0.1, col = '#cfc6b4') => { const p = P(pts, false); a.save(); a.lineCap = a.lineJoin = 'round'; a.strokeStyle = OR; a.globalAlpha = 0.7; a.lineWidth = w; a.stroke(p); a.strokeStyle = col; a.globalAlpha = 0.75; a.lineWidth = w * 0.7; a.stroke(p); a.restore(); R.pipe(p, w, null, h0, dh, 1); };

    // top-left gold tubes and arm
    tube([[-20, 400], [80, 375], [180, 345], [260, 322], [320, 306]], 110, 0.06, 0.1, '#c8bca8');
    tube([[170, 150], [172, 200], [180, 250], [200, 280]], 70, 0.08, 0.1, '#e8dcc8');
    tube([[250, -20], [264, 60], [270, 140], [250, 220], [230, 262], [300, 300], [400, 322], [470, 300]], 56, 0.07, 0.12, '#b89878');
    tube([[360, -20], [340, 80], [350, 170], [410, 212], [470, 232]], 64, 0.08, 0.1, '#f0e6d0');
    tube([[-20, 100], [30, 110], [60, 140], [40, 170], [-20, 180]], 44);
    tube([[0, 420], [60, 400], [140, 400]], 60, 0.05, 0.12, '#c8a070');
    // mouth plain (slightly raised, flat)
    const plain = P([[300, 360], [380, 330], [470, 360], [560, 380], [640, 360], [720, 300], [780, 330], [810, 420], [800, 520], [760, 580], [620, 560], [520, 560], [440, 520], [360, 460]]);
    a.save(); a.filter = 'blur(20px)'; a.fillStyle = 'rgba(244,236,214,0.85)'; a.fill(plain); a.restore();
    R.dome(plain, null, 0.08, 0.03, 60, 1);
    // cross lumps
    const crossA = P([[430, 300], [462, 262], [500, 244], [520, 204], [558, 192], [584, 216], [592, 262], [598, 302], [574, 332], [560, 370], [530, 390], [498, 380], [468, 360], [440, 340]]);
    lump(crossA, 0.12, 0.14, 26);
    R.groove(P([[480, 300], [520, 290], [548, 320], [540, 350]], false), 16, '#4a3020', 0.24, 0.06, 1);
    const crossB = P([[598, 322], [630, 300], [662, 296], [690, 330], [700, 380], [720, 412], [712, 452], [690, 482], [660, 500], [622, 490], [600, 460], [596, 420], [610, 390], [590, 360]]);
    lump(crossB, 0.12, 0.14, 26);
    R.groove(P([[630, 360], [660, 400], [640, 440], [670, 470]], false), 16, '#4a3020', 0.24, 0.06, 1);
    // teeth
    const teeth = [[262, 378, 36, 44, -0.6], [325, 445, 33, 46, -0.45], [385, 488, 30, 46, -0.35], [443, 526, 30, 46, -0.3], [500, 562, 30, 45, -0.2]];
    for (const [x, y, rx, ry, rot] of teeth) {
      const p = ellipseP(x, y, rx, ry, rot);
      R.groove(ellipseP(x, y, rx + 9, ry + 9, rot), 14, '#2a1a10', 0.14, 0.06, 1, 0.9);
      a.save(); a.fillStyle = '#c8b090'; a.fill(p); a.restore(); rim(p, 8);
      R.dome(p, null, 0.12, 0.16, Math.min(rx, ry), 1);
    }
    // drip-like fangs hanging from the plain into the dark lower mass
    for (const x of [598, 655, 712, 766]) {
      const p = P([[x, 575], [x + 2, 640], [x, 700]], false);
      a.save(); a.lineCap = 'round'; a.strokeStyle = OR; a.lineWidth = 50; a.stroke(p); a.strokeStyle = '#ddd6c8'; a.lineWidth = 34; a.stroke(p); a.restore();
      R.pipe(p, 50, null, 0.1, 0.12, 1);
    }
    // right ridges / swirl
    tube([[700, 240], [770, 280], [820, 350], [836, 450], [812, 540], [770, 590]], 70, 0.08, 0.14, '#e0d8c8');
    tube([[890, 250], [905, 330], [925, 420], [940, 520], [915, 610]], 54);
    tube([[940, 220], [990, 262], [1014, 340], [1040, 420]], 44);
    tube([[780, 120], [860, 150], [940, 190], [1040, 200]], 60, 0.06, 0.12, '#b08050');
    tube([[820, 700], [880, 680], [960, 640], [1040, 600]], 46);
    tube([[860, 760], [920, 740], [980, 760], [1040, 740]], 40);
    const eye = ellipseP(950, 800, 55, 18, -0.12); R.flat(eye, '#4a2c18', 0.1, 1); rim(eye, 8);
    // dark lower mass (raised) and lip ridges
    const mass = P([[500, 690], [560, 700], [640, 712], [720, 706], [800, 690], [840, 710], [820, 780], [760, 806], [660, 808], [560, 790], [490, 740]]);
        R.dome(mass, null, 0.07, 0.08, 50, 1);
    tube([[262, 690], [330, 700], [420, 718], [500, 740], [560, 760]], 30, 0.06, 0.1, '#e8e4dc');
    tube([[330, 610], [400, 640], [460, 680], [500, 700]], 50, 0.05, 0.1, '#3a2a1c');

    // blue enamel pools
    const BL = '#3f6cc0';
    const enamel = (pts, col = BL, dh = 0.1) => { const p = P(pts); R.dome(p, col, 0.1, dh, 30, 2); };
    enamel([[640, -20], [720, -20], [730, 60], [760, 110], [790, 150], [780, 200], [740, 228], [690, 222], [660, 190], [652, 130], [668, 80]], '#4a74c4');
    enamel([[740, -20], [800, -20], [790, 30], [760, 50]], '#5a84cc', 0.05);
    enamel([[384, -20], [640, -20], [648, 60], [630, 118], [600, 162], [548, 168], [490, 150], [436, 128], [398, 92], [380, 40]], '#4a7ec4', 0.03);
    enamel([[520, 1044], [550, 960], [580, 910], [630, 890], [690, 910], [730, 930], [770, 890], [800, 870], [840, 890], [880, 930], [930, 960], [980, 990], [1044, 1000], [1044, 1044]], '#3462b4');
    enamel([[300, 720], [380, 740], [460, 760], [530, 770], [560, 800], [520, 830], [440, 820], [360, 790], [290, 740]], '#4a78c8', 0.04);
    enamel([[-20, 20], [30, 10], [90, 40], [120, 90], [140, 150], [200, 180], [240, 220], [220, 240], [140, 230], [60, 220], [-20, 230]], '#5a86c4', 0.04);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ metal: 1, spec: 0.9, shin: 70, tint: [1.0, 0.98, 0.95], ao: 0.5, rim: 0.2 }),       // gold / chrome
        E.mat({ dif: 0.75, emis: 0.3, spec: 1.2, shin: 90, wrap: 0.2, coat: 0.35, rim: 0.3 })        // blue enamel
      ],
      light: [-0.4, 0.6, 0.7], lc: [1, 0.97, 0.92], amb: [0.25, 0.27, 0.32],
      envTop: [1.15, 1.25, 1.45], envHor: [1.2, 1.08, 0.9], envBot: [0.1, 0.07, 0.05], envK: [0.3, 0.9, 0, 0],
      rimC: [0.8, 0.45, 0.1], shadow: [-6, 6, 0.4, 8], r1: 2.5, r2: 12, k: [0, 0.55, 0.45, 72]
    });
    // lower-left drifts out of focus
    const snap = E.snapshot(), bl = E.blur(snap, 9);
    const mask = E.newCanvas(), mx = mask.getContext('2d'); mx.setTransform(E.S, 0, 0, E.S, 0, 0);
    const mg = mx.createRadialGradient(140, 720, 60, 140, 720, 420); mg.addColorStop(0, 'rgba(0,0,0,1)'); mg.addColorStop(0.6, 'rgba(0,0,0,0.8)'); mg.addColorStop(1, 'rgba(0,0,0,0)');
    mx.fillStyle = mg; mx.fillRect(0, 0, 1024, 1024);
    mx.globalCompositeOperation = 'source-in'; mx.setTransform(1, 0, 0, 1, 0, 0); mx.drawImage(bl, 0, 0);
    E.draw(mask);
    E.grain(0.03, 8);
  }
});
