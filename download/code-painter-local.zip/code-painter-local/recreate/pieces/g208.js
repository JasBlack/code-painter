'use strict';
// g208 — "Goldfish in the glass helmet": a pale-blue glass helmet head with a navy visor and white chrome slit, red
// lips, a cream shrimp, a starry slate disc ringed in zebra spots, a big red tongue with an orange fish, white goo drips.
REC.register('g208', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const st = (x, path, col, w) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(path); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── 1. black ground, top-right bands ──
    R.flat(rrect(-10, -10, 600, 1050, 0), '#08080a', 0, 0);
    R.flat(Q([290, -10, 600, -10, 600, 60, 430, 52, 300, 70], false), lg(300, 0, 578, 0, [[0, '#aab8c6'], [0.45, '#a8b6c4'], [0.5, '#5a6c80'], [1, '#62768a']]), 0, 0);
    R.flat(Q([380, 38, 430, 30, 600, 40, 600, 60, 430, 56, 380, 62], false), '#4c5e72', 0, 0);
    R.flat(Q([430, 50, 600, 50, 600, 120, 470, 110], false), '#1e2c3e', 0, 0);

    // ── 2. the glass helmet ──
    const helm = ellipseP(330, 420, 322, 362, 0);
    R.dome(helm, rg(360, 440, 40, 330, 420, 340, [[0, '#d8e2ec'], [0.6, '#c6d2e0'], [0.85, '#b2c2d6'], [1, '#98aac0']]), 0.05, 0.12, 30, 1);
    soft(x => { x.strokeStyle = '#4a5464'; x.lineWidth = 4; x.stroke(helm); }, 1, 0.9);
    clipA(helm, () => soft(x => { fe(x, 120, 300, 80, 150, 0.2, '#6c9ec0'); fe(x, 60, 470, 50, 100, 0.2, '#7898b6'); fe(x, 330, 110, 110, 40, 0, '#9ccce6'); }, 26, 0.9));
    R.flat(Q([538, 212, 600, 200, 600, 338, 548, 324, 534, 280]), '#08080a', 0.0, 0);

    // ── 3. lower neck, right navy ──
    R.flat(Q([440, 820, 600, 820, 600, 1040, 430, 1040], false), lg(0, 820, 0, 1024, [[0, '#2a3c52'], [1, '#22344a']]), 0, 0);
    const neck = Q([70, 640, 200, 700, 330, 760, 450, 820, 470, 880, 455, 950, 440, 1040, 130, 1040, 90, 900, 70, 780], true);
    R.dome(neck, lg(70, 0, 470, 0, [[0, '#8aa0b4'], [0.25, '#b0bccc'], [0.6, '#c8d0da'], [0.85, '#bec8d4'], [1, '#8a98ae']]), 0.04, 0.18, 50, 1);

    // ── 4. navy visor with chrome slit ──
    const visor = Q([205, 245, 196, 190, 212, 150, 245, 128, 290, 122, 350, 120, 400, 124, 440, 140, 470, 200, 470, 250, 420, 262, 330, 254, 262, 250]);
    R.dome(visor, lg(200, 0, 470, 0, [[0, '#5a9ac0'], [0.12, '#1e5088'], [0.35, '#123c6c'], [0.8, '#1a3458'], [1, '#26384e']]), 0.1, 0.06, 10, 2);
    clipA(visor, () => { const r = rng(81); a.fillStyle = 'rgba(200,220,255,0.5)'; for (let i = 0; i < 160; i++) { a.beginPath(); a.arc(200 + r() * 260, 100 + r() * 160, 0.3 + r() * 0.8, 0, 6.283); a.fill(); } });
    const slit = Q([280, 195, 296, 165, 340, 150, 420, 140, 480, 138, 505, 160, 500, 215, 450, 228, 360, 230, 300, 222]);
    R.dome(slit, '#f2f4f6', 0.18, 0.12, 12, 3);
    R.groove(Q([300, 196, 360, 186, 440, 182, 480, 186], true, false), 3, '#1a1a20', 0.28, 0.06, 3);
    R.groove(Q([306, 206, 380, 204, 470, 200], true, false), 2, '#2a2a30', 0.28, 0.05, 3);
    R.bead(275, 147, 8, '#d02828', 0.2, 0.08, 5);

    // ── 5. pink face wedges ──
    const pk1 = Q([130, 330, 165, 285, 220, 258, 300, 258, 300, 300, 270, 340, 230, 362, 170, 350], true, false);
    const pk2 = Q([110, 382, 150, 368, 205, 398, 190, 462, 132, 470, 108, 430], true, false);
    for (const pk of [pk1, pk2]) {
      R.flat(pk, lg(110, 260, 300, 470, [[0, '#f6a8b0'], [1, '#f49aa2']]), 0.1, 0);
      clipA(pk, () => { a.strokeStyle = 'rgba(200,60,90,0.35)'; a.lineWidth = 0.8; for (let i = 0; i < 70; i++) { const t = i / 70; a.beginPath(); a.moveTo(100 + t * 120, 260 + t * 210); a.lineTo(130 + t * 120, 250 + t * 210); a.stroke(); } });
    }
    soft(x => { fe(x, 300, 300, 40, 40, 0, '#fae0e4'); }, 14, 0.8);

    // ── 6. slate disc with bubbles and zebra rim ──
    const slate = Q([300, 330, 360, 282, 420, 252, 480, 250, 520, 270, 545, 320, 550, 400, 545, 500, 530, 600, 500, 650, 440, 660, 380, 650, 330, 640, 280, 680, 265, 745, 230, 745, 200, 705, 205, 650, 245, 600, 250, 560, 255, 480, 270, 400]);
    R.flat(slate, lg(260, 250, 550, 650, [[0, '#56627a'], [1, '#485468']]), 0.08, 0);
    clipA(slate, () => { const r = rng(83); a.fillStyle = 'rgba(30,36,48,0.25)'; for (let i = 0; i < 2500; i++) { a.beginPath(); a.arc(250 + r() * 300, 250 + r() * 410, 0.6, 0, 6.283); a.fill(); } });
    const ZB = E.fx(`vec3 fx(vec2 uv, vec2 p){
      // zebra patch (diagonal waves) and dotted rim strip
      float s = sin(6.2832 * (dot(p, vec2(0.62, -0.78)) / 15. + 0.6 * sin(p.x * 0.02) + 0.3 * sin(p.y * 0.03)));
      vec3 z = mix(vec3(0.82, 0.84, 0.88), vec3(0.06, 0.07, 0.09), smoothstep(-0.1, 0.25, s));
      float n = vnoise(p * vec2(0.09, 0.05)) + 0.5 * vnoise(p * 0.2);
      vec3 d = mix(vec3(0.86, 0.88, 0.9), vec3(0.08, 0.09, 0.12), smoothstep(0.62, 0.7, n));
      return p.x > 430. ? d : z; }`);
    const zpatch = Q([230, 500, 270, 485, 330, 488, 380, 520, 410, 580, 405, 630, 370, 640, 320, 625, 270, 590, 240, 550]);
    R.flat(zpatch, '#cfd2da', 0.1, 0);
    clipA(zpatch, () => img(ZB));
    const zstrip = Q([505, 290, 530, 296, 540, 380, 536, 480, 528, 560, 510, 620, 472, 652, 440, 652, 470, 620, 492, 560, 500, 480, 503, 380]);
    R.flat(zstrip, '#d8dade', 0.1, 0);
    clipA(zstrip, () => img(ZB));
    // bubbles in the slate
    for (const [x, y, r] of [[405, 375, 7], [430, 420, 22], [375, 448, 26], [440, 515, 14], [445, 555, 12], [470, 340, 8], [320, 450, 6], [345, 420, 5], [475, 400, 7], [470, 455, 6], [325, 595, 7], [295, 600, 8], [460, 480, 5], [500, 590, 6], [350, 525, 5], [418, 470, 5], [285, 510, 4], [395, 600, 5]]) {
      if (r >= 20) { R.dome(circleP(x, y, r), r > 24 ? '#e8eef4' : '#9aa6b4', 0.14, 0.06, r * 0.6, 4); if (r > 24) soft(x2 => { x2.fillStyle = '#7890a8'; for (const [dx, dy, rr] of [[-8, 6, 6], [8, -6, 5], [4, 12, 4], [-10, -8, 3]]) x2.fill(circleP(x + dx, y + dy, rr)); }, 1.5, 0.8); }
      else R.bead(x, y, r, '#e4eaf2', 0.14, Math.min(0.2, r * 0.02), 5);
    }

    // ── 7. lips with teeth ──
    const mouth = Q([272, 322, 300, 300, 340, 286, 392, 286, 376, 300, 340, 310, 300, 320]);
    R.flat(Q([272, 322, 292, 290, 330, 270, 370, 268, 396, 288, 360, 304, 320, 316]), '#5a0c10', 0.16, 0);
    for (let i = 0; i < 8; i++) { const t = i / 7, x = 300 + t * 82, y = 290 - t * 6; R.dome(rrect(x - 6, y - 9, 11, 17, 4), '#eceef2', 0.24, 0.05, 3, 5); }
    const lipU = Q([272, 320, 286, 290, 310, 268, 340, 256, 362, 258, 380, 264, 396, 286, 380, 280, 350, 274, 318, 280, 292, 300]);
    R.dome(lipU, '#e4282e', 0.22, 0.12, 8, 7);
    const lipL = Q([272, 322, 300, 316, 340, 308, 372, 300, 396, 288, 386, 304, 360, 318, 320, 328, 288, 330]);
    R.dome(lipL, '#e02a2a', 0.22, 0.1, 6, 7);
    R.dome(Q([300, 336, 330, 330, 360, 322, 392, 320, 384, 336, 350, 350, 312, 352]), '#f4f4f6', 0.18, 0.06, 6, 1);

    // ── 8. cream shrimp + brush disc ──
    for (let i = 0; i < 9; i++) {
      const t = i / 8, x = 340 - t * 135, y = 350 + t * 92, rr = 32 - t * 14;
      R.dome(ellipseP(x, y, rr, rr * 0.8, -0.6), '#ece8d6', 0.2, 0.1, rr * 0.7, 1);
      R.groove(Q([x - rr * 0.6, y - rr * 0.6, x + rr * 0.4, y + rr * 0.6], true, false), 2, '#b8b2a0', 0.32, 0.03, 1);
    }
    for (let i = 0; i < 12; i++) { const t = i / 11, x = 330 - t * 110, y = 370 + t * 80; R.pipe(Q([x, y, x + 14, y + 18], true, false), 3, '#e8e4d2', 0.24, 0.04, 1); }
    R.pipe(Q([350, 420, 370, 410, 386, 380], true, false), 3, '#e8e4d2', 0.2, 0.04, 1);
    R.dome(circleP(178, 432, 26), '#f2f2f2', 0.2, 0.06, 6, 5);
    { const r = rng(5); for (let i = 0; i < 26; i++) { const t = i / 26 * 6.283; R.pipe(Q([178 + Math.cos(t) * 6, 432 + Math.sin(t) * 6, 178 + Math.cos(t) * 25, 432 + Math.sin(t) * 25], true, false), 2.4, i % 2 ? '#18181c' : '#f4f4f4', 0.28, 0.02, 5); } }

    // ── 9. big red tongue ──
    const red = Q([262, 740, 270, 700, 300, 662, 350, 642, 420, 632, 480, 628, 510, 605, 528, 560, 535, 480, 525, 400, 512, 340, 518, 312, 545, 312, 570, 330, 590, 360, 590, 860, 556, 880, 530, 920, 505, 945, 480, 925, 470, 880, 458, 840, 420, 830, 360, 825, 300, 808, 275, 780]);
    R.dome(red, lg(300, 640, 420, 840, [[0, '#d24a46'], [0.4, '#c43a38'], [0.75, '#a83234'], [1, '#922c30']]), 0.1, 0.25, 34, 6);
    clipA(red, () => soft(x => { fe(x, 420, 790, 140, 30, 0, '#9a2c30'); fe(x, 560, 500, 20, 120, 0, '#d84a48'); fe(x, 380, 660, 80, 20, -0.1, '#dc5a56'); }, 12, 0.7));
    clipA(red, () => { const r = rng(91); for (let i = 0; i < 260; i++) { const x = 260 + r() * 330, y = 310 + r() * 640, rr = 0.8 + r() * r() * 3.5; if (!a.isPointInPath(red, x * S, y * S)) continue; R.bead(x, y, rr, '#b83a3a', 0.4, 0.03, 6); } });
    R.dome(ellipseP(548, 435, 9, 13, 0), '#f4d8d8', 0.4, 0.06, 5, 5);
    R.dome(circleP(440, 855, 9), '#a02a2e', 0.38, 0.04, 4, 6);

    soft(x => { fe(x, 290, 805, 60, 22, 0.2, '#a87888'); }, 14, 0.8);
    // ── 10. orange fish ──
    const fish = Q([212, 752, 240, 735, 270, 722, 282, 705, 295, 722, 330, 722, 360, 712, 382, 694, 398, 688, 392, 712, 398, 742, 380, 742, 360, 735, 330, 745, 300, 758, 290, 782, 275, 768, 250, 766, 225, 762]);
    R.dome(fish, '#f8a434', 0.3, 0.04, 4, 5);

    // ── 11. white goo hand, drips, spiky red eye ──
    const goo = Q([16, 488, 40, 470, 90, 480, 130, 470, 140, 420, 160, 400, 190, 404, 210, 440, 250, 470, 260, 530, 250, 600, 232, 640, 200, 646, 180, 610, 150, 600, 120, 560, 70, 535, 30, 528]);
    R.dome(goo, lg(20, 0, 260, 0, [[0, '#c4d2e0'], [0.5, '#b0c2d6'], [1, '#9cb2cc']]), 0.14, 0.14, 18, 1);
    const drips = [[80, 520, 70, 620, 66, 720, 70, 820, 60, 920, 66, 1040], [110, 560, 116, 660, 104, 760, 118, 860, 110, 960, 120, 1040], [150, 620, 160, 700, 152, 800, 164, 900, 172, 1040], [180, 760, 186, 860, 180, 960, 190, 1040], [42, 760, 60, 860, 70, 1040]];
    for (const d of drips) R.pipe(Q(d, true, false), 13, '#b8c8da', 0.2, 0.14, 1);
    { const r = rng(3); for (const d of drips) for (let k = 2; k < d.length - 2; k += 2) R.bead(d[k] + (r() - 0.5) * 3, d[k + 1], 8, '#c4d2e2', 0.26, 0.1, 1); }
    R.dome(circleP(190, 582, 40), '#f0c8a0', 0.2, 0.06, 6, 5);
    { for (let i = 0; i < 40; i++) { const t = i / 40 * 6.283; R.pipe(Q([190 + Math.cos(t) * 12, 582 + Math.sin(t) * 12, 190 + Math.cos(t) * 40, 582 + Math.sin(t) * 40], true, false), 3, i % 3 ? '#c81a1a' : '#f6d8b0', 0.3, 0.03, 5); } }
    R.dome(circleP(190, 582, 18), '#b01818', 0.3, 0.04, 4, 5);
    R.bead(190, 582, 9, '#d8dce4', 0.36, 0.1, 3);

    R.dome(Q([548, 640, 568, 610, 590, 600, 590, 1040, 552, 1040, 544, 940, 552, 840, 544, 740]), lg(540, 0, 578, 0, [[0, '#b8c6d8'], [1, '#c8d4e2']]), 0.16, 0.14, 12, 1);

    // ── 12. top: white cloud, top-right ghost ──
    const ghost = Q([440, 120, 470, 95, 520, 82, 578, 80, 590, 90, 590, 200, 560, 215, 540, 240, 530, 300, 515, 330, 500, 300, 498, 250, 480, 230, 470, 200]);
    R.dome(ghost, lg(440, 0, 578, 0, [[0, '#c8d4e0'], [1, '#e2e8f0']]), 0.1, 0.16, 24, 1);
    const cl = [[156, 35, 20], [187, 23, 20], [225, 54, 18], [237, 73, 12], [129, 92, 25], [175, 100, 30], [221, 108, 22], [229, 127, 14], [110, 115, 22], [118, 135, 16], [152, 154, 25], [183, 162, 22], [160, 185, 22], [187, 181, 15], [200, 60, 20], [150, 65, 18]];
    // union outline of the lumps, ray-cast from the middle
    const cpts = [];
    for (let i = 0; i < 120; i++) {
      const t = i / 120 * 6.283, ux = Math.cos(t), uy = Math.sin(t); let best = 10;
      for (const [x, y, r] of cl) { const dx = x - 172, dy = y - 108, ud = ux * dx + uy * dy, disc = ud * ud - dx * dx - dy * dy + r * r; if (disc > 0) best = Math.max(best, ud + Math.sqrt(disc)); }
      cpts.push([172 + ux * best, 108 + uy * best]);
    }
    const cloud = P(cpts, true, false);
    R.dome(cloud, '#f2f4f6', 0.2, 0.16, 16, 1);
    for (const [x, y, r] of cl) R.dome(circleP(x, y, r * 0.8), null, 0.3, 0.06, r * 0.7, 1);
    R.pipe(Q([150, 92, 165, 96, 185, 80, 205, 70, 222, 62], true, false), 2.5, '#141418', 0.42, 0.03, 5);
    R.dome(ellipseP(198, 140, 8, 8, 0), '#d02020', 0.34, 0.04, 3, 5);
    // bead chains
    for (let i = 0; i < 30; i++) { const t = i / 29, x = 196 + Math.sin(t * 3) * 14 + t * 40, y = 210 + t * 150; R.bead(x, y, 2.2, '#e4e6ea', 0.3, 0.03, 3); }
    for (let i = 0; i < 26; i++) { const t = i / 25, x = 250 + t * 52, y = 60 - t * 50; R.bead(x, y, 2.2, '#e4e6ea', 0.3, 0.03, 3); }
    for (let i = 0; i < 26; i++) { const t = i / 25, ang = 2.75 + t * 0.95, x = 330 + Math.cos(ang) * 318, y = 420 + Math.sin(ang) * 360; if (y < 350) continue; R.bead(x, y, 5 + (i % 2) * 2, '#d0281c', 0.26, 0.08, 5); }
    for (const [x, y, r] of [[20, 435, 19], [44, 600, 15], [62, 562, 11], [34, 652, 14], [38, 690, 18], [96, 640, 6], [550, 98, 10]]) R.dome(circleP(x, y, r), rg(x - r * 0.3, y - r * 0.4, 1, x, y, r, [[0, '#e8f6ff'], [0.5, '#70b0dc'], [1, '#2a6aa8']]), 0.3, 0.1, r * 0.8, 2);
    for (const [x, y, r] of [[405, 165, 4], [410, 155, 3], [315, 125, 6], [420, 290, 6], [440, 245, 8], [360, 255, 5], [470, 270, 4], [500, 180, 3]]) R.bead(x, y, r, '#e4eaf2', 0.2, 0.05, 5);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.08, rim: 0.2 }),                 // 1 glass / clay
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, ao: 0.3, coat: 0.2 }),                             // 2 navy visor / glass beads
        E.mat({ dif: 0.9, spec: 1.2, shin: 70, wrap: 0.4, metal: 0.2, coat: 0.2 }),                        // 3 chrome
        E.mat({ dif: 1, spec: 0.3, shin: 30, wrap: 0.5, ao: 0.4 }),                                        // 4 bubbles
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.2 }),                            // 5 beads / gloss
        E.mat({ dif: 1, spec: 0.9, shin: 45, wrap: 0.45, coat: 0.12, ao: 0.4 }),                           // 6 red tongue
        E.mat({ dif: 0.8, spec: 1.0, shin: 50, wrap: 0.4, emis: 0.25, coat: 0.1 })                         // 7 red lips
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.76], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.1, 0.12, 0.16], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.45, 6]
    });
  }
});
