'use strict';
// s48 — "Grey heart machine": a gunmetal clay blob-heart with swirling relief, fed by a
// clamped pipe from the top-left and ending in a ribbed U-bend, over a black silhouette,
// red and blue grounds, a purple sky with pink dots, speckled sand, organic zebra
// stripes, an aqua polka-dot slab, pink striped plume and a glossy cyan tube.
REC.register('s48', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const speck = (path, n, seed, col, rmax = 1, al = 0.8) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al * (0.4 + r() * 0.6); a.beginPath(); a.arc(r() * 726, r() * 1024, 0.4 + Math.pow(r(), 2) * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });

    // ── frame + grounds ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#063048', 0, 0);
    const panel = P([[8, 16], [712, 16], [712, 700], [690, 800], [680, 990], [8, 984]], true, false);
    R.flat(panel, '#fa0404', 0.01, 0);
    clipA(panel, () => soft(x => { fe(x, 36, 250, 66, 130, 0, '#2a26e4'); x.fillStyle = '#1a30f0'; x.fill(P([[100, 0], [320, 0], [310, 60], [250, 76], [180, 64], [120, 44]])); }, 14, 1));
    // purple sky with dots
    const sky = P([[300, 16], [712, 16], [712, 236], [430, 236], [300, 200]], true, false);
    R.flat(sky, '#6a28f6', 0.01, 0);
    for (const [x, y, r, c] of [[482, 64, 20, '#f07ac0'], [554, 52, 14, '#f4e020'], [620, 60, 20, '#f07ac0'], [430, 72, 5, '#f07ac0'], [412, 132, 16, '#f07ac0'], [330, 50, 6, '#6a28f6']])
      R.flat(circleP(x, y, r), c, 0.02, 0);
    R.flat(P([[436, 110], [452, 94], [462, 120], [460, 160], [446, 170], [430, 160], [428, 130]]), '#f07ac0', 0.02, 0);
    R.flat(circleP(452, 122, 5), '#f05010', 0.03, 0);
    // pink speckled strip
    const pink = P([[318, 16], [372, 16], [370, 60], [360, 84], [336, 86], [320, 60]], true, true);
    R.flat(pink, '#f47cbe', 0.02, 0); speck(pink, 200, 3, '#c04070', 1.5);
    // sand wave
    const sand = P([[421, 181], [500, 152], [593, 116], [660, 70], [714, 30], [714, 238], [571, 238], [443, 196]], true, true);
    R.flat(sand, '#e6b05a', 0.02, 0); speck(sand, 2000, 4, '#7a3a20', 1.4);
    a.save(); a.strokeStyle = '#f8d8e0'; a.lineWidth = 6; a.stroke(P([[421, 181], [500, 152], [593, 116], [660, 70], [714, 30]], false)); a.restore();
    R.pipe(P([[628, 204], [626, 246], [620, 262]], false), 7, '#f07ac0', 0.1, 0.06, 4);
    // black silhouette + black right field
    a.fillStyle = '#050507';
    a.fill(P([[286, 100], [310, 80], [346, 82], [368, 104], [372, 140], [362, 170], [390, 186], [440, 200], [500, 236], [560, 236], [712, 236], [712, 700], [620, 700], [560, 480],
      [480, 460], [420, 520], [330, 600], [260, 560], [130, 560], [110, 470], [150, 390], [230, 330], [250, 260], [270, 200], [280, 160]], true, true));
    R.flat(P([[284, 250], [300, 240], [306, 270], [296, 284]]), '#f8a8c0', 0.02, 0);
    a.fillStyle = '#f4f4f4'; a.fill(circleP(293, 176, 3));
    // spiky tuft
    a.fillStyle = '#050507'; { const t = []; for (let i = 0; i < 18; i++) { const ang = -2.8 + i / 17 * 2.2, r = i % 2 ? 16 : 40; t.push([510 + Math.cos(ang) * r, 205 + Math.sin(ang) * r]); } a.fill(P(t, true, false)); }

    // ── zebra field (organic) ──
    const zeb = P([[130, 540], [200, 515], [260, 500], [300, 540], [330, 610], [400, 680], [520, 700], [640, 690], [690, 760], [684, 900], [650, 1000], [470, 1000], [300, 975],
      [240, 955], [170, 920], [110, 880], [70, 830], [52, 760], [62, 690], [90, 620], [110, 580]], true, true);
    const zfx = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = vec2(360., 770.); vec2 d = p - c; float r = length(d);
      float warp = 18. * (fbm(p * 0.012) - 0.5) + 6. * sin(p.x * 0.05 + p.y * 0.02);
      float ph = (p.y * 0.8 - p.x * 0.35 + warp * 1.8) / 16.;
      float whorl = smoothstep(90., 60., r);
      ph = mix(ph, r / 11. + atan(d.y, d.x) * 0.3, whorl);
      float s = sin(6.2832 * ph);
      return vec3(smoothstep(-0.18, 0.18, s)) * 0.94 + 0.02; }`);
    R.flat(zeb, null, 0.02, 0); clipA(zeb, () => img(zfx));
    a.save(); a.strokeStyle = '#080808'; a.lineWidth = 3; a.stroke(zeb); a.restore();
    // zebra hand (top)
    const hand = P([[160, 70], [170, 40], [186, 60], [200, 30], [214, 60], [232, 30], [248, 64], [262, 38], [280, 70], [292, 110], [270, 150], [240, 176], [212, 170], [190, 140], [170, 110]], true, true);
    R.flat(hand, null, 0.03, 0);
    clipA(hand, () => { a.fillStyle = '#f4f4f4'; a.fill(hand); a.fillStyle = '#0a0a0a'; for (let k = 0; k < 9; k++) a.fill(P(lock([[168 + k * 14, 40], [178 + k * 12, 100], [200 + k * 8, 180]], 7, 5, 1))); });
    // teal seafoam + cyan tube + splats
    for (const [cx, cy, sd] of [[70, 640, 1], [52, 700, 2], [100, 600, 3]]) {
      const bp = P(blob(cx, cy, 44, 40, sd, 14, 0.3)); R.flat(bp, '#48cdb4', 0.03, 0);
      clipA(bp, () => { a.strokeStyle = '#1a6a5a'; a.lineWidth = 2; const r = rng(sd); for (let i = 0; i < 8; i++) { a.beginPath(); a.moveTo(cx - 40 + r() * 20, cy - 30 + i * 8); a.bezierCurveTo(cx - 10, cy - 40 + i * 9, cx + 10, cy - 20 + i * 8, cx + 40, cy - 30 + i * 9); a.stroke(); } });
    }
    R.pipe(P([[-20, 866], [30, 842], [80, 810], [116, 796]], false), 54, '#18d8f4', 0.1, 0.2, 5);
    R.flat(P([[536, 300], [560, 282], [580, 296], [600, 290], [596, 320], [580, 340], [560, 356], [548, 330]]), '#f06a30', 0.03, 0);
    R.flat(P([[540, 290], [556, 282], [560, 300], [546, 306]]), '#40e0c0', 0.04, 0);
    R.pipe(ellipseP(620, 350, 16, 16, 0), 9, '#f070c0', 0.1, 0.06, 4); R.pipe(P([[606, 366], [590, 390]], false), 9, '#f070c0', 0.1, 0.06, 4);
    // purple capsule
    R.dome(P([[676, 300], [700, 296], [712, 330], [706, 400], [690, 432], [666, 420], [664, 360]]), '#8a4cf2', 0.1, 0.2, 18, 5);
    // pink striped plume
    for (const [cx, cy, sd] of [[660, 680, 7], [690, 640, 8]]) { const bp = P(blob(cx, cy, 40, 36, sd, 14, 0.3)); R.flat(bp, '#48cdb4', 0.03, 0); }
    const plume = P([[610, 470], [640, 440], [690, 446], [712, 480], [712, 610], [690, 650], [640, 640], [610, 600], [600, 540]], true, true);
    R.flat(plume, '#e868d4', 0.03, 0);
    clipA(plume, () => { a.strokeStyle = '#7a30c8'; a.lineWidth = 3; for (let i = 0; i < 16; i++) { a.beginPath(); a.moveTo(600, 470 + i * 14); a.quadraticCurveTo(650, 450 + i * 14, 712, 500 + i * 12); a.stroke(); } });
    a.save(); a.fillStyle = '#f8f4c0'; { const sr = rng(21); for (let i = 0; i < 26; i++) { const t = -3.1 + sr() * 3.1, L = 20 + sr() * 36; a.fill(P([[656 + Math.cos(t - 0.08) * 20, 470 + Math.sin(t - 0.08) * 14], [656 + Math.cos(t) * L * 1.4, 470 + Math.sin(t) * L], [656 + Math.cos(t + 0.08) * 20, 470 + Math.sin(t + 0.08) * 14]], true, false)); a.fill(circleP(656 + Math.cos(t) * L * 1.4, 470 + Math.sin(t) * L, 3)); } } a.fill(ellipseP(656, 474, 46, 16, 0)); a.restore();
    // aqua slab with pink dots + orange speckled edge + purple striped hole
    const slab = P([[420, 520], [560, 400], [616, 420], [622, 512], [580, 660], [540, 840], [520, 850], [440, 790], [414, 700]], true, true);
    R.flat(slab, '#20f0c0', 0.04, 0);
    const edge = P([[590, 420], [622, 420], [620, 520], [570, 700], [544, 848], [524, 846], [548, 700], [590, 520]], true, false);
    R.flat(edge, '#d8a040', 0.05, 0); speck(edge, 400, 5, '#6a3a10', 1.4);
    const hole = ellipseP(526, 596, 32, 50, 0.2);
    R.flat(hole, '#e060d0', 0.03, 0); clipA(hole, () => { a.strokeStyle = '#5a20b0'; a.lineWidth = 3; for (let i = 0; i < 12; i++) { a.beginPath(); a.moveTo(490 + i * 7, 540); a.lineTo(470 + i * 7, 650); a.stroke(); } });
    for (const [x, y, r] of [[452, 650, 14], [476, 670, 8], [598, 530, 14], [588, 616, 12], [562, 760, 14], [514, 752, 12], [500, 462, 10], [584, 440, 12]]) R.flat(circleP(x, y, r), '#f070b8', 0.05, 0);
    R.bead(505, 606, 5, '#f0e020', 0.08, 0.04, 0);

    // ── gunmetal pipe from top-left with clamp, chain ──
    const MET = '#9a9ea4';
    for (const c of [a, R.h]) c.lineCap = 'butt';
    R.pipe(P([[-40, -10], [80, 90], [150, 150]], false), 116, MET, 0.12, 0.34, 1);
    R.pipe(P([[140, 140], [182, 178]], false), 130, '#767a80', 0.14, 0.36, 1);
    R.pipe(P([[178, 174], [196, 190]], false), 96, '#8a8e94', 0.14, 0.3, 1);
    R.pipe(P([[192, 186], [262, 262]], false), 74, '#80848a', 0.16, 0.3, 1);
    R.pipe(P([[258, 258], [270, 272]], false), 84, '#8a8e94', 0.18, 0.3, 1);
    for (const c of [a, R.h]) c.lineCap = 'round';
    for (const t of [0.15, 0.35, 0.55, 0.75]) R.groove(ellipseP(192 + t * 70, 186 + t * 76, 10, 38, -0.75), 5, '#3a3c40', 0.4, 0.06, 1, 0.8);
    R.pipe(P([[112, 200], [140, 170], [180, 150], [210, 160]], false), 12, '#9ea2a6', 0.3, 0.1, 1);
    R.pipe(ellipseP(206, 90, 12, 12, 0), 7, '#9ea2a6', 0.3, 0.08, 1); R.pipe(ellipseP(80, 218, 12, 10, 0), 7, '#9ea2a6', 0.3, 0.08, 1);
    R.pipe(P([[136, 230], [110, 260], [100, 300], [112, 340], [130, 360], [150, 356], [220, 356], [240, 370]], false), 8, '#9a9ea4', 0.3, 0.08, 1);
    R.pipe(P([[240, 370], [260, 420], [268, 500]], false), 5, '#8a8e92', 0.3, 0.06, 1);
    R.pipe(ellipseP(136, 370, 10, 10, 0), 6, '#9a9ea4', 0.32, 0.06, 1);

    // ── the gunmetal blob-heart ──
    const heart = P([[300, 300], [380, 280], [440, 292], [500, 300], [560, 330], [600, 370], [614, 420], [600, 452], [580, 470], [560, 480], [543, 512], [530, 560],
      [480, 600], [420, 640], [400, 684], [340, 692], [296, 664], [272, 604], [262, 530], [270, 440], [284, 360]]);
    const hg = a.createLinearGradient(260, 280, 600, 690); hg.addColorStop(0, '#8a9096'); hg.addColorStop(1, '#6e747a');
    R.dome(heart, hg, 0.14, 0.3, 40, 2);
    a.save(); a.clip(heart); R.h.save(); R.h.clip(heart);
    for (const [cl, w] of [[[[300, 330], [360, 320], [420, 340], [480, 330], [540, 350], [590, 390]], 12], [[[290, 380], [350, 372], [410, 392], [470, 380], [530, 400], [600, 430]], 12],
      [[[300, 430], [360, 420], [420, 440], [480, 450]], 10], [[[440, 470], [500, 470], [540, 490]], 10], [[[290, 520], [340, 500], [390, 520], [440, 560], [480, 590]], 12],
      [[[330, 610], [370, 590], [410, 600]], 10]]) R.pipe(P(cl, false), w, '#8e949a', 0.36, 0.12, 2);
    { const sp = []; for (let i = 0; i < 60; i++) { const t = i / 60 * 6.283 * 1.6, r = 4 + i * 0.5; sp.push([336 + Math.cos(t) * r, 457 + Math.sin(t) * r]); } R.pipe(P(sp, false), 7, '#8e949a', 0.36, 0.1, 2); }
    R.groove(P([[400, 470], [440, 520], [460, 560]], false), 8, '#5a6066', 0.4, 0.1, 2);
    a.restore(); R.h.restore();
    // top cap pipe + knob
    R.pipe(P([[480, 290], [510, 230]], false), 70, MET, 0.24, 0.3, 1);
    R.dome(ellipseP(514, 230, 44, 22, -0.45), '#9ca0a6', 0.44, 0.1, 10, 1);
    R.flat(ellipseP(514, 230, 26, 12, -0.45), '#3a3c40', 0.46, 0);
    R.bead(407, 236, 14, MET, 0.3, 0.2, 1); R.bead(462, 276, 10, MET, 0.34, 0.1, 1); R.bead(454, 294, 8, MET, 0.34, 0.1, 1);
    R.pipe(P([[326, 268], [326, 290]], false), 3, '#b0b4b8', 0.4, 0.04, 1);

    // ── ribbed U-bend ──
    R.pipe(P([[510, 850], [560, 872], [620, 850], [648, 790], [636, 730], [606, 700]], false), 60, MET, 0.12, 0.34, 1);
    R.dome(ellipseP(604, 698, 32, 22, 0.4), '#7a7e84', 0.36, 0.1, 10, 1);
    for (const c of [a, R.h]) c.lineCap = 'butt';
    R.pipe(P([[522, 806], [410, 930]], false), 104, MET, 0.12, 0.34, 1);
    for (const c of [a, R.h]) c.lineCap = 'round';
    for (let k = 0; k < 7; k++) { const u = 0.12 + k * 0.1; R.groove(ellipseP(522 - u * 112, 806 + u * 124, 12, 54, 0.74), 7, '#3a3c40', 0.4, 0.06, 1, 0.8); }
    R.dome(ellipseP(410, 930, 54, 30, 0.74 - 1.57), '#80848a', 0.3, 0.12, 12, 1);
    R.dome(ellipseP(516, 844, 40, 26, 0.3), '#80848a', 0.3, 0.1, 10, 1);
    // dark red dots on the right frame
    { const r = rng(48); for (let i = 0; i < 26; i++) { const x = 650 + r() * 76, y = 720 + r() * 290; R.flat(circleP(x, y, 3 + r() * 9), '#2a0e10', 0.01, 0); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 30, wrap: 0.25, ao: 0.8, metal: 0.35, coat: 0.15, grain: 0.1 }),   // 1 gunmetal
        E.mat({ dif: 1, spec: 0.8, shin: 26, wrap: 0.3, ao: 0.9, metal: 0.3, coat: 0.12, grain: 0.08 }),    // 2 blob relief
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4 }),
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.4, emis: 0.2 }),                                      // 4 pink tubes
        E.mat({ dif: 1, spec: 1.2, shin: 60, wrap: 0.3, coat: 0.3, emis: 0.25 })                            // 5 glossy cyan / purple
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.72, 0.72, 0.76], amb: [0.4, 0.42, 0.46],
      envTop: [1.05, 1.08, 1.12], envHor: [0.45, 0.47, 0.5], envBot: [0.08, 0.08, 0.1], envK: [0.4, 1.0, 0.3, 0],
      rimC: [0.2, 0.22, 0.26], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [-7, 9, 0.6, 6]
    });
    E.grain(0.05, 48);
  }
});
