'use strict';
// u088 — "Chrome cutlery storm": sweeping chrome spatulas, a slotted fork plate and a ladder-ribbed blade tumble
// across a blue sky and blue-white camouflage chrome, against copper fur strips and a mirrored ball.
REC.register('u088', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const pf = q => { const r = []; for (let i = 0; i < q.length; i += 2) r.push([q[i], q[i + 1]]); return r; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const pg = q => P(pf(q), true, true);
    // a chrome blade: tapered ribbon with a dark keyline and a bright edge
    const blade = (cl, w0, w1, c0 = '#d4d8de', c1 = '#8a90a0', h = 0.2, m = 1) => {
      const pts = lock(cl, w0, w1), path = P(pts, true, true);
      const k = Math.max(1, Math.min(cl.length - 2, cl.length >> 1)), M = cl[k], dx = cl[k + 1][0] - cl[k - 1][0], dy = cl[k + 1][1] - cl[k - 1][1], L = Math.hypot(dx, dy) || 1;
      const nx = -dy / L * w0 * 0.6, ny = dx / L * w0 * 0.6;
      R.dome(path, lin(M[0] - nx, M[1] - ny, M[0] + nx, M[1] + ny, c0 === '#eceef0' ? [[0, c1], [0.3, c0], [0.55, mixHex(c0, c1, 0.4)], [0.8, c0], [1, c1]]
        : [[0, '#3a3e4a'], [0.16, c0], [0.36, mixHex(c0, c1, 0.5)], [0.56, '#3c404e'], [0.76, c0], [1, c1]]), h, 0.06, 7, m);
      stroke(path, 'rgba(20,22,30,0.85)', 1.6);
      return path;
    };

    // ── dark machine depths ──
    const BRUSH = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float c = cos(-.6), s = sin(-.6); vec2 q = vec2(c * p.x - s * p.y, s * p.x + c * p.y);
        float n = vnoise(vec2(q.x * .015, q.y * .5)) * .45 + vnoise(vec2(q.x * .006, q.y * .08)) * .55;
        return mix(vec3(.26, .28, .36), vec3(.72, .74, .80), n); }`);
    img(BRUSH);
    // blue sky with clouds, top left
    const SKY = pg([113, 0, 112, 28, 128, 45, 124, 71, 112, 73, 111, 112, 112, 182, 120, 183, 112, 214, 124, 215, 125, 227, 184, 239, 207, 233, 230, 185, 225, 157, 195, 154, 208, 86, 240, 81, 242, 65, 275, 57, 289, 85, 300, 83, 306, 63, 315, 64, 310, 115, 324, 135, 377, 132, 367, 165, 341, 160, 345, 185, 361, 185, 362, 192, 427, 186, 429, 152, 395, 114, 379, 113, 372, 79, 361, 77, 349, 99, 328, 100, 329, 73, 352, 73, 345, 54, 326, 58, 312, 14, 260, 0, 192, 0, 195, 18]);
    fill(P([[110, 0], [440, 0], [440, 240], [110, 240]], true, false), '#3a5aa6');
    soft(x => { for (const [cx, cy, rx, ry] of [[330, 40, 30, 22], [380, 150, 40, 18], [300, 200, 50, 14], [150, 230, 40, 10]]) fill(ellipseP(cx, cy, rx, ry, 0), 'rgba(170,185,225,0.85)', x); }, 8);
    // right top: dark glass and chrome
    fill(P([[600, 0], [726, 0], [726, 240], [660, 200], [620, 120]], true, true), '#262c36');
    // vertical pale column
    R.dome(P([[62, 0], [108, 0], [108, 700], [62, 700]], true, false), lin(62, 0, 108, 0, [[0, '#8e9aa0'], [0.4, '#d0dadc'], [1, '#9aa6aa']]), 0.06, 0.08, 14, 2);
    // the chrome bulb and its spout
    R.dome(sm([[208, 116], [244, 88], [292, 80], [326, 102], [338, 150], [326, 190], [296, 196], [262, 176], [232, 150]]), lin(210, 80, 330, 190, [[0, '#f0f2f4'], [0.5, '#a8acb4'], [1, '#d8dadc']]), 0.12, 0.2, 40, 1);
    R.bead(110, 46, 12, '#c8ccd2', 0.1, 0.1, 1); R.bead(160, 62, 7, '#d8dce0', 0.1, 0.06, 1); R.bead(686, 100, 30, lin(660, 75, 712, 128, [[0, '#e0e4e8'], [1, '#4a4e58']]), 0.1, 0.2, 1);
    for (const [pts, wd] of [[[[0, 74], [80, 86], [180, 82], [260, 74]], 3], [[[0, 196], [100, 170], [200, 150], [300, 146]], 3], [[[196, 0], [232, 30], [246, 80], [252, 120]], 4],
      [[[0, 112], [40, 140], [60, 200]], 3], [[[600, 0], [640, 40], [660, 70]], 3]])
      R.pipe(line(pts), wd, '#c8ccd4', 0.2, 0.04, 1);

    // ── copper fur, top right and the dark fur bed bottom right ──
    const FURBED = sm([[726, 520], [726, 1030], [380, 1030], [420, 940], [520, 840], [610, 740], [670, 660], [690, 600]]);
    fill(FURBED, lin(500, 600, 726, 1024, [[0, '#5a2c28'], [1, '#3e1e1e']]));
    const FUR = sm([[600, 192], [700, 186], [726, 180], [726, 710], [700, 640], [660, 560], [600, 520], [578, 470], [586, 420], [574, 360], [600, 300], [640, 250]]);
    fill(FUR, lin(600, 200, 726, 700, [[0, '#8e4834'], [0.6, '#7c4032'], [1, '#5a2c28']]));
    const FURTX = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float c = cos(-.9), s = sin(-.9); vec2 q = vec2(c * p.x - s * p.y, s * p.x + c * p.y);
        float n = vnoise(vec2(q.x * 1.3, q.y * .06)) * .55 + vnoise(vec2(q.x * .35, q.y * .02)) * .45;
        return vec3(.62 + .7 * n * n); }`);
    for (const pth of [FUR, FURBED]) clipA(pth, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(FURTX); a.restore(); });
    // dark teal blades, top left
    fill(P([[0, 0], [62, 0], [62, 330], [0, 360]], true, false), lin(0, 0, 62, 300, [[0, '#4e585e'], [1, '#3a4248']]));
    for (const pts of [[[0, 120], [30, 160], [62, 200]], [[0, 250], [30, 270], [62, 290]]]) stroke(line(pts), 'rgba(200,210,215,0.6)', 3);

    // ── ribbed arc and the white spatula at the top ──
    const B2 = [[196, 220], [300, 208], [400, 206], [500, 212], [560, 230], [604, 264], [626, 320], [622, 372]];
    blade(B2, 62, 40, '#eceef0', '#a8a8ae');
    for (let i = 0; i < 26; i++) { const t = i / 25, x = 300 + t * 300, y = 196 + Math.pow(t, 3) * 90; stroke(line([[x, y], [x - 4 + t * 10, y + 22 - t * 6]]), 'rgba(60,64,76,0.7)', 1.6); }
    blade([[392, 82], [470, 116], [540, 150], [600, 182], [644, 222], [664, 280], [670, 330]], 84, 36, '#eceef0', '#c8c4c0', 0.24);
    blade([[280, 40], [340, 30], [420, 20], [520, 10], [620, 8]], 30, 20, '#d8dce2', '#8a90a0', 0.2);
    blade([[600, 20], [560, 80], [580, 150], [620, 170]], 30, 20, '#c8ccd4', '#7a8090', 0.2);
    R.dome(ellipseP(410, 78, 34, 26, 0.3), '#eef0f2', 0.24, 0.12, 20, 1);
    // gold mesh behind the arc
    fill(pg([577, 255, 546, 252, 504, 283, 535, 329, 569, 312]), '#7a6040');
    for (let i = 0; i < 9; i++) stroke(line([[510 + i * 7, 260], [520 + i * 7, 325]]), 'rgba(200,170,110,0.6)', 1);

    // ── slotted fork plate ──
    const FORK = sm([[96, 258], [200, 252], [320, 256], [430, 266], [490, 284], [500, 316], [470, 340], [380, 334], [260, 322], [150, 312], [96, 300]]);
    R.dome(FORK, lin(100, 250, 300, 340, [[0, '#cfd4da'], [0.5, '#e6e8ec'], [1, '#9aa0aa']]), 0.24, 0.1, 18, 1);
    for (let k = 0; k < 4; k++) { const y = 272 + k * 13; R.groove(line([[106, y], [300, y + 6], [470, y + 16 + k * 2]]), 7, '#14151c', 0.34, 0.14, 1, 1); }

    // ── blue-white camouflage chrome ──
    const CAMO = sm([[120, 452], [150, 402], [220, 370], [300, 362], [362, 332], [430, 330], [505, 336], [520, 384], [484, 442], [424, 484], [384, 540], [334, 562], [278, 560], [220, 532], [160, 482]]);
    R.dome(CAMO, lin(120, 330, 520, 560, [[0, '#90a2d2'], [0.5, '#a2b0da'], [1, '#8494c8']]), 0.1, 0.18, 40, 2);
    clipA(CAMO, () => soft(x => {
      for (const q of [[414, 332, 366, 329, 365, 341, 318, 339, 303, 364, 295, 401, 319, 432, 330, 474, 352, 489, 346, 536, 385, 511, 401, 440, 420, 423, 427, 377, 385, 397, 369, 417, 336, 400, 332, 387, 365, 386, 391, 353, 391, 341, 414, 340],
        [299, 434, 270, 396, 269, 372, 222, 369, 181, 380, 161, 413, 132, 438, 132, 449, 167, 458, 189, 444, 234, 435, 293, 448], [193, 523, 194, 533, 243, 550, 286, 579, 290, 562, 274, 525, 235, 513]])
        fill(pg(q), 'rgba(40,66,160,0.8)', x);
      for (const [cx, cy, rx, ry, rt] of [[250, 400, 50, 22, -0.3], [360, 360, 30, 16, 0.4], [200, 500, 40, 18, 0.2], [420, 470, 22, 40, 0.5], [300, 520, 30, 14, 0]]) fill(ellipseP(cx, cy, rx, ry, rt), '#e2e6f2', x);
    }, 2.5));
    soft(x => fill(ellipseP(160, 470, 60, 20, -0.3), 'rgba(240,170,90,0.5)', x), 10);

    // ── left chrome feathers and the bottom-left fan ──
    const FAN = sm([[0, 690], [120, 662], [240, 640], [340, 680], [360, 800], [340, 1030], [0, 1030]]);
    R.dome(FAN, lin(0, 680, 340, 1024, [[0, '#9aa0b0'], [0.5, '#7a8090'], [1, '#8a90a0']]), 0.06, 0.1, 30, 1);
    clipA(FAN, () => { const r = rng(88); for (let i = 0; i < 16; i++) { const y = 700 + i * 22 + r() * 8; stroke(line([[-10, y + 40], [150, y], [360, y - 60 + r() * 20]]), r() < 0.5 ? 'rgba(220,226,236,0.55)' : 'rgba(20,22,30,0.6)', 1.5 + r() * 4); } });
    for (const [cl, w0, w1] of [[[[-10, 330], [120, 318], [260, 312], [400, 316]], 40, 30], [[[-10, 410], [100, 382], [200, 352], [290, 334]], 52, 26], [[[-10, 488], [80, 458], [160, 432], [240, 418], [300, 424]], 56, 30],
      [[[-10, 566], [100, 530], [200, 496], [262, 478]], 56, 26], [[[-10, 642], [80, 604], [150, 566], [226, 528]], 50, 20], [[[-10, 726], [100, 692], [200, 664], [300, 650]], 46, 20],
      [[[-10, 806], [80, 780], [160, 760], [260, 740]], 40, 16], [[[0, 950], [100, 920], [200, 905], [300, 910]], 30, 12]])
      blade(cl, w0, w1, '#dfe3e8', '#8a90a0', 0.16);
    // bronze patch and the white sky-light behind the loop
    R.dome(pg([224, 607, 187, 601, 144, 612, 151, 661, 222, 633]), '#b08048', 0.14, 0.06, 10, 3);

    // ── the long spoon handle with its loop end ──
    blade([[236, 652], [300, 604], [400, 544], [500, 484], [600, 436], [700, 404], [740, 396]], 56, 50, '#e8eaee', '#a0a6b2', 0.3);
    blade([[300, 720], [400, 640], [500, 570], [560, 520]], 50, 30, '#d4d8de', '#8a90a0', 0.22);
    blade([[200, 1030], [260, 930], [330, 860], [420, 800], [500, 740]], 60, 30, '#c8ccd4', '#7a8090', 0.2);
    R.pipe(circleP(250, 652, 24), 12, '#d8dce2', 0.36, 0.1, 1);
    R.flat(circleP(250, 652, 16), '#262834', 0.3, 0);

    // ── the ladder-ribbed blade ──
    const LCL = [[24, 882], [120, 870], [220, 846], [310, 796], [400, 720], [470, 640], [530, 566], [560, 520]];
    blade(LCL, 64, 50, '#d0d4dc', '#8c92a2', 0.26);
    { const inner = P(lock(LCL, 40, 30), true, true); R.flat(inner, '#2e303c', 0.3, 0);
      for (let i = 0; i <= 40; i++) { const t = i / 40, k = Math.min(LCL.length - 2, Math.floor(t * (LCL.length - 1))), u = t * (LCL.length - 1) - k;
        const p0 = LCL[k], p1 = LCL[k + 1], x = p0[0] + (p1[0] - p0[0]) * u, y = p0[1] + (p1[1] - p0[1]) * u, dx = p1[0] - p0[0], dy = p1[1] - p0[1], L = Math.hypot(dx, dy), w = 20 - t * 5;
        stroke(line([[x - dy / L * w, y + dx / L * w], [x + dy / L * w, y - dx / L * w]]), 'rgba(200,206,216,0.75)', 1.4); }
      stroke(P(lock(LCL, 22, 16), true, true), 'rgba(200,206,216,0.6)', 1.2); }

    // ── copper strips, bottom right ──
    for (const [cl, w0, w1, c0, c1] of [[[[380, 1000], [470, 900], [560, 810], [640, 730], [720, 664]], 90, 80, '#9a5a40', '#5e2e28'],
      [[[480, 1040], [570, 950], [650, 880], [740, 800]], 96, 84, '#764232', '#4a2626'], [[[630, 1040], [690, 980], [740, 940]], 80, 70, '#6a302c', '#3e1e20']]) {
      const path = P(lock(cl, w0, w1), true, true);
      R.dome(path, lin(cl[0][0], cl[0][1], cl[cl.length - 1][0], cl[cl.length - 1][1], [[0, c0], [1, c1]]), 0.16, 0.12, w0 * 0.4, 3);
      clipA(path, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(FURTX); a.restore(); });
      stroke(path, 'rgba(230,200,180,0.7)', 2);
    }
    // spring coil and the mirrored ball
    { const pts = []; for (let i = 0; i <= 60; i++) { const t = i / 60; pts.push([548 + t * 40 + Math.cos(t * 50) * 10, 500 + t * 80 + Math.sin(t * 50) * 4]); } R.pipe(P(pts, false, false), 2.5, '#c0c4cc', 0.3, 0.04, 1); }
    R.bead(652, 574, 56, lin(610, 530, 700, 620, [[0, '#f0f2f4'], [0.4, '#9aa0aa'], [1, '#30343e']]), 0.2, 0.36, 1);
    R.bead(552, 362, 18, '#c8ccd2', 0.3, 0.1, 1);
    // orange sparks
    soft(x => { for (const [px, py, r] of [[32, 324, 5], [80, 460, 4], [125, 740, 6], [35, 625, 6], [468, 690, 4], [430, 640, 3], [120, 990, 5], [290, 940, 4]]) fill(circleP(px, py, r), 'rgba(255,140,60,0.95)', x); }, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 60, metal: 0.12, wrap: 0.4, ao: 0.4, rim: 0.2 }),      // 1 chrome
        E.mat({ dif: 0.8, spec: 1.0, shin: 60, metal: 0.3, wrap: 0.3, ao: 0.3 }),                  // 2 painted chrome
        E.mat({ dif: 1, spec: 0.4, shin: 20, wrap: 0.4, ao: 0.4, grain: 0.1 })                     // 3 copper fur / bronze
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.55, 0.55, 0.56], amb: [0.56, 0.56, 0.58],
      envTop: [1, 1, 1], envHor: [0.5, 0.52, 0.6], envBot: [0.08, 0.08, 0.1], envK: [0.5, 1.2, 0.0, 0],
      rimC: [0.5, 0.55, 0.7], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-5, 6, 0.5, 8]
    });
    { const r = rng(9); for (let i = 0; i < 40; i++) fill(circleP(r() * 726, r() * 1024, 0.6 + r()), 'rgba(255,255,255,0.8)', o); }
    E.grain(0.05, 88);
  }
});
