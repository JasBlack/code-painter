'use strict';
// s19 — "Cosmic octopus contact sheet": a ten-panel collage on a navy gutter — red and
// dark octopi in black space, a fiery orange nebula, a salmon/green/black close-up, red
// smoke with a fire burst, a neon fish head, turtles under a blue sky, a silver ink splash
// with a red octopus, a pale blue dream sky and a near-black jellyfish field.
REC.register('s19', {
  w: 716, h: 862,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const r = rng(19);
    const panel = (x, y, w, h, fn) => { a.save(); a.clip(rrect(x, y, w, h, 8)); fn(x, y, w, h); a.restore(); };
    const fillB = (pts, col, smooth = true) => { a.fillStyle = col; a.fill(P(pts, true, smooth)); };
    const circ = (x, y, rad, col) => { a.fillStyle = col; a.beginPath(); a.arc(x, y, rad, 0, 6.283); a.fill(); };
    const ell = (x, y, rx, ry, rot, col) => { a.fillStyle = col; a.fill(ellipseP(x, y, rx, ry, rot)); };
    const strk = (pts, w, col, smooth = true) => { a.strokeStyle = col; a.lineWidth = w; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, false, smooth)); };
    const ring = (x, y, rad, w, col) => { a.strokeStyle = col; a.lineWidth = w; a.beginPath(); a.arc(x, y, rad, 0, 6.283); a.stroke(); };
    const glow = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const stars = (x0, y0, w, h, n, col = '255,255,255', maxR = 1.6) => {
      for (let i = 0; i < n; i++) circ(x0 + r() * w, y0 + r() * h, 0.4 + Math.pow(r(), 3) * maxR, `rgba(${col},${0.35 + r() * 0.65})`);
    };
    const curl = (cx, cy, rad, turns, w0, col, dir = 1, a0 = 0) => {   // tapered spiral tentacle
      const pts = []; const n = 24;
      for (let i = 0; i <= n; i++) { const t = i / n, an = a0 + dir * t * turns * 6.283, rr = rad * (1 - 0.75 * t); pts.push([cx + Math.cos(an) * rr, cy + Math.sin(an) * rr]); }
      a.fillStyle = col; a.fill(P(lock(pts, w0, 1)));
    };

    R.flat(rrect(-10, -10, 736, 882, 0), '#181e2a', 0, 0);

    // ── P1: red octopus in black space, violet-blue wave ──
    panel(0, 0, 356, 213, (x0, y0, w, h) => {
      a.fillStyle = '#060308'; a.fillRect(x0, y0, w, h);
      stars(0, 0, 200, 213, 60);
      const bg = a.createLinearGradient(180, 0, 356, 213); bg.addColorStop(0, '#3a22e0'); bg.addColorStop(0.5, '#2c18dc'); bg.addColorStop(1, '#4a34ea');
      fillB([[172, -5], [362, -5], [362, 220], [334, 196], [302, 156], [262, 118], [218, 84], [192, 44]], bg);
      glow(x => { x.strokeStyle = '#6a58f4'; x.lineWidth = 18; x.stroke(P([[220, 20], [262, 70], [300, 110], [350, 150]], false)); x.strokeStyle = '#8030d0'; x.lineWidth = 10; x.stroke(P([[190, 60], [230, 100], [260, 140]], false)); }, 8, 0.7);
      for (const [x, y, rr] of [[322, 25, 8], [240, 40, 3], [300, 92, 3], [336, 122, 2.5], [210, 18, 2], [280, 60, 2], [340, 70, 2]]) circ(x, y, rr, '#fafaff');
      // octopus
      fillB([[70, 110], [110, 80], [160, 84], [196, 112], [210, 160], [196, 215], [80, 215], [60, 170]], '#4e1008');
      ell(140, 118, 48, 40, 0, '#6a160c');
      for (const [cx, cy, rad, tu, w0, dir, a0] of [[30, 90, 34, 1.1, 18, 1, 3.4], [40, 160, 30, 1.0, 16, -1, 0.3], [205, 170, 28, 1.1, 16, 1, 4.2], [100, 40, 26, 1, 14, -1, 1], [170, 200, 22, 1, 14, -1, 3]]) curl(cx, cy, rad, tu, w0, '#e0341c', dir, a0);
      curl(250, 190, 20, 1, 10, '#b02010', 1, 2);
      circ(135, 148, 10, '#f4f0ea'); circ(136, 149, 5, '#0a0404');
      ring(78, 196, 12, 5, '#f0c020'); circ(196, 124, 8, '#30e070'); fillB([[0, 196], [26, 206], [0, 216]], '#30d040', false);
      circ(170, 150, 4, '#f0a020'); circ(60, 120, 5, '#8a40d0'); circ(212, 206, 6, '#8a40d0');
      glow(x => { x.fillStyle = '#40c080'; x.beginPath(); x.arc(195, 125, 14, 0, 6.283); x.fill(); }, 6, 0.6, 'screen');
    });

    // ── P2: dark octopus, pink eye, dotted mound ──
    panel(365, 3, 351, 210, (x0, y0, w, h) => {
      a.fillStyle = '#050407'; a.fillRect(x0, y0, w, h);
      stars(x0, y0, w, h, 90);
      glow(x => { const g = x.createLinearGradient(480, 80, 600, 80); g.addColorStop(0, '#6020a0'); g.addColorStop(0.5, '#c040c0'); g.addColorStop(1, '#f0a030');
        x.fillStyle = g; x.fill(ellipseP(540, 82, 70, 16, -0.15)); }, 6, 0.9);
      ell(560, 135, 120, 62, -0.1, '#161418');
      for (let i = 0; i < 26; i++) circ(620 + r() * 70, 70 + r() * 80, 8 + r() * 12, r() < 0.5 ? '#48484e' : '#2a2a30');
      for (let i = 0; i < 14; i++) circ(625 + r() * 60, 75 + r() * 70, 2 + r() * 4, '#8a8a92');
      for (let i = 0; i < 14; i++) { const yy = 20 + r() * 60, xx = 380 + r() * 300; strk([[xx, yy], [xx + 40, yy + 10 + r() * 20], [xx + 90, yy + 20]], 1.5, 'rgba(230,230,230,0.7)'); }
      ring(425, 120, 24, 7, '#e02c80'); circ(425, 120, 18, '#f4f0f4'); circ(430, 124, 8, '#060406');
      ring(692, 166, 9, 4, '#e02c80');
      // dotted black/white mound
      ell(560, 250, 170, 80, 0, '#0a0a0c');
      for (const k of [0, 1, 2]) strk([[400 + k * 30, 220 - k * 18], [480, 190 - k * 16], [580, 186 - k * 16], [680, 208 - k * 14]], 2.5, '#f0f0f0');
      for (const [x, y, rr] of [[472, 214, 12], [505, 206, 13], [540, 212, 11], [585, 208, 9], [612, 214, 8], [640, 205, 6], [690, 214, 10]]) circ(x, y, rr, '#f6f6f6');
      strk([[560, 40], [590, 30]], 4, '#f0d020'); circ(610, 92, 5, '#30d050'); strk([[380, 190], [410, 170]], 3, '#e02020');
    });

    // ── P3: fiery nebula with a dark octopus ──
    panel(0, 223, 443, 267, (x0, y0, w, h) => {
      const g = a.createRadialGradient(60, 380, 5, 90, 370, 330); g.addColorStop(0, '#fff6c0'); g.addColorStop(0.1, '#fbd040'); g.addColorStop(0.3, '#ee8418'); g.addColorStop(0.6, '#c43c10'); g.addColorStop(1, '#8a200c');
      a.fillStyle = g; a.fillRect(x0, y0, w, h);
      glow(x => { const gg = x.createRadialGradient(40, 380, 0, 40, 380, 90); gg.addColorStop(0, 'rgba(255,255,220,1)'); gg.addColorStop(0.4, 'rgba(255,220,90,0.8)'); gg.addColorStop(1, 'rgba(250,160,40,0)'); x.fillStyle = gg; x.fillRect(0, 280, 140, 200); }, 4);
      for (let i = 0; i < 26; i++) { const off = i * 4; strk([[-10, 236 + off * 0.9], [80, 246 + off], [180, 268 + off * 0.7]], 1.6, i % 2 ? 'rgba(240,70,20,0.9)' : 'rgba(250,170,60,0.8)'); }
      for (let i = 0; i < 40; i++) circ(220 + r() * 150, 222 + r() * 60, 6 + r() * 14, ['#5a3a18', '#b89038', '#3a2410', '#d8b050'][i % 4]);
      circ(350, 256, 9, '#40c040'); strk([[350, 240], [360, 280]], 6, '#58d050');
      // dark octopus body + head
      fillB([[80, 490], [100, 420], [140, 370], [190, 340], [250, 350], [300, 390], [320, 440], [300, 490]], '#3c0c08');
      ell(210, 380, 64, 50, 0, '#4c120a');
      ell(160, 440, 30, 18, 0.4, '#5a1810');
      // red swirls on the right + left tentacle
      fillB([[300, 300], [350, 270], [410, 280], [443, 300], [443, 380], [410, 420], [380, 400], [350, 360], [320, 340]], '#e8341a');
      fillB([[270, 420], [320, 380], [380, 400], [430, 440], [443, 490], [300, 490]], '#d62c14');
      fillB([[340, 440], [390, 430], [443, 450], [443, 490], [360, 490]], '#1a0604');
      fillB([[0, 410], [50, 390], [110, 420], [120, 470], [80, 490], [0, 490]], '#d8321a');
      curl(60, 440, 30, 1, 14, '#6a1a0e', 1, 2);
      fillB([[150, 490], [200, 456], [280, 440], [360, 452], [385, 490]], '#f8c810');
      ring(405, 330, 14, 7, '#5ad020'); circ(405, 330, 7, '#101010');
      ring(270, 426, 7, 3, '#f0d030'); circ(240, 432, 4, '#f0f0f0'); circ(242, 432, 2, '#101010');
      strk([[300, 350], [330, 330], [360, 340]], 4, '#50c030'); strk([[420, 380], [430, 350]], 5, '#f0d020');
      for (let i = 0; i < 70; i++) circ(r() * 443, 223 + r() * 267, 0.6 + Math.pow(r(), 3) * 3, `rgba(255,250,${180 + r() * 70},${0.5 + r() * 0.5})`);
    });

    // ── P4: black / salmon / green close-up ──
    panel(452, 223, 264, 267, (x0, y0, w, h) => {
      a.fillStyle = '#0a0710'; a.fillRect(x0, y0, w, h);
      const g = a.createLinearGradient(600, 230, 716, 480); g.addColorStop(0, '#f6c6c2'); g.addColorStop(0.4, '#eea08c'); g.addColorStop(1, '#d87c5a');
      fillB([[604, 215], [730, 215], [730, 500], [566, 500], [578, 440], [612, 418], [644, 398], [630, 356], [614, 318], [606, 270]], g);
      fillB([[640, 400], [716, 380], [716, 470], [650, 460]], '#e4886a');
      circ(470, 268, 44, '#f8f4f4');
      a.strokeStyle = '#2e8e34'; a.lineWidth = 26; a.beginPath(); a.arc(478, 262, 76, -0.2, 1.5); a.stroke();
      fillB([[500, 440], [560, 410], [620, 424], [604, 476], [540, 486]], '#3450d4');
      fillB([[480, 490], [520, 452], [570, 446], [600, 470], [600, 495], [480, 495]], '#e8e6f2');
      fillB([[452, 470], [500, 460], [500, 495], [452, 495]], '#6a2a50');
      for (const [x, y, rr, c] of [[526, 342, 14, '#e03a30'], [592, 332, 12, '#e03a30'], [602, 372, 9, '#e03a30'], [470, 392, 8, '#e04030'], [496, 380, 5, '#f0d030'], [552, 410, 8, '#30a040'], [520, 400, 6, '#f0d030'], [640, 300, 4, '#f8f0f0']]) circ(x, y, rr, c);
      fillB([[660, 225], [716, 223], [716, 262], [690, 250]], '#f8e0f0');
    });

    // ── P5: red smoke with a fire burst ──
    panel(0, 499, 268, 163, (x0, y0, w, h) => {
      a.fillStyle = '#7a1c0e'; a.fillRect(x0, y0, w, h);
      for (let i = 0; i < 70; i++) circ(r() * 268, 499 + r() * 163, 8 + r() * 20, ['#a82a14', '#5a1008', '#c43a1c', '#8a2010', '#3a0a06'][i % 5]);
      glow(x => { const g = x.createRadialGradient(140, 585, 0, 140, 585, 58); g.addColorStop(0, '#fffac0'); g.addColorStop(0.3, '#f8c030'); g.addColorStop(0.6, '#f07018'); g.addColorStop(1, 'rgba(220,60,20,0)');
        x.fillStyle = g; x.beginPath(); x.arc(140, 585, 58, 0, 6.283); x.fill(); x.strokeStyle = '#70f040'; x.lineWidth = 8; x.beginPath(); x.moveTo(150, 530); x.lineTo(145, 600); x.stroke(); }, 6, 0.85);
      curl(40, 540, 34, 1, 16, '#e4381c', 1, 3); curl(60, 620, 26, 1, 12, '#e4381c', -1, 1);
      circ(245, 560, 26, '#2a0806'); ring(245, 560, 16, 5, '#5a1810'); circ(252, 606, 6, '#30c040');
      for (let i = 0; i < 25; i++) circ(r() * 268, 499 + r() * 163, 0.8 + r() * 1.5, 'rgba(255,240,200,0.8)');
    });

    // ── P6: neon fish head ──
    panel(276, 499, 165, 163, (x0, y0, w, h) => {
      a.fillStyle = '#040406'; a.fillRect(x0, y0, w, h);
      strk([[318, 502], [352, 516], [384, 534]], 13, '#e424c8'); strk([[400, 522], [444, 500]], 7, '#e424c8'); strk([[276, 540], [300, 520]], 5, '#e424c8');
      circ(287, 580, 8, '#3060f0');
      fillB([[282, 670], [300, 630], [340, 606], [390, 596], [441, 600], [441, 670]], '#0c1024');
      const cols = ['#30c8f0', '#f4f4f4', '#2060f0', '#30c8f0', '#f4f4f4', '#2a90f0'];
      for (let k = 0; k < 6; k++) strk([[296 + k * 10, 668], [320 + k * 6, 640 + k * 3], [360, 622 + k * 6], [400, 616 + k * 7], [441, 622 + k * 7]], k % 3 === 1 ? 2.5 : 4.5, cols[k]);
      strk([[340, 662], [360, 646], [380, 650], [370, 662]], 4, '#40e040');
      a.strokeStyle = '#f0e020'; a.lineWidth = 7; a.stroke(ellipseP(404, 592, 24, 17, -0.1));
      ell(404, 592, 15, 10, -0.1, '#3aa0e8'); circ(398, 592, 5, '#050505');
      strk([[430, 560], [441, 575]], 5, '#40e040');
    });

    // ── P7: turtles, blue sky, magenta stripe ──
    panel(450, 499, 266, 163, (x0, y0, w, h) => {
      a.fillStyle = '#050407'; a.fillRect(x0, y0, w, h);
      const g = a.createLinearGradient(560, 499, 716, 570); g.addColorStop(0, '#3a86ee'); g.addColorStop(1, '#60aaf6');
      fillB([[556, 495], [720, 495], [720, 566], [690, 542], [646, 572], [602, 560], [572, 530]], g);
      ell(650, 518, 10, 7, 0, '#f4f4f4'); circ(700, 546, 6, '#f0a0d0'); circ(610, 512, 3, '#f4f4f4');
      strk([[498, 526], [558, 548], [620, 578], [668, 610], [690, 645]], 10, '#e030e0');
      ell(505, 550, 46, 32, -0.2, '#4a3220'); for (let i = 0; i < 10; i++) ring(490 + r() * 30, 540 + r() * 20, 5, 1.5, '#8a6a3a');
      ell(694, 604, 38, 46, 0, '#2c3a1c'); for (let i = 0; i < 10; i++) ring(680 + r() * 28, 585 + r() * 36, 5, 1.5, '#6a8a3a');
      ell(612, 600, 26, 10, 0.3, '#f07c30'); circ(596, 594, 4, '#3a3a3a');
      ell(484, 632, 26, 10, -0.3, '#a050c8');
      for (const pts of [[[520, 664], [528, 640], [546, 650]], [[560, 664], [566, 632], [584, 646]], [[600, 664], [612, 640]], [[470, 600], [480, 580]]]) strk(pts, 6, '#e03020');
      stars(450, 560, 266, 100, 30);
    });

    // ── P8: silver ink splash + kanji, black space, red fish, lime swirls, blue turtle ──
    panel(0, 670, 320, 192, (x0, y0, w, h) => {
      a.fillStyle = '#07070a'; a.fillRect(x0, y0, w, h);
      stars(120, 670, 200, 120, 40);
      const g = a.createLinearGradient(0, 670, 160, 862); g.addColorStop(0, '#a0a0aa'); g.addColorStop(0.5, '#8a8a96'); g.addColorStop(1, '#6a6a78');
      fillB([[-10, 700], [40, 690], [90, 700], [130, 690], [150, 720], [120, 760], [140, 800], [160, 820], [150, 870], [-10, 870]], g);
      fillB([[120, 690], [200, 680], [250, 700], [220, 720], [170, 712], [140, 730]], '#8a8a96');
      for (const [x, y, rx, ry] of [[60, 690, 36, 12], [150, 700, 30, 10], [110, 760, 14, 24]]) { a.fillStyle = '#0a0a0c'; a.fill(P(blob(x, y, rx, ry, x + y, 12, 0.35))); }
      for (const pts of [[[40, 730], [100, 726]], [[70, 716], [70, 790]], [[36, 752], [108, 748]], [[46, 770], [34, 792]], [[96, 770], [110, 792]], [[56, 790], [90, 788]], [[40, 776], [100, 772]]]) strk(pts, 10, '#08080a', false);
      fillB([[-10, 670], [30, 672], [60, 690], [40, 712], [10, 720], [-10, 716]], '#8ad030'); strk([[20, 690], [50, 700]], 6, '#f0e040'); circ(76, 694, 8, '#e03020');
      fillB([[250, 670], [330, 670], [330, 720], [300, 712], [270, 700]], '#40b040'); fillB([[280, 680], [320, 676], [310, 700]], '#f0f0f0');
      // lime swirls, red fish, blue turtle
      strk([[100, 800], [130, 770], [170, 760], [200, 780], [210, 820]], 20, '#b8e030'); strk([[170, 740], [210, 736], [250, 760], [262, 790]], 14, '#c8f040');
      fillB([[130, 830], [160, 796], [210, 786], [250, 808], [262, 850], [240, 870], [140, 870]], '#e8301a');
      fillB([[98, 790], [118, 780], [126, 820], [110, 840], [96, 820]], '#e8301a');
      circ(210, 830, 12, '#f0e040'); circ(210, 830, 6, '#101010'); circ(170, 822, 6, '#f8f0f0');
      fillB([[236, 750], [290, 736], [322, 760], [322, 862], [260, 862], [236, 820], [230, 780]], '#2432d0');
      for (let i = 0; i < 26; i++) circ(240 + r() * 80, 745 + r() * 110, 1.2 + r() * 1.5, '#e8e8ff');
      fillB([[244, 824], [276, 816], [290, 846], [262, 862], [240, 852]], '#f0d8e8'); strk([[250, 830], [270, 836], [262, 850]], 2, '#e03060');
      circ(155, 750, 16, '#6a5a8a'); circ(155, 752, 10, '#e8c0b0'); ring(155, 750, 17, 2, '#c0c0d0');
      circ(108, 812, 10, '#e060a8'); circ(24, 838, 20, '#101014'); for (let i = 0; i < 8; i++) circ(14 + r() * 20, 828 + r() * 20, 1, '#f0f0f0');
      glow(x => { x.fillStyle = '#ffffff'; x.fill(ellipseP(40, 740, 30, 8, -0.3)); x.fill(ellipseP(60, 830, 26, 7, 0.3)); }, 8, 0.4);
    });

    // ── P9: pale blue dream sky ──
    panel(328, 670, 191, 192, (x0, y0, w, h) => {
      const g = a.createLinearGradient(0, 670, 0, 862); g.addColorStop(0, '#050508'); g.addColorStop(0.18, '#1a2a5a'); g.addColorStop(0.42, '#4a90d0'); g.addColorStop(0.62, '#7cb4dc'); g.addColorStop(0.8, '#a8b4e0'); g.addColorStop(1, '#ccd0ee');
      a.fillStyle = g; a.fillRect(x0, y0, w, h);
      fillB([[320, 660], [520, 660], [520, 700], [470, 720], [420, 700], [380, 740], [340, 760], [320, 740]], '#06060a');
      fillB([[320, 740], [350, 760], [360, 862], [320, 862]], '#1a1a30');
      glow(x => { x.fillStyle = '#2040c0'; x.beginPath(); x.arc(498, 748, 18, 0, 6.283); x.fill(); }, 2);
      for (const [x, y, rr, c] of [[480, 800, 12, '#3060e0'], [440, 740, 9, '#40c0e0'], [455, 822, 11, '#f0d020'], [410, 792, 8, '#e04040'], [398, 770, 6, '#f080c0'], [370, 800, 7, '#40a0f0'], [500, 700, 6, '#ffffff']]) circ(x, y, rr, c);
      fillB([[440, 862], [446, 820], [458, 812], [470, 830], [474, 862]], '#0a0a10');
      fillB([[500, 862], [506, 835], [519, 830], [519, 862]], '#0a0a10');
    });

    // ── P10: near-black jellyfish field ──
    panel(528, 670, 188, 192, (x0, y0, w, h) => {
      a.fillStyle = '#060506'; a.fillRect(x0, y0, w, h);
      for (let i = 0; i < 14; i++) { const x = 540 + r() * 170, y = 690 + r() * 160; circ(x, y, 6 + r() * 10, 'rgba(60,50,60,0.35)'); strk([[x, y + 6], [x + (r() - 0.5) * 8, y + 30]], 1.2, 'rgba(70,60,70,0.3)'); }
      for (let i = 0; i < 90; i++) circ(530 + r() * 186, 672 + r() * 190, 0.6 + r() * 1.4, `rgba(${[200, 90, 60][i % 3]},${[80, 180, 90][i % 3]},${[80, 90, 200][i % 3]},${0.2 + r() * 0.4})`);
    });

    R.shade({ mats: [E.mat({})], shadow: [0, 0, 0, 0] });
    E.draw(E.blur(E.snapshot(), 0.6), 1);
    E.grain(0.03, 19);
  }
});
