'use strict';
// g133 — "Mint paper collage": pinked mint and pink papers scattered with black ink curls, a pale palette
// face, a gold badge, a neon-green frame, a white plastic tray and a zebra-striped wave of cloth on concrete.
REC.register('g133', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, S = E.S;
    const R = E.relief(), a = R.a;
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st, x1 = x, y1 = y) => { const g = a.createRadialGradient(x, y, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const img = (cv, path) => { a.save(); if (path) a.clip(path); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const poly = pts => P(pts, true, false);
    const all = rrect(-10, -10, W + 20, H + 20, 0);

    // ── concrete ground ──
    const concrete = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * .02) * .6 + fbm(p * .09) * .4;
      vec3 c = mix(vec3(.30,.30,.26), vec3(.50,.50,.44), n);
      c *= .8 + .4 * step(.35, hash(floor(p * .7)));
      c = mix(c, vec3(.08), step(.93, fbm(p * .06 + 3.)) * .7);
      return c; }`);
    img(concrete);
    // ── pink paper ──
    R.flat(poly([[52, 0], [240, 0], [240, 600], [420, 860], [400, 905], [260, 950], [0, 965], [0, 215], [28, 205], [42, 150], [48, 60]]), lin(0, 200, 300, 900, [[0, '#f3d5db'], [0.6, '#ecccd3'], [1, '#e2bcc6']]), 0.02, 0);
    // ── mint paper with pinked left edge ──
    const mintEdge = ragged([[100, 470], [96, 600], [60, 620]], 0, 1, 7, 6, 3);
    const mint = P([[343, 0], [726, 0], [726, 1024], [440, 1024], [440, 850], [300, 690], [60, 640], ...mintEdge.reverse(), [112, 450], [150, 300], [104, 281], [118, 263], [147, 248], [165, 222], [169, 187], [187, 159], [239, 113], [252, 91], [245, 76], [254, 61], [298, 34], [320, 31], [322, 15]], true, false);
    R.flat(mint, '#8ebba6', 0.03, 0);
    soft(x => { x.fillStyle = '#98c4ae'; x.fill(ellipseP(420, 520, 200, 260, 0.4)); x.fillStyle = '#82b29c'; x.fill(ellipseP(250, 120, 120, 90, 0)); }, 60, 0.6, 'source-over', mint);
    // big black ink areas
    const blk = '#040507';
    R.flat(P(ragged([[343, 0], [229, 0], [229, 45], [206, 87], [158, 122], [135, 128], [98, 125], [93, 137], [96, 154], [47, 188], [58, 204], [55, 217], [60, 222], [52, 250], [66, 244], [72, 234], [82, 237], [101, 227], [106, 245], [86, 275], [104, 281], [118, 263], [147, 248], [165, 222], [165, 207], [172, 198], [169, 187], [187, 159], [239, 113], [252, 91], [245, 76], [254, 61], [298, 34], [320, 31], [322, 15]], 0, 99, 4, 5, 8), true, false), blk, 0.04, 0);
    R.flat(P(ragged([[715, 279], [699, 282], [691, 272], [680, 274], [666, 289], [670, 344], [661, 351], [649, 344], [635, 348], [647, 374], [610, 403], [606, 422], [608, 436], [632, 459], [642, 458], [696, 422], [736, 426], [736, 297], [716, 294]], 0, 99, 4, 5, 34), true, false), blk, 0.04, 0);
    R.flat(poly([[736, 0], [698, 0], [666, 31], [663, 46], [671, 58], [659, 89], [662, 102], [686, 93], [715, 50], [721, 54], [721, 68], [708, 97], [736, 99]]), blk, 0.04, 0);
    R.flat(P(ragged([[236, 390], [245, 405], [260, 411], [250, 422], [260, 441], [292, 428], [324, 399], [341, 397], [349, 382], [363, 378], [356, 366], [329, 377], [319, 365], [289, 374], [280, 383], [262, 371], [254, 352]], 0, 99, 4, 5, 10), true, false), blk, 0.04, 0);
    R.flat(P(ragged([[359, 506], [340, 519], [323, 523], [310, 518], [293, 550], [281, 546], [272, 554], [262, 552], [259, 572], [241, 577], [240, 588], [252, 588], [258, 596], [280, 596], [293, 607], [287, 630], [272, 636], [271, 643], [296, 635], [307, 609], [298, 592], [300, 580], [360, 517]], 0, 99, 4, 5, 82), true, false), blk, 0.04, 0);
    // ink curls (brushy C-strokes)
    const curl = (cx, cy, r, a0, sw, wd, seed) => {
      const rr = rng(seed);
      a.save(); a.strokeStyle = blk; a.lineCap = 'round';
      for (let k = 0; k < 16; k++) {
        const off = (rr() - 0.5) * wd * 1.25, n = 16; a.lineWidth = 0.8 + rr() * 1.6; a.beginPath();
        for (let i = 0; i <= n; i++) { const t = a0 + sw * (i / n) + (rr() - 0.5) * 0.04, rad = r + off * (0.4 + 0.6 * Math.sin(Math.PI * i / n)); const x = cx + Math.cos(t) * rad, y = cy + Math.sin(t) * rad; i ? a.lineTo(x, y) : a.moveTo(x, y); }
        a.stroke();
      }
      a.lineWidth = wd * 0.55; a.beginPath(); a.arc(cx, cy, r, a0 + sw * 0.08, a0 + sw * 0.92); a.stroke();
      a.restore();
    };
    { const rr = rng(1330);
      const spots = [[378, 42], [332, 96], [262, 132], [303, 168], [228, 208], [198, 262], [270, 262], [350, 300], [222, 330], [170, 396], [222, 420], [300, 330], [408, 400], [460, 368], [520, 392], [570, 345], [640, 330], [330, 460], [250, 470], [160, 470], [460, 470], [420, 510], [200, 560], [130, 600], [330, 590], [340, 650], [280, 690], [420, 560], [575, 22], [500, 12], [430, 20], [640, 190], [565, 400], [620, 410], [520, 30], [190, 520], [380, 470], [110, 530], [600, 300], [150, 360]];
      for (const [x, y] of spots) curl(x + (rr() - 0.5) * 8, y + (rr() - 0.5) * 8, 14 + rr() * 10, rr() * 6.28, 3.4 + rr() * 1.4, 11 + rr() * 4, Math.floor(rr() * 1e5));
      for (let i = 0; i < 26; i++) { const x = 140 + rr() * 480, y = 60 + rr() * 600; a.save(); a.strokeStyle = blk; a.lineWidth = 1 + rr() * 2; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 8 + rr() * 22, y - 5 - rr() * 12); a.stroke(); a.restore(); } }

    // ── neon frame interior: green concrete ──
    const neonPts = [[420, 660], [421, 556], [575, 447], [594, 450], [622, 483], [660, 488], [700, 455], [736, 438]];
    const inner = poly([...neonPts, [736, 740], [640, 760], [520, 720], [430, 690]]);
    const gconc = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * .025) * .6 + fbm(p * .1) * .4;
      vec3 c = mix(vec3(.55,.62,.48), vec3(.74,.80,.66), n);
      c = mix(c, vec3(.32,.36,.28), step(.62, fbm(p * .07 + 9.)) * .6);
      return c; }`);
    img(gconc, inner);
    // light mint triangle frame
    for (const pts of [[[598, 556], [662, 556]], [[662, 556], [604, 656]], [[604, 656], [700, 690]], [[662, 556], [702, 498]], [[702, 498], [736, 494]], [[700, 690], [722, 560]], [[700, 690], [710, 735]]])
      R.pipe(P(pts, false), 11, '#c4ddd0', 0.15, 0.08, 1);

    // ── zebra cloth ──
    const zTop = [[0, 659], [33, 630], [83, 605], [133, 601], [175, 613], [208, 638], [250, 667], [292, 688], [333, 705], [367, 718], [410, 728]];
    const zBot = ragged([[415, 838], [367, 855], [317, 872], [275, 884], [233, 897], [192, 909], [125, 917], [75, 922], [33, 909], [0, 897]], 0, 9, 9, 7, 13);
    const zeb = P([...zTop, ...zBot], true, false);
    const zfx = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 14. * vec2(fbm(p * .012), fbm(p * .012 + 7.)) - 7.;
      vec2 d = q - vec2(-40., 765.);
      float dy = d.y - .04 * d.x;
      float ph = abs(dy) - 113. * log(1. + max(d.x, 0.) / 75.) + 5. * sin(d.x * .025);
      float s = sin(ph * 6.2832 / 30.);
      float e = fwidth(s) + .02;
      return vec3(smoothstep(-e, e, s)) * .96 + .02; }`);
    R.flat(zeb, '#000', 0.08, 0);
    img(zfx, zeb);
    soft(x => { x.fillStyle = '#000'; x.fill(ellipseP(380, 790, 60, 50, 0)); }, 25, 0.25, 'source-over', zeb);

    // ── bottom mint wave panel + concrete + ink splotch ──
    const wave = P([[0, 962], [60, 958], [120, 950], [180, 935], [230, 912], [280, 893], [330, 878], [380, 864], [420, 852], [470, 838], [560, 800], [620, 772], [680, 748], [736, 738], [736, 1034], [0, 1034]]);
    R.dome(wave, '#8ab6a1', 0.06, 0.04, 8, 3);
    R.flat(P([[0, 1034], [0, 1000], [80, 990], [160, 975], [230, 950], [260, 960], [220, 1000], [180, 1034]]), '#a2cab8', 0.1, 0);
    R.flat(poly([[736, 901], [674, 927], [644, 960], [652, 968], [648, 981], [639, 980], [634, 968], [621, 974], [624, 992], [640, 1004], [636, 1034], [736, 1034]]), '#5e5e54', 0.1, 0);
    img(concrete, poly([[736, 901], [674, 927], [644, 960], [652, 968], [648, 981], [639, 980], [634, 968], [621, 974], [624, 992], [640, 1004], [636, 1034], [736, 1034]]));
    R.flat(P(ragged([[671, 931], [663, 920], [634, 917], [628, 904], [603, 898], [592, 903], [584, 921], [570, 909], [555, 908], [532, 942], [514, 935], [467, 951], [460, 963], [471, 981], [439, 994], [431, 1003], [446, 1007], [444, 1034], [475, 1034], [506, 1008], [528, 1034], [636, 1034], [640, 1003], [619, 976], [636, 967]], 0, 24, 8, 6, 31), true, false), blk, 0.1, 0);

    // ── white disc, palette face, peach cloud, star ──
    R.dome(ellipseP(146, 58, 86, 64, -0.12), radg(130, 40, 10, 100, [[0, '#f4f3f1'], [1, '#e2e1de']]), 0.1, 0.12, 14, 1);
    const pal = P([[548, 66], [489, 66], [439, 85], [399, 115], [361, 163], [348, 195], [345, 226], [353, 252], [366, 266], [394, 277], [412, 275], [438, 266], [428, 284], [423, 304], [430, 327], [444, 342], [463, 351], [488, 353], [505, 349], [557, 318], [595, 276], [620, 220], [625, 162], [614, 119], [589, 87]]);
    R.dome(pal, radg(470, 140, 10, 220, [[0, '#d0dfd9'], [1, '#bccdc6']]), 0.12, 0.14, 16, 2);
    R.groove(P([[440, 270], [470, 262], [505, 246], [540, 226], [575, 210], [592, 214], [590, 232]], false), 22, '#9db4b4', 0.26, 0.07, 2, 0.9);
    R.dome(rrect(468, 172, 104, 26, 6), '#8a9898', 0.24, 0.02, 4, 2);
    a.save(); a.translate(520, 185); a.rotate(-0.18); a.translate(-520, -185); R.flat(rrect(474, 178, 92, 12, 4), '#2a3434', 0.24, 2); R.flat(rrect(480, 183, 80, 4, 2), '#e8f0ee', 0.25, 2); a.restore();
    for (const [x, y, r] of [[493, 135, 7], [410, 182, 7], [497, 310, 6]]) R.flat(circleP(x, y, r), '#202828', 0.22, 2);
    R.bead(551, 232, 7, '#b8ccd0', 0.28, 0.05, 2);
    R.dome(poly([[709, 161], [683, 173], [683, 185], [672, 191], [669, 200], [675, 220], [669, 229], [656, 235], [656, 247], [644, 255], [642, 265], [658, 271], [658, 281], [666, 286], [687, 269], [699, 280], [716, 276], [720, 279], [716, 292], [736, 295], [736, 169], [716, 168]]), '#f7d8bb', 0.08, 0.04, 6, 3);

    // ── gold badge ──
    const badge = poly([[16, 344], [160, 312], [184, 326], [170, 452], [152, 470], [20, 472], [6, 458], [8, 360]]);
    R.dome(badge, '#d8f0e0', 0.08, 0.06, 6, 4);
    const bIn = poly([[26, 352], [154, 324], [170, 334], [158, 446], [146, 458], [26, 460], [16, 450], [18, 364]]);
    R.flat(bIn, '#0a0806', 0.14, 3);
    R.pipe(circleP(88, 388, 30), 8, '#d8b050', 0.14, 0.06, 2);
    R.pipe(circleP(88, 388, 16), 6, '#e0c060', 0.14, 0.05, 2);
    R.bead(88, 388, 8, '#c8a040', 0.14, 0.06, 2);
    for (const [x, y] of [[78, 380], [96, 380], [88, 398]]) R.bead(x, y, 4, '#f0d070', 0.2, 0.03, 2);
    R.pipe(P([[118, 360], [140, 340], [150, 350], [130, 440]], false), 5, '#d8b050', 0.14, 0.05, 2);
    R.pipe(P([[40, 400], [50, 430], [80, 440], [110, 430]], false), 5, '#40d070', 0.14, 0.05, 4);
    R.flat(rrect(40, 440, 60, 10, 2), '#c8a848', 0.15, 2);

    // ── neon tube ──
    R.pipe(P(neonPts, false, false), 24, '#f4fff4', 0.22, 0.08, 7);

    // ── white plastic tray ──
    a.save(); a.translate(497, 724); a.rotate(-0.56);
    const tray = rrect(-112, -85, 224, 170, 22), win = rrect(-96, -70, 192, 140, 6);
    a.restore();
    const T = new DOMMatrix().translate(497, 724).rotate(-0.56 * 180 / Math.PI);
    const trayP = new Path2D(); trayP.addPath(tray, T);
    const winP = new Path2D(); winP.addPath(win, T);
    R.dome(trayP, '#ece2de', 0.12, 0.2, 14, 1);
    const glass = E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * .05) * .5 + vnoise(p * .4) * .5; return mix(vec3(.44,.50,.50), vec3(.62,.68,.68), n); }`);
    R.flat(winP, '#7a8888', 0.22, 2); img(glass, winP);
    const bar = (x0, y0, x1, y1, wd) => { const p0 = T.transformPoint(new DOMPoint(x0, y0)), p1 = T.transformPoint(new DOMPoint(x1, y1)); R.pipe(P([[p0.x, p0.y], [p1.x, p1.y]], false), wd, '#f0e8e4', 0.3, 0.08, 1); };
    bar(-30, -70, -30, 70, 9); bar(40, -70, 40, 70, 9); bar(-96, 10, 96, 10, 9); bar(-96, -40, -30, -40, 6);
    { const c = T.transformPoint(new DOMPoint(5, 12)); R.dome(circleP(c.x, c.y, 22), '#f0eae8', 0.32, 0.14, 12, 1); }
    R.pipe(P([[624, 668], [652, 672], [668, 700], [662, 725], [640, 742], [612, 760], [590, 790], [565, 800], [540, 795], [530, 815], [548, 832], [580, 828], [600, 812]], false), 13, '#eee2e0', 0.3, 0.12, 1);

    // ── pearls ──
    for (const [x, y, r] of [[183, 208, 8], [268, 165, 8], [310, 122, 8], [330, 245, 6], [320, 295, 7], [400, 128, 7], [423, 72, 6], [486, 22, 9], [531, 33, 7], [387, 368, 7], [290, 465, 7], [193, 550, 7], [288, 668, 7], [68, 518, 15], [52, 563, 15], [25, 630, 14], [10, 665, 12], [33, 942, 17], [100, 945, 17], [162, 927, 17], [242, 913, 17], [8, 940, 12], [345, 610, 6]])
      R.bead(x, y, r, radg(x - r * 0.3, y - r * 0.3, 1, r * 1.3, [[0, '#ffffff'], [1, '#e0dcd8']]), 0.12, Math.min(0.3, r * 0.02 + 0.05), 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.5, ao: 0.5, coat: 0.05 }),                    // 1 white plastic / pearls
        E.mat({ dif: 1, spec: 0.5, shin: 36, wrap: 0.45, ao: 0.4 }),                                // 2 pale palette plastic
        E.mat({ dif: 1, spec: 0.15, shin: 12, wrap: 0.6, ao: 0.3 }),                                // 3 paper
        E.mat({ dif: 0.7, spec: 0.9, shin: 50, wrap: 0.4, ao: 0.3, emis: 0.15 }),                    // 4 enamel / glow edge
        E.mat({}), E.mat({}),
        E.mat({ dif: 0.5, emis: 0.7, spec: 0.6, shin: 30, wrap: 0.5 })                               // 7 neon
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.55, 0.55, 0.55], amb: [0.55, 0.56, 0.56],
      envTop: [1, 1, 1], envHor: [0.6, 0.65, 0.62], envBot: [0.2, 0.22, 0.2], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0, 0, 0], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-7, 8, 0.45, 6]
    });

    // ── neon glow + sparkle ──
    const o = E.out;
    const glow = (path, col, wd, blur, al) => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; x.strokeStyle = col; x.lineWidth = wd; x.stroke(path); const b1 = E.blur(c, blur), b2 = E.blur(c, blur * 2.5); o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = al; o.drawImage(b2, 0, 0); o.drawImage(b1, 0, 0); o.globalAlpha = 1; o.drawImage(b1, 0, 0); o.restore(); };
    glow(P(neonPts, false, false), '#4cf050', 30, 12, 0.8);
    o.save(); o.lineCap = o.lineJoin = 'round'; o.strokeStyle = '#d8f8d8'; o.lineWidth = 22; o.stroke(P(neonPts, false, false)); o.strokeStyle = '#fbfffb'; o.lineWidth = 14; o.stroke(P(neonPts, false, false)); o.restore();
    { const g = o.createRadialGradient(652, 60, 0, 652, 60, 40); g.addColorStop(0, 'rgba(255,240,210,0.9)'); g.addColorStop(1, 'rgba(255,220,180,0)'); o.fillStyle = g; o.fillRect(600, 10, 110, 100);
      o.fillStyle = '#fbe6c4'; o.fill(P(star(652, 60, 4, 50, 4, -Math.PI / 4), true, false)); o.fill(P(star(652, 60, 3, 24, 4, 0), true, false)); }
    E.grain(0.035, 133);
  }
});
