'use strict';
// u025 — "Chrome saucer reverie": a retro-futurist airbrush dream — a zebra-chrome dome and red-tubed chrome
// engine plunge into a pale blue ghost, a jellyfish UFO hangs over striped grey towers, a pink star wheel below.
REC.register('u025', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const fill = (path, c) => { a.fillStyle = c; a.fill(path); };
    const stroke = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const speck = (path, x0, y0, w, h, n, col, seed, sz = 1.6) => clipA(path, () => { const r = rng(seed); a.fillStyle = col; for (let i = 0; i < n; i++) a.fillRect(x0 + r() * w, y0 + r() * h, sz, sz); });

    // ── textures ──
    const BLD = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float y = p.y - p.x * .06 + 3. * sin(p.x * .01);
        float b = fract(y / 15.), k = floor(y / 15.);
        vec3 c = mix(vec3(.47, .46, .5), vec3(.6, .59, .63), step(.5, b));
        c = mix(c, vec3(.38, .37, .41), step(.88, b));
        c *= .92 + .16 * hash(vec2(k, 3.));
        c += (hash(floor(p / 1.5)) - .5) * .08;
        return c; }`);
    const ZEB = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float ph;
        if (p.x < 300.) { vec2 d = p - vec2(255., 250.); ph = atan(d.y, -d.x) * 5.5 + length(d) * .012 + 1.2 * fbm(p * .015); }
        else ph = (p.x * .25 - p.y * .9) / 10. + 1.6 * fbm(p * vec2(.03, .08));
        float v = sin(6.2832 * ph) + (p.x < 300. ? .5 : .6);
        return mix(vec3(.05), vec3(.97), smoothstep(-.2, .2, v)); }`);

    // ── sky, towers, ribbons ──
    fill(poly([[0, 0], [726, 0], [726, 1024], [0, 1024]]), lin(0, 0, 0, 160, [[0, '#223e96'], [1, '#2a4ea4']]));
    clipA(poly([[0, 460], [726, 460], [726, 1024], [0, 1024]]), () => img(BLD));
    for (const [x, y, h] of [[140, 60, 58], [222, 38, 52], [395, 46, 48], [470, 30, 44]]) {
      fill(sm([[x, y - h * 0.62], [x + 22, y - 10], [x + 18, y + h * 0.5], [x, y + h * 0.62], [x - 18, y + h * 0.5], [x - 22, y - 10]]), '#ab8c98');
      stroke(P([[x, y - h * 0.55], [x, y + h * 0.6]], false), '#c0303e', 3);
    }
    const TOW = poly([[0, 168], [60, 150], [150, 118], [240, 6], [300, 0], [330, 0], [330, 140], [375, 118], [430, 75], [480, 48], [570, 20], [640, 0], [726, 0], [726, 460], [0, 460]]);
    clipA(TOW, () => img(BLD));
    for (const [x, y, w] of [[185, 117, 64], [455, 95, 70], [140, 182, 60], [395, 182, 65], [640, 44, 120], [636, 152, 90], [670, 218, 56], [360, 360, 30], [650, 380, 70]]) { fill(rrect(x, y, w, 7, 1), '#b8d8f0'); for (let k = 1; k < w / 14; k++) stroke(P([[x + k * 14, y], [x + k * 14, y + 7]], false), '#7890a8', 1); }
    fill(rrect(258, 140, 12, 30, 1), '#c8e0f4'); fill(rrect(640, 152, 8, 18, 0), '#2050c0'); fill(rrect(705, 275, 22, 30, 0), '#a03060');
    // left dark corner with violet speckle
    fill(poly([[0, 168], [60, 150], [60, 350], [0, 360]]), '#1c191e');
    speck(poly([[0, 200], [50, 190], [50, 260], [0, 270]]), 0, 190, 50, 80, 300, '#8a5aa0', 3, 2);
    // cream and blue ribbons
    R.pipe(P([[312, 0], [322, 40], [344, 80], [356, 110], [340, 140], [322, 180], [318, 220], [330, 256], [370, 285], [420, 300]], false), 16, '#f2eacc', 0.05, 0.02, 0);
    R.pipe(P([[406, 82], [380, 100], [352, 126], [334, 170], [330, 214], [342, 252], [380, 280], [430, 296]], false), 14, '#7aaee8', 0.05, 0.02, 0);
    R.pipe(P([[300, 0], [310, 40], [330, 74], [340, 100]], false), 8, '#7aaee8', 0.05, 0.02, 0);
    // right-side orange and blue bands behind the jellyfish
    fill(poly([[600, 438], [726, 448], [726, 478], [600, 466]]), '#e8962e');
    fill(poly([[600, 466], [726, 478], [726, 500], [600, 490]]), '#f2eacc');
    fill(poly([[600, 490], [726, 500], [726, 540], [600, 530]]), '#88b0e0');

    // ── jellyfish column under the UFO ──
    const JC = sm([[408, 270], [470, 262], [560, 262], [660, 290], [652, 340], [650, 420], [660, 520], [690, 610], [640, 650], [560, 660], [470, 640], [420, 560], [410, 420], [412, 340]]);
    fill(JC, '#c6b8a6');
    clipA(JC, () => {
      for (const [x0, x1, c] of [[440, 470, '#a49c9e'], [575, 595, '#9a9496'], [600, 618, '#efe2c2'], [620, 640, '#4a4850'], [524, 534, '#efe2c2']]) fill(poly([[x0, 270], [x1, 270], [x1 + 20, 660], [x0 + 20, 660]]), c);
      speck(JC, 410, 270, 280, 390, 1400, '#6a6878', 9, 1.6);
      const OR = poly([[484, 276], [562, 274], [556, 402], [498, 404]]);
      fill(OR, '#ea8238');
      clipA(OR, () => { for (let y = 280; y < 404; y += 7) stroke(P([[480, y], [566, y - 2]], false), '#c86a28', 2); });
      for (let i = 0; i < 9; i++) stroke(P([[440 + i * 24, 300], [446 + i * 26, 420], [440 + i * 28, 560]], false), 'rgba(250,240,210,0.5)', 3);
    });
    // UFO legs
    stroke(P([[668, 320], [726, 420]], false), '#e8e4dc', 4); stroke(P([[660, 330], [664, 600]], false), '#e8e4dc', 4);

    // ── blue skirt with white streaks ──
    const SK = sm([[300, 610], [420, 650], [540, 650], [640, 630], [700, 600], [726, 620], [726, 780], [640, 770], [560, 790], [460, 800], [380, 790], [330, 740]]);
    fill(SK, lin(0, 600, 0, 790, [[0, '#9ab8e4'], [0.5, '#7096cc'], [1, '#8aaad8']]));
    clipA(SK, () => {
      const sr = rng(41);
      for (let i = 0; i < 70; i++) { const x = 300 + sr() * 420, y = 600 + sr() * 120, L = 30 + sr() * 70; a.globalAlpha = 0.6; stroke(P([[x, y], [x + (sr() - 0.5) * 10, y + L * 0.5], [x + (sr() - 0.5) * 16, y + L]], false), '#eef4fa', 1.5 + sr() * 1.5); }
      a.globalAlpha = 1; speck(SK, 300, 600, 420, 200, 900, '#2a4a8a', 12, 1.8);
    });

    // ── pale blue ghost ──
    const GH = sm([[0, 345], [20, 312], [50, 282], [100, 268], [200, 265], [262, 268], [300, 320], [312, 420], [330, 452], [300, 480], [292, 560], [330, 610], [380, 640], [392, 700], [380, 780], [344, 782], [311, 792], [267, 792], [222, 802], [178, 802], [144, 797], [111, 769], [100, 747], [33, 724], [0, 708]]);
    fill(GH, '#a0b8e0');
    clipA(GH, () => {
      soft(x => { x.fillStyle = '#c0bcc8'; x.fill(sm([[20, 300], [120, 268], [262, 270], [300, 330], [300, 450], [200, 470], [80, 450], [20, 400]])); }, 20, 0.95);
      soft(x => { x.fillStyle = '#6c9ce0'; x.fill(sm([[0, 380], [50, 400], [70, 480], [60, 560], [0, 580]])); }, 16, 0.9);
      soft(x => { x.fillStyle = '#f2e6c8'; x.fill(sm([[150, 440], [250, 420], [300, 470], [310, 560], [300, 700], [250, 720], [200, 660], [140, 560], [130, 480]])); }, 22, 1);
      soft(x => { x.fillStyle = '#d8ccc0'; x.fill(ellipseP(220, 400, 70, 40, 0)); }, 20, 0.7);
      const LB = sm([[0, 560], [60, 548], [130, 552], [162, 578], [168, 618], [184, 634], [200, 600], [222, 592], [240, 612], [232, 660], [252, 700], [300, 716], [336, 700], [364, 760], [346, 792], [300, 796], [260, 802], [180, 804], [140, 796], [100, 760], [30, 726], [0, 712]]);
      soft(x => { x.fillStyle = '#7aa2dc'; x.fill(LB); }, 3, 1);
      soft(x => { x.fillStyle = '#a8c6f0'; x.fill(sm([[20, 590], [100, 580], [150, 610], [170, 660], [220, 680], [260, 730], [300, 760], [240, 785], [160, 780], [90, 740], [30, 700]])); }, 16, 1);
      soft(x => { x.fillStyle = '#8eb0e4'; x.fill(sm([[300, 560], [360, 600], [390, 680], [380, 780], [330, 720], [300, 640]])); }, 14, 0.9);
      const wr = rng(17); a.globalAlpha = 0.55;
      for (let i = 0; i < 26; i++) { const x = wr() * 70, y = 400 + wr() * 170; stroke(P([[x, y], [x + 30 + wr() * 30, y - 8 - wr() * 10]], false), '#eef4fc', 2 + wr() * 2); }
      for (let i = 0; i < 26; i++) { const x = 300 + wr() * 80, y = 560 + wr() * 150; stroke(P([[x, y], [x + 4, y + 24 + wr() * 20]], false), '#eef4fc', 1.5 + wr() * 1.5); }
      a.globalAlpha = 1;
      soft(x => { x.fillStyle = '#ff8a50'; x.fill(circleP(108, 378, 24)); }, 10, 0.9);
      speck(sm([[0, 280], [300, 280], [300, 470], [0, 470]]), 0, 260, 320, 220, 1300, '#2a3040', 5, 1.6);
      speck(sm([[0, 470], [140, 470], [120, 600], [0, 640]]), 0, 470, 140, 180, 300, '#1a3070', 6, 1.8);
      speck(sm([[290, 540], [400, 540], [400, 800], [290, 800]]), 290, 540, 110, 260, 300, '#1a3070', 7, 1.8);
      speck(GH, 0, 260, 400, 560, 160, '#20242c', 8, 2);
      soft(x => { const r = rng(6); x.fillStyle = '#fff4d8'; for (let i = 0; i < 30; i++) x.fill(circleP(200 + r() * 70, 360 + r() * 60, 3 + r() * 3)); }, 2, 0.8);
    });
    R.dome(circleP(193, 368, 16), '#e8b040', 0.1, 0.04, 4, 3);
    R.dome(circleP(193, 368, 12), '#0a0a0c', 0.14, 0.02, 3, 2);

    // ── saucer: halo, red ring and dark underside ──
    soft(x => { x.fillStyle = '#f2e6c4'; x.fill(ellipseP(468, 535, 212, 112, 0.164)); }, 10, 0.95);
    R.dome(ellipseP(465, 517, 171, 79, 0.164), '#741418', 0.1, 0.08, 14, 4);
    R.dome(ellipseP(455, 503, 140, 58, 0.164), '#4c4856', 0.18, 0.06, 10, 4);
    clipA(ellipseP(560, 540, 50, 26, 0.3), () => { fill(ellipseP(560, 540, 50, 26, 0.3), '#40a050'); fill(ellipseP(566, 536, 30, 14, 0.3), '#e8e0d0'); });
    R.dome(poly([[640, 540], [660, 552], [666, 580], [646, 578]]), '#d8a830', 0.2, 0.04, 4, 3);
    R.dome(rrect(532, 598, 40, 34, 4), '#d8a830', 0.2, 0.04, 4, 3);

    // ── UFO dome and zebra brim ──
    R.dome(P([[438, 262], [442, 222], [462, 192], [500, 172], [545, 165], [592, 172], [628, 194], [650, 230], [656, 268]]), '#f0f0f4', 0.2, 0.3, 60, 6);
    soft(x => { x.fillStyle = 'rgba(40,40,50,0.55)'; x.fill(ellipseP(612, 225, 6, 22, 0.1)); x.fill(ellipseP(468, 225, 6, 18, -0.4)); x.fill(ellipseP(560, 255, 60, 6, 0.1)); }, 4, 1);
    for (const [x, y] of [[536, 214], [548, 214], [560, 214]]) R.dome(rrect(x - 3, y - 12, 6, 24, 3), '#18181e', 0.5, 0.02, 2, 2);
    for (const [x, y] of [[490, 178], [528, 170], [570, 172]]) R.dome(ellipseP(x, y, 8, 3, 0.1), '#28282e', 0.5, 0.01, 2, 2);
    const BRIM = new Path2D(); BRIM.addPath(ellipseP(552, 284, 158, 34, 0.2)); BRIM.addPath(ellipseP(546, 276, 128, 14, 0.2));
    clipAH(ellipseP(552, 284, 158, 34, 0.2), () => {
      a.save(); a.clip(BRIM, 'evenodd'); R.h.save(); R.h.clip(BRIM, 'evenodd');
      R.dome(ellipseP(552, 284, 158, 34, 0.2), null, 0.25, 0.12, 14, 5); img(ZEB);
      a.restore(); R.h.restore();
    });
    // red antenna
    R.dome(poly([[500, 246], [514, 248], [614, 0], [606, 0]]), '#d81a1a', 0.3, 0.06, 4, 5);

    // ── zebra chrome dome with red bow ──
    const ZD = sm([[44, 196], [64, 166], [112, 148], [180, 144], [230, 160], [262, 198], [270, 238], [252, 262], [200, 272], [120, 274], [60, 268], [44, 240]]);
    R.dome(ZD, null, 0.15, 0.2, 40, 5);
    clipA(ZD, () => img(ZEB));
    R.dome(sm([[30, 172], [60, 150], [90, 160], [100, 190], [80, 214], [44, 208]]), '#f4f0f0', 0.2, 0.1, 14, 1);
    R.dome(sm([[0, 70], [34, 132], [46, 150], [60, 140], [66, 90], [52, 30], [42, 110]]), '#dd1a1a', 0.12, 0.06, 6, 1);
    R.dome(sm([[0, 140], [30, 150], [50, 162], [40, 132], [0, 120]]), '#dd1a1a', 0.12, 0.06, 6, 1);
    R.dome(circleP(46, 156, 10), '#cc1414', 0.2, 0.06, 6, 1);
    R.pipe(P([[60, 262], [30, 250], [10, 264]], false), 12, '#e8e8ec', 0.18, 0.08, 5);

    // ── chrome engine: red tube, knurled barrel, grey body and disc ──
    R.pipe(P([[230, 252], [300, 322]], false), 24, '#c41420', 0.2, 0.2, 5);
    R.pipe(P([[206, 236], [234, 262]], false), 36, '#a8a8b0', 0.2, 0.2, 5);
    const BAR = poly([[262, 344], [314, 292], [410, 376], [358, 430]]);
    R.dome(BAR, '#c4c4cc', 0.2, 0.25, 26, 5);
    clipA(BAR, () => { for (let i = 0; i < 46; i++) stroke(P([[250 + i * 4, 290], [250 + i * 4 - 40, 440]], false), 'rgba(60,60,70,0.35)', 1); for (let i = 0; i < 30; i++) stroke(P([[240, 300 + i * 5], [420, 260 + i * 5 + 170]], false), 'rgba(60,60,70,0.3)', 1); });
    R.pipe(P([[258, 342], [314, 286]], false), 12, '#b01820', 0.32, 0.08, 5);
    R.pipe(P([[352, 428], [408, 372]], false), 14, '#b01820', 0.32, 0.08, 5);
    R.dome(sm([[370, 380], [420, 380], [470, 400], [490, 440], [460, 466], [400, 460], [340, 450], [330, 420]]), '#86868e', 0.2, 0.2, 30, 5);
    R.dome(ellipseP(496, 466, 86, 72, 0.1), '#8c8c94', 0.2, 0.12, 20, 5);
    R.dome(ellipseP(498, 468, 38, 30, 0.1), '#8a5432', 0.32, 0.03, 4, 4);
    R.dome(ellipseP(498, 468, 26, 20, 0.1), '#9a9aa2', 0.34, 0.02, 4, 5);
    R.bead(498, 466, 3, '#101014', 0.36, 0.01, 2);
    // liquid chrome arm
    R.pipe(P([[132, 548], [134, 506], [152, 482], [200, 468], [270, 466], [330, 460], [372, 446]], false), 24, '#b8b8c0', 0.22, 0.2, 5);
    R.dome(ellipseP(136, 530, 16, 26, 0), '#c0c0c8', 0.22, 0.15, 10, 5);
    // chrome rivets
    for (const [x, y, r] of [[395, 323, 9], [455, 359, 8], [427, 368, 7], [306, 552, 8], [312, 568, 6], [403, 570, 10], [457, 650, 13], [486, 738, 13], [543, 763, 12], [455, 766, 10], [512, 625, 9], [420, 1004, 10], [440, 1012, 8]]) R.bead(x, y, r, y === 766 ? '#d0a040' : '#b8b8c4', 0.4, 0.12, 5);

    // ── star wheel (bottom left) ──
    const WH = ellipseP(190, 950, 300, 168, 0.06);
    R.dome(WH, '#a4a4ac', 0.06, 0.08, 30, 1);
    clipA(WH, () => {
      fill(ellipseP(180, 945, 262, 138, 0.06), '#2a2a30');
      clipA(ellipseP(180, 945, 262, 138, 0.06), () => { for (let i = 0; i < 90; i++) { const t = i / 90 * Math.PI * 2; stroke(P([[180 + Math.cos(t) * 200, 945 + Math.sin(t) * 105], [180 + Math.cos(t) * 270, 945 + Math.sin(t) * 145]], false), '#b0b0b8', 4); } });
      fill(ellipseP(178, 950, 222, 116, 0.06), '#c0c2cc');
      fill(ellipseP(176, 955, 200, 102, 0.06), '#9a6a8a');
      speck(ellipseP(176, 955, 200, 102, 0.06), 0, 850, 380, 180, 2500, '#5a3a5a', 14, 1.8);
      fill(ellipseP(176, 955, 140, 66, 0.06), 'rgba(220,150,190,0.35)');
    });
    soft(x => { x.fillStyle = '#e8a030'; x.fill(sm([[380, 860], [420, 880], [455, 930], [460, 980], [430, 1010], [440, 960], [420, 910]])); }, 1, 1);
    const ST = star(158, 915, 26, 150, 6, -0.2).map(([x, y]) => [x, 915 + (y - 915) * 0.8]);
    R.dome(poly(ST), '#c8d8ec', 0.14, 0.04, 6, 1);
    R.dome(poly(star(158, 915, 20, 135, 6, -0.2).map(([x, y]) => [x, 915 + (y - 915) * 0.8])), '#eeb0c8', 0.16, 0.03, 5, 1);
    R.bead(158, 915, 10, '#e8e0e8', 0.22, 0.04, 1);
    // ground left: stripes and orange band
    clipA(poly([[0, 712], [120, 750], [140, 790], [0, 790]]), () => img(BLD));
    fill(poly([[0, 782], [130, 790], [126, 800], [0, 796]]), '#e8962e');
    fill(poly([[300, 800], [400, 812], [470, 850], [400, 840]]), '#e8962e');

    // ── orange flame, black space ──
    fill(poly([[590, 850], [726, 840], [726, 1024], [600, 1024]]), '#060406');
    speck(poly([[590, 850], [726, 840], [726, 1024], [600, 1024]]), 590, 840, 140, 190, 30, '#f0f0f0', 33, 2);
    R.dome(circleP(632, 975, 17), '#e8e0e4', 0.1, 0.08, 6, 1); R.dome(circleP(632, 975, 9), '#141014', 0.16, 0.01, 3, 2);
    R.dome(sm([[726, 530], [700, 560], [700, 620], [680, 680], [640, 700], [596, 740], [560, 800], [552, 850], [600, 890], [660, 880], [726, 850]]), '#f27242', 0.1, 0.06, 20, 1);
    soft(x => { x.fillStyle = '#ffe0d0'; x.fill(ellipseP(712, 600, 14, 40, 0)); x.fill(ellipseP(620, 860, 50, 14, -0.2)); x.fill(ellipseP(680, 770, 30, 10, -0.5)); }, 8, 0.8);
    // grey machine under the figure
    R.dome(sm([[470, 960], [560, 940], [620, 980], [620, 1024], [470, 1024]]), '#b0aeb8', 0.06, 0.06, 14, 1);

    // ── pale blue figure with purple bows ──
    const FG = sm([[392, 582], [405, 575], [420, 600], [440, 630], [470, 630], [497, 612], [530, 612], [558, 630], [555, 650], [530, 670], [512, 700], [510, 740], [520, 775], [545, 792], [600, 820], [640, 850], [645, 900], [632, 940], [615, 982], [565, 1002], [515, 1002], [500, 965], [495, 900], [470, 860], [436, 820], [412, 792], [398, 760], [402, 700], [390, 645]]);
    R.dome(FG, lin(390, 0, 640, 0, [[0, '#8eaee0'], [0.3, '#d2def0'], [0.7, '#e0e8f4'], [1, '#a8c0e4']]), 0.1, 0.14, 26, 1);
    const bow = pts => { const cx = pts.reduce((t, q) => t + q[0], 0) / pts.length, cy = pts.reduce((t, q) => t + q[1], 0) / pts.length; R.dome(poly(pts.map(([x, y]) => [cx + (x - cx) * 1.15, cy + (y - cy) * 1.15])), '#6a1a56', 0.3, 0.03, 4, 1); };
    bow([[388, 530], [397, 559], [410, 563], [419, 548], [444, 558], [421, 571], [423, 586], [494, 601], [509, 582], [498, 559], [527, 536], [472, 520], [397, 520]]);
    bow([[328, 573], [330, 581], [319, 589], [325, 597], [316, 607], [320, 617], [309, 625], [306, 656], [341, 632], [379, 622], [378, 659], [398, 668], [388, 596], [375, 589], [385, 578]]);
    bow([[382, 863], [482, 884], [474, 908], [490, 939], [504, 937], [505, 922], [524, 903], [520, 893], [507, 897], [506, 884], [491, 888], [499, 878], [487, 869], [497, 862], [466, 842], [466, 830], [453, 816]]);
    bow([[490, 818], [504, 843], [501, 850], [527, 860], [537, 826], [552, 862], [564, 854], [587, 855], [597, 830], [575, 826], [558, 834], [565, 808], [580, 797], [532, 791], [524, 805], [510, 804]]);
    bow([[647, 886], [611, 868], [600, 877], [564, 882], [556, 894], [615, 926], [618, 895], [636, 895]]);
    for (const [x, y, r] of [[457, 650, 13], [486, 738, 13], [543, 763, 12], [456, 766, 10], [512, 625, 9]]) R.bead(x, y, r, y === 766 ? '#d0a040' : '#c0c0cc', 0.4, 0.12, 5);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.6, ao: 0.3 }),               // 1 airbrushed matte
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.2, coat: 0.3 }),              // 2 black gloss
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.3, coat: 0.2 }),              // 3 gold ring
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.3, coat: 0.15 }),             // 4 painted metal
        E.mat({ dif: 0.6, spec: 1.3, shin: 90, metal: 0.55, coat: 0.3 }),          // 5 chrome
        E.mat({ dif: 1, spec: 1.2, shin: 70, wrap: 0.5, coat: 0.25 }),             // 6 white gloss
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.5, 0.52],
      envTop: [1, 1, 1], envHor: [0.78, 0.78, 0.82], envBot: [0.15, 0.15, 0.18], envK: [0.4, 1.2, 0, 0],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-4, 6, 0.4, 8]
    });
    E.grain(0.03, 5);
  }
});
