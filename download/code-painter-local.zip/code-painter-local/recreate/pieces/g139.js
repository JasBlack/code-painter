'use strict';
// g139 — "Zebra tunnel card": a gold-framed card — a black-and-white zebra tunnel swirling into the dark, a blue sky
// corner, a white spotted capsule and a coral-caged white box glowing red inside, red ribbons, a rainbow and stars.
REC.register('g139', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true);
    const op = pts => P(pts, false, true);
    // white coral: recursive branching tubes
    const coral = (x, y, ang, len, wd, depth, r, h0 = 0.3) => {
      const x1 = x + Math.cos(ang) * len, y1 = y + Math.sin(ang) * len;
      R.pipe(P([[x, y], [x + Math.cos(ang) * len * 0.5 + (r() - 0.5) * 4, y + Math.sin(ang) * len * 0.5 + (r() - 0.5) * 4], [x1, y1]], false, true), wd, '#f2f2f4', h0, 0.08, 2);
      if (depth === 0) R.bead(x1, y1, wd * 0.6, '#f6f6f8', h0, 0.06, 2);
      if (depth > 0) { const n = r() < 0.6 ? 2 : 3; for (let i = 0; i < n; i++) coral(x1, y1, ang + (i - (n - 1) / 2) * 0.7 + (r() - 0.5) * 0.4, len * (0.6 + r() * 0.2), wd * 0.85, depth - 1, r, h0); }
    };

    // ── card border gradient ──
    img(E.fx(`
      vec3 h(float x){ return vec3(float((int(x) >> 16) & 255), float((int(x) >> 8) & 255), float(int(x) & 255)) / 255.; }
      vec3 gl(float t){ float A[7] = float[7](0.00, 0.20, 0.40, 0.60, 0.75, 0.88, 1.00); vec3 C[7] = vec3[7](h(16445387.), h(16511404.), h(16511628.), h(16443249.), h(16564314.), h(16544321.), h(16525852.)); vec3 c = C[0]; for (int i = 1; i < 7; i++) c = mix(c, C[i], smoothstep(A[i - 1], A[i], t)); return c; }
      vec3 gt(float t){ float A[7] = float[7](0.00, 0.30, 0.50, 0.65, 0.80, 0.90, 1.00); vec3 C[7] = vec3[7](h(16445387.), h(16183977.), h(15003055.), h(13557176.), h(11453373.), h(8953263.), h(6847646.)); vec3 c = C[0]; for (int i = 1; i < 7; i++) c = mix(c, C[i], smoothstep(A[i - 1], A[i], t)); return c; }
      vec3 gr(float t){ float A[7] = float[7](0.00, 0.20, 0.40, 0.50, 0.60, 0.70, 1.00); vec3 C[7] = vec3[7](h(6847646.), h(5529983.), h(5589393.), h(6633639.), h(8007609.), h(13115344.), h(14160859.)); vec3 c = C[0]; for (int i = 1; i < 7; i++) c = mix(c, C[i], smoothstep(A[i - 1], A[i], t)); return c; }
      vec3 gb(float t){ float A[7] = float[7](0.00, 0.20, 0.42, 0.56, 0.70, 0.84, 1.00); vec3 C[7] = vec3[7](h(16524311.), h(16319745.), h(16584276.), h(15866491.), h(12523424.), h(10556592.), h(14488796.)); vec3 c = C[0]; for (int i = 1; i < 7; i++) c = mix(c, C[i], smoothstep(A[i - 1], A[i], t)); return c; }
      vec3 fx(vec2 uv, vec2 p){
        float dl = p.x, dr = 726. - p.x, dt = p.y, db = 1024. - p.y;
        vec3 c = gl(uv.y); float d = dl;
        if (dr < d) { d = dr; c = gr(uv.y); }
        if (dt < d) { d = dt; c = gt(uv.x); }
        if (db < d) { d = db; c = gb(uv.x); }
        return c; }`));
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    // panel with notched corners (gold rim)
    const panelPath = (x0, y0, x1, y1, rr) => {
      const p = new Path2D();
      p.moveTo(x0 + rr, y0); p.lineTo(x1 - rr, y0); p.arc(x1, y0, rr, Math.PI, Math.PI / 2, true);
      p.lineTo(x1, y1 - rr); p.arc(x1, y1, rr, -Math.PI / 2, Math.PI, true);
      p.lineTo(x0 + rr, y1); p.arc(x0, y1, rr, 0, -Math.PI / 2, true);
      p.lineTo(x0, y0 + rr); p.arc(x0, y0, rr, Math.PI / 2, 0, true); p.closePath(); return p;
    };
    const rim = panelPath(18, 34, 708, 990, 40), panel = panelPath(23, 39, 703, 985, 36);
    R.dome(rim, '#e6bc6c', 0.06, 0.04, 3, 2);

    // ── zebra field: a fitted tunnel flow (top) and a wavy flow (bottom left) ──
    R.flat(panel, null, 0.04, 0);
    clipA(panel, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = (p.x - 363.) / 512., v = (p.y - 512.) / 512.;
      float th = (mod(atan(p.y - 121., p.x - 368.) - 0.6, 6.28318) + 0.6) / 6.28318;
      float pT = -22. + 10.97612 +57.12451*th +40.09107*u +7.57274*v +58.74601*u*u +18.62905*u*v +11.61290*v*v +20.86387*u*u*u +21.67759*u*u*v +4.91753*u*v*v +5.56925*v*v*v;
      float pB = -14.86985 -35.76019*u +16.14622*v -18.93285*u*u +33.94246*u*v +56.96688*v*v -34.56863*u*u*u -4.95168*u*u*v +44.84133*u*v*v -84.04649*v*v*v
        -36.88641*u*u*u*u -37.45883*u*u*u*v -13.74178*u*u*v*v -53.58275*u*v*v*v +31.24220*v*v*v*v;
      float w = smoothstep(455., 500., p.y);
      float ph = mix(pT, pB, w);
      float c = cos(6.2832 * ph) - 0.3 * (1. - w);
      float k = 0.9 / max(fwidth(ph) * 6.2832, 1e-3);
      float t = clamp(0.5 + c * min(k, 6.) * 0.5, 0., 1.);
      float fade = smoothstep(130., 20., length((p - vec2(372., 168.)) * vec2(1., 1.3)));
      return mix(vec3(.02, .02, .025), vec3(.97, .97, .96), t * (1. - fade)); }`)));

    // ── black space + blue sky ──
    const space = sm([[330, 150], [400, 136], [450, 190], [510, 236], [706, 470], [706, 990], [430, 990], [380, 920], [330, 870], [290, 830], [256, 770], [246, 700], [252, 600], [244, 470], [254, 340], [290, 240]]);
    clipA(panel, () => { R.flat(space, rad(560, 700, 420, [[0, '#1a1418'], [0.6, '#0c0a0c'], [1, '#050405']], 520, 560), 0.04, 0); clipA(space, () => soft(x => { x.fillStyle = '#6e5e6e'; x.fill(P([[300, 900], [420, 860], [706, 840], [706, 990], [380, 990]], true, false)); }, 40, 0.9)); });
    const sky = sm([[426, 36], [710, 36], [710, 480], [670, 452], [640, 420], [612, 380], [588, 330], [540, 252], [490, 226], [452, 172], [436, 110]]);
    clipA(panel, () => {
      R.flat(sky, lin(450, 40, 700, 300, [[0, '#0858f2'], [0.5, '#0670f6'], [1, '#0a62f0']]), 0.04, 0);
      soft(x => { x.fillStyle = '#2424e6'; x.fill(sm([[700, 150], [640, 190], [560, 214], [520, 240], [600, 330], [650, 420], [710, 470]])); }, 6, 1);
      soft(x => { x.fillStyle = '#3a52e8'; x.fill(sm([[700, 200], [610, 230], [570, 260], [610, 300], [700, 260]])); }, 10, 0.8);
      soft(x => { x.strokeStyle = '#c0207e'; x.lineWidth = 9; x.stroke(op([[466, 76], [486, 112], [514, 140], [546, 152]])); }, 3, 1);
    });
    // spotlight beam (bottom right)
    clipA(panel, () => { soft(x => { x.fillStyle = 'rgba(224,200,216,0.9)'; x.fill(P([[500, 752], [706, 820], [706, 985], [590, 985]], true, false)); }, 26, 0.85); soft(x => { x.fillStyle = 'rgba(255,240,250,0.9)'; x.fill(P([[500, 752], [640, 830], [600, 900]], true, false)); }, 20, 0.6); });
    // stars
    clipA(panel, () => {
      const r = rng(139);
      for (let i = 0; i < 70; i++) { const x = 260 + r() * 446, y = 180 + r() * 800, rr = 1 + r() * 2.5; R.bead(x, y, rr, '#ffffff', 0.06, 0.02, 0); }
      for (const [x, y, rr] of [[322, 48, 6], [665, 255, 7], [530, 190, 4], [298, 258, 6], [382, 312, 6], [296, 552, 9], [352, 606, 5], [367, 672, 9], [668, 492, 8], [672, 638, 8],
        [660, 795, 5], [517, 930, 9], [449, 883, 7], [340, 855, 7], [185, 965, 6], [630, 850, 4], [560, 775, 5], [104, 237, 5], [186, 216, 4], [256, 308, 4], [608, 905, 4], [520, 832, 5], [480, 870, 4]])
        R.bead(x, y, rr, '#ffffff', 0.08, 0.04, 0);
      R.bead(625, 74, 15, rad(620, 70, 15, [[0, '#ffffff'], [1, '#d8dce6']]), 0.08, 0.1, 2);
    });

    // ── red ribbons ──
    { // one S-shaped red ribbon: wide swoosh at the top, narrowing into a streamer down to the left
      const cl = [[236, 98], [300, 104], [360, 118], [416, 144], [460, 182], [484, 226], [470, 258], [430, 284], [380, 308], [320, 334], [260, 358], [206, 374], [164, 384]];
      const wdt = [2, 18, 34, 46, 50, 40, 30, 24, 20, 18, 16, 12, 2];
      const Lp = [], Rp = [];
      for (let i = 0; i < cl.length; i++) { const p0 = cl[Math.max(0, i - 1)], p1 = cl[Math.min(cl.length - 1, i + 1)]; let dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy); dx /= d; dy /= d; const w = wdt[i] / 2;
        Lp.push([cl[i][0] - dy * w, cl[i][1] + dx * w]); Rp.push([cl[i][0] + dy * w, cl[i][1] - dx * w]); }
      R.dome(P([...Lp, ...Rp.reverse()], true, true), lin(240, 100, 480, 380, [[0, '#ff2010'], [0.5, '#e81010'], [1, '#d00808']]), 0.14, 0.1, 12, 2);
    }
    // rainbow band
    const rb = ['#e81818', '#f8d020', '#30c040', '#20c8e0', '#2a60e8', '#7a3ad8'];
    for (let i = 0; i < 6; i++) { const o = i * 7; R.pipe(op([[300 + o, 420 - o * 0.2], [312 + o, 372 - o * 0.4], [350 + o * 0.6, 326 - o * 0.4], [420 + o * 0.3, 292 - o * 0.3]]), 8, rb[i], 0.14, 0.03, 2); }

    // ── black spheres with red rims ──
    const orb = (x, y, r, ring) => {
      R.dome(ellipseP(x, y + r * 0.35, r * 1.05, r * 0.55, 0), '#e01010', 0.12, 0.1, r * 0.3, 2);
      R.bead(x, y, r, rad(x, y, r, [[0, '#2a2a34'], [0.8, '#101016'], [1, '#08080a']], x - r * 0.3, y - r * 0.4), 0.14, 0.3, 2);
      if (ring) { R.dome(circleP(x + r * 0.5, y + r * 0.55, r * 0.32), '#e01010', 0.3, 0.06, 5, 2); R.dome(circleP(x + r * 0.5, y + r * 0.55, r * 0.16), '#ffe8f0', 0.34, 0.03, 3, 2); }
    };
    R.dome(P(lock([[238, 486], [232, 520], [250, 560], [276, 590]], 30, 18)), '#e01010', 0.14, 0.1, 12, 2);

    // ── left capsule ──
    const cap = new Path2D(); cap.addPath(rrect(-172, -78, 344, 156, 72), new DOMMatrix().translate(192, 612).rotate(42));
    for (let k = 0; k < 2; k++) { const r = rng(20 + k); for (let i = 0; i < 8; i++) coral(70 + r() * 60, 470 + r() * 220, Math.PI + (r() - 0.5) * 1.6, 26 + r() * 14, 11, 2, r, 0.12); }
    { const r = rng(31); coral(160, 700, 2.0, 26, 11, 2, r, 0.12); coral(190, 730, 2.3, 24, 10, 2, r, 0.12); coral(118, 470, -2.0, 24, 10, 2, r, 0.12); coral(150, 460, -1.6, 22, 10, 2, r, 0.12); }
    R.dome(cap, lin(140, 520, 80, 640, [[0, '#ffffff'], [0.6, '#f4f4f6'], [1, '#c8cad4']]), 0.2, 0.2, 50, 2);
    clipA(cap, () => soft(x => { x.fillStyle = 'rgba(120,124,150,0.5)'; x.fill(sm([[56, 600], [140, 720], [200, 762], [120, 770], [40, 700]])); }, 30, 0.6));
    { const r = rng(7), dd = []; for (let i = 0; i < 900 && dd.length < 70; i++) { const x = 70 + r() * 270, y = 460 + r() * 300; if (!a.isPointInPath(cap, x * S, y * S) || dd.some(q => Math.hypot(q[0] - x, q[1] - y) < 22)) continue; dd.push([x, y]); R.dome(circleP(x, y, 3.6), '#7a5420', 0.36, 0.01, 1.5, 1); } }
    R.dome(ellipseP(298, 714, 40, 74, 0.73), lin(270, 650, 340, 780, [[0, '#ffffff'], [1, '#d4d6de']]), 0.36, 0.06, 16, 2);
    R.dome(circleP(292, 716, 30), '#e01010', 0.4, 0.06, 8, 2); R.flat(circleP(292, 716, 20), '#120808', 0.42, 0); R.dome(circleP(290, 714, 9), '#ffe0f0', 0.44, 0.03, 4, 2);
    R.dome(circleP(95, 580, 24), '#f2d010', 0.4, 0.05, 7, 2); R.flat(circleP(95, 580, 13), '#0a0a0a', 0.42, 0);

    // ── right box with a coral cage ──
    const net = (path, x0, y0, w, h, n, seed, wd, h0) => {
      const r = rng(seed), pts = [];
      for (let i = 0; i < n * 4 && pts.length < n; i++) { const x = x0 + r() * w, y = y0 + r() * h; if (a.isPointInPath(path, x * S, y * S) && pts.every(q => Math.hypot(q[0] - x, q[1] - y) > 18)) pts.push([x, y]); }
      const seen = new Set();
      for (let i = 0; i < pts.length; i++) {
        const d = pts.map((q, j) => [Math.hypot(q[0] - pts[i][0], q[1] - pts[i][1]), j]).sort((u, v) => u[0] - v[0]);
        for (let k = 1; k <= 3 && k < d.length; k++) {
          const j = d[k][1], key = Math.min(i, j) + ':' + Math.max(i, j); if (seen.has(key) || d[k][0] > 60) continue; seen.add(key);
          const m = [(pts[i][0] + pts[j][0]) / 2 + (r() - 0.5) * 8, (pts[i][1] + pts[j][1]) / 2 + (r() - 0.5) * 8];
          R.pipe(P([pts[i], m, pts[j]], false, true), wd * (0.7 + r() * 0.6), '#f6f6f8', h0, 0.07, 2);
        }
      }
    };
    const top = P([[352, 376], [412, 292], [522, 260], [584, 290], [610, 332], [512, 414], [358, 424]], true, false);
    const front = P([[358, 424], [512, 414], [520, 702], [430, 724], [366, 692], [350, 560]], true, false);
    const side = P([[512, 414], [610, 332], [614, 520], [606, 656], [590, 692], [520, 702]], true, false);
    R.dome(front, '#f4f4f6', 0.16, 0.06, 8, 2);
    const inner = P([[372, 442], [500, 432], [506, 684], [434, 704], [378, 676], [366, 560]], true, false);
    R.flat(inner, lin(370, 440, 500, 700, [[0, '#f83018'], [0.5, '#e81810'], [1, '#c00c0c']]), 0.12, 1);
    clipA(inner, () => {
      soft(x => { x.fillStyle = '#ffa020'; x.fill(ellipseP(440, 540, 46, 110, 0.1)); x.fillStyle = '#ffe080'; x.fill(circleP(420, 470, 16)); }, 18, 0.75);
      a.fillStyle = '#f8e020';
      a.fill(P([[392, 470], [420, 462], [446, 640], [470, 660], [440, 668], [420, 560], [410, 600], [396, 606]], true, false));
      a.fill(circleP(424, 624, 12));
    });
    R.dome(side, lin(510, 400, 610, 700, [[0, '#e8eaf0'], [1, '#b4b8c4']]), 0.16, 0.06, 8, 2);
    clipA(side, () => soft(x => { x.fillStyle = 'rgba(70,50,70,0.6)'; x.fill(sm([[524, 440], [596, 380], [600, 650], [530, 690]])); }, 16, 0.5));
    R.dome(top, lin(360, 270, 600, 410, [[0, '#ffffff'], [1, '#e6e8ee']]), 0.18, 0.06, 10, 2);
    { const r = rng(9), dots = []; for (let i = 0; i < 400 && dots.length < 34; i++) { const x = 368 + r() * 240, y = 270 + r() * 150; if (!a.isPointInPath(top, x * S, y * S) || dots.some(q => Math.hypot(q[0] - x, q[1] - y) < 24)) continue; dots.push([x, y]); R.dome(ellipseP(x, y, 4, 3.4, 0), '#7a5420', 0.22, 0.01, 1.5, 1); } }
    net(inner, 366, 432, 145, 280, 50, 41, 7, 0.24);
    net(side, 512, 330, 104, 372, 30, 42, 7, 0.24);
    { const r = rng(43);
      for (let i = 0; i < 11; i++) coral(604 + r() * 12, 300 + r() * 380, (r() - 0.5) * 1.2, 22 + r() * 10, 11, 2, r, 0.26);
      for (let i = 0; i < 5; i++) coral(500 + r() * 90, 266 + r() * 14, -1.6 + (r() - 0.5) * 0.8, 20, 10, 2, r, 0.26);
      for (let i = 0; i < 4; i++) coral(356 + r() * 10, 440 + r() * 200, Math.PI + (r() - 0.5) * 0.8, 16, 9, 1, r, 0.26);
    }
    R.dome(P(star(504, 462, 10, 4, 8)), '#e02020', 0.34, 0.03, 3, 2);
    orb(458, 262, 38, false); orb(218, 452, 46, true);
    R.bead(565, 512, 6, '#e030e0', 0.34, 0.03, 2);

    // ── red arm + yellow tongue + glitter ball (bottom) ──
    R.dome(sm([[520, 600], [560, 590], [590, 610], [600, 680], [580, 740], [540, 780], [500, 790], [520, 740], [540, 690]]), '#e81010', 0.16, 0.12, 14, 2);
    R.dome(sm([[160, 800], [200, 776], [280, 766], [360, 760], [440, 770], [520, 790], [556, 800], [540, 830], [470, 840], [400, 830], [330, 840], [270, 860], [210, 850]]), lin(160, 760, 550, 840, [[0, '#f04010'], [0.5, '#e01810'], [1, '#c00c0c']]), 0.14, 0.12, 20, 2);
    R.dome(sm([[176, 820], [230, 800], [290, 798], [326, 820], [300, 850], [250, 872], [200, 878], [176, 860]]), lin(180, 800, 300, 870, [[0, '#f8a030'], [1, '#f0d070']]), 0.2, 0.1, 14, 2);
    R.dome(sm([[380, 760], [430, 740], [480, 740], [510, 760], [490, 784], [430, 790], [390, 784]]), lin(380, 740, 500, 790, [[0, '#f8c040'], [1, '#e8d070']]), 0.2, 0.08, 10, 2);
    R.dome(sm([[350, 720], [380, 700], [420, 700], [450, 720], [446, 760], [410, 774], [370, 766], [352, 746]]), '#e81818', 0.24, 0.12, 14, 2);
    R.dome(circleP(493, 752, 22), rad(493, 752, 22, [[0, '#3a3a48'], [1, '#101016']], 486, 744), 0.3, 0.16, 12, 2);
    clipA(circleP(493, 752, 21), () => { const r = rng(5); a.fillStyle = '#ffffff'; for (let i = 0; i < 60; i++) { a.beginPath(); a.arc(472 + r() * 42, 731 + r() * 42, 0.5 + r() * 1.2, 0, 6.283); a.fill(); } });
    R.dome(P(lock([[190, 852], [176, 840], [168, 836]], 14, 8)), '#c87050', 0.22, 0.04, 5, 2);
    // green balls, cyan ring
    R.bead(70, 755, 28, rad(70, 755, 28, [[0, '#60f060'], [1, '#10a020']], 60, 744), 0.12, 0.3, 2);
    R.bead(95, 838, 12, '#30c030', 0.12, 0.14, 2); R.bead(113, 803, 5, '#f8e020', 0.12, 0.05, 2);
    R.dome(circleP(313, 480, 10), '#30e0e0', 0.14, 0.04, 4, 2); R.dome(circleP(313, 480, 5), '#f0f080', 0.16, 0.02, 2, 2);
    R.bead(400, 802, 6, '#ff40c0', 0.2, 0.03, 2); R.bead(344, 744, 5, '#ff40c0', 0.2, 0.03, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.3 }),                                // 1 matte
        E.mat({ dif: 1, spec: 0.85, shin: 50, wrap: 0.5, ao: 0.4, coat: 0.15 }),                   // 2 glossy plastic
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.62, 0.62, 0.62], amb: [0.5, 0.5, 0.52],
      envTop: [1.1, 1.1, 1.15], envHor: [0.6, 0.6, 0.66], envBot: [0.08, 0.08, 0.1], envK: [0.5, 1.2, 0, 0],
      r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 130], shadow: [-5, 7, 0.6, 7]
    });
    E.grain(0.02, 139);
  }
});
