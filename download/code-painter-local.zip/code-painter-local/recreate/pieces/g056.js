'use strict';
// g056 — "Clay snail zebra dream": a pale clay creature with a ball-chain antenna rides a radiating
// zebra-tube body; a twisted striped ribbon, a spiral shell and soap bubbles drift in a misty light.
REC.register('g056', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const put = (cv, clip) => { a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };

    // ── shaded zebra-tube field: PH = stripe phase (GLSL body), SH = large-scale light factor ──
    const zebra = (PH, SH, o2 = {}) => {
      const thr = o2.thr ?? -0.05, k = o2.k ?? 3.2, FG = o2.fog || 'return vec4(0.);', W = o2.white || [0.93, 0.89, 0.88], D = o2.dark || [0.02, 0.02, 0.025];
      const v3 = c => `vec3(${c.map(x => x.toFixed(3)).join(',')})`;
      return E.fx(`
        float C(float x){ return cos(6.2832 * x); }
        ${o2.pre || ''}
        float SF(vec2 p){ ${PH} }
        float SH(vec2 p){ ${SH} }
        vec4 FG(vec2 p){ ${FG} }
        float Hh(vec2 p){ float s = SF(p); return sqrt(clamp((s - (${thr.toFixed(3)})) / (1. - (${thr.toFixed(3)})), 0., 1.)); }
        vec3 fx(vec2 uv, vec2 p){
          float s = SF(p);
          float w = max(fwidth(s) * 0.8, 0.02);
          float m = smoothstep(${thr.toFixed(3)} - w, ${thr.toFixed(3)} + w, s);
          float hx = Hh(p + vec2(1., 0.)) - Hh(p - vec2(1., 0.)), hy = Hh(p + vec2(0., 1.)) - Hh(p - vec2(0., 1.));
          vec3 n = normalize(vec3(-hx * ${k.toFixed(2)}, -hy * ${k.toFixed(2)}, 1.));
          vec3 L = normalize(vec3(-0.45, -0.6, 0.66));
          float dif = max(dot(n, L), 0.);
          float sp = pow(max(dot(n, normalize(L + vec3(0., 0., 1.))), 0.), 30.);
          float sh = SH(p);
          vec3 wc = ${v3(W)} * (0.42 + 0.68 * dif) * sh + sp * 0.35 * sh;
          float ao = smoothstep(-1., ${thr.toFixed(3)}, s);
          vec3 dc = ${v3(D)} + 0.05 * ao * sh;
          vec4 fg = FG(p);
          return mix(mix(dc, wc, m), fg.rgb, fg.a);
        }`);
    };

    // ── background: misty top-centre light, black left, cream glow right, rays bottom-left ──
    put(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(0.035, 0.032, 0.036);
      float d1 = length((p - vec2(400., -40.)) * vec2(1.0, 0.7));
      c = mix(c, vec3(0.45, 0.50, 0.50), smoothstep(560., 260., d1));
      c = mix(c, vec3(0.74, 0.80, 0.77), smoothstep(320., 130., d1));
      c = mix(c, vec3(1.0, 1.0, 0.99), smoothstep(140., 20., d1));
      // dark left wall
      c *= mix(1., 0.12, smoothstep(260., 60., p.x) * smoothstep(150., 380., p.y));
      // cream glow lower right
      float d2 = length((p - vec2(690., 690.)) * vec2(1.0, 0.85));
      c = mix(c, vec3(0.97, 0.94, 0.9), smoothstep(320., 140., d2));
      c = mix(c, vec3(1.0, 0.99, 0.94), smoothstep(170., 50., d2));
      c = mix(c, vec3(0.45, 0.42, 0.41), smoothstep(90., 0., abs(p.y - 420.)) * smoothstep(560., 700., p.x) * 0.5);
      // rays bottom left
      float t = dot(p - vec2(0., 1024.), normalize(vec2(1., 0.3)));
      float ray = 0.5 + 0.5 * sin(t * 0.045 + 1.2) ; ray = smoothstep(0.35, 0.9, ray);
      float rz = smoothstep(640., 860., p.y) * smoothstep(320., 150., p.x - (1024. - p.y) * 0.25);
      c = mix(c, mix(vec3(0.42, 0.41, 0.43), vec3(0.9, 0.88, 0.87), ray) * (0.75 + 0.3 * smoothstep(760., 1000., p.y)), rz);
      c += 0.02 * (fbm(p * 0.02) - 0.5);
      return c; }`));

    // ── top-right zebra mass (concentric ripple around a point off the right edge) ──
    const trMass = P([[412, -5], [440, 60], [478, 120], [520, 170], [560, 210], [600, 250], [650, 285], [700, 300], [735, 300], [735, -5]]);
    put(zebra(`vec2 q = p - vec2(780., 270.); float r = length(q * vec2(1., 0.9));
      float s0 = C(r / 15. + 1.4 * (fbm(p * 0.012) - 0.5) + 0.25 * sin(p.y * 0.05 + p.x * 0.02));
      float u = clamp((p.x - 580.) / 150., -1.1, 1.0), v = clamp((p.y - 120.) / 150., -0.8, 0.4);
      float pf = (2.4388) + (3.9833)*v + (-2.2333)*v*v + (-3.5145)*v*v*v + (10.0621)*u + (8.2350)*u*v + (6.5075)*u*v*v + (-6.3611)*u*u + (-4.1435)*u*u*v + (-1.1571)*u*u*u;
      float t = max(smoothstep(150., 210., p.y), smoothstep(610., 670., p.x));
      return mix(C(pf + 0.2 * (fbm(p * 0.03) - 0.5)), s0, t);`,
      `return 0.9 + 0.1 * smoothstep(500., 420., p.x) - 0.1 * smoothstep(150., 300., p.y);`,
      { thr: -0.38, fog: `return vec4(0.78, 0.76, 0.72, 0.55 * smoothstep(620., 430., p.x) * smoothstep(250., 0., p.y));` }), trMass);

    // ── upper-left twisted ribbon ──
    const band = P([[-10, 40], [60, 60], [130, 85], [210, 98], [270, 118], [320, 160], [370, 215], [420, 280], [458, 345], [490, 400], [500, 440], [440, 440], [380, 400], [300, 345], [230, 350], [150, 345], [100, 395], [40, 360], [-10, 340]]);
    put(zebra(`vec2 c = vec2(300., 260.); float th = -0.55 * smoothstep(160., 420., p.x) - 0.25 * smoothstep(250., 420., p.y) * smoothstep(250., 450., p.x);
      vec2 q = p - c; float u = q.x * cos(th) + q.y * sin(th);
      float s0 = C(u / 15. + 1.2 * (fbm(p * 0.018 + 3.) - 0.5) + 0.3 * sin(p.y * 0.07 + p.x * 0.012));
      float uu = clamp((p.x - 200.) / 150., -1.4, 1.8), v = clamp((p.y - 220.) / 150., -0.9, 1.3); u = uu;
      float pf = (0.2295) + (3.4346)*v + (-4.8879)*v*v + (1.1542)*v*v*v + (9.1457)*u + (2.4807)*u*v + (-1.5812)*u*v*v + (-0.4300)*u*u + (2.8110)*u*u*v + (-0.8023)*u*u*u;
      return C(pf + 0.3 * (fbm(p * 0.035 + 2.) - 0.5));`,
      `return 1.05 - 0.3 * smoothstep(180., 330., p.y) * smoothstep(250., 0., p.x) - 0.1 * smoothstep(250., 420., p.y);`,
      { thr: -0.3, fog: `return vec4(0.7, 0.72, 0.7, 0.18 * smoothstep(200., 420., p.x) * smoothstep(400., 150., p.y));` }), band);

    // ── main radiating body below the creature ──
    const body = P([[440, 405], [520, 392], [600, 400], [650, 430], [674, 480], [674, 545], [660, 605], [632, 650], [592, 680], [560, 712], [536, 760], [516, 810], [510, 870], [520, 1030], [222, 1030], [212, 960], [202, 880], [194, 800], [190, 720], [196, 650], [208, 595], [228, 540], [250, 485], [290, 450], [350, 432], [405, 420]]);
    const bodyPre = `float PB(float u, float v){ return (5.1958) + (1.5190)*v + (1.1206)*v*v + (0.6106)*v*v*v + (-1.3176)*v*v*v*v + (5.3334)*u + (0.0192)*u*v + (0.9300)*u*v*v + (-1.7196)*u*v*v*v + (0.4333)*u*u + (0.1399)*u*u*v + (1.6990)*u*u*v*v + (-1.3380)*u*u*u + (-2.2520)*u*u*u*v + (-0.1315)*u*u*u*u; }
      float SB(vec2 p){ vec2 q = p - vec2(515., 475.); float r = length(q); float a = atan(q.x, q.y);
      float w = 1.1 * (fbm(p * 0.011 + 7.) - 0.5) * smoothstep(160., 420., r) + 0.12 * sin(r * 0.05);
      float N = 50. + 0.1 * r;
      float sr = C(a * N / 6.2832 + w);
      float u = (p.x - 400.) / 200., v = clamp((p.y - 800.) / 200., -1.3, 1.15);
      float uc = clamp(u, -0.7, 0.85), pf = PB(uc, v);
      if (u < -0.7) pf += (u + 0.7) * (PB(-0.7, v) - PB(-0.75, v)) / 0.05;
      float sp = C(pf + 0.15 * (fbm(p * 0.03) - 0.5));
      float brk = smoothstep(0.62, 0.72, vnoise(p * 0.045 + 11.)) * smoothstep(330., 250., p.x);
      sp = mix(sp, -1., brk);
      return mix(sr, sp, smoothstep(575., 615., p.y) * smoothstep(585., 545., p.x)); }
`;
    put(zebra(`return SB(p);`,
      `return 0.98 - 0.15 * smoothstep(900., 1024., p.y);`, { thr: -0.1, dark: [0.0, 0.0, 0.005], pre: bodyPre }), body);

    // ── small zebra wedge at the right edge + spiral shell ──
    const wedge = P([[648, 790], [680, 740], [712, 705], [735, 696], [735, 790], [700, 806]]);
    put(E.blur(zebra(`vec2 q = p - vec2(560., 900.); return C(atan(q.y, q.x) * 40. / 6.2832);`, `return 0.95;`, { thr: 0.1, fog: `return vec4(0.95, 0.92, 0.88, 0.25);` }), 1), wedge);
    const shell = P([[512, 900], [530, 830], [575, 785], [640, 762], [700, 770], [735, 790], [735, 1030], [540, 1030], [518, 970]]);
    put(E.blur(zebra(`float r0 = length(p - vec2(657., 873.));
      vec2 q = p - (vec2(657., 873.) - 0.1 * r0); q.y /= 0.95; float r = length(q); vec2 d = q / max(r, 1e-3);
      r *= 1. + 0.15 * max(0., d.y) + 0.1 * max(0., d.x);
      float f = r < 31.5 ? (r - 31.5) / 9.3 : (r - 31.5) / mix(14.5, 18., smoothstep(30., 120., r));
      return C(f);`,
      `vec2 q = p - vec2(660., 878.); float r = length(q); return 0.35 + 0.8 * smoothstep(8., 110., r);`, { k: 2.2, thr: -0.35 }), 1.2), shell);

    keep();
    // ── clay: creature head, ball chain, cluster, hand, bottom-left blob ──
    const CL = '#ead9d5', CL2 = '#e2cfcb';
    const ball = (x, y, r, c = CL) => R.dome(circleP(x, y, r), c, 0.04, Math.min(0.6, r * 0.009 + 0.12), r, 1);
    // creature body and head
    R.dome(P([[420, 520], [436, 450], [480, 408], [540, 398], [600, 404], [640, 432], [656, 490], [646, 560], [610, 598], [560, 610], [500, 612], [445, 590]]), CL, 0.03, 0.45, 70, 1);
    ball(497, 557, 54);
    ball(597, 465, 29);
    ball(630, 420, 22);
    ball(520, 402, 18);
    R.dome(circleP(558, 440, 9), '#2a1e1e', 0.05, 0.02, 4, 0);
    // ball chain rising from the head
    for (const [x, y, r] of [[565, 372, 22], [592, 330, 34], [622, 342, 28], [601, 293, 28], [566, 290, 20], [615, 266, 21], [556, 250, 15], [635, 216, 15], [638, 192, 8], [637, 177, 5], [535, 224, 9], [527, 207, 6], [622, 380, 16]]) ball(x, y, r, CL2);
    // left cluster
    for (const [x, y, r] of [[280, 365, 42], [305, 415, 22], [225, 382, 25], [172, 407, 28], [242, 427, 50], [167, 450, 25], [125, 505, 22], [200, 490, 50], [130, 570, 48], [205, 560, 22], [155, 610, 20], [115, 625, 17], [187, 667, 15], [197, 650, 8], [115, 467, 6], [132, 472, 8]]) ball(x, y, r);
    for (const [x, y, r] of [[112, 332, 5], [120, 350, 6], [130, 362, 7], [140, 375, 9], [152, 384, 12]]) ball(x, y, r);
    keep();
    // bottom-left blobs
    R.dome(P([[-10, 800], [30, 790], [60, 830], [66, 900], [56, 960], [30, 995], [-10, 990]]), '#e6d4d0', 0.03, 0.45, 50, 1);
    ball(18, 764, 40, '#e8d6d2'); ball(76, 845, 31, '#ead8d4');
    keep();

    R.shade({
      mats: [E.mat({}),
        E.mat({ dif: 1, spec: 0.22, shin: 18, wrap: 0.45, ao: 0.6, rim: 0.15, coat: 0.03 })],
      light: [-0.5, 0.6, 0.62], lc: [0.92, 0.9, 0.9], amb: [0.34, 0.32, 0.33],
      envTop: [1, 1, 1], envHor: [0.6, 0.6, 0.62], envBot: [0.2, 0.18, 0.18], envK: [0.3, 0.5, 0.3, 0],
      rimC: [0.2, 0.2, 0.22], r1: 2.6, r2: 9, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.5, 6]
    });

    // out-of-focus clay hand reaching in at the top left
    o.save(); o.filter = `blur(${2.5 * S}px)`;
    const fing = (pts, wd, c1, c2) => { const pth = P(pts, false); o.lineCap = 'round'; o.lineWidth = wd + 4; o.strokeStyle = c2; o.stroke(pth); o.lineWidth = wd; o.strokeStyle = c1; o.stroke(pth); };
    fing([[150, 10], [215, 18], [288, 32]], 30, '#e8d8d4', '#a8928e');
    fing([[160, 40], [212, 58], [258, 84]], 28, '#e4d2ce', '#a08a86');
    fing([[168, 60], [208, 92], [240, 126]], 26, '#dcc8c4', '#988480');
    const pg = o.createRadialGradient(80, 40, 10, 70, 40, 120); pg.addColorStop(0, '#c8b2ac'); pg.addColorStop(0.6, '#a48c86'); pg.addColorStop(1, '#6a5854');
    o.fillStyle = pg; o.fill(P([[-10, -10], [120, -10], [150, 20], [160, 60], [142, 96], [104, 116], [62, 112], [28, 90], [-10, 62]]));
    const kg = o.createRadialGradient(132, 30, 2, 140, 38, 26); kg.addColorStop(0, '#f2e6e2'); kg.addColorStop(1, '#b8a29c');
    o.fillStyle = kg; o.fill(circleP(140, 38, 22));
    o.restore();

    // spiral marks on clay
    const spiral = (cx, cy, r, turns) => { const pts = []; for (let t = 0; t <= 1; t += 0.01) { const an = t * turns * 6.283, rr = r * t; pts.push([cx + Math.cos(an) * rr, cy + Math.sin(an) * rr]); }
      o.lineWidth = r / turns * 0.45; o.strokeStyle = '#111'; o.lineCap = 'round'; o.stroke(P(pts, false)); };
    spiral(250, 437, 17, 4); spiral(428, 526, 17, 4); spiral(547, 386, 9, 3);

    // ── soap bubbles + specks ──
    const bubble = (x, y, r) => {
      const g = o.createRadialGradient(x, y, r * 0.55, x, y, r);
      g.addColorStop(0, 'rgba(255,255,255,0.2)'); g.addColorStop(0.7, 'rgba(235,240,255,0.4)'); g.addColorStop(0.92, 'rgba(255,255,255,0.9)'); g.addColorStop(1, 'rgba(255,255,255,0.2)');
      o.fillStyle = g; o.fill(circleP(x, y, r));
      o.save(); o.clip(circleP(x, y, r)); o.globalAlpha = 0.7;
      o.fillStyle = 'rgba(170,120,255,0.8)'; o.fill(ellipseP(x + r * 0.2, y + r * 0.25, r * 0.35, r * 0.18, -0.5));
      o.fillStyle = 'rgba(255,220,120,0.8)'; o.fill(ellipseP(x - r * 0.35, y + r * 0.45, r * 0.3, r * 0.12, 0.6));
      o.restore();
      o.fillStyle = 'rgba(255,255,255,0.9)'; o.fill(ellipseP(x - r * 0.35, y - r * 0.4, r * 0.22, r * 0.12, -0.6));
    };
    for (const [x, y, r] of [[592, 110, 28], [712, 192, 27], [57, 478, 27], [75, 688, 20], [135, 875, 22], [718, 582, 17], [700, 387, 15], [158, 138, 14], [688, 52, 12], [718, 242, 11], [50, 386, 12], [66, 542, 8], [44, 575, 8], [125, 668, 12], [150, 620, 11], [289, 714, 10], [478, 125, 8], [508, 133, 8], [510, 316, 7], [80, 980, 13], [148, 795, 7], [165, 742, 6], [199, 718, 7], [684, 678, 10], [598, 740, 6], [35, 236, 8], [44, 190, 6], [168, 717, 6], [366, 195, 6], [290, 990, 7]]) bubble(x, y, r);
    const sr = rng(56);
    for (let i = 0; i < 160; i++) { const x = sr() * 726, y = sr() * 1024, rr = 0.6 + sr() * 1.8; o.fillStyle = `rgba(255,255,255,${0.4 + sr() * 0.5})`; o.fill(circleP(x, y, rr)); }

    E.bloom(0.12, 10);
    E.grain(0.025, 56);
  }
});
