'use strict';
// g063 — "Pink worms on teal": glossy clay relief on black — bumpy pink worm tubes crossing a teal slab,
// coral-orange paddles, a pastel-green and a spotted black sphere, a pink dotted plaque, pale-blue beads and
// ferns, and white zebra ribbons swirling out of a little spiral.
REC.register('g063', {
  w: 726, h: 1024,
  draw(E) {
    const ZF = `float zph(vec2 p){
        vec2 d = p - vec2(343., 296.); float rs = length(d);
        if (rs < 32.) return rs / 6. - atan(d.y, d.x) / 6.2832;
        float rho = length((p - vec2(338., 566.)) * vec2(1., 0.92));
        float m = 1. + 3.2 * exp(-rs / 80.);
        float re = 250. + (rho - 250.) * m;
        return 5. * log(max(re, 20.)) + (fbm(p * 0.012) - .5) * 0.5; }`;
    const zcv = E.fx(ZF + `vec3 fx(vec2 uv, vec2 p){ float f = fract(zph(p)); return vec3(smoothstep(0.52, 0.56, f) * (1. - smoothstep(0.96, 1.0, f))); }`);
    const hcv = E.fx(ZF + `vec3 fx(vec2 uv, vec2 p){ float f = fract(zph(p)); float w = smoothstep(0.52, 0.6, f) * (1. - smoothstep(0.92, 1.0, f)); return vec3(w * 0.05, 0., 0.); }`);
    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    // add a little height (bumps) on top of whatever is there: R channel only, 'lighter'
    const bump = (fn, blur) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      hx.save(); hx.setTransform(1, 0, 0, 1, 0, 0); hx.globalCompositeOperation = 'lighter'; hx.filter = `blur(${blur * S}px)`; hx.drawImage(c, 0, 0); hx.restore();
    };
    const lin = (x, x0, y0, x1, y1, st) => { const g = x.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, cx, cy, r0, r1, st, fx = cx, fy = cy) => { const g = x.createRadialGradient(fx, fy, r0, cx, cy, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const BLUE = '#a4d6e8', WHITE = '#f2f2f0', PINK = '#f2c6cc', ORG = '#e27a52';

    // ── black ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#060606', 0, 0);
    a.fillStyle = '#d0d0d0'; a.fill(P(star(133, 125, 4, 1.2, 5, 0.3), true, false));

    // ── teal slab ──
    const slab = P([[296, 214], [360, 190], [420, 168], [480, 146], [540, 128], [600, 118], [680, 116], [740, 116], [740, 1040], [330, 1040], [200, 950], [170, 860], [196, 800], [262, 762], [300, 700], [322, 620], [300, 560], [290, 460], [306, 380], [326, 330], [310, 250]], true, true);
    R.dome(slab, lin(a, 300, 150, 600, 900, [[0, '#5a98a8'], [0.5, '#4f8a9a'], [1, '#46808f']]), 0.02, 0.06, 18, 4);
    clipA(slab, () => { const r = rng(3); a.fillStyle = '#9cc8d4'; for (let i = 0; i < 220; i++) { a.globalAlpha = 0.4 + r() * 0.5; a.beginPath(); a.arc(300 + r() * 426, 120 + r() * 900, 0.6 + r() * 1.4, 0, 6.283); a.fill(); } a.globalAlpha = 1; });
    keep();

    // ── zebra ribbons swirling out of the spiral ──
    const zebP = P([[150, 350], [200, 330], [250, 300], [300, 270], [345, 260], [380, 290], [360, 340], [330, 400], [310, 460], [290, 500], [280, 560], [300, 620], [330, 690], [250, 712], [150, 700], [100, 660], [96, 600], [110, 540], [130, 470], [140, 400]], true, true);
    clipA(zebP, () => img(zcv));
    // raise the white stripes a little
    {
      hx.save(); hx.clip(zebP); hx.setTransform(1, 0, 0, 1, 0, 0); hx.globalCompositeOperation = 'lighter'; hx.drawImage(hcv, 0, 0); hx.restore();
      hx.save(); hx.clip(zebP); hx.fillStyle = 'rgb(0,32,0)'; hx.globalCompositeOperation = 'lighter'; hx.fillRect(0, 0, 726, 1024); hx.restore(); }
    keep();

    // ── white tubes on black ──
    const WT = [
      [[[-10, 254], [40, 246], [95, 262], [130, 300], [140, 350], [130, 410], [112, 466], [96, 510], [76, 548]], 44],
      [[[38, 352], [36, 400], [40, 446]], 40],
      [[[-10, 708], [40, 728], [80, 742], [110, 746]], 46],
      [[[-10, 832], [40, 829], [100, 808], [160, 806], [210, 822], [240, 850], [232, 880]], 44],
      [[[-10, 938], [40, 925], [100, 899], [150, 892], [190, 908]], 38],
      [[[184, 336], [210, 300], [250, 262], [300, 232], [350, 212]], 30]];
    for (const [pts, wd] of WT) R.pipe(P(pts, false), wd, WHITE, 0.06, 0.16, 1);
    for (const [x, y, r] of [[212, 318, 7], [250, 250, 5], [322, 222, 6], [298, 236, 4]]) R.bead(x, y, r, '#f07830', 0.2, 0.04, 1);
    R.pipe(P([[96, 430], [130, 384], [170, 350], [212, 322]], false), 7, '#7ab8d0', 0.1, 0.06, 1);
    R.bead(104, 418, 9, '#7ab8d0', 0.12, 0.08, 1);
    keep();

    // ── orange paddles ──
    const O1 = P([[528, 118], [560, 100], [640, 96], [726, 84], [740, 84], [740, 440], [690, 442], [650, 420], [630, 380], [612, 330], [594, 290], [586, 250], [598, 206], [590, 176], [548, 150]], true, true);
    const O2 = P([[650, 552], [668, 532], [700, 522], [740, 518], [740, 624], [700, 618], [662, 600], [648, 576]], true, true);
    const O3 = P([[340, 1040], [352, 980], [386, 940], [446, 924], [504, 912], [540, 880], [572, 850], [624, 834], [680, 826], [700, 700], [740, 690], [740, 1040]], true, true);
    for (const pth of [O1, O2, O3]) R.dome(pth, lin(a, 300, 80, 726, 1024, [[0, '#ea8460'], [0.5, '#e27a52'], [1, '#d8704a']]), 0.12, 0.12, 16, 3);
    for (let y = 128; y < 420; y += 35) R.groove(P([[676 + (y > 300 ? 10 : 0), y], [700, y + 2], [740, y + 4]], false), 5, '#a85030', 0.24, 0.08, 3, 0.9);
    R.bead(608, 122, 14, BLUE, 0.24, 0.12, 5);
    R.bead(615, 258, 22, '#e86a38', 0.24, 0.14, 3);
    R.bead(672, 378, 18, BLUE, 0.24, 0.12, 5);
    R.bead(646, 334, 7, BLUE, 0.24, 0.06, 5);
    { const fl = []; for (let i = 0; i < 10; i++) { const t = i / 10 * 6.283, rr = i % 2 ? 10 : 18; fl.push([655 + Math.cos(t) * rr * 0.8, 162 + Math.sin(t) * rr]); } R.dome(P(fl, true, true), '#f0e6c0', 0.24, 0.04, 4, 3); }
    R.flat(circleP(690, 572, 5), '#140806', 0.2, 0);
    R.flat(circleP(590, 888, 6), '#140806', 0.2, 0);
    keep();

    // ── pink plaque with dotted script ──
    const plaque = ellipseP(445, 515, 172, 66, -0.32);
    R.dome(plaque, '#f0b8c4', 0.1, 0.1, 16, 2);
    clipA(plaque, () => soft(x => { x.fillStyle = '#f8cbb4'; x.fill(ellipseP(430, 520, 100, 32, -0.32)); }, 10, 0.9));
    { const r = rng(11); for (let i = 0; i < 70; i++) { const t = r() * 6.283, k = 0.8 + r() * 0.12; const x = 445 + Math.cos(t) * 172 * k * Math.cos(-0.32) - Math.sin(t) * 66 * k * Math.sin(-0.32), y = 515 + Math.cos(t) * 172 * k * Math.sin(-0.32) + Math.sin(t) * 66 * k * Math.cos(-0.32);
      R.bead(x, y, 1.8 + r() * 1.6, '#fbf4f4', 0.2, 0.03, 1); } }
    for (const pts of [[[300, 520], [312, 500], [330, 506], [322, 530]], [[350, 590], [370, 572], [392, 586]], [[540, 470], [560, 456], [580, 466], [570, 482]], [[470, 590], [490, 578], [500, 596]]])
      R.pipe(P(pts, false), 3, '#fbf4f4', 0.2, 0.03, 1);

    // ── spheres ──
    R.dome(circleP(395, 396, 68), rad(a, 395, 396, 4, 68, [[0, '#e8f4c0'], [0.45, '#c8e4b0'], [0.75, '#7ab0b0'], [1, '#3a7080']], 372, 360), 0.2, 0.5, 68, 5);
    R.dome(circleP(516, 386, 66), '#0a0a0c', 0.2, 0.5, 66, 5);
    clipA(circleP(516, 386, 66), () => {
      for (const [x, y, rx, ry] of [[468, 352, 10, 6], [494, 344, 12, 7], [520, 352, 9, 6], [548, 346, 10, 6], [538, 332, 7, 4], [486, 330, 6, 4], [566, 362, 7, 5], [506, 366, 6, 4], [538, 370, 5, 4]]) { a.fillStyle = '#f2eea0'; a.fill(ellipseP(x, y, rx, ry, 0)); }
      soft(x => { x.fillStyle = '#3a7888'; x.fill(ellipseP(516, 446, 60, 14, 0)); }, 6, 0.8);
    });
    keep();

    // ── pale blue beads and squiggles on the slab ──
    { const r = rng(21);
      for (let row = 0; row < 4; row++) for (let i = 0; i < 6; i++) {
        const x = 438 + i * 26 + row * 6 + (r() - 0.5) * 6, y = 160 + row * 24 + (r() - 0.5) * 5 - i * 3;
        if (x > 596 || (row === 3 && i > 3)) continue;
        R.bead(x, y, 10 + r() * 4, BLUE, 0.1, 0.12, 5);
      }
      for (const [x, y, rr] of [[392, 244, 10], [420, 236, 9], [372, 268, 6], [404, 270, 6], [452, 285, 5], [584, 214, 7], [560, 226, 5], [610, 300, 6], [362, 220, 5], [518, 660, 8], [292, 790, 18], [262, 830, 6], [300, 860, 5], [518, 600, 6], [290, 610, 5]])
        R.bead(x, y, rr, BLUE, 0.1, 0.1, 5); }
    R.pipe(P([[430, 268], [470, 262], [500, 252], [540, 246], [570, 232]], false), 10, BLUE, 0.1, 0.08, 5);
    R.pipe(P([[440, 300], [480, 296], [520, 304], [560, 296], [590, 290]], false), 7, BLUE, 0.1, 0.06, 5);
    R.pipe(P([[230, 616], [262, 628], [296, 640]], false), 14, '#6ab2c8', 0.12, 0.08, 5);
    R.bead(304, 646, 13, '#6ab2c8', 0.12, 0.1, 5);
    R.bead(355, 845, 13, '#c8ccd4', 0.12, 0.2, 7);
    R.bead(48, 972, 12, '#c8ccd4', 0.12, 0.16, 7);
    R.pipe(P([[400, 796], [440, 786], [480, 774], [512, 764]], false), 12, PINK, 0.1, 0.06, 2);
    R.pipe(P([[400, 796], [430, 790]], false), 18, PINK, 0.1, 0.07, 2);
    keep();

    // ── bumpy pink worms ──
    const worm = (pts, wd, seed) => {
      const pth = P(pts, false);
      R.pipe(pth, wd, PINK, 0.14, 0.2, 2);
      // cell bumps
      const r = rng(seed);
      bump(x => {
        x.save(); x.lineWidth = wd * 0.82; x.strokeStyle = 'rgba(0,0,0,0)'; x.restore();
        const L = [], n = pts.length;
        for (let i = 0; i < n - 1; i++) { const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], d = Math.hypot(x1 - x0, y1 - y0), k = Math.ceil(d / 4); for (let j = 0; j < k; j++) L.push([x0 + (x1 - x0) * j / k, y0 + (y1 - y0) * j / k, Math.atan2(y1 - y0, x1 - x0)]); }
        x.fillStyle = 'rgb(5,0,0)';
        for (let i = 0; i < L.length; i += 2) {
          const [cx, cy, an] = L[i];
          for (let s = 0; s < 3; s++) {
            const off = (r() - 0.5) * wd * 0.8;
            x.fill(ellipseP(cx - Math.sin(an) * off, cy + Math.cos(an) * off, 4 + r() * 5, 3 + r() * 3, an + (r() - 0.5)));
          }
        }
      }, 1.2);
      // tiny white spikes along the lower edge
      return pth;
    };
    worm([[740, 470], [650, 500], [560, 545], [470, 600], [400, 650], [330, 706], [250, 742], [180, 738], [118, 696], [84, 630], [76, 572]], 84, 31);
    worm([[740, 640], [690, 672], [610, 730], [540, 786], [450, 846], [340, 896], [250, 924], [196, 946]], 92, 32);
    // orange inner line of the left worm
    R.pipe(P([[70, 580], [78, 650], [112, 714], [180, 766], [260, 774], [340, 752], [400, 718]], false), 5, '#f08038', 0.16, 0.04, 3);
    // white teeth under the worms
    { const r = rng(41); for (const [x0, y0, x1, y1, n] of [[90, 690, 330, 770, 28], [200, 960, 340, 930, 12], [580, 760, 700, 690, 10]]) for (let i = 0; i < n; i++) { const t = i / n, x = x0 + (x1 - x0) * t + (r() - 0.5) * 6, y = y0 + (y1 - y0) * t + Math.sin(t * 3.14) * 16; R.pipe(P([[x, y], [x + (r() - 0.5) * 3, y + 6 + r() * 6]], false), 3.5, '#f4f2f0', 0.2, 0.04, 1); } }
    keep();

    // ── pale-blue ferns ──
    const fern = (x, y, ang, len, seed, sc = 1) => {
      const r = rng(seed), n = Math.round(len / 7);
      const stem = [];
      for (let i = 0; i <= n; i++) { const t = i / n; stem.push([x + Math.cos(ang + (r() - 0.5) * 0.08) * len * t, y + Math.sin(ang) * len * t]); }
      R.pipe(P(stem, false), 3 * sc, BLUE, 0.3, 0.04, 6);
      for (let i = 1; i < n; i++) for (const off of [0, 0.5]) {
        const t = (i + off) / n, k = Math.min(n, i + 1), sx = stem[i][0] + (stem[k][0] - stem[i][0]) * off, sy = stem[i][1] + (stem[k][1] - stem[i][1]) * off, ll = (1 - t * 0.7) * 12 * sc + 3;
        for (const sg of [-1, 1]) { const aa = ang + sg * (0.55 + r() * 0.2); R.pipe(P([[sx, sy], [sx + Math.cos(aa) * ll, sy + Math.sin(aa) * ll]], false), 2.8 * sc, BLUE, 0.3, 0.04, 6); }
      }
    };
    const cluster = (x, y, angs, len, seed, sc) => angs.forEach((an, i) => fern(x, y, an, len * (0.8 + 0.25 * Math.sin(i * 2.3)), seed + i, sc));
    cluster(236, 310, [-2.3, -2.0, -1.75, -2.6, -2.85], 150, 100, 1);
    cluster(384, 208, [-2.2, -1.65, -1.15, -2.65], 90, 110, 0.9);
    cluster(472, 168, [-1.9, -1.45, -2.35], 90, 120, 0.9);
    cluster(540, 124, [-1.7, -1.35, -2.0, -1.05], 110, 130, 1);
    cluster(328, 452, [-2.4, -1.6, -3.0, -0.8], 30, 140, 0.6);
    cluster(436, 576, [-2.6, -1.8, -1.0, 0.3, -0.3], 34, 150, 0.7);
    cluster(80, 556, [-2.2, -1.6, -1.0, 2.6, 0.4], 36, 160, 0.7);
    cluster(56, 620, [-2.8, 2.6, 3.1], 30, 170, 0.6);
    cluster(90, 736, [-2.6, 2.4, 1.8, 3.0, -1.6], 30, 180, 0.7);
    cluster(220, 900, [-2.0, -1.4, -2.7, 2.6, -0.8], 40, 190, 0.8);
    cluster(230, 990, [-2.0, -1.2, -2.6], 26, 200, 0.6);
    cluster(350, 248, [-2.0, -1.0, 0.6], 18, 210, 0.5);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.4, ao: 0.4, coat: 0.12, rim: 0.2 }),                  // 1 glossy white / pink plastic
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.6, grain: 0.2, rim: 0.2 }),                  // 2 pink clay worms
        E.mat({ dif: 1, spec: 0.22, shin: 14, wrap: 0.5, ao: 0.5, grain: 0.2 }),                           // 3 orange clay
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4, grain: 0.1 }),                            // 4 teal slab
        E.mat({ dif: 0.9, spec: 1.3, shin: 90, wrap: 0.3, coat: 0.3, ao: 0.3, rim: 0.3 }),                 // 5 glossy spheres / beads
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.7, emis: 0.15 }),                                     // 6 ferns
        E.mat({ dif: 0.3, metal: 1, spec: 1.4, shin: 80, rim: 0.3 })                                       // 7 chrome
      ],
      light: [-0.45, 0.62, 0.64], lc: [0.85, 0.84, 0.84], amb: [0.36, 0.38, 0.4],
      envTop: [1.05, 1.05, 1.05], envHor: [0.5, 0.55, 0.6], envBot: [0.08, 0.08, 0.1], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.2, 0.25, 0.3], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-5, 7, 0.7, 7]
    });
    E.bloom(0.06, 8);
    E.grain(0.03, 63);
  }
});
