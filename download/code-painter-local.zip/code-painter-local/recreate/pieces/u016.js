'use strict';
// u016 — "Gold pear reliquary": a grey plate holding a molten gold pear, a painted grey face and chrome spheres,
// under a red moon; a zebra-striped figure on blue graph paper on the left, a starfield with silver planets on the right.
REC.register('u016', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, fx = x, fy = y) => { const g = ctx.createRadialGradient(fx, fy, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const fillA = (path, col) => { a.fillStyle = col; a.fill(path); };
    const strokeA = (path, col, w) => { a.lineWidth = w; a.strokeStyle = col; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const shadow = (path, dx, dy, b, al) => soft(x => { x.fillStyle = '#000'; x.translate(dx, dy); x.fill(path); }, b, al);

    // ── backgrounds: blue graph paper (left), starfield (right), pale wave + splatter (bottom left) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#2c52ac', 0, 0);
    clipA(rrect(-10, -10, 746, 1044, 0), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 g = abs(fract(p / 16.5 + .5) - .5) * 16.5; float l = 1. - smoothstep(.4, 1.2, min(g.x, g.y));
      vec3 c = mix(vec3(.16, .31, .66), vec3(.2, .36, .72), fbm(p * .01));
      return mix(c, vec3(.42, .56, .86), l * .55); }`)));
    const SPACE = poly([[560, -10], [736, -10], [736, 1034], [330, 1034], [345, 965], [420, 948], [520, 880], [600, 300], [560, 180]]);
    R.flat(SPACE, '#0a0508', 0.005, 0);
    clipA(SPACE, () => { const g = rng(16), cols = ['#ffffff', '#ff6a8a', '#7aa8ff', '#ffd0a0', '#ffffff'];
      for (let i = 0; i < 260; i++) { const x = 330 + g() * 400, y = g() * 1024, r = 0.6 + g() * g() * 2.6; fillA(circleP(x, y, r), cols[i % 5]); }
      for (let i = 0; i < 40; i++) { const x = 560 + g() * 170, y = 150 + g() * 870, r = 3 + g() * 4; soft(q => { q.fillStyle = cols[i % 5]; q.fill(circleP(x, y, r * 2)); }, r, 0.5); fillA(circleP(x, y, r * 0.8), '#fff8f0'); }
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p / 1.4)); return vec3(step(.985, n) * (p.y > 900. ? 1. : .5)); }`), a); });
    // bottom-left wave
    const WAVE = sm([[-10, 790], [40, 820], [110, 870], [180, 905], [260, 935], [330, 965], [380, 1000], [400, 1034], [-10, 1034]]);
    R.flat(WAVE, lin(0, 800, 300, 1030, [[0, '#dcdcda'], [0.4, '#c6e0ea'], [0.7, '#e8e2c8'], [1, '#d8eef4']]), 0.01, 0);
    clipA(WAVE, () => { for (let i = 0; i < 6; i++) strokeA(P([[-10, 850 + i * 30], [120, 900 + i * 28], [260, 960 + i * 24], [400, 1040 + i * 20]], false), i % 2 ? 'rgba(140,200,225,0.7)' : 'rgba(240,230,190,0.7)', 10); });
    { const g = rng(61); for (let i = 0; i < 420; i++) { const t = g(), x = t * 420 + (g() - 0.5) * 80, y = 800 + t * 200 + (g() - 0.5) * 70; fillA(circleP(x, y, 0.6 + g() * g() * 4), 'rgba(250,250,252,0.9)'); } }
    R.flat(poly([[-10, 1012], [260, 1018], [270, 1034], [-10, 1034]]), '#7a3a26', 0.01, 0);

    // ── red moon and pink glow ──
    R.flat(circleP(527, -8, 214), rad(470, -60, 300, [[0, '#ff4a4c'], [0.6, '#f02024'], [1, '#c81414']]), 0.02, 0);
    soft(x => { x.fillStyle = '#ff9ad0'; x.fill(circleP(70, 45, 44)); }, 20, 0.9);
    soft(x => { x.fillStyle = '#fff8f0'; x.fill(ellipseP(70, 40, 22, 26, 0)); x.fillStyle = '#f0c880'; x.fill(ellipseP(70, 72, 46, 10, 0)); }, 5, 1);

    // ── zebra figure ──
    const ZB = sm([[95, 175], [140, 160], [200, 145], [250, 125], [292, 82], [318, 62], [332, 80], [318, 130], [312, 175], [300, 220], [260, 260], [230, 320], [195, 360], [180, 420], [176, 480], [170, 560], [150, 640], [130, 690], [80, 680], [40, 630], [12, 560], [20, 500], [60, 450], [98, 420], [95, 350], [80, 270], [72, 210]]);
    R.dome(ZB, '#eae6e4', 0.02, 0.05, 20, 1);
    clipA(ZB, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = 30. * (fbm(p * .006 + 4.) - .5) + 12. * sin(p.y * .012 + p.x * .004);
      vec2 q = p - vec2(330., 40.); float top = smoothstep(260., 120., p.y);
      float ph = mix(p.x + w, length(q) * 1.1 + w * .6, top) / 14.;
      float v = cos(6.2832 * ph);
      float blob = smoothstep(.66, .72, fbm(p * .012 + 7.)) * smoothstep(320., 200., p.y);
      return mix(mix(vec3(.05, .04, .05), vec3(.93, .91, .9), smoothstep(-.25, .25, v)), vec3(.93, .91, .9), blob); }`)));

    // ── the grey plate ──
    const PLATE = sm([[440, 52], [478, 46], [496, 64], [497, 150], [508, 180], [560, 186], [620, 196], [656, 228], [676, 290], [682, 440], [664, 560], [634, 630], [612, 700], [590, 760], [560, 820], [515, 878], [462, 922], [410, 942], [330, 936], [262, 905], [214, 860], [184, 800], [166, 720], [156, 640], [154, 560], [168, 470], [196, 390], [240, 320], [300, 262], [370, 222], [424, 200], [432, 150], [432, 74]]);
    shadow(PLATE, 6, 12, 14, 0.6);
    R.dome(PLATE, '#7e8288', 0.08, 0.06, 10, 2);
    clipA(PLATE, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = hash(floor(p)) * .5 + vnoise(p * .3) * .5; return vec3(.47, .49, .52) + (n - .5) * .12; }`), a));
    for (const [x, y, r] of [[450, 62, 5], [436, 102, 6], [437, 143, 6], [472, 330, 4], [575, 242, 10], [590, 434, 9]]) R.flat(circleP(x, y, r), '#0a0a0c', 0.06, 0);

    // ── gold insert ──
    const GOLD = sm([[300, 330], [420, 300], [500, 268], [526, 210], [590, 228], [630, 268], [642, 330], [640, 420], [628, 520], [610, 590], [588, 660], [565, 720], [536, 770], [500, 830], [470, 880], [420, 912], [340, 912], [270, 880], [226, 830], [200, 760], [180, 680], [170, 600], [172, 540], [200, 470], [240, 400]]);
    R.dome(GOLD, lin(200, 300, 640, 900, [[0, '#e8e0d4'], [0.5, '#e0d6c6'], [1, '#d8c4a8']]), 0.12, 0.05, 10, 3);
    clipA(GOLD, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * vec2(.03, .012) + 3.), m = fbm(p * .02 + 11.);
      float dark = smoothstep(.55, .62, n) * (1. - smoothstep(.62, .75, n));
      return mix(vec3(1.), vec3(.42, .32, .24), dark * .9) * mix(1., .8, smoothstep(.5, .7, m)); }`), a); a.restore(); });
    // grey bars in the gold
    for (const pts of [[[528, 322], [636, 318], [636, 336], [544, 342], [528, 336]], [[500, 462], [606, 456], [614, 468], [606, 478], [512, 482]], [[560, 330], [578, 330], [578, 360], [560, 360]]]) R.dome(poly(pts), '#6e7278', 0.13, 0.02, 3, 2);
    R.pipe(ellipseP(540, 404, 34, 30, 0), 12, '#e8dcc8', 0.14, 0.06, 3);
    R.dome(sm([[492, 515], [530, 505], [560, 520], [570, 560], [548, 600], [510, 600], [490, 560]]), '#c8b6a0', 0.18, 0.05, 8, 3);
    // the molten pear
    const PEAR = sm([[380, 545], [420, 550], [442, 582], [452, 640], [470, 700], [495, 760], [500, 820], [485, 870], [450, 900], [390, 912], [320, 905], [260, 880], [225, 840], [215, 790], [225, 740], [260, 700], [300, 670], [330, 620], [350, 570]]);
    R.dome(PEAR, lin(250, 570, 480, 900, [[0, '#ece6dc'], [0.4, '#d8d0c4'], [0.7, '#e0ccb0'], [1, '#e0b888']]), 0.18, 0.3, 90, 4);
    clipA(PEAR, () => {
      soft(x => { x.fillStyle = '#3a2a20'; x.fill(sm([[230, 760], [262, 700], [300, 690], [290, 760], [270, 840], [300, 900], [240, 870]])); x.fill(ellipseP(400, 880, 70, 22, -0.1)); x.fill(ellipseP(420, 640, 22, 50, 0.2)); x.fill(ellipseP(330, 820, 40, 26, 0.3)); }, 12, 0.9);
    });
    soft(x => { x.fillStyle = '#6a5040'; x.fill(sm([[175, 600], [215, 600], [240, 680], [228, 760], [222, 840], [196, 820], [180, 720]])); }, 14, 0.7);
    // molten ridges
    for (const c of [[[300, 560], [270, 600], [252, 650], [260, 700], [230, 740]], [[455, 520], [470, 560], [460, 620], [480, 680], [470, 720]], [[200, 600], [230, 640], [215, 690], [235, 730]], [[505, 620], [520, 680], [510, 740], [530, 780]]])
      R.pipe(P(c, false), 9, '#b89c78', 0.2, 0.06, 3);
    // gold dimples with beads
    { const g = rng(29); for (const [x, y, r] of [[497, 240, 8], [528, 255, 6], [512, 278, 6], [540, 300, 6], [516, 300, 5], [510, 365, 8], [538, 362, 7], [500, 395, 6], [526, 420, 7], [503, 498, 9], [520, 505, 6], [555, 520, 8], [574, 540, 8], [508, 560, 7], [512, 600, 7], [530, 645, 10], [495, 700, 6], [455, 600, 6], [220, 680, 8], [238, 664, 6], [300, 650, 6], [192, 640, 5]]) {
      R.dome(circleP(x, y, r + 5), '#9a8268', 0.14, 0.02, 3, 3); R.bead(x, y, r, '#e4e4e6', 0.17, Math.min(0.2, r * 0.02), 5); } }
    for (const [x, y, rx, ry] of [[600, 285, 12, 15], [602, 390, 12, 14], [557, 572, 17, 13], [598, 538, 10, 12]]) { R.dome(ellipseP(x, y, rx + 4, ry + 4, 0), '#8a6a50', 0.15, 0.03, 4, 3); R.dome(ellipseP(x, y, rx, ry, 0), '#a8542e', 0.18, 0.06, rx, 6); }
    R.dome(circleP(436, 369, 13), '#f2f2f2', 0.14, 0.02, 3, 1); R.flat(circleP(436, 369, 8), '#0a0a0c', 0.16, 0); R.flat(circleP(436, 369, 4), '#e8e8e8', 0.16, 0);

    // ── the painted grey face panel with a red rim ──
    const FACE = sm([[166, 430], [190, 375], [240, 350], [292, 334], [345, 322], [396, 320], [452, 326], [490, 342], [478, 400], [455, 456], [428, 508], [390, 538], [320, 556], [244, 574], [196, 570], [168, 535], [160, 480]]);
    R.pipe(FACE, 14, '#d02a20', 0.16, 0.06, 6);
    R.flat(FACE, '#8c8c8a', 0.17, 0);
    clipA(FACE, () => {
      img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = vnoise(p * .25) * .5 + hash(floor(p)) * .5; float sp = step(.82, fbm(p * .05 + 2.)) * step(.5, hash(floor(p / 3.)));
        return mix(vec3(.55, .55, .54) + (n - .5) * .14, vec3(.06), sp); }`), a);
      const face = sm([[180, 420], [215, 398], [260, 392], [300, 404], [330, 430], [335, 470], [325, 510], [300, 545], [255, 570], [210, 572], [180, 545], [168, 490]]);
      fillA(face, '#e8e6e2');
      fillA(sm([[180, 420], [210, 410], [200, 450], [185, 500], [176, 540], [168, 490]]), '#5a5a5c');
      fillA(sm([[215, 470], [240, 455], [244, 490], [226, 520], [210, 505]]), '#6a6a6c');
      fillA(sm([[278, 470], [310, 462], [326, 480], [316, 520], [290, 540], [276, 510]]), '#6a6a6c');
      fillA(ellipseP(210, 437, 18, 7, 0.05), '#0e0e10'); fillA(ellipseP(212, 437, 9, 6, 0), '#2a2a2c'); fillA(ellipseP(295, 446, 24, 9, 0.1), '#0e0e10'); fillA(ellipseP(298, 446, 11, 7, 0), '#2a2a2c');
      strokeA(P([[190, 425], [230, 420]], false), '#1a1a1a', 4); strokeA(P([[270, 430], [318, 436]], false), '#1a1a1a', 4);
      strokeA(P([[245, 440], [240, 470], [250, 480]], false), '#3a3a3a', 3);
      fillA(sm([[226, 505], [250, 498], [262, 512], [256, 545], [238, 560], [222, 540]]), '#0c0c0e');
      fillA(sm([[180, 540], [215, 525], [236, 560], [210, 575], [180, 570]]), '#f4f2ee');
    });

    // ── blue pill ──
    { a.save(); const pill = new Path2D(); const m = new DOMMatrix().translate(142, 776).rotate(-17); pill.addPath(rrect(-52, -112, 104, 224, 52), m);
      shadow(pill, 6, 10, 10, 0.6); R.dome(pill, lin(90, 700, 200, 860, [[0, '#2a9cf0'], [0.5, '#0a80dc'], [1, '#0660b8']]), 0.1, 0.22, 52, 7); a.restore(); }

    // ── chrome spheres and gold beads ──
    const ball = (x, y, r, m = 5, alb = '#d8dadc') => { shadow(circleP(x, y, r), r * 0.08, r * 0.14, r * 0.15, 0.5);
      R.bead(x, y, r, rad(x - r * 0.3, y - r * 0.35, r * 1.3, [[0, '#ffffff'], [0.45, alb], [0.75, '#8a8c90'], [1, '#e8eaee']]), 0.2, Math.min(0.45, r * 0.006 + 0.1), m); };
    R.pipe(P([[318, 290], [330, 316], [348, 330]], false), 26, '#a8784a', 0.18, 0.08, 4);
    R.pipe(P([[168, 590], [186, 600], [200, 612]], false), 24, '#a8784a', 0.18, 0.08, 4);
    ball(426, 262, 72); ball(276, 255, 56); ball(298, 197, 22); ball(120, 580, 42); ball(118, 150, 18);
    ball(662, 665, 45, 5, '#b8c8dc'); ball(620, 952, 57, 5, '#b8c8dc');
    ball(228, 878, 18); ball(466, 932, 14); ball(488, 922, 12); ball(606, 765, 15); ball(626, 192, 12); ball(178, 678, 10);
    { const g = rng(160); const golds = [[50, 280, 7], [62, 296, 9], [24, 400, 13], [20, 668, 12], [60, 418, 7], [12, 340, 5], [22, 260, 5], [44, 380, 4], [82, 640, 9], [96, 600, 5], [30, 750, 5], [56, 798, 9], [98, 860, 7], [150, 935, 10], [96, 975, 20], [520, 958, 8], [652, 584, 9], [662, 768, 12], [700, 222, 12], [710, 300, 9], [686, 376, 10], [700, 500, 12], [652, 792, 8], [676, 890, 10], [348, 152, 8], [612, 195, 6], [258, 625, 9], [230, 718, 6], [240, 780, 7], [690, 600, 8]];
      for (const [x, y, r] of golds) R.bead(x, y, r, g() < 0.25 ? '#a86a3c' : '#e0b888', 0.1, 0.06 + r * 0.008, 4); }
    R.dome(sm([[90, 400], [118, 380], [150, 386], [152, 410], [128, 426], [100, 424]]), '#d8c4d8', 0.15, 0.08, 14, 5);
    R.dome(sm([[40, 300], [60, 296], [70, 318], [54, 330], [38, 322]]), '#b07850', 0.12, 0.06, 8, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.3, emis: 0.05 }),                                        // 1 zebra skin
        E.mat({ dif: 1, spec: 0.25, shin: 16, wrap: 0.5, ao: 0.5, grain: 0.05 }),                                       // 2 grey plate
        E.mat({ dif: 0.45, metal: 0.8, spec: 1.4, shin: 60, ao: 0.4, rim: 0.2, tint: [1.08, 1.02, 0.92], emis: 0.1 }),  // 3 gold
        E.mat({ dif: 0.4, metal: 0.85, spec: 1.6, shin: 70, ao: 0.3, bump: 0.6, tint: [1.08, 1.0, 0.9], emis: 0.08 }), // 4 gold pear
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.8, shin: 120, ao: 0.2, rim: 0.3, coat: 0.2, emis: 0.25 }),               // 5 chrome
        E.mat({ dif: 0.9, spec: 0.6, shin: 40, ao: 0.3, coat: 0.15 }),                                                  // 6 glossy red rim / stones
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, ao: 0.3, coat: 0.15 }),                                         // 7 blue pill
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.85, 0.82, 0.8], amb: [0.36, 0.36, 0.38],
      envTop: [1.35, 1.3, 1.24], envHor: [0.58, 0.52, 0.45], envBot: [0.3, 0.26, 0.22], envK: [1.1, 1.7, 0.2, 0],
      rimC: [0.25, 0.25, 0.3], rimD: [0, 1, 0], r1: 4, r2: 10, k: [0, 0.6, 0.4, 110], shadow: [-5, 8, 0.6, 7]
    });
    E.grain(0.03, 16);
  }
});
