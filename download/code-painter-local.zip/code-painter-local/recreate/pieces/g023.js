'use strict';
// g023 — "Porcelain squid vitrine": a white porcelain tangle of tentacles, bubbles and a striped squid
// in a lit display case, against a starry black night, a draped zebra cloth and a zebra cushion.
REC.register('g023', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (ctx, cv, alpha = 1) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const lin = (ctx, x0, y0, x1, y1, stops) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const WH = '#e6e4e6';

    // ── back: starfield, case wall, pillar, ceiling with a light strip ──
    const sky = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(0.012, 0.012, 0.02);
      vec2 g = floor(p / 9.); float h = hash(g); vec2 o = vec2(hash(g + 3.1), hash(g + 5.7)) * 9.;
      float s = smoothstep(1.4, 0.2, length(p - g * 9. - o)) * step(0.93, h) * (0.5 + 0.5 * hash(g + 9.));
      return c + vec3(s * 0.9, s * 0.92, s); }`);
    img(a, sky);
    R.paint(P([[-10, 120], [150, 90], [150, 1034], [-10, 1034]], true, false), lin(a, 0, 150, 0, 700, [[0, '#ddd3c0'], [0.25, '#cdc3af'], [0.7, '#c4beb2'], [1, '#9a9694']]));
    a.fillStyle = lin(a, 0, 0, 140, 0, [[0, 'rgba(255,255,255,0.0)'], [0.6, 'rgba(0,0,0,0.05)'], [1, 'rgba(0,0,0,0.25)']]); a.fill(P([[-10, 120], [150, 90], [150, 1034], [-10, 1034]], true, false));
    R.paint(P([[112, 118], [148, 108], [148, 700], [112, 700]], true, false), lin(a, 112, 0, 148, 0, [[0, '#7a7268'], [0.45, '#d8d0c0'], [0.6, '#a49c90'], [1, '#6a645c']]));
    R.paint(P([[-10, -10], [520, -10], [490, 0], [300, 64], [100, 124], [-10, 150]], true, false), lin(a, 0, 0, 260, 160, [[0, '#121010'], [0.45, '#3a3634'], [1, '#8a827c']]));
    R.paint(P([[150, -10], [520, -10], [500, 6], [300, 70], [150, 110]], true, false), lin(a, 150, 0, 480, 0, [[0, 'rgba(60,56,54,0.6)'], [1, 'rgba(120,112,104,0.9)']]));
    { const c2 = E.newCanvas(), x2 = c2.getContext('2d'); x2.setTransform(S, 0, 0, S, 0, 0); x2.fillStyle = '#fffbe8'; x2.fill(P([[-10, 128], [100, 104], [300, 40], [482, -10], [510, -10], [306, 70], [110, 140], [-10, 158]], true, false));
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.filter = `blur(${8 * S}px)`; a.globalAlpha = 0.4; a.drawImage(c2, 0, 0); a.filter = 'none'; a.globalAlpha = 1; a.drawImage(c2, 0, 0); a.restore(); }
    // snowflakes
    for (const [x, y, r] of [[420, 185, 18], [380, 128, 10], [452, 44, 8], [373, 90, 7]]) { a.strokeStyle = 'rgba(220,220,230,0.8)'; a.lineWidth = 1.2; for (let k = 0; k < 3; k++) { const t = k * Math.PI / 3; a.beginPath(); a.moveTo(x - Math.cos(t) * r, y - Math.sin(t) * r); a.lineTo(x + Math.cos(t) * r, y + Math.sin(t) * r); a.stroke(); } }

    // ── draped zebra cloth (top right) ──
    const cloth = P([[492, 92], [530, 60], [600, 40], [660, 24], [700, 18], [736, 26], [736, 470], [650, 466], [566, 452], [510, 420], [474, 372], [452, 310], [444, 240], [458, 170]], true, true);
    const clothCv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float fold = 10. * sin(p.x * 0.028 + p.y * 0.012) + 6. * sin(p.x * 0.05 - p.y * 0.03 + 1.3) + 8. * (fbm(p * 0.01) - .5);
      float ph = (p.y + (p.x - 600.) * (-0.25 + 0.0011 * (p.y - 60.)) + fold) / 17.5;
      float s = sin(6.2832 * ph);
      float sh = 0.86 + 0.14 * sin(p.x * 0.02 + p.y * 0.015);
      vec3 w = vec3(0.9, 0.89, 0.91) * sh, b = vec3(0.04, 0.04, 0.06);
      return mix(b, w, smoothstep(-0.55, -0.1, s)); }`);
    { const c2 = E.newCanvas(), x2 = c2.getContext('2d'); x2.setTransform(S, 0, 0, S, 0, 0); x2.strokeStyle = '#3c90ff'; x2.lineWidth = 12; x2.stroke(cloth);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.filter = `blur(${7 * S}px)`; a.drawImage(c2, 0, 0); a.restore(); }
    clipA(cloth, () => img(a, clothCv));
    a.strokeStyle = 'rgba(170,215,255,0.9)'; a.lineWidth = 3; a.stroke(cloth);

    // ── zebra cushion (bottom) ──
    const cush = P([[30, 900], [120, 884], [300, 872], [460, 878], [600, 884], [736, 890], [736, 1034], [40, 1034], [24, 980]], true, true);
    const cushCv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(640., 1220.)) * vec2(1., 1.7);
      float ph;
      float yy = max(p.y - 846., 1.); float Z = 2000. / (yy + 90.); float X = (p.x - 380.) * Z / 300.; ph = length(vec2(X, Z + 1.)) / 1.2;
      float s = sin(6.2832 * ph);
      vec3 w = vec3(0.84, 0.82, 0.84) * (0.75 + 0.25 * smoothstep(1024., 880., p.y)), b = vec3(0.03, 0.03, 0.04);
      return mix(b, w, smoothstep(-0.2, 0.2, s)); }`);
    R.paint(rrect(-10, 860, 746, 180, 0), '#0a0a0c');
    clipA(cush, () => img(a, cushCv));

    // ── soft blue rim glow behind the sculpture (on the night side) ──
    const glowShapes = [];
    // ── white porcelain sculpture ──
    const dome = (path, h0, dh, wd, alb = WH, m = 1) => { R.dome(path, alb, h0, dh, wd, m); glowShapes.push(path); };
    const sph = (x, y, r, h0 = 0.2, alb = WH) => dome(ellipseP(x, y, r, r * 0.96, 0), h0, Math.min(0.4, r * 0.008 + 0.12), r, alb);
    const tube = (pts, wd, h0 = 0.3, alb = WH) => { const p = P(pts, false); R.pipe(p, wd, alb, h0, 0.08 + wd * 0.004, 1); glowShapes.push(null, p, wd); };
    // shadowed porcelain mass behind the tangle
    R.dome(P([[110, 470], [170, 410], [260, 390], [380, 400], [470, 420], [560, 460], [580, 560], [560, 700], [420, 740], [240, 720], [110, 680], [90, 560]], true, true), '#a8a6ae', 0.04, 0.12, 40, 1);
    // big bottom bodies
    dome(P([[-10, 700], [60, 690], [140, 700], [220, 720], [290, 760], [300, 830], [250, 880], [120, 890], [-10, 880]], true, true), 0.06, 0.35, 70);
    dome(P([[280, 720], [400, 690], [520, 700], [620, 740], [640, 800], [600, 850], [480, 870], [340, 860], [280, 820]], true, true), 0.05, 0.3, 60, '#dcdade');
    for (const [x, y, rx, ry] of [[60, 760, 70, 60], [150, 790, 80, 70], [240, 760, 60, 55]]) dome(ellipseP(x, y, rx, ry, 0), 0.1, 0.3, rx * 0.8);
    // right side blobs and arm
    dome(P([[560, 470], [620, 456], [690, 448], [714, 470], [712, 520], [680, 540], [620, 530], [570, 534], [546, 510]], true, true), 0.2, 0.3, 40);
    dome(ellipseP(736, 360, 46, 66, 0), 0.2, 0.3, 40);
    dome(P([[736, 560], [736, 700], [660, 740], [600, 770], [560, 790], [520, 780], [520, 740], [570, 716], [640, 680], [700, 600]], true, true), 0.15, 0.35, 50);
    dome(P([[470, 740], [530, 716], [600, 724], [610, 770], [580, 806], [520, 812], [480, 790]], true, true), 0.2, 0.3, 40);
    // grape cluster and egg
    const gr = rng(23);
    const grapes = [[190, 450, 34], [235, 425, 36], [270, 455, 40], [320, 470, 36], [210, 510, 38], [260, 520, 42], [330, 530, 40], [190, 570, 36], [240, 580, 44], [300, 590, 40], [350, 600, 34],
      [220, 640, 38], [280, 650, 40], [330, 650, 30], [170, 620, 30], [380, 560, 28], [300, 410, 30], [350, 420, 24], [160, 520, 28]];
    for (const [x, y, r] of grapes) sph(x, y, r, 0.15 + gr() * 0.08);
    sph(318, 642, 32, 0.3); sph(262, 676, 26, 0.32);
    dome(ellipseP(432, 492, 58, 50, -0.2), 0.25, 0.35, 50);
    // creature head + body (top centre)
    dome(ellipseP(376, 210, 46, 36, 0.15), 0.3, 0.35, 34);
    for (const [x, y, r] of [[390, 272, 30], [432, 266, 32], [392, 312, 24], [440, 312, 22]]) sph(x, y, r, 0.28);
    R.pipe(P([[306, 186], [290, 160], [282, 150]], false), 14, '#d8c050', 0.4, 0.1, 5);
    R.pipe(P([[300, 192], [330, 186], [350, 190]], false), 12, '#d8c050', 0.4, 0.1, 5);
    tube([[350, 182], [345, 140], [352, 110]], 14, 0.38);
    tube([[340, 170], [325, 150], [330, 128]], 10, 0.36);
    R.bead(366, 205, 3, '#101014', 0.6, 0.02, 2);
    // striped tentacle bundle (left of the head)
    const sr = rng(5);
    for (let i = 0; i < 9; i++) {
      const x0 = 320 + sr() * 30, y0 = 220 + sr() * 30, x1 = 225 + i * 12 + sr() * 10, y1 = 290 + sr() * 40;
      const pts = [[x0, y0], [x0 - 40 - i * 4, y0 - 20 - sr() * 10], [x1 - 10, y1 - 70], [x1, y1]];
      tube(pts, 9, 0.3 + i * 0.01, i % 2 ? '#e8e8ec' : '#202024');
    }
    // the tangle: many thin curling tentacles
    const tg = rng(77);
    const curl = (x, y, ang, n, step, wd, turn) => { const pts = [[x, y]]; for (let k = 0; k < n; k++) { ang += turn * (0.6 + tg() * 0.8) + (tg() - 0.5) * 0.4; x += Math.cos(ang) * step; y += Math.sin(ang) * step; pts.push([x, y]); } return pts; };
    for (let i = 0; i < 46; i++) {
      const x = 80 + tg() * 500, y = 330 + tg() * 520;
      tube(curl(x, y, tg() * 6.28, 6 + Math.floor(tg() * 6), 14 + tg() * 10, 7 + tg() * 7, (tg() < 0.5 ? -1 : 1) * (0.15 + tg() * 0.25)), 7 + tg() * 7, 0.34 + tg() * 0.1);
    }
    // sweeping bundle below the head
    for (let i = 0; i < 14; i++) {
      const y0 = 250 + i * 6, x0 = 360 + tg() * 40;
      tube([[x0, y0], [300 - i * 4, y0 + 20 + tg() * 20], [230 - i * 3, y0 + 60 + tg() * 30], [200 + tg() * 40, y0 + 130 + tg() * 40]], 8 + tg() * 6, 0.3 + tg() * 0.1);
    }
    // big hooks and loops
    tube([[150, 640], [140, 520], [150, 420], [130, 360], [100, 350], [90, 380], [110, 400]], 22, 0.42);
    tube([[300, 560], [290, 470], [300, 400], [330, 360], [370, 370], [380, 400]], 16, 0.46);
    tube([[0, 890], [20, 850], [60, 832], [96, 850], [102, 900], [96, 916]], 34, 0.4);
    tube([[340, 880], [290, 900], [220, 880], [200, 840], [230, 820], [280, 830], [300, 860]], 22, 0.44);
    tube([[110, 700], [130, 740], [170, 770], [200, 800], [220, 840], [230, 880]], 30, 0.42);
    tube([[50, 700], [70, 600], [60, 560], [80, 520]], 12, 0.4);
    tube([[580, 670], [540, 640], [530, 680], [560, 700]], 10, 0.44);
    // thin feet at the bottom
    for (let i = 0; i < 14; i++) { const x = 330 + i * 16 + tg() * 8; tube([[x, 790], [x + (tg() - 0.5) * 30, 840], [x + (tg() - 0.5) * 40, 900]], 6, 0.46); }

    // ── striped squid + glass pipette ──
    const sq = P([[612, 252], [622, 290], [612, 340], [580, 400], [548, 460], [520, 520], [500, 575], [480, 580], [478, 540], [500, 470], [528, 400], [560, 320], [584, 262]], true, true);
    R.dome(sq, '#ecebee', 0.42, 0.25, 26, 1); glowShapes.push(sq);
    clipA(sq, () => { a.fillStyle = '#121216'; for (const [x0, y0, x1, y1] of [[600, 300, 520, 560], [575, 300, 498, 560]]) { a.beginPath(); a.moveTo(x0, y0); a.lineTo(x0 + 8, y0); a.lineTo(x1 + 8, y1); a.lineTo(x1, y1); a.closePath(); a.fill(); } });
    for (const [x, y] of [[566, 322], [602, 322], [590, 300]]) { R.bead(x, y, 9, '#e8e8ec', 0.66, 0.06, 1); R.bead(x, y, 5, '#1a1a20', 0.72, 0.02, 2); }
    for (let i = 0; i < 6; i++) tube([[470 + i * 16, 570], [450 + i * 18 + tg() * 20, 660], [440 + i * 22 + tg() * 30, 760], [430 + i * 26, 860]], 9, 0.48);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.55, shin: 40, wrap: 0.35, ao: 0.6, coat: 0.12, rim: 0.6 }),       // 1 porcelain
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.2, coat: 0.3 }),                             // 2 black gloss
        E.mat({}), E.mat({}),
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.9, shin: 30, emis: 0.1 })                           // 5 gold
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.7, 0.68, 0.68], amb: [0.36, 0.35, 0.38],
      envTop: [1, 1, 1.02], envHor: [0.6, 0.6, 0.68], envBot: [0.15, 0.15, 0.22], envK: [0.3, 0.9, 0.3, 0],
      rimC: [0.12, 0.2, 0.4], rimD: [0.3, 0.2, 0.4], r1: 1.6, r2: 7, k: [0, 0.6, 0.4, 100], shadow: [-6, 7, 0.5, 6]
    });

    // ── blue rim light on the night side ──
    { const c2 = E.newCanvas(), x2 = c2.getContext('2d'); x2.setTransform(S, 0, 0, S, 0, 0); x2.strokeStyle = '#4a9cff'; x2.lineCap = x2.lineJoin = 'round';
      for (let i = 0; i < glowShapes.length; i++) { const g = glowShapes[i]; if (g === null) { x2.lineWidth = glowShapes[i + 2] + 4; x2.stroke(glowShapes[i + 1]); i += 2; } else { x2.lineWidth = 5; x2.stroke(g); } }
      x2.globalCompositeOperation = 'destination-in'; x2.fillStyle = '#000'; x2.fill(P([[150, 80], [736, -10], [736, 880], [150, 880]], true, false));
      o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalCompositeOperation = 'screen'; o.filter = `blur(${4 * S}px)`; o.globalAlpha = 0.35; o.drawImage(c2, 0, 0); o.restore(); }

    // ── glass: pipette, leaves, bubbles, pendant, jar ──
    const glass = (path, a1 = 0.25) => { o.fillStyle = `rgba(200,220,240,${a1})`; o.fill(path); o.strokeStyle = 'rgba(235,245,255,0.85)'; o.lineWidth = 2; o.stroke(path); };
    glass(P([[640, -10], [664, -10], [626, 250], [604, 250]], true, false), 0.3);
    o.strokeStyle = 'rgba(255,255,255,0.7)'; o.lineWidth = 3; o.beginPath(); o.moveTo(650, 0); o.lineTo(616, 240); o.stroke();
    glass(rrect(596, 200, 34, 60, 6), 0.35);
    glass(P([[672, 40], [690, 80], [694, 110], [684, 112], [676, 80]], true, true), 0.3);
    for (const pts of [[[380, 365], [440, 350], [520, 372], [450, 392]], [[400, 380], [460, 400], [520, 380], [460, 372]], [[470, 330], [500, 260], [520, 320], [500, 380]]]) glass(P(pts, true, true), 0.22);
    const bub = (x, y, r) => { const g = o.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r); g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(0.35, 'rgba(190,210,235,0.45)'); g.addColorStop(0.9, 'rgba(120,150,190,0.35)'); g.addColorStop(1, 'rgba(230,240,255,0.9)'); o.fillStyle = g; o.fill(circleP(x, y, r)); };
    bub(170, 285, 30); bub(192, 386, 30); bub(32, 476, 28); bub(610, 622, 22); bub(410, 590, 8); bub(294, 527, 9); bub(248, 768, 9); bub(294, 680, 8); bub(430, 592, 6); bub(520, 690, 14);
    o.strokeStyle = 'rgba(220,220,230,0.8)'; o.lineWidth = 1.2; o.beginPath(); o.moveTo(610, 540); o.lineTo(610, 600); o.stroke(); o.beginPath(); o.moveTo(28, 504); o.lineTo(28, 700); o.stroke(); o.beginPath(); o.moveTo(168, 315); o.lineTo(168, 360); o.stroke();
    // jar
    { const jx = 610, jy = 888; const body = P([[530, 868], [690, 868], [688, 920], [660, 940], [560, 940], [532, 920]], true, true);
      glass(body, 0.25); o.fillStyle = 'rgba(80,130,220,0.35)'; o.fill(ellipseP(jx, 918, 60, 12, 0));
      o.fillStyle = '#e8e8ec'; o.fill(ellipseP(jx, 856, 80, 18, 0)); o.fillStyle = '#16161a'; o.fill(rrect(530, 856, 160, 18, 6)); o.fillStyle = '#d8d8dc'; o.fill(rrect(530, 872, 160, 6, 3));
      o.fillStyle = '#f2f2f4'; o.fill(ellipseP(jx, 850, 78, 14, 0)); o.fillStyle = '#b8b8c0'; o.fill(ellipseP(jx, 850, 34, 6, 0)); }
    E.bloom(0.12, 10);
    E.grain(0.03, 23);
  }
});
