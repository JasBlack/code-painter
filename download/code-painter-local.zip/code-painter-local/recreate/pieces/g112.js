'use strict';
// g112 — "Zebra sleepers' still life": two zebra-striped figures — one sprawled over the top reaching for a
// grey shelf, one crouched below a wire dome — around an orange eye planet, a radio, a spool, a coil and a box frame.
REC.register('g112', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd, cap = 'round') => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = cap; o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, stops, x1 = x, y1 = y) => { const g = o.createRadialGradient(x, y, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const L = (pts) => P(pts, false, false);

    // ── textures ──
    const concrete = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.675, .635, .625) + .03 * (fbm(p * .02) - .5);
      c *= 1. - .35 * step(.985, hash(floor(p / 1.6)));
      c += .05 * (hash(p) - .5);
      return c; }`));
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * vec2(.02, .035) + 3.);
      return mix(vec3(.38, .92, .96), vec3(.93, .98, 1.), smoothstep(.55, .75, n)); }`));
    const planet = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * .018 + 11.), m = fbm(p * .06);
      vec3 c = vec3(.98, .40, .02);
      c = mix(c, vec3(.99, .55, .22), smoothstep(.5, .62, n) * (.6 + .4 * m));
      c = mix(c, vec3(.92, .34, .02), smoothstep(.62, .5, n) * .3);
      return c; }`));
    const fur = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float a = vnoise(vec2(p.x * .25, p.y * .05)) * .6 + vnoise(vec2(p.x * .6 + p.y * .2, p.y * .09)) * .4;
      return vec3(.05, .045, .05) + vec3(.22, .21, .22) * smoothstep(.45, .9, a); }`));
    const pebbles = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p / 13.; vec2 i = floor(q), f = fract(q); float d = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 r = g + vec2(hash(i + g), hash(i + g + 5.3)) * .8 + .1 - f; d = min(d, length(r * vec2(1., 1.3))); }
      vec3 c = vec3(.05, .15, .58);
      c = mix(c, vec3(.13, .26, .80), smoothstep(.42, .30, d));
      return c; }`));
    const olive = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      return mix(vec3(.55, .37, .05), vec3(.30, .20, .02), step(.9, hash(floor(p / 2.)))); }`));
    const zeb = (body) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ ${body}
      float v = cos(6.2832 * f);
      vec3 w = vec3(.97, .96, .94) - .04 * hash(p);
      return mix(vec3(.02), w, smoothstep(-.15, .15, v)); }`));
    // stripe phase fields (polynomial coefficients fitted offline to the stripe flow)
    const zTop = zeb(`vec2 n = (p - vec2(250., 200.)) / vec2(180., 100.); float X = n.x, Y = n.y, X2 = X*X, Y2 = Y*Y, X3 = X2*X, Y3 = Y2*Y;
      float f = -0.1858 + 0.4993*Y + 5.8890*X - 0.5905*Y2 + 0.0396*X*Y - 0.2120*X2 - 0.5472*Y3 - 1.9753*X*Y2 + 0.2073*X2*Y + 0.8423*X3
        - 0.5953*Y2*Y2 + 1.8085*X*Y3 + 2.9166*X2*Y2 + 1.2496*X3*Y - 0.2207*X2*X2 + 0.2673*Y3*Y2 + 3.4802*X*Y2*Y2 + 1.3394*X2*Y3
        + 2.0043*X3*Y2 + 1.9307*X2*X2*Y - 0.4009*X3*X2;`);
    const zBot = zeb(`vec2 n = (p - vec2(330., 850.)) / vec2(210., 160.); float X = n.x, Y = n.y, X2 = X*X, Y2 = Y*Y, X3 = X2*X, Y3 = Y2*Y;
      float f = -0.2632 + 4.1555*Y - 4.7628*X + 1.4684*Y2 - 2.8262*X*Y - 0.5501*X2 + 2.9273*Y3 - 3.5952*X*Y2 - 1.6947*X2*Y + 1.5119*X3
        + 3.1664*Y2*Y2 + 15.6736*X*Y3 + 8.3783*X2*Y2 + 3.3014*X3*Y - 1.3050*X2*X2 + 3.5614*Y3*Y2 + 21.9155*X*Y2*Y2 + 10.4823*X2*Y3
        + 6.2773*X3*Y2 + 4.3462*X2*X2*Y - 3.4567*X3*X2;`);
    const zDome = zeb(`vec2 n = (p - vec2(470., 960.)) / vec2(220., 80.); float X = n.x, Y = n.y, X2 = X*X, Y2 = Y*Y;
      float f = -0.0158 + 3.0157*Y - 1.2226*X - 0.5879*Y2 - 0.9911*X*Y - 4.9308*X2 + 0.3987*Y2*Y + -0.1568*X*Y2 + 0.5792*X2*Y + 1.1935*X2*X
        + 0.0866*Y2*Y2 - 0.2778*X*Y2*Y + -0.5062*X2*Y2 + 0.5296*X2*X*Y - 0.7262*X2*X2;`);

    // ════════ background ════════
    fill(rrect(0, 0, 726, 1024, 0), concrete);
    fill(rrect(644, 0, 82, 880, 0), '#f8f7f4');
    // sky window + green blob + orange sole (top-left)
    fill(P([[96, -2], [280, -2], [280, 108], [236, 116], [195, 136], [177, 134], [158, 110], [140, 100], [100, 100], [96, 60]], true, false), sky);
    fill(P([[-5, -5], [205, -5], [206, 30], [190, 58], [150, 74], [80, 78], [30, 70], [-5, 62]]), '#10f018');
    fill(P([[-5, 50], [40, 62], [90, 66], [150, 62], [192, 50], [190, 58], [150, 74], [80, 78], [30, 70], [-5, 62]]), '#0ab814');
    fill(P([[74, -5], [198, -5], [196, 16], [172, 26], [102, 24], [80, 14]]), '#f99418');
    stroke(P([[80, 14], [102, 24], [172, 26], [196, 16]], false), '#b85a10', 3);
    fill(P([[0, 62], [100, 70], [96, 135], [0, 135]], true, false), '#9a908e');
    fill(P([[58, 98], [76, 94], [70, 108]], true, false), '#151515');
    fill(circleP(208, 97, 16), '#fb5f03');

    // ════════ radio (top) ════════
    fill(rrect(277, -10, 365, 112, 6), '#060606');
    fill(rrect(283, 54, 353, 44, 6), '#2e2d30');
    fill(rrect(281, 98, 357, 10, 2), '#1a1a1c');
    for (let x = 290; x < 636; x += 22) fill(rrect(x, 100, 14, 5, 1), '#3a3a3e');
    for (const x of [436, 454, 472, 490]) fill(rrect(x, 74, 12, 6, 3), '#22e2f0');
    for (let i = 0; i < 12; i++) fill(rrect(556 + i * 6, 76, 4, 9, 1), '#e8e8ec');
    stroke(circleP(566, 8, 20), '#22d8e8', 7, 'butt');
    o.save(); o.setLineDash([5, 4]); stroke(circleP(566, 8, 20), '#060606', 7, 'butt'); o.restore();
    for (const [x, y, r] of [[322, 30, 9], [455, 20, 9], [548, 45, 7]]) fill(P(star(x, y, r, r * 0.42, 5, -Math.PI / 2), true, false), '#f0f0f0');
    for (const [x, y] of [[340, 10], [430, 8], [470, 38], [520, 30], [600, 40], [395, 44]]) fill(circleP(x, y, 2.5), '#e8e8e8');
    fill(rrect(370, 16, 3, 12, 1), '#f0f0f0'); fill(rrect(380, 18, 12, 3, 1), '#f0f0f0'); fill(rrect(380, 24, 12, 3, 1), '#f0f0f0'); fill(rrect(396, 18, 12, 3, 1), '#f0f0f0'); fill(rrect(396, 24, 12, 3, 1), '#f0f0f0');

    // ════════ top zebra figure + orange arm ════════
    const topBody = P([[64, 105], [102, 100], [139, 100], [158, 110], [177, 134], [195, 136], [236, 116], [280, 108], [440, 112], [440, 143], [416, 143], [398, 155], [350, 220], [337, 284], [279, 284], [258, 288], [230, 297], [185, 303], [152, 293], [128, 281], [102, 250], [83, 198], [67, 159], [70, 118]]);
    fill(P([[-5, 205], [85, 200], [102, 250], [128, 281], [140, 290], [110, 302], [-5, 304]]), '#9ef2ea');
    fill(topBody, zTop);
    // cyan zigzags behind
    stroke(L([[252, 288], [263, 323], [204, 333], [206, 390]]), '#14f0f8', 8, 'butt');
    stroke(L([[312, 282], [331, 392]]), '#14f0f8', 8, 'butt');
    stroke(L([[325, 348], [278, 360], [285, 392]]), '#14f0f8', 8, 'butt');
    stroke(L([[76, 524], [92, 500], [124, 514], [150, 482], [182, 492]]), '#22e8f4', 7);
    // arm
    const arm = P([[-5, 205], [45, 212], [70, 240], [100, 280], [125, 305], [100, 335], [60, 310], [25, 280], [-5, 262]]);
    fill(arm, lin(60, 230, 30, 280, [[0, '#fc9a20'], [0.6, '#fb8c12'], [1, '#e07010']]));
    // blue fluffy cuffs
    const fluff = (cx, cy, rx, ry, seed, n) => { const r = rng(seed); for (let i = 0; i < n; i++) { const a = r() * Math.PI * 2, d = Math.sqrt(r()); const x = cx + Math.cos(a) * rx * d, y = cy + Math.sin(a) * ry * d; fill(circleP(x, y, 9 + r() * 7), r() < 0.5 ? '#1a2ad8' : '#0f1cc0'); } };
    fluff(36, 172, 40, 48, 3, 70);
    // hand
    const hand = P([[150, 330], [196, 322], [236, 340], [256, 364], [252, 380], [224, 378], [200, 390], [180, 412], [168, 404], [164, 380]]);
    fill(hand, lin(150, 330, 250, 390, [[0, '#f59a48'], [1, '#f08430']]));
    stroke(L([[200, 336], [236, 352]]), '#fde0c0', 3); stroke(L([[204, 344], [240, 360]]), '#fde0c0', 2);
    fluff(124, 350, 38, 42, 9, 60);

    // ════════ orange eye planet ════════
    const pc = circleP(507, 270, 166);
    fill(pc, planet);
    clipped(pc, () => {
      o.save(); o.globalCompositeOperation = 'multiply';
      fill(pc, rad(560, 220, 60, 200, [[0, 'rgba(255,255,255,0)'], [0.75, 'rgba(255,255,255,0)'], [1, 'rgba(225,120,90,0.8)']]));
      o.restore();
    });
    const B = '#1630d0';
    for (const r of [[432, 128, 90, 14, 6], [445, 145, 70, 12, 6], [432, 158, 52, 11, 5]]) stroke(rrect(...r), '#101010', 5);
    for (const [x, y, r] of [[468, 188, 10], [518, 176, 8], [551, 172, 7], [575, 248, 8]]) fill(circleP(x, y, r), B);
    stroke(L([[555, 192], [605, 194]]), B, 8); stroke(L([[530, 210], [612, 206]]), B, 9); stroke(L([[562, 226], [595, 226]]), B, 7);
    const eye = P([[438, 250], [460, 232], [488, 226], [516, 232], [532, 250], [508, 262], [482, 266], [456, 262]]);
    fill(eye, '#f8f8f8');
    clipped(eye, () => { fill(circleP(484, 260, 16), '#22d6f0'); fill(rrect(430, 220, 110, 26, 0), B); });
    for (const [x, y] of [[456, 240], [472, 235], [490, 234], [508, 238]]) fill(circleP(x, y, 4), '#d8f040');
    stroke(eye, B, 5);
    const purple = P([[418, 262], [432, 258], [442, 272], [438, 292], [456, 298], [482, 288], [505, 285], [520, 292], [524, 304], [508, 302], [498, 312], [478, 308], [464, 318], [470, 338], [490, 352], [480, 360], [478, 386], [466, 386], [462, 362], [450, 362], [440, 390], [428, 388], [434, 362], [418, 370], [400, 390], [390, 384], [410, 360], [388, 358], [386, 348], [412, 342], [390, 330], [396, 320], [420, 326], [420, 298]]);
    fill(purple, '#c672e2');
    stroke(purple, B, 4);

    // ════════ shelf + yellow block ════════
    fill(P([[540, 374], [646, 356], [666, 364], [556, 402]], true, false), '#dcc524');
    fill(P([[556, 402], [666, 364], [666, 420], [566, 446]], true, false), olive);
    // black frame under the shelf
    fill(P([[205, 455], [404, 470], [404, 497], [288, 497], [365, 700], [390, 722], [290, 726], [250, 620]], true, false), '#060606');
    fill(P([[170, 398], [250, 383], [556, 428], [500, 448]], true, false), lin(170, 390, 550, 440, [[0, '#d2d1cd'], [1, '#c6c5c1']]));
    fill(P([[170, 398], [500, 448], [500, 502], [170, 446]], true, false), lin(0, 400, 0, 500, [[0, '#b8b6b2'], [1, '#a8a6a2']]));
    fill(P([[500, 448], [556, 428], [556, 452], [500, 502]], true, false), '#8e8c88');
    for (const x of [190, 199, 208]) fill(circleP(x, 433 + (x - 190) * 0.12, 2.6), '#2a2a2a');

    // ════════ dark panel (right middle) ════════
    fill(P([[520, 450], [642, 440], [642, 870], [420, 870], [430, 700], [520, 690]], true, false), '#0a0608');
    fill(P([[420, 700], [642, 700], [642, 870], [410, 870]], true, false), '#192685');
    fill(P([[600, 760], [642, 720], [642, 870], [560, 870]], true, false), '#1a2a90');
    stroke(L([[530, 470], [634, 450], [632, 700], [590, 780], [520, 800], [470, 812]]), '#f0188e', 9);
    stroke(L([[600, 500], [582, 640], [560, 704], [500, 740]]), '#d01080', 7);
    stroke(L([[540, 560], [552, 590], [538, 620]]), '#1a3ce0', 7);
    stroke(L([[600, 500], [620, 520], [604, 556]]), '#1a3ce0', 7);
    stroke(L([[588, 590], [610, 562], [624, 596], [640, 570], [660, 590]]), '#f07020', 9);
    stroke(L([[476, 812], [500, 790], [520, 822], [546, 796], [556, 820]]), '#f07020', 9);
    fill(circleP(540, 508, 9), '#f07020'); fill(circleP(500, 720, 9), '#e85020');

    // ════════ fur behind the box + box frame ════════
    fill(P([[360, 498], [420, 494], [440, 540], [440, 690], [400, 700], [372, 690], [356, 640], [362, 580], [372, 540]]), fur);
    fill(P([[372, 690], [384, 668], [396, 680], [408, 668], [404, 696]]), '#f05a10');
    fill(P([[408, 548], [575, 535], [590, 548], [588, 700], [420, 702], [408, 690]], true, false), '#f2c282');
    fill(P([[408, 548], [575, 535], [590, 548], [424, 562]], true, false), '#f8d494');
    fill(P([[452, 572], [548, 572], [548, 658], [452, 658]], true, false), '#08070b');
    fill(P([[430, 560], [452, 572], [452, 658], [430, 680]], true, false), '#d8a466');
    fill(P([[430, 680], [452, 658], [548, 658], [566, 680]], true, false), '#eab878');
    fill(P([[452, 572], [548, 572], [566, 556], [430, 560]], true, false), '#c49050');
    o.save(); o.translate(515, 640); o.rotate(0.35); fill(rrect(-7, -18, 14, 34, 3), '#f06018'); fill(ellipseP(0, -18, 7, 3), '#f8a070'); o.restore();

    // ════════ spool ════════
    fill(rrect(108, 576, 108, 222, 4), lin(108, 0, 216, 0, [[0, '#f09020'], [0.5, '#f9a83a'], [1, '#e88a20']]));
    for (let y = 612; y < 768; y += 10.5) fill(rrect(118, y, 88, 3.2, 1.5), '#fde3c8');
    fill(rrect(108, 770, 108, 28, 3), '#fbe4d0');
    fill(ellipseP(162, 578, 54, 10), '#fde3ce');
    fill(ellipseP(162, 575, 34, 7), '#f08a18');

    // ════════ coil spring ════════
    const coil = [[396, 506], [362, 548], [330, 578], [298, 602], [266, 640], [246, 680], [240, 716], [236, 746]];
    const cpts = [];
    for (let i = 0; i < coil.length - 1; i++) { const n = Math.max(1, Math.round(Math.hypot(coil[i + 1][0] - coil[i][0], coil[i + 1][1] - coil[i][1]) / 17)); for (let k = 0; k < n; k++) { const t = k / n; cpts.push([coil[i][0] + (coil[i + 1][0] - coil[i][0]) * t, coil[i][1] + (coil[i + 1][1] - coil[i][1]) * t]); } }
    cpts.push(coil[coil.length - 1]);
    for (let i = cpts.length - 1; i >= 0; i--) {
      const p = cpts[i], q = cpts[Math.min(cpts.length - 1, i + 1)], pp = cpts[Math.max(0, i - 1)];
      const ang = Math.atan2(q[1] - pp[1], q[0] - pp[0]) + Math.PI / 2;
      o.save(); o.translate(p[0], p[1]); o.rotate(ang);
      fill(ellipseP(0, 1, 24, 7), '#0c0c0c');
      stroke(P([[-19, 3], [-8, 6], [8, 6], [19, 3]], false), '#fafafa', 3.5);
      stroke(ellipseP(0, 0, 27, 9), '#1a0a04', 11);
      stroke(ellipseP(0, 0, 27, 9), '#f8661a', 8);
      o.restore();
    }

    // ════════ black fur bottom-right + pebble floor + pearls ════════
    fill(P([[480, 880], [560, 862], [640, 858], [736, 866], [736, 1034], [480, 1034]]), fur);
    stroke(L([[500, 878], [560, 864], [640, 860], [726, 868]]), '#cdbb9e', 12);
    fill(P([[-5, 846], [60, 842], [110, 840], [150, 850], [200, 880], [260, 900], [300, 930], [300, 1034], [-5, 1034]]), pebbles);
    for (const [x, y, r] of [[65, 970, 30], [150, 975, 28], [-4, 974, 24]]) {
      fill(circleP(x, y, r), rad(x - r * 0.35, y - r * 0.35, 1, r * 1.1, [[0, '#ffffff'], [0.25, '#fde4cc'], [0.85, '#f4c8a4'], [1, '#d8a888']]));
    }

    // ════════ bottom zebra figure + wire dome ════════
    const botBody = P([[120, 830], [135, 790], [180, 770], [225, 760], [262, 735], [290, 712], [330, 700], [400, 697], [440, 700], [454, 740], [448, 790], [470, 806], [500, 812], [530, 835], [530, 870], [515, 890], [470, 895], [430, 880], [400, 885], [370, 905], [330, 935], [310, 970], [300, 1005], [260, 1010], [225, 985], [212, 950], [205, 925], [160, 905], [130, 880]]);
    fill(botBody, zBot);
    const dome = ellipseP(470, 1062, 226, 178);
    fill(dome, zDome);
    const G = '#9a9ea4';
    stroke(dome, G, 9);
    clipped(dome, () => {
      for (const rx of [60, 120, 175]) stroke(ellipseP(470, 1062, rx, 178), G, 8);
      for (const [cx, rx] of [[330, 140], [610, 140]]) stroke(ellipseP(cx, 1062, rx, 160), G, 7);
      stroke(ellipseP(470, 1062, 226, 110), G, 7);
    });

    // ════════ chain tower (right) ════════
    fill(rrect(676, 430, 46, 440, 0), '#d8d8d8');
    clipped(rrect(676, 430, 46, 440, 0), () => {
      for (let y = 400; y < 900; y += 16) { stroke(L([[670, y], [730, y + 50]]), '#505050', 2.5); stroke(L([[730, y], [670, y + 50]]), '#505050', 2.5); }
      for (const y of [510, 572, 630, 690, 752, 832]) { stroke(circleP(700, y, 10), '#141414', 6); fill(circleP(686, y - 8, 3), '#c03a20'); fill(circleP(712, y + 8, 3), '#c03a20'); }
    });
    fill(rrect(668, 350, 58, 80, 6), lin(668, 0, 726, 0, [[0, '#8a8a8a'], [0.4, '#e0e0e0'], [1, '#9a9a9a']]));
    fill(ellipseP(697, 356, 28, 9), '#3a3a3a');
    stroke(L([[700, 356], [714, 354]]), '#c03a20', 3);

    // ════════ yellow zigzags (left) ════════
    stroke(L([[-4, 434], [42, 432], [68, 650], [-4, 690]]), '#f8ee10', 8);
    stroke(L([[-4, 716], [30, 714], [44, 748], [-4, 762]]), '#f8ee10', 8);
    stroke(L([[-4, 832], [28, 846], [56, 812], [86, 838], [118, 802]]), '#f8ee10', 8);

    E.grain(0.035, 112);
  }
});
