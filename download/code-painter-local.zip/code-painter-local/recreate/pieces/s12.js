'use strict';
// s12 — "Melting crooner": a small porcelain-and-gold figure with zebra-striped legs,
// hands clasped to its face, standing on a speckled indigo stage before a forest of grey
// grooved trunks, a sand-speckled tree with droplet cells and a wet lilac wall with a black drip.
REC.register('s12', {
  w: 768, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const W = 768, H = 1024;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const texIn = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, W, H); a.restore(); };
    const full = rrect(-10, -10, W + 20, H + 20, 0);

    // grooved-stripe texture (albedo) + matching height stripes
    const stripes = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float w = px.x + 26.0 * fbm(px * vec2(0.004, 0.012)) + 6.0 * sin(px.y * 0.02);
        float s = 0.5 + 0.5 * sin(w * 0.42);
        float lit = 0.7 + 0.4 * smoothstep(0.2, 0.9, fbm(px * 0.004 + 3.0));
        vec3 c = mix(vec3(0.16, 0.16, 0.18), vec3(0.72, 0.70, 0.72), smoothstep(0.3, 0.7, s)) * lit;
        return c;
      }`);
    const sand = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float g = hash(floor(px)), n = fbm(px * 0.02);
        vec3 c = mix(vec3(0.34, 0.33, 0.29), vec3(0.64, 0.62, 0.55), n);
        c *= 0.6 + 0.7 * g;
        return c;
      }`);
    const lilac = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.015), g = hash(floor(px * 0.8));
        vec3 c = mix(vec3(0.40, 0.39, 0.46), vec3(0.56, 0.54, 0.62), n);
        return c * (0.9 + 0.2 * g);
      }`);
    const floorT = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float g = hash(floor(px * 0.7)), n = fbm(px * vec2(0.01, 0.04));
        vec3 c = mix(vec3(0.20, 0.22, 0.36), vec3(0.34, 0.36, 0.54), n);
        c *= 0.8 + 0.4 * g;
        c = mix(c, vec3(0.55, 0.22, 0.30), step(0.93, hash(floor(px * 0.35) + 3.0)) * 0.8);
        return c;
      }`);

    // ── backdrop: grooved trunks ──
    R.flat(full, '#3a383c', 0.05, 1); texIn(full, stripes);
    // stripe relief: vertical grooves across the back
    for (let x = 4; x < W; x += 15) {
      const pts = []; for (let y = -10; y <= 850; y += 40) pts.push([x + 10 * Math.sin(y * 0.012 + x * 0.05) + 8 * (noise2(x * 0.05, y * 0.01) - 0.5), y]);
      R.groove(P(pts, false), 7, null, 0.08, 0.03, 1);
    }
    // dark gaps between trunks
    soft(x => { fillE(x, 190, 450, 80, 380, 0, '#0c0c0e'); fillE(x, 260, 80, 60, 120, 0, '#141414'); fillE(x, 20, 820, 60, 60, 0, '#141418'); }, 30, 0.7);
    // top-left horizontal striped arm
    const arm = P([[170, -10], [420, -10], [410, 30], [360, 60], [260, 62], [175, 40]]);
    R.dome(arm, '#8a8690', 0.14, 0.08, 20, 1);
    a.save(); a.clip(arm); a.strokeStyle = '#2a2a2e'; a.lineWidth = 4; for (let i = 0; i < 8; i++) { a.beginPath(); a.moveTo(160, 2 + i * 8); a.bezierCurveTo(250, 10 + i * 8, 330, -4 + i * 8, 430, 6 + i * 7); a.stroke(); } a.restore();
    R.dome(P([[220, -10], [260, -10], [258, 20], [236, 26]]), '#d8d4d0', 0.24, 0.04, 8, 2);

    // ── centre tree: sandy trunk with droplet cells, striped arching right edge ──
    const trunk = P([[330, -10], [590, -10], [640, 60], [600, 180], [560, 260], [540, 360], [540, 520], [548, 700], [560, 840], [300, 840], [360, 700], [380, 520], [370, 360], [350, 200], [330, 90]]);
    R.dome(trunk, '#7a7466', 0.1, 0.08, 40, 6); texIn(trunk, sand);
    // lighter sandy centre + darker lower trunk
    soft(x => { fillE(x, 470, 200, 90, 180, 0, '#8a8676'); fillE(x, 460, 720, 90, 140, 0, '#3a3830'); }, 40, 0.5, 'source-over', trunk);
    { const r = rng(12); for (let i = 0; i < 48; i++) { const y = 10 + r() * 420, x = 370 + r() * 200 - y * 0.05, rr = 8 + r() * 18; const e = ellipseP(x, y, rr * 1.1, rr, r() * 3); a.save(); a.clip(e); a.globalAlpha = 0.5; a.drawImage(sand, 0, 0, W, H); a.restore(); R.dome(e, null, 0.12, 0.03, rr * 0.8, 6); R.groove(e, 3, '#24221e', 0.15, 0.015, 6, 0.6); } }
    // striped arch rising to the right
    const archOut = P([[560, -10], [778, -10], [778, 150], [720, 160], [650, 210], [600, 280], [560, 360], [545, 300], [575, 200], [610, 90]]);
    R.dome(archOut, '#9a96a4', 0.12, 0.1, 40, 1); texIn(archOut, stripes, 0.6);
    for (let i = 0; i < 9; i++) R.groove(P([[570 + i * 6, 340 - i * 16], [600 + i * 8, 220 - i * 12], [680 + i * 6, 120 - i * 12], [780, 60 - i * 10]], false), 5, '#3a3a40', 0.2, 0.04, 1, 0.7);

    // ── right: wet lilac wall with droplets and a black drip ──
    const wall = P([[590, 300], [640, 220], [720, 165], [778, 150], [778, 850], [555, 850], [548, 600], [555, 400]]);
    R.flat(wall, '#7e7a8c', 0.1, 4); texIn(wall, lilac);
    { const r = rng(21); for (let i = 0; i < 150; i++) { const x = 560 + r() * 210, y = 180 + r() * 660, rr = 2 + r() * r() * 16; R.dome(ellipseP(x, y, rr, rr * (0.8 + r() * 0.5), r() * 3), '#8e8a9e', 0.12, 0.05 + rr * 0.004, rr * 0.7, 4); } }
    R.dome(P([[660, 360], [700, 340], [740, 360], [740, 420], [700, 440], [665, 410]]), '#8a869c', 0.12, 0.06, 20, 4);
    R.dome(P([[640, 440], [700, 470], [690, 560], [660, 600], [630, 560]]), '#8a869c', 0.12, 0.05, 20, 4);
    const drip = P([[612, 660], [640, 640], [676, 650], [690, 690], [688, 800], [690, 940], [676, 950], [664, 800], [650, 700], [630, 690]]);
    R.dome(drip, '#0a0a0c', 0.14, 0.08, 16, 5);
    R.pipe(P([[640, 668], [660, 690], [668, 760]], false), 6, '#5a5a6a', 0.24, 0.02, 5);

    // ── stage floor ──
    const ledge = P([[-10, 838], [778, 838], [778, 935], [-10, 945]], true, false);
    R.dome(ledge, '#3a3e62', 0.12, 0.06, 20, 6); texIn(ledge, floorT);
    const fl = P([[-10, 935], [778, 925], [778, 1034], [-10, 1034]], true, false);
    R.flat(fl, '#2c3050', 0.08, 6); texIn(fl, floorT);
    soft(x => { x.fillStyle = '#10121e'; x.fillRect(-10, 838, 800, 16); fillE(x, 30, 945, 60, 20, 0, '#050508'); fillE(x, 700, 940, 60, 14, 0, '#050508'); }, 6, 0.7);
    { const r = rng(5); for (let i = 0; i < 80; i++) { const x = 120 + r() * 660, y = 940 + r() * 84, rr = 2 + r() * 8; R.dome(ellipseP(x, y, rr * 1.4, rr * 0.7, 0), '#b8bccc', 0.1, 0.03, rr * 0.5, 7); } }
    { const r = rng(6); a.save(); a.clip(ledge); for (let i = 0; i < 700; i++) { a.fillStyle = r() < 0.7 ? 'rgba(230,235,255,0.7)' : 'rgba(210,90,120,0.8)'; a.fillRect(r() * W, 838 + r() * 100, 1.5, 1.5); } a.restore(); }

    // ── the figure ──
    const GOLD = '#8a7c5c', WH = '#d0ced0';
    // legs: zebra stripes
    const legs = P([[205, 720], [300, 700], [330, 740], [360, 700], [430, 690], [430, 800], [420, 900], [440, 1034], [340, 1034], [330, 900], [320, 820], [300, 900], [290, 1034], [210, 1034], [215, 900]]);
    R.dome(legs, '#c8c6c4', 0.3, 0.12, 40, 2);
    a.save(); a.clip(legs); a.strokeStyle = '#1a1a1c'; a.lineWidth = 5.5;
    for (let x = 200; x < 450; x += 12) { a.beginPath(); a.moveTo(x, 690); a.bezierCurveTo(x + 6, 800, x - 6, 900, x + 3, 1034); a.stroke(); } a.restore();
    for (let x = 206; x < 450; x += 12) R.groove(P([[x, 700], [x + 6, 800], [x - 6, 900], [x + 3, 1034]], false), 6, null, 0.42, 0.04, 2);
    R.bead(255, 818, 10, WH, 0.44, 0.06, 2); R.bead(350, 760, 8, WH, 0.44, 0.06, 2); R.dome(P([[330, 930], [360, 920], [370, 1000], [345, 1034], [330, 1000]]), WH, 0.4, 0.08, 14, 2);
    // gold torso
    const torso = P([[190, 470], [230, 440], [290, 440], [340, 480], [400, 540], [430, 600], [425, 680], [380, 720], [300, 730], [230, 725], [200, 690], [205, 620], [190, 560]]);
    R.dome(torso, GOLD, 0.3, 0.3, 60, 3);
    // white swirl folds on the torso
    for (const t of [[[210, 690], [260, 700], [320, 690], [380, 700], [420, 680]], [[240, 620], [280, 650], [330, 640], [360, 600]], [[300, 700], [320, 660], [350, 670]], [[380, 600], [400, 640], [410, 680]]])
      R.pipe(P(t, false), 22, WH, 0.5, 0.1, 2);
    for (const t of [[[215, 470], [250, 520], [240, 580]], [[280, 470], [300, 520], [350, 540], [400, 560]], [[260, 560], [290, 600], [250, 640]]]) R.pipe(P(t, false), 12, '#c8c4bc', 0.5, 0.06, 2);
    R.bead(298, 707, 10, '#e8e6e4', 0.62, 0.06, 2); R.bead(232, 735, 20, WH, 0.52, 0.12, 2);
    // white bulb on the left
    R.dome(P([[190, 480], [230, 470], [260, 490], [265, 540], [250, 590], [210, 590], [180, 560], [178, 510]]), '#c4c0b8', 0.5, 0.2, 40, 2);
    R.dome(ellipseP(198, 497, 10, 8, 0), '#2a2620', 0.66, -0.04, 6, 2);
    R.dome(P([[178, 520], [200, 580], [230, 600], [200, 610], [180, 580]]), GOLD, 0.45, 0.1, 16, 3);
    // head (gold swirl)
    const head = P([[290, 300], [330, 285], [370, 295], [395, 330], [405, 380], [410, 420], [380, 430], [360, 410], [345, 380], [310, 370], [290, 345]]);
    R.dome(head, GOLD, 0.4, 0.25, 40, 3);
    R.pipe(P([[300, 310], [340, 300], [370, 320], [375, 360]], false), 14, '#e0dcd6', 0.62, 0.05, 2);
    R.pipe(P([[330, 330], [352, 340], [355, 370]], false), 10, '#e0dcd6', 0.62, 0.04, 2);
    // clasped white hands / arms
    const hands = P([[225, 395], [270, 380], [320, 395], [350, 430], [385, 470], [390, 500], [360, 505], [320, 470], [270, 450], [230, 440]]);
    R.dome(hands, WH, 0.55, 0.18, 30, 2);
    for (let i = 0; i < 4; i++) R.groove(P([[235, 400 + i * 12], [280, 395 + i * 12], [320, 410 + i * 10]], false), 4, '#8a8886', 0.72, 0.03, 2, 0.6);
    const arm2 = P([[330, 440], [380, 420], [430, 430], [462, 470], [455, 520], [420, 560], [360, 570], [330, 540], [340, 500], [380, 500]]);
    R.dome(arm2, '#c8c6ca', 0.5, 0.18, 30, 2);
    for (let i = 0; i < 6; i++) R.groove(P([[340 + i * 3, 520 + i * 7], [390, 505 + i * 8], [440, 470 + i * 12]], false), 5, '#6a6874', 0.66, 0.04, 2, 0.6);
    R.dome(P([[360, 380], [390, 370], [405, 410], [395, 430], [370, 420]]), GOLD, 0.6, 0.1, 14, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, emis: 0.2, spec: 0.5, shin: 30, wrap: 0.3, coat: 0.12 }),                      // grooved trunks
        E.mat({ dif: 0.9, emis: 0.1, spec: 0.9, shin: 60, wrap: 0.2, coat: 0.25, rim: 0.3 }),             // porcelain
        E.mat({ dif: 0.35, metal: 0.8, spec: 1.1, shin: 50, tint: [1.15, 1.02, 0.78], coat: 0.12 }),       // gold chrome
        E.mat({ dif: 0.85, emis: 0.2, spec: 0.6, shin: 40, wrap: 0.3, coat: 0.1 }),                       // wet lilac
        E.mat({ dif: 0.6, emis: 0.1, spec: 0.9, shin: 60, coat: 0.2 }),                                   // black drip
        E.mat({ dif: 0.85, emis: 0.25, spec: 0.2, shin: 20, wrap: 0.3, grain: 0.3 }),                     // floor
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.8, shin: 50, wrap: 0.3, coat: 0.15 })                        // floor drops
      ],
      light: [-0.6, 0.55, 0.6], lc: [0.78, 0.78, 0.8], amb: [0.22, 0.22, 0.26],
      envTop: [0.95, 0.95, 1.0], envHor: [0.35, 0.34, 0.38], envBot: [0.03, 0.03, 0.04], envK: [0.5, 1.2, 0.5, 0],
      shadow: [-6, 6, 0.55, 8], r1: 2, r2: 8, k: [0, 0.6, 0.4, 70]
    });
    E.grain(0.04, 12);
  }
});
