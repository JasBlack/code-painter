'use strict';
// g062 — "Gold mask in zebra folds": a stitched gold leather face mask in profile against grey fur and a
// strip of blue sky, folded black/white zebra cloth behind, a coral leather creature with gold studs,
// a chain of gold pearls and a pink ribbon over a glass shard.
REC.register('g062', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x, x0, y0, x1, y1, st) => { const g = x.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, cx, cy, r0, r1, st, fx = cx, fy = cy) => { const g = x.createRadialGradient(fx, fy, r0, cx, cy, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── zebra cloth: four stripe fields ──
    const zeb = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = (fbm(p * 0.006) - .5) * 0.25;
      float ph; float duty = 0.5;
      float crease = 470. - 0.7 * p.y;
      if (p.y > 560. && p.x < 600.) { ph = (p.y + 0.17 * p.x) / 90. - 0.73; }                       // lower cloth
      else if (p.y > 560.) { ph = (p.y + 0.33 * p.x) / 62. - 0.71; duty = 0.52; }                    // lower right
      else if (length((p - vec2(290., 430.)) / vec2(160., 232.)) < 1.02 && p.y > 180.) { ph = length(p - vec2(320., -31.)) / 64. - 0.89; duty = 0.47; } // fold C mound
      else if (p.x > crease) { float P = 45. - 0.05 * (p.y - 30.); ph = (p.x - (513. - 0.16 * (p.y - 30.))) / P; }   // fold B
      else if (p.x > 300.) { ph = (p.x - 0.5 * (p.y - 30.) - 301.) / 46.; }                            // left of the crease
      else { ph = (p.x - (1.1 * p.y - 0.0025 * p.y * p.y) - 206.) / 50.; }                                    // fold A
      float f = fract(ph + w);
      float b = smoothstep(0., 0.02, f) * (1. - smoothstep(duty - 0.02, duty, f));
      return mix(vec3(.94, .94, .93), vec3(.04, .04, .05), b); }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0.02, 4);
    img(zeb);
    // folds: gentle height so the cloth reads as glossy folds
    R.dome(P([[300, -20], [560, -20], [520, 120], [450, 250], [400, 330], [330, 240], [300, 196]], true, true), null, 0.02, 0.1, 60, 4);
    R.dome(P([[110, -20], [300, -20], [304, 196], [200, 200], [120, 240]], true, true), null, 0.02, 0.08, 50, 4);
    R.dome(ellipseP(290, 430, 160, 232), null, 0.04, 0.18, 90, 4);
    R.dome(P([[60, 580], [620, 580], [620, 1040], [60, 1040]], true, false), null, 0.02, 0.04, 40, 4);
    // holes in the lower cloth
    for (const [x, y, r] of [[425, 712, 19], [352, 765, 16], [396, 806, 23], [455, 760, 8], [298, 826, 21]]) {
      R.groove(circleP(x + 3, y + 2, r), 4, '#f4f4f2', 0.04, 0.0, 4, 1);
      R.flat(circleP(x, y, r), y === 826 ? '#f6f6f4' : '#060608', 0.0, 4);
    }
    R.pipe(circleP(298, 826, 21), 3, '#1a1a1c', 0.04, 0.02, 4);
    keep();

    // ── sky: top-left blue, right strip with horizon ──
    R.flat(P([[-10, -10], [190, -10], [120, 60], [80, 140], [40, 200], [-10, 230]], true, true), lin(a, 0, 0, 0, 220, [[0, '#6890c4'], [0.4, '#68a0dc'], [1, '#80a8d8']]), 0, 0);
    const sky = P([[740, 80], [690, 150], [662, 250], [654, 400], [658, 600], [660, 780], [650, 836], [740, 836]], true, true);
    R.flat(sky, lin(a, 0, 100, 0, 840, [[0, '#1a5c98'], [0.12, '#0c86d6'], [0.25, '#0896e6'], [0.4, '#08a8ea'], [0.55, '#0cbcea'], [0.68, '#70c8dc'], [0.8, '#a8d4d8'], [0.88, '#a8b8cc'], [0.93, '#6a78a0'], [1, '#7a7e8e']]), 0, 0);
    clipA(sky, () => soft(x => {
      x.fillStyle = '#5a6488'; x.fill(P([[640, 830], [660, 790], [690, 782], [720, 770], [740, 776], [740, 840]], true, true));
      for (const [k, c] of [[0, 'rgba(255,120,120,0.35)'], [8, 'rgba(255,230,120,0.35)'], [16, 'rgba(120,230,160,0.3)'], [24, 'rgba(140,170,255,0.3)']]) { x.lineWidth = 8; x.strokeStyle = c; x.beginPath(); x.arc(980, 900, 300 + k, Math.PI * 1.05, Math.PI * 1.35); x.stroke(); }
    }, 3, 1));

    // ── grey fur behind the head ──
    const furPts = [[740, -10], [740, 80], [690, 150], [662, 250], [654, 400], [658, 600], [664, 800], [652, 840], [640, 1040], [600, 1040], [560, 700], [420, 520], [352, 470],
      [356, 420], [400, 378], [470, 320], [530, 252], [590, 172], [650, 100], [700, 24], [712, -10]];
    const fr = rng(7), furJ = [];
    for (let i = 0; i < furPts.length; i++) {
      const p0 = furPts[i], p1 = furPts[(i + 1) % furPts.length], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), k = Math.max(1, Math.round(L / 7));
      const edge = i >= 10;   // spiky only on the left (outer) edge
      for (let j = 0; j < k; j++) { const u = j / k, jt = edge ? (fr() - 0.3) * 18 * (j % 2 ? 1 : 0.3) : 0; furJ.push([p0[0] + (p1[0] - p0[0]) * u - jt * 0.7, p0[1] + (p1[1] - p0[1]) * u - jt * 0.5]); }
    }
    const fur = P(furJ, true, false);
    const furTex = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = vec2(p.x * 0.7 + p.y * 0.7, -p.x * 0.7 + p.y * 0.7);
      float s = vnoise(vec2(q.x * 0.9, q.y * 0.06)) * .6 + vnoise(vec2(q.x * 2.3, q.y * 0.15)) * .4;
      float m = fbm(p * 0.01);
      vec3 base = mix(vec3(.38, .43, .49), vec3(.60, .64, .69), m);
      return base * (0.7 + 0.6 * s); }`);
    R.flat(fur, '#7a848e', 0.06, 5);
    clipA(fur, () => img(furTex));
    keep();

    R.dome(P([[-20, 170], [16, 160], [44, 190], [58, 250], [56, 330], [30, 352], [-20, 352]], true, true), lin(a, 0, 160, 60, 350, [[0, '#b86a62'], [0.5, '#cc5e4a'], [1, '#d86a52']]), 0.06, 0.12, 20, 1);
    // ── gold rod + glass rod behind the pearls ──
    R.pipe(P([[20, 340], [60, 200], [104, 70], [126, 10]], false), 12, '#d8b040', 0.1, 0.06, 2);
    R.pipe(P([[0, 270], [30, 170], [70, 60]], false), 5, '#e8eef8', 0.1, 0.04, 6);
    R.bead(98, 72, 25, '#e8800c', 0.12, 0.18, 6);

    // ── coral leather creature ──
    const body = P([[-20, 352], [40, 362], [96, 344], [130, 334], [190, 334], [240, 348], [276, 376], [290, 416], [320, 456], [352, 488], [370, 520], [366, 560], [340, 588],
      [290, 600], [230, 596], [180, 604], [110, 618], [40, 640], [-20, 650]], true, true);
    R.dome(body, lin(a, 0, 340, 0, 640, [[0, '#f09484'], [0.3, '#ee8a78'], [0.5, '#d8604e'], [0.62, '#a8382e'], [0.8, '#7a2622'], [1, '#702424']]), 0.06, 0.26, 50, 1);
    const lobe = P([[96, 346], [140, 334], [200, 334], [250, 350], [280, 384], [286, 420], [262, 446], [210, 452], [150, 446], [110, 420], [92, 384]], true, true);
    R.dome(lobe, rad(a, 180, 370, 10, 140, [[0, '#f6b4a4'], [1, '#e89484']]), 0.3, 0.06, 30, 1);
    R.bead(215, 420, 31, '#f2a494', 0.36, 0.06, 1);
    // eye
    R.dome(ellipseP(30, 410, 30, 28, 0), '#e07868', 0.3, 0.08, 10, 1);
    R.dome(ellipseP(34, 412, 22, 20, 0), '#f2f2f0', 0.36, 0.06, 8, 6);
    R.flat(circleP(36, 412, 13), '#7a8a96', 0.42, 6);
    R.flat(circleP(37, 412, 6), '#101418', 0.42, 6);
    // gold studs
    R.dome(circleP(360, 540, 42), '#6c8088', 0.3, 0.06, 10, 2);
    R.bead(378, 535, 31, '#d0a050', 0.36, 0.16, 2);
    R.bead(107, 517, 35, '#d0a454', 0.34, 0.16, 2);
    // amber drop on a white saucer
    R.dome(ellipseP(186, 640, 30, 36, 0.1), '#f2eeec', 0.08, 0.1, 14, 1);
    R.dome(P([[200, 566], [212, 590], [204, 625], [182, 668], [176, 640], [182, 600]], true, true), '#ee900e', 0.2, 0.08, 6, 6);
    keep();

    // ── gold pearls ──
    for (const [x, y, r] of [[222, 6, 18], [205, 30, 21], [178, 58, 23], [152, 92, 26], [126, 134, 28], [108, 182, 29], [94, 232, 30], [86, 284, 30], [90, 336, 30]])
      R.bead(x, y, r, '#c89e50', 0.2, 0.22, 2);

    // ── pink ribbon and glass shard, bottom left ──
    R.flat(P([[-10, 640], [44, 630], [50, 760], [-10, 790]], true, false), lin(a, 0, 640, 0, 790, [[0, '#c8a8a8'], [0.5, '#d8bcb6'], [1, '#c8b4b8']]), 0.04, 1);
    const glass = P([[-10, 770], [40, 790], [84, 860], [122, 940], [150, 1040], [-10, 1040]], true, true);
    R.flat(glass, lin(a, 0, 780, 150, 1024, [[0, '#9cb8d4'], [0.4, '#c0c8dc'], [0.7, '#a8b4c8'], [1, '#d0a8a0']]), 0.06, 6);
    clipA(glass, () => soft(x => {
      x.strokeStyle = '#a07040'; x.lineWidth = 30; x.stroke(P([[-10, 800], [30, 830], [60, 870]], false)); x.strokeStyle = '#d08a20'; x.lineWidth = 34; x.stroke(P([[20, 880], [60, 930], [90, 980], [110, 1040]], false)); x.strokeStyle = '#f0b040'; x.lineWidth = 8; x.stroke(P([[-10, 840], [40, 880], [80, 930], [110, 1000]], false));
      x.lineWidth = 16; x.strokeStyle = '#d07818'; x.stroke(P([[20, 960], [60, 1000], [80, 1040]], false));
      x.strokeStyle = '#f8f8ff'; x.lineWidth = 6; x.stroke(P([[0, 800], [50, 850], [90, 920]], false));
      x.strokeStyle = '#4a70b0'; x.lineWidth = 8; x.stroke(P([[-10, 900], [30, 940], [50, 1000]], false));
    }, 3, 1));
    const ribbon = P([[40, 622], [70, 622], [76, 700], [102, 786], [160, 856], [244, 918], [312, 976], [334, 1040], [146, 1040], [124, 962], [84, 884], [54, 800], [42, 700]], true, true);
    R.dome(ribbon, lin(a, 40, 640, 330, 1024, [[0, '#f0b0a0'], [0.5, '#eeaa98'], [1, '#e6b0a4']]), 0.08, 0.14, 30, 1);
    keep();

    // ── gold mask ──
    const mask = P([[570, 380], [592, 410], [616, 470], [630, 520], [630, 552], [602, 590], [612, 622], [632, 652], [642, 680], [622, 706], [584, 712], [592, 732], [620, 768],
      [616, 810], [592, 830], [616, 850], [612, 890], [622, 932], [610, 990], [602, 1040], [470, 1040], [466, 990], [450, 930], [446, 870], [456, 810], [482, 780],
      [496, 748], [490, 710], [460, 672], [426, 630], [404, 582], [400, 530], [410, 488], [432, 452], [468, 420], [520, 398]], true, true);
    const mg = lin(a, 400, 380, 640, 900, [[0, '#c8a46a'], [0.25, '#ccaa72'], [0.6, '#b89256'], [1, '#9a7840']]);
    R.flat(mask, mg, 0.2, 3);
    clipA(mask, () => soft(x => {
      x.fillStyle = '#ecd8a8'; x.fill(ellipseP(500, 468, 60, 30, 0.1)); x.fill(ellipseP(622, 664, 12, 30, -0.5));
      x.fillStyle = '#7a5a2a'; x.fill(ellipseP(640, 800, 36, 230, 0)); x.fill(ellipseP(520, 1010, 80, 40, 0)); x.fill(ellipseP(566, 734, 34, 22, 0)); x.fill(ellipseP(600, 566, 20, 26, 0)); x.fill(ellipseP(470, 860, 20, 60, 0));
    }, 24, 0.55));
    // smooth sculpted height field for the face
    { const hf = E.newCanvas(), hx = hf.getContext('2d'); hx.setTransform(S, 0, 0, S, 0, 0);
      const H = v => hc(v, 3);
      hx.fillStyle = H(0.14); hx.fillRect(0, 0, 726, 1024);
      const bh = (path, v, b) => { hx.save(); hx.filter = `blur(${b * S}px)`; hx.fillStyle = H(v); hx.fill(path); hx.restore(); };
      const sh = (path, v, wd, b) => { hx.save(); hx.filter = `blur(${b * S}px)`; hx.strokeStyle = H(v); hx.lineWidth = wd; hx.lineCap = 'round'; hx.stroke(path); hx.restore(); };
      bh(mask, 0.4, 18);
      bh(ellipseP(498, 470, 84, 52, 0.1), 0.5, 22);
      bh(ellipseP(520, 690, 76, 118, 0.12), 0.56, 30);
      bh(ellipseP(522, 548, 48, 20, 0.15), 0.42, 9);
      bh(P([[594, 592], [618, 624], [638, 656], [644, 684], [622, 706], [590, 708], [572, 684], [578, 636]], true, true), 0.68, 9);
      bh(ellipseP(588, 790, 32, 24, 0.2), 0.6, 9);
      bh(ellipseP(580, 864, 32, 20, 0), 0.6, 8);
      bh(ellipseP(578, 912, 36, 30, 0), 0.56, 14);
      bh(ellipseP(526, 494, 70, 8, 0.1), 0.55, 4);
      sh(P([[504, 832], [540, 822], [574, 826], [598, 838]], false), 0.46, 6, 2);
      sh(P([[574, 708], [590, 714], [610, 710]], false), 0.5, 7, 2);
      R.h.save(); R.h.clip(mask); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(hf, 0, 0); R.h.restore(); }
    // eye, brow, nostril, mouth (paint)
    clipA(mask, () => soft(x => { x.fillStyle = '#8a6a38'; x.fill(ellipseP(520, 552, 60, 26, 0.15)); x.fill(ellipseP(606, 604, 16, 22, 0)); }, 10, 0.55));
    a.fillStyle = '#f4f0e8'; a.fill(P([[452, 520], [490, 524], [530, 532], [556, 542], [544, 554], [510, 558], [476, 546]], true, true));
    a.fillStyle = '#2a9cb0'; a.fill(circleP(512, 542, 15));
    a.fillStyle = '#0a1418'; a.fill(circleP(512, 542, 7));
    a.lineCap = a.lineJoin = 'round';
    a.strokeStyle = '#0a0806'; a.lineWidth = 5; a.stroke(P([[446, 516], [480, 520], [520, 526], [552, 540], [562, 556], [552, 578]], false));
    a.strokeStyle = '#2a1c10'; a.lineWidth = 2.5; a.stroke(P([[476, 548], [510, 560], [544, 556]], false));
    a.strokeStyle = '#6a4c20'; a.lineWidth = 2; a.stroke(P([[460, 498], [520, 494], [584, 506]], false));
    a.fillStyle = '#1a1208'; a.fill(ellipseP(604, 604, 7, 9, 0));
    a.strokeStyle = '#2a1a08'; a.lineWidth = 5; a.stroke(P([[574, 708], [590, 714], [610, 710]], false));
    a.strokeStyle = '#1a1006'; a.lineWidth = 4; a.stroke(P([[504, 832], [540, 822], [574, 826], [598, 838]], false));
    // crown ornament
    const crown = P([[572, 376], [586, 410], [600, 440], [598, 470], [584, 500], [570, 476], [560, 440], [562, 408]], true, true);
    R.dome(crown, '#d8b46c', 0.5, 0.06, 6, 2);
    R.pipe(P([[578, 430], [592, 440], [586, 456], [574, 452], [578, 438]], true, true), 3, '#5a4018', 0.58, 0.02, 2);
    R.pipe(P([[574, 462], [586, 470], [580, 484]], false), 3, '#5a4018', 0.58, 0.02, 2);
    // stitched seam along the edge
    { const seam = [[566, 388], [520, 404], [472, 426], [440, 456], [418, 490], [410, 530], [414, 580], [436, 626], [468, 664], [498, 708], [504, 750], [490, 786], [466, 816], [456, 870], [460, 930], [476, 990], [482, 1040]];
      const sp = P(seam, false, true); a.save(); a.setLineDash([7, 6]); a.lineWidth = 2.6; a.strokeStyle = '#2a1a08'; a.stroke(sp); a.restore(); }
    // stud overlapping the mask edge
    R.dome(circleP(360, 540, 42), '#6c8088', 0.3, 0.06, 10, 2);
    R.bead(378, 535, 31, '#d0a050', 0.36, 0.16, 2);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 18, wrap: 0.35, ao: 0.5, grain: 0.22, rim: 0.2 }),                          // 1 pink leather
        E.mat({ dif: 0.7, metal: 0.55, spec: 1.1, shin: 40, ao: 0.4, rim: 0.3, tint: [1.15, 1.0, 0.7] }),            // 2 gold studs / pearls
        E.mat({ dif: 0.92, metal: 0.15, spec: 0.4, shin: 22, wrap: 0.3, ao: 0.5, grain: 0, rim: 0.15, tint: [1.1, 1.0, 0.75] }),  // 3 gold mask
        E.mat({ dif: 0.75, spec: 0.55, shin: 40, wrap: 0.6, ao: 0.3, emis: 0.22 }),                                    // 4 zebra cloth
        E.mat({ dif: 0.9, spec: 0.08, shin: 10, wrap: 0.6, grain: 0.5, emis: 0.1 }),                                  // 5 fur
        E.mat({ dif: 0.6, spec: 1.2, shin: 80, wrap: 0.4, emis: 0.35, coat: 0.2 })                                    // 6 glass / eyeball
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.85, 0.82, 0.78], amb: [0.4, 0.4, 0.42],
      envTop: [1.05, 1.02, 1.0], envHor: [0.6, 0.58, 0.6], envBot: [0.2, 0.16, 0.16], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.25, 0.3, 0.4], rimD: [0.3, 0.6, 0.3], r1: 2.6, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-6, 7, 0.55, 6]
    });
    o.fillStyle = '#050505'; o.fillRect(0, 0, 726, 6);
    E.bloom(0.06, 10);
    E.grain(0.03, 62);
  }
});
