'use strict';
// g121 — "Coral clay planet": a huge salmon clay sphere studded with lemon discs, slate triangles and a
// zebra spiral, a speckled lime teardrop, a zigzag zebra ribbon, a stone bar with teal claws, a bullseye and a polka ball.
REC.register('g121', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H], al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const poly = (pts) => P(pts, true, false);
    const all = rrect(-10, -10, W + 20, H + 20, 0);

    // ── backdrop: soft grey studio wall, teal mottled floor bottom-left ──
    R.flat(all, lin(0, 0, 0, 1024, [[0, '#c6c6c9'], [0.35, '#d4d5d9'], [0.6, '#a8a2a6'], [1, '#6a7a80']]), 0, 0);
    const floor = poly([[-10, 760], [120, 760], [140, 1034], [-10, 1034]]);
    R.flat(floor, '#5f8e96', 0, 0);
    clipA(floor, () => soft(x => { const r = rng(4); for (let i = 0; i < 70; i++) fe(x, r() * 140, 760 + r() * 270, 4 + r() * 10, 3 + r() * 8, r() * 3, r() < 0.5 ? '#2e4a52' : '#9fc0b8'); }, 3, 0.8));

    // ── the coral sphere ──
    const SC = [560, 540], SR = 505;
    const sphere = circleP(SC[0], SC[1], SR);
    R.dome(sphere, radg(300, 330, 40, 640, [[0, '#fb9a8c'], [0.45, '#f68a7c'], [0.75, '#e47264'], [1, '#b2524a']]), 0.05, 0.3, 150, 1);

    // ── wheel + dark machinery (left) ──
    R.dome(poly([[48, 300], [112, 290], [128, 330], [118, 440], [60, 450], [40, 380]]), '#6a787c', 0.18, 0.08, 10, 2);
    R.dome(ellipseP(90, 274, 42, 70, 0.1), '#1c1c20', 0.2, 0.08, 10, 4);
    R.dome(ellipseP(90, 274, 30, 54, 0.1), '#3a3a42', 0.22, 0.03, 5, 2);
    R.dome(ellipseP(92, 276, 14, 26, 0.1), '#5a5e66', 0.25, 0.04, 5, 2);
    R.bead(68, 270, 4, '#d03030', 0.3, 0.03, 4);
    // ── grey-green leaves, dial (top-left) ──
    const leaf = (pts, seed) => { const p = P(pts); R.dome(p, '#9fb2b4', 0.3, 0.14, 24, 2); speck(p, 500, seed, '#56645f', 0.9); return p; };
    R.dome(P([[250, -10], [330, -10], [330, 30], [300, 50], [262, 46], [244, 20]]), '#4c5656', 0.28, 0.1, 14, 2);
    leaf([[104, 128], [110, 100], [134, 74], [172, 50], [210, 34], [238, 36], [252, 60], [246, 96], [222, 122], [180, 140], [130, 150]], 11);
    leaf([[118, 280], [114, 240], [124, 200], [148, 170], [174, 166], [182, 200], [172, 246], [150, 276], [130, 290]], 13);
    leaf([[222, 50], [240, 26], [276, 22], [302, 46], [320, 92], [328, 136], [314, 164], [288, 166], [264, 140], [242, 100]], 12);
    for (const [pts, w] of [[[[128, 128], [180, 105], [235, 80]], 3], [[[262, 55], [282, 95], [298, 140]], 3], [[[148, 190], [156, 225], [146, 260]], 3]])
      R.groove(P(pts, false), w, '#5c6a66', 0.44, 0.06, 2);
    { const r = rng(14); for (let i = 0; i < 8; i++) { const t = i / 8; R.groove(P([[255 + t * 50 + 6, 60 + t * 85], [255 + t * 50 + 18, 56 + t * 85]], false), 2.5, '#2a3230', 0.44, 0.04, 2); } }
    R.flat(poly([[245, 198], [250, 168], [330, 120], [392, 92], [398, 110], [300, 172], [262, 206]]), '#d03440', 0.26, 1);
    R.dome(ellipseP(212, 181, 50, 54, 0), '#b4bec8', 0.36, 0.1, 14, 2);
    R.dome(ellipseP(205, 136, 15, 14, 0), '#40404a', 0.46, 0.05, 4, 2);
    R.bead(205, 136, 7, '#c02838', 0.5, 0.05, 4);
    R.bead(206, 174, 14, '#d8e0e6', 0.46, 0.08, 2);
    for (const [x, y] of [[188, 200], [230, 172], [220, 212]]) R.dome(circleP(x, y, 7), '#3a3e46', 0.46, 0.02, 2, 2);
    R.dome(rrect(326, 96, 42, 52, 8), '#e2e8ec', 0.36, 0.08, 6, 2);

    // ── track (top) with white rivets, blue/yellow cylinder ──
    const track = poly([[300, 62], [360, 42], [430, 30], [500, 26], [500, 60], [480, 96], [420, 104], [380, 112], [330, 116], [300, 92]]);
    R.dome(track, '#7e8e8e', 0.3, 0.06, 8, 2);
    { const r = rng(22); for (let i = 0; i < 40; i++) { const x = 300 + i * 4.5, y = 110 - i * 0.6 + r() * 6; R.dome(poly([[x, y - 3], [x + 4, y + 3], [x - 1, y + 4]]), '#1c2024', 0.36, 0.02, 1, 2); } }
    R.flat(poly([[320, -10], [520, -10], [520, 28], [430, 30], [330, 46]]), '#40484c', 0.28, 2);
    R.dome(rrect(352, -10, 68, 34, 10), '#1c64d8', 0.32, 0.08, 6, 4);
    R.dome(rrect(378, -10, 28, 30, 6), '#f0c020', 0.36, 0.06, 5, 4);
    { const r = rng(21); for (let i = 0; i < 34; i++) R.bead(310 + r() * 185, 42 + r() * 60, 1.5 + r() * 2.5, '#f4f4f0', 0.38, 0.03, 4); }
    R.flat(poly([[520, -10], [736, -10], [736, 26], [640, 20], [560, 16]]), '#5a6264', 0.3, 2);

    // ── zigzag zebra ribbon ──
    const zz = [[78, 440], [90, 396], [110, 358], [130, 328], [150, 314], [200, 288], [230, 275], [262, 256], [290, 222], [320, 194], [350, 173], [380, 152], [410, 127], [460, 104]];
    const off = (pts, d) => pts.map((p, i) => {
      const q = pts[Math.max(0, i - 1)], s = pts[Math.min(pts.length - 1, i + 1)];
      let dx = s[0] - q[0], dy = s[1] - q[1]; const L = Math.hypot(dx, dy) || 1; return [p[0] - dy / L * d, p[1] + dx / L * d];
    });
    const zl = d => P(off(zz, d), false, false);
    R.pipe(zl(24), 52, '#3a3e42', 0.22, 0.06, 2);
    R.flat(P([...off(zz, -22), ...off(zz, 27).reverse()], true, false), '#141416', 0.3, 4);
    R.pipe(zl(-14), 11, '#f4f6f4', 0.3, 0.05, 4);
    R.pipe(zl(14), 17, '#f4f6f4', 0.3, 0.05, 4);

    // ── lemon discs, olive dots, slate triangles, grey buttons ──
    for (const [x, y, r] of [[360, 325, 48], [240, 380, 42], [150, 455, 36]]) {
      R.dome(circleP(x, y, r + 8), '#f08c80', 0.32, 0.03, 4, 1);
      R.dome(circleP(x, y, r), '#fcf6a8', 0.34, 0.06, 7, 1);
    }
    for (const [x, y, r] of [[330, 412, 23], [506, 420, 22], [692, 320, 25], [100, 622, 12]]) R.dome(circleP(x, y, r), '#b8b46a', 0.33, 0.04, 6, 1);
    const tri = (pts, c = '#5c7084') => { R.dome(poly(pts), c, 0.33, 0.1, 9, 2); };
    tri([[405, 386], [445, 460], [362, 450]], '#6c849a');
    tri([[612, 310], [662, 368], [575, 370]], '#3c4a58');
    tri([[140, 535], [170, 580], [122, 612]], '#4c6278');
    tri([[430, 305], [530, 340], [464, 388]], '#5c6c7c');
    R.bead(406, 425, 10, '#a8bccc', 0.42, 0.04, 2);
    R.bead(620, 345, 8, '#a0a8b0', 0.42, 0.04, 2);
    for (const [x, y, r, c] of [[330, 483, 20, '#8496a8'], [340, 545, 25, '#7a8490'], [352, 248, 12, '#52626e'], [175, 375, 13, '#52626e'], [700, 380, 13, '#4a5a68'], [102, 690, 20, '#6a7888']])
      R.dome(circleP(x, y, r), c, 0.33, 0.06, 6, 2);
    R.dome(circleP(95, 550, 34), '#c4ccd6', 0.33, 0.06, 7, 2);
    R.dome(circleP(95, 550, 26), '#d8dee4', 0.36, 0.02, 4, 2);

    // ── zebra spiral disc ──
    const sp = circleP(245, 495, 72);
    R.dome(sp, '#f2f2f2', 0.33, 0.06, 8, 4);
    const spiral = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(242., 498.); float r = length(d), th = atan(d.y, d.x);
      float s = fract(r / 13. - th / 6.2832);
      float b = smoothstep(0.42, 0.48, s) * smoothstep(0.98, 0.92, s);
      return mix(vec3(.96), vec3(.06), max(b, smoothstep(66., 70., r))); }`);
    clipA(sp, () => img(spiral));

    // ── lime teardrop with white dots ──
    const tear = P([[540, 4], [585, 30], [622, 90], [650, 150], [662, 220], [648, 290], [606, 330], [532, 345], [452, 330], [408, 282], [400, 222], [425, 172], [478, 120], [518, 60]]);
    R.dome(tear, radg(500, 180, 20, 230, [[0, '#d8e8a0'], [0.7, '#cbdc8e'], [1, '#a8b878']]), 0.33, 0.24, 60, 5);
    speck(tear, 500, 31, '#5a6a4a', 0.9, [400, 0, 662, 345], 0.4);
    { const r = rng(32); for (let i = 0; i < 90; i++) { const x = 400 + r() * 262, y = 5 + r() * 340; if (a.isPointInPath(tear, x * S, y * S)) R.bead(x, y, 1.5 + r() * r() * 7, '#f8faf4', 0.55, 0.04, 5); } }
    tri([[430, 305], [530, 340], [464, 388]], '#5c6c7c');

    // ── clock & dark bar (right) ──
    R.dome(circleP(708, 108, 52), '#9aa0a8', 0.3, 0.06, 6, 3);
    R.dome(circleP(708, 108, 43), '#e8dcc4', 0.32, 0.04, 6, 1);
    R.groove(P([[712, 108], [690, 100]], false), 3, '#303030', 0.36, 0.02, 1);
    R.dome(poly([[582, 190], [726, 186], [726, 254], [582, 256]]), '#4a4e56', 0.36, 0.08, 6, 2);
    R.pipe(circleP(712, 228, 24), 8, '#9aa0a8', 0.45, 0.06, 3);

    // ── cream blob with black studs and lime icing ──
    const cream = P([[386, 540], [400, 505], [440, 478], [500, 458], [560, 432], [630, 410], [700, 404], [736, 410], [736, 540], [680, 568], [600, 582], [500, 586], [420, 576]]);
    R.dome(cream, '#f2ece0', 0.33, 0.14, 30, 1);
    speck(cream, 400, 41, '#2a2a2a', 0.9, [380, 400, 726, 590], 0.4);
    const icing = P([[530, 440], [560, 405], [610, 390], [670, 392], [726, 405], [726, 440], [700, 470], [670, 462], [640, 440], [600, 446], [565, 452]]);
    R.dome(icing, '#c4d88c', 0.42, 0.06, 14, 5);
    { const r = rng(42); for (let i = 0; i < 14; i++) R.bead(540 + r() * 180, 398 + r() * 50, 1.5 + r() * 3, '#f8faf4', 0.5, 0.03, 5); }
    for (const [x, y, rr] of [[516, 482, 15], [580, 465, 10], [592, 528, 15], [468, 548, 13], [530, 562, 12], [636, 492, 8], [418, 540, 10], [452, 498, 7], [490, 520, 8], [688, 462, 10], [656, 548, 9], [560, 505, 6], [440, 512, 5], [620, 455, 6]]) {
      R.dome(circleP(x, y, rr), '#1a1c20', 0.46, 0.06, rr * 0.6, 4); R.dome(circleP(x, y, rr * 0.45), '#0a0a0c', 0.44, 0.02, 2, 4);
    }
    { const r = rng(43); for (let i = 0; i < 40; i++) { const x = 400 + r() * 300, y = 470 + r() * 110; if (a.isPointInPath(cream, x * S, y * S)) R.bead(x, y, 2 + r() * 3, '#16181c', 0.44, 0.03, 4); } }
    // keyboard
    const kb = poly([[590, 545], [726, 498], [726, 600], [612, 612]]);
    R.dome(kb, '#22262c', 0.42, 0.06, 6, 2);
    { for (let i = 0; i < 4; i++) for (let j = 0; j < 6; j++) R.dome(rrect(612 + j * 19, 540 + i * 16 - j * 6, 13, 10, 2), (i + j) % 3 ? '#3a4a5a' : '#60a8e0', 0.48, 0.03, 2, 4); }

    // ── stone bar + dark bar + teal claws ──
    R.flat(P([[420, 636], [520, 646], [512, 676], [488, 702], [446, 706], [428, 680]]), '#0c0c0e', 0.3, 0);
    const claw = (cl, w0) => R.dome(P(lock(cl, w0, 8, 0.4)), lin(160, 640, 300, 820, [[0, '#5cc4c4'], [0.6, '#4ab4b6'], [1, '#86dce0']]), 0.4, 0.2, 18, 6);
    claw([[240, 628], [242, 665], [237, 700], [222, 728], [202, 750], [186, 766], [176, 780]], 58);
    claw([[304, 628], [302, 665], [297, 700], [290, 735], [282, 765], [278, 790], [279, 804]], 68);
    claw([[389, 628], [388, 665], [384, 700], [379, 740], [375, 772], [375, 800], [378, 818]], 66);
    R.dome(poly([[600, 600], [726, 618], [726, 700], [610, 662]]), '#4a4c52', 0.36, 0.08, 6, 2);
    const blocks = [[[190, 572], [262, 566], [265, 636], [194, 640]], [[262, 568], [345, 566], [350, 640], [265, 644]], [[345, 566], [430, 562], [435, 636], [350, 640]],
      [[430, 568], [520, 566], [525, 646], [435, 640]], [[520, 578], [612, 590], [610, 656], [522, 648]]];
    for (const [i, b] of blocks.entries()) { const p = poly(b); R.dome(p, '#bcc6ca', 0.44, 0.07, 6, 3); speck(p, 260, 50 + i, '#6c7478', 1.0, [180, 555, 620, 660]); }
    R.dome(rrect(152, 612, 46, 42, 6), '#9c6c48', 0.45, 0.06, 6, 3);

    // ── rope ──
    const rope = (pts, wd, seed) => {
      const p = P(pts, false); R.pipe(p, wd, '#a8542e', 0.38, 0.08, 7);
      // twisted strands: short diagonal grooves along the rope
      const r = rng(seed); a.save(); a.strokeStyle = '#5a2412'; a.lineWidth = 1.6; a.globalAlpha = 0.8;
      for (let i = 0; i < pts.length - 1; i++) {
        const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], L = Math.hypot(x1 - x0, y1 - y0), n = Math.ceil(L / 6), dx = (x1 - x0) / L, dy = (y1 - y0) / L;
        for (let j = 0; j < n; j++) { const x = x0 + dx * j * 6, y = y0 + dy * j * 6; a.beginPath(); a.moveTo(x - dy * wd * 0.45 - dx * 3, y + dx * wd * 0.45 - dy * 3); a.lineTo(x + dy * wd * 0.45 + dx * 3, y - dx * wd * 0.45 + dy * 3); a.stroke(); }
      }
      a.restore();
    };
    rope([[165, 652], [140, 700], [124, 750], [112, 810], [100, 870], [80, 925], [40, 985], [-10, 1020]], 14, 1);
    rope([[150, 664], [110, 704], [60, 738], [-10, 770]], 12, 2);

    // ── left: horn + chrome spiral mic ──
    R.dome(P([[-10, 742], [30, 718], [60, 700], [84, 688], [76, 730], [70, 780], [62, 830], [46, 872], [16, 896], [-10, 900]]), lin(0, 700, 80, 900, [[0, '#f8e8a6'], [1, '#e8c464']]), 0.3, 0.22, 30, 6);
    R.dome(rrect(30, 410, 75, 110, 18), '#8a8c90', 0.3, 0.1, 14, 3);
    R.pipe(P([[60, 520], [50, 600], [36, 640]], false), 12, '#a8acb0', 0.34, 0.08, 3);
    const mic = circleP(28, 465, 56);
    R.dome(mic, '#8a7c70', 0.36, 0.12, 14, 3);
    const msp = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(28., 465.); float r = length(d), th = atan(d.y, d.x);
      float s = fract(r / 9. - th / 6.2832);
      return mix(vec3(.82,.74,.66), vec3(.25,.2,.18), smoothstep(0.4, 0.5, s) * smoothstep(1., 0.9, s)); }`);
    clipA(circleP(28, 465, 46), () => img(msp));

    // ── bullseye ──
    const bull = ellipseP(558, 826, 152, 172, -0.12);
    R.dome(ellipseP(560, 828, 160, 180, -0.12), '#3a3c40', 0.34, 0.06, 8, 2);
    R.dome(bull, '#f4f6f6', 0.38, 0.1, 16, 4);
    const rings = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(558., 826.); float cs = cos(0.12), sn = sin(0.12);
      q = vec2(cs * q.x - sn * q.y, sn * q.x + cs * q.y);
      float r0 = length(q / vec2(152., 172.));
      vec2 c0 = vec2(573., 812.);
      float r = length(p - c0);
      r = length(p - c0 - vec2(0., 0.115 * r)); r = length(p - c0 - vec2(0., 0.115 * r));
      float th = atan(p.y - c0.y, p.x - c0.x);
      float rw = r + 3. * sin(th * 4. + r * 0.06) * smoothstep(30., 90., r);
      float k = fract((rw - 16.) / 31.);
      float w = 1. - smoothstep(0.22, 0.29, k) * (1. - smoothstep(0.71, 0.78, k));
      w = max(w, 1. - smoothstep(24., 27., r));
      w *= 1. - smoothstep(0.9, 0.93, r0);
      float gring = smoothstep(16., 18.5, r) * (1. - smoothstep(20.5, 23., r));
      return mix(mix(vec3(.07,.07,.08), vec3(.96,.97,.97), w), vec3(.5,.52,.55), gring * 0.8); }`);
    clipA(bull, () => img(rings));
    // dark rails (bottom right)
    R.dome(poly([[410, 975], [726, 890], [726, 950], [440, 1034], [410, 1034]]), '#5c6066', 0.3, 0.06, 8, 2);
    R.dome(poly([[690, 700], [726, 690], [726, 890], [700, 900]]), '#3a3c40', 0.32, 0.06, 6, 2);

    // ── polka ball ──
    const pb = circleP(225, 925, 148);
    R.dome(pb, radg(190, 870, 20, 170, [[0, '#ab9c8e'], [1, '#7c6c62']]), 0.36, 0.3, 100, 1);
    speck(pb, 900, 61, '#4a3e36', 0.9, [77, 777, 373, 1073], 0.4);
    { const r = rng(62); const pts = [];
      for (let i = 0; i < 1500 && pts.length < 110; i++) {
        const t = r() * 6.283, u = Math.sqrt(r()) * 0.98, rad = i < 300 ? 14 + r() * 12 : 5 + r() * 12;
        const x = 225 + Math.cos(t) * u * 148, y = 925 + Math.sin(t) * u * 148;
        const sh = Math.sqrt(1 - u * u);
        if (pts.some(([px, py, pr]) => Math.hypot(px - x, py - y) < (pr + rad * sh) * 1.25 + 3)) continue;
        pts.push([x, y, rad * sh]);
      }
      clipA(pb, () => { for (const [x, y, rr] of pts) {
        const ang = Math.atan2(y - 925, x - 225), u = Math.hypot(x - 225, y - 925) / 148;
        const sh = Math.max(0.35, Math.sqrt(1 - u * u));
        a.fillStyle = '#4a3c30'; a.fill(ellipseP(x, y, rr * 1.18 + 1.5, rr * 1.18 / sh + 1.5, ang));
        a.fillStyle = '#e2eaa2'; a.fill(ellipseP(x, y, rr, rr / sh, ang));
      } });
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 20, wrap: 0.5, ao: 0.5, grain: 0.1 }),                         // 1 matte clay
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.6, grain: 0.15 }),                          // 2 grey plastic
        E.mat({ dif: 1, spec: 0.25, shin: 16, wrap: 0.4, ao: 0.6, grain: 0.3 }),                          // 3 stone / metal
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.35, coat: 0.1, ao: 0.4 }),                           // 4 gloss black/white
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.5, ao: 0.4, grain: 0.15 }),                          // 5 lime clay
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, coat: 0.2, ao: 0.3, rim: 0.3 }),                 // 6 glossy teal / horn
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.4, ao: 0.7, grain: 0.4 })                            // 7 rope
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.75, 0.74, 0.72], amb: [0.45, 0.45, 0.46],
      envTop: [1.1, 1.1, 1.1], envHor: [0.5, 0.52, 0.55], envBot: [0.1, 0.1, 0.12], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.25, 0.3, 0.4], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-9, 11, 0.75, 5]
    });
    // depth of field: the top-left and far-left are out of focus
    { const bl = E.blur(E.snapshot(), 3.2), x = bl.getContext('2d');
      x.globalCompositeOperation = 'destination-in'; x.setTransform(S, 0, 0, S, 0, 0);
      const g = x.createLinearGradient(40, 60, 300, 330); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(0.55, 'rgba(0,0,0,0.85)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 0, W, H);
      E.draw(bl); }
    { const bl = E.blur(E.snapshot(), 2.5), x = bl.getContext('2d');
      x.globalCompositeOperation = 'destination-in'; x.setTransform(S, 0, 0, S, 0, 0);
      const g = x.createLinearGradient(0, 0, 120, 0); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 380, W, H);
      E.draw(bl); }
    E.grain(0.04, 121);
  }
});
