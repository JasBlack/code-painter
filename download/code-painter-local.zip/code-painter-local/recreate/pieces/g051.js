'use strict';
// g051 — "Zebra-bearded dreamer": a glossy slate-teal relief plaque on red — a sleeping cream face with a
// zebra-striped beard, a blue-magenta splat on the cheek, silver hood with holes, teal pebbles and a teal fern.
REC.register('g051', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, op = 'source-over', al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalCompositeOperation = op; a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const himg = (path, cv) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const RED = '#f8061f', SLATE = '#3a565e', SILV = '#98a2ae', TEAL = '#0cdca0', CREAM = '#fbf8ee', BLK = '#121416';

    // ── red ground, cork disc, left-edge blue tubes ──
    R.flat(rrect(-10, -10, 746, 1044, 0), RED, 0, 5);
    R.dome(circleP(78, 205, 64), '#c98a64', 0.02, 0.05, 10, 7);
    R.pipe(P([[4, 440], [6, 560]], false), 34, '#0a7ef0', 0.02, 0.1, 1);
    R.pipe(P([[2, 570], [4, 680]], false), 30, '#eef0f4', 0.02, 0.1, 1);
    R.pipe(P([[-30, 860], [10, 960], [24, 1040]], false), 60, '#f2f4f8', 0.02, 0.14, 1);
    R.pipe(P([[0, 790], [40, 900], [76, 1040]], false), 52, '#0a84f4', 0.02, 0.14, 1);
    R.bead(4, 410, 24, '#3c4448', 0.02, 0.1, 4);

    // ── the plaque: slate body ──
    const plaque = P([[100, 1014], [64, 960], [36, 880], [22, 780], [20, 600], [22, 440], [36, 330], [62, 262], [96, 214], [130, 186], [180, 162], [232, 138], [252, 80], [262, -20],
      [746, -20], [746, 930], [712, 980], [670, 1012], [500, 1018], [300, 1016], [140, 1018]]);
    R.dome(plaque, SLATE, 0.04, 0.12, 22, 2);
    keep();
    // silver hood (outside the red line)
    const silver = P([[30, 350], [42, 320], [64, 268], [98, 216], [130, 188], [180, 164], [232, 140], [254, 80], [264, -20], [746, -20], [746, 378], [680, 372], [600, 356],
      [548, 330], [505, 288], [460, 236], [400, 206], [320, 196], [236, 200], [168, 226], [124, 266], [100, 320], [80, 350], [50, 370]]);
    const sg = a.createLinearGradient(0, 200, 700, 300); sg.addColorStop(0, '#ccd4de'); sg.addColorStop(0.35, '#b0b9c4'); sg.addColorStop(1, '#a0a9b4');
    R.dome(silver, sg, 0.1, 0.08, 14, 3);
    // slate inset around the orange splat and the blue eye
    const inset = P([[262, 40], [300, 0], [470, -10], [482, 52], [430, 66], [396, 84], [382, 126], [388, 180], [404, 212], [340, 214], [290, 208], [262, 150]]);
    R.dome(inset, '#4e626c', 0.14, 0.02, 8, 2);
    // violet arm (top right) with its black hollow
    const violet = P([[430, -20], [746, -20], [746, 384], [708, 374], [696, 320], [702, 250], [712, 190], [690, 150], [640, 140], [596, 112], [556, 94], [514, 82], [470, 60]]);
    R.dome(violet, '#5a48f4', 0.16, 0.08, 14, 1);
    R.flat(P([[446, -10], [624, -10], [604, 26], [566, 54], [516, 60], [474, 42]]), '#030304', 0.1, 0);
    R.flat(P([[630, -10], [700, -10], [692, 16], [650, 22]]), '#030304', 0.1, 0);
    R.bead(708, 32, 20, '#f4f0e0', 0.2, 0.12, 1);
    R.pipe(P([[592, 122], [650, 116], [740, 118]], false), 15, '#f88a1c', 0.22, 0.06, 1);
    R.dome(P([[700, 196], [726, 186], [726, 230], [706, 222]]), '#f87c1c', 0.22, 0.06, 4, 1);
    for (const [x0, y0, x1, y1] of [[640, 74], [660, 86], [682, 98], [700, 108]].map(([x, y]) => [x, y, x + 18, y + 6])) R.pipe(P([[x0, y0], [x1, y1]], false), 8, '#38a8f0', 0.22, 0.05, 1);
    R.bead(700, 300, 14, '#5a6aa0', 0.2, 0.08, 3);
    keep();

    // holes and beads in the silver
    const hr = rng(51);
    const holes = [];
    for (let i = 0; i < 48; i++) {
      const x = 480 + hr() * 220, y = 120 + hr() * 240;
      if (y > 0.36 * (x - 480) + 270 + 40 || (x > 690 && y < 380)) continue;
      holes.push([x, y, 1.8 + hr() * 3]);
    }
    for (const [x, y, r] of holes) R.dome(circleP(x, y, r), '#121418', 0.04, 0.02, r, 4);
    R.dome(circleP(548, 268, 24), '#5a6672', 0.1, 0.01, 6, 3);
    R.dome(circleP(548, 268, 17), '#3c4650', 0.06, 0.02, 6, 3);
    R.bead(548, 158, 8, '#e8e4a0', 0.2, 0.06, 1); R.bead(668, 228, 10, '#eeeab8', 0.2, 0.06, 1); R.bead(663, 298, 10, '#f0f0ea', 0.2, 0.06, 1);
    R.bead(548, 182, 4, '#f05020', 0.2, 0.03, 1);
    R.bead(212, 178, 13, '#6e7a86', 0.2, 0.08, 3); R.bead(140, 210, 10, '#6e7a86', 0.2, 0.08, 3);
    // blue eye in its bezel
    R.dome(ellipseP(432, 146, 52, 66, 0.15), '#6a7480', 0.14, 0.06, 8, 3);
    R.dome(ellipseP(432, 146, 42, 56, 0.15), '#3446e0', 0.2, 0.08, 18, 1);
    R.bead(446, 148, 10, BLK, 0.28, 0.06, 4);
    // grey squiggles in the inset
    for (const pts of [[[352, 108], [372, 92], [392, 104], [380, 122], [360, 128]], [[356, 150], [380, 160], [392, 186]], [[350, 182], [372, 200], [400, 204]]])
      R.pipe(P(pts, false), 9, '#7e8a96', 0.16, 0.06, 3);
    R.bead(355, 52, 16, TEAL, 0.16, 0.1, 1);
    R.bead(398, 18, 9, '#eae4d4', 0.16, 0.08, 1);
    R.pipe(P([[398, 28], [406, 56], [416, 70]], false), 5, '#c8c0a0', 0.16, 0.04, 3);
    // orange splat
    const orng = P([[262, 26], [290, 14], [302, 30], [318, 18], [336, 38], [324, 62], [332, 86], [314, 100], [342, 120], [338, 142], [318, 150], [332, 176], [314, 194],
      [294, 184], [284, 160], [300, 140], [284, 122], [290, 100], [274, 84], [286, 62], [268, 50]]);
    R.dome(orng, '#f67a1a', 0.16, 0.08, 10, 1);
    for (const [x, y] of [[300, 72], [312, 82], [296, 90], [316, 132]]) R.dome(circleP(x, y, 2.4), '#6a2a08', 0.2, 0.01, 2, 0);
    keep();

    // ── zebra hat (top left) ──
    const hat = P([[92, 196], [84, 166], [94, 132], [112, 100], [116, 50], [124, 14], [136, -10], [258, -10], [268, 34], [272, 84], [262, 124], [230, 140], [180, 160], [130, 180]]);
    const hatZ = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float b = smoothstep(110., 190., p.y) * smoothstep(170., 110., p.x);
      float ph = (p.x - 138.) / (42. - 0.04 * (p.x - 138.)) + 0.25 + b * (p.y - 110.) * 0.012;
      float s = sin(6.2832 * ph);
      return mix(vec3(.04, .04, .05), vec3(.97), smoothstep(-0.12, 0.12, s)); }`);
    R.dome(hat, '#888', 0.12, 0.2, 40, 4);
    clipA(hat, () => img(hatZ));

    // ── red rim lines ──
    const redOut = P([[146, 662], [118, 600], [98, 520], [88, 430], [96, 350], [118, 288], [158, 240], [230, 210], [320, 202], [408, 214], [466, 250], [516, 310], [566, 350], [640, 366], [740, 374]], false);
    const redIn = P([[150, 254], [228, 226], [320, 218], [400, 230], [456, 266], [504, 322], [560, 362], [640, 380], [740, 388]], false);
    R.pipe(redOut, 9, '#ee3a18', 0.18, 0.05, 1);
    R.pipe(redIn, 7, '#e83416', 0.16, 0.04, 1);
    keep();

    // ── face ──
    const facePts = [[130, 335], [150, 290], [185, 262], [240, 248], [300, 250], [356, 258], [396, 280], [414, 322], [414, 390], [406, 440], [408, 480], [424, 520], [432, 560],
      [418, 600], [390, 628], [330, 640], [270, 630], [225, 605], [178, 572], [150, 520], [138, 450], [130, 390]];
    const face = P(facePts);
    R.pipe(face, 16, '#34404c', 0.14, 0.06, 4);
    R.dome(face, CREAM, 0.16, 0.06, 20, 1);
    soft(x => { x.fillStyle = 'rgba(200,190,170,0.5)'; x.fill(ellipseP(430, 470, 20, 70, 0)); }, 12, 0.6);
    // brown eyelid dome
    const lid = P([[176, 352], [176, 320], [190, 288], [214, 268], [244, 264], [268, 278], [282, 304], [286, 352]]);
    const lg = a.createRadialGradient(248, 336, 4, 236, 320, 64); lg.addColorStop(0, '#f8a040'); lg.addColorStop(0.22, '#c85614'); lg.addColorStop(0.5, '#3a1408'); lg.addColorStop(1, '#100604');
    R.dome(lid, lg, 0.2, 0.12, 24, 4);
    R.pipe(P([[182, 356], [228, 364], [272, 360]], false), 4, '#8a2018', 0.22, 0.03, 1);
    R.pipe(P([[188, 368], [230, 374], [268, 370]], false), 3, '#a03020', 0.22, 0.02, 1);
    // right eye + brow
    R.pipe(P([[306, 324], [308, 302], [322, 292], [350, 302], [380, 318], [406, 340]], false), 18, BLK, 0.24, 0.1, 4);
    R.pipe(P([[322, 352], [356, 350], [392, 356]], false), 4, '#3a1a14', 0.22, 0.03, 1);
    R.pipe(P([[326, 366], [360, 372], [396, 368]], false), 3, '#8a2a20', 0.22, 0.02, 1);
    R.bead(358, 354, 8, BLK, 0.22, 0.06, 4);
    // nose, mouth
    R.pipe(P([[304, 352], [306, 410], [308, 470], [314, 498]], false), 6, BLK, 0.22, 0.05, 4);
    R.pipe(P([[304, 488], [322, 508], [348, 512], [368, 504]], false), 10, BLK, 0.22, 0.07, 4);
    R.pipe(P([[284, 576], [300, 580], [318, 572], [340, 566], [362, 572], [382, 580], [396, 574]], false), 11, BLK, 0.22, 0.08, 4);
    R.pipe(P([[284, 576], [280, 568]], false), 7, BLK, 0.22, 0.06, 4); R.pipe(P([[396, 574], [400, 566]], false), 7, BLK, 0.22, 0.06, 4);
    R.dome(rrect(334, 592, 30, 12, 5), '#e8e4d0', 0.2, 0.04, 4, 1);
    keep();

    // ── blue → magenta splat on the cheek ──
    const splat = P([[150, 404], [168, 384], [186, 392], [196, 410], [204, 386], [222, 380], [236, 394], [236, 418], [254, 428], [256, 446], [280, 432], [302, 446], [298, 476], [308, 500], [302, 540],
      [282, 558], [262, 554], [250, 576], [254, 606], [236, 626], [214, 616], [206, 590], [184, 566], [160, 562], [132, 548], [118, 526], [100, 514], [98, 492], [114, 478],
      [100, 462], [96, 440], [112, 428], [132, 430], [140, 416]]);
    const pg = a.createLinearGradient(110, 430, 290, 560); pg.addColorStop(0, '#2e48e8'); pg.addColorStop(0.35, '#5a46ea'); pg.addColorStop(0.6, '#c64ce8'); pg.addColorStop(1, '#f44ee6');
    R.pipe(splat, 8, '#28304a', 0.18, 0.04, 4);
    R.dome(splat, pg, 0.2, 0.1, 16, 1);
    for (const [x, y, r] of [[230, 492, 6], [214, 516, 4], [194, 512, 3], [264, 520, 5], [186, 498, 3], [270, 540, 3]]) R.dome(circleP(x, y, r), '#1a0c20', 0.22, 0.01, r, 4);

    // ── teal pebbles + beads ──
    const peb = (path) => R.dome(path, TEAL, 0.06, 0.1, 14, 1);
    peb(ellipseP(84, 612, 30, 46, 0.05)); peb(ellipseP(95, 762, 34, 38, 0)); peb(ellipseP(215, 990, 46, 32, 0.15)); peb(ellipseP(392, 984, 74, 30, 0));
    peb(ellipseP(556, 1000, 52, 30, 0));
    peb(P([[166, 640], [188, 630], [210, 646], [232, 640], [236, 660], [212, 670], [188, 664], [170, 660]]));
    R.pipe(P([[426, 434], [418, 398], [436, 374], [470, 368], [496, 382], [504, 404]], false), 32, TEAL, 0.08, 0.12, 1);
    for (const [x, y, r] of [[100, 258, 10], [66, 330, 16], [64, 425, 12], [56, 500, 13], [56, 706, 11], [146, 718, 8], [436, 512, 7], [540, 570, 8], [652, 528, 7],
      [665, 670, 12], [565, 935, 6], [316, 938, 7], [76, 552, 6]]) R.bead(x, y, r, r < 9 ? TEAL : TEAL, 0.06, 0.08, 1);
    R.bead(74, 552, 6, '#f05018', 0.06, 0.05, 1);
    keep();

    // ── right side: black hollow, grey shelf with yellow + teal tiles, pink ring, orange ball ──
    R.flat(P([[450, 432], [468, 410], [526, 408], [534, 440], [514, 472], [482, 484], [458, 470]]), '#050608', 0.02, 0);
    R.pipe(P([[462, 540], [470, 470], [490, 420], [530, 404]], false), 3, '#b04018', 0.04, 0.02, 1);
    R.dome(P([[440, 488], [452, 480], [474, 520], [462, 530]]), '#8c96a2', 0.1, 0.05, 4, 3);
    const shelf = P([[520, 540], [496, 480], [520, 424], [600, 398], [680, 386], [746, 384], [746, 486], [690, 500], [620, 530], [556, 552]]);
    R.dome(shelf, '#7e8894', 0.1, 0.06, 10, 3);
    R.dome(P([[540, 435], [590, 402], [602, 468], [570, 462]], true, false), '#f8e604', 0.18, 0.05, 5, 1);
    R.dome(P([[600, 425], [638, 398], [652, 465], [620, 468]], true, false), '#f8e604', 0.18, 0.05, 5, 1);
    R.dome(P([[668, 398], [702, 396], [686, 416]]), '#f87a10', 0.18, 0.04, 4, 1);
    R.dome(rrect(700, 404, 34, 26, 8), '#f04ce0', 0.18, 0.04, 6, 1);
    R.dome(P([[500, 478], [548, 460], [560, 500], [512, 515]], true, false), '#10c494', 0.18, 0.04, 5, 1);
    R.dome(P([[560, 488], [612, 472], [625, 525], [612, 530], [600, 505], [588, 508], [592, 535], [572, 540]], true, false), '#10c494', 0.18, 0.04, 5, 1);
    R.bead(640, 478, 12, '#a8b0bc', 0.16, 0.06, 3);
    R.dome(P([[684, 450], [720, 440], [740, 460], [740, 500], [700, 500], [686, 480]]), '#9aa4b0', 0.16, 0.05, 6, 3);
    R.dome(circleP(620, 610, 34), '#f454ec', 0.08, 0.12, 14, 1);
    R.dome(circleP(620, 610, 13), '#1a1418', 0.02, 0.01, 6, 4);
    R.bead(704, 586, 27, '#fc6208', 0.08, 0.16, 1);
    R.dome(P([[690, 556], [700, 532], [726, 530], [740, 556]]), '#14c08e', 0.1, 0.05, 5, 1);
    keep();

    // ── zebra beard ──
    const beard = P([[164, 692], [250, 672], [330, 650], [420, 610], [470, 560], [520, 590], [570, 640], [616, 700], [644, 760], [640, 840], [612, 900], [580, 944],
      [450, 944], [300, 952], [200, 946], [110, 952], [68, 924], [72, 872], [108, 840], [148, 800], [166, 744]]);
    const FIELD = `float ph(vec2 p){
        vec2 sc = vec2(250., 650.), sd = p - sc;
        float al = -0.9 * exp(-dot(sd, sd) / (160. * 160.));
        p = sc + mat2(cos(al), sin(al), -sin(al), cos(al)) * sd;
        float t = smoothstep(60., 440., p.x);
        vec2 n = normalize(vec2(1., mix(0.15, 0.72, t)));
        vec2 q = p - vec2(360., 800.);
        float w = 12. * sin(p.y * 0.012 - p.x * 0.006) + 22. * (fbm(p * 0.005) - .5);
        return (dot(q, n) + w) / 33.; }`;
    const zA = E.fx(FIELD + `vec3 fx(vec2 uv, vec2 p){
      float s = sin(6.2832 * ph(p));
      vec3 c = mix(vec3(.2, .27, .3), vec3(.04, .045, .05), smoothstep(-0.75, -0.5, s));
      return mix(c, vec3(.9, .9, .91), smoothstep(-0.1, 0.08, s)); }`);
    const zH = E.fx(FIELD + `vec3 fx(vec2 uv, vec2 p){
      float s = sin(6.2832 * ph(p));
      float h = 0.1 + 0.08 * sqrt(clamp((s + 0.15) / 1.15, 0., 1.));
      float v = h * 255.;
      return vec3(floor(v) / 255., 6. * 32. / 255., fract(v)); }`);
    clipA(beard, () => img(zA));
    himg(beard, zH);
    keep();

    // ── teal fern (bottom right) ──
    const fr = rng(7);
    for (let i = 0; i < 36; i++) {
      const y0 = 640 + i * 10 + fr() * 4, t = (y0 - 640) / 360;
      const ang = Math.PI + 0.12 - t * 0.6 + (fr() - 0.5) * 0.12, bend = -0.2 - t * 0.35;
      const L = 70 + t * 80 + fr() * 24, pts = [];
      for (let k = 0; k <= 8; k++) { const u = k / 8, an = ang + bend * u * u; pts.push([742 + Math.cos(an) * L * u, y0 + Math.sin(an) * L * u + Math.sin(u * 6 + i) * 3]); }
      R.pipe(P(pts, false), 6, '#1f9476', 0.1, 0.05, 1);
    }
    R.dome(P([[690, 966], [740, 1000], [740, 1020], [700, 990]]), '#8a929c', 0.2, 0.06, 4, 3);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.35, coat: 0.12, ao: 0.5, rim: 0.25 }),                 // 1 glossy plastic
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.4, grain: 0.18, ao: 0.6, coat: 0.05 }),                // 2 slate plaque
        E.mat({ dif: 0.9, metal: 0.2, spec: 0.6, shin: 30, wrap: 0.45, grain: 0.14, ao: 0.6, coat: 0.06 }),   // 3 silver
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.2, coat: 0.2, ao: 0.4 }),                               // 4 black gloss
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.6, emis: 0.25 }),                                       // 5 red ground
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, coat: 0.12, ao: 0.6 }),                              // 6 zebra beard
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, grain: 0.5 })                                       // 7 cork
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.8, 0.8, 0.82], amb: [0.42, 0.42, 0.45],
      envTop: [1.05, 1.04, 1.02], envHor: [0.5, 0.52, 0.56], envBot: [0.12, 0.13, 0.15], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.25, 0.3, 0.35], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-5, 6, 0.5, 6]
    });
    E.grain(0.035, 51);
  }
});
