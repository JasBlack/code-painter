'use strict';
// g219 — "Anemone with a zebra spoon": a pale-blue glossy creature trailing blue tentacles tipped with orange beads,
// a black plate of white pills, a chrome porthole eye, a glowing red glitter slot and a black-striped white spoon, on black.
REC.register('g219', {
  w: 1024, h: 726,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const SKIN = 1, GLOSS = 2, CHROME = 3, BEAD = 4, TUBE = 5, GLOW = 6;

    // ── textures ──
    const GRV = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float w = fbm(p * 0.006) * 4.0;
        float g = sin((p.x * 0.45 - p.y * 0.9) * 0.9 + w * 2.5);
        return vec3(0.5 + 0.5 * smoothstep(0.2, 1.0, g)); }`);

    // ── 1. black void + orange stripes (top left) ──
    R.flat(rrect(-10, -10, 1044, 746, 0), '#040405', 0, 0);
    const stripeZone = Q([-10, -10, 230, -10, 200, 120, 160, 250, 130, 400, 60, 470, -10, 480], true, false);
    clipA(stripeZone, () => {
      R.paint(rrect(-10, -10, 260, 500, 0), '#1c1418');
      for (let k = -2; k < 9; k++) { const y = 85 + k * 58; a.lineCap = 'butt'; a.lineWidth = k === -1 ? 24 : 27; a.strokeStyle = k === -1 ? '#e8d8c8' : '#f06a46'; a.beginPath(); a.moveTo(-20, y); a.lineTo(260, y + 140); a.stroke(); }
    });
    soft(x => { fe(x, 100, 380, 90, 140, 0, '#3a1a28'); fe(x, 60, 560, 70, 120, 0, '#3a1820'); }, 20, 0.9);

    // ── 2. the pale-blue body ──
    const body = Q([200, -10, 845, -10, 868, 50, 895, 120, 935, 230, 955, 320, 975, 420, 975, 520, 955, 620, 930, 736, -10, 736, -10, 600, 30, 540, 70, 450, 100, 350, 120, 260, 140, 170, 165, 80], true, false);
    R.dome(body, lg(650, 150, 300, 720, [[0, '#d0e0ee'], [0.4, '#c0d4e4'], [0.62, '#5a88a8'], [0.8, '#2e6282'], [1, '#1c4458']]), 0.05, 0.3, 120, SKIN);
    clipA(body, () => {
      soft(x => { fe(x, 700, 640, 260, 90, -0.2, '#3a6c8c'); fe(x, 250, 650, 260, 120, -0.4, '#1d5064'); fe(x, 830, 700, 120, 60, 0, '#283c50'); fe(x, 430, 200, 160, 120, 0, '#c4d4e4'); }, 40, 0.9);
      a.globalCompositeOperation = 'multiply'; img(GRV, 0.55); a.globalCompositeOperation = 'source-over';
    });
    // lobes on the upper right
    for (const [x, y, rx, ry] of [[790, 50, 72, 80], [870, 180, 45, 75], [920, 300, 38, 70], [240, 20, 55, 40]])
      R.dome(ellipseP(x, y, rx, ry, 0.2), lg(x - rx, y - ry, x + rx, y + ry, [[0, '#d4e2ee'], [0.6, '#b0c4d6'], [1, '#7a8ca0']]), 0.12, 0.25, Math.min(rx, ry) * 1.1, SKIN);

    // ── 3. black plate of white pills ──
    const plate = Q([263, 95, 272, 75, 300, 60, 340, 44, 380, 30, 440, 16, 480, 8, 545, 6, 585, 20, 600, 60, 604, 130, 585, 160, 520, 172, 470, 200, 420, 226, 380, 238, 348, 232, 325, 212, 300, 180, 283, 148, 268, 118]);
    R.dome(plate, '#0c1424', 0.12, 0.06, 10, GLOSS);
    R.pipe(plate, 5, '#c8d8e8', 0.16, 0.03, GLOSS);
    for (const [x, y] of [[322, 87], [411, 58], [487, 42], [508, 83], [433, 103], [359, 130], [453, 146], [520, 127], [386, 178]])
      R.dome(ellipseP(x, y, 33, 21, -0.15), rg(x - 8, y - 8, 2, x, y, 34, [[0, '#f4f6fa'], [0.7, '#c4ccdc'], [1, '#8a98b0']]), 0.2, 0.14, 18, GLOSS);
    R.pipe(Q([575, 18, 588, 80, 602, 148], true, false), 9, '#c8b090', 0.2, 0.06, CHROME);

    // ── 4. porthole eye ──
    R.dome(ellipseP(637, 245, 104, 100, 0), '#0e1830', 0.14, 0.1, 16, GLOSS);
    R.pipe(ellipseP(637, 245, 92, 88, 0), 4, '#a8c4e0', 0.24, 0.03, GLOSS);
    const lens = circleP(648, 250, 74);
    R.dome(lens, lg(0, 176, 0, 324, [[0, '#f4f4f6'], [0.42, '#e8e8ea'], [0.47, '#2a2226'], [0.8, '#1a1214'], [1, '#c86a30']]), 0.26, 0.2, 30, CHROME);
    R.pipe(Q([600, 300, 640, 316, 690, 312], true, false), 4, '#ff9a40', 0.4, 0.02, GLOW);
    R.pipe(circleP(650, 232, 13), 3, '#f0f0f0', 0.46, 0.02, CHROME);

    // ── 5. membrane, red slot, zebra spoon ──
    const mem = Q([385, 330, 440, 298, 520, 296, 600, 316, 680, 336, 732, 360, 742, 405, 700, 425, 620, 418, 540, 432, 480, 460, 430, 452, 395, 410]);
    R.dome(mem, '#e8dcec', 0.12, 0.08, 30, SKIN);
    clipA(mem, () => { a.strokeStyle = 'rgba(250,250,255,0.7)'; a.lineWidth = 1.2; for (let i = 0; i < 9; i++) { a.beginPath(); a.ellipse(540, 362, 8 + i * 9, 6 + i * 7, 0, 0, 6.283); a.stroke(); } });
    const spoon = Q([484, 462, 493, 466, 500, 490, 520, 502, 528, 530, 500, 560, 430, 640, 390, 670, 352, 684, 294, 696, 228, 690, 175, 664, 154, 642, 155, 620, 162, 604, 180, 586, 232, 560, 330, 536, 420, 500, 458, 478]);
    R.dome(spoon, lg(150, 700, 560, 480, [[0, '#f2f0ec'], [0.6, '#e6e2de'], [1, '#f8e0d4']]), 0.16, 0.2, 40, GLOSS);
    for (const st of [[460, 492, 369, 533, 253, 563, 219, 577, 278, 570, 355, 550, 408, 526],
      [481, 516, 448, 529, 398, 561, 352, 582, 269, 604, 169, 617, 161, 623, 160, 634, 179, 640, 231, 636, 341, 608, 391, 583, 479, 522],
      [520, 529, 467, 559, 444, 578, 397, 618, 361, 641, 299, 667, 230, 682, 229, 687, 294, 693, 352, 671, 415, 628],
      [526, 535, 492, 558, 401, 642, 351, 673, 351, 679, 389, 669, 428, 642, 527, 542]]) R.flat(Q(st, true, true), '#060608', 0.34, GLOSS);
    // red glitter slot with a pink glow
    soft(x => { fe(x, 600, 458, 150, 60, -0.08, '#ffd8c0'); }, 18, 1);
    const slot = Q([492, 470, 500, 446, 540, 436, 600, 432, 660, 428, 700, 432, 706, 452, 690, 470, 640, 478, 580, 486, 520, 492, 496, 486]);
    R.dome(Q([470, 470, 480, 430, 540, 414, 620, 410, 700, 410, 728, 440, 712, 480, 650, 500, 560, 510, 490, 510]), '#ffe4d4', 0.2, 0.06, 18, GLOW);
    R.flat(slot, '#c8141c', 0.26, GLOW);
    clipA(slot, () => { const r = rng(4); for (let i = 0; i < 260; i++) R.paint(circleP(490 + r() * 220, 426 + r() * 70, 0.8 + r() * 1.2), r() < 0.4 ? '#f8c040' : (r() < 0.5 ? '#ff4040' : '#700810')); });
    R.pipe(Q([736, 433, 770, 440, 800, 448, 828, 452], true, false), 12, '#f0f0f0', 0.2, 0.06, GLOSS);
    R.pipe(Q([740, 433, 770, 440, 800, 448, 824, 452], true, false), 6, '#0a0a10', 0.24, 0.02, GLOSS);

    // ── 6. right side: grey lobe, blue spiky arm, coral double ring ──
    R.dome(ellipseP(900, 482, 62, 82, 0.1), lg(840, 400, 960, 560, [[0, '#e0eaf4'], [1, '#9eb4cc']]), 0.14, 0.3, 70, SKIN);
    const arm = Q([925, 300, 945, 290, 958, 350, 990, 372, 1030, 345, 1034, 400, 995, 430, 990, 500, 1020, 520, 1034, 600, 1000, 580, 975, 540, 958, 560, 950, 500, 958, 440, 935, 380]);
    R.dome(arm, lg(900, 300, 1030, 600, [[0, '#5a98dc'], [1, '#3a70bc']]), 0.12, 0.2, 20, GLOSS);
    const ring = Q([786, 545, 800, 512, 842, 502, 860, 512, 880, 506, 905, 515, 912, 548, 900, 580, 862, 590, 840, 600, 800, 596, 784, 575]);
    R.dome(ring, '#e2705a', 0.2, 0.12, 14, GLOSS);
    R.dome(ellipseP(826, 558, 26, 30, 0), '#06060a', 0.22, 0.04, 10, GLOSS);
    R.dome(ellipseP(882, 548, 20, 24, 0), '#0a0a12', 0.22, 0.04, 8, GLOSS);

    // ── 7. tentacles ──
    const tips = [[205, 98], [295, 145], [283, 172], [255, 193], [173, 163], [178, 208], [133, 205], [215, 243], [200, 268], [243, 270], [163, 283], [189, 302], [133, 280], [120, 258], [313, 278], [344, 260],
      [360, 338], [248, 338], [265, 353], [155, 355], [188, 373], [88, 325], [68, 365], [30, 328], [253, 384], [133, 400], [53, 408], [303, 423], [225, 458], [253, 476], [320, 498], [210, 518],
      [133, 528], [110, 518], [68, 495], [115, 560], [40, 570], [65, 628], [5, 660]];
    tips.sort((p, q) => q[0] - p[0]);
    for (const [tx, ty] of tips) {
      const bx = 415, by = 335 + (ty - 98) * 0.25, cx = tx + 30, cy = by + (ty - by) * 0.15;
      const pth = new Path2D(); pth.moveTo(tx, ty); pth.quadraticCurveTo(cx, cy, bx, by);
      R.pipe(pth, 22, '#2a5ed0', 0.2, 0.12, TUBE);
    }
    soft(x => { fe(x, 420, 390, 40, 90, 0, '#e8e0ee'); }, 18, 0.85);
    for (const [tx, ty] of tips) {
      const bx = 415, by = 335 + (ty - 98) * 0.25, cx = tx + 30, cy = by + (ty - by) * 0.15;
      const t = 16 / Math.hypot(bx - tx, by - ty), sx = (1 - t) * (1 - t) * tx + 2 * (1 - t) * t * cx + t * t * bx, sy = (1 - t) * (1 - t) * ty + 2 * (1 - t) * t * cy + t * t * by;
      R.pipe(Q([tx, ty, sx, sy], true, false), 20, '#f2eef4', 0.32, 0.08, BEAD);
      R.bead(tx, ty, 12, '#f2581e', 0.36, 0.14, BEAD);
    }

    // ── 8. scattered beads ──
    const br = rng(2191);
    for (const [x, y, r] of [[455, 398, 16], [540, 322, 12], [472, 316, 10], [614, 358, 12], [685, 383, 10], [705, 357, 9], [732, 346, 8], [775, 330, 7], [830, 410, 14], [873, 358, 11], [906, 323, 10], [820, 255, 9],
      [910, 236, 9], [924, 255, 11], [605, 510, 14], [733, 515, 11], [683, 540, 12], [718, 585, 12], [770, 583, 9], [830, 600, 12], [864, 665, 8], [770, 650, 13], [735, 610, 11], [650, 628, 16], [605, 568, 13],
      [545, 557, 13], [518, 630, 12], [577, 608, 9], [605, 646, 10], [546, 685, 13], [498, 686, 10], [405, 683, 12], [600, 680, 8], [690, 700, 12], [770, 712, 10], [440, 715, 9], [340, 600, 9], [165, 580, 8], [200, 540, 7]]) {
      R.bead(x, y, r, '#f4ecec', 0.3, Math.min(0.2, 0.05 + r * 0.008), BEAD);
      for (let k = 0; k < 3; k++) R.paint(P(blob(x + (br() - 0.5) * r, y + (br() - 0.5) * r, r * 0.3, r * 0.22, 7 + k, 7, 0.4)), '#f05a20');
    }
    for (let i = 0; i < 90; i++) { const x = 380 + br() * 560, y = 200 + br() * 520, r = 1.5 + br() * 3; R.bead(x, y, r, br() < 0.5 ? '#f0d0d8' : '#d8e0ec', 0.3, 0.03, BEAD); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.9, shin: 40, wrap: 0.6, coat: 0.2, ao: 0.3, emis: 0.15 }),               // 1 glossy skin
        E.mat({ dif: 1, spec: 1.6, shin: 90, wrap: 0.4, coat: 0.3, ao: 0.2, emis: 0.05 }),                 // 2 gloss plastic
        E.mat({ dif: 0.4, spec: 1.6, shin: 90, metal: 0.7, tint: [1.15, 1.15, 1.15] }),                    // 3 chrome
        E.mat({ dif: 0.9, spec: 1.3, shin: 70, wrap: 0.5, coat: 0.15, emis: 0.15 }),                       // 4 beads
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.5, ao: 0.4, grain: 0.15, emis: 0.1 }),                // 5 blue tubes
        E.mat({ dif: 0.4, spec: 0.6, shin: 40, emis: 0.7 }),                                               // 6 glowing slot
      ],
      light: [-0.4, 0.65, 0.65], lc: [0.75, 0.75, 0.78], amb: [0.38, 0.4, 0.44],
      envTop: [1.1, 1.12, 1.15], envHor: [0.6, 0.66, 0.72], envBot: [0.08, 0.1, 0.14], envK: [0.3, 1.0, 0, 0],
      rimC: [0.1, 0.14, 0.2], rimD: [0, 1, 0], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.5, 6]
    });
  }
});
