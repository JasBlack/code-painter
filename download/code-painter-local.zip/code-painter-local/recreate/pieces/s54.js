'use strict';
// s54 — "Mushroom keeper": a striated grey creature with three glowing eyes crouches in a
// dark blue cave among glossy dark mushroom caps on tall tan stalks, under layered
// rock ridges, over a floor of blue glossy pebbles and pale coral stems.
REC.register('s54', {
  w: 1024, h: 580,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      const src = E.blur(c, blur);
      if (clip) { const m = src.getContext('2d'); m.setTransform(S, 0, 0, S, 0, 0); m.globalCompositeOperation = 'destination-in'; m.fillStyle = '#fff'; m.fill(clip); }
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(src, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); for (const [t, c] of st) g.addColorStop(t, c); return g; };
    const ell = (x, cx, cy, rx, ry, c, rot = 0) => { x.fillStyle = c; x.beginPath(); x.ellipse(cx, cy, rx, ry, rot, 0, 6.283); x.fill(); };
    const r = rng(54);

    // ── dark cave + blue haze ────────────────────────────────
    R.flat(rrect(-10, -10, 1044, 600, 0), '#01040e', 0, 0);
    soft(x => {
      ell(x, 240, 170, 60, 30, '#0a88d8', -0.3); ell(x, 450, 300, 70, 40, '#0660c0'); ell(x, 930, 320, 110, 60, '#04245a');
      ell(x, 880, 110, 120, 70, '#061c48'); ell(x, 250, 360, 170, 70, '#1a3468'); ell(x, 600, 470, 200, 50, '#303850'); ell(x, 560, 90, 150, 50, '#040c24'); ell(x, 120, 330, 120, 50, '#041030'); ell(x, 960, 440, 100, 40, '#0a2a6a');
    }, 30, 1);
    // stars / spores
    for (let i = 0; i < 120; i++) { const x = r() * 1024, y = r() * 420; a.fillStyle = `rgba(80,150,255,${0.3 + r() * 0.6})`; a.fill(circleP(x, y, 0.6 + r() * 1.6)); }

    // ── striated rock ridges ─────────────────────────────────
    const rockTex = (warm, base, line, k) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.005) * 150. + fbm(p * 0.02 + 4.) * 20.;
      float s = sin((p.y * 0.95 - p.x * ${k.toFixed(2)} + n) * 0.42);
      float l = smoothstep(0.78, 0.98, s) * (0.5 + 0.5 * smoothstep(0.3, 0.6, fbm(p * 0.01 + 9.)));
      vec3 b = vec3(${base});
      vec3 lc = mix(vec3(${line}), vec3(${warm}), smoothstep(0.35, 0.8, fbm(p * 0.008 + 2.)));
      return mix(b, lc, l); }`));
    const rockTL = P([[-10, -10], [412, -10], [404, 30], [376, 70], [330, 112], [280, 150], [212, 182], [150, 212], [90, 240], [30, 266], [-10, 276]], true, true);
    R.dome(rockTL, rockTex('.95,.55,.3', '.03,.03,.07', '.55,.52,.62', 0.45), 0.05, 0.15, 80, 6);
    soft(x => { x.strokeStyle = '#f0a060'; x.lineWidth = 10; x.stroke(P([[390, 20], [350, 80], [290, 140], [210, 176], [140, 206], [60, 240]], false)); }, 8, 0.55, 'screen', rockTL);
    soft(x => { ell(x, 110, 120, 90, 40, '#010208', -0.3); ell(x, 260, 60, 60, 26, '#020410', -0.3); }, 14, 0.7, 'source-over', rockTL);
    const arch = P([[400, -10], [834, -10], [820, 36], [760, 58], [650, 66], [550, 58], [470, 48], [404, 34]], true, true);
    R.dome(arch, rockTex('.5,.55,.7', '.02,.03,.07', '.3,.33,.45', 0.1), 0.05, 0.08, 30, 6);
    const rockTR = P([[800, -10], [1034, -10], [1034, 268], [990, 244], [944, 204], [896, 146], [856, 86], [818, 34]], true, true);
    R.dome(rockTR, '#020308', 0.05, 0.2, 90, 6);
    a.save(); a.clip(rockTR); a.lineWidth = 80; a.lineJoin = 'round'; a.strokeStyle = rockTex('.86,.88,.92', '.3,.32,.38', '.9,.92,.96', -0.9);
    a.stroke(P([[790, -30], [818, 34], [856, 86], [896, 146], [944, 204], [990, 244], [1044, 272]], false, true)); a.restore();
    soft(x => { x.strokeStyle = '#020308'; x.lineWidth = 60; x.stroke(P([[850, -40], [880, 40], [930, 110], [980, 160], [1060, 200]], false, true)); }, 14, 1, 'source-over', rockTR);

    // grey striated wings behind the creature
    const wingTex = rockTex('.66,.66,.7', '.16,.16,.19', '.66,.66,.7', 0.9);
    R.dome(P([[396, 244], [420, 192], [470, 152], [530, 136], [580, 142], [610, 172], [600, 232], [560, 262], [480, 272]], true, true), wingTex, 0.05, 0.2, 40, 3);
    R.dome(P([[700, 122], [760, 96], [830, 90], [862, 112], [852, 182], [802, 240], [750, 262], [712, 232]], true, true), wingTex, 0.05, 0.2, 40, 3);

    // ── creature ─────────────────────────────────────────────
    const skin = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.012) * 70. + fbm(p * 0.04 + 3.) * 12. + p.y * 0.25;
      float s = sin(n * 1.9);
      float l = smoothstep(-0.55, -0.1, s);
      return mix(vec3(.12,.12,.14), vec3(.6,.59,.58), l); }`));
    const body = P([[470, 424], [462, 384], [500, 334], [540, 274], [582, 242], [622, 246], [700, 240], [742, 272], [772, 322], [782, 382], [764, 432], [700, 444], [600, 444]], true, true);
    R.dome(body, skin, 0.08, 0.3, 60, 3);
    R.dome(ellipseP(655, 190, 52, 68, 0), skin, 0.2, 0.3, 40, 3);
    R.dome(ellipseP(652, 228, 26, 20, 0), '#3a3836', 0.3, 0.06, 12, 3);
    a.save(); a.fillStyle = '#d8d0c0'; for (let i = 0; i < 6; i++) a.fillRect(636 + i * 5, 226, 3.5, 6); a.restore();
    R.pipe(P([[590, 262], [600, 292], [622, 310]], false, true), 36, skin, 0.3, 0.2, 3);
    R.pipe(P([[560, 380], [620, 400], [690, 402]], false, true), 30, skin, 0.25, 0.14, 3);
    a.save(); a.strokeStyle = '#1a1818'; a.lineWidth = 3; a.stroke(P([[626, 236], [645, 242], [668, 236]], false)); a.restore();
    for (const [x, y] of [[635, 176], [662, 177], [690, 178]]) { R.bead(x, y, 8, '#fff8e8', 0.5, 0.05, 0); }
    soft(x => { for (const [cx, cy] of [[635, 176], [662, 177], [690, 178]]) ell(x, cx, cy, 16, 12, '#fff0c0'); }, 8, 1, 'screen');

    // purple + cyan glows on the ground
    soft(x => { ell(x, 235, 440, 55, 18, '#7040f0'); ell(x, 395, 320, 28, 22, '#10a0ff'); ell(x, 470, 270, 20, 30, '#1080f0'); ell(x, 760, 430, 30, 12, '#3070f0'); }, 12, 0.9, 'screen');

    // ── ground pebbles ───────────────────────────────────────
    R.flat(P([[-10, 420], [120, 408], [300, 420], [500, 440], [700, 440], [900, 420], [1034, 400], [1034, 590], [-10, 590]], true, true), '#060a16', 0.02, 0);
    for (let row = 0; row < 26; row++) {
      const t = row / 25, y = 418 + Math.pow(t, 1.3) * 168, rr = 3 + t * t * 20;
      for (let x = -10 + (row % 2) * rr; x < 1040; x += rr * 1.9) {
        const px = x + (r() - 0.5) * rr, py = y + (r() - 0.5) * rr * 0.6;
        const blue = px < 360 - (py - 480) * 0.3 && py > 470;
        const c = blue ? mixHex('#0a2a90', '#1a50c0', r()) : mixHex('#0c1018', '#222a38', r());
        R.dome(ellipseP(px, py, rr, rr * 0.72, 0), c, 0.05, 0.1 + rr * 0.01, rr * 0.9, blue ? 2 : 5);
      }
    }

    // ── mushrooms: tan stalks + glossy dark caps ─────────────
    const shrooms = [[320, 212, 40], [268, 266, 32], [325, 288, 36], [235, 340, 30], [192, 330, 24], [142, 290, 20], [118, 280, 15], [162, 308, 18], [102, 352, 16], [376, 256, 24],
      [372, 346, 20], [408, 334, 22], [443, 246, 40], [490, 236, 18], [286, 198, 15], [380, 232, 15], [800, 246, 33], [866, 250, 38], [918, 238, 30], [800, 286, 20], [836, 286, 14],
      [1006, 426, 18], [16, 382, 22], [4, 410, 16], [610, 276, 18], [632, 300, 16], [657, 318, 20], [656, 270, 20], [558, 366, 14], [577, 338, 12], [638, 352, 11], [215, 275, 22], [110, 300, 13]];
    for (const [x, y, rc] of shrooms) {
      const bx = x + (r() - 0.5) * 60, by = 470 + r() * 60;
      const st = P([[x, y + rc * 0.4], [x + (bx - x) * 0.3 + (r() - 0.5) * 10, y + (by - y) * 0.4], [bx, by]], false, true);
      R.pipe(st, 3 + rc * 0.1, lin(0, y, 0, by, [[0, '#8a96a8'], [0.5, '#b8a088'], [1, '#d08a40']]), 0.2, 0.06, 4);
    }
    for (const [x, y, rc] of shrooms) {
      const cap = P([[x - rc, y + rc * 0.45], [x - rc * 0.95, y], [x - rc * 0.6, y - rc * 0.55], [x, y - rc * 0.72], [x + rc * 0.6, y - rc * 0.55], [x + rc * 0.95, y], [x + rc, y + rc * 0.45], [x, y + rc * 0.3]], true, true);
      R.dome(cap, lin(x - rc, y - rc, x + rc, y + rc, [[0, '#3a3e4a'], [0.5, '#1c1f28'], [1, '#0c0d14']]), 0.3, 0.3, rc * 0.7, 1);
      soft(z => { z.strokeStyle = '#f0e0ff'; z.lineWidth = 2; z.stroke(P([[x - rc, y + rc * 0.45], [x - rc * 0.95, y], [x - rc * 0.6, y - rc * 0.55], [x, y - rc * 0.72], [x + rc * 0.6, y - rc * 0.55], [x + rc * 0.95, y], [x + rc, y + rc * 0.45]], false, true)); }, 1.2, 0.8, 'screen');
      soft(z => { ell(z, x - rc * 0.55, y + rc * 0.2, rc * 0.35, rc * 0.2, '#f0a060'); }, rc * 0.2, 0.55, 'screen');
    }

    // ── pale coral stems in the foreground ───────────────────
    const stem = (x0, y0, len, ang, w, depth) => {
      const x1 = x0 + Math.cos(ang) * len, y1 = y0 + Math.sin(ang) * len;
      R.pipe(P([[x0, y0], [(x0 + x1) / 2 + (r() - 0.5) * 8, (y0 + y1) / 2], [x1, y1]], false, true), w, depth > 1 ? '#5a6272' : '#8a8478', 0.3, 0.1, 4);
      if (depth > 0) for (let k = 0; k < 2; k++) if (r() < 0.8) stem(x1, y1, len * (0.5 + r() * 0.3), ang + (k ? 1 : -1) * (0.3 + r() * 0.4), w * 0.75, depth - 1);
      else R.bead(x1, y1, w * 0.7, '#c0c8d4', 0.35, 0.05, 4);
    };
    for (let i = 0; i < 16; i++) { const x = 420 + r() * 620; stem(x, 590, 50 + r() * 70, -Math.PI / 2 + (r() - 0.5) * 0.6, 5 + r() * 3, 2); }
    for (let i = 0; i < 40; i++) { const x = 440 + r() * 360, y = 470 + r() * 110; R.pipe(P([[x, y + 40], [x + (r() - 0.5) * 20, y - 30 - r() * 50]], false), 4 + r() * 3, mixHex('#a08a68', '#c8b08a', r()), 0.3, 0.06, 4); }
    for (let i = 0; i < 6; i++) { const x = 400 + r() * 200; stem(x, 590, 90 + r() * 60, -Math.PI / 2 + (r() - 0.5) * 0.5, 7, 2); }
    // tall tan stalks crossing the foreground
    for (const [x0, x1, y1] of [[430, 450, 250], [410, 330, 290], [870, 866, 250], [912, 918, 238], [820, 800, 290]]) R.pipe(P([[x0, 590], [(x0 + x1) / 2, 420], [x1, y1 + 20]], false, true), 7, lin(0, 590, 0, y1, [[0, '#e09040'], [0.5, '#c0a080'], [1, '#98a0b0']]), 0.35, 0.06, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, spec: 0.5, shin: 60, wrap: 0.1, rim: 0.9 }),                         // 1 glossy caps
        E.mat({ dif: 1, spec: 0.7, shin: 30, wrap: 0.3, rim: 0.4, coat: 0.05 }),               // 2 blue pebbles
        E.mat({ dif: 1, spec: 0.25, shin: 16, wrap: 0.4, rim: 0.4, ao: 0.4 }),                 // 3 creature
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, rim: 0.4 }),                          // 4 stems
        E.mat({ dif: 1, spec: 0.4, shin: 20, wrap: 0.3, rim: 0.3 }),                          // 5 dark pebbles
        E.mat({ dif: 1, spec: 0.15, shin: 12, wrap: 0.5, rim: 0.2 })                          // 6 rock ridges
      ],
      light: [-0.6, 0.35, 0.72], lc: [0.7, 0.5, 0.36], amb: [0.3, 0.34, 0.48],
      envTop: [0.4, 0.5, 0.8], envHor: [0.1, 0.14, 0.3], envBot: [0.01, 0.02, 0.05], envK: [0.05, 0.4, 0.2, 0],
      rimC: [0.45, 0.48, 0.7], rimD: [0, 1, 0.3], l2: [0.6, 0.3, 0.4, 3], l2c: [0.1, 0.16, 0.4],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [4, 6, 0.5, 6]
    });
    E.bloom(0.25, 10, 'brightness(0.7) contrast(2.2)');
    E.grain(0.03, 54);
  }
});
