'use strict';
// g045 — "Spiral-cheeked dreamer": a pale aqua face with a glowing outline, yellow hair wisps, a stippled forehead
// split by navy and orange stripes, green eyes, black dots and inked spirals, a glowing blue coral spilling from
// the cheek into an orange gloss blob, a black-and-white zebra spiral behind and a royal-blue turtleneck.
REC.register('g045', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (blur, fn) => { o.save(); o.filter = `blur(${blur * S}px)`; fn(); o.restore(); };
    const glow = (path, c, wd, blur) => { o.save(); o.shadowColor = c; o.shadowBlur = blur * S; K(path, c, wd); o.restore(); };
    const rr = rng(45);
    const spiral = (x, y, R0, turns, wd, col) => { const pts = []; const n = Math.round(turns * 60);
      for (let i = 0; i <= n; i++) { const t = i / n, a = t * turns * 6.2832, r = 2 + t * R0; pts.push([x + Math.cos(a) * r, y + Math.sin(a) * r]); }
      K(P(pts, false, false), col, wd); };

    // ── background: blue field, grey top-left, zebra swirl right ──
    F(rrect(0, 0, 726, 1024, 0), '#1d95ed');
    F(P([[0, 0], [230, 0], [220, 60], [180, 110], [100, 170], [40, 200], [0, 210]], true, true), '#d0cecf');
    const zeb = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(578., 578.);
      float r = length(d), th = atan(d.y, d.x);
      float sp = r / 38. - th / 6.2832;
      float hz = (p.y + 10. * sin(p.x * 0.025 + 1.) + 14. * sin(p.y * 0.012 + p.x * 0.008)) / 34.;
      float w = smoothstep(185., 250., r);
      float ph = mix(sp, hz + 0.3, w);
      vec2 d2 = p - vec2(676., 74.);
      float r2 = length(d2), sp2 = r2 / 30. - atan(d2.y, d2.x) / 6.2832;
      ph = mix(sp2, ph, smoothstep(55., 95., r2));
      float s = cos(6.2832 * ph);
      vec3 c = mix(vec3(.03), vec3(.95, .94, .93), smoothstep(-0.18, 0.18, s));
      return c; }`);
    const zreg = P([[430, 0], [726, 0], [726, 960], [560, 940], [540, 800], [470, 720], [450, 600], [450, 470], [470, 420], [600, 390], [600, 300], [540, 200], [470, 110], [430, 60]], true, false);
    F(zreg, pat(zeb));
    F(P([[540, 780], [726, 780], [726, 960], [560, 950]], true, false), '#050505');

    // glossy blue wave top-left, pale neck shape top centre
    { const g = o.createLinearGradient(0, 80, 0, 260); g.addColorStop(0, '#8cc0f0'); g.addColorStop(1, '#3a90e8');
      F(P([[0, 150], [40, 120], [90, 110], [140, 80], [190, 50], [240, 20], [270, 40], [250, 100], [210, 150], [150, 190], [90, 220], [40, 250], [0, 260]]), g); }
    soft(3, () => { K(P([[20, 170], [70, 140], [120, 128], [170, 96]], false), 'rgba(255,255,255,0.75)', 5); K(P([[150, 70], [200, 44]], false), 'rgba(255,255,255,0.6)', 4); });
    F(P([[226, 0], [380, 0], [372, 40], [340, 60], [270, 60], [236, 40]], true, true), '#c8c4d8');
    F(P([[226, 0], [360, 0], [356, 18], [232, 20]], true, false), '#f0c8b8');

    // ── orange gloss blob, right ──
    { const g = o.createLinearGradient(500, 700, 726, 700); g.addColorStop(0, '#f8c0b0'); g.addColorStop(0.35, '#f9783c'); g.addColorStop(1, '#f94818');
      F(P([[480, 760], [540, 740], [600, 724], [650, 690], [690, 620], [710, 560], [726, 520], [736, 520], [736, 800], [700, 812], [660, 840], [610, 860], [560, 850], [510, 820]]), g); }
    soft(5, () => F(ellipseP(632, 784, 28, 20, -0.3), '#f4f4ff'));
    soft(10, () => F(ellipseP(640, 760, 60, 40, -0.3), 'rgba(255,170,140,0.35)'));

    // ── turtleneck ──
    const neck = P([[160, 740], [400, 740], [410, 860], [300, 880], [170, 860]], true, false);
    { const g = o.createLinearGradient(160, 0, 400, 0); g.addColorStop(0, '#a8c4d8'); g.addColorStop(0.5, '#c4dce4'); g.addColorStop(1, '#9cb8d0'); F(neck, g); }
    const sweater = P([[-10, 930], [60, 900], [120, 860], [130, 820], [180, 840], [260, 856], [340, 850], [420, 830], [470, 860], [560, 900], [620, 930], [736, 950], [736, 1034], [-10, 1034]]);
    F(sweater, '#1446ee');
    C(sweater, () => soft(14, () => { F(ellipseP(300, 990, 280, 40, 0), '#1238e0'); F(ellipseP(120, 950, 80, 30, 0), '#1858f4'); }));
    K(P([[110, 960], [124, 900], [134, 836], [200, 870], [300, 886], [400, 870], [440, 846]], false), '#22306a', 2.5);
    K(P([[110, 960], [200, 975], [330, 980], [460, 960]], false), '#22306a', 2);

    // ── the face ──
    const face = P([[70, 300], [110, 240], [180, 210], [250, 150], [300, 112], [380, 100], [450, 100], [490, 120], [520, 170], [550, 230], [590, 280], [606, 330],
      [596, 372], [560, 395], [500, 410], [462, 450], [450, 520], [430, 560], [400, 640], [380, 700], [350, 745], [300, 772], [240, 774], [190, 750], [140, 700],
      [100, 640], [86, 560], [76, 470], [66, 380]]);
    glow(face, '#f8e8c8', 4, 14);
    { const g = o.createLinearGradient(0, 200, 0, 780); g.addColorStop(0, '#9cbcd8'); g.addColorStop(0.45, '#a8cce0'); g.addColorStop(1, '#c4e4e2'); F(face, g); }
    C(face, () => {
      soft(30, () => { F(ellipseP(120, 420, 60, 160, 0), 'rgba(110,150,200,0.6)'); F(ellipseP(300, 640, 90, 110, 0), 'rgba(220,245,240,0.7)'); });
      // stippled forehead
      const st = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
        float dens = smoothstep(470., 200., p.y) * (0.35 + 0.65 * smoothstep(120., 300., p.x)) * 0.8;
        vec2 g = floor(p / 2.6); float h = hash(g);
        float dot = step(1. - dens * 0.5, h) * smoothstep(1.1, 0.4, length(fract(p / 2.6) - .5) * 2.6);
        return vec3(1. - dot * 0.75); }`));
      o.save(); o.globalCompositeOperation = 'multiply'; o.fillStyle = st; o.fillRect(60, 100, 560, 440); o.restore();
    });
    // forehead stripes: navy stippled bands with pale rims, and the orange band
    const bands = [[[238, 160], [262, 156], [270, 300], [276, 470], [256, 480], [246, 300]], [[280, 156], [298, 154], [306, 300], [300, 452], [286, 440], [284, 300]],
      [[394, 154], [424, 156], [430, 300], [428, 420], [404, 440], [398, 300]], [[436, 160], [462, 170], [470, 300], [456, 400], [440, 400], [438, 300]]];
    for (const b of bands) {
      const p = P(b);
      glow(p, '#f4e4cc', 3, 6);
      F(p, '#5a5a78');
      C(p, () => { for (let i = 0; i < 260; i++) F(circleP(230 + rr() * 250, 150 + rr() * 340, 0.9), 'rgba(20,20,40,0.6)'); });
    }
    const orange = P([[304, 156], [392, 154], [400, 300], [388, 420], [372, 440], [350, 438], [330, 300]]);
    glow(orange, '#f8e0c0', 3, 6);
    F(orange, '#f98a1c');
    C(orange, () => { for (let y = 160; y < 440; y += 7) K(P([[300, y], [410, y - 3]], false), 'rgba(255,200,140,0.6)', 1.2); });
    // white sparkles
    for (let i = 0; i < 22; i++) F(circleP(200 + rr() * 280, 180 + rr() * 300, 1.2 + rr() * 1.8), '#f4f8ff');

    // ── hair ──
    const HY = '#f6d850';
    const hairShapes = [
      P([[0, 326], [18, 296], [38, 258], [74, 226], [128, 206], [172, 192], [210, 164], [242, 132], [274, 104], [304, 108], [280, 150], [248, 188], [208, 216],
        [154, 236], [108, 250], [84, 276], [76, 320], [78, 370], [82, 430], [86, 484], [50, 486], [40, 430], [34, 370], [30, 340], [10, 356]]),
      P([[0, 292], [16, 284], [30, 296], [22, 310], [8, 306]]), P([[0, 356], [24, 340], [40, 330], [30, 352], [8, 366]]),
      P([[90, 236], [140, 216], [190, 204], [170, 222], [120, 234]])];
    for (const hp of hairShapes) { glow(hp, '#fff4b0', 2, 8); F(hp, HY); }
    C(hairShapes[0], () => { for (let k = 0; k < 6; k++) K(P([[0, 320 + k * 3], [60, 250 + k * 2], [140, 214 + k * 2], [230, 160 + k * 2], [290, 112 + k]], false), 'rgba(200,150,40,0.35)', 1.2); });
    for (const [x0, y0, x1, y1] of [[280, 150, 270, 108], [300, 150, 310, 104], [320, 152, 330, 110], [340, 150, 360, 108], [360, 150, 350, 104], [380, 150, 400, 110],
      [400, 150, 420, 116], [420, 156, 450, 120], [440, 160, 462, 136], [290, 152, 256, 128]]) {
      o.fillStyle = HY; o.beginPath(); o.moveTo(x0 - 8, y0); o.quadraticCurveTo((x0 + x1) / 2, y0 - 10, x1, y1); o.lineTo(x0 + 8, y0); o.fill(); }
    { const crown = P([[258, 176], [262, 150], [276, 128], [300, 120], [320, 98], [334, 120], [356, 96], [372, 118], [396, 100], [412, 122], [440, 112], [452, 134],
        [470, 140], [466, 166], [440, 158], [410, 152], [380, 160], [350, 150], [320, 162], [290, 158]]);
      glow(crown, '#fff4b0', 2, 8); F(crown, HY);
      for (let k = 0; k < 9; k++) K(P([[280 + k * 20, 168], [286 + k * 20, 140], [296 + k * 19, 118]], false), 'rgba(210,160,40,0.5)', 1.2); }

    // ── eyes, brow ──
    o.save(); o.lineCap = 'round'; o.strokeStyle = '#0a0a0a'; o.lineWidth = 10; o.beginPath(); o.moveTo(78, 412); o.quadraticCurveTo(140, 370, 202, 392); o.stroke(); o.restore();
    for (const [x, y, w, h, ir] of [[160, 467, 66, 30, 22], [530, 346, 58, 26, 19]]) {
      const eye = P([[x - w, y + 4], [x - w * 0.5, y - h], [x + w * 0.4, y - h * 1.05], [x + w, y], [x + w * 0.4, y + h * 0.9], [x - w * 0.4, y + h * 0.9]]);
      F(eye, '#f4d47a'); K(eye, '#1a1410', 3);
      C(eye, () => { F(circleP(x, y, ir + 2), '#0a3a3a'); F(circleP(x, y, ir), '#1ea8a0'); F(circleP(x, y, ir * 0.6), '#127a7a'); F(circleP(x, y, ir * 0.38), '#050505'); F(circleP(x + 5, y - 5, ir * 0.18), '#ffffff'); });
      for (let i = 0; i < 18; i++) { const t = i / 17, px = x - w * 0.85 + t * w * 1.7, py = y - h * (1 - Math.pow(2 * t - 1, 2)) * 0.95 - 2;
        K(P([[px, py], [px + (t - 0.5) * 10, py - 12 - 4 * Math.sin(t * 3.14)]], false), '#141414', 1.6); }
      for (let i = 0; i < 12; i++) { const t = i / 11, px = x - w * 0.6 + t * w * 1.2, py = y + h * 0.9 * (1 - Math.pow(2 * t - 1, 2)) * 0.9 + 2;
        K(P([[px, py], [px + (t - 0.5) * 6, py + 8]], false), '#141414', 1.2); }
    }

    // ── nose, lips, blush, ear ──
    K(P([[262, 480], [250, 540], [240, 590], [246, 610], [262, 612], [276, 604], [292, 612], [304, 604], [302, 588], [292, 570]], false), '#e89040', 2.5);
    soft(14, () => F(ellipseP(135, 590, 38, 46, 0), 'rgba(248,150,90,0.85)'));
    const lips = P([[228, 684], [250, 664], [276, 660], [300, 664], [324, 680], [300, 700], [272, 708], [248, 700]]);
    F(lips, '#c8d8e0'); K(lips, '#e88a50', 2); K(P([[228, 684], [276, 682], [324, 680]], false), '#e88a50', 1.6);
    F(circleP(228, 686, 3), '#141414'); F(circleP(326, 680, 3), '#141414');
    const ear = P([[78, 470], [50, 470], [30, 490], [26, 530], [40, 580], [60, 620], [92, 628]]);
    F(ear, '#a4c4dc'); glow(ear, '#f4dcc0', 3, 8);
    K(P([[56, 500], [44, 530], [54, 570], [70, 600]], false), '#e09060', 2);

    // ── coral spilling from the cheek ──
    const coral = P([[360, 560], [400, 540], [450, 520], [470, 600], [500, 680], [540, 740], [580, 790], [590, 850], [560, 880], [530, 910], [490, 920], [460, 900],
      [430, 880], [420, 840], [400, 790], [380, 740], [366, 700], [372, 640]]);
    glow(coral, '#80e0ff', 6, 16);
    { const g = o.createLinearGradient(0, 540, 0, 920); g.addColorStop(0, '#8cc0e8'); g.addColorStop(0.45, '#48b4f0'); g.addColorStop(1, '#6cd0f8'); F(coral, g); }
    C(coral, () => {
      for (let i = 0; i < 70; i++) { const x = 370 + rr() * 200, y = 560 + rr() * 260; F(P(blob(x, y, 4 + rr() * 9, 3 + rr() * 7, 900 + i, 8, 0.4)), rr() < 0.6 ? '#2c74c8' : '#4a90d8'); }
      for (let i = 0; i < 16; i++) { const t = i / 15, x = 410 + t * 170, y = 820 + Math.sin(t * 3.1) * 50;
        o.save(); o.translate(x, y); o.rotate(1.9 - t * 0.9); F(rrect(-6, -26, 12, 52, 6), '#a8e8ff'); K(rrect(-6, -26, 12, 52, 6), '#2a80d0', 1.5); o.restore(); }
    });
    // ── dots and spirals ──
    F(circleP(433, 353, 20), '#050505'); glow(circleP(433, 353, 20), '#f0e0c0', 2, 6);
    F(circleP(320, 530, 18), '#e8a040'); F(circleP(320, 530, 14), '#050505');
    F(circleP(372, 585, 20), '#050505'); glow(circleP(372, 585, 20), '#f0e0c0', 2, 6);
    for (const [x, y, R0] of [[380, 497, 54], [208, 757, 42]]) {
      F(circleP(x, y, R0 + 2), '#dcd8d4'); spiral(x, y, R0, 7, 3, '#1a1616');
    }
    E.grain(0.035, 45);
  }
});
