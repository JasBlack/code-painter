'use strict';
// s39 — "Glowing idol tray": a pale-blue plastic platter with a yellow rubber rim, a gold face
// tile, a black glossy orb, carved grey brains, a red speckled pill in a warm glow, grey pills
// and bead strings; lavender frosting swirls, violet rectangles, a terracotta slab, a cream U.
REC.register('s39', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, r = rng(39);
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const FLAT = 0, PLAS = 1, GOLD = 2, CREAM = 3, CLAY = 4, ORB = 5, SOFT = 6;

    // ── background: black + dark teal speckle + green floor ──
    const speck = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.012), s = hash(floor(p * 0.5)), m = smoothstep(0.45, 0.62, n);
      vec3 c = mix(vec3(.03,.03,.04), vec3(.2,.3,.28) * (0.7 + 0.6 * s), m * 0.9); return c; }`));
    const tealSp = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = hash(floor(p * 0.55)), n = fbm(p * 0.03); return vec3(.26,.38,.38) * (0.75 + 0.35 * n) * (0.8 + 0.35 * s); }`));
    R.flat(rrect(-5, -5, 1034, 1034, 0), speck, 0, FLAT);
    R.flat(rrect(0, 848, 1024, 180, 0), '#19a866', 0.01, FLAT);
    R.flat(rrect(0, 0, 60, 1024, 0), speck, 0.01, FLAT);
    R.flat(P([[0, 848], [60, 848], [60, 1024], [0, 1024]]), '#19a866', 0.01, FLAT);

    // ── violet rectangles + grey card with tan star ──
    const VIO = '#6d18e2';
    R.flat(rrect(350, 42, 350, 165, 0), VIO, 0.02, FLAT);
    R.flat(P([[696, 32], [956, 26], [962, 272], [700, 276]], true, false), '#a8b7ba', 0.05, SOFT);
    R.dome(P(star(830, 148, 100, 30, 6, -0.3)), '#e4b878', 0.1, 0.05, 6, SOFT);

    // ── terracotta slab (right) + bottom notch ──
    const terra = P([[740, 300], [790, 280], [900, 282], [918, 330], [920, 520], [930, 760], [920, 1030], [800, 1030], [812, 900], [820, 760], [790, 620], [760, 470], [744, 380]], true, false);
    R.flat(terra, '#c95d32', 0.05, SOFT);
    for (const [x, y, rx, ry] of [[918, 560, 18, 26], [905, 795, 14, 14], [945, 858, 22, 26], [880, 730, 6, 8]]) R.flat(ellipseP(x, y, rx, ry, 0.3), '#f8e8d0', 0.06, SOFT);

    // ── platter ──
    const plate = circleP(470, 660, 408);
    R.dome(plate, lg(150, 500, 700, 950, [[0, '#a8cce4'], [0.35, '#86aabb'], [1, '#5e8a98']]), 0.04, 0.12, 40, PLAS);
    clipA(plate, () => {
      // dark teal speckled well in the upper half
      a.fillStyle = tealSp; a.fill(P([[300, 200], [760, 200], [770, 440], [700, 440], [600, 430], [470, 440], [300, 430]]));
      a.fillStyle = tealSp; a.fill(P([[430, 800], [620, 780], [800, 800], [820, 900], [700, 960], [480, 950]]));
      soft(x => { fillE(x, 560, 860, 240, 110, 0, '#4a7280'); fillE(x, 230, 700, 110, 210, 0, '#c0e0f6'); fillE(x, 400, 800, 120, 60, 0, '#b0d4ec'); }, 40, 0.8);
    });
    for (const [x, y, w, h] of [[0, 440, 160, 130], [0, 598, 165, 157], [915, 255, 110, 205], [925, 500, 100, 245]]) R.flat(rrect(x, y, w, h, 0), VIO, 0.12, FLAT);
    // yellow rubber rim (left arc + bottom)
    const rimArc = new Path2D(); rimArc.arc(470, 660, 395, 2.2, 3.55);
    R.pipe(rimArc, 40, '#18a038', 0.15, 0.1, PLAS);
    R.pipe(rimArc, 28, '#f0d428', 0.2, 0.14, PLAS);
    R.flat(P([[360, 950], [560, 950], [560, 1030], [360, 1030]], true, false), '#c95d32', 0.2, SOFT);
    R.flat(rrect(470, 965, 70, 60, 0), '#060606', 0.22, FLAT);
    R.pipe(P([[566, 972], [650, 956], [728, 940]], false), 40, '#f0d428', 0.2, 0.16, PLAS);

    // ── lavender frosting swirls ──
    R.dome(P([[30, 560], [40, 470], [80, 380], [150, 300], [220, 220], [290, 150], [330, 90], [370, 30], [430, 50], [425, 150], [385, 205], [310, 262], [285, 330], [235, 420], [165, 500], [100, 560]]), '#b8cae8', 0.15, 0.2, 60, CREAM);
    const cream = (cl, w0, w1, col) => R.dome(P(lock(cl, w0, w1)), col, 0.2, 0.3, Math.max(w0, w1) * 0.5, CREAM);
    cream([[60, 540], [120, 470], [210, 400], [290, 330], [340, 240], [380, 160], [410, 80], [420, 10]], 110, 40, '#c4d4f0');
    cream([[40, 470], [120, 400], [200, 340], [260, 270], [300, 200]], 70, 30, '#cddcf4');
    cream([[50, 380], [140, 340], [220, 300], [270, 240]], 60, 24, '#b8cae8');
    cream([[330, 0], [390, 60], [410, 130], [380, 190], [320, 230]], 60, 26, '#d0def6');
    cream([[1030, 80], [980, 130], [960, 190], [990, 250]], 70, 40, '#c8d8f2');
    cream([[620, 0], [700, 30], [760, 10]], 40, 20, '#cddcf4');
    for (let k = 0; k < 4; k++) R.groove(P([[80 + k * 30, 520 - k * 20], [220 + k * 30, 380 - k * 20], [330 + k * 10, 220 - k * 10]], false), 6, '#a8b4d0', 0.46, 0.08, CREAM, 0.5);

    // ── cream U (top-left) ──
    const U = new Path2D(); U.addPath(rrect(84, -60, 316, 200, 50));
    R.dome(U, '#fbf0c2', 0.25, 0.2, 18, CREAM);
    R.pipe(P([[84, 130], [400, 130]], false), 14, '#d8a848', 0.3, 0.06, GOLD);
    R.dome(rrect(150, -60, 185, 140, 30), '#0a0c0e', 0.5, -0.3, 10, FLAT);

    // ── needle ──
    R.pipe(P([[512, 32], [512, 190]], false), 12, '#b8c4cc', 0.4, 0.14, ORB);
    R.pipe(P([[512, 190], [512, 282]], false), 5, '#98a4ac', 0.4, 0.08, ORB);

    // ── grey pills + bead strings ──
    for (const [x, y, w, h] of [[323, 225, 72, 46], [405, 222, 78, 48], [536, 216, 56, 48], [606, 216, 82, 46], [312, 292, 92, 46], [418, 285, 82, 52], [552, 283, 96, 48], [676, 272, 50, 44]])
      R.dome(rrect(x, y, w, h, h / 2), '#98b2c0', 0.3, 0.2, h * 0.45, PLAS);
    R.dome(P(lock([[310, 382], [350, 378], [400, 374]], 16, 10)), '#98b2c0', 0.3, 0.12, 8, PLAS);
    for (let k = 0; k < 22; k++) { const t = k / 21; R.bead(400 + t * 360, 376 - t * 30 + Math.sin(t * 9) * 4, 7 + (k % 3) * 2, '#a2bccc', 0.3, 0.14, PLAS); }
    for (let k = 0; k < 20; k++) { const t = k / 19; R.bead(420 + t * 250, 408 - t * 14, 8 + (k % 2) * 3, '#a2bccc', 0.3, 0.14, PLAS); }
    R.bead(532, 330, 14, '#a2bccc', 0.3, 0.14, PLAS);

    // ── warm glow behind the tile + red pill ──
    soft(x => { x.fillStyle = '#fff8d8'; x.fill(rrect(260, 580, 540, 160, 70)); }, 22, 1);
    soft(x => { x.fillStyle = '#ffffff'; x.fill(rrect(290, 610, 480, 110, 50)); }, 10, 1);

    // ── gold face tile + ears + egg ──
    R.dome(P(lock([[245, 480], [225, 550], [245, 625]], 70, 50)), '#c6ccd4', 0.3, 0.15, 24, CLAY);
    for (let k = 0; k < 6; k++) R.groove(P([[222 + k * 6, 490], [210 + k * 6, 550], [226 + k * 6, 615]], false), 3, '#7a8290', 0.44, 0.06, CLAY, 0.6);
    R.dome(P(lock([[490, 450], [505, 520], [490, 600]], 44, 30)), '#e8c250', 0.3, 0.15, 16, GOLD);
    const tile = rrect(272, 448, 228, 282, 26);
    R.dome(tile, lg(272, 448, 500, 730, [[0, '#f2d460'], [0.5, '#d8b030'], [1, '#a88418']]), 0.3, 0.1, 16, GOLD);
    R.dome(rrect(292, 470, 188, 238, 18), lg(292, 470, 480, 708, [[0, '#dcc250'], [1, '#b89a28']]), 0.36, -0.04, 10, GOLD);
    // face
    R.dome(ellipseP(372, 600, 70, 90, 0), '#d4b43c', 0.36, 0.1, 50, GOLD);
    R.dome(P([[360, 570], [385, 570], [392, 630], [352, 632]]), '#dcbc44', 0.44, 0.08, 12, GOLD);
    for (const [x0, y0, x1, y1] of [[325, 555, 355, 562], [392, 562, 420, 555], [330, 578, 352, 580], [394, 580, 416, 578]]) R.groove(P([[x0, y0], [x1, y1]], false), 5, '#6a5010', 0.48, 0.1, GOLD, 0.7);
    R.groove(P([[345, 660], [372, 664], [400, 660]], false), 7, '#5a4008', 0.48, 0.12, GOLD, 0.8);
    R.dome(P([[320, 470], [350, 436], [400, 428], [440, 450], [440, 490], [420, 520], [400, 510], [380, 530], [360, 510], [340, 525], [322, 500]]), '#eef2f8', 0.46, 0.14, 24, CREAM);
    R.dome(ellipseP(375, 455, 24, 16, 0), '#e8a078', 0.56, 0.06, 10, CREAM);

    // ── black glossy orb ──
    R.bead(575, 505, 98, '#101418', 0.3, 0.35, ORB);
    soft(x => { fillE(x, 588, 478, 44, 28, 0, '#ecf088'); fillE(x, 612, 440, 20, 12, 0, '#f4f090'); fillE(x, 540, 490, 14, 10, 0, '#c8e070'); }, 10, 0.9);
    soft(x => { fillE(x, 590, 482, 14, 10, 0, '#ffffe0'); fillE(x, 610, 440, 8, 6, 0, '#ffffe0'); fillE(x, 585, 440, 6, 5, 0, '#ffffe0'); }, 2, 1);

    // ── carved grey brain + gold leaf (right) ──
    R.dome(P([[660, 400], [720, 386], [760, 420], [772, 480], [768, 560], [740, 600], [690, 610], [650, 580], [630, 500], [636, 430]]), '#b8c0d0', 0.3, 0.2, 40, CLAY);
    for (let k = 0; k < 9; k++) { const pts = [[650 + r() * 40, 420 + k * 20], [690 + r() * 20, 410 + k * 20 + r() * 20], [740 + r() * 20, 425 + k * 20]]; R.groove(P(pts, false), 4, '#707888', 0.5, 0.08, CLAY, 0.6); }
    const leaf = P([[752, 470], [790, 430], [840, 440], [860, 490], [838, 540], [856, 580], [826, 612], [780, 600], [758, 560]]);
    R.dome(leaf, '#e0bc50', 0.3, 0.14, 20, GOLD);
    for (let k = 0; k < 8; k++) R.groove(P([[770, 530], [770 + Math.cos(-1.2 + k * 0.36) * 80, 530 + Math.sin(-1.2 + k * 0.36) * 80]], false), 3, '#8a6a18', 0.44, 0.06, GOLD, 0.6);

    // ── red speckled pill ──
    const pill = rrect(500, 618, 272, 92, 46);
    R.dome(pill, '#e8102c', 0.3, 0.14, 30, PLAS);
    clipA(pill, () => { for (let k = 0; k < 160; k++) { a.fillStyle = r() < 0.8 ? '#f8e040' : '#f8a030'; a.beginPath(); a.arc(505 + r() * 262, 622 + r() * 84, 1 + r() * 2.8, 0, 6.283); a.fill(); } });
    R.bead(616, 632, 11, '#30d8e8', 0.44, 0.06, PLAS); R.bead(661, 660, 9, '#30d8e8', 0.44, 0.06, PLAS);
    R.bead(616, 612, 6, '#30a8f0', 0.44, 0.04, PLAS);

    // ── wavy white line, spheres, bits ──
    const wav = []; for (let k = 0; k <= 40; k++) { const t = k / 40; wav.push([355 + t * 395, 770 - t * 38 + Math.sin(t * 22) * 5]); }
    R.pipe(P(wav, false), 12, '#dce8f4', 0.3, 0.1, CREAM);
    R.bead(796, 816, 62, lg(740, 760, 850, 870, [[0, '#f2f6fc'], [1, '#98acc8']]), 0.2, 0.36, PLAS);
    R.bead(840, 336, 46, lg(800, 290, 880, 380, [[0, '#f0a080'], [1, '#b04828']]), 0.2, 0.3, PLAS);
    for (const [x, y, rr] of [[226, 676, 26], [232, 774, 19], [170, 620, 13], [183, 818, 10], [440, 745, 6], [590, 425, 5], [275, 835, 5]]) R.bead(x, y, rr, '#a8d0e4', 0.2, 0.2, PLAS);
    R.bead(428, 832, 14, '#6a2020', 0.2, 0.2, ORB); R.bead(603, 962, 16, '#50505a', 0.2, 0.2, ORB);
    R.dome(P([[300, 872], [340, 856], [380, 862], [412, 884], [380, 896], [330, 894]]), '#1d6a60', 0.2, 0.12, 14, PLAS);
    for (let k = 0; k < 5; k++) R.groove(P([[320 + k * 16, 866], [330 + k * 16, 894]], false), 3, '#0e3a34', 0.3, 0.05, PLAS, 0.6);
    // black cable loops
    for (const pp of [[[180, 1030], [175, 940], [215, 880], [280, 868], [330, 900], [342, 960], [320, 1030]], [[250, 1030], [220, 960], [240, 900], [300, 880], [330, 930]]])
      R.pipe(P(pp, false), 10, '#16181c', 0.3, 0.1, ORB);
    R.pipe(ellipseP(95, 840, 22, 16, 0), 6, '#c8ccd4', 0.2, 0.06, ORB);
    // small dots on violet / terracotta
    for (const [x, y, rr, c] of [[58, 654, 6, '#e8d8f8'], [940, 958, 7, '#5018d0'], [850, 970, 6, '#e87050'], [998, 535, 5, '#f0e8f0'], [998, 288, 4, '#e0d0a0'], [970, 390, 3, '#f0e0f0']]) R.bead(x, y, rr, c, 0.1, 0.06, PLAS);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, coat: 0.12, ao: 0.6, rim: 0.4 }),                               // 1 plastic
        E.mat({ metal: 0.6, dif: 0.55, spec: 1.0, shin: 36, tint: [1.15, 1.05, 0.75], ao: 0.5, rim: 0.3, emis: 0.08 }), // 2 gold
        E.mat({ dif: 1, spec: 0.4, shin: 20, wrap: 0.3, ao: 0.8, emis: 0.02, rim: 0.2 }),                                // 3 frosting
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.3, ao: 0.8, grain: 0.3 }),                                          // 4 carved clay
        E.mat({ metal: 0.6, dif: 0.5, spec: 1.2, shin: 80, coat: 0.3, ao: 0.4 }),                                       // 5 glossy orb / chrome
        E.mat({ dif: 0.8, emis: 0.25, spec: 0.1, shin: 10, wrap: 0.3, grain: 0.25 })                                    // 6 card / terracotta
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.85, 0.85, 0.85], amb: [0.38, 0.38, 0.42],
      envTop: [1, 1, 1], envHor: [0.5, 0.52, 0.58], envBot: [0.08, 0.08, 0.1], envK: [0.4, 1.2, 0.4, 0],
      rimC: [0.3, 0.3, 0.35], rimD: [-0.3, 0.5, 0.3], r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-6, 8, 0.6, 6]
    });
    // post-light glows: warm halo under the tile + pill, glowing spots in the orb
    const glow = (fn, blur, alpha, op = 'screen') => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x); const o = E.out; o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore(); };
    glow(x => { x.strokeStyle = '#fff4d8'; x.lineWidth = 26; x.stroke(rrect(262, 438, 248, 302, 34)); x.stroke(rrect(492, 610, 288, 108, 54)); x.fillStyle = '#fff0d0'; x.fill(rrect(300, 700, 480, 50, 20)); }, 14, 0.9);
    glow(x => { for (let k = 0; k < 40; k++) { const t = k / 39; x.fillStyle = '#ffffff'; x.beginPath(); x.arc(290 + t * 480, 736 + Math.sin(k) * 3, 4, 0, 6.283); x.fill(); } }, 2, 0.8);
    glow(x => { fillE(x, 590, 482, 26, 18, 0, '#e8f070'); fillE(x, 612, 440, 14, 10, 0, '#f0f080'); fillE(x, 586, 440, 10, 8, 0, '#f0f080'); fillE(x, 545, 490, 10, 8, 0, '#b8e060'); }, 6, 0.9);
    E.bloom(0.15, 12);
    E.grain(0.05, 39);
  }
});
