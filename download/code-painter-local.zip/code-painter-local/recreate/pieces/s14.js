'use strict';
// s14 — "Glass ring in the marble swirl": a clear, glittering resin ring floats over a glossy
// swirl of cream-white, orange, cobalt and black paint; a big white sphere with black and
// orange spots and a small dalmatian bead sit in the dark heart, white droplets all around.
REC.register('s14', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const texIn = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, 1024, 1024); a.restore(); };
    const full = rrect(-10, -10, 1044, 1044, 0);
    const WH = '#e4e2e6', OR = '#f06a10', BL = '#1c44c4';

    // ── mottled swirl base: cobalt / black / orange / navy bands wrapping the centre ──
    const base = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        vec2 d = px - vec2(590.0, 480.0);
        float r = length(d), th = atan(d.y, d.x);
        // swirl-warped coordinates -> big paint blobs
        vec2 q = vec2(cos(th + r * 0.004), sin(th + r * 0.004)) * r * 0.009;
        q += vec2(fbm(px * 0.004), fbm(px * 0.004 + 7.0)) * 1.6;
        float n1 = fbm(q * 1.3 + 2.0), n2 = fbm(q * 2.1 + 9.0), n3 = vnoise(px * 0.03);
        vec3 c = vec3(0.03, 0.03, 0.05);
        c = mix(c, vec3(0.10, 0.25, 0.74), smoothstep(0.46, 0.5, n1));
        c = mix(c, vec3(0.92, 0.40, 0.08), smoothstep(0.60, 0.63, n2));
        c = mix(c, vec3(0.84, 0.84, 0.88), smoothstep(0.58, 0.61, n1));
        c = mix(c, vec3(0.03, 0.03, 0.05), step(0.72, n3) * 0.9);
        c = mix(c, vec3(0.20, 0.10, 0.55), smoothstep(0.64, 0.67, n2) * smoothstep(450.0, 250.0, px.x + px.y * 0.5) * 0.8);
        return c;
      }`);
    R.flat(full, '#101828', 0.05, 1); texIn(full, base);
    // corners: black top-left, navy bottom-right
    soft(x => { fillE(x, 0, 0, 170, 150, 0, '#030303'); fillE(x, 1024, 1024, 170, 190, 0, '#021230'); fillE(x, 1024, 560, 60, 200, 0, '#1a1420'); fillE(x, 940, 60, 110, 70, 0, '#141418'); }, 30, 1);

    // ── big glossy cream-white paint masses ──
    const whites = [
      [[380, -20], [900, -20], [890, 60], [850, 150], [800, 190], [760, 120], [640, 80], [520, 90], [430, 108], [380, 60]],
      [[940, -20], [1044, -20], [1044, 90], [990, 80], [950, 40]],
      [[930, 130], [990, 120], [1044, 140], [1044, 210], [980, 205], [935, 175]],
      [[-20, 300], [30, 290], [60, 320], [50, 370], [-20, 380]],
      [[-20, 640], [90, 628], [160, 660], [190, 730], [200, 820], [250, 900], [230, 980], [150, 1000], [60, 960], [-20, 930]],
      [[300, 838], [380, 818], [460, 848], [470, 900], [400, 925], [320, 905]],
      [[880, 720], [930, 710], [970, 740], [975, 800], [945, 840], [895, 840], [870, 790]],
      [[900, 450], [950, 440], [990, 460], [985, 505], [950, 520], [905, 505]],
      [[560, 120], [640, 105], [730, 120], [780, 170], [730, 205], [640, 215], [580, 190]],
      [[430, 870], [520, 850], [600, 865], [620, 900], [540, 930], [450, 915]]
    ];
    for (const [i, w] of whites.entries()) R.dome(P(w), i === 4 ? '#bcc2d2' : WH, 0.2, 0.22, 40, 2);
    const oranges = [
      [[-20, 240], [40, 250], [90, 290], [100, 350], [60, 390], [-20, 395]],
      [[280, 1044], [320, 1000], [400, 985], [520, 990], [620, 958], [720, 928], [800, 880], [860, 842], [905, 862], [880, 930], [810, 1000], [770, 1044]],
      [[-20, 890], [40, 880], [70, 920], [40, 960], [-20, 965]],
      [[620, 580], [700, 560], [760, 600], [760, 660], [700, 690], [640, 660]],
      [[230, 30], [300, 20], [330, 70], [280, 100], [230, 80]],
      [[900, 580], [960, 570], [1044, 600], [1044, 700], [980, 690], [920, 650]],
      [[960, 860], [1044, 820], [1044, 900], [990, 920]]
    ];
    for (const o of oranges) R.dome(P(o), OR, 0.16, 0.12, 30, 3);
    R.dome(P([[130, 60], [240, 40], [270, 100], [200, 140], [140, 130]]), '#3a2a98', 0.12, 0.06, 20, 3);
    R.dome(P([[120, 180], [210, 160], [260, 200], [230, 270], [170, 300], [120, 260]]), BL, 0.12, 0.08, 30, 3);
    R.dome(P([[780, 170], [850, 200], [900, 280], [880, 330], [820, 290]]), BL, 0.12, 0.08, 30, 3);

    // ── dark heart ──
    const heart = P([[400, 300], [480, 230], [600, 210], [720, 250], [800, 330], [830, 450], [800, 590], [720, 700], [600, 740], [470, 720], [380, 640], [350, 500]]);
    R.dome(heart, '#1c1e40', 0.1, 0.02, 30, 1);
    soft(x => { fillE(x, 600, 480, 150, 140, 0, '#06070c'); }, 50, 0.9, 'source-over', heart);
    { const r = rng(7); a.save(); a.clip(heart); for (let i = 0; i < 120; i++) { const x = 360 + r() * 470, y = 220 + r() * 520, rr = 4 + r() * r() * 28; a.fillStyle = [BL, '#2848c8', OR, '#6a7ad0', '#101c50'][i % 5]; a.fill(circleP(x, y, rr)); } a.restore(); }
    // blobs in the heart
    R.dome(P([[610, 460], [650, 430], [700, 440], [720, 480], [690, 520], [640, 530], [615, 500]]), '#bfe4ee', 0.14, 0.08, 20, 4);
    R.dome(P([[630, 430], [690, 410], [730, 440], [700, 460], [660, 455]]), BL, 0.16, 0.05, 12, 4);
    R.dome(P([[330, 590], [390, 580], [430, 610], [410, 650], [360, 660], [330, 630]]), '#bfe4ee', 0.14, 0.08, 20, 4);
    R.dome(P([[480, 640], [540, 630], [590, 660], [600, 700], [560, 730], [500, 720], [470, 690]]), '#e8eaf0', 0.14, 0.1, 20, 4);
    R.dome(circleP(520, 675, 16), '#1c3cc0', 0.2, 0.04, 8, 4);
    R.pipe(circleP(598, 472, 26), 18, OR, 0.14, 0.08, 3);
    R.pipe(circleP(760, 588, 20), 10, OR, 0.14, 0.06, 3);
    R.bead(545, 460, 10, '#e8e8f0', 0.14, 0.06, 4);
    R.bead(650, 628, 12, '#9ab0e0', 0.14, 0.06, 4);
    R.bead(712, 638, 14, '#2848c8', 0.14, 0.06, 4);
    R.bead(695, 410, 18, '#2a2a2e', 0.14, 0.08, 4);

    // ── clear glittering resin ring (with branching arms) ──
    const ringO = P([[120, 580], [180, 460], [280, 320], [330, 220], [420, 170], [560, 110], [700, 110], [820, 170], [890, 280], [900, 420], [880, 560], [850, 660], [760, 780], [620, 850], [480, 850], [360, 800], [260, 730], [160, 660]]);
    const ringI = P([[250, 590], [300, 470], [360, 350], [440, 260], [560, 200], [680, 200], [790, 270], [830, 380], [830, 520], [790, 640], [700, 740], [600, 790], [480, 790], [380, 740], [300, 670]]);
    const ring = new Path2D(); ring.addPath(ringO); ring.addPath(ringI);
    const glass = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float g = step(0.965, hash(floor(px / 2.0)));
        vec3 c = mix(vec3(0.58, 0.56, 0.74), vec3(0.82, 0.80, 0.92), fbm(px * 0.01));
        c += iri(px.x * 0.002 + px.y * 0.003) * 0.12;
        return mix(c, vec3(1.0), g * 0.8);
      }`);
    a.save(); a.clip(ring, 'evenodd'); a.globalAlpha = 0.5; a.drawImage(glass, 0, 0, 1024, 1024); a.restore();
    R.h.save(); R.h.clip(ring, 'evenodd'); R.h.fillStyle = hc(0.4, 5); R.h.fillRect(0, 0, 1024, 1024); R.h.restore();
    R.pipe(ringO, 22, 'rgba(210,210,240,0.55)', 0.36, 0.08, 5);
    R.pipe(ringI, 18, 'rgba(200,200,236,0.5)', 0.36, 0.08, 5);
    // branching arms into the centre
    for (const t of [[[390, 180], [400, 240], [440, 300], [470, 360], [440, 400]], [[420, 250], [470, 280], [500, 330]], [[230, 600], [300, 560], [360, 500], [420, 490]], [[260, 600], [320, 640], [380, 690]],
      [[470, 520], [520, 560], [560, 540]], [[830, 480], [770, 470], [720, 470]], [[560, 600], [600, 640], [640, 700], [660, 760]], [[470, 740], [520, 700], [560, 720]], [[700, 260], [690, 320], [700, 380]]])
      R.pipe(P(t, false), 26, 'rgba(170,160,210,0.45)', 0.36, 0.1, 5);

    // ── spotted spheres ──
    const sph = (x, y, r, seed, patches) => {
      R.dome(circleP(x, y, r), '#ecebe6', 0.44, r * 0.004, r, 6);
      a.save(); a.clip(circleP(x, y, r));
      for (const [px, py, pr, pc] of patches) { a.fillStyle = pc; a.fill(ellipseP(x + px * r, y + py * r, pr * r, pr * r * 0.8, 0.3)); }
      const q = rng(seed); a.fillStyle = '#0c0c10';
      for (let i = 0; i < 26; i++) { const t = q() * Math.PI * 2, rr = Math.sqrt(q()) * r * 0.95; a.fill(ellipseP(x + Math.cos(t) * rr, y + Math.sin(t) * rr, 3 + q() * r * 0.08, 3 + q() * r * 0.06, q() * 3)); }
      a.restore();
    };
    sph(356, 385, 125, 3, [[-0.25, -0.5, 0.45, '#f8b810'], [0.45, -0.55, 0.35, '#f07010'], [-0.9, 0.0, 0.2, '#f07010'], [-0.05, 0.75, 0.25, '#f07010']]);
    sph(565, 578, 62, 9, [[0.2, 0.7, 0.25, '#f07010']]);
    // white droplets everywhere
    for (const [x, y, r] of [[610, 38, 22], [270, 82, 28], [800, 290, 42], [980, 300, 34], [940, 510, 40], [1010, 590, 26], [990, 890, 30], [900, 1000, 26],
      [320, 790, 20], [450, 800, 26], [790, 800, 30], [42, 490, 20], [12, 440, 12], [150, 150, 12], [980, 30, 40], [590, 400, 14], [880, 900, 22], [770, 480, 12]])
      R.dome(ellipseP(x, y, r, r * 0.8, 0.3), WH, 0.4, 0.14, r * 0.9, 2);
    // white bristles on the left orange
    for (let i = 0; i < 9; i++) R.pipe(P([[80 + i * 3, 250 + i * 14], [120 + (i % 3) * 12, 252 + i * 14]], false), 5, '#f4f0ee', 0.3, 0.03, 2);

    // soft shading
    soft(x => { fillE(x, 610, 470, 200, 200, 0, '#000'); }, 60, 0.35);
    soft(x => { fillE(x, 650, 170, 140, 60, 0, '#ffffff'); }, 40, 0.25);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, emis: 0.2, spec: 0.6, shin: 40, wrap: 0.3, coat: 0.12 }),                 // gloss paint base
        E.mat({ dif: 0.85, emis: 0.15, spec: 0.8, shin: 30, wrap: 0.45, coat: 0.1, rim: 0.3 }),      // cream white
        E.mat({ dif: 0.9, emis: 0.3, spec: 0.7, shin: 40, wrap: 0.3, coat: 0.1 }),                   // orange / blue
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.6, shin: 40, wrap: 0.3, coat: 0.1 }),                   // blobs
        E.mat({ dif: 0.6, emis: 0.3, spec: 1.2, shin: 80, coat: 0.35, iri: 0.25, rim: 0.6 }),        // glass
        E.mat({ dif: 0.9, emis: 0.15, spec: 0.9, shin: 50, wrap: 0.3, coat: 0.12 })                  // spheres
      ],
      light: [-0.35, 0.65, 0.68], lc: [0.85, 0.85, 0.85], amb: [0.22, 0.22, 0.26],
      envTop: [1, 1, 1], envHor: [0.4, 0.4, 0.45], envBot: [0.02, 0.02, 0.04], envK: [0.4, 1.2, 0.4, 0],
      rimC: [0.5, 0.5, 0.6], shadow: [-8, 10, 0.6, 7], r1: 2, r2: 10, k: [0, 0.6, 0.4, 80]
    });
    E.grain(0.03, 14);
  }
});
