'use strict';
// g102 — "Mint clay fingerprint": soft mint clay squiggles, rings and a framed grey panel over a pink slab,
// a fingerprint zebra whorl, a spiral well, a glossy white blob, green neon tubes and speckled concrete.
REC.register('g102', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const ring = (x, y, rx, ry) => { const p = new Path2D(); p.ellipse(x, y, rx, ry, 0, 0, Math.PI * 2); return p; };
    const MINT = '#c6d2d1', MINT2 = '#bccac8';

    // ── speckled concrete ──
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 1);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.022), m = fbm(p * 0.06 + 9.);
      vec3 c = vec3(.44, .44, .42);
      c = mix(c, vec3(.64, .64, .61), smoothstep(0.54, 0.58, n + 0.15 * (m - 0.5)));
      c = mix(c, vec3(.32, .32, .30), smoothstep(0.42, 0.38, n - 0.1 * (m - 0.5)));
      float sp = step(0.988, hash(floor(p / 2.)));
      c *= mix(1.0, 0.72, smoothstep(600., 1000., p.y));
      return mix(c, vec3(.15), sp * 0.8); }`));
    soft(x => { x.fillStyle = '#1a1a18'; x.fill(ellipseP(455, 1000, 60, 100, 0)); x.fill(ellipseP(745, 820, 60, 70, 0)); }, 24, 0.75);

    // ── pink slab ──
    const slab = P([[-10, 300], [40, 315], [80, 360], [150, 362], [205, 330], [232, 285], [244, 200], [262, 168], [302, 160], [330, 230], [340, 520], [335, 1040], [-10, 1040]], true, true);
    R.dome(slab, '#dcc8c9', 0.04, 0.08, 30, 1);
    clipA(slab, () => soft(x => { x.fillStyle = '#d2bcbe'; x.fill(ellipseP(300, 900, 60, 200, 0)); x.fillStyle = '#efe0e0'; x.fill(ellipseP(120, 560, 90, 160, 0)); }, 40, 0.7));
    // spiral well (sunken, with raised rim)
    R.dome(ellipseP(125, 838, 118, 110, 0), '#e2cfd0', 0.1, 0.06, 14, 1);
    R.flat(ellipseP(125, 838, 106, 99, 0), null, 0.06, 5);
    clipA(ellipseP(125, 838, 106, 99, 0), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(122., 840.);
      float r = length(q), an = atan(q.y, q.x);
      float ph = r / 15. + 2. * an / 6.2832;
      float v = abs(fract(ph) - 0.5);
      return mix(vec3(.06), vec3(.93, .92, .92), smoothstep(0.23, 0.27, v)); }`)));

    // ── scalloped plate + gold-rimmed device (left edge) ──
    const scal = []; for (let i = 0; i <= 40; i++) { const t = i / 40, an = -Math.PI / 2 + t * Math.PI; const rr = 1 + 0.06 * Math.cos(i * Math.PI); scal.push([10 + Math.cos(an) * 112 * rr, 500 + Math.sin(an) * 150 * rr]); }
    scal.push([-10, 650], [-10, 350]);
    R.dome(P(scal, true, true), '#ece2df', 0.1, 0.05, 10, 1);
    const dev = rrect(-30, 410, 130, 190, 34);
    R.dome(dev, '#3c3b36', 0.15, 0.05, 8, 7);
    clipA(dev, () => {
      a.fillStyle = '#5a5a54'; a.fill(P([[0, 450], [40, 440], [50, 490], [20, 520], [0, 500]]));
      a.fillStyle = '#151513'; a.fill(P([[10, 470], [45, 455], [35, 500]]));
      a.fillStyle = '#3cc070'; a.fill(rrect(-10, 540, 60, 12, 4)); a.fill(rrect(60, 470, 8, 40, 3));
      a.fillStyle = '#20201e'; a.fill(circleP(65, 545, 14));
    });
    R.pipe(rrect(-28, 412, 126, 186, 32), 11, '#c8a04a', 0.2, 0.08, 4);

    // ── glossy white blob (top left) ──
    const wb = P([[-10, 168], [38, 150], [46, 100], [54, 58], [80, 34], [128, 26], [178, 30], [214, 22], [242, 6], [262, -10], [352, -10], [324, 40], [302, 92], [298, 150], [262, 166], [246, 192], [236, 280], [212, 320], [168, 350], [124, 370], [66, 366], [30, 326], [-10, 312]], true, true);
    R.dome(wb, '#f4f3ef', 0.12, 0.45, 70, 3);
    clipA(wb, () => soft(x => {
      x.fillStyle = '#474343'; x.fill(P([[236, 84], [310, 50], [304, 170], [245, 290], [200, 335], [110, 376], [40, 356], [-10, 320], [-10, 236], [30, 262], [80, 300], [120, 292], [150, 250], [168, 190], [200, 136]], true, true));
      x.fillStyle = '#8a8486'; x.fill(ellipseP(150, 230, 18, 50, 0.3));
    }, 12, 0.95));
    // white disc lobe
    R.dome(P([[50, 140], [52, 70], [80, 36], [140, 30], [185, 50], [190, 110], [150, 150], [90, 160]], true, true), '#f8f7f3', 0.3, 0.12, 30, 3);

    soft(x => { x.lineWidth = 18; x.strokeStyle = '#1e1c1c'; x.stroke(P([[338, -10], [306, 30], [298, 100], [300, 160]], false, true)); }, 8, 0.8);
    // ── mint head (top right) ──
    const head = P([[334, -10], [300, 30], [292, 100], [296, 165], [316, 205], [350, 230], [378, 254], [402, 256], [416, 276], [446, 292], [470, 330], [482, 400], [480, 470], [494, 508], [520, 452], [570, 432], [610, 404], [650, 360], [690, 326], [740, 300], [740, -10]], true, true);
    R.dome(head, MINT, 0.12, 0.16, 26, 2);
    clipA(head, () => { a.fillStyle = lin(300, 0, 726, 200, [[0, '#ccd6d6'], [0.5, '#bac6c6'], [1, '#a2acac']]); a.fill(head); });
    clipA(head, () => soft(x => { x.fillStyle = '#d2dcdc'; x.fill(ellipseP(400, 120, 90, 120, 0)); x.fillStyle = '#b2c2be'; x.fill(ellipseP(600, 380, 140, 50, -0.4));
      x.lineWidth = 34; x.strokeStyle = '#6e8274'; x.stroke(P([[470, 344], [520, 342], [570, 334], [606, 318], [636, 302], [672, 302], [704, 288], [740, 274]], false, true)); }, 14, 0.8));
    // spiral record
    R.dome(circleP(575, 65, 90), MINT, 0.28, 0.05, 8, 2);
    R.flat(circleP(575, 65, 78), null, 0.26, 5);
    clipA(circleP(575, 65, 78), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float r = length(p - vec2(574., 64.));
      float v = abs(fract(r / 10.5) - 0.5);
      vec3 c = mix(vec3(.08), vec3(.92, .93, .93), smoothstep(0.2, 0.26, v));
      return mix(vec3(.04), c, smoothstep(26., 28., r)); }`)));
    for (const [x, y, r] of [[420, 64, 13], [423, 107, 13], [460, 134, 14], [415, 165, 13]]) R.dome(circleP(x, y, r), '#d4dddd', 0.28, 0.08, 4, 2);
    R.dome(rrect(453, 184, 146, 46, 14), '#d6dfdf', 0.28, 0.06, 6, 2);
    R.flat(rrect(466, 195, 120, 24, 8), '#8e9696', 0.26, 2);
    R.dome(rrect(472, 199, 108, 14, 6), '#e4eaea', 0.3, 0.05, 4, 2);
    // top-right frame bits
    R.pipe(P([[740, 18], [704, 20], [694, 50], [696, 92], [740, 100]], false, true), 14, '#d8e0e0', 0.28, 0.1, 2);
    R.pipe(P([[740, 122], [708, 124], [700, 150], [706, 172], [740, 178]], false, true), 14, '#d8e0e0', 0.28, 0.1, 2);

    // ── fingerprint zebra field ──
    const zf = P([[250, 212], [300, 214], [330, 240], [378, 262], [412, 280], [446, 300], [470, 340], [480, 400], [472, 470], [440, 520], [410, 560], [400, 640], [420, 700], [450, 760], [430, 822], [380, 846], [300, 840], [250, 800], [240, 700], [230, 560], [215, 450], [210, 380], [222, 320], [244, 280]], true, true);
    R.dome(zf, '#e0e6e6', 0.1, 0.05, 6, 5);
    clipA(zf, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(338., 392.);
      q += 16. * vec2(fbm(p * 0.011), fbm(p * 0.011 + 5.)) - 8.;
      float r = length(q * vec2(1.0, 0.92)), an = atan(q.y, q.x);
      float ph = r / 14. + an / 6.2832;
      float top = smoothstep(330., 250., p.y) * smoothstep(40., 90., r);
      ph = mix(ph, (p.x - 280.) / 16. + 0.0015 * (p.x - 280.) * (p.y - 200.), top * 0.85);
      float v = abs(fract(ph) - 0.5);
      return mix(vec3(.05), vec3(.94, .95, .95), smoothstep(0.235, 0.27, v)); }`)));
    // dark pocket behind the frame
    R.flat(P([[398, 540], [470, 500], [560, 515], [585, 640], [570, 712], [520, 716], [470, 730], [425, 700], [398, 640]], true, true), '#2a2a2c', 0.1, 1);

    // ── green neon tubes + molecule ──
    R.pipe(P([[465, 322], [515, 320], [565, 312], [600, 296], [632, 280], [668, 280], [700, 266], [740, 252]], false, true), 22, '#b4e2ac', 0.3, 0.12, 6);
    R.pipe(P([[490, 512], [490, 468], [515, 450], [552, 440], [582, 420], [615, 382], [650, 346], [690, 320], [740, 290]], false, true), 22, '#b0e0a8', 0.3, 0.12, 6);
    for (const pts of [[[460, 440], [510, 398]], [[460, 440], [430, 420]], [[485, 420], [478, 380], [470, 350]]]) R.pipe(P(pts, false, true), 10, '#d0dada', 0.3, 0.06, 2);
    R.bead(510, 397, 21, '#d4dede', 0.32, 0.2, 2); R.bead(460, 440, 16, '#d4dede', 0.32, 0.16, 2);
    R.dome(circleP(605, 432, 11), '#d8dfe2', 0.06, 0.1, 4, 2);
    R.bead(645, 582, 8, '#151518', 0.06, 0.1, 7); R.bead(626, 850, 10, '#151518', 0.06, 0.1, 7);

    // ── right zigzag frame + ring ──
    R.pipe(P([[740, 418], [684, 440], [674, 468], [700, 508], [662, 518], [650, 545], [664, 584], [702, 632], [740, 664]], false, true), 22, MINT, 0.12, 0.2, 2);
    R.pipe(ring(782, 812, 100, 112), 62, MINT2, 0.12, 0.34, 2);

    // ── squiggle clay ──
    const tube = (pts, wd, dh = 0.34) => R.pipe(P(pts, false, true), wd, MINT, 0.14, dh, 2);
    R.dome(P(blob(195, 420, 52, 50, 31, 10, 0.12), true, true), MINT, 0.14, 0.34, 34, 2);
    tube([[180, 400], [196, 440], [210, 480], [215, 515], [212, 560], [205, 590]], 72);
    tube([[212, 486], [262, 494], [312, 504], [346, 532], [342, 572], [320, 600], [334, 632], [362, 660], [384, 682]], 68);
    tube([[240, 640], [272, 616], [306, 600]], 54);
    R.pipe(ring(190, 655, 48, 54), 58, MINT, 0.14, 0.34, 2);
    tube([[372, 650], [326, 682], [294, 722], [290, 772], [318, 808], [370, 822], [420, 808], [456, 782]], 66);
    // studs on the squiggle
    R.dome(circleP(270, 560, 11), '#cfd4d6', 0.5, 0.06, 3, 2); R.dome(circleP(374, 622, 12), '#cfd4d6', 0.5, 0.06, 3, 2);
    R.bead(384, 675, 20, MINT, 0.48, 0.16, 2); R.bead(400, 463, 17, MINT, 0.18, 0.18, 2); R.bead(390, 500, 11, MINT, 0.18, 0.12, 2);

    // ── framed grey panel + stick ──
    const fr = P([[412, 515], [492, 508], [520, 498], [548, 506], [612, 478], [620, 640], [452, 670]], true, false);
    R.pipe(P([[520, 650], [534, 700], [536, 760]], false, true), 24, MINT, 0.2, 0.16, 2);
    R.flat(fr, '#a2a6a8', 0.3, 1);
    R.pipe(fr, 18, '#e6e6ea', 0.3, 0.12, 3);
    // knob ring + ball ring
    R.pipe(ring(462, 775, 32, 32), 26, MINT, 0.3, 0.2, 2); R.bead(462, 776, 15, '#7c8080', 0.3, 0.12, 2);
    R.pipe(P([[490, 750], [520, 712], [552, 700], [570, 730], [560, 760]], false, true), 20, MINT, 0.26, 0.16, 2);
    R.pipe(ring(533, 830, 40, 40), 28, MINT, 0.3, 0.2, 2); R.bead(533, 830, 30, '#ece4e4', 0.35, 0.22, 3);
    // big bottom ring
    R.pipe(ring(444, 990, 100, 140), 70, MINT, 0.14, 0.4, 2);

    // ── white beads on the pink ──
    for (const [x, y, r] of [[130, 470, 25], [90, 648, 22], [40, 725, 22], [30, 960, 21], [190, 955, 25], [275, 900, 22], [272, 975, 21], [90, 1016, 22], [200, 1024, 18], [5, 545, 10], [700, 1012, 36]])
      R.bead(x, y, r, x > 600 ? '#e8e0d0' : '#eceaea', 0.08, 0.26, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.45, ao: 0.6 }),                       // 1 concrete / pink
        E.mat({ dif: 1, spec: 0.3, shin: 26, wrap: 0.5, ao: 0.5, coat: 0.04 }),             // 2 mint clay
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.4, ao: 0.3, coat: 0.25 }),             // 3 glossy white
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.0, shin: 50, ao: 0.4, tint: [1.1, 0.95, 0.6] }), // 4 gold
        E.mat({ dif: 0.95, spec: 0.25, shin: 30, wrap: 0.6, emis: 0.08 }),                  // 5 zebra
        E.mat({ dif: 1, spec: 0.45, shin: 40, wrap: 0.3, emis: 0.1, ao: 0.4 }),             // 6 green neon
        E.mat({ dif: 1, spec: 0.8, shin: 60, coat: 0.2 })                                   // 7 dark gloss
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.72, 0.72, 0.72], amb: [0.42, 0.42, 0.43],
      envTop: [1, 1, 1], envHor: [0.6, 0.62, 0.62], envBot: [0.12, 0.12, 0.12], envK: [0.15, 0.7, 0.3, 0],
      r1: 2, r2: 12, k: [0, 0.6, 0.4, 60], shadow: [-10, 12, 0.85, 6]
    });
    E.grain(0.03, 102);
  }
});
