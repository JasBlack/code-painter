'use strict';
// g080 — "Tongue in the pink gallery": a giant maroon tongue scribbled with white squiggles, capped by a black ribbed
// hose, lolls through a pink-and-red gallery of framed pictures, zebra cushions, blue tubes and harlequin mannequins.
REC.register('g080', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const Q = (pts) => P(pts, true, false);

    // ── textures ──
    const WAVE = (A, k1, k2, ph, per, off, wf, A2, k3, ph2, sl, white, black) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x + ${sl} * p.y + ${A} * sin(p.y * ${k1} + p.x * ${k2} + ${ph}) + ${A2} * sin(p.y * ${k3} + ${ph2});
      float f = fract(x / ${per} + ${off});
      float w = smoothstep(${wf} - 0.03, ${wf} + 0.01, f) * smoothstep(1.0, 0.97, f);
      return mix(vec3(${black}), vec3(${white}), w); }`));
    const zWall = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(100., 170.); float th = -0.0022;
      float u = d.x * cos(th) + d.y * sin(th), v = -d.x * sin(th) + d.y * cos(th);
      float s = u - 0.7636e-3 * v * v + 1.89315e-3 * u * v - 6.594 * sin(v * 0.03136 - 2.0667);
      float f = fract(s / 32.137 + 0.422);
      float w = smoothstep(0.48, 0.52, f) * smoothstep(1.0, 0.97, f);
      return mix(vec3(.02), vec3(.99,.97,.92), w); }`));
    const zCush = WAVE(12.41, 0.0202, -0.0181, 0.794, 36.45, 0.9214, 0.6182, 0.321, 0.0849, -1.862, -0.148, '.99,.98,.93', '.02,.02,.03');
    // bottom cushion: ")"-shaped bands that crowd together to the right (perspective)
    const zBot = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float c = 4e-5 * max(p.x - 150., 0.), dy = p.y - 960.;
      float xp = p.x + c * dy * dy;
      float ph = (6.23 - log(max(720. - xp, 1.))) / 0.39;
      float f = fract(ph + 0.5);
      float b = smoothstep(0.26, 0.30, f) * smoothstep(0.76, 0.72, f);
      return mix(vec3(.99,.98,.93), vec3(.02,.02,.03), b); }`));
    const stars = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec3 c = vec3(.01);
      vec2 g = floor(p / 34.); vec2 f = fract(p / 34.) - .5; float h = hash(g);
      vec2 o = (vec2(hash(g + 3.), hash(g + 7.)) - .5) * 0.5;
      float an = hash(g + 11.) * 3.14; vec2 q = mat2(cos(an), -sin(an), sin(an), cos(an)) * (f - o);
      float sq = step(max(abs(q.x), abs(q.y)), 0.1 + 0.08 * hash(g + 13.));
      vec3 col = h < .3 ? vec3(1.,.95,.3) : h < .5 ? vec3(.5,.8,1.) : h < .7 ? vec3(1.,.4,.7) : h < .8 ? vec3(.6,.4,.9) : vec3(.9);
      c = mix(c, col, sq * step(0.35, hash(g + 17.)));
      return c; }`));
    const redFloor = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ return vec3(.96,.06,.13) * (0.92 + 0.12 * vnoise(vec2(p.x * 0.4, p.y * 0.02))); }`));

    // ── ceiling, black starfield panel ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#f8a4d8', 0, 0);
    const PANEL = Q([[165, -10], [690, -10], [600, 30], [480, 88], [400, 128], [300, 176], [240, 110], [190, 50]]);
    F(Q([[150, -10], [710, -10], [610, 38], [485, 98], [405, 140], [300, 192], [228, 115], [175, 50]]), '#ee5ea8');
    F(PANEL, stars);
    clipA(Q([[150, -10], [710, -10], [610, 38], [485, 98], [405, 140], [300, 192], [228, 115], [175, 50]]), () => {
      for (let i = 0; i < 60; i++) { const t = i / 60; K(P([[170 + t * 130, 10 + t * 170], [178 + t * 130, 8 + t * 170]], false), '#c03a80', 2); K(P([[300 + t * 400, 186 - t * 190], [304 + t * 400, 194 - t * 190]], false), '#c03a80', 2); }
    });
    R.bead(470, 15, 11, '#f0207a', 0.06, 0.08, 2);
    K(P([[400, 70], [470, 45]], false), '#8a6a6a', 3); R.bead(424, 62, 8, '#7a5050', 0.05, 0.04, 3);
    K(P([[455, 60], [490, 52]], false), '#f8f040', 3);

    // ── walls ──
    const ZWALL = Q([[-10, -10], [22, -10], [204, 166], [204, 348], [-10, 332]]);
    F(ZWALL, zWall);
    F(Q([[-10, 332], [204, 348], [204, 640], [-10, 650]]), '#f8dce4');
    F(Q([[200, 162], [246, 200], [246, 350], [200, 348]]), lin(200, 160, 246, 350, [[0, '#1838a8'], [0.4, '#2a58c8'], [0.7, '#c87a6a'], [1, '#8a5040']]));
    soft(x => { x.strokeStyle = '#40c0e8'; x.lineWidth = 6; x.stroke(P([[208, 240], [222, 210], [238, 230], [230, 262], [214, 270]], false)); x.fillStyle = '#f0b0c0'; x.fill(ellipseP(232, 228, 7, 14, 0)); }, 1, 1);
    F(Q([[244, 198], [340, 244], [340, 444], [244, 446]]), '#fcf80e');
    F(Q([[340, 244], [452, 250], [452, 420], [340, 424]]), lin(340, 250, 452, 420, [[0, '#0646b8'], [1, '#1858d0']]));
    soft(x => { x.fillStyle = '#ff90d0'; x.fill(circleP(410, 282, 18)); x.fill(ellipseP(360, 390, 28, 18, 0)); x.strokeStyle = '#f8f8ff'; x.lineWidth = 7; x.stroke(P([[340, 340], [400, 300]], false)); x.stroke(P([[400, 300], [380, 360]], false)); }, 2, 1);
    { const q = rng(80); for (let i = 0; i < 10; i++) F(rrect(345 + q() * 100, 255 + q() * 150, 5, 5, 0), ['#f02060', '#f8f040', '#40f0f0'][i % 3]); }
    // pink ceiling apex wedge
    F(Q([[204, 166], [228, 115], [300, 192], [405, 140], [452, 120], [452, 250], [340, 244], [246, 200]]), '#fcaee0');
    // red wall + right pink wall section
    F(Q([[590, 100], [736, 72], [736, 1034], [590, 1034]]), redFloor);
    F(Q([[470, 360], [600, 380], [640, 380], [660, 360], [660, 720], [600, 720], [470, 720]]), '#f8d4dc');
    // floor (pale pink) + red floor bits
    F(Q([[150, 600], [470, 560], [600, 720], [590, 1034], [-10, 1034], [-10, 650]]), '#fbe6e6');
    F(Q([[590, 700], [736, 690], [736, 1034], [590, 1034]]), redFloor);
    F(Q([[-10, 760], [150, 740], [130, 1034], [-10, 1034]]), redFloor);
    keep();

    // ── framed pictures ──
    const frame = (x, y, w, h, inner) => {
      R.dome(rrect(x, y, w, h, 2), lin(x, y, x + w, y + h, [[0, '#8a6038'], [0.5, '#5a3a20'], [1, '#3a2410']]), 0.04, 0.04, 5, 3);
      const p = rrect(x + 6, y + 6, w - 12, h - 12, 0); R.flat(p, inner[0], 0.06, 0);
      clipA(p, () => inner.slice(1).forEach(f => f(x + 6, y + 6, w - 12, h - 12)));
    };
    const fig = (c) => (x, y, w, h) => { F(ellipseP(x + w * 0.5, y + h * 0.55, w * 0.18, h * 0.38, 0), c); F(circleP(x + w * 0.5, y + h * 0.18, w * 0.12), c); };
    const ground = (c) => (x, y, w, h) => F(rrect(x, y + h * 0.7, w, h * 0.3, 0), c);
    frame(-10, 345, 95, 150, ['#3a62c0', ground('#5a3a30'), fig('#f0c090')]);
    frame(-10, 505, 40, 120, ['#a8a8b8', fig('#405080')]);
    frame(32, 497, 54, 100, ['#2a5ab8', fig('#e0a070')]);
    frame(102, 350, 55, 88, ['#f0c0c8', fig('#405080')]);
    frame(162, 358, 32, 128, ['#4a7ad0', fig('#e09070')]);
    frame(100, 444, 55, 84, ['#f0e020', fig('#203050')]);
    frame(146, 262, 30, 86, ['#f0c070', fig('#6080a0')]);
    frame(200, 352, 40, 96, ['#202028', fig('#e08040')]);
    frame(536, 458, 104, 98, ['#3a4ab0', (x, y, w, h) => { F(rrect(x + 20, y + 30, 18, 50, 4), '#f0e0c0'); F(rrect(x + 50, y + 30, 18, 50, 4), '#e0a080'); }]);
    frame(538, 563, 103, 130, ['#4a5a8a', fig('#e0a070')]);
    frame(578, 380, 60, 70, ['#2a2a40', fig('#a06040')]);
    // vitrines with tiny figures
    F(Q([[95, 555], [250, 505], [255, 520], [100, 580]]), 'rgba(220,240,255,0.7)');
    K(Q([[95, 555], [250, 505], [255, 520], [100, 580]]), '#f8f8f8', 2);
    F(Q([[100, 580], [255, 520], [255, 540], [100, 600]]), '#f4a0c8');
    for (const [x, y] of [[190, 480], [205, 476], [220, 472]]) { F(rrect(x - 3, y, 7, 26, 3), '#202030'); F(circleP(x, y - 3, 3.5), '#e8b090'); }
    R.dome(Q([[140, 520], [175, 512], [180, 535], [150, 545]]), '#3a4a7a', 0.06, 0.04, 5, 2);
    F(Q([[240, 445], [345, 440], [345, 470], [240, 480]]), '#fbe6f0');
    K(Q([[240, 445], [345, 440], [345, 470], [240, 480]]), '#f8f8ff', 2);
    keep();

    // ── yellow-wall statue on a red chair ──
    R.pipe(P([[262, 340], [262, 440]], false), 5, '#e02030', 0.06, 0.04, 2); R.pipe(P([[296, 340], [296, 440]], false), 5, '#e02030', 0.06, 0.04, 2);
    R.dome(rrect(255, 385, 50, 14, 4), '#4a8ad8', 0.07, 0.04, 5, 2);
    R.dome(P([[280, 330], [300, 322], [310, 350], [302, 385], [282, 390], [270, 360]]), '#141420', 0.08, 0.08, 8, 2);
    R.pipe(P([[300, 382], [320, 390], [332, 432]], false), 12, '#141420', 0.08, 0.06, 2);
    R.pipe(P([[288, 386], [292, 410], [286, 434]], false), 11, '#141420', 0.08, 0.06, 2);
    R.bead(286, 318, 10, '#f4f0f4', 0.1, 0.06, 2);
    K(P([[296, 340], [318, 300], [270, 250]], false), '#202020', 2);
    R.pipe(P([[300, 335], [312, 310]], false), 6, '#f080c0', 0.08, 0.04, 2);

    // ── zebra cushion (behind the tongue) + pink pedestal ──
    const CUSH = P([[290, 610], [320, 570], [380, 552], [430, 556], [462, 580], [468, 640], [450, 700], [425, 780], [370, 760], [320, 720], [295, 680]]);
    R.dome(CUSH, zCush, 0.06, 0.12, 30, 4);
    const PEDF = Q([[432, 680], [590, 690], [590, 830], [432, 812]]);
    R.flat(Q([[465, 500], [500, 480], [500, 690], [465, 690]]), '#f878c8', 0.04, 0);
    R.flat(PEDF, lin(432, 680, 590, 830, [[0, '#f88ad0'], [1, '#f070c0']]), 0.04, 0);
    R.flat(Q([[465, 595], [500, 590], [600, 590], [600, 700], [432, 690], [440, 650]]), '#fbeef0', 0.05, 0);
    R.flat(Q([[500, 595], [585, 595], [588, 628], [505, 630]]), '#f0f0f8', 0.06, 0);
    F(rrect(508, 600, 70, 24, 0), lin(508, 600, 578, 624, [[0, '#50a0e0'], [0.5, '#a0d0f0'], [1, '#e0a0c0']]));
    R.dome(rrect(472, 628, 52, 34, 3), '#e8d070', 0.08, 0.04, 6, 3); R.dome(circleP(498, 640, 10), '#f0f0e0', 0.12, 0.03, 4, 3);
    R.dome(P(blob(565, 655, 34, 22, 3, 14, 0.15)), '#141414', 0.08, 0.1, 14, 4);
    keep();

    // ── the tongue ──
    const TONGUE = [[120, 640], [132, 608], [170, 585], [230, 562], [272, 536], [302, 508], [332, 474], [370, 412], [408, 340], [438, 285], [462, 240], [500, 206],
      [540, 180], [580, 158], [625, 147], [662, 158], [692, 200], [714, 258], [714, 312], [692, 352], [650, 382], [600, 410], [560, 438], [520, 468], [492, 500], [462, 545],
      [420, 556], [372, 580], [340, 610], [308, 640], [270, 642], [230, 634], [206, 648], [196, 690], [170, 682], [138, 666]];
    const TP = P(TONGUE);
    soft(x => { x.fillStyle = 'rgba(80,20,60,0.5)'; x.translate(-6, 14); x.fill(TP); }, 10, 1);
    R.pipe(TP, 22, '#9ab0e0', 0.08, 0.1, 2);
    R.dome(TP, lin(200, 650, 650, 160, [[0, '#26050a'], [0.5, '#3a0c12'], [1, '#30080e']]), 0.12, 0.2, 60, 5);
    clipA(TP, () => {
      soft(x => { x.fillStyle = 'rgba(150,60,80,0.45)'; x.fill(ellipseP(600, 230, 70, 40, -0.6)); x.fill(ellipseP(270, 600, 60, 18, -0.3)); }, 14, 1);
      const q = rng(8);
      for (let i = 0; i < 230; i++) {
        const t = q(), s = q();
        // sample along the tongue's long axis
        const cx = 160 + t * 520 + (q() - 0.5) * 30, cy = 620 - t * 430 + (s - 0.5) * (80 + t * 160);
        const L = 12 + q() * 12, an = -0.3 + (q() - 0.5) * 0.5, ph = q() * 6.28;
        const pts = []; for (let k = 0; k <= 8; k++) { const u = k / 8, w = 2.2 * Math.sin(u * 9 + ph);
          pts.push([cx + Math.cos(an) * L * u - Math.sin(an) * w, cy + Math.sin(an) * L * u + Math.cos(an) * w]); }
        K(P(pts, false), '#f4f0f0', 1.7);
      }
    });
    // lower lip lobe + chin knob
    R.dome(P([[470, 400], [500, 390], [528, 410], [530, 440], [505, 455], [478, 440]]), '#2a0a10', 0.3, 0.06, 12, 5);
    keep();

    // ── black ribbed hose over the top ──
    const HOSE = [[322, 222], [400, 204], [455, 186], [500, 148], [550, 116], [610, 102], [665, 112], [705, 140], [730, 180]];
    R.pipe(P(HOSE, false), 52, '#0c0c10', 0.2, 0.2, 6);
    { const hp = P(HOSE, false);
      for (let i = 0; i < 26; i++) { const t = i / 25, k = Math.min(HOSE.length - 2, Math.floor(t * (HOSE.length - 1))), u = t * (HOSE.length - 1) - k;
        const A = HOSE[k], B = HOSE[k + 1], x = A[0] + (B[0] - A[0]) * u, y = A[1] + (B[1] - A[1]) * u, dx = B[0] - A[0], dy = B[1] - A[1], L = Math.hypot(dx, dy);
        R.groove(P([[x - dy / L * 24, y + dx / L * 24], [x + dy / L * 24, y - dx / L * 24]], false), 3, '#c8c8d8', 0.38, 0.04, 6, 0.9); }
      void hp; }
    R.pipe(P([[322, 236], [380, 228], [440, 210], [490, 168], [540, 140], [600, 128], [650, 140], [700, 175], [726, 210]], false), 12, '#90a8dc', 0.16, 0.06, 2);
    R.dome(rrect(440, 172, 30, 52, 6), '#a0b4e0', 0.24, 0.06, 6, 2);
    keep();

    // ── star burst ──
    soft(x => { x.fillStyle = '#fff8a0';
      x.fill(Q([[470, 290], [630, 302], [730, 312], [630, 322], [470, 298]])); x.fill(Q([[630, 310], [640, 312], [705, 420], [696, 424]])); }, 1.5, 1);
    F(Q([[592, 228], [624, 300], [636, 312], [585, 360], [628, 318], [655, 236], [636, 306]]), '#ffffff');
    soft(x => { x.fillStyle = 'rgba(255,240,255,0.9)'; x.fill(circleP(630, 312, 30)); }, 10, 0.8);
    R.bead(630, 312, 24, rad(622, 302, 30, [[0, '#ffffff'], [0.6, '#f8c8f4'], [1, '#e8a0e8']]), 0.4, 0.08, 2);
    R.dome(Q([[680, 384], [700, 370], [712, 384], [705, 398], [686, 398]]), '#f0c020', 0.2, 0.04, 4, 2);

    // ── mannequins ──
    const black = '#0c0c14';
    R.dome(P([[-10, 640], [30, 630], [70, 660], [80, 760], [70, 800], [120, 800], [130, 830], [80, 850], [60, 900], [-10, 900]]), black, 0.08, 0.16, 20, 6);
    R.dome(ellipseP(57, 650, 27, 32, 0.2), black, 0.14, 0.12, 14, 6);
    R.dome(P([[0, 672], [24, 668], [40, 700], [44, 740], [30, 770], [0, 780]]), '#f4f4f8', 0.12, 0.06, 8, 2);
    R.dome(P([[0, 700], [16, 696], [20, 730], [0, 740]]), black, 0.14, 0.04, 6, 6);
    R.pipe(P([[30, 760], [70, 790], [100, 800]], false), 22, black, 0.12, 0.1, 6);
    R.pipe(P([[20, 800], [40, 850], [70, 880]], false), 26, black, 0.12, 0.1, 6);
    for (const [x, y] of [[55, 778], [40, 830]]) R.dome(rrect(x - 8, y - 8, 16, 16, 3), '#f4f4f8', 0.2, 0.03, 4, 2);
    F(Q([[38, 648], [72, 634], [80, 650], [62, 656], [58, 672], [48, 660]]), '#f8f8ff');
    F(Q([[30, 612], [36, 590], [48, 604], [58, 588], [68, 604], [80, 590], [82, 618]]), '#f8d020');
    R.dome(P([[684, 452], [704, 436], [726, 436], [726, 720], [700, 720], [690, 640], [668, 640], [662, 560], [674, 480]]), black, 0.08, 0.16, 20, 6);
    R.dome(P([[656, 730], [700, 720], [726, 722], [726, 800], [680, 805], [654, 770]]), black, 0.1, 0.14, 20, 6);
    F(P(star(712, 570, 16, 8, 2, 0.79), true, false), '#f8f8ff'); F(P(star(712, 520, 8, 4, 2, 0.79), true, false), '#f8f8ff');
    R.dome(P([[660, 640], [690, 636], [694, 680], [674, 690], [660, 670]]), '#6a40b0', 0.12, 0.06, 6, 2);
    R.dome(rrect(668, 690, 30, 40, 6), '#f8f8f8', 0.1, 0.04, 6, 2);
    keep();

    // ── bottom: pink tilted frame, painting, zebra cushion ──
    const OUT = Q([[150, 740], [702, 868], [650, 1034], [80, 1034]]);
    soft(x => { x.fillStyle = 'rgba(90,10,30,0.5)'; x.translate(-8, 10); x.fill(OUT); }, 8, 1);
    R.flat(OUT, lin(150, 740, 700, 1000, [[0, '#f8c0d8'], [0.5, '#fbd0e0'], [1, '#f070b0']]), 0.06, 0);
    const INN = Q([[176, 768], [668, 884], [628, 1034], [112, 1034]]);
    R.flat(INN, '#060608', 0.05, 0);
    R.flat(Q([[150, 770], [350, 798], [330, 905], [120, 892]]), lin(150, 770, 330, 900, [[0, '#a07840'], [1, '#6a4a28']]), 0.08, 3);
    F(Q([[160, 780], [340, 806], [322, 896], [130, 884]]), lin(160, 780, 320, 900, [[0, '#3a64c8'], [1, '#2a4a98']]));
    R.flat(Q([[185, 810], [305, 826], [292, 885], [175, 875]]), '#8a6a3a', 0.1, 3);
    F(Q([[193, 818], [298, 832], [288, 879], [183, 869]]), lin(193, 818, 290, 880, [[0, '#b8d070'], [1, '#6a9040']]));
    F(rrect(178, 844, 16, 18, 2), '#f09020');
    R.pipe(P([[220, 870], [235, 845], [250, 830]], false), 10, '#d04030', 0.12, 0.04, 3);
    R.bead(250, 826, 6, '#e8c0a0', 0.12, 0.04, 3);
    const ZC = P([[135, 905], [200, 880], [300, 860], [420, 845], [520, 845], [610, 862], [646, 880], [630, 930], [600, 1034], [120, 1034]]);
    R.dome(ZC, zBot, 0.08, 0.12, 40, 4);
    keep();

    // ── blue tubes ──
    const BLUE = '#5c9cf2';
    const TUBE = [[300, 650], [250, 680], [210, 665], [170, 660], [120, 655], [110, 690], [140, 720], [200, 740], [235, 760], [220, 780], [170, 790], [120, 800], [70, 830],
      [45, 880], [60, 940], [100, 975], [140, 990], [200, 1010], [260, 1040]];
    R.pipe(P([[118, 650], [110, 680], [130, 715], [180, 735], [230, 755]], false), 32, BLUE, 0.1, 0.18, 2);
    R.pipe(P([[240, 765], [200, 780], [150, 790], [100, 810], [60, 845], [40, 890], [50, 940], [90, 975], [150, 995], [210, 1012], [270, 1040]], false), 44, BLUE, 0.1, 0.22, 2);
    void TUBE;
    R.bead(130, 960, 26, BLUE, 0.2, 0.12, 2);
    R.bead(110, 790, 24, BLUE, 0.2, 0.1, 2);
    R.pipe(P([[340, 1034], [400, 1000], [460, 975], [520, 940]], false), 40, BLUE, 0.1, 0.2, 2);
    R.pipe(P([[520, 940], [545, 922]], false), 14, BLUE, 0.2, 0.06, 2);
    // top-left robot arm
    R.pipe(P([[40, 92], [62, 130], [92, 160], [125, 190]], false), 34, BLUE, 0.06, 0.18, 2);
    for (const [x, y] of [[48, 106], [70, 140], [98, 166]]) R.groove(P([[x - 16, y + 10], [x + 16, y - 10]], false), 4, '#4a7ac0', 0.2, 0.06, 2, 0.8);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.4, shin: 30, wrap: 0.6, ao: 0.3, emis: 0.3 }),
        E.mat({ dif: 0.8, spec: 1.3, shin: 70, wrap: 0.4, ao: 0.4, coat: 0.25, emis: 0.3 }),                          // 2 glossy plastic
        E.mat({ dif: 0.8, spec: 0.8, shin: 50, wrap: 0.5, ao: 0.4, emis: 0.3 }),                                      // 3 frames / props
        E.mat({ dif: 0.85, spec: 0.6, shin: 40, wrap: 0.5, ao: 0.4, emis: 0.35 }),                                    // 4 cushions
        E.mat({ dif: 0.8, spec: 1.2, shin: 60, wrap: 0.5, ao: 0.4, coat: 0.2, emis: 0.25 }),                          // 5 tongue
        E.mat({ dif: 0.6, spec: 1.8, shin: 90, wrap: 0.3, ao: 0.3, coat: 0.4, emis: 0.1 })                            // 6 black gloss
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.85, 0.84, 0.86], amb: [0.36, 0.36, 0.38],
      envTop: [1.1, 1.08, 1.1], envHor: [0.7, 0.6, 0.68], envBot: [0.25, 0.15, 0.2], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.1, 0.1, 0.14], rimD: [0, 1, 0], r1: 1.3, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.45, 7]
    });
    E.grain(0.03, 80);
  }
});
