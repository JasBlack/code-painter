'use strict';
// g041 — "Zebra boy and octopus": a grinning black-skinned boy with zebra stripes across his brow and a
// navy cap of hair inside a pink coral-planet bubble, a jellyfish window by his cheek and a pale-blue
// octopus spilling its tentacles over a zebra field, white-outlined on hot orange beside a black strip.
REC.register('g041', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (blur, fn) => { o.save(); o.filter = `blur(${blur * S}px)`; fn(); o.restore(); };
    const cr = (pts, seg = 10) => {
      const out = [], n = pts.length;
      for (let i = 0; i < n - 1; i++) {
        const p0 = pts[Math.max(0, i - 1)], p1 = pts[i], p2 = pts[i + 1], p3 = pts[Math.min(n - 1, i + 2)];
        for (let j = 0; j < seg; j++) {
          const t = j / seg, t2 = t * t, t3 = t2 * t;
          out.push([0, 1].map(k => 0.5 * (2 * p1[k] + (-p0[k] + p2[k]) * t + (2 * p0[k] - 5 * p1[k] + 4 * p2[k] - p3[k]) * t2 + (-p0[k] + 3 * p1[k] - 3 * p2[k] + p3[k]) * t3)));
        }
      }
      out.push(pts[n - 1]); return out;
    };
    // wobbly tapered ribbon (tentacles)
    const rib = (pts, w0, w1, wob = 0.08, seed = 1) => {
      const q = cr(pts, 14), n = q.length, L = [], R = [], r = rng(seed);
      for (let i = 0; i < n; i++) {
        const a = q[Math.max(0, i - 1)], b = q[Math.min(n - 1, i + 1)];
        let dx = b[0] - a[0], dy = b[1] - a[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
        const t = i / (n - 1), w = (w0 + (w1 - w0) * t) / 2;
        const wl = w * (1 + wob * Math.sin(i * 0.8 + seed) + wob * 0.6 * (r() - 0.5)), wr = w * (1 + wob * Math.sin(i * 0.7 + seed * 2.3) + wob * 0.6 * (r() - 0.5));
        L.push([q[i][0] - dy * wl, q[i][1] + dx * wl]); R.push([q[i][0] + dy * wr, q[i][1] - dx * wr]);
      }
      return { path: P([...L, ...R.reverse()], true, false), cl: q };
    };
    const INK = '#030305', NAVY = '#33508c', PINK = '#ef2f78', OBG = '#fb6a4f';

    // ── ground: hot orange gradient + black strip ──
    { const g = o.createLinearGradient(0, 0, 0, 1024);
      g.addColorStop(0, '#fb4309'); g.addColorStop(0.18, '#fb5a2c'); g.addColorStop(0.3, '#fb6a4f'); g.addColorStop(0.5, '#fb6b45');
      g.addColorStop(0.62, '#fb6424'); g.addColorStop(0.78, '#fb5408'); g.addColorStop(1, '#fb4a05');
      o.fillStyle = g; o.fillRect(0, 0, 726, 1024); }
    F(rrect(0, 0, 102, 1024, 0), '#010101');
    // red glow where the shoulder meets the black strip
    soft(16, () => { K(P([[0, 940], [40, 915], [90, 892], [110, 884]], false), '#e8200c', 26); });
    soft(6, () => { K(P([[30, 920], [70, 900], [104, 886]], false), '#ff3a14', 8); });

    // ── the figure silhouette (head, bubble, shoulders, octopus base) ──
    const sil = P([
      [-20, 948], [0, 944], [30, 926], [60, 908], [100, 893], [150, 872], [200, 846], [240, 822], [272, 796], [294, 768], [302, 740], [300, 712],
      [282, 690], [260, 668], [236, 642], [216, 612], [194, 580], [180, 548], [174, 500], [172, 452], [160, 404], [151, 352], [140, 302], [146, 250],
      [174, 202], [210, 152], [253, 112], [300, 89], [360, 73], [400, 68], [440, 73], [480, 86], [520, 101], [560, 120], [600, 147], [640, 186],
      [660, 215], [680, 252], [697, 300], [704, 350], [701, 400], [688, 450], [662, 500], [622, 550], [582, 598], [576, 630], [586, 662], [620, 682],
      [670, 686], [700, 672], [740, 660], [740, 1040], [-20, 1040]], true, true);
    K(sil, '#f8f8f6', 16);
    F(sil, INK);

    // ── zebra brow field ──
    const zeb = E.fx(`
      const float Y0[19] = float[19](482.,468.,452.,439.,427.,416.,406.,399.,387.,372.,345.,319.,295.,275.,259.,245.,235.,228.,220.);
      const float PP[19] = float[19](44.,45.,44.,44.,44.,47.,49.,53.,57.,63.,62.,62.,58.,57.,54.,55.,52.,52.,54.);
      const float BB[19] = float[19](552.,542.,528.,515.,500.,490.,494.,478.,458.,440.,420.,395.,372.,352.,345.,345.,345.,345.,345.);
      float tab(int k, int which){ return which == 0 ? Y0[k] : (which == 1 ? PP[k] : BB[k]); }
      float lut(float x, int which){
        float f = (x - 200.) / 20.;
        if (f <= 0.) return tab(0, which) + (tab(0, which) - tab(1, which)) * (-f);
        if (f >= 18.) return tab(18, which) + (tab(18, which) - tab(17, which)) * (f - 18.);
        int i = int(floor(f)); float t = f - float(i);
        return mix(tab(i, which), tab(i + 1, which), t);
      }
      vec3 fx(vec2 uv, vec2 p){
        float y0 = lut(p.x, 0), P = lut(p.x, 1), B = lut(p.x, 2);
        float k = (p.y - y0) / P;
        float s = cos(6.2832 * k);
        float t = -0.02 + 1.1 * smoothstep(B - 50., B + 4., p.y);
        float wv = smoothstep(t - 0.06, t + 0.06, s);
        return mix(vec3(.012, .012, .02), vec3(.97, .97, .98), wv);
      }`);
    const face = P([[176, 470], [182, 420], [190, 340], [200, 290], [230, 240], [300, 190], [380, 140], [440, 128], [490, 140], [530, 175], [560, 230], [575, 290],
      [650, 300], [650, 430], [600, 560], [560, 640], [470, 690], [300, 700], [220, 620], [190, 560]]);
    F(face, pat(zeb));

    // ── navy hair cap (jagged fringe) ──
    const hairTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * vec2(0.012, 0.03)) * 0.7 + vnoise(p * 0.9) * 0.3;
      vec3 a = vec3(.15, .25, .47), b = vec3(.30, .37, .62);
      return mix(a, b, n) * (0.92 + 0.12 * hash(floor(p)));
    }`));
    const hair = P([[170, 520], [168, 470], [158, 410], [149, 352], [139, 302], [145, 250], [172, 202], [208, 152], [252, 112], [300, 88], [360, 72],
      [400, 67], [440, 72], [470, 79], [500, 96], [530, 113], [556, 137], [576, 164], [590, 200], [602, 250], [609, 300], [611, 380], [606, 440], [596, 500],
      [588, 560], [580, 585], [570, 570], [566, 520], [566, 450], [570, 400], [578, 340], [576, 290], [566, 250], [550, 212], [528, 180], [500, 150], [470, 138],
      [440, 132], [410, 133], [380, 145], [352, 170], [340, 195], [318, 222], [330, 190], [300, 220], [270, 244], [262, 230], [246, 262], [238, 255],
      [218, 290], [200, 330], [192, 380], [188, 440], [184, 480], [180, 520]], true, false);
    F(hair, hairTex);
    C(hair, () => { const g = o.createLinearGradient(0, 240, 0, 420); g.addColorStop(0, 'rgba(8,30,80,0)'); g.addColorStop(1, 'rgba(8,30,80,0.8)'); o.fillStyle = g; o.fillRect(560, 240, 60, 360); });
    // jagged fringe spikes pointing down into the stripes
    for (const sp of [[[250, 200], [262, 238], [276, 210]], [[290, 196], [308, 232], [318, 190]], [[330, 178], [345, 204], [356, 168]], [[226, 228], [232, 268], [248, 236]],
      [[200, 280], [196, 330], [214, 290]], [[360, 160], [384, 168], [372, 150]]]) F(P(sp, true, false), hairTex);
    // bubbles in the hair
    for (const [x, y, r] of [[243, 168, 8], [253, 185, 3.5], [228, 196, 7], [340, 150, 2], [455, 98, 2.5], [470, 128, 4], [500, 152, 3.5], [530, 144, 6], [578, 160, 7]]) F(circleP(x, y, r), '#cfe0f4');

    // ── pink coral-planet bubble on the right ──
    const bub = P([[470, 78], [520, 101], [560, 120], [600, 147], [640, 186], [660, 215], [680, 252], [697, 300], [704, 350], [701, 400], [688, 450], [662, 500],
      [622, 550], [588, 592], [588, 560], [596, 500], [606, 440], [611, 380], [609, 300], [602, 250], [590, 200], [576, 164], [556, 137], [530, 113], [500, 96]]);
    { const g = o.createLinearGradient(520, 100, 700, 480); g.addColorStop(0, '#de8aa8'); g.addColorStop(0.4, '#f49aa8'); g.addColorStop(1, '#ee94a8');
      F(bub, g); }
    C(bub, () => {
      // violet coral trees
      const rr = rng(41);
      o.strokeStyle = '#5e60ac'; o.lineCap = 'round';
      const branch = (x, y, a, len, wd, d) => {
        if (d <= 0 || len < 3) return;
        const x2 = x + Math.cos(a) * len, y2 = y + Math.sin(a) * len;
        o.lineWidth = wd; o.beginPath(); o.moveTo(x, y); o.lineTo(x2, y2); o.stroke();
        branch(x2, y2, a - 0.35 - rr() * 0.4, len * (0.62 + rr() * 0.2), wd * 0.7, d - 1);
        branch(x2, y2, a + 0.3 + rr() * 0.4, len * (0.62 + rr() * 0.2), wd * 0.7, d - 1);
      };
      branch(622, 330, -1.45, 46, 3, 6); branch(672, 470, -1.75, 60, 4, 6); branch(690, 330, -2.0, 40, 3, 5); branch(650, 260, -1.9, 34, 2.5, 5);
      soft(10, () => F(P([[640, 340], [690, 330], [700, 420], [680, 480], [640, 500], [628, 420]]), 'rgba(110,100,180,0.75)'));
      for (let i = 0; i < 120; i++) { const t = rr(), y = 225 + t * 270, x = 628 + rr() * 74 - t * 10; if (rr() < 0.75) F(P(blob(x, y, 3 + rr() * 7, 2 + rr() * 5, 400 + i, 8, 0.4)), rr() < 0.7 ? '#6264b0' : '#7a70b8'); }
      o.save(); o.lineWidth = 10; o.strokeStyle = 'rgba(150,120,190,0.45)'; o.stroke(P([[660, 215], [690, 280], [704, 350], [694, 430], [662, 500]], false)); o.restore();
    });
    // zebra wedge between hair band and bubble
    const wedge = P([[612, 282], [628, 296], [640, 360], [646, 410], [640, 424], [614, 420], [612, 350]]);
    C(wedge, () => { o.fillStyle = INK; o.fillRect(600, 270, 60, 170); for (let k = 0; k < 4; k++) F(P([[600, 300 + k * 40], [660, 330 + k * 40], [660, 350 + k * 40], [600, 320 + k * 40]], true, false), '#f6f6f8'); });
    // pale blue fin in the bubble's lower part
    F(P([[600, 420], [630, 410], [650, 430], [655, 470], [640, 520], [610, 560], [586, 576], [590, 520], [596, 470]]), '#4a74bc');
    F(P([[612, 440], [626, 432], [630, 470], [616, 520], [600, 548], [604, 500]]), '#6c8cc8');
    // bubble shine dots
    for (const [x, y, r] of [[555, 134, 3], [583, 160, 5], [600, 175, 3], [568, 148, 2]]) F(circleP(x, y, r), '#f4f4f8');

    // ── jellyfish window ──
    const win = P([[438, 380], [446, 356], [470, 346], [520, 344], [566, 346], [572, 420], [590, 470], [588, 560], [560, 610], [520, 620], [460, 620], [448, 560], [444, 480]]);
    { const g = o.createLinearGradient(0, 340, 0, 620); g.addColorStop(0, '#0d2d64'); g.addColorStop(0.5, '#082252'); g.addColorStop(1, '#0a2a5c'); F(win, g); }
    K(P([[444, 620], [444, 480], [438, 380], [446, 356], [470, 346], [530, 344]], false), '#c8dcf0', 3);
    C(win, () => {
      const rr = rng(4141);
      for (let i = 0; i < 40; i++) F(circleP(450 + rr() * 140, 350 + rr() * 260, 0.6 + rr() * 1.4), 'rgba(220,235,255,0.8)');
      for (const [x, y, r] of [[570, 352, 3], [580, 380, 3], [578, 470, 4], [584, 440, 2]]) F(circleP(x, y, r), '#e8f0fa');
      // lavender strands
      for (let i = 0; i < 3; i++) K(P([[458 + i * 8, 430], [470 + i * 6, 480], [460 + i * 8, 540], [474 + i * 6, 600]], false), '#9a90b8', 4);
      // orange tentacles
      for (let i = 0; i < 11; i++) {
        const x0 = 462 + i * 9, len = 120 + rr() * 70;
        const pts = []; for (let j = 0; j <= 6; j++) pts.push([x0 + Math.sin(j * 1.1 + i) * 6 + j * (i - 5) * 0.8, 425 + j * len / 6]);
        K(P(pts, false), '#f49a48', 3 + rr() * 2);
      }
      // bell
      const bell = P([[447, 430], [450, 395], [470, 368], [505, 356], [540, 366], [558, 392], [562, 430], [540, 426], [505, 432], [470, 426]]);
      F(bell, '#f6a052');
      for (let k = 0; k < 6; k++) K(P([[456 + k * 2, 380 + k * 8], [490, 376 + k * 9], [520, 382 + k * 8], [552 - k, 378 + k * 9]], false), '#fbd0a0', 2);
    });

    // ── face details ──
    const BL = '#1f6bc0', LB = '#9cc4ea';
    // ear
    F(P([[176, 498], [188, 488], [204, 498], [216, 530], [222, 572], [214, 606], [196, 596], [182, 572], [174, 534]]), '#1d5aa8');
    F(P([[190, 512], [200, 506], [208, 532], [210, 570], [202, 584], [192, 560]]), INK);
    K(P([[194, 524], [196, 552], [204, 566]], false), '#8ab8e8', 2.5);
    // eyes
    for (const [x, y, sx, sy, rot] of [[275, 478, 34, 16, -0.15], [403, 447, 32, 14, -0.1]]) {
      F(ellipseP(x, y, sx, sy, rot), '#f2f2f6');
      F(circleP(x + 1, y + 1, 15), '#1a1020'); F(circleP(x + 1, y + 1, 12.5), PINK); F(circleP(x + 1, y + 1, 4.5), '#2a0a18');
      K(P([[x - sx - 6, y + 4], [x - sx * 0.4, y - sy - 3], [x + sx * 0.5, y - sy - 2], [x + sx + 8, y + 2]], false), BL, 4);
      K(P([[x - sx * 0.8, y + sy * 0.6], [x, y + sy + 3], [x + sx * 0.8, y + sy * 0.5]], false), BL, 2.5);
    }
    // brows
    F(P([[326, 380], [380, 364], [430, 368], [440, 378], [400, 376], [350, 384]]), BL);
    F(P([[220, 432], [250, 410], [288, 404], [262, 418], [232, 440]]), BL);
    // nose
    K(P([[338, 432], [342, 460], [346, 478]], false), LB, 6);
    K(P([[312, 500], [318, 520], [340, 524], [352, 512], [366, 520], [384, 512], [380, 494], [368, 486]], false), BL, 5);
    K(P([[330, 498], [322, 510]], false), BL, 3);
    // mouth
    const mouth = P([[296, 585], [320, 570], [340, 562], [360, 556], [380, 551], [400, 552], [415, 554], [428, 549], [424, 562], [415, 582], [400, 593],
      [380, 598], [360, 602], [340, 604], [320, 600]]);
    F(mouth, PINK);
    const teeth = P([[310, 588], [330, 579], [350, 572], [370, 566], [390, 561], [410, 557], [419, 559], [412, 567], [390, 572], [370, 577], [350, 583], [330, 589]]);
    F(teeth, '#f6f4f2');
    C(teeth, () => { for (let i = 0; i < 11; i++) K(P([[318 + i * 9.5, 560 - i * 2], [321 + i * 9.5, 600 - i * 3]], false), '#1a1018', 1.8); });
    K(teeth, '#1a1018', 1.5);
    K(P([[298, 580], [288, 586], [290, 598]], false), BL, 4); K(P([[422, 546], [432, 548], [438, 558]], false), BL, 4);
    K(P([[356, 606], [380, 602]], false), BL, 2.5);
    // cheek patch
    F(ellipseP(276, 640, 12, 22, -0.3), '#7aa2cc');
    // jaw line
    K(P([[300, 686], [360, 690], [430, 688]], false), '#e8eef8', 2);
    // neck marks
    K(P([[300, 748], [318, 770], [326, 806]], false), '#d8e6f6', 4);
    F(P([[214, 905], [260, 900], [300, 902], [256, 912]]), '#dce8f6');
    F(ellipseP(240, 950, 22, 9, -0.5), BL);

    // ── lower-right zebra field ──
    const zf = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float k = (p.y + 0.83 * (p.x - 720.) - 721.) / 62.;
      float s = cos(6.2832 * k);
      return mix(vec3(.012), vec3(.96, .96, .97), smoothstep(0.17, 0.33, s));
    }`));
    const zreg = P([[548, 1040], [552, 900], [570, 800], [600, 740], [660, 700], [740, 690], [740, 1040]], true, false);
    F(zreg, zf);
    F(P([[556, 958], [560, 930], [574, 918], [584, 930], [576, 954]]), '#6a70b4');
    F(P([[572, 1000], [578, 972], [592, 962], [602, 976], [598, 1002]]), '#a4c4ec');
    F(P(lock(cr([[333, 730], [345, 770], [365, 810], [388, 845]], 6), 14, 3)), BL);
    F(P([[402, 760], [416, 756], [420, 766], [410, 772], [400, 768]]), BL);

    // ── octopus ──
    const LT = '#9fc3e6', MID = '#3f8ad4';
    const tents = [
      [[[460, 730], [440, 770], [410, 805], [380, 850], [330, 900], [302, 950], [284, 1000], [278, 1040]], 34, 28],
      [[[480, 735], [466, 790], [440, 850], [388, 900], [356, 950], [332, 1000], [326, 1040]], 36, 30],
      [[[494, 740], [490, 800], [480, 850], [472, 900], [463, 950], [450, 1000], [445, 1040]], 34, 30],
      [[[508, 735], [516, 790], [528, 850], [522, 900], [519, 950], [513, 1000], [510, 1040]], 32, 28],
      [[[522, 730], [550, 780], [580, 840], [595, 900], [608, 950], [636, 1000], [646, 1040]], 36, 30],
      [[[530, 720], [580, 765], [618, 805], [647, 850], [680, 900], [712, 950], [750, 1010]], 36, 30],
      [[[540, 712], [600, 750], [660, 785], [700, 800], [750, 806]], 44, 40],
      [[[530, 690], [590, 702], [640, 702], [690, 692], [750, 688]], 50, 44],
    ];
    const T = tents.map(([pts, w0, w1], i) => rib(pts, w0, w1, 0.1, i + 1));
    const curl = rib([[750, 640], [726, 630], [705, 610], [688, 596], [668, 594], [652, 604], [650, 618]], 56, 22, 0.06, 9);
    const mantle = P([[420, 690], [440, 660], [452, 636], [480, 628], [510, 640], [540, 652], [570, 668], [570, 720], [520, 745], [470, 745], [430, 730]]);
    const all = [...T.map(t => t.path), curl.path, mantle];
    for (const p of all) K(p, '#f6f8fa', 9);
    for (const p of all) K(p, INK, 5);
    for (const p of all) F(p, MID);
    F(mantle, LT);
    // pale highlights and white flecks along each tentacle
    const rr = rng(77);
    for (const t of [...T, curl]) {
      const q = t.cl;
      const n = q.length, nrm = i => { const a = q[Math.max(0, i - 1)], b = q[Math.min(n - 1, i + 1)], d = Math.hypot(b[0] - a[0], b[1] - a[1]) || 1; return [-(b[1] - a[1]) / d, (b[0] - a[0]) / d]; };
      for (let pass = 0; pass < 2; pass++) {
        for (let i = 0; i < n - 4;) {
          const len = 6 + Math.floor(rr() * 14), off = (rr() - 0.5) * (pass ? 14 : 10), seg = [];
          for (let j = i; j < Math.min(n, i + len); j += 2) { const [nx, ny] = nrm(j); seg.push([q[j][0] + nx * off, q[j][1] + ny * off]); }
          if (seg.length > 2) F(P(lock(seg, pass ? 5 + rr() * 3 : 6 + rr() * 5, 1.5)), pass ? (rr() < 0.5 ? '#9cccf2' : '#7ab4ea') : '#2b72c6');
          i += len + Math.floor(rr() * 6);
        }
      }
      for (let i = 2; i < q.length - 2; i += 5) F(ellipseP(q[i][0] + (rr() - 0.5) * 10, q[i][1] + (rr() - 0.5) * 10, 2 + rr() * 3, 1.2, rr() * 3), '#e8f2fc');
    }
    C(mantle, () => {
      for (const [x, y, rx, ry, a] of [[470, 650, 10, 4, -0.2], [452, 700, 6, 18, 0.1], [478, 708, 8, 22, 0.15], [505, 680, 22, 6, 0.4], [530, 700, 26, 6, 0.35],
        [552, 690, 20, 5, 0.3], [500, 725, 7, 18, -0.2], [540, 724, 18, 5, 0.4], [430, 740, 8, 20, 0.2], [520, 660, 14, 4, 0.3]]) F(ellipseP(x, y, rx, ry, a), MID);
      for (const [x, y] of [[466, 668], [496, 700], [524, 676], [446, 728], [560, 708]]) F(ellipseP(x, y, 3, 1.5, 0.4), '#f0f6fc');
    });
    // eye stalks: concentric ring discs
    for (const [x, y] of [[543, 622], [415, 712]]) {
      F(circleP(x, y, 37), '#f6f8fa'); F(circleP(x, y, 34), '#123c80'); F(circleP(x, y, 32.5), '#e2edf8');
      for (let r = 30; r > 15; r -= 3.3) K(circleP(x, y, r), '#3a7ccc', 1.3);
      F(circleP(x, y, 14), INK); F(circleP(x, y, 12), PINK);
      C(circleP(x, y, 12), () => F(P([[x + 12, y - 8], [x + 12, y + 12], [x - 8, y + 12]], true, false), '#f39a3a'));
    }

    E.grain(0.03, 41);
  }
});
