'use strict';
// g225 — "Chrome fish with a sun eye": a silver relief plate shaped like a fish head, with a red ray-burst eye, a coiled
// spiral boss, orange balls in a black channel and rows of pearls, a ribbed white cup on top, drifting over mauve haze
// with a lavender cloud, a mint glow, yellow stripes, blue-grey ripples and glowing amber droplets.
REC.register('g225', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, clipP = null, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, fx = x, fy = y, r0 = 0) => { const g = a.createRadialGradient(fx, fy, r0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const pts = f => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return q; };
    const sm = f => P(pts(f), true, true), ln = f => P(pts(f), false, true), poly = f => P(pts(f), true, false);
    const ball = (x, y, r, c0, c1, c2, m = 3, h0 = 0.3) => R.dome(circleP(x, y, r), rad(x, y, r, [[0, c0], [0.7, c1], [1, c2]], x - r * 0.3, y - r * 0.35), h0, Math.min(0.3, r * 0.01 + 0.06), r, m);
    const SIL = '#b4a7ad';

    // ── 1. background: mauve haze, blue-grey ripples, lavender cloud, mint glow, yellow stripes ──
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 mauve = vec3(0.35, 0.29, 0.31);
      float r = length((p - vec2(470., 470.)) * vec2(1., 0.9));
      float ring = 0.5 + 0.5 * cos(6.2832 * r / 92. + 0.6 * sin(atan(p.y - 470., p.x - 470.) * 2.));
      vec3 blu = mix(vec3(0.34, 0.27, 0.31), vec3(0.45, 0.5, 0.63), ring);
      float low = smoothstep(560., 760., p.y) * smoothstep(120., 300., p.x) * smoothstep(700., 600., p.x + 0.3 * (p.y - 800.));
      vec3 c = mix(mauve, blu, low);
      c = mix(c, vec3(0.36, 0.46, 0.48), smoothstep(160., 40., length((p - vec2(500., 290.)) / vec2(1.2, 0.8))) * 0.8);
      c += 0.012 * sin((p.x * 0.6 + p.y) * 0.25);
      c = mix(c, vec3(0.2, 0.26, 0.28), smoothstep(70., 20., length((p - vec2(490., 320.)) / vec2(1.4, 0.6))) * 0.8);
      return c; }`));
    // lavender cloud left, pale ground lower left with a beige sweep
    soft(x => {
      x.fillStyle = '#cac4ce'; x.fill(sm([-20, 95, 40, 72, 100, 66, 140, 70, 160, 100, 152, 160, 168, 220, 160, 285, 140, 335, 100, 385, 60, 425, -20, 445]));
      x.fill(sm([-20, 770, 80, 765, 160, 770, 230, 760, 205, 830, 160, 920, 130, 1044, -20, 1044]));
      x.fillStyle = '#c4a8a2'; x.fill(sm([230, 760, 255, 780, 230, 860, 200, 940, 185, 1044, 130, 1044, 160, 930, 200, 830]));
      x.fillStyle = '#d2ead8'; x.fill(sm([300, 175, 345, 120, 380, 92, 420, 100, 460, 150, 520, 175, 560, 210, 548, 260, 470, 300, 360, 320, 290, 300, 255, 255]));
    }, 8);
    soft(x => { x.fillStyle = 'rgba(100,140,120,0.85)'; x.fill(sm([255, 255, 300, 220, 360, 230, 420, 260, 440, 320, 360, 330, 270, 320]));
      x.fillStyle = 'rgba(160,184,170,0.95)'; x.fill(sm([140, 230, 200, 200, 260, 220, 300, 260, 290, 310, 220, 340, 150, 370, 130, 300])); }, 18);
    // dark teal shadow behind the eye and cup
    soft(x => { x.fillStyle = '#1c2c34'; x.fill(sm([420, 300, 480, 280, 560, 270, 610, 300, 630, 380, 610, 470, 560, 470, 520, 380, 450, 350])); }, 18, 0.9);
    // teal pocket with yellow stripes on the right
    const stripeZ = sm([600, 320, 660, 300, 736, 290, 736, 500, 680, 515, 630, 500, 605, 430]);
    soft(x => { x.fillStyle = '#4a5c62'; x.fill(stripeZ); }, 10);
    clipAH(stripeZ, () => soft(x => {
      x.strokeStyle = '#f2b23e'; x.lineWidth = 20; for (const c of [360, 412, 462, 512]) x.stroke(ln([560, c + 44, 760, c - 66]));
    }, 3, 0.95));
    // blue drop top right
    R.dome(sm([700, -10, 726, -10, 726, 140, 690, 145, 655, 128, 645, 98, 660, 70, 690, 50]), lin(650, 50, 726, 140, [[0, '#0a2a6a'], [0.4, '#2a78c8'], [1, '#8ad4f0']]), 0.2, 0.15, 24, 3);

    // ── 2. the silver plate ──
    const plate = sm([-20, 445, 40, 425, 100, 405, 150, 385, 178, 362, 210, 345, 250, 330, 290, 312, 302, 290, 300, 255, 312, 236, 335, 232, 350, 248, 352, 275, 362, 290, 395, 288, 425, 280,
      452, 290, 462, 312, 450, 340, 420, 380, 380, 440, 370, 500, 385, 560, 430, 585, 520, 588, 580, 560, 612, 562, 642, 572, 650, 592, 636, 612, 600, 620, 582, 650, 575, 690, 556, 728,
      460, 740, 350, 745, 250, 750, 150, 756, 60, 766, -20, 776]);
    R.dome(plate, lin(0, 400, 600, 750, [[0, '#c4b8be'], [0.5, '#bcafb5'], [1, '#b0a4aa']]), 0.1, 0.12, 22, 1);
    // grainy specks
    clipAH(plate, () => soft(x => { const r = rng(225); for (let i = 0; i < 500; i++) { const px = r() * 650, py = 230 + r() * 530; x.fillStyle = r() < 0.5 ? 'rgba(90,70,70,0.6)' : 'rgba(240,235,240,0.7)'; x.fill(circleP(px, py, 0.6 + r() * 1.2)); } }, 0.3));
    { const r = rng(7); for (let i = 0; i < 90; i++) { const x = r() * 600, y = 340 + r() * 380; R.bead(x, y, 1.5 + r() * 3, null, 0.24, 0.03, 1); } }
    // rim pipe along the bottom edge and ribbed top edge
    R.pipe(ln([-20, 772, 60, 762, 150, 752, 250, 746, 350, 741, 460, 736, 552, 724]), 14, '#c8bcc2', 0.18, 0.08, 1);
    R.pipe(ln([150, 383, 178, 362, 210, 345, 250, 330, 290, 312]), 12, '#a89ca2', 0.2, 0.06, 1);
    for (let i = 0; i < 16; i++) { const t = i / 15, x = 160 + 125 * t, y = 377 - 63 * t; R.groove(ln([x - 2, y - 4, x + 2, y + 4]), 3.5, '#2a2428', 0.26, 0.05, 1, 0.9); }
    // knob handle and right bump on top
    R.pipe(ln([300, 300, 305, 255, 322, 238, 342, 245, 348, 268, 340, 290, 360, 302, 395, 296, 425, 290, 445, 300]), 22, '#c8c0c8', 0.22, 0.12, 1);
    R.pipe(ln([255, 245, 285, 235, 300, 240]), 14, '#c0b8c0', 0.24, 0.08, 1);
    // black holes and little blisters
    for (const [x, y, r] of [[185, 400, 13], [300, 355, 11], [38, 505, 7]]) { R.groove(circleP(x, y, r * 0.5), r, '#060406', 0.12, 0.08, 1, 1); R.flat(circleP(x, y, r * 0.7), '#060406', 0.04, 1); }
    ball(272, 386, 18, '#b8e8e8', '#60a8b0', '#3a6a70', 3, 0.2);

    // ── 3. spiral boss and orange smear ──
    R.flat(sm([75, 474, 130, 478, 190, 494, 250, 518, 246, 546, 196, 548, 150, 528, 112, 502]), lin(80, 480, 250, 540, [[0, '#d65a1c'], [1, '#cc5018']]), 0.13, 3);
    R.dome(circleP(215, 463, 48), '#bab0b8', 0.14, 0.1, 18, 1);
    R.groove(ln((() => { const q = []; for (let t = 0.6; t < 5.2 * 6.283; t += 0.15) { const rr = 2 + t * 1.25; q.push(215 + Math.cos(t) * rr, 463 + Math.sin(t) * rr); } return q; })()), 5, '#6a6068', 0.26, 0.08, 1, 0.8);

    // ── 4. black channel with orange balls ──
    const chan = poly([-20, 637, 262, 544, 284, 584, -20, 690]);
    R.flat(chan, '#060506', 0.06, 0);
    R.pipe(ln([-20, 635, 262, 542]), 5, '#d0c8cc', 0.16, 0.04, 1);
    R.pipe(ln([-20, 692, 284, 586]), 5, '#d0c8cc', 0.16, 0.04, 1);
    for (const [x, y, r] of [[117, 616, 17], [170, 598, 17], [203, 586, 18], [260, 568, 22], [305, 552, 17]]) ball(x, y, r, '#ffb090', '#f85a1c', '#c03a08');
    R.dome(circleP(18, 652, 22), '#b8acb4', 0.1, 0.1, 8, 1);
    for (let i = 1; i <= 4; i++) R.groove(circleP(18, 652, i * 4.5), 2.4, '#5a5058', 0.18, 0.04, 1, 0.8);
    R.flat(rrect(220, 600, 70, 40, 6), '#c49070', 0.13, 3);

    // ── 5. the eye ──
    R.dome(sm([336, 470, 350, 440, 380, 430, 420, 440, 430, 520, 420, 585, 380, 590, 345, 570, 335, 520]), '#38c4f8', 0.08, 0.04, 8, 3);
    R.dome(circleP(491, 468, 120), lin(400, 350, 600, 590, [[0, '#c8c0c8'], [1, '#a8a0a8']]), 0.12, 0.16, 18, 4);
    for (let i = 0; i < 26; i++) { const t = -2.6 + i * 0.07, x = 491 + Math.cos(t) * 108, y = 468 + Math.sin(t) * 108; R.groove(ln([x, y, x + Math.cos(t) * 6, y + Math.sin(t) * 6]), 3, '#3a3238', 0.28, 0.05, 4, 0.9); }
    R.groove(circleP(491, 468, 92), 10, '#202024', 0.28, 0.1, 4, 1);
    R.flat(circleP(491, 468, 86), '#8a2a14', 0.2, 0);
    clipAH(circleP(491, 468, 86), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(491., 468.); float r = length(d), a = atan(d.y, d.x);
      vec3 c = mix(vec3(0.95, 0.42, 0.16), vec3(0.42, 0.08, 0.04), smoothstep(10., 86., r));
      c += vec3(0.5, 0.25, 0.1) * pow(0.5 + 0.5 * cos(a * 70. + 3. * vnoise(vec2(a * 9., 2.))), 6.) * smoothstep(80., 20., r);
      c = mix(c, vec3(1.), smoothstep(26., 18., r));
      return c; }`)));
    // lever with orange cap and the black teardrop key
    R.pipe(ln([318, 552, 350, 540, 392, 530]), 14, '#c8c0c8', 0.3, 0.1, 4);
    ball(388, 528, 12, '#d0d0d8', '#888890', '#404048', 4, 0.32);
    R.dome(sm([398, 500, 412, 504, 418, 520, 412, 545, 414, 580, 418, 625, 404, 632, 398, 590, 396, 545, 386, 520]), '#060506', 0.3, 0.06, 6, 3);

    // ── 6. pearls ──
    for (let row = 0; row < 2; row++) for (let i = 0; i < 16; i++) {
      const t = i / 15, x = 130 + 446 * t + row * 6, y = 700 - 95 * t + row * 22, rr = 15.5;
      R.dome(circleP(x, y, rr), rad(x, y, rr, [[0, '#f8f4f8'], [0.6, '#d8d0d8'], [1, '#9a929a']], x - 5, y - 6), 0.3 - row * 0.02, 0.12, rr, 5);
    }
    R.dome(sm([520, 690, 548, 668, 576, 680, 574, 710, 545, 730, 516, 722]), '#d4ccd4', 0.26, 0.1, 12, 5);

    // ── 7. ribbed cup ──
    const cupB = sm([392, 238, 400, 214, 430, 200, 470, 198, 510, 205, 540, 218, 550, 240, 540, 268, 512, 290, 476, 298, 440, 292, 410, 274]);
    const cupT = sm([392, 206, 400, 176, 425, 158, 462, 148, 505, 146, 540, 160, 552, 186, 545, 212, 520, 228, 480, 232, 440, 230, 408, 222]);
    for (const cp of [cupB, cupT]) {
      R.dome(cp, lin(400, 150, 550, 290, [[0, '#e0dce6'], [0.6, '#cbc6d2'], [1, '#a8a2b2']]), 0.3, 0.16, 22, 2);
      clipAH(cp, () => { for (let i = 0; i < 10; i++) { const x = 404 + i * 16, b = (x - 472) * 0.18; R.groove(ln([x - b, 140, x + b, 190, x - b, 240, x + b, 300]), 4, '#aaa4b4', 0.44, 0.03, 2, 0.35); } });
    }
    R.dome(ellipseP(500, 165, 44, 20, 0.2), '#8a8494', 0.4, -0.06, 10, 2);
    // glitch fragments: black / white / orange slivers beside the cup
    soft(x => { const r = rng(12);
      for (const [x0, y0, w, h] of [[548, 205, 22, 60], [560, 250, 18, 70], [580, 225, 12, 40], [598, 280, 16, 40], [612, 236, 22, 30], [370, 248, 50, 22], [600, 320, 40, 26]]) {
        x.fillStyle = '#0a0808'; x.fill(sm([x0, y0, x0 + w * 0.6, y0 + h * 0.15, x0 + w, y0 + h * 0.6, x0 + w * 0.5, y0 + h, x0 + w * 0.1, y0 + h * 0.7]));
        x.strokeStyle = r() < 0.5 ? '#f4a040' : '#f0f0f4'; x.lineWidth = 2.5; x.stroke(ln([x0 + 2, y0 + 4, x0 + w * 0.3, y0 + h * 0.5, x0 + w * 0.2, y0 + h * 0.9])); } }, 0.8);

    // ── 8. chrome C ring, droplets ──
    R.pipe(P((() => { const q = []; for (let t = -2.6; t < 2.0; t += 0.1) q.push([145 + Math.cos(t + 1.5) * 46, 838 + Math.sin(t + 1.5) * 46]); return q; })(), false, true), 14, '#d0c8d0', 0.2, 0.14, 4);
    R.dome(circleP(145, 838, 40), '#aaa6b0', 0.08, 0.03, 10, 1);
    ball(195, 155, 22, '#ffffff', '#a8b0b4', '#40484c', 3, 0.2);
    for (const [x, y, r] of [[25, 152, 18], [295, 197, 18], [210, 322, 14], [690, 565, 16], [668, 525, 10], [600, 683, 18], [692, 690, 12], [678, 770, 22], [565, 745, 18], [350, 765, 15],
      [330, 800, 12], [320, 845, 22], [465, 850, 16], [440, 905, 22], [485, 822, 8], [40, 820, 18], [690, 495, 8], [610, 312, 18], [290, 238, 14]]) {
      R.dome(circleP(x, y, r + 4), '#a8d0dc', 0.06, 0.04, 4, 3);
      R.dome(circleP(x, y, r), rad(x, y, r, [[0, '#ffe8a0'], [0.35, '#e8a048'], [0.8, '#9a6a40'], [1, '#c8d8e0']], x, y + r * 0.1), 0.1, 0.1, r, 6);
    }
    { const r = rng(31); for (let i = 0; i < 60; i++) { const x = r() * 726, y = r() * 1024, rr = 2 + Math.pow(r(), 3) * 6; ball(x, y, rr, '#ffffff', '#b8b0b8', '#504850'); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.8, shin: 40, metal: 0.25, wrap: 0.4, ao: 0.5, coat: 0.1 }),      // 1 silver plate
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.5, coat: 0.06 }),                    // 2 ribbed cup
        E.mat({ dif: 1, spec: 1.3, shin: 80, wrap: 0.4, ao: 0.3, coat: 0.3 }),                     // 3 gloss beads
        E.mat({ dif: 0.8, spec: 1.2, shin: 50, metal: 0.4, wrap: 0.3, ao: 0.5, coat: 0.15 }),      // 4 chrome eye ring
        E.mat({ dif: 1, spec: 1.1, shin: 60, wrap: 0.4, ao: 0.3, coat: 0.25 }),                    // 5 pearls
        E.mat({ dif: 0.7, spec: 1.2, shin: 70, wrap: 0.5, emis: 0.35, coat: 0.2 }),                 // 6 glowing amber drops
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.7, 0.7, 0.72], amb: [0.46, 0.44, 0.47],
      envTop: [1.2, 1.2, 1.25], envHor: [0.55, 0.55, 0.6], envBot: [0.15, 0.13, 0.15], envK: [0.4, 1.2, 0.3, 0],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.5, 6]
    });
    // glows: eye core and amber droplets
    { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0);
      const g = x.createRadialGradient(491, 468, 0, 491, 468, 60); g.addColorStop(0, 'rgba(255,255,240,1)'); g.addColorStop(0.35, 'rgba(255,220,180,0.6)'); g.addColorStop(1, 'rgba(255,120,60,0)'); x.fillStyle = g; x.fillRect(400, 380, 180, 180);
      E.draw(c, 0.8, 'screen'); }
  }
});
