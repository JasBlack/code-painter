'use strict';
// u036 — "Frosted lavender clay parade": a frosted lavender clay pad and a bulbous grey idol over a wavy zebra wall and
// blue sky, a sugar-frosted ribbon sweeping down through rainbow streaks, tiger-striped blue clay creatures crawling below.
REC.register('u036', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };

    // ── textures ──
    const PAL = `vec3 pal(float t){ t = fract(t) * 6.;
        vec3 c0 = vec3(.36, .45, .80), c1 = vec3(.48, .83, .66), c2 = vec3(.93, .88, .52), c3 = vec3(.97, .60, .42), c4 = vec3(.90, .56, .64), c5 = vec3(.55, .46, .78);
        return t < 1. ? mix(c0, c1, t) : t < 2. ? mix(c1, c2, t - 1.) : t < 3. ? mix(c2, c3, t - 2.) : t < 4. ? mix(c3, c4, t - 3.) : t < 5. ? mix(c4, c5, t - 4.) : mix(c5, c0, t - 5.); }`;
    const STREAK = E.fx(PAL + `
      vec3 fx(vec2 uv, vec2 p){
        float u = p.y + .27 * p.x;
        float k = smoothstep(800., 1040., u);
        float id = floor(u / 16.), f = fract(u / 16.), h = hash(vec2(id, 3.));
        float w = mix(.12, 1.05, k) * (.5 + .5 * h);
        float m = step(740., u) * step(.35 - k * .3, hash(vec2(id, 9.))) * smoothstep(0., .05, f) * smoothstep(w, w - .05, f);
        vec3 c = pal(u * .011 + h * .25) * (.85 + .15 * vnoise(p * .3));
        vec3 bg = vec3(.02, .02, .03);
        // thin streaks top-left
        float u2 = p.y + .62 * p.x, f2 = fract(u2 / 9.);
        float m2 = (1. - step(130., u2)) * step(.45, hash(vec2(floor(u2 / 9.), 1.))) * smoothstep(.0, .1, f2) * smoothstep(.45, .3, f2);
        return mix(bg, c, max(m, m2)); }`);
    const ZEB = E.fx(`
      const float ZBC[168] = float[168](-17.908,-16.373,-14.424,-11.554,-8.420,-7.228,-8.452,-9.692,-10.219,-10.529,-10.559,-10.305,-9.863,-9.346,-13.792,-12.547,-11.542,-10.144,-7.376,-7.890,-8.141,-8.035,-8.443,-8.751,-8.721,-8.521,-8.262,-7.993,-10.039,-8.781,-7.479,-7.103,-7.318,-6.779,-6.240,-6.094,-6.972,-6.903,-6.763,-6.678,-6.647,-6.642,-6.734,-5.988,-5.356,-5.998,-5.648,-5.100,-4.458,-4.290,-4.359,-4.527,-4.601,-4.753,-4.998,-5.249,-3.983,-4.074,-4.445,-3.757,-4.075,-3.333,-2.797,-2.403,-2.614,-2.300,-2.269,-2.725,-3.266,-3.703,-1.777,-1.894,-1.828,-1.865,-2.040,-1.601,-1.036,-0.758,-0.553,-0.982,0.043,-0.664,-1.305,-1.863,0.170,0.064,-0.024,-0.240,-0.258,0.600,0.543,0.810,1.116,0.964,1.663,1.575,1.332,0.325,1.945,1.775,1.578,1.371,1.278,1.267,1.139,2.288,2.540,3.086,2.805,3.016,2.835,2.795,3.599,3.365,3.117,2.865,2.612,2.370,2.355,2.709,2.769,3.375,4.711,4.472,5.183,5.684,5.184,4.905,4.613,4.296,3.953,3.641,3.467,3.400,3.483,3.915,4.735,6.380,7.631,8.558,6.737,6.423,6.091,5.720,5.312,4.906,4.559,4.338,4.404,4.883,5.943,7.736,9.529,11.181,8.282,7.936,7.567,7.148,6.669,6.151,5.666,5.363,5.435,6.047,7.297,9.116,11.302,13.622);
      float zb(vec2 p){ vec2 u = clamp((p - vec2(130.0, 180.0)) / vec2(45.4545, 43.3333), vec2(0.), vec2(10.999, 8.999));
        ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
        vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
        vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
        float f = 0.;
        for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZBC[(i.y + b) * 14 + i.x + a] * bx[a] * by[b];
        return f; }
      vec3 fx(vec2 uv, vec2 p){ float v = cos(6.2832 * zb(p)); return mix(vec3(.02), vec3(.95, .95, .96), smoothstep(-.15, .15, v)); }`);
    const TIGER = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float w = fbm(p * .02) * 6.;
        float s = sin(p.x * .3 + p.y * .12 + w);
        vec3 blue = vec3(.33, .43, .68) * (.8 + .3 * vnoise(p * .05)), org = vec3(.86, .62, .36), yel = vec3(.84, .82, .48);
        return mix(blue, mix(org, yel, vnoise(p * .03)), smoothstep(.35, .6, s)); }`);
    const RAINLEG = E.fx(PAL + `
      vec3 fx(vec2 uv, vec2 p){ return pal(p.x * .03 + fbm(p * .02) * .8) * .9; }`);

    // ── backdrop ──
    img(STREAK);
    const SKY = poly([[178, 104], [350, 50], [420, 30], [540, 0], [620, 0], [600, 60], [560, 130], [520, 150], [440, 150], [430, 260], [400, 300], [300, 300], [200, 300], [178, 300]]);
    fill(SKY, lin(0, 0, 0, 300, [[0, '#2a4ec0'], [1, '#2246b0']]));
    stroke(line([[176, 102], [300, 62], [420, 26], [560, -6]]), '#8890ae', 12);
    fill(poly([[410, 140], [508, 140], [508, 256], [410, 256]]), '#ddb8ae');
    fill(poly([[650, 176], [726, 174], [726, 250], [650, 250]]), '#e9b4a0');
    const ZP = poly([[140, 255], [200, 232], [280, 205], [350, 195], [425, 195], [440, 260], [470, 330], [500, 360], [560, 400], [625, 400], [625, 565], [400, 565], [300, 420], [250, 330], [160, 290]]);
    clipA(ZP, () => img(ZEB));
    // navy shadows and crowd zone
    fill(sm([[290, 560], [480, 560], [500, 620], [470, 690], [320, 700], [300, 640]]), '#3e466c');
    fill(sm([[0, 380], [40, 380], [60, 470], [80, 560], [110, 640], [60, 680], [0, 700]]), '#4a5680');
    { const r = rng(6); for (let i = 0; i < 26; i++) { const x = 310 + r() * 150, y = 650 + r() * 50; fill(sm(blob(x, y, 6 + r() * 6, 10 + r() * 8, 30 + i, 8, 0.3)), ['#2c3260', '#5a5c90', '#c09080', '#20243c'][i % 4]); } }
    { const r = rng(8); for (let i = 0; i < 14; i++) { const x = 5 + r() * 60, y = 510 + r() * 120; fill(sm(blob(x, y, 8 + r() * 8, 12 + r() * 10, 50 + i, 8, 0.3)), ['#2a2e58', '#56508a', '#c8a090'][i % 3]); } }

    // ── grey idol (upper right) ──
    const IDOL = sm([[555, 48], [584, 58], [600, 100], [610, 150], [626, 198], [652, 224], [700, 234], [716, 254], [712, 290], [690, 320], [668, 340], [636, 352], [598, 362], [560, 372], [528, 372], [500, 360], [482, 338], [474, 310], [476, 270], [492, 230], [504, 180], [514, 110], [530, 64]]);
    R.dome(IDOL, '#b4b0b8', 0.05, 0.3, 60, 1);
    R.dome(circleP(452, 302, 26), '#b4b0b8', 0.05, 0.25, 22, 1);
    R.dome(sm([[470, 290], [480, 318], [470, 310]]), null, 0.2, 0.05, 6, 1);
    // thumb idol + finger below the ribbon
    R.dome(sm([[568, 470], [576, 432], [598, 420], [622, 432], [628, 470], [616, 520], [592, 536], [574, 520]]), '#b8b4bc', 0.05, 0.25, 26, 1);
    R.dome(sm([[560, 490], [580, 486], [590, 500], [574, 508]]), '#b8b4bc', 0.1, 0.1, 8, 1);

    // ── top men ──
    const SUIT = sm([[0, 92], [50, 74], [100, 66], [140, 76], [150, 96], [170, 130], [200, 152], [222, 160], [222, 178], [196, 180], [164, 166], [136, 140], [110, 122], [70, 120], [44, 132], [44, 180], [38, 250], [32, 330], [0, 334]]);
    fill(SUIT, '#8a8040');
    clipA(SUIT, () => { a.save(); a.rotate(0.35); a.fillStyle = '#302a1a'; for (let k = -10; k < 30; k++) a.fillRect(k * 14, -300, 6, 800); a.restore(); });
    fill(sm([[148, 72], [170, 60], [190, 68], [190, 96], [176, 112], [156, 108], [146, 92]]), '#e2b090');
    fill(sm([[146, 76], [160, 58], [186, 60], [192, 76], [176, 70], [158, 80]]), '#6a5040');
    fill(sm([[196, 160], [218, 158], [224, 172], [206, 180]]), '#e2b090');
    const SHIRT = sm([[400, 30], [440, 0], [540, 0], [530, 60], [500, 80], [470, 110], [440, 140], [430, 180], [418, 186], [412, 150], [420, 110], [410, 80]]);
    fill(SHIRT, '#f2f2f2');
    clipA(SHIRT, () => { a.save(); a.translate(450, 60); a.rotate(0.3); a.fillStyle = '#121214'; for (let k = -12; k < 12; k++) a.fillRect(k * 12, -200, 6, 400); a.restore(); });
    fill(sm([[360, 50], [380, 24], [410, 30], [416, 60], [400, 92], [376, 94], [362, 76]]), '#9c7c70');
    fill(sm([[430, 186], [446, 182], [450, 204], [436, 208]]), '#d8a890');

    // ── blue spiky bursts ──
    const burst = (x, y, r0, r1, n, a0, a1, seed) => { const rr = rng(seed); for (let i = 0; i < n; i++) { const an = a0 + (a1 - a0) * i / (n - 1) + (rr() - 0.5) * 0.08, L = r1 * (0.75 + rr() * 0.3);
      fill(poly([[x + Math.cos(an - 0.04) * r0, y + Math.sin(an - 0.04) * r0], [x + Math.cos(an) * L, y + Math.sin(an) * L], [x + Math.cos(an + 0.04) * r0, y + Math.sin(an + 0.04) * r0]]), '#a8cce6'); } };
    burst(330, 192, 16, 70, 30, -3.0, -0.1, 1); burst(560, 40, 14, 55, 24, -3.1, 0.2, 2); burst(505, 125, 10, 45, 16, 2.0, 4.6, 3);
    burst(480, 200, 10, 40, 14, 2.4, 4.4, 4); burst(245, 312, 10, 40, 18, -3.0, 0.3, 5); burst(165, 625, 10, 40, 18, -2.8, -0.4, 6); burst(712, 488, 10, 48, 20, 2.2, 4.8, 7);
    // lollipop spike and frosted worm
    burst(218, 128, 6, 34, 9, 0, 6.0, 8);
    R.pipe(line([[200, 290], [204, 230], [210, 170], [214, 132]]), 18, '#c4d8d0', 0.2, 0.15, 2);
    R.pipe(line([[205, 290], [208, 230], [213, 170]]), 5, '#e8d890', 0.3, 0.05, 2);
    R.pipe(line([[262, 222], [290, 190], [330, 182], [380, 186], [430, 200], [470, 224]]), 16, '#dcd8c8', 0.15, 0.12, 2);
    R.pipe(line([[262, 222], [290, 190], [330, 182], [380, 186], [430, 200], [470, 224]]), 6, '#b8d8b0', 0.25, 0.04, 2);

    // ── frosted lavender pad ──
    const PAD = sm([[10, 350], [24, 328], [60, 302], [110, 282], [150, 266], [195, 284], [230, 320], [262, 355], [300, 390], [350, 414], [400, 432], [450, 438], [500, 444], [540, 464], [570, 496], [580, 530], [572, 556], [540, 578], [500, 588], [440, 594], [400, 592], [350, 580], [300, 566], [250, 556], [200, 548], [150, 540], [100, 532], [60, 526], [36, 514], [26, 480], [16, 440], [10, 400]]);
    R.dome(PAD, '#d6c6c8', 0.05, 0.06, 20, 3);
    clipA(PAD, () => { const r = rng(12); for (let i = 0; i < 70; i++) { let x = 30 + r() * 540, y = 300 + r() * 300; if (!a.isPointInPath(PAD, x * S, y * S)) continue; const pts = [[x, y]]; let an = r() * 6.28; for (let k = 0; k < 6; k++) { an += (r() - 0.5) * 2.4; x += Math.cos(an) * 8; y += Math.sin(an) * 8; pts.push([x, y]); } R.pipe(line(pts), 2.6, '#e8dcda', 0.1, 0.03, 3); } });
    // frosted rim
    R.pipe(PAD, 10, '#ece0de', 0.06, 0.05, 4);
    { const r = rng(14); const pts = [[10, 350], [24, 328], [60, 302], [110, 282], [150, 266], [195, 284], [230, 320], [262, 355], [300, 390], [350, 414], [400, 432], [450, 438], [500, 444], [540, 464], [570, 496], [580, 530], [572, 556], [540, 578], [500, 588], [440, 594], [400, 592], [350, 580], [300, 566], [250, 556], [200, 548], [150, 540], [100, 532], [60, 526], [36, 514], [26, 480], [16, 440], [10, 400]];
      for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; for (let k = 0; k < 8; k++) { const t = k / 8, x = p[0] + (q[0] - p[0]) * t, y = p[1] + (q[1] - p[1]) * t; R.bead(x + (r() - 0.5) * 6, y + (r() - 0.5) * 6, 2.5 + r() * 3, '#f0e6e4', 0.1, 0.05, 4); } } }
    fill(ellipseP(312, 468, 85, 37, 0.06), '#f2d5c8');
    R.flat(ellipseP(462, 524, 46, 22, 0.05), '#050505', 0, 0);
    clipA(ellipseP(462, 524, 46, 22, 0.05), () => img(ZEB));
    // dome, knob and flower lobe on the pad
    R.dome(ellipseP(150, 372, 76, 82, 0), '#cfc4c8', 0.06, 0.28, 60, 1);
    R.dome(circleP(84, 428, 26), '#cfc4c8', 0.06, 0.2, 22, 1);
    { const C = [[96, 236, 34], [120, 190, 21], [150, 226, 22], [130, 268, 20], [62, 262, 22], [70, 206, 20]], pts = [];
      for (let k = 0; k < 120; k++) { const an = k / 120 * 6.283, dx = Math.cos(an), dy = Math.sin(an); let best = 0;
        for (const [x, y, r] of C) { const ox = x - 96, oy = y - 236, b = ox * dx + oy * dy, q = b * b - (ox * ox + oy * oy - r * r); if (q >= 0) best = Math.max(best, b + Math.sqrt(q)); }
        pts.push([96 + dx * best, 236 + dy * best]); }
      R.dome(poly(pts), '#c8c4cc', 0.06, 0.24, 24, 1); }
    R.dome(sm([[40, 545], [130, 540], [200, 552], [180, 560], [100, 560]]), '#e4dcda', 0.1, 0.08, 6, 4);

    // ── sugar-frosted ribbons ──
    const RIB1 = sm([[445, 362], [500, 346], [560, 342], [620, 350], [680, 368], [730, 386], [730, 452], [700, 420], [640, 396], [580, 388], [520, 390], [470, 398], [445, 390]]);
    const RIB2 = sm([[30, 850], [100, 832], [200, 805], [300, 772], [400, 734], [500, 670], [600, 615], [700, 546], [730, 524], [730, 600], [700, 616], [600, 682], [500, 736], [400, 792], [300, 832], [200, 862], [100, 882], [40, 910], [26, 880]]);
    for (const [Rb, c0] of [[RIB1, [[445, 372], [560, 360], [640, 368], [730, 410]]], [RIB2, [[34, 878], [100, 857], [200, 834], [300, 802], [400, 763], [500, 703], [600, 648], [700, 581], [730, 562]]]]) {
      R.dome(Rb, '#e6d4d2', 0.08, 0.12, 18, 2);
      R.pipe(line(c0), 10, '#f2e4e2', 0.18, 0.06, 2);
      const r = rng(c0.length * 7); const T = Rb === RIB1 ? 260 : 600;
      for (let i = 0; i < T; i++) { const k = r() * (c0.length - 1), j = Math.floor(k), t = k - j, p = c0[j], q = c0[j + 1];
        const cx = p[0] + (q[0] - p[0]) * t, cy = p[1] + (q[1] - p[1]) * t, dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy);
        const side = r() < 0.5 ? -1 : 1, off = (Rb === RIB1 ? 22 : 34) * (0.75 + r() * 0.4);
        R.bead(cx - dy / L * off * side, cy + dx / L * off * side, 2.5 + r() * 3.5, '#f2ebe8', 0.12, 0.06, 4); }
    }
    // pink disk with frosted rim
    R.dome(ellipseP(340, 692, 66, 24, -0.08), '#e8d6d2', 0.06, 0.06, 10, 2);
    fill(poly([[300, 712], [400, 708], [400, 740], [300, 744]]), '#6a2a28');

    // ── tiger-striped clay creatures ──
    const HEAD = sm([[176, 640], [214, 616], [258, 612], [290, 640], [298, 690], [314, 712], [320, 748], [300, 770], [270, 764], [244, 740], [214, 730], [190, 710], [176, 680]]);
    const BODY = sm([[30, 720], [80, 690], [140, 680], [190, 700], [210, 740], [200, 770], [180, 790], [150, 800], [120, 790], [90, 780], [60, 790], [40, 800]]);
    const ARM = sm(lock([[150, 780], [180, 800], [200, 812], [216, 840], [232, 878]], 26, 18));
    const LEG = sm(lock([[60, 760], [40, 820], [26, 880], [20, 950], [24, 1030]], 50, 30));
    const LEG2 = sm(lock([[0, 650], [30, 640], [60, 610], [70, 590]], 22, 10));
    for (const B of [BODY, ARM, LEG2]) { R.dome(B, null, 0.1, 0.2, 18, 5); clipA(B, () => img(TIGER)); }
    R.dome(LEG, null, 0.1, 0.2, 20, 5); clipA(LEG, () => img(RAINLEG));
    R.dome(HEAD, null, 0.12, 0.26, 28, 5); clipA(HEAD, () => img(TIGER));
    R.dome(sm([[236, 692], [272, 690], [298, 700], [316, 720], [320, 748], [300, 770], [270, 764], [244, 740]]), '#6e86c0', 0.2, 0.2, 18, 5);
    fill(sm([[184, 690], [212, 684], [232, 700], [220, 720], [192, 716]]), '#d86a6a');
    fill(circleP(258, 734, 3), '#111'); fill(ellipseP(268, 708, 4, 3, 0), '#f0f0f0');
    // striped creature on the right
    const RLEG = sm(lock([[726, 500], [680, 530], [640, 548], [600, 560], [560, 580], [520, 610], [490, 640], [470, 680], [464, 690]], 30, 12));
    R.dome(RLEG, null, 0.1, 0.18, 14, 5); clipA(RLEG, () => img(TIGER));
    R.dome(sm(lock([[600, 556], [620, 530], [640, 506]], 22, 10)), null, 0.1, 0.15, 10, 5);
    // bottom-right creature and its tail
    const BRC = sm([[400, 1030], [430, 980], [500, 950], [580, 930], [610, 900], [640, 872], [676, 872], [700, 900], [726, 940], [726, 1030]]);
    R.dome(BRC, null, 0.1, 0.2, 30, 5); clipA(BRC, () => img(TIGER));
    R.dome(sm([[560, 950], [600, 900], [640, 872], [676, 872], [700, 900], [726, 950], [726, 990], [650, 980], [590, 975]]), '#6676b0', 0.15, 0.2, 26, 5);
    const TAIL = sm(lock([[274, 924], [290, 960], [320, 990], [360, 1010], [400, 1024]], 14, 20));
    R.dome(TAIL, null, 0.1, 0.12, 10, 5); clipA(TAIL, () => img(RAINLEG));
    // grey pompom balls
    for (const [x, y, r] of [[412, 422, 17], [528, 474, 15], [378, 728, 18], [420, 986, 18], [222, 340, 15]]) {
      R.bead(x, y, r, r === 15 && x < 300 ? '#c0a8a8' : '#949aa4', 0.2, 0.12, 4);
      const rr = rng(x); for (let k = 0; k < 30; k++) { const an = rr() * 6.283, d = rr() * r; R.bead(x + Math.cos(an) * d, y + Math.sin(an) * d, 2 + rr() * 1.6, null, 0.3, 0.03, 4); }
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.5, ao: 0.5 }),               // 1 matte clay
        E.mat({ dif: 1, spec: 0.35, shin: 24, wrap: 0.45, ao: 0.5, grain: 0.1 }),    // 2 frosted fondant
        E.mat({ dif: 1, spec: 0.15, shin: 14, wrap: 0.6, ao: 0.4 }),                 // 3 pad clay
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.6, grain: 0.3 }),      // 4 sugar crystals / pompom
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.45, ao: 0.5 }),               // 5 striped clay
      ],
      light: [-0.4, 0.62, 0.68], lc: [0.55, 0.55, 0.55], amb: [0.6, 0.6, 0.62],
      envTop: [1, 1, 1], envHor: [0.5, 0.5, 0.52], envBot: [0.1, 0.1, 0.12], envK: [0.2, 0.6, 0.2, 0],
      r1: 2, r2: 10, k: [0, 0.6, 0.4, 60], shadow: [-4, 6, 0.35, 8]
    });
    E.grain(0.04, 6);
  }
});
