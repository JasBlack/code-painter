'use strict';
// u021 — "Toothy gallery diorama": a gallery room under a starry ceiling — a sky-blue grinning mask on a
// khaki slab of op-art zebra waves, white cloud blobs, rainbow-striped figures, a chrome ring and a white plinth
// with a glass gem, all on a radiating rainbow-stripe floor.
REC.register('u021', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, clip) => { a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const poly = (pts, sm = false) => P(pts, true, sm);
    const line = (pts, wd, col) => { a.lineWidth = wd; a.strokeStyle = col; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, false, true)); };

    // ── room: starry ceiling, top band, striped side walls, radiating rainbow floor ──
    img(E.fx(`
      vec3 pal(float k){
        float h = hash(vec2(k, 3.1));
        if (h < 0.13) return vec3(0.92, 0.42, 0.50);
        if (h < 0.24) return vec3(0.95, 0.62, 0.38);
        if (h < 0.36) return vec3(0.95, 0.85, 0.40);
        if (h < 0.48) return vec3(0.45, 0.72, 0.55);
        if (h < 0.58) return vec3(0.30, 0.70, 0.80);
        if (h < 0.68) return vec3(0.30, 0.38, 0.75);
        if (h < 0.77) return vec3(0.55, 0.40, 0.70);
        if (h < 0.86) return vec3(0.06, 0.05, 0.08);
        if (h < 0.93) return vec3(0.90, 0.90, 0.94);
        return vec3(0.55, 0.52, 0.58);
      }
      vec3 fx(vec2 uv, vec2 p){
        // starry black
        vec3 c = vec3(0.02, 0.015, 0.03);
        float st = hash(floor(p / 2.));
        c += vec3(0.85, 0.85, 0.95) * step(0.994, st) * (0.4 + 0.6 * hash(floor(p / 2.) + 3.));
        // top band
        if (p.y < 29.) c = vec3(0.29, 0.23, 0.19);
        if (p.y < 22.) c = vec3(0.96, 0.92, 0.84);
        if (p.y < 14.) c = p.x < 150. ? vec3(0.29, 0.54, 0.9) : vec3(0.95, 0.94, 0.96);
        if (p.y > 20. && p.y < 30. && p.x > 655.) c = vec3(0.24, 0.48, 0.86);
        // left wall: stripes radiating from the room's vanishing point
        vec2 d = p - vec2(600., 520.);
        float th = atan(d.y, d.x);
        if (p.x < 170. - (p.y - 30.) * 0.1 && p.y > 22. && p.y < 580.) {
          float k = floor(th * 95.);
          vec3 w = mix(vec3(0.30, 0.30, 0.34), vec3(0.40, 0.43, 0.56), step(0.5, hash(vec2(k, 1.))));
          w = mix(w, vec3(0.86, 0.84, 0.86), step(0.75, hash(vec2(k, 2.))));
          w = mix(w, c, step(p.y, 130. + p.x * 0.45));
          w = mix(w, vec3(0.92, 0.88, 0.72), smoothstep(6., 0., abs(p.y - 40. - p.x * 0.75)) + smoothstep(9., 0., abs(p.y - 110. - p.x * 0.72)) * step(p.x, 150.));
          c = w;
        }
        // right wall
        vec2 d2 = p - vec2(520., 470.);
        if (p.x > 655. + (p.y - 120.) * 0.0 && p.y > 120. && p.y < 600.) {
          float k = floor(atan(d2.y, d2.x) * 80.);
          c = mix(vec3(0.12, 0.13, 0.25), vec3(0.30, 0.45, 0.78), step(0.55, hash(vec2(k, 5.))));
          c = mix(c, vec3(0.85, 0.86, 0.9), step(0.85, hash(vec2(k, 6.))));
        }
        // floor
        vec2 f = p - vec2(530., 790.);
        if (p.y > 800. && p.x < 690.) {
          float k = floor(atan(f.y, f.x) * 72.);
          c = pal(k) * (0.92 + 0.12 * hash(vec2(k, 9.)));
        }
        return c; }`));

    // sky window: blue with a peach sunset band
    const sky1 = poly([[725, 20], [685, 24], [672, 41], [675, 64], [669, 89], [645, 106], [625, 105], [597, 90], [566, 93], [541, 107], [515, 139], [512, 154], [624, 156], [725, 150]], true);
    const sky2 = poly([[484, 187], [504, 199], [509, 224], [500, 243], [525, 253], [569, 252], [597, 234], [618, 217], [641, 222], [648, 239], [661, 246], [676, 224], [711, 169], [711, 164], [531, 164], [484, 183]], true);
    R.flat(sky1, '#3a82e0', 0.01, 0);
    R.flat(sky2, '#e8b99a', 0.01, 0);
    clipA(sky2, () => { a.fillStyle = '#3a82e0'; a.fill(poly([[480, 170], [540, 168], [550, 210], [530, 230], [600, 240], [620, 260], [480, 260]], true)); });
    for (const s of [sky1, sky2]) { a.lineWidth = 4; a.strokeStyle = '#6a5040'; a.stroke(s); }
    // dark room on the right and the back wall
    R.flat(poly([[560, 380], [656, 330], [656, 600], [726, 600], [726, 860], [470, 860], [470, 560]]), '#22203a', 0.01, 0);
    R.flat(poly([[560, 560], [656, 556], [656, 660], [560, 670]]), '#9a96a0', 0.01, 0);
    R.flat(poly([[588, 330], [640, 326], [640, 440], [590, 444]]), '#5c88b8', 0.01, 0);
    soft(x => { const r = rng(8); for (let i = 0; i < 30; i++) fe(x, 590 + r() * 50, 330 + r() * 110, 3 + r() * 6, 2 + r() * 4, r() * 3, r() < 0.5 ? '#a8d0f0' : '#2a4878'); }, 1.5, 1, poly([[588, 330], [640, 326], [640, 440], [590, 444]]));

    // ── the khaki slab ──
    const slab = P([[0, 572], [40, 540], [110, 520], [190, 505], [205, 430], [196, 330], [214, 200], [250, 168], [320, 160], [400, 172], [450, 200], [478, 250], [470, 330], [440, 420],
      [420, 520], [330, 600], [300, 700], [340, 770], [440, 800], [446, 948], [330, 925], [180, 895], [60, 868], [0, 850]], true, true);
    R.dome(slab, '#a28e7e', 0.04, 0.06, 30, 1);
    soft(x => { fe(x, 100, 700, 120, 90, 0, '#a08a78'); fe(x, 330, 260, 90, 60, 0.3, '#a59a74'); fe(x, 160, 850, 150, 30, 0.1, '#5a4a40'); }, 26, 0.7, slab);
    R.pipe(P([[0, 852], [60, 870], [180, 897], [330, 927], [446, 950]], false), 14, '#4a3c34', 0.06, 0.04, 1);

    // ── op-art zebra waves ──
    const zv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = fbm(p * 0.006 + vec2(1.3, 4.2));
      vec2 c1 = vec2(470., 330.), c2 = vec2(330., 560.);
      float r1 = length((p - c1) * vec2(1., 1.25)), r2 = length((p - c2) * vec2(1.1, 0.9));
      float m = smoothstep(380., 470., p.y + p.x * 0.3);
      float ph = mix((p.x + 16. * sin(p.y * 0.035 + w * 5.) + 0.15 * (p.y - 300.)) / 10.5, r2 / 11.5 + w * 6., m);
      float s = sin(6.2832 * ph);
      return vec3(smoothstep(-0.18, 0.18, s)) * vec3(0.93, 0.93, 0.95) + vec3(0.03); }`);
    const zebA = P([[405, 330], [425, 290], [460, 262], [510, 256], [560, 252], [610, 238], [645, 240], [650, 330], [600, 330], [586, 372], [550, 368], [510, 380], [480, 400],
      [470, 440], [450, 500], [430, 540], [400, 520], [400, 450], [410, 400]], true, true);
    const zebB = P([[205, 525], [240, 470], [300, 440], [380, 430], [430, 450], [470, 500], [480, 560], [450, 620], [430, 690], [350, 700], [300, 690], [260, 640], [215, 600]], true, true);
    // upper patch: fine stripes fanning out of a focus below the wings (angles measured from the reference)
    const zA = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(492., 450.);
      float ph = atan(d.x, -d.y) * 17.5 + 1.6 * (fbm(p * 0.012 + 2.) - .5) + 0.8 * sin(length(d) * 0.05);
      return vec3(smoothstep(-0.2, 0.2, sin(6.2832 * ph))) * vec3(0.9) + vec3(0.04); }`);
    for (const z of [zebA, zebB]) R.flat(z, null, 0.07, 1);
    img(zv, zebB); img(zA, zebA);

    // ── grinning sky-blue mask ──
    const mask = P([[214, 210], [262, 176], [320, 168], [360, 170], [384, 196], [400, 260], [420, 310], [410, 360], [380, 400], [330, 425], [270, 432], [222, 420], [202, 380], [196, 320],
      [200, 260]], true, true);
    R.dome(mask, '#86bce0', 0.1, 0.12, 24, 1);
    const rimO = P([[330, 172], [380, 168], [430, 186], [462, 214], [470, 252], [460, 290], [430, 296], [404, 270], [384, 220], [356, 186]], true, true);
    R.dome(rimO, '#a49c74', 0.1, 0.1, 14, 1);
    R.flat(ellipseP(412, 248, 38, 28, 0.25), '#2c2c34', 0.14, 1);
    R.flat(ellipseP(290, 460, 50, 22, 0.05), '#6a6a6e', 0.08, 1);
    const mouth = P([[232, 352], [250, 320], [286, 302], [330, 296], [372, 304], [396, 326], [386, 360], [350, 386], [302, 398], [256, 394], [236, 380]], true, true);
    R.flat(mouth, '#050407', 0.12, 0);
    // teeth: a ring of white pegs round the mouth
    {
      const cx = 314, cy = 350, rx = 92, ry = 56;
      for (let i = 0; i < 26; i++) {
        const t = i / 26 * 6.283, x = cx + Math.cos(t) * rx, y = cy + Math.sin(t) * ry * (Math.sin(t) > 0 ? 0.98 : 0.92);
        R.dome(ellipseP(x, y, 11, 15, t + 1.57), '#f4f4f8', 0.18, 0.12, 6, 2);
      }
    }
    // white tentacle crown
    for (const pts of [[[236, 236], [222, 200], [230, 160], [236, 110]], [[248, 230], [262, 190], [268, 160], [274, 138]], [[226, 250], [196, 236], [176, 220], [170, 196]],
      [[230, 262], [196, 262], [178, 280], [184, 310]], [[240, 270], [220, 296], [214, 320]], [[255, 250], [230, 200], [210, 180], [196, 178]], [[466, 210], [462, 170], [456, 130]],
      [[226, 240], [190, 224], [160, 230], [140, 260], [150, 285]], [[230, 250], [190, 250], [166, 270], [170, 300]], [[236, 258], [206, 280], [196, 310], [204, 330]],
      [[244, 236], [212, 214], [180, 200], [150, 205]], [[236, 226], [204, 196], [184, 172]]])
      R.pipe(P(pts, false), 15, '#f2f2f6', 0.2, 0.12, 2);
    R.dome(ellipseP(250, 222, 28, 24, 0), '#f2f2f6', 0.22, 0.14, 12, 2);
    for (const [x, y, r] of [[236, 106, 8], [274, 136, 7], [453, 125, 7]]) R.bead(x, y, r, '#f4f4f8', 0.3, 0.1, 2);

    // ── white blobs and clouds ──
    const W2 = '#f0f0f4';
    const plinth = P([[73, 447], [138, 432], [139, 410], [109, 404], [116, 389], [150, 372], [190, 350], [204, 365], [214, 420], [222, 470], [220, 515], [160, 520], [73, 520]], true, true);
    R.dome(plinth, W2, 0.1, 0.14, 14, 2);
    R.dome(P([[40, 545], [90, 525], [180, 515], [240, 520], [230, 540], [120, 548], [50, 556]], true, true), W2, 0.1, 0.1, 8, 2);
    // worm loop on the slab
    R.pipe(P([[90, 640], [100, 600], [80, 570], [40, 580], [20, 620], [40, 670], [70, 712], [110, 742], [158, 752]], false), 34, W2, 0.1, 0.18, 2);
    R.flat(circleP(88, 600, 9), '#6a5a4c', 0.2, 1);
    R.dome(P([[0, 800], [30, 784], [60, 766], [88, 772], [106, 800], [100, 822], [60, 820], [30, 812], [0, 832]], true, true), W2, 0.08, 0.1, 10, 2);
    R.dome(P([[230, 770], [256, 762], [262, 784], [236, 790]], true, true), W2, 0.1, 0.06, 6, 2);
    // big white cloud cluster
    for (const [x, y, r] of [[370, 560, 40], [420, 600, 44], [372, 640, 46], [440, 670, 34], [400, 690, 36], [350, 690, 30]]) R.bead(x, y, r, W2, 0.12, 0.2, 2);
    R.dome(rrect(440, 650, 130, 60, 26), W2, 0.12, 0.16, 18, 2);
    for (let i = 0; i < 4; i++) R.groove(P([[472 + i * 26, 656], [472 + i * 26, 702]], false), 5, '#c8c8d0', 0.26, 0.05, 2);
    // pale-blue clouds with white rims
    const cloud = (pts, sd) => { const p = P(ragged(pts, 0, pts.length, 14, 7, sd), true, true); R.dome(p, '#f4f4f8', 0.1, 0.08, 6, 2); R.dome(P(pts, true, true), '#b8dcf4', 0.16, 0.04, 8, 1); };
    cloud([[375, 505], [385, 470], [410, 445], [420, 425], [445, 412], [470, 400], [500, 380], [530, 382], [560, 372], [590, 390], [586, 430], [580, 470], [560, 520], [520, 560],
      [470, 560], [455, 530], [440, 525], [420, 512], [400, 515]], 3);
    R.flat(P([[470, 482], [492, 470], [502, 455], [522, 450], [532, 430], [548, 418], [575, 412], [578, 450], [570, 520], [540, 550], [480, 552], [462, 530]], true, true), '#262440', 0.18, 0);
    cloud([[440, 600], [455, 570], [480, 560], [510, 555], [540, 550], [565, 560], [570, 580], [545, 605], [510, 615], [470, 625]], 5);
    // glossy white balls
    for (const [x, y, r] of [[480, 215, 26], [672, 355, 32], [710, 292, 22], [708, 362, 10]]) R.bead(x, y, r, '#f4f4f8', 0.2, 0.3, 2);

    // ── figures ──
    // gold-and-black statue (top left)
    R.flat(rrect(96, 280, 120, 120, 2), '#2a56b8', 0.03, 0);
    for (let i = 0; i < 6; i++) R.flat(rrect(160 + i * 7, 296, 3, 90, 1), '#d8e0f0', 0.04, 0);
    R.dome(circleP(140, 362, 14), '#101014', 0.05, 0.05, 6, 3);
    const statue = P([[96, 176], [120, 158], [168, 160], [176, 190], [168, 230], [150, 262], [118, 268], [98, 240], [92, 206]], true, true);
    for (const pth of [[[130, 176], [96, 168], [64, 178], [44, 200]], [[112, 250], [84, 262], [66, 290], [70, 320]], [[140, 258], [124, 290], [108, 330], [104, 342]]])
      R.pipe(P(pth, false), 22, '#b8a448', 0.12, 0.12, 3);
    R.dome(statue, '#c0aa48', 0.12, 0.16, 16, 3);
    soft(x => { fe(x, 136, 214, 22, 30, 0.4, '#1a1a20'); fe(x, 90, 176, 14, 8, -0.3, '#1a1a20'); fe(x, 92, 284, 10, 18, 0.3, '#3a5aa0'); fe(x, 156, 196, 8, 16, 0, '#3a6ac0'); fe(x, 118, 300, 8, 20, 0.4, '#1a1a20'); }, 5, 0.9);
    R.dome(ellipseP(162, 142, 16, 20, 0), '#6a4c38', 0.2, 0.12, 10, 4);
    R.dome(ellipseP(160, 128, 15, 10, 0), '#2a2420', 0.24, 0.06, 6, 4);
    // small dark figurine left
    R.dome(P([[20, 420], [42, 404], [58, 420], [56, 480], [50, 560], [24, 560], [16, 480]], true, true), '#283048', 0.1, 0.12, 10, 3);
    R.bead(16, 360, 22, '#3a6ac8', 0.15, 0.2, 2);
    // rainbow-striped stooping figure
    const fig = P([[256, 572], [290, 566], [302, 580], [300, 610], [280, 640], [250, 660], [240, 700], [236, 760], [246, 830], [262, 880], [300, 930], [300, 948], [262, 950],
      [236, 920], [218, 950], [160, 932], [190, 900], [196, 830], [184, 760], [176, 720], [150, 700], [160, 660], [196, 630], [230, 600]], true, true);
    R.dome(fig, '#c8c070', 0.15, 0.16, 18, 4);
    clipA(fig, () => { const cols = ['#e86078', '#f0b040', '#58b878', '#4a70d0', '#9060c0', '#f0e060', '#40b8c8']; for (let i = 0; i < 40; i++) line([[150 + i * 4, 560], [148 + i * 4 + Math.sin(i) * 10, 760], [150 + i * 4, 960]], 2.6, cols[i % 7]); });
    // blue imp
    R.dome(P([[276, 720], [300, 700], [330, 712], [350, 740], [360, 780], [330, 800], [300, 790], [290, 760]], true, true), '#4a78d0', 0.15, 0.18, 14, 4);
    R.bead(300, 726, 22, '#4a78d0', 0.2, 0.2, 4); R.bead(384, 796, 10, '#4a78d0', 0.2, 0.1, 4);
    // blue diver on the right with striped arms
    const diver = P([[650, 420], [680, 396], [716, 398], [726, 420], [726, 760], [700, 700], [690, 620], [650, 560], [640, 520], [652, 470]], true, true);
    R.dome(diver, '#3a6ad0', 0.15, 0.2, 20, 4);
    R.dome(ellipseP(682, 452, 18, 22, 0), '#d8b8a0', 0.25, 0.1, 10, 4);
    R.dome(P([[700, 470], [726, 460], [726, 600], [706, 580], [698, 520]], true, true), '#e8e6ee', 0.22, 0.1, 10, 4);
    R.pipe(P([[700, 520], [640, 500], [600, 470], [580, 430], [560, 420]], false), 18, '#c8c070', 0.2, 0.14, 4);
    R.pipe(P([[640, 540], [600, 548], [560, 548], [545, 552]], false), 20, '#3a6ad0', 0.2, 0.14, 4);
    R.pipe(P([[710, 580], [690, 640], [660, 690], [620, 720], [580, 740], [556, 750]], false), 20, '#c8c070', 0.2, 0.14, 4);
    for (const pth of [[[700, 520], [640, 500], [600, 470], [580, 430], [560, 420]], [[710, 580], [690, 640], [660, 690], [620, 720], [580, 740], [556, 750]]]) {
      const p = P(pth, false); a.save(); a.setLineDash([5, 5]); a.lineWidth = 16; a.strokeStyle = '#e06878'; a.stroke(p); a.lineDashOffset = 5; a.strokeStyle = '#40a8d0'; a.lineWidth = 10; a.stroke(p); a.restore();
    }
    // dark trousered legs under the clouds
    R.dome(P([[470, 704], [500, 700], [506, 780], [486, 800], [462, 790]], true, true), '#1a2440', 0.1, 0.1, 10, 3);

    // ── chrome ring, figurine table, glass gem, white plinth ──
    R.flat(P([[300, 700], [470, 700], [500, 790], [500, 850], [440, 870], [260, 850], [250, 790]], true, true), '#8c8590', 0.06, 0);
    { const r = rng(17); for (let i = 0; i < 26; i++) R.bead(400 + r() * 100, 780 + r() * 70, 2 + r() * 4, r() < 0.5 ? '#1a1a1e' : '#c8c0b8', 0.1, 0.06, 3); }
    R.pipe(P([[240, 830], [290, 834]], false), 12, '#5a98e0', 0.15, 0.1, 3);
    R.bead(232, 830, 14, '#5a98e0', 0.15, 0.12, 3);
    R.dome(ellipseP(366, 850, 72, 36, 0), '#b8bcc8', 0.15, 0.2, 18, 3);
    R.dome(ellipseP(366, 840, 66, 28, 0), '#e8eaf0', 0.2, 0.12, 12, 3);
    R.flat(ellipseP(366, 836, 40, 14, 0), '#3a3a44', 0.22, 3);
    const gem = poly([[536, 742], [580, 760], [612, 810], [596, 860], [540, 872], [500, 840], [494, 790], [510, 760]]);
    R.dome(gem, '#c8ccd8', 0.12, 0.12, 22, 3);
    R.flat(poly([[570, 600], [626, 592], [650, 620], [630, 642], [580, 640]]), '#c0c8d8', 0.06, 3);
    const box = poly([[431, 879], [520, 860], [600, 866], [687, 883], [696, 930], [690, 1030], [630, 1030], [631, 985], [442, 941], [427, 915]], true);
    R.dome(box, '#ececf0', 0.1, 0.14, 12, 2);
    R.flat(poly([[442, 941], [631, 985], [630, 1030], [440, 1030]]), null, 0.02, 0);
    R.flat(poly([[631, 985], [638, 946], [646, 917], [690, 892], [696, 930], [690, 1030], [630, 1030]]), '#8a8084', 0.1, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.5 }),                                  // 1 matte
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.4, coat: 0.12, ao: 0.5 }),                      // 2 glossy white
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.1, shin: 60, rim: 0.4, ao: 0.4 }),                      // 3 chrome / glass
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.3, ao: 0.5 })                                   // 4 plastic figures
      ],
      light: [-0.3, 0.6, 0.75], lc: [0.6, 0.6, 0.62], amb: [0.5, 0.5, 0.53],
      envTop: [0.95, 0.95, 1.0], envHor: [0.45, 0.48, 0.58], envBot: [0.1, 0.1, 0.14], envK: [0.3, 0.9, 0.3, 0],
      rimC: [0.3, 0.35, 0.45], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [5, 7, 0.45, 6]
    });
    { const r = rng(31); o.fillStyle = '#ffffff'; for (let i = 0; i < 300; i++) { o.globalAlpha = 0.3 + r() * 0.6; o.fillRect(r() * 726, r() * 1024, 1.2, 1.2); } o.globalAlpha = 1; }
    o.save(); o.lineWidth = 1.4; o.strokeStyle = '#1a1a1e'; o.stroke(P([[588, 966], [596, 958], [600, 968], [610, 960], [616, 968], [628, 962], [636, 968]], false, true)); o.restore();
    E.grain(0.04, 21);
  }
});
