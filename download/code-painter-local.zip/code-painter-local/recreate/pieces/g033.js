'use strict';
// g033 — "Lilac serpent vase": a cel-shaded comic collage — a lilac glass vase sprouting a snake arm in front
// of starry space, saw-edged grey leaves, zebra zigzags and socks, a slate panel with blue tiles, a golden light
// column, beige pebbles and a big zebra sphere.
REC.register('g033', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = o.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = o.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const ink = (path, wd = 3) => K(path, '#0c0a0c', wd);
    // saw-tooth outline: resample a polygon and push alternate points outward
    const saw = (pts, step, amp) => {
      const out = [], n = pts.length; let A = 0;
      for (let i = 0; i < n; i++) { const p = pts[i], q = pts[(i + 1) % n]; A += p[0] * q[1] - q[0] * p[1]; }
      const sg = A > 0 ? -1 : 1;
      for (let i = 0; i < n; i++) {
        const p = pts[i], q = pts[(i + 1) % n], L = Math.hypot(q[0] - p[0], q[1] - p[1]), k = Math.max(1, Math.round(L / step));
        const nx = sg * (q[1] - p[1]) / L, ny = -sg * (q[0] - p[0]) / L;
        for (let j = 0; j < k; j++) { const u = j / k, d = (j % 2 ? amp : 0); out.push([p[0] + (q[0] - p[0]) * u + nx * d, p[1] + (q[1] - p[1]) * u + ny * d]); }
      }
      return P(out, true, false);
    };
    // stripe textures
    const zig = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float z = abs(fract(p.x / 62.) - .5) * 52.; float s = sin(6.2832 * (p.y - 0.3 * p.x + z) / /*zp*/30. + /*zf*/0.);
      return vec3(smoothstep(-.15, .15, s)) * .93 + .04; }`));
    const wav = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = sin(6.2832 * (p.x + 9. * sin(p.y * 0.09) + 30. * fbm(p * 0.008)) / 26.);
      return vec3(smoothstep(-.2, .2, s)) * .93 + .04; }`));
    const band = (dx, dy, per) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = sin(6.2832 * (dot(p, normalize(uD)) + 6. * sin(p.x * 0.02)) / uP);
      return vec3(smoothstep(-.15, .15, s)) * .93 + .04; }`, { uD: [dx, dy], uP: per }));
    const sphere = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 c = vec2(820., 870.); float r = 292., th = /*sr*/0.2;
      vec2 q = mat2(cos(th), sin(th), -sin(th), cos(th)) * (p - c); float yy = clamp(q.y / r, -.99, .99);
      float xx = clamp(q.x / (r * sqrt(1. - yy * yy)), -.999, .999); float s = sin(asin(xx) * /*sn*/22. + /*sp*/0.0);
      return vec3(smoothstep(-.45, -.05, s)) * .9 + .05; }`));

    // ── space: black, nebula haze, stars ──
    F(rrect(0, 0, 726, 1024, 0), '#060507');
    blurred(40, () => { F(ellipseP(470, 560, 90, 110, 0), 'rgba(90,70,140,0.55)'); F(ellipseP(420, 480, 70, 70, 0), 'rgba(90,170,140,0.7)'); F(ellipseP(440, 560, 50, 60, 0), 'rgba(80,120,190,0.6)'); F(ellipseP(520, 470, 70, 50, 0), 'rgba(110,80,160,0.5)'); });
    { const r = rng(33); o.fillStyle = '#f4f2ff'; for (let i = 0; i < 500; i++) { const x = 380 + r() * 346, y = 420 + r() * 600; o.globalAlpha = 0.3 + r() * 0.6; o.fillRect(x, y, 0.9, 0.9); } o.globalAlpha = 1; }

    // ── olive disc (top right) with beige ring ──
    const olive = P([[372, -10], [736, -10], [736, 142], [650, 136], [560, 126], [480, 110], [420, 80], [384, 36]]);
    F(olive, '#706b56'); ink(olive, 3);
    F(ellipseP(518, 6, 64, 40, 0), '#d6cecb'); F(ellipseP(518, 2, 50, 30, 0), '#a8a08a'); ink(ellipseP(518, 6, 64, 40, 0), 2.5);
    K(P([[640, 50], [670, 46], [700, 52]], false), '#2a2820', 2); K(P([[560, 72], [580, 70]], false), '#2a2820', 2);

    // ── slate panel with sockets and blue tiles ──
    const panel = P([[470, 150], [500, 108], [560, 96], [640, 98], [700, 112], [736, 126], [736, 448], [690, 432], [620, 404], [550, 370], [490, 338], [466, 300], [462, 220]]);
    F(panel, lin(460, 100, 726, 440, [[0, '#5e626e'], [1, '#575b67']])); ink(panel, 5);
    for (const [x, y, rr] of [[606, 152, 25], [668, 188, 25], [536, 246, 28], [598, 288, 26], [660, 322, 25], [716, 232, 22], [718, 366, 22]]) { K(circleP(x, y, rr), '#14161c', 3); K(circleP(x - 2, y - 2, rr - 3), 'rgba(140,146,160,0.35)', 1.2); }
    const tile = (x, y, w, h, rot) => { o.save(); o.translate(x, y); o.rotate(rot); F(rrect(-w / 2, -h / 2, w, h, 1), '#96dcf8'); o.restore(); };
    tile(568, 196, 42, 22, 0.42); tile(632, 240, 42, 22, 0.42); tile(698, 280, 42, 22, 0.42);
    for (let i = 0; i < 6; i++) F(circleP(612 + i * 6, 362 - i * 4, 1.8), '#f0f0f4');

    // ── grey-green stippled saw leaf ──
    const sage = saw([[232, 60], [262, 34], [306, 36], [346, 46], [380, 70], [414, 120], [446, 180], [468, 250], [470, 320], [446, 366], [400, 360], [330, 330], [270, 290], [240, 200], [228, 120]], 9, 7);
    K(sage, '#f4f0ea', 8); F(sage, '#929894');
    C(sage, () => { const r = rng(7); o.fillStyle = '#1a1c1c'; for (let i = 0; i < 260; i++) o.fillRect(230 + r() * 240, 30 + r() * 340, 1.2, 1.2); });
    tile(346, 88, 22, 30, -0.5); tile(373, 126, 22, 30, -0.5); tile(407, 181, 24, 34, -0.45);
    F(circleP(372, 48, 14), '#f6f6f2'); ink(circleP(372, 48, 14), 2);

    // ── light column (left), gold rail, blue glass slab ──
    F(rrect(-10, 60, 104, 700, 0), lin(0, 0, 95, 0, [[0, '#dcc8a6'], [0.35, '#eadabc'], [0.6, '#cab896'], [0.8, '#847a70'], [1, '#bcac90']]));
    blurred(14, () => { for (const y of [130, 230, 330, 430, 530, 630]) F(ellipseP(32, y, 30, 40, 0), 'rgba(255,255,240,0.9)'); });
    F(rrect(94, 110, 28, 560, 0), lin(94, 0, 122, 0, [[0, '#8a6828'], [0.4, '#f0c650'], [1, '#b8902e']])); ink(P([[94, 110], [94, 670]], false), 2); ink(P([[122, 110], [122, 670]], false), 2);
    const slab = rrect(120, 160, 130, 500, 4);
    F(slab, lin(120, 0, 250, 0, [[0, '#b8d4e0'], [0.3, '#e4f4fa'], [0.55, '#9ab4c4'], [0.8, '#d6eaf2'], [1, '#8aa4b4']]));
    C(slab, () => { for (const [x, w, c] of [[150, 6, 'rgba(255,255,255,0.8)'], [196, 3, 'rgba(255,255,255,0.7)'], [228, 10, 'rgba(60,80,110,0.25)']]) F(rrect(x, 160, w, 500, 0), c); });

    // ── zigzag band, zebra bow and sock ──
    const zz = P([[-10, -10], [300, -10], [296, 30], [250, 46], [200, 70], [150, 84], [100, 104], [50, 96], [-10, 84]]);
    K(zz, '#f4f0ea', 8); F(zz, zig); ink(zz, 2);
    const bow = P([[86, 150], [110, 112], [150, 96], [190, 70], [240, 62], [290, 78], [312, 120], [300, 180], [276, 220], [250, 252], [210, 252], [180, 236], [150, 262], [120, 266], [96, 236], [88, 190]]);
    K(bow, '#f4f0ea', 9); F(bow, wav); ink(bow, 2.5);
    F(ellipseP(130, 248, 14, 10, 0), '#0c0a0c'); F(ellipseP(125, 245, 4, 3, 0), '#f4f0ea');
    const sock = P([[228, 250], [290, 250], [276, 300], [270, 350], [274, 400], [280, 452], [230, 452], [176, 432], [164, 412], [180, 390], [200, 350], [216, 300]]);
    K(sock, '#f4f0ea', 8); F(sock, band(0.15, 1, 26)); ink(sock, 2.5);

    // ── teal glass block ──
    const block = P([[146, 420], [176, 404], [250, 410], [270, 440], [300, 560], [350, 560], [350, 780], [262, 800], [150, 800], [140, 640]]);
    F(block, lin(140, 0, 350, 0, [[0, '#7c8a94'], [0.4, '#8c9a9e'], [1, '#909c9a']])); ink(block, 3);
    K(P([[176, 404], [186, 440], [186, 800]], false), '#2a3036', 1.5);
    blurred(2, () => { K(ellipseP(290, 812, 60, 40, -0.2), 'rgba(214,216,216,0.9)', 16); K(ellipseP(262, 790, 34, 22, -0.3), 'rgba(226,226,226,0.8)', 10); });

    // ── lilac saw leaf with glass bead ──
    const leaf = saw([[316, 196], [346, 220], [384, 250], [412, 300], [440, 360], [452, 420], [446, 470], [420, 520], [380, 550], [330, 556], [296, 530], [270, 470], [258, 400], [262, 320], [282, 250]], 9, 7);
    K(leaf, '#f6f2ee', 9); F(leaf, lin(260, 200, 450, 560, [[0, '#c6bec4'], [1, '#b8afb6']])); ink(leaf, 2);
    F(rrect(308, 282, 5, 180, 2), '#f8f6f6');
    F(circleP(368, 383, 6), '#0a0a0a'); F(circleP(334, 488, 5), '#0a0a0a');

    // ── the vase + snake arm ──
    const arm = P([[392, 612], [460, 606], [540, 600], [600, 586], [632, 540], [642, 478], [626, 420], [592, 380], [546, 364], [506, 380], [486, 420], [494, 466], [520, 498]], false);
    K(arm, '#2a2840', 52); K(arm, '#f6f2ee', 46); K(arm, lin(480, 360, 640, 620, [[0, '#d4ccd0'], [1, '#c4bcc2']]), 36);
    K(arm, 'rgba(255,255,255,0.35)', 8);
    F(ellipseP(522, 500, 26, 20, 0.7), '#cac2c8'); F(circleP(507, 492, 4.5), '#0a0a0a'); F(circleP(527, 511, 6), '#0a0a0a');
    const vase = P([[340, 500], [372, 492], [404, 520], [394, 600], [388, 700], [392, 760], [404, 800], [420, 862], [436, 910], [442, 940], [440, 984], [400, 992], [300, 988], [278, 960], [274, 910], [282, 850], [302, 800], [328, 760], [334, 700], [336, 600]]);
    K(vase, '#2a2840', 8); K(vase, '#f6f2ee', 5);
    F(vase, lin(270, 0, 455, 0, [[0, '#b0a8b0'], [0.3, '#ccc4ca'], [0.7, '#d2cad0'], [1, '#a8a0aa']]));
    C(vase, () => {
      F(rrect(338, 560, 44, 420, 22), lin(0, 560, 0, 980, [[0, 'rgba(110,170,240,0.0)'], [0.25, 'rgba(110,170,240,0.55)'], [0.5, 'rgba(90,210,140,0.5)'], [0.75, 'rgba(240,130,200,0.45)'], [1, 'rgba(120,160,240,0.0)']]));
      F(rrect(296, 640, 8, 340, 4), 'rgba(255,255,255,0.5)'); F(circleP(414, 900, 6), '#ffffff'); F(circleP(288, 940, 7), 'rgba(255,255,255,0.8)');
    });
    // green glass bead in the leaf
    const bead = ellipseP(380, 462, 30, 40, 0.15);
    F(bead, rad(372, 448, 44, [[0, '#d8e2b8'], [0.5, '#8ea46c'], [1, '#3c4a30']])); ink(bead, 3); F(circleP(371, 482, 5), '#f8f8f4');

    // ── zebra sphere + grey-blue block (right) ──
    const sph = circleP(820, 870, 292);
    K(sph, '#f4f0ea', 9); F(sph, sphere); ink(sph, 4);
    const gb = P([[640, 900], [662, 872], [736, 860], [736, 1034], [610, 1034], [612, 950]]);
    F(gb, '#5c606c'); ink(gb, 4);

    // ── bottom left: beige boat, green box, rock, zebra tube, white blob ──
    const boat = P([[-10, 696], [80, 668], [160, 650], [220, 640], [256, 646], [244, 690], [204, 740], [150, 786], [90, 812], [-10, 820]]);
    F(boat, lin(0, 640, 250, 820, [[0, '#d8c8b6'], [1, '#c8b8a6']])); ink(boat, 3);
    F(circleP(205, 715, 10), '#0a0a0a'); F(circleP(143, 752, 10), '#0a0a0a');
    for (let i = 0; i < 4; i++) K(P([[72 + i * 8, 700 - i * 2], [82 + i * 8, 718 - i * 2]], false), '#3a3430', 1.5);
    const box = P([[-10, 720], [60, 700], [88, 730], [96, 820], [70, 852], [-10, 864]]);
    F(box, '#848a72'); ink(box, 3);
    F(rrect(4, 720, 50, 22, 3), '#c8c8c0'); ink(rrect(4, 720, 50, 22, 3), 2);
    F(P(blob(78, 750, 18, 14, 4, 9, 0.2)), '#f05567'); F(circleP(22, 810, 12), '#f4d040'); ink(circleP(22, 810, 12), 2);
    const rock = P([[48, 868], [70, 834], [130, 812], [184, 802], [226, 820], [246, 856], [250, 912], [226, 952], [160, 962], [90, 956], [52, 924]]);
    F(rock, lin(40, 800, 250, 960, [[0, '#cbb8a2'], [1, '#b8a48e']])); ink(rock, 3);
    C(rock, () => { const r = rng(3); o.fillStyle = 'rgba(60,50,40,0.5)'; for (let i = 0; i < 120; i++) o.fillRect(50 + r() * 200, 800 + r() * 160, 1.4, 1.4); });
    F(P([[70, 838], [80, 832], [84, 856], [74, 862]]), '#f4d040');
    const tubeZ = P([[128, 930], [190, 878], [250, 852], [290, 868], [296, 930], [270, 990], [210, 1012], [150, 1006], [126, 980]]);
    F(tubeZ, band(0.78, -0.62, 30)); ink(tubeZ, 3);
    const wb = P([[-10, 920], [40, 910], [90, 930], [112, 980], [110, 1034], [-10, 1034]]);
    F(wb, rad(40, 960, 90, [[0, '#ffffff'], [0.6, '#e6e4de'], [1, '#bcb8b0']])); ink(wb, 3);
    // smoky tentacle
    blurred(3, () => { K(P([[-10, 520], [40, 540], [90, 570], [130, 610], [150, 640]], false), 'rgba(220,214,212,0.95)', 26); });

    // ── bottom zebra band + dark ledge ──
    const zb = P([[347, 918], [604, 974], [600, 1010], [340, 996]]);
    F(zb, band(1, 0.2, 34)); ink(zb, 3);
    const ledge = P([[250, 1000], [330, 988], [600, 1000], [650, 1034], [240, 1034]]);
    F(ledge, '#4c4c50'); ink(ledge, 3);

    // ── star bubbles ──
    for (const [x, y, rr] of [[690, 580, 14], [587, 641, 13], [500, 887, 12], [447, 663, 5], [485, 760, 6], [534, 744, 6], [488, 798, 4], [530, 822, 5], [503, 840, 5], [585, 935, 5],
      [552, 696, 4], [565, 688, 4], [580, 679, 4], [632, 612, 4], [668, 513, 5], [540, 560, 8], [700, 545, 4]]) { F(circleP(x, y, rr), '#fbfaf6'); ink(circleP(x, y, rr), rr > 8 ? 2.5 : 1.2); }

    E.grain(0.03, 33);
  }
});
