'use strict';
// g018 — "Granite helmet sitter": a clay-render diorama in a black light-box — a speckled granite
// helmeted figure with a cream tube over his shoulder, glossy black/white zebra body, a coral pompom
// disc, a white squid with a spiral eye, white blob clouds, a glass drop, a candle-sword and a chrome bowl.
REC.register('g018', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    for (const k of ['dome', 'flat', 'pipe', 'groove']) { const f0 = R[k]; R[k] = (...args) => { f0(...args); R.h.getImageData(0, 0, 1, 1); }; }
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, x0, y0, w, h, col = '#2a2420') => clipA(path, () => { const r = rng(seed); a.fillStyle = col; for (let i = 0; i < n; i++) { a.globalAlpha = 0.4 + r() * 0.6; a.beginPath(); a.arc(x0 + r() * w, y0 + r() * h, 0.5 + r() * r() * 2.4, 0, 6.283); a.fill(); } a.globalAlpha = 1; });
    const WH = '#e6e4e2';

    // ── light box: black backdrop, ceiling beam, light strip, pillars ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#161515', 0, 0);
    R.flat(rrect(-10, -10, 746, 40, 0), lin(0, 0, 0, 40, [[0, '#2c2b2a'], [1, '#3e3c3a']]), 0.02, 0);
    soft(x => { x.fillStyle = '#fffaf0'; x.fill(rrect(36, 28, 655, 16, 4)); }, 6, 0.8);
    R.flat(rrect(38, 30, 650, 12, 3), '#f4f0e6', 0.04, 0);
    R.dome(rrect(10, 28, 30, 320, 2), lin(10, 0, 40, 0, [[0, '#6c6864'], [0.5, '#a8a29a'], [1, '#5a5652']]), 0.04, 0.03, 6, 2);
    R.dome(rrect(688, 28, 40, 300, 2), lin(688, 0, 726, 0, [[0, '#5a5652'], [0.5, '#9a948c'], [1, '#6a6660']]), 0.04, 0.03, 6, 2);
    { const r = rng(18); for (let i = 0; i < 70; i++) { const x = 60 + r() * 620, y = 55 + r() * 330, rr = 0.6 + r() * r() * 3; a.fillStyle = `rgba(230,230,235,${0.3 + r() * 0.6})`; a.beginPath(); a.arc(x, y, rr, 0, 6.283); a.fill(); } }
    for (const [x, y, r] of [[395, 112, 7], [520, 74, 4], [452, 96, 3], [44, 158, 4], [248, 428, 9], [20, 422, 6]]) R.bead(x, y, r, '#c8ccd2', 0.1, 0.08, 7);

    // ── floor + round grey-blue mat ──
    R.flat(P([[-10, 838], [736, 820], [736, 1034], [-10, 1034]], true, false), lin(0, 830, 0, 1024, [[0, '#cfc9be'], [1, '#d8d2c8']]), 0.02, 1);
    soft(x => { x.fillStyle = '#b8b2a8'; x.fill(ellipseP(320, 900, 300, 30, 0)); }, 20, 0.5);
    R.flat(ellipseP(560, 1110, 470, 168, 0), '#bfd8e8', 0.03, 1);
    R.flat(ellipseP(564, 1114, 462, 162, 0), lin(0, 950, 0, 1024, [[0, '#8c939c'], [1, '#9aa0a8']]), 0.035, 1);

    // ── left coral cloud ──
    const coral = P([[-10, 318], [30, 308], [70, 330], [100, 360], [128, 420], [140, 500], [134, 600], [118, 700], [100, 800], [60, 860], [-10, 870]]);
    const ccv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 6. * vec2(vnoise(p * 0.05), vnoise(p * 0.05 + 3.));
      float v = vnoise(q * 0.11) * 0.7 + vnoise(q * 0.23) * 0.3;
      float b = smoothstep(0.35, 0.75, v);
      return mix(vec3(0.42, 0.41, 0.40), vec3(0.86, 0.85, 0.84), b); }`);
    R.dome(coral, '#bdbbb8', 0.06, 0.16, 50, 3);
    clipA(coral, () => img(ccv));
    { const r = rng(4); for (let i = 0; i < 90; i++) { const x = r() * 130, y = 320 + r() * 540; R.bead(x, y, 5 + r() * 8, null, 0.1 + r() * 0.08, 0.05, 3); } }

    // ── white blob cloud ──
    { const r = rng(9);
      const balls = [];
      for (let i = 0; i < 60; i++) balls.push([150 + r() * 230, 300 + r() * 330, 14 + r() * 26]);
      balls.sort((p, q) => p[1] - q[1]);
      for (const [x, y, rr] of balls) R.bead(x, y, rr, '#dedcda', 0.12 + y * 0.0001, 0.12, 1);
    }
    R.pipe(P([[80, 600], [78, 545], [110, 512], [160, 515], [192, 548]], false), 50, WH, 0.16, 0.16, 1);
    for (const [x, y, rr] of [[600, 560, 30], [630, 610, 34], [610, 660, 28], [650, 520, 26], [640, 690, 22], [580, 620, 22], [120, 820, 38], [100, 780, 28]]) R.bead(x, y, rr, '#dcdad8', 0.14, 0.14, 1);
    R.dome(P([[170, 610], [210, 585], [270, 575], [330, 580], [360, 605], [350, 630], [300, 640], [240, 645], [190, 640]]), '#e8dcda', 0.2, 0.12, 22, 1);
    R.dome(P([[268, 450], [290, 420], [340, 400], [400, 410], [430, 440], [460, 455], [478, 470], [470, 495], [440, 500], [410, 490], [370, 505], [310, 505], [278, 485]]), WH, 0.2, 0.16, 34, 1);
    R.bead(452, 476, 26, WH, 0.24, 0.14, 1);
    // right column of white spheres
    for (const [x, y, rr] of [[710, 340, 42], [705, 450, 46], [700, 560, 48], [690, 670, 44], [705, 780, 40], [722, 870, 40], [655, 620, 26], [25, 820, 42], [470, 886, 17]]) R.bead(x, y, rr, '#e2e0de', 0.16, 0.18, 1);

    // ── squid ──
    const tent = [];
    const sr = rng(31);
    for (let i = 0; i < 15; i++) {
      const u = i / 14, ex = 112 + u * 175 + (sr() - 0.5) * 10, ey = 330 + Math.sin(u * 2.6) * 70 + (sr() - 0.5) * 16;
      const cx = 195 + u * 80, cy = 112 + u * 60, x0 = 300, y0 = 238, pts = [];
      for (let k = 0; k <= 10; k++) { const t = k / 10, m = 1 - t; pts.push([m * m * x0 + 2 * m * t * cx + t * t * ex, m * m * y0 + 2 * m * t * cy + t * t * ey]); }
      tent.push(pts);
    }
    for (const pts of tent) R.pipe(P(pts, false), 11, '#eeeeec', 0.3, 0.08, 1);
    for (const [ex, ey] of [[218, 130], [282, 106], [315, 133], [205, 165]]) { R.pipe(P([[292, 228], [(292 + ex) / 2 + 6, (228 + ey) / 2], [ex, ey + 6]], false), 7, '#eeeeec', 0.32, 0.05, 1); R.bead(ex, ey, 8, '#f2f2f0', 0.34, 0.08, 1); }
    R.dome(P([[262, 210], [300, 196], [340, 196], [366, 208], [372, 224], [354, 236], [348, 262], [318, 272], [282, 262], [262, 240]]), '#f0f0ee', 0.32, 0.1, 18, 1);
    R.bead(328, 242, 26, '#b8bcc4', 0.4, 0.06, 4);
    { const pts = []; for (let i = 0; i <= 120; i++) { const t = i / 120, an = t * 6.283 * 4, rr = 2 + t * 20; pts.push([328 + Math.cos(an) * rr, 242 + Math.sin(an) * rr]); } R.groove(P(pts, false), 2.5, '#303238', 0.46, 0.05, 4, 1); }
    R.pipe(P([[322, 180], [345, 172], [360, 185]], false), 8, '#b8bcc4', 0.4, 0.06, 4);

    // ── glass drop (left) ──
    R.dome(circleP(100, 214, 28), rad(92, 205, 2, 30, [[0, '#c0c6cc'], [0.6, '#70767e'], [1, '#d0d6dc']]), 0.12, 0.16, 20, 5);
    R.dome(P([[86, 240], [100, 238], [104, 270], [110, 300], [106, 335], [86, 348], [64, 340], [56, 316], [70, 290], [82, 262]]), lin(56, 240, 110, 350, [[0, '#9aa0a8'], [0.5, '#5a6068'], [1, '#c0c8d0']]), 0.12, 0.12, 14, 5);

    // ── granite sneaker sole + brown welt ──
    const sole = P([[150, 868], [300, 852], [460, 836], [600, 816], [690, 798], [700, 836], [692, 880], [600, 908], [420, 932], [280, 944], [180, 920], [150, 896]]);
    R.dome(sole, '#c4b8ac', 0.08, 0.1, 14, 6);
    speck(sole, 900, 41, 140, 790, 570, 160);
    R.pipe(P([[150, 864], [300, 849], [460, 833], [600, 813], [690, 796]], false), 7, '#5a3a32', 0.18, 0.04, 2);
    R.bead(660, 846, 9, '#a8acb0', 0.2, 0.06, 4);

    // ── zebra body ──
    const body = P([[300, 820], [304, 740], [318, 660], [345, 570], [380, 516], [450, 498], [530, 500], [570, 530], [574, 610], [570, 690], [620, 720], [690, 760], [700, 800], [640, 818], [560, 838], [420, 858], [320, 856]]);
    // stripe flow: a cubic phase field (constants fitted offline to the robe's stripe flow) plus a small ripple
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = (p.x - 450.) / 100., v = (p.y - 680.) / 100.;
      float ph = 0.02523 + 1.7977 * v + 0.27508 * v * v - 0.22889 * v * v * v - 1.1148 * u - 0.4071 * u * v - 0.11249 * u * v * v
        - 0.2719 * u * u + 0.19583 * u * u * v - 0.26107 * u * u * u + 0.07 * sin(u * 9. + v * 3.);
      float s = cos(6.2832 * ph) - 0.1;
      return mix(vec3(0.95), vec3(0.03), smoothstep(-0.12, 0.12, s)); }`);
    R.dome(body, '#ffffff', 0.14, 0.3, 70, 2);
    clipA(body, () => img(zcv));

    // ── coral pompom disc ──
    const disc = circleP(218, 752, 118);
    R.dome(disc, '#e2886e', 0.14, 0.24, 60, 3);
    clipA(disc, () => { const r = rng(52); for (let i = 0; i < 1400; i++) { const an = r() * 6.283, r0 = 30 + r() * 20, r1 = 80 + r() * 40; a.strokeStyle = r() < 0.5 ? 'rgba(170,80,60,0.45)' : 'rgba(255,180,160,0.4)'; a.lineWidth = 0.8; a.beginPath(); a.moveTo(218 + Math.cos(an) * r0, 752 + Math.sin(an) * r0); a.lineTo(218 + Math.cos(an + 0.05) * r1, 752 + Math.sin(an + 0.05) * r1); a.stroke(); } });
    R.bead(215, 752, 36, '#e2dcd2', 0.4, 0.2, 1);

    // ── yellow tube + blue cuff ──
    const tube = [[548, 150], [582, 102], [640, 76], [690, 96], [712, 160], [716, 240], [730, 300]];
    R.pipe(P(tube, false), 84, '#e8c08a', 0.3, 0.3, 3);
    for (const c of [a, R.h]) c.lineCap = 'butt';
    R.pipe(P([[512, 116], [545, 168]], false), 98, '#b8ccd8', 0.34, 0.3, 1);
    for (const c of [a, R.h]) c.lineCap = 'round';

    // ── helmet head ──
    const helmet = P([[372, 236], [392, 186], [436, 150], [492, 134], [548, 140], [596, 168], [626, 214], [636, 280], [626, 350], [604, 420], [566, 470], [520, 496], [476, 492], [452, 440], [430, 412]]);
    R.dome(helmet, '#c8beb4', 0.2, 0.3, 70, 6);
    speck(helmet, 700, 61, 360, 130, 280, 370);
    const face = P([[392, 244], [372, 262], [366, 282], [358, 318], [356, 330], [380, 334], [384, 352], [390, 388], [404, 400], [440, 404], [462, 396], [470, 330], [456, 270], [432, 248]]);
    R.dome(face, '#9e9088', 0.3, 0.12, 20, 6);
    speck(face, 220, 62, 350, 240, 130, 170, '#4a4038');
    R.pipe(P([[368, 246], [440, 240], [520, 252], [560, 262]], false), 8, '#9a9088', 0.44, 0.06, 6);
    for (let k = 0; k < 6; k++) R.groove(P([[386, 342 + k * 8], [430, 344 + k * 8]], false), 4, '#3a2e2a', 0.42, 0.08, 6, 1);
    R.dome(rrect(388, 388, 76, 30, 4), '#d8d4ce', 0.4, 0.06, 6, 6);
    for (let k = 0; k < 10; k++) R.groove(P([[392 + k * 7.5, 392], [392 + k * 7.5, 414]], false), 2.5, '#8a8480', 0.46, 0.04, 6, 1);
    // eye + brow
    R.groove(P([[392, 278], [404, 272], [418, 276]], false), 4, '#3a3030', 0.38, 0.06, 6, 1);
    R.paint(ellipseP(405, 282, 8, 5, 0), '#f0ece8'); R.paint(circleP(402, 282, 3.5), '#2a2420');
    for (const [x, y] of [[450, 312], [458, 360], [470, 270]]) R.bead(x, y, 4, '#8a8078', 0.42, 0.04, 6);
    // ── skin arm, glove, rings ──
    R.pipe(P([[628, 320], [632, 380], [612, 450], [585, 505]], false), 84, '#d8b49c', 0.4, 0.3, 1);
    R.pipe(P([[630, 430], [670, 440], [690, 455]], false), 22, '#eeeeec', 0.5, 0.06, 1);
    for (const [y, w] of [[498, 70], [516, 72], [534, 70]]) { for (const c of [a, R.h]) c.lineCap = 'butt'; R.pipe(P([[570, y - 7], [570, y + 7]], false), w, '#e4d4c0', 0.52, 0.14, 1); for (const c of [a, R.h]) c.lineCap = 'round'; }
    R.dome(P([[536, 548], [600, 546], [602, 590], [590, 632], [570, 662], [548, 666], [522, 650], [514, 620], [528, 590]]), '#f0eeec', 0.5, 0.14, 18, 1);
    for (const fx of [524, 540, 556]) R.pipe(P([[fx, 610], [fx - 4, 650]], false), 12, '#f0eeec', 0.52, 0.06, 1);

    // ── black strap ──
    const strap = P([[548, 272], [590, 246], [660, 230], [706, 238], [726, 270], [726, 310], [690, 330], [630, 318], [574, 310], [550, 300]]);
    R.dome(strap, '#141414', 0.6, 0.08, 10, 2);
    for (const [x, y] of [[626, 284], [688, 316], [580, 296]]) R.bead(x, y, 6, '#c0c4c8', 0.68, 0.06, 4);
    R.pipe(P([[500, 438], [545, 428]], false), 10, '#d8d4cc', 0.4, 0.04, 1);
    R.bead(514, 496, 16, '#9aa0a8', 0.4, 0.14, 5);

    // ── candle-sword ──
    R.dome(P([[42, 742], [42, 524], [52, 490], [62, 524], [62, 742]], true, false), '#e8e4dc', 0.2, 0.06, 6, 1);
    R.pipe(P([[50, 742], [50, 950]], false), 14, '#8a8070', 0.22, 0.08, 4);
    for (const y of [760, 790, 830]) R.dome(ellipseP(50, y, 16, 6, 0), '#9a907e', 0.26, 0.04, 4, 4);
    R.dome(ellipseP(52, 962, 42, 14, 0), '#b0a690', 0.2, 0.06, 6, 4);
    R.pipe(P([[22, 740], [14, 700], [26, 680]], false), 5, '#b8bcc4', 0.3, 0.04, 4);
    R.pipe(P([[78, 740], [86, 700], [74, 680]], false), 5, '#b8bcc4', 0.3, 0.04, 4);

    // ── pale blue disc ──
    R.dome(P([[62, 946], [68, 900], [110, 880], [240, 878], [280, 900], [292, 946]], true, true), '#a9c6d8', 0.06, 0.08, 14, 1);

    // ── chrome bowl ──
    R.dome(ellipseP(500, 970, 92, 28, 0), '#d8dadc', 0.08, 0.06, 8, 1);
    R.dome(ellipseP(500, 936, 86, 34, 0), '#b4b8bc', 0.12, 0.12, 22, 4);
    R.dome(ellipseP(500, 932, 38, 10, 0), '#4a4c50', 0.18, 0.02, 4, 4);

    // ── glass splash ──
    { const r = rng(77); for (let i = 0; i < 9; i++) { const pts = []; let x = 540 + r() * 100, y = 650 + r() * 60; for (let k = 0; k < 6; k++) { pts.push([x, y]); x += (r() - 0.6) * 30; y += 20 + r() * 20; } R.pipe(P(pts, false), 4 + r() * 4, 'rgba(200,210,220,0.5)', 0.3, 0.06, 5); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.6, ao: 0.6, rim: 0.15 }),                        // 1 white clay
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.4, coat: 0.15, ao: 0.5 }),                        // 2 glossy (zebra, strap)
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.55, ao: 0.6, grain: 0.12 }),                       // 3 matte fibre / felt
        E.mat({ dif: 0.6, metal: 0.55, spec: 1.1, shin: 60, rim: 0.3, ao: 0.4, emis: 0.05 }),            // 4 chrome
        E.mat({ dif: 0.4, spec: 1.4, shin: 110, coat: 0.4, ao: 0.1, emis: 0.2 }),                        // 5 glass
        E.mat({ dif: 1, spec: 0.15, shin: 14, wrap: 0.5, ao: 0.6, grain: 0.08 }),                        // 6 granite
        E.mat({ dif: 0.5, spec: 1.2, shin: 90, coat: 0.3, emis: 0.3 })                                   // 7 bubbles
      ],
      light: [-0.55, 0.62, 0.58], lc: [0.72, 0.71, 0.7], amb: [0.42, 0.42, 0.43],
      envTop: [1.05, 1.04, 1.02], envHor: [0.55, 0.54, 0.53], envBot: [0.2, 0.2, 0.2], envK: [0.3, 0.9, 0.1, 0],
      rimC: [0.15, 0.15, 0.16], rimD: [0.3, 0.6, 0.3], r1: 2, r2: 9, k: [0, 0.6, 0.4, 70], shadow: [-8, 9, 0.6, 5]
    });
    E.bloom(0.08, 10);
    E.grain(0.03, 18);
  }
});
