'use strict';
// g090 — "Rainbow chrome contraption": a cream-rimmed clay board on a starry slate — a rainbow sky, an
// iridescent chrome hook pipe, a blue-framed TV with orange beads, a huge zebra-striped tube and chrome eggs.
REC.register('g090', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const line = (pts, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, false)); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true);
    const dots = (n, seed, x0, y0, w, h, rmin, rmax, col, h0 = 0.12, clip = null) => {
      const r = rng(seed);
      for (let i = 0; i < n; i++) { const x = x0 + r() * w, y = y0 + r() * h; if (clip && !a.isPointInPath(clip, x * S, y * S)) continue; R.bead(x, y, rmin + r() * (rmax - rmin), col, h0, 0.05, 2); }
    };
    const chromeAlb = (x0, y0, x1, y1) => lin(x0, y0, x1, y1, [[0, '#d8f0f4'], [0.3, '#eef0f4'], [0.5, '#f6f6fa'], [0.65, '#ece4f4'], [0.85, '#e0f0ee'], [1, '#e8eaf0']]);

    // ── slate background with stars ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#2c323d', 0, 0);
    { const r = rng(90); a.fillStyle = '#f4f6f8'; for (let i = 0; i < 60; i++) { const x = r() * 726, y = r() < 0.5 ? r() * 44 : 978 + r() * 46; a.beginPath(); a.arc(x, y, 2 + r() * 3, 0, 6.283); a.fill(); } }

    // ── board: cream rim + black field ──
    const board = P([[8, 50], [200, 44], [400, 48], [600, 45], [718, 48], [722, 300], [718, 600], [722, 900], [716, 972], [400, 974], [120, 970], [6, 972], [4, 700], [8, 400], [4, 150]], true, false);
    R.dome(board, '#f5efd7', 0.04, 0.06, 10, 1);
    a.lineWidth = 3; a.strokeStyle = '#d84a24'; a.stroke(board);
    const field = P([[38, 60], [400, 56], [710, 56], [710, 940], [400, 944], [22, 934], [22, 400], [38, 390]], true, false);
    R.flat(field, '#060508', 0.06, 0);
    // bottom-edge brown shadow line
    soft(x => { x.fillStyle = '#5a2020'; x.fillRect(0, 966, 726, 16); }, 3, 0.9);
    // crack lines on the cream rim
    line([[10, 220], [24, 190], [30, 150], [44, 120], [70, 100], [92, 70], [100, 58]], '#1a1210', 1.6);
    line([[14, 340], [26, 360], [34, 390]], '#1a1210', 1.4);

    // ── rainbow sky (top right) ──
    const skyP = sm([[384, 82], [470, 74], [560, 78], [640, 90], [700, 100], [712, 300], [712, 580], [640, 560], [600, 520], [560, 480], [520, 300], [470, 200], [400, 140]]);
    R.flat(skyP, '#e020c0', 0.06, 0);
    const rb = E.fx(`
      vec3 h(float x){ return vec3(float((int(x) >> 16) & 255), float((int(x) >> 8) & 255), float(int(x) & 255)) / 255.; }
      vec3 fx(vec2 uv, vec2 p){
        float u = dot(p, vec2(.747, .664));
        const int N = 15;
        float U[N] = float[N](360., 420., 455., 485., 515., 530., 545., 560., 575., 590., 605., 622., 640., 660., 700.);
        vec3 C[N] = vec3[N](h(8918249.), h(16130249.), h(15998157.), h(7017449.), h(13178342.), h(16127304.), h(16029720.), h(11661067.), h(1043647.), h(598510.), h(4459759.), h(12326896.), h(15341292.), h(16193457.), h(16323892.));
        vec3 c = C[0];
        for (int i = 1; i < N; i++) c = mix(c, C[i], smoothstep(U[i - 1], U[i], u));
        vec3 lo = mix(vec3(.96, .12, .58), vec3(.48, .08, .84), smoothstep(470., 540., p.y) * (1. - smoothstep(640., 690., p.x)));
        c = mix(c, lo, smoothstep(380., 440., p.y) * smoothstep(640., 700., u));
        return c * (0.94 + 0.12 * vnoise(p * 0.7)); }`);
    clipA(skyP, () => img(rb));
    dots(26, 3, 400, 90, 310, 480, 2, 4, '#ffffff', 0.08, skyP);
    // black corner with brown drip edge
    const corner = sm([[548, 48], [716, 48], [716, 290], [700, 282], [698, 210], [690, 140], [660, 100], [600, 92], [560, 80]]);
    R.dome(corner, '#151214', 0.08, 0.04, 6, 4);
    R.pipe(P([[548, 56], [600, 58], [660, 54], [716, 58]], false), 18, '#86301e', 0.1, 0.06, 2);
    for (const [x, y, r] of [[642, 98, 9], [698, 180, 10], [592, 112, 4], [668, 62, 4]]) R.bead(x, y, r, r > 6 ? '#f25a14' : '#f4f4f4', 0.14, 0.08, 2);

    // purple wavy band (top + left)
    const purp = sm([[40, 62], [150, 56], [300, 56], [450, 52], [556, 58], [552, 80], [470, 84], [380, 86], [300, 92], [200, 90], [120, 100], [86, 130], [80, 200], [86, 300], [84, 400], [60, 420], [42, 410]]);
    R.dome(purp, '#8a66b8', 0.08, 0.06, 10, 1);
    clipA(purp, () => { for (let i = 0; i < 8; i++) line([[40, 68 + i * 7], [200, 60 + i * 6], [400, 64 + i * 5], [556, 62 + i * 4]], 'rgba(70,50,150,0.35)', 1.5); for (let i = 0; i < 6; i++) line([[44 + i * 7, 110], [50 + i * 7, 250], [44 + i * 7, 410]], 'rgba(70,50,150,0.35)', 1.5); });
    // light blue side strips
    R.dome(sm([[22, 396], [54, 392], [60, 440], [56, 600], [60, 760], [54, 860], [22, 870]]), '#80b2d0', 0.08, 0.05, 6, 1);
    R.dome(sm([[110, 924], [400, 930], [600, 930], [640, 900], [690, 850], [714, 850], [714, 950], [400, 960], [110, 958]]), '#6ca0c0', 0.08, 0.05, 8, 1);
    R.dome(sm([[640, 524], [672, 520], [690, 540], [714, 532], [714, 610], [690, 606], [668, 616], [646, 600], [652, 570]]), '#8aa4cc', 0.1, 0.04, 6, 1);

    // ── yellow sun, antenna, small rods ──
    R.dome(circleP(133, 130, 45), '#fafa48', 0.08, 0.06, 20, 2);
    R.pipe(P([[100, 165], [100, 250]], false), 4, '#c8ccd8', 0.2, 0.04, 3); R.dome(ellipseP(100, 172, 5, 14, 0), '#d8dce4', 0.22, 0.06, 4, 3);
    for (const x of [92, 100, 108]) R.pipe(P([[x, 290], [x - 4, 410]], false), 5, '#2aa8b8', 0.14, 0.05, 3);
    R.bead(183, 222, 14, '#f4ec30', 0.14, 0.12, 2);

    // ── pink tongue, lavender back, blue TV frame ──
    R.dome(sm([[440, 196], [500, 204], [530, 240], [546, 300], [546, 520], [530, 560], [498, 562], [496, 300]]), '#a8b8ec', 0.08, 0.06, 12, 2);
    R.dome(sm([[186, 322], [190, 252], [220, 206], [270, 180], [330, 170], [400, 174], [452, 198], [470, 214], [468, 232], [430, 238], [320, 240], [262, 262], [222, 300], [202, 334]]), '#f488aa', 0.08, 0.08, 14, 1);
    const blueF = rrect(180, 255, 352, 306, 46);
    R.dome(blueF, '#1442ee', 0.1, 0.08, 14, 2);
    const scrBox = rrect(240, 288, 250, 196, 22);
    R.flat(scrBox, '#050508', 0.06, 0);
    R.flat(P([[180, 340], [240, 340], [240, 560], [180, 560]], true, false), '#050508', 0.06, 0);
    R.flat(P([[240, 484], [490, 484], [490, 562], [240, 562]], true, false), '#050508', 0.06, 0);
    dots(70, 7, 240, 288, 250, 270, 1, 3, '#f4f4f6', 0.08);
    { const r = rng(8), cols = ['#f04040', '#40c0f0', '#f0c040', '#40f080', '#ffffff']; for (let i = 0; i < 30; i++) R.bead(188 + r() * 45, 290 + r() * 50, 2 + r() * 3, cols[i % 5], 0.2, 0.04, 2); }
    for (let i = 0; i < 9; i++) R.bead(514, 262 + i * 24, 5.5, '#f4f4f4', 0.2, 0.06, 2);
    for (let i = 0; i < 6; i++) R.bead(282 + i * 40.5, 234, 23, '#f8a024', 0.14, 0.14, 2);
    R.dome(rrect(267, 322, 166, 118, 14), '#b6cad2', 0.12, 0.04, 6, 1);
    R.dome(sm([[292, 345], [320, 338], [345, 350], [380, 345], [415, 355], [410, 380], [418, 400], [395, 408], [360, 400], [330, 405], [298, 398], [285, 380]]), '#6d96b8', 0.13, 0.01, 3, 1);
    R.bead(463, 435, 19, '#e4ecd4', 0.14, 0.14, 2);
    for (const [x, y, r] of [[406, 466, 6], [508, 491, 8]]) R.bead(x, y, r, '#f8e020', 0.16, 0.08, 2);
    // fan lines + blue/cyan lips
    { for (let i = 0; i < 26; i++) { const t = -2.6 + i * 0.09; line([[352 + Math.cos(t) * 30, 500 + Math.sin(t) * 30], [352 + Math.cos(t) * 62, 500 + Math.sin(t) * 62]], 'rgba(200,210,230,0.75)', 1); }
      for (let i = 0; i < 14; i++) { const t = 2.0 + i * 0.07; line([[320 + Math.cos(t) * 20, 520 + Math.sin(t) * 20], [320 + Math.cos(t) * 70, 520 + Math.sin(t) * 70]], 'rgba(120,180,230,0.8)', 1.4); } }
    R.dome(sm([[280, 506], [300, 486], [340, 478], [380, 490], [420, 478], [460, 470], [486, 480], [488, 500], [460, 513], [420, 510], [380, 518], [330, 526], [290, 522]]), lin(280, 470, 480, 530, [[0, '#1a50e8'], [0.4, '#20c8d0'], [0.7, '#28d8b0'], [1, '#1440e0']]), 0.14, 0.14, 16, 3);

    // ── right column: orange caterpillar, lavender bar, cone ──
    R.dome(rrect(548, 236, 56, 264, 24), '#f8900e', 0.1, 0.14, 20, 2);
    for (let i = 0; i < 7; i++) R.dome(ellipseP(576, 260 + i * 36, 27, 19, 0), '#f8940e', 0.18, 0.05, 8, 2);
    R.dome(rrect(652, 262, 17, 374, 8), '#8ca8d8', 0.1, 0.06, 7, 1);
    R.dome(P([[566, 504], [598, 504], [604, 540], [586, 548], [570, 542]], true, true), '#40c8b8', 0.14, 0.08, 6, 3);

    // ── lower right: blue floor, lavender blob, orange capsule, chrome balls ──
    R.dome(sm([[416, 760], [470, 720], [520, 700], [570, 690], [604, 640], [620, 604], [650, 600], [712, 590], [712, 846], [660, 800], [600, 812], [520, 802], [470, 782]]), '#103cf0', 0.08, 0.05, 10, 2);
    dots(16, 11, 430, 620, 280, 220, 2.5, 6, '#f8f8f8', 0.14);
    R.bead(528, 772, 11, '#f8f8f8', 0.14, 0.1, 2);
    R.dome(sm([[340, 616], [380, 602], [450, 606], [520, 600], [580, 588], [606, 556], [618, 600], [600, 642], [560, 652], [520, 682], [472, 702], [440, 732], [400, 742], [360, 726], [338, 690], [332, 650]]), '#8eaadc', 0.1, 0.12, 24, 1);
    R.dome(rrect(355, 548, 252, 58, 28), '#f89c18', 0.12, 0.1, 18, 2);
    R.pipe(P([[370, 576], [582, 576]], false), 6, '#9ab0d8', 0.24, 0.03, 1);
    R.dome(circleP(578, 692, 46), rad(578, 692, 48, [[0, '#ffffff'], [0.3, '#c8ccd4'], [0.6, '#7a7e88'], [0.85, '#c0a8e0'], [1, '#40c0b0']], 560, 670), 0.14, 0.3, 46, 3);

    // ── zebra tube ──
    const tube = sm([[185, 440], [232, 440], [228, 500], [218, 560], [222, 640], [250, 700], [290, 740], [330, 750], [380, 740], [420, 750], [470, 790], [520, 818], [570, 832], [620, 826], [650, 800], [668, 802], [668, 838], [625, 890], [560, 930], [480, 952], [380, 958], [280, 948], [200, 920], [150, 870], [110, 800], [78, 740], [60, 680], [62, 600], [95, 520], [145, 470]]);
    R.dome(tube, '#888', 0.1, 0.24, 60, 4);
    // stripe field: local stripe fits (centre, normal angle, period, phase) blended smoothly
    const ZP = [[190, 480, 26, 19.75, 0.107], [135, 560, -31.5, 21, 0.034], [140, 680, -49.5, 26.75, -0.359], [85, 680, -43.5, 22.25, -0.284],
      [170, 820, -44.5, 22.75, -0.262], [280, 825, -56.5, 24.25, -0.306], [285, 750, -89, 19.5, 0.494], [390, 780, -65.5, 20.75, -0.212],
      [450, 855, -70, 30, 0.278], [470, 925, -77, 28.5, 0.216], [250, 915, -62, 19.5, 0.287], [600, 850, 39.5, 19.75, 0.177]];
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      const int N = ${ZP.length};
      vec4 Q[N] = vec4[N](${ZP.map(([cx, cy, an, T, ph]) => `vec4(${cx.toFixed(1)}, ${cy.toFixed(1)}, ${(an * Math.PI / 180).toFixed(4)}, ${T.toFixed(2)})`).join(', ')});
      float F[N] = float[N](${ZP.map(z => z[4].toFixed(3)).join(', ')});
      float sv = 0., sw = 0.;
      for (int i = 0; i < N; i++) {
        vec2 d = p - Q[i].xy; float w = exp(-dot(d, d) / (2. * 48. * 48.)) + 1e-6;
        sv += w * cos(6.2832 * (dot(p, vec2(cos(Q[i].z), sin(Q[i].z))) / Q[i].w - F[i])); sw += w;
      }
      float v = sv / sw;
      return mix(vec3(.03), vec3(.97, .96, .93), smoothstep(-.1, .1, v)); }`);
    clipA(tube, () => img(zcv));
    clipA(tube, () => soft(x => { x.fillStyle = '#ffffff'; x.fill(ellipseP(330, 830, 140, 30, 0.2)); x.fill(ellipseP(130, 600, 22, 80, 0.2)); }, 22, 0.45));
    // chrome egg on the tube, teal rings + hook
    const egg = ellipseP(272, 628, 66, 96, -0.45);
    R.dome(egg, chromeAlb(210, 540, 340, 720), 0.24, 0.24, 50, 3);
    clipA(egg, () => soft(x => {
      x.fillStyle = '#3a3c48'; x.fill(ellipseP(238, 670, 30, 60, -0.45)); x.fill(ellipseP(316, 600, 12, 40, -0.45));
      x.fillStyle = '#f0a0d0'; x.fill(ellipseP(300, 560, 30, 14, -0.45)); x.fillStyle = '#80e0e0'; x.fill(ellipseP(320, 700, 20, 10, -0.45));
    }, 10, 0.75));
    for (const [x, y, rx, ry, rot] of [[207, 452, 24, 9, -0.3], [207, 462, 24, 9, -0.3], [186, 670, 18, 26, 0.6], [660, 812, 10, 24, 0.2]]) R.dome(ellipseP(x, y, rx, ry, rot), '#30b8b0', 0.3, 0.06, 5, 3);
    R.pipe(P([[180, 676], [140, 694], [110, 712], [96, 738], [116, 750]], false), 10, '#40c0c0', 0.3, 0.08, 3);
    R.dome(circleP(696, 800, 36), rad(696, 800, 38, [[0, '#b8f0e8'], [0.5, '#30a898'], [1, '#106050']], 686, 786), 0.14, 0.26, 36, 3);

    // ── big chrome hook pipe ──
    const hook = sm([[100, 280], [105, 220], [125, 170], [165, 125], [220, 95], [290, 80], [350, 82], [400, 95], [430, 120], [448, 150], [450, 180], [440, 200], [420, 205], [390, 195], [350, 175], [300, 160], [250, 160], [210, 175], [180, 205], [162, 250], [158, 300], [170, 340], [205, 365], [228, 392], [234, 440], [196, 440], [160, 405], [128, 372], [108, 330]]);
    R.dome(hook, chromeAlb(100, 80, 450, 440), 0.3, 0.26, 34, 3);
    clipA(hook, () => soft(x => {
      x.lineCap = 'round'; x.lineWidth = 14; x.strokeStyle = '#2c2e3a';
      x.stroke(P([[180, 400], [160, 360], [150, 300], [158, 240], [190, 190], [250, 158], [320, 158], [390, 186]], false));
      x.lineWidth = 12; x.strokeStyle = '#60d8e8'; x.stroke(P([[112, 300], [116, 230], [140, 175], [190, 130]], false));
      x.strokeStyle = '#f0a8e0'; x.stroke(P([[220, 100], [300, 86], [360, 90]], false));
      x.lineWidth = 10; x.strokeStyle = '#40d0b0'; x.stroke(P([[200, 420], [214, 440]], false));
    }, 7, 0.7));
    R.pipe(P([[-10, 296], [40, 258], [92, 232]], false), 40, chromeAlb(0, 230, 100, 300), 0.26, 0.2, 3);
    R.dome(ellipseP(96, 232, 9, 24, 0.2), '#30b8b0', 0.36, 0.05, 5, 3);
    soft(x => { x.strokeStyle = '#ffffff'; x.lineWidth = 6; x.stroke(P([[400, 120], [340, 102], [270, 104], [205, 128]], false)); x.stroke(P([[128, 240], [126, 300], [140, 340]], false)); }, 4, 0.7);

    // ── left side: coral sponge, orange beads, pink egg ──
    const coral = sm([[72, 410], [104, 384], [130, 400], [140, 440], [126, 470], [136, 500], [112, 540], [84, 530], [76, 490], [64, 460]]);
    R.dome(coral, '#e8645c', 0.1, 0.06, 8, 1);
    clipA(coral, () => { const r = rng(4); a.fillStyle = '#300808'; for (let i = 0; i < 40; i++) { a.beginPath(); a.arc(70 + r() * 70, 384 + r() * 160, 1.5 + r() * 2.5, 0, 6.283); a.fill(); } });
    R.dome(circleP(130, 464, 9), '#e86460', 0.12, 0.04, 4, 1); R.bead(130, 464, 3, '#300808', 0.14, 0.01, 0);
    R.bead(150, 440, 4, '#f8f8f8', 0.14, 0.04, 2);
    for (const [x, y] of [[62, 497], [71, 776]]) R.bead(x, y, 16, '#f45010', 0.14, 0.14, 2);
    R.dome(ellipseP(112, 892, 40, 43, 0), rad(112, 892, 44, [[0, '#ff98b0'], [1, '#f05878']], 100, 875), 0.12, 0.2, 36, 2);
    for (const [x, y, r] of [[35, 990, 0], [38, 912, 8], [80, 798, 5], [36, 760, 4], [182, 942, 5], [652, 760, 5], [688, 930, 6], [612, 950, 5], [660, 960, 6], [590, 476, 5], [612, 495, 3]]) if (r) R.bead(x, y, r, '#f6f6f6', 0.14, 0.08, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.55, ao: 0.5, grain: 0.06 }),                  // 1 matte clay
        E.mat({ dif: 1, spec: 0.75, shin: 44, wrap: 0.4, ao: 0.4, coat: 0.15 }),                   // 2 glossy plastic
        E.mat({ dif: 0.3, metal: 0.8, spec: 1.2, shin: 70, rim: 0.25, ao: 0.3, emis: 0.08, iri: 0.3 }),   // 3 chrome
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.45, ao: 0.4, coat: 0.15 }),                   // 4 zebra gloss tube
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.6, 0.6, 0.6], amb: [0.55, 0.55, 0.56],
      envTop: [1.2, 1.2, 1.25], envHor: [0.85, 0.85, 0.9], envBot: [0.08, 0.08, 0.12], envK: [0.5, 1.3, 0, 0],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 100], shadow: [-5, 6, 0.55, 7]
    });
    E.grain(0.03, 90);
  }
});
