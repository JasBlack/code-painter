'use strict';
// s38 — "Gilded desert machine": sunlit surreal sculpture against a blue window sky — a gold
// segmented bottle-column, a curved gold arm, a scalloped cream shell, a silver-to-gold sphere
// with a ringed port, a pale-blue branching creature with fuzzy black pores, sandy cream flesh.
REC.register('s38', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, r = rng(38);
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const GOLD = m => 3, CH = 4, CREAM = 1, BLUE = 2, PINK = 5;

    // ── sky, window, desert ──
    R.flat(rrect(-5, -5, 1034, 1034, 0), lg(0, 60, 0, 520, [[0, '#5f86ee'], [0.5, '#88a8f2'], [1, '#bcd0ee']]), 0, 0);
    soft(x => {
      for (const [cx, cy, rx, ry] of [[330, 300, 80, 28], [420, 290, 110, 40], [520, 250, 90, 50], [580, 210, 60, 36], [470, 320, 120, 24], [300, 320, 60, 16]]) fillE(x, cx, cy, rx, ry, 0, '#f2eef2');
      fillE(x, 420, 330, 150, 14, 0, '#d8c8d8');
    }, 8, 1);
    a.fillStyle = '#9a88c0'; a.fill(P([[330, 530], [400, 500], [470, 495], [540, 510], [600, 495], [670, 520], [670, 560], [330, 560]]));
    R.flat(rrect(0, 540, 1024, 490, 0), lg(0, 540, 0, 1000, [[0, '#e0b890'], [1, '#d09060']]), 0, 0);
    R.flat(rrect(0, 0, 1024, 56, 0), lg(0, 0, 0, 56, [[0, '#1c2430'], [1, '#2c3444']]), 0.02, 0);
    R.flat(rrect(0, 0, 58, 820, 0), lg(0, 0, 58, 0, [[0, '#4a5a3a'], [1, '#6a7658']]), 0.02, 0);
    R.pipe(P([[300, 58], [850, 58]], false), 9, '#b8bcc8', 0.05, 0.05, CH);
    R.pipe(P([[16, 60], [16, 520]], false), 8, '#9aa0a8', 0.05, 0.05, CH);
    R.flat(P([[160, 100], [240, 100], [236, 500], [168, 500]], true, false), lg(160, 0, 240, 0, [[0, '#e8eef4'], [1, '#c8d4e0']]), 0.03, 0);

    // ── pink blob (left) ──
    R.dome(P([[0, 330], [60, 320], [140, 360], [200, 430], [215, 520], [180, 600], [120, 660], [80, 760], [30, 780], [0, 780]]), '#eec4c0', 0.05, 0.25, 90, PINK);

    // ── big curved gold arm ──
    const armCl = [[108, 100], [118, 200], [150, 300], [205, 400], [285, 500], [372, 572], [472, 636]];
    R.pipe(P(armCl, false), 104, lg(40, 0, 200, 0, [[0, '#fae488'], [0.5, '#eec448'], [1, '#b07a18']]), 0.08, 0.36, 3);
    R.pipe(P([[60, 138], [165, 138]], false), 34, '#f0c040', 0.3, 0.14, 3);
    R.dome(ellipseP(112, 128, 62, 36, 0), '#f2c848', 0.3, 0.16, 20, 3);
    R.pipe(P([[62, 300], [100, 272], [150, 262], [182, 268]], false), 12, '#f4d060', 0.4, 0.1, 3);
    R.pipe(P([[352, 610], [405, 548]], false), 26, '#f0c040', 0.4, 0.1, 3);

    // ── cream creature head (top left) ──
    R.dome(P([[96, 30], [120, -10], [300, -10], [320, 40], [305, 90], [270, 108], [200, 110], [130, 100], [96, 70]]), '#e6e2da', 0.15, 0.25, 60, CREAM);
    soft(x => { fillE(x, 150, 30, 22, 18, 0, '#1a1410'); fillE(x, 288, 92, 12, 6, 0.3, '#2a1a14'); }, 3, 1);
    for (let k = 0; k < 40; k++) { const an = r() * 6.28, d = 14 + r() * 14; a.strokeStyle = '#1a1410'; a.lineWidth = 1.2; a.beginPath(); a.moveTo(150, 30); a.lineTo(150 + Math.cos(an) * d, 30 + Math.sin(an) * d); a.stroke(); }

    // ── gold helmet / leaf ──
    R.dome(P([[360, 192], [380, 150], [430, 120], [500, 115], [552, 130], [540, 170], [520, 220], [480, 262], [430, 272], [390, 250], [365, 220]]), lg(360, 120, 550, 270, [[0, '#fae488'], [0.5, '#eec448'], [1, '#a07018']]), 0.2, 0.3, 50, 3);

    // ── cream scallop shell (right) ──
    const shell = P([[712, 330], [730, 230], [790, 150], [870, 118], [960, 110], [1024, 115], [1024, 400], [980, 440], [900, 480], [800, 480], [730, 430]]);
    R.dome(shell, '#e2dcd2', 0.1, 0.3, 80, CREAM);
    for (let k = 0; k < 6; k++) { const an = -2.6 + k * 0.42; R.groove(P([[860, 470], [860 + Math.cos(an) * 200, 470 + Math.sin(an) * 330]], false), 14, '#a8a098', 0.36, 0.14, CREAM, 0.5); }
    // gold mesh flower on the shell
    for (let k = 0; k < 14; k++) { const an = k / 14 * 6.283; R.pipe(P([[928, 378], [928 + Math.cos(an) * 34, 378 + Math.sin(an) * 30]], false), 2.5, '#e8b040', 0.4, 0.04, 3); }
    R.pipe(ellipseP(928, 378, 30, 26, 0), 3, '#e8b040', 0.42, 0.04, 3);

    // ── big sphere: silver top -> gold bottom ──
    const sph = circleP(900, 720, 330);
    R.dome(sph, lg(0, 400, 0, 1000, [[0, '#e8e6f0'], [0.25, '#d4d0dc'], [0.4, '#e0c078'], [0.6, '#f0c448'], [1, '#c89028']]), 0.1, 0.5, 260, 4);
    soft(x => { fillE(x, 800, 520, 130, 80, -0.4, '#f4f2f8'); fillE(x, 740, 860, 90, 120, 0, '#f4c050'); }, 30, 0.6);
    R.dome(circleP(988, 712, 64), '#e8b848', 0.5, 0.12, 20, 3);
    R.dome(circleP(992, 714, 40), '#120a04', 0.62, -0.22, 12, 0);

    // ── gold segmented column + neck + arm ──
    R.pipe(P([[690, 70], [690, 240]], false), 66, lg(655, 0, 725, 0, [[0, '#fae488'], [0.5, '#eec448'], [1, '#b07a18']]), 0.2, 0.3, 3);
    R.dome(ellipseP(682, 72, 26, 14, 0), '#f0c850', 0.45, 0.1, 10, 3);
    R.pipe(P([[700, 150], [780, 110], [860, 70], [920, 40]], false), 42, '#e8b438', 0.2, 0.3, 3);
    R.dome(circleP(930, 42, 50), '#e8b848', 0.35, 0.2, 24, 3);
    R.dome(circleP(932, 40, 26), '#0e0804', 0.5, -0.2, 10, 0);
    R.pipe(P([[885, 10], [880, -10]], false), 20, '#f0c850', 0.3, 0.1, 3);
    const blk = (cx, cy, wd, ht, rot) => {
      const c = Math.cos(rot), sn = Math.sin(rot), pts = [];
      for (const [u, v] of [[-1, -1], [1, -1], [1, 1], [-1, 1]]) pts.push([cx + c * u * wd / 2 - sn * v * ht / 2, cy + sn * u * wd / 2 + c * v * ht / 2]);
      return pts;
    };
    for (let i = 0; i < 6; i++) {
      const t = i / 5, cx = 560 + (660 - 560) * t, cy = 612 + (268 - 612) * t, wd = 172 - 30 * t;
      const q = blk(cx, cy, wd, 76, -0.12 + 0.02 * i);
      R.dome(P(q, true, true), lg(cx - wd / 2, cy - 40, cx + wd / 2, cy + 40, [[0, '#fbe690'], [0.45, '#eec448'], [1, '#a87418']]), 0.22, 0.3, 36, 3);
    }
    R.groove(P([[612, 300], [600, 360], [615, 440]], false), 6, '#5a3a08', 0.5, 0.2, 3);
    R.pipe(P([[520, 320], [590, 318]], false), 30, '#e8b038', 0.3, 0.2, 3);

    // ── pale blue branching creature ──
    const blueCl = [[-20, 370], [60, 360], [140, 380], [210, 420], [250, 460], [300, 440], [360, 400], [420, 370], [460, 330], [480, 300]];
    R.pipe(P(blueCl, false), 52, '#bcd4e0', 0.3, 0.3, BLUE);
    R.pipe(P([[250, 460], [240, 510], [236, 560]], false), 70, '#b8d2de', 0.3, 0.3, BLUE);
    R.dome(ellipseP(478, 292, 50, 26, -0.3), '#c6dce6', 0.4, 0.2, 20, BLUE);
    R.pipe(P([[478, 292], [520, 305]], false), 30, '#c0d8e2', 0.4, 0.1, BLUE);
    R.pipe(P([[-20, 110], [30, 95], [70, 60], [100, 40]], false), 36, '#bcd4e0', 0.3, 0.26, BLUE);
    soft(x => { fillE(x, 243, 460, 26, 26, 0, '#050505'); }, 2, 1);
    for (let k = 0; k < 60; k++) { const an = r() * 6.28, d = 20 + r() * 16; a.strokeStyle = '#0a0808'; a.lineWidth = 1.4; a.beginPath(); a.moveTo(243, 460); a.lineTo(243 + Math.cos(an) * d, 460 + Math.sin(an) * d); a.stroke(); }

    // ── big sandy cream body ──
    const body = P([[70, 1030], [66, 800], [80, 680], [120, 610], [180, 565], [240, 545], [300, 560], [400, 612], [520, 648], [640, 700], [740, 780], [840, 870], [930, 950], [1000, 1030]]);
    R.dome(body, lg(0, 560, 0, 1024, [[0, '#e6e0d6'], [0.6, '#d6cec2'], [1, '#c8beb0']]), 0.12, 0.45, 220, CREAM);
    soft(x => { fillE(x, 380, 700, 240, 90, 0.2, '#ece8e0'); fillE(x, 190, 870, 150, 120, 0.3, '#8a8078'); fillE(x, 640, 830, 150, 70, 0.6, '#f0e8d8'); fillE(x, 820, 960, 120, 50, 0.6, '#a09486'); }, 50, 0.75);
    // dark lace under the body edge
    soft(x => { x.fillStyle = '#1c1414'; x.fill(P([[44, 640], [100, 606], [84, 680], [74, 790], [58, 790], [44, 720]])); }, 3, 1);

    // ── small silver ball + spring + wrench ──
    R.bead(810, 770, 74, lg(740, 700, 880, 840, [[0, '#f0f0f4'], [0.5, '#a8a8b0'], [1, '#606068']]), 0.3, 0.3, CH);
    for (let k = 0; k < 9; k++) R.pipe(ellipseP(690, 620 + k * 9, 20, 5, 0), 3.5, '#e8b040', 0.5, 0.06, 3);
    R.pipe(P([[690, 600], [735, 620], [742, 680], [720, 740], [690, 725], [660, 690]], false), 5, '#c8c8cc', 0.5, 0.06, CH);
    R.pipe(P([[725, 740], [760, 690], [790, 700]], false), 5, '#c8c8cc', 0.5, 0.06, CH);
    R.pipe(P([[880, 800], [888, 840], [900, 900], [905, 980]], false), 14, '#c8c8cc', 0.4, 0.12, CH);
    R.pipe(P([[880, 910], [985, 912]], false), 20, '#c8c8d0', 0.4, 0.12, CH);

    // ── bottom: gold blob, silver ball, pale-blue disc ──
    R.dome(ellipseP(420, 1010, 150, 90, 0), lg(300, 930, 520, 1024, [[0, '#f8d060'], [1, '#c88818']]), 0.1, 0.3, 80, 3);
    R.bead(186, 948, 88, lg(120, 880, 260, 1020, [[0, '#f0f0f4'], [0.5, '#b0b0b8'], [1, '#5a5a60']]), 0.3, 0.3, CH);
    R.dome(ellipseP(60, 1000, 140, 70, 0), '#c8e0ec', 0.3, 0.2, 40, BLUE);
    R.dome(P([[110, 950], [170, 930], [250, 945], [270, 965], [200, 975], [130, 975]]), '#9a9690', 0.5, 0.06, 10, CREAM);

    // cream speckle grain
    clipA(body, () => { for (let k = 0; k < 6000; k++) { a.fillStyle = r() < 0.5 ? 'rgba(120,110,95,0.08)' : 'rgba(255,255,250,0.08)'; a.fillRect(r() * 1024, 540 + r() * 490, 1.5, 1.5); } });
    clipA(shell, () => { for (let k = 0; k < 2500; k++) { a.fillStyle = r() < 0.5 ? 'rgba(120,110,95,0.08)' : 'rgba(255,255,250,0.08)'; a.fillRect(700 + r() * 330, 100 + r() * 390, 1.5, 1.5); } });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.35, grain: 0.18, ao: 0.6 }),                               // 1 sandy cream
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.4, ao: 0.5, emis: 0.05, coat: 0.05 }),                      // 2 pale blue
        E.mat({ metal: 0.7, dif: 0.5, spec: 1.0, shin: 40, rim: 0.3, tint: [1.25, 1.12, 0.82], coat: 0.08, ao: 0.4, emis: 0.08 }), // 3 gold
        E.mat({ metal: 0.8, dif: 0.35, spec: 1.0, shin: 60, rim: 0.3, tint: [1.1, 1.08, 1.1], coat: 0.06, ao: 0.4 }), // 4 chrome
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, grain: 0.3, emis: 0.08 })                                // 5 pink
      ],
      light: [-0.5, 0.55, 0.66], lc: [0.72, 0.7, 0.64], amb: [0.36, 0.36, 0.4],
      envTop: [1.1, 1.05, 1.0], envHor: [0.85, 0.75, 0.6], envBot: [0.35, 0.25, 0.15], envK: [0.5, 1.4, 0.4, 0],
      rimC: [0.2, 0.2, 0.2], rimD: [-0.4, 0.5, 0.3], r1: 2, r2: 12, k: [0, 0.6, 0.4, 70], shadow: [8, 9, 0.5, 5]
    });
    E.bloom(0.12, 14);
    E.grain(0.04, 38);
  }
});
