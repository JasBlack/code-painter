'use strict';
// u068 — "Telescope over the sponge cake": a comic-print still life in a black porthole — a cream sponge slab
// veined with gold, a black-and-teal telescope, corrugated brown hoses, a speckled boulder face, a zebra-striped
// crate, a teal gear, mauve splats and red-capped canisters, under a snowy blue sky.
REC.register('u068', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const img = cv => { o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.drawImage(cv, 0, 0); o.restore(); };
    const clip = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const fill = (path, c, x = o) => { x.fillStyle = c; x.fill(path); };
    const stroke = (path, c, wd, x = o) => { x.lineWidth = wd; x.strokeStyle = c; x.lineCap = x.lineJoin = 'round'; x.stroke(path); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops) => { const g = o.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false);
    const ink = (path, wd = 2.5) => stroke(path, '#0c0a0c', wd);
    const spots = (path, n, seed, cols, rmin, rmax, bb = [0, 0, 726, 1024]) => clip(path, () => { const r = rng(seed); for (let i = 0; i < n; i++) { const b = blob(bb[0] + r() * (bb[2] - bb[0]), bb[1] + r() * (bb[3] - bb[1]), rmin + r() * (rmax - rmin), (rmin + r() * (rmax - rmin)) * 0.8, seed * 100 + i, 9, 0.35, r() * 3); fill(P(b), cols[i % cols.length]); } });

    const SPONGE = [[590,281],[579,289],[567,281],[543,286],[530,310],[517,309],[516,319],[500,333],[492,333],[484,322],[469,322],[476,344],[466,363],[495,385],[483,411],[502,404],[510,410],[484,442],[467,444],[428,435],[428,427],[460,398],[462,381],[460,366],[447,355],[447,325],[415,335],[429,346],[443,373],[438,391],[448,402],[404,430],[396,442],[392,508],[379,526],[376,554],[367,559],[331,612],[300,636],[291,651],[258,669],[240,669],[204,702],[198,720],[185,725],[175,740],[165,772],[162,823],[209,844],[272,890],[318,948],[334,915],[350,913],[376,893],[373,889],[358,897],[349,894],[345,885],[351,875],[334,873],[331,861],[351,854],[369,868],[374,841],[366,829],[388,809],[398,786],[415,782],[412,770],[434,746],[448,753],[456,742],[480,737],[482,714],[496,720],[513,705],[522,680],[517,662],[530,651],[524,632],[538,626],[551,609],[567,551],[579,548],[599,578],[608,581],[581,515],[639,491],[653,477],[650,462],[641,456],[597,456],[589,450],[590,436],[627,378],[629,358],[637,346],[638,318],[634,310],[621,311]];
    const LATTICE = [[679,135],[660,139],[654,127],[658,113],[620,91],[611,79],[578,76],[571,67],[548,69],[543,48],[532,54],[504,52],[495,70],[462,88],[439,124],[413,122],[421,135],[421,156],[400,195],[411,203],[415,233],[356,255],[416,244],[442,296],[453,297],[434,258],[435,237],[546,208],[552,202],[435,230],[426,222],[427,192],[544,157],[559,144],[590,156],[600,177],[617,185],[613,200],[620,236],[646,239],[649,232],[639,221],[662,187],[664,171],[683,170]];

    // ── snowy blue sky ──
    fill(rrect(0, 0, 726, 1024, 0), lin(0, 0, 0, 1024, [[0, '#30458a'], [0.3, '#4a5c98'], [0.45, '#6a7aa4'], [0.56, '#a2b8cc'], [0.72, '#acd2e2'], [1, '#a4d2e4']]));
    { const r = rng(2); for (let i = 0; i < 40; i++) { const x = r() * 726, y = r() * 1024; soft(x2 => fill(circleP(x, y, 2 + r() * 8), 'rgba(255,255,255,0.8)', x2), 2, 1); } }
    // ── black porthole ──
    fill(sm([[0, 380], [40, 360], [60, 500], [64, 760], [70, 1044], [0, 1044]]), 'rgba(196,204,222,0.55)');
    const WIN = sm([[52, 150], [72, 110], [112, 84], [160, 64], [210, 48], [270, 50], [320, 70], [380, 92], [430, 106], [480, 80], [560, 58], [640, 48], [760, 44], [760, 1060], [90, 1060], [56, 900], [42, 700], [40, 500], [44, 300], [48, 180]]);
    fill(WIN, '#08070a');
    clip(WIN, () => { const r = rng(5); for (let i = 0; i < 160; i++) fill(circleP(r() * 726, r() * 1024, 1 + r() * 4), '#f4f4f8'); });
    stroke(P([[20, 260], [40, 140], [90, 70], [200, 42], [290, 56], [380, 88], [440, 104]], false), 'rgba(235,240,255,0.85)', 2.5);
    stroke(P([[30, 600], [26, 800], [40, 1000]], false), 'rgba(235,240,255,0.6)', 2);
    // teal panel with a gold frame on the right
    fill(sm([[668, 62], [690, 48], [760, 48], [760, 730], [716, 730], [706, 500], [690, 260]]), '#b89048'); fill(sm([[682, 74], [700, 62], [760, 62], [760, 600], [720, 600], [712, 400], [700, 240]]), '#2e8a86');
    for (const y of [130, 160, 190]) fill(rrect(704, y, 30, 12, 2), '#f0d040');
    // ── brown fur halo and the speckled boulder face ──
    const FUR = sm([[90, 150], [120, 96], [180, 66], [240, 70], [282, 110], [296, 170], [286, 230], [250, 200], [200, 150], [140, 150], [100, 190]]);
    fill(FUR, '#4a2618'); spots(FUR, 120, 3, ['#7a4a30', '#2a120a'], 2, 5, [80, 60, 300, 240]);
    const RK = sm([[100, 150], [130, 112], [180, 98], [232, 106], [272, 140], [290, 190], [286, 250], [262, 300], [220, 330], [170, 336], [126, 316], [96, 276], [84, 216]]);
    fill(RK, '#b4a4a0'); spots(RK, 9, 7, ['#8a6c60', '#9a7c6e'], 10, 24, [84, 98, 290, 336]); spots(RK, 16, 8, ['#f4f2ee'], 6, 15, [84, 98, 290, 336]); ink(RK);
    stroke(P([[160, 236], [176, 244], [194, 240]], false), '#0c0a0c', 3);
    stroke(P([[130, 296], [170, 320], [220, 318]], false), '#b02020', 14); ink(P([[130, 288], [170, 330], [226, 326]], false), 2);
    // brown rock on the left
    const LR = sm([[14, 300], [50, 270], [100, 272], [114, 320], [110, 380], [90, 420], [40, 436], [12, 410]]);
    fill(LR, '#a98c82'); spots(LR, 8, 9, ['#7a5a4c', '#c8b0a6'], 8, 18, [12, 270, 114, 436]); ink(LR);
    // ── zebra crate with a grey block ──
    const CRATE = poly([[34, 420], [110, 346], [160, 352], [210, 400], [262, 470], [290, 520], [270, 600], [200, 610], [120, 570], [60, 500]]);
    fill(CRATE, '#f2f0f0');
    clip(CRATE, () => { for (let k = -40; k < 40; k++) { const x = k * 14; stroke(P([[x, 300], [x + 360, 660]], false), '#16141a', 4.2); } });
    ink(CRATE);
    const BLOCK = poly([[200, 500], [262, 488], [300, 540], [290, 604], [226, 612], [196, 560]]);
    fill(BLOCK, '#a4a0a4'); spots(BLOCK, 60, 11, ['#6a666a', '#d8d4d8'], 1, 3, [196, 488, 300, 612]); ink(BLOCK);
    fill(poly([[62, 590], [128, 576], [134, 600], [70, 640]]), '#e8c030');
    // ── teal gear ──
    { const pts = []; for (let i = 0; i < 48; i++) { const an = i / 48 * 6.283, rr = i % 2 ? 54 : 70; pts.push([310 + Math.cos(an) * rr, 400 + Math.sin(an) * rr]); }
      const G = poly(pts); fill(G, '#3aa0b8'); ink(G, 1.5);
      const r = rng(4); for (let i = 0; i < 18; i++) fill(circleP(270 + r() * 90, 360 + r() * 90, 2 + r() * 4), '#f4f8fa'); }
    stroke(circleP(350, 380, 26), '#8a6a5a', 10); ink(circleP(350, 380, 31), 1.5);
    // ── cream lattice top right ──
    const LAT = sm(LATTICE);
    fill(LAT, '#e0d4b8'); ink(LAT);
    clip(LAT, () => { const r = rng(6); for (let i = 0; i < 16; i++) { const x = 420 + r() * 250, y = 60 + r() * 230; stroke(P([[x - 18, y], [x + 18, y]], false), '#fbfbfb', 9); stroke(P([[x, y - 18], [x, y + 18]], false), '#fbfbfb', 9); } });
    // ── the sponge slab: cream cells with gold-brown veins and white flecks ──
    const SP = sm(SPONGE);
    fill(SP, '#d8c8a2');
    clip(SP, () => img(E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 q = (p + 26. * vec2(fbm(p * .012), fbm(p * .012 + 4.))) / 84.; vec2 i = floor(q), f = fract(q);
        float d1 = 9., d2 = 9.; vec2 c1 = vec2(0.), r1 = vec2(0.);
        for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(float(x), float(y)); vec2 o = .15 + .7 * vec2(hash(i + g), hash(i + g + 9.1));
          vec2 r = g + o - f; float d = dot(r, r); if (d < d1) { d2 = d1; d1 = d; c1 = i + g; r1 = r; } else if (d < d2) d2 = d; }
        float e = sqrt(d2) - sqrt(d1);
        vec3 c = mix(vec3(.82, .77, .64), vec3(.90, .86, .74), fbm(p * .06));
        c = mix(c, vec3(.40, .28, .14), smoothstep(.24, .2, e) * smoothstep(.15, .19, e));
        c = mix(c, vec3(.88, .74, .34), smoothstep(.15, .12, e));
        c = mix(c, vec3(.30, .20, .08), smoothstep(.05, .025, e));
        // white capsules inside each cell, black-outlined
        float an = hash(c1 + 3.) * 3.1416; vec2 dir = vec2(cos(an), sin(an));
        vec2 rr = -r1 * 84. + (vec2(hash(c1 + 5.), hash(c1 + 6.)) - .5) * 18.;
        float L = 6. + 14. * hash(c1 + 7.);
        float t = clamp(dot(rr, dir), -L, L); float cap = length(rr - dir * t) - 6. - 3. * hash(c1 + 8.);
        c = mix(c, vec3(.08), smoothstep(1.6, .6, abs(cap + .2)) * step(.25, hash(c1 + 9.)));
        c = mix(c, vec3(.98), smoothstep(.4, -.6, cap) * step(.25, hash(c1 + 9.)));
        return c; }`)));
    ink(SP, 3);
    // ── telescope ──
    o.save(); o.translate(400, 254); o.rotate(-0.25);
    fill(rrect(-40, -48, 250, 96, 6), '#0e0d12'); fill(rrect(-40, -48, 250, 40, 6), '#6ab8d0'); fill(rrect(-40, -10, 250, 6, 2), '#e8f0f4');
    fill(rrect(36, -46, 6, 92, 2), '#f2f2f4'); fill(rrect(-40, -4, 250, 5, 2), '#f2f2f4');
    fill(ellipseP(212, 0, 16, 48, 0), '#6ab8d0'); stroke(ellipseP(212, 0, 16, 48, 0), '#0c0a0c', 3);
    for (let k = 0; k < 7; k++) { const x = -60 - k * 22, h = 54 - k * 3; fill(rrect(x - 12, -h, 24, 2 * h, 6), lin(0, -h, 0, h, [[0, '#30303a'], [0.3, '#e8e8f0'], [0.55, '#5a5a66'], [0.8, '#c8c8d4'], [1, '#202028']])); stroke(rrect(x - 12, -h, 24, 2 * h, 6), '#0c0a0c', 2); }
    fill(rrect(-230, -18, 40, 36, 6), lin(0, -18, 0, 18, [[0, '#40404a'], [0.4, '#e0e0e8'], [1, '#30303a']]));
    o.fillStyle = '#e8f0f4'; o.font = 'bold 15px Arial'; o.fillText("PAR + hind.", 70, 24);
    o.restore();
    // ── corrugated hoses ──
    const hose = (pts, wd) => { const p = P(pts, false); stroke(p, '#0c0a0c', wd + 5); stroke(p, '#9a7464', wd); o.save(); o.setLineDash([2.2, 3.8]); o.lineCap = 'butt'; o.lineWidth = wd - 2; o.strokeStyle = '#4a2e26'; o.stroke(p); o.restore(); stroke(p, 'rgba(210,180,160,0.3)', wd * 0.25); };
    hose([[470, 340], [430, 340], [392, 370], [364, 430], [344, 500], [318, 560], [270, 610], [180, 632], [110, 660], [76, 720], [70, 800]], 40);
    hose([[420, 396], [388, 470], [366, 540], [330, 610], [260, 660], [190, 700], [140, 760], [130, 820]], 38);
    // ── mauve splats ──
    const SPL1 = sm([[476, 500], [500, 466], [540, 448], [590, 452], [640, 456], [660, 476], [640, 500], [600, 510], [560, 530], [520, 544], [490, 536]]);
    const SPL2 = sm([[455, 775], [490, 756], [530, 738], [560, 700], [572, 660], [604, 628], [622, 600], [652, 592], [662, 624], [648, 664], [642, 704], [680, 700], [726, 716], [746, 730], [746, 800], [690, 794], [650, 804], [612, 832], [580, 858], [556, 836], [540, 802], [500, 800], [466, 800]]);
    for (const SPL of [SPL1, SPL2]) { fill(SPL, '#b8a6a0'); spots(SPL, 10, 13, ['#9a8278', '#a89088'], 10, 24, [455, 440, 746, 860]); spots(SPL, 18, 14, ['#fbfbfb'], 4, 9, [455, 440, 746, 860]); ink(SPL); }
    // ── red-capped canisters, black ring, dark floor ──
    fill(sm([[380, 900], [500, 880], [640, 878], [746, 870], [746, 1044], [380, 1044]]), '#2c2a30');
    const can = (x, y, rx, ry, h) => { fill(rrect(x - rx, y, 2 * rx, h, 4), lin(x - rx, 0, x + rx, 0, [[0, '#101014'], [0.35, '#4a4a54'], [0.6, '#1a1a20'], [1, '#08080a']])); ink(rrect(x - rx, y, 2 * rx, h, 4));
      fill(ellipseP(x, y, rx, ry, 0), '#a8a8b0'); ink(ellipseP(x, y, rx, ry, 0)); fill(ellipseP(x, y - 4, rx * 0.8, ry * 0.75, 0), '#d83030'); ink(ellipseP(x, y - 4, rx * 0.8, ry * 0.75, 0), 1.5);
      fill(rrect(x - rx * 0.45, y - 4 - ry * 0.12, rx * 0.9, ry * 0.24, 1), '#fbfbfb'); fill(rrect(x - rx * 0.1, y - 4 - ry * 0.55, rx * 0.2, ry * 1.1, 1), '#fbfbfb'); };
    can(495, 864, 62, 26, 200); can(668, 668, 32, 13, 40);
    fill(circleP(662, 830, 50), lin(612, 780, 712, 880, [[0, '#5a5a62'], [0.5, '#16161a'], [1, '#3a3a42']])); fill(circleP(662, 830, 32), '#020203'); ink(circleP(662, 830, 50));
    // ── brown leather bag and grey slab, bottom left ──
    const BAG = sm([[50, 790], [120, 770], [200, 800], [270, 860], [300, 930], [290, 1000], [270, 1044], [60, 1044], [40, 920]]);
    fill(BAG, '#7f5f54'); clip(BAG, () => soft(x => fill(ellipseP(220, 940, 70, 90, 0.3), '#a07e70', x), 20, 1));
    { o.save(); o.setLineDash([5, 7]); stroke(P([[72, 800], [110, 880], [150, 960], [170, 1030]], false), '#1a1210', 5); stroke(P([[130, 800], [210, 850], [270, 920]], false), '#1a1210', 4); o.restore(); }
    ink(BAG);
    const SLAB = poly([[200, 900], [330, 950], [340, 1044], [180, 1044]]);
    fill(SLAB, '#a8a4a0'); ink(SLAB);
    const BOX = poly([[332, 840], [400, 820], [420, 900], [350, 940]]);
    fill(BOX, '#9a9898'); spots(BOX, 40, 15, ['#6a686a', '#cac8ca'], 1, 3, [332, 820, 420, 940]); ink(BOX);
    fill(poly([[96, 980], [120, 990], [112, 1024], [90, 1024]]), '#e8c030');
    // white egg on the hose, snow crosses, light corner
    fill(ellipseP(462, 342, 18, 22, 0.3), '#fbfbfb'); ink(ellipseP(462, 342, 18, 22, 0.3), 2);
    for (const [x, y, s] of [[290, 160, 18], [640, 270, 20], [230, 360, 12], [680, 560, 14], [520, 820, 10]]) { stroke(P([[x - s, y], [x + s, y]], false), '#fbfbfb', 6); stroke(P([[x, y - s], [x, y + s]], false), '#fbfbfb', 6); }
    fill(sm([[690, 950], [746, 930], [746, 1044], [680, 1044]]), '#c8c6c4');
    E.grain(0.04, 4);
  }
});
