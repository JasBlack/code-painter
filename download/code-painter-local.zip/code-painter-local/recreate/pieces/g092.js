'use strict';
// g092 — "Blue ghost in stockings": a glowing periwinkle creature with an orange striped heart, stippled
// stripes and a yellow eye, wearing zebra-striped legs, tangled in cream tubes, adrift in starry space.
REC.register('g092', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, r0 = 0) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── background: blurry cream / brown / grey wall at left, black starfield at right ──
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y;
      vec3 L = mix(vec3(.86, .9, .84), vec3(.88, .93, .87), smoothstep(0., 300., y));
      L = mix(L, vec3(.6, .66, .65), smoothstep(380., 600., y));
      L = mix(L, vec3(.3, .32, .34), smoothstep(700., 850., y));
      L = mix(L, vec3(.2, .22, .3), smoothstep(880., 1000., y));
      vec3 c = L;
      // cream streak + brown column at the top
      float top = 1. - smoothstep(150., 230., y);
      c = mix(c, vec3(.98, .95, .8), top * exp(-pow((p.x - 55.) / 14., 2.)));
      c = mix(c, mix(vec3(.4, .33, .27), vec3(.22, .2, .18), smoothstep(90., 200., p.x)), top * smoothstep(68., 92., p.x));
      // darker toward the middle lower down
      c = mix(c, vec3(.06), (1. - top) * smoothstep(40., 160., p.x) * mix(.45, .95, smoothstep(560., 720., y)));
      c = mix(c, vec3(.012), smoothstep(160., 260., p.x));
      return c; }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), '#030303', 0, 0);
    img(bg);
    // stars
    { const r = rng(92); a.fillStyle = '#ffffff';
      for (let i = 0; i < 170; i++) { const x = 380 + r() * 346, y = r() * 1024, s = r(); a.globalAlpha = 0.5 + r() * 0.5; a.beginPath(); a.arc(x, y, s < 0.8 ? 0.7 + s * 1.2 : 2 + s * 2, 0, 6.283); a.fill(); }
      a.globalAlpha = 1; }

    // ── the body ──
    const bodyPts = [[232, 4], [300, -4], [400, -4], [470, 4], [490, 60], [540, 92], [566, 130], [590, 165], [598, 205], [584, 245], [564, 282], [540, 322], [508, 360], [490, 400], [486, 440],
      [510, 520], [522, 600], [556, 642], [586, 646], [600, 690], [590, 724], [610, 762], [624, 802], [620, 842], [604, 882], [596, 922], [582, 960], [552, 1000], [520, 1030], [360, 1030],
      [320, 720], [190, 676], [156, 640], [152, 560], [140, 484], [104, 444], [80, 402], [64, 360], [60, 320], [62, 280], [78, 242], [112, 204], [172, 168], [172, 124], [186, 84], [204, 44]];
    const body = P(bodyPts, true, true);
    // glow halo
    soft(x => { x.lineWidth = 34; x.strokeStyle = '#2e6cff'; x.stroke(body); }, 16, 0.9);
    soft(x => { x.lineWidth = 12; x.strokeStyle = '#4c8cff'; x.stroke(body); }, 5, 1);
    a.fillStyle = rad(388, 30, 330, [[0, '#fbe2d2'], [0.18, '#e6d2cc'], [0.38, '#b6b4c6'], [0.6, '#8ca4d8'], [0.85, '#76a6f2'], [1, '#6c9cf0']]); a.fill(body);
    clipA(body, () => {
      soft(x => { x.lineWidth = 6; x.strokeStyle = '#bcd8ff'; x.stroke(body); }, 2, 0.8);
      soft(x => { x.fillStyle = '#3e62b0'; x.fill(ellipseP(250, 620, 120, 120, 0)); x.fill(ellipseP(520, 880, 90, 140, 0)); }, 40, 0.5);
    });
    // ruffles (blue frills with ridges)
    const scal = (pts, len, amp) => {
      const out = [], n = pts.length; let acc = 0;
      for (let i = 0; i < n - 1; i++) {
        const p0 = pts[i], p1 = pts[i + 1], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), k = Math.max(1, Math.round(L / 3));
        const nx = (p1[1] - p0[1]) / L, ny = -(p1[0] - p0[0]) / L;
        for (let j = 0; j < k; j++) { const u = j / k, d = amp * Math.pow(Math.abs(Math.sin(Math.PI * (acc + L * u) / len)), 0.7); out.push([p0[0] + (p1[0] - p0[0]) * u + nx * d, p0[1] + (p1[1] - p0[1]) * u + ny * d]); }
        acc += L;
      }
      return out;
    };
    const ruffL = P([...scal([[150, 480], [150, 560], [160, 640], [200, 690], [262, 708], [320, 700]], 34, 12), [330, 600], [300, 520], [240, 490]], true, false);
    const ruffR = P([[480, 640], [520, 650], ...scal([[560, 640], [600, 690], [592, 728], [612, 764], [628, 806], [622, 846], [606, 884], [598, 922], [584, 960], [552, 1004], [520, 1030]], 30, 10), [440, 1030], [440, 800]], true, false);
    for (const rf of [ruffL, ruffR]) {
      soft(x => { x.lineWidth = 16; x.strokeStyle = '#3c7cff'; x.stroke(rf); }, 8, 0.8);
      a.fillStyle = lin(0, 480, 0, 1024, [[0, '#4e8cf2'], [1, '#3f7ee8']]); a.fill(rf);
      clipA(rf, () => {
        const rr = rng(rf === ruffL ? 3 : 4); a.lineCap = 'round';
        for (let i = 0; i < 110; i++) {
          const x = (rf === ruffL ? 150 : 440) + rr() * 190, y = (rf === ruffL ? 480 : 640) + rr() * (rf === ruffL ? 230 : 390);
          a.strokeStyle = rr() < 0.3 ? 'rgba(150,195,255,0.5)' : 'rgba(16,44,150,0.55)'; a.lineWidth = 1.5 + rr() * 2;
          a.beginPath(); a.moveTo(x, y); a.quadraticCurveTo(x + 10, y + 8, x + 14 + rr() * 10, y + 22 + rr() * 10); a.stroke();
        }
        a.lineWidth = 4; a.strokeStyle = 'rgba(200,225,255,0.7)'; a.stroke(rf);
      });
    }

    // ── face details ──
    // warm glow behind the orange heart
    clipA(body, () => soft(x => { x.fillStyle = '#ffb48c'; x.fill(ellipseP(385, 220, 80, 170, 0)); x.fill(circleP(520, 270, 36)); }, 26, 0.55));
    clipA(body, () => { a.fillStyle = 'rgba(244,150,110,0.85)'; a.fill(circleP(522, 268, 32)); });
    // stippled dark stripes
    { const sr = rng(921);
      const band = (cl, w, n) => {
        const pth = P(lock(cl, w, w * 0.6), true, true);
        clipA(pth, () => { a.fillStyle = '#2a2236'; for (let i = 0; i < n; i++) { const t = sr(), q = cl[Math.min(cl.length - 1, Math.floor(t * (cl.length - 1)))], q2 = cl[Math.min(cl.length - 1, Math.floor(t * (cl.length - 1)) + 1)]; const u = (t * (cl.length - 1)) % 1;
          const x = q[0] + (q2[0] - q[0]) * u + (sr() - 0.5) * w * 1.1, y = q[1] + (q2[1] - q[1]) * u + (sr() - 0.5) * 14; a.globalAlpha = 0.5 + sr() * 0.5; a.beginPath(); a.arc(x, y, 0.6 + sr() * 1.1, 0, 6.283); a.fill(); } a.globalAlpha = 1; });
      };
      band([[318, 40], [308, 120], [296, 200], [302, 280], [318, 340], [330, 400]], 16, 1600);
      band([[340, 40], [334, 120], [326, 200], [330, 280], [342, 350]], 9, 800);
      band([[426, 40], [428, 120], [438, 200], [450, 260]], 14, 1000);
      band([[448, 50], [452, 120], [462, 190]], 8, 500);
      band([[300, 60], [290, 140], [280, 220], [286, 300], [300, 360], [312, 410]], 6, 500);
      // fine stipple around the eye
      clipA(body, () => { a.fillStyle = '#3a3048'; for (let i = 0; i < 700; i++) { const t = sr() * 6.283, rr = 30 + Math.pow(sr(), 0.6) * 90; a.globalAlpha = 0.25 + sr() * 0.4; a.beginPath(); a.arc(238 + Math.cos(t) * rr, 330 + Math.sin(t) * rr * 0.9, 0.6 + sr() * 0.9, 0, 6.283); a.fill(); } a.globalAlpha = 1; });
      a.fillStyle = '#4a3a40'; for (const [x, y, rx, ry] of [[340, 330, 5, 9], [352, 352, 5, 8], [344, 372, 4, 7], [358, 390, 4, 6]]) a.fill(ellipseP(x, y, rx, ry, 0.2));
    }
    // orange striped heart
    const heart = P([[372, 118], [392, 128], [406, 160], [416, 210], [418, 260], [408, 300], [388, 318], [366, 306], [350, 270], [344, 220], [350, 165], [360, 130]], true, true);
    a.fillStyle = lin(0, 120, 0, 320, [[0, '#f59a3a'], [0.5, '#fb8f2e'], [1, '#f6a446']]); a.fill(heart);
    clipA(heart, () => { a.strokeStyle = '#d8541c'; a.lineWidth = 1.6; for (let y = 124; y < 320; y += 10.5) { a.beginPath(); a.moveTo(330, y); a.quadraticCurveTo(380, y + 4, 430, y); a.stroke(); } });
    // cheek and eye
    a.fillStyle = '#f7ae8c'; a.fill(circleP(153, 335, 37));
    a.fillStyle = '#f2cf1e'; a.fill(circleP(225, 323, 24));
    a.fillStyle = '#0c0a0c'; a.fill(circleP(226, 323, 17.5));
    a.fillStyle = '#ffffff'; for (const [x, y, r] of [[201, 279, 4], [247, 356, 4], [242, 334, 2]]) a.fill(circleP(x, y, r));

    // ── the arm (cream with an orange tip) ──
    const arm = P([[480, 456], [530, 446], [600, 438], [650, 428], [690, 420], [740, 424], [740, 590], [706, 580], [694, 548], [660, 556], [620, 590], [580, 630], [540, 652], [510, 640], [488, 560]], true, true);
    soft(x => { x.lineWidth = 22; x.strokeStyle = '#3a78ff'; x.stroke(arm); }, 10, 0.8);
    a.fillStyle = lin(480, 500, 726, 500, [[0, '#e8dcd6'], [0.35, '#fbf4ec'], [0.6, '#f4dccc'], [0.78, '#f68a5a'], [1, '#e8502e']]); a.fill(arm);
    clipA(arm, () => soft(x => { x.fillStyle = '#ffffff'; x.fill(ellipseP(600, 470, 70, 26, -0.1)); x.fillStyle = '#b0a8c0'; x.fill(ellipseP(560, 620, 60, 40, 0)); }, 16, 0.7));
    // yellow glint under the bubble
    soft(x => { x.fillStyle = '#ffe24a'; x.fill(ellipseP(540, 485, 22, 6, -0.1)); }, 3, 0.95);

    // ── zebra legs ──
    const legA = P([[402, 330], [440, 300], [472, 292], [466, 380], [474, 450], [492, 560], [494, 640], [482, 760], [456, 860], [428, 960], [404, 1034], [226, 1034], [250, 960], [276, 880], [300, 800], [314, 720], [320, 600], [330, 480], [356, 392]], true, true);
    const legB = P([[118, 760], [160, 726], [222, 706], [284, 704], [314, 730], [312, 800], [300, 870], [272, 960], [248, 1034], [46, 1034], [56, 950], [76, 870], [96, 806]], true, true);
    const zA = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float Y = (p.y - 600.) / 100., X = (p.x - 400.) / 100.;
      float k = 6.2351 + 1.5379 * Y - 0.10951 * Y * Y + 0.034932 * Y * Y * Y - 0.0049048 * Y * Y * Y * Y + 0.21168 * X + 0.038774 * X * Y;
      float v = cos(6.2832 * k);
      return mix(vec3(.96, .95, .92), vec3(.02), smoothstep(-.1, .1, v + .05)); }`);
    const zB = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x, y = p.y;
      float k = 0.431337 - 0.0285775 * x - 0.004 * y + 2.08587e-5 * x * x + 1.77941e-5 * x * y + 7.56935e-6 * y * y;
      float v = cos(6.2832 * k);
      return mix(vec3(.96, .95, .92), vec3(.02), smoothstep(-.1, .1, v)); }`);
    clipA(legA, () => img(zA));
    R.dome(legA, null, 0.1, 0.35, 70, 2);
    clipA(legB, () => img(zB));
    R.dome(legB, null, 0.2, 0.35, 80, 2);
    // faint green net lines on the legs
    for (const lg of [legA, legB]) clipA(lg, () => { const nr = rng(lg === legA ? 7 : 8); a.strokeStyle = 'rgba(120,190,150,0.35)'; a.lineWidth = 0.8;
      for (let i = 0; i < 26; i++) { const x = 40 + nr() * 480, y = 300 + nr() * 740; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 60 - nr() * 120, y + 30 + nr() * 60); a.stroke(); } });

    // ── cream tubes ──
    const tube = (pts, w, cap = true) => {
      const pth = P(pts, false, true);
      R.pipe(pth, w + 3, '#5a5650', 0.3, 0.02, 0);
      R.pipe(pth, w, '#f6ecd8', 0.3, 0.18, 3);
      if (cap) { const e = pts[0]; R.bead(e[0], e[1], w * 0.55, '#f4f2ee', 0.32, 0.18, 4); }
    };
    tube([[305, -6], [292, 18], [252, 40], [216, 70], [186, 110], [182, 150], [205, 176], [245, 196], [276, 218], [296, 252], [302, 300], [306, 360], [316, 410], [332, 452], [342, 500]], 20, false);
    tube([[12, 527], [40, 513], [80, 505], [130, 500], [180, 490], [220, 466], [250, 436], [286, 416], [320, 418], [345, 440], [356, 472]], 18);
    tube([[130, 603], [170, 590], [220, 572], [270, 552], [310, 540], [340, 536]], 16);
    tube([[386, 648], [386, 614], [372, 584], [340, 564], [300, 562], [266, 580], [246, 620], [250, 680], [270, 720], [294, 742]], 17);
    tube([[364, 792], [368, 756], [354, 720], [324, 702], [300, 704], [284, 726]], 15);
    tube([[482, 996], [488, 920], [494, 840], [490, 760], [480, 680], [474, 600], [470, 520], [466, 450], [462, 392]], 14);
    tube([[372, 1034], [376, 960], [386, 900], [406, 860], [450, 836], [496, 816], [530, 780], [546, 730], [536, 680], [512, 620], [492, 560], [482, 500], [478, 430], [470, 386]], 18, false);
    tube([[392, 1034], [398, 960], [412, 900], [430, 830], [442, 772]], 13, false);
    tube([[48, 1034], [54, 1000], [64, 920], [72, 850], [70, 780], [56, 742], [30, 728], [-6, 736]], 18, false);
    tube([[-6, 800], [20, 790], [34, 800]], 12, false);
    tube([[440, 780], [452, 740], [470, 700]], 12, false);
    tube([[290, 760], [276, 820], [262, 880]], 12, false);
    tube([[280, 1034], [300, 960], [330, 900], [370, 860], [420, 840], [456, 800], [462, 760]], 14, false);
    tube([[270, 1034], [296, 980], [318, 930], [340, 880]], 12, false);
    tube([[230, 470], [236, 520], [250, 560], [290, 600], [320, 640]], 13, false);
    tube([[200, 440], [180, 470], [176, 520], [190, 560]], 12, false);
    tube([[350, 600], [390, 640], [430, 700], [446, 740]], 12, false);

    // ── the white bottle with black dots ──
    tube([[536, -6], [546, 20], [548, 50], [545, 84]], 22, false);
    const bottle = P([[516, 108], [560, 112], [572, 160], [566, 210], [568, 260], [556, 302], [528, 336], [506, 368], [484, 384], [456, 384], [438, 366], [438, 340], [454, 316], [470, 286], [480, 240], [490, 186], [500, 140]], true, true);
    R.dome(bottle, '#e4e2e8', 0.3, 0.3, 30, 4);
    for (let i = 0; i < 3; i++) R.pipe(P([[522, 84 + i * 8], [566, 92 + i * 8]], false), 7, '#ece6dc', 0.5, 0.1, 4);
    for (const [x, y] of [[506, 184], [528, 189], [491, 234]]) R.dome(circleP(x, y, 9), '#0a0a0c', 0.6, 0.04, 4, 5);
    R.bead(473, 316, 11, '#e8e6ea', 0.6, 0.12, 4);
    // top cap of the creature
    R.dome(rrect(345, -20, 100, 52, 18), '#eceaea', 0.2, 0.15, 14, 4);
    R.dome(P([[214, 2], [240, -6], [262, 10], [252, 40], [226, 48], [210, 30]]), '#a8b8d8', 0.15, 0.1, 10, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.6, ao: 0.3 }),                              // 2 striped legs
        E.mat({ dif: 1.05, spec: 0.25, shin: 20, wrap: 0.5, ao: 0.6 }),                            // 3 tubes
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.45, ao: 0.4, rim: 0.3 }),                    // 4 white plastic
        E.mat({ dif: 1, spec: 1.2, shin: 80, coat: 0.25 })                                         // 5 gloss black
      ],
      light: [-0.4, 0.45, 0.8], lc: [0.8, 0.79, 0.76], amb: [0.36, 0.36, 0.38],
      envTop: [1, 1, 1], envHor: [0.5, 0.55, 0.7], envBot: [0.12, 0.14, 0.24], envK: [0.2, 0.7, 0.3, 0],
      rimC: [0.25, 0.4, 0.9], rimD: [0, 0, 0], r1: 1.4, r2: 8, k: [0, 0.6, 0.4, 110], shadow: [-5, 7, 0.45, 6]
    });

    // ── bubbles ──
    const bubble = (x, y, r) => {
      o.fillStyle = rad(x, y, r, [[0, 'rgba(255,255,255,0.08)'], [0.7, 'rgba(200,220,255,0.15)'], [0.9, 'rgba(255,150,170,0.6)'], [1, 'rgba(255,255,255,0.9)']], o); o.fill(circleP(x, y, r));
      o.save(); o.clip(circleP(x + 2, y + 2, r * 0.6));
      const br = rng(x | 0); for (let i = 0; i < 70; i++) { o.fillStyle = br() < 0.5 ? '#111' : '#f4f4f4'; o.fill(circleP(x - r * 0.6 + br() * r * 1.4, y - r * 0.6 + br() * r * 1.4, 1.4)); }
      o.restore();
      o.fillStyle = 'rgba(255,255,255,0.9)'; o.fill(ellipseP(x - r * 0.45, y - r * 0.5, r * 0.22, r * 0.12, -0.7));
      o.save(); o.lineCap = 'round'; o.lineWidth = 4; o.strokeStyle = '#d8d8dc'; o.beginPath(); o.moveTo(x, y + r * 0.6); o.lineTo(x + (x > 600 ? -18 : 8), y + r + 14); o.stroke(); o.restore();
    };
    bubble(537, 438, 26); bubble(617, 697, 26);
    E.grain(0.035, 92);
  }
});
