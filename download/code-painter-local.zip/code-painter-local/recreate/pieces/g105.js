'use strict';
// g105 — "Pearl caterpillar fringe": a white clay caterpillar sprouting a fan of clay fingers over a pale floor,
// wavy clay ribbons, zebra spiral wells, a pearl cluster, wavy op-art stripes, space and soap bubbles.
REC.register('g105', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const CLAY = '#cbc1c0';

    // ── space with a golden nebula web ──
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.02), w = smoothstep(0.05, 0.0, abs(fbm(p * 0.03 + 4.) - 0.5));
      float ring = smoothstep(4., 0., abs(length(p - vec2(170., 45.)) - 22.));
      float fog = exp(-length(p - vec2(0., 0.)) / 180.);
      vec3 c = vec3(.02) + vec3(.55, .45, .32) * fog * (0.6 + 0.6 * n) + vec3(.6, .5, .35) * (w * 0.5 + ring) * smoothstep(320., 120., p.x);
      float st = step(0.9965, hash(floor(p / 2.)));
      return c + vec3(.8, .85, 1.) * st * smoothstep(200., 600., p.x + 0.0 * p.y); }`));

    // ── pale floor ──
    const floor = P([[-10, 170], [120, 200], [260, 232], [420, 300], [500, 420], [480, 700], [470, 1040], [-10, 1040]], true, true);
    R.flat(floor, null, 0.02, 1);
    clipA(floor, () => {
      a.fillStyle = lin(0, 200, 0, 1024, [[0, '#c4c0bc'], [0.4, '#c8c5c0'], [1, '#c6c3be']]); a.fillRect(-10, 160, 520, 900);
      soft(x => { x.fillStyle = '#c6d2c8'; x.fill(ellipseP(420, 940, 110, 100, 0)); x.fillStyle = '#b8b4b0'; x.fill(ellipseP(330, 560, 120, 140, 0.4)); }, 40, 0.7);
    });

    // ── wavy op-art stripes (right), grey near the top ──
    const zr = P([[440, -10], [740, -10], [740, 570], [540, 570], [470, 420], [460, 240]], true, false);
    R.flat(zr, null, 0.06, 6);
    clipA(zr, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(650., 150.); float r = length(d) / 100., t = atan(d.y, d.x);
      float ph = -1.83079 + 5.06677 * r - 0.02478 * r * r + 1.40014 * t - 0.26578 * t * t - 1.89667 * r * t
               - 0.76276 * sin(3. * t) + 0.36444 * cos(3. * t) + 0.37053 * sin(6. * t) - 0.10732 * cos(6. * t) - 0.05143 * sin(9. * t) - 0.11671 * cos(9. * t);
      float k = smoothstep(-0.15, 0.15, cos(6.2832 * ph));
      vec3 wh = vec3(.93, .93, .94), bk = vec3(.03);
      float grey = smoothstep(240., 150., p.y) * smoothstep(660., 600., p.x);
      wh = mix(wh, vec3(.72, .72, .74), grey); bk = mix(bk, vec3(.36, .36, .38), grey);
      return mix(wh, bk, k); }`)));
    // grey folded tube
    R.pipe(P([[492, -20], [478, 40], [466, 100], [476, 158], [506, 196], [560, 216], [630, 214], [680, 205]], false, true), 52, '#b8b8bc', 0.12, 0.34, 2);

    // ── fine-ring disc (top right) ──
    R.dome(circleP(706, 100, 96), '#808084', 0.16, 0.06, 10, 2);
    clipA(circleP(706, 100, 90), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float r = length(p - vec2(708., 98.)) + 2.5 * fbm(p * 0.08);
      float v = abs(fract(r / 7.5) - 0.5);
      return mix(vec3(.08), vec3(.9), smoothstep(0.18, 0.26, v)); }`)));
    R.flat(circleP(706, 100, 90), null, 0.2, 6);

    // ── concentric zebra (lower right) ──
    const lr = P([[740, 680], [640, 735], [560, 770], [500, 806], [470, 870], [470, 1040], [740, 1040]], true, true);
    R.flat(lr, null, 0.06, 6);
    clipA(lr, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float X = (p.x - 600.) / 100., Y = (p.y - 900.) / 100.;
      float ph = -0.58555 - 1.07829 * Y + 0.65044 * Y * Y - 2.43003 * X - 0.44176 * X * Y + 0.45747 * X * X;
      return mix(vec3(.95, .95, .95), vec3(.03), smoothstep(-0.15, 0.15, cos(6.2832 * ph))); }`)));

    // ── zebra discs ──
    const disc = (x, y, r, per, arms, rim, h) => {
      R.dome(circleP(x, y, r), rim, h, 0.06, 10, 2);
      clipA(circleP(x, y, r * 0.9), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
        vec2 q = p - vec2(${x.toFixed(1)}, ${y.toFixed(1)}); float rr = length(q), an = atan(q.y, q.x);
        float ph = ${per > 20 ? '(rr - 40.) / (32. - 0.1 * (rr - 40.)) + 0.5' : 'rr / ' + per.toFixed(1) + ' + ' + arms.toFixed(1) + ' * an / 6.2832'};
        float v = abs(fract(ph) - 0.5);
        return mix(vec3(.04), vec3(.95), smoothstep(0.22, 0.27, v)); }`)));
      R.flat(circleP(x, y, r * 0.9), null, h + 0.04, 6);
    };
    disc(91, 411, 84, 9, 1, '#58585c', 0.06);
    disc(190, 845, 92, 12, 1, '#5a5a5e', 0.06);
    disc(680, 653, 122, 31, 0, '#3a3a3e', 0.1);

    // ── clay ribbons (top left) ──
    const ribY = [[25, 85, 150, 180], [62, 112, 170, 196], [100, 140, 190, 212], [138, 165, 210, 226], [176, 200, 232, 242], [214, 230, 252, 258], [252, 262, 272, 274]];
    ribY.forEach(([y0, y1, y2, y3], i) => {
      const pts = [];
      for (let x = -20; x <= 300; x += 15) {
        const yb = x < 100 ? y0 + (y1 - y0) * Math.max(0, x) / 100 : x < 200 ? y1 + (y2 - y1) * (x - 100) / 100 : y2 + (y3 - y2) * (x - 200) / 70;
        pts.push([x, yb + 6 * Math.sin(x * 0.045 + i * 1.3)]);
      }
      R.pipe(P(pts, false, true), 32, CLAY, 0.1, 0.26, 1);
    });
    // dark gap under the caterpillar's tail
    R.flat(P([[410, 370], [480, 350], [530, 390], [520, 470], [490, 530], [440, 540], [400, 500]], true, true), '#060606', 0.05, 0);
    // ── fan of clay fingers ──
    const tips = [[92, 302], [148, 352], [162, 402], [190, 472], [222, 546], [240, 582], [264, 622], [288, 668], [316, 700], [352, 690]];
    tips.forEach(([tx, ty], i) => {
      const u = i / (tips.length - 1), sx = 330 + 160 * u, sy = 262 + 220 * u, pts = [];
      const dx = tx - sx, dy = ty - sy, L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      for (let k = 0; k <= 16; k++) { const t = k / 16, w = 15 * Math.sin(t * Math.PI * 2.6 + i * 0.7) * Math.min(1, t * 3); pts.push([sx + dx * t + nx * w, sy + dy * t + ny * w]); }
      R.pipe(P(pts, false, true), 37, CLAY, 0.12, 0.28, 1);
    });

    // ── blue pool + caterpillar ──
    const pool = P([[244, 124], [296, 106], [366, 110], [398, 140], [400, 182], [330, 194], [262, 204], [240, 172]], true, true);
    R.dome(pool, '#eef2f6', 0.12, 0.06, 8, 1);
    R.flat(P([[256, 128], [300, 116], [362, 120], [388, 146], [386, 176], [330, 184], [266, 192], [252, 168]], true, true), null, 0.14, 0);
    clipA(P([[256, 128], [300, 116], [362, 120], [388, 146], [386, 176], [330, 184], [266, 192], [252, 168]], true, true), () => {
      a.fillStyle = lin(250, 150, 390, 150, [[0, '#1e64e8'], [0.5, '#5aa0f0'], [1, '#2a70e8']]); a.fillRect(240, 100, 170, 110);
      const pr = rng(2); a.fillStyle = 'rgba(230,240,255,0.7)'; for (let i = 0; i < 200; i++) a.fill(circleP(270 + pr() * 110, 125 + pr() * 60, 0.8 + pr()));
    });
    const cr = rng(55);
    for (let k = 0; k < 40; k++) {
      const t = k / 39, x = 310 + 214 * t, y = 186 + 194 * t, r = 70 - 40 * t, nx = -0.67, ny = 0.74;
      const o_ = (cr() - 0.5) * 0.9, rad_ = r * (0.55 + cr() * 0.3), cx = x + nx * o_ * r, cy = y + ny * o_ * r;
      R.dome(ellipseP(cx, cy, rad_ * (1 + cr() * 0.25), rad_ * 0.85, -0.75 + (cr() - 0.5) * 0.6), CLAY, 0.24, 0.26, rad_ * 0.8, 1);
    }

    // ── small spiral half-hidden by the pearls, black berries, teardrop ──
    disc(485, 556, 72, 9, 1, '#4a4a4e', 0.08);
    for (const [x, y, r] of [[386, 598, 18], [410, 584, 16], [404, 616, 17], [392, 612, 12]]) R.bead(x, y, r, '#0c0c0e', 0.14, 0.14, 4);
    R.dome(P([[390, 638], [406, 660], [418, 720], [410, 760], [390, 772], [370, 760], [362, 720], [374, 660]], true, true), '#d8d4dc', 0.1, 0.36, 26, 4);

    // ── pearl cluster ──
    const pearls = [], prr = rng(105);
    for (let k = 0; k < 4000 && pearls.length < 120; k++) {
      const t = prr(), cx = 700 - t * 250, cy = 360 + t * 480, hw = 90 - t * 50;
      const x = cx + (prr() - 0.5) * 2 * hw, y = cy + (prr() - 0.5) * 2 * hw * 0.6, r = 14 + prr() * (34 - t * 18);
      if (x > 760 || y < 330) continue;
      if (pearls.every(b => Math.hypot(b[0] - x, b[1] - y) > (b[2] + r) * 0.82)) pearls.push([x, y, r]);
    }
    pearls.sort((p, q) => p[1] - q[1]);
    for (const [x, y, r] of pearls) R.dome(circleP(x, y, r), rad(x - r * 0.3, y - r * 0.4, r * 1.3, [[0, '#f2eeee'], [1, '#cfc8c8']]), 0.2, 0.3, r * 0.9, 3);
    // drip at the bottom
    R.dome(P([[450, 860], [478, 870], [490, 930], [488, 980], [470, 1000], [452, 990], [446, 930]], true, true), '#e0dce2', 0.2, 0.3, 22, 4);
    for (const [x, y, r] of [[495, 435, 7], [118, 652, 4], [304, 730, 6], [92, 812, 6], [332, 855, 4], [10, 690, 4], [128, 135, 3], [6, 375, 5]]) R.bead(x, y, r, '#ece8e8', 0.04, 0.05, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 26, wrap: 0.35, ao: 0.9, coat: 0.04 }),          // 1 clay
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.12 }),           // 2 grey gloss / rims
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.45, ao: 0.4, coat: 0.15 }),          // 3 pearls
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, coat: 0.3 }),                     // 4 gloss
        E.mat({}),
        E.mat({ dif: 0.85, spec: 0.3, shin: 30, wrap: 0.6, emis: 0.12 })                  // 6 stripe fields
      ],
      light: [-0.4, 0.62, 0.68], lc: [0.75, 0.75, 0.76], amb: [0.42, 0.42, 0.44],
      envTop: [1, 1, 1], envHor: [0.6, 0.6, 0.62], envBot: [0.12, 0.12, 0.13], envK: [0.2, 0.9, 0.2, 0],
      r1: 1.8, r2: 12, k: [0, 0.6, 0.4, 70], shadow: [-8, 10, 0.7, 6]
    });

    // ── soap bubbles ──
    const bubble = (x, y, r, dark) => {
      o.save(); o.clip(circleP(x, y, r));
      o.fillStyle = dark ? 'rgba(40,40,60,0.45)' : 'rgba(230,240,255,0.08)'; o.fill(circleP(x, y, r));
      const cg = o.createConicGradient(0.4, x, y);
      [['#ff50d0', 0], ['#50e0ff', 0.18], ['#fff070', 0.34], ['#70ffa0', 0.46], ['#8070ff', 0.62], ['#ff70b0', 0.78], ['#50d0ff', 0.9], ['#ff50d0', 1]].forEach(([c, t]) => cg.addColorStop(t, c));
      o.globalAlpha = dark ? 0.7 : 0.5; o.lineWidth = r * 0.16; o.strokeStyle = cg; o.filter = `blur(${r * 0.05 * S}px)`; o.stroke(circleP(x, y, r * 0.93));
      o.filter = 'none'; o.globalAlpha = 1;
      o.fillStyle = 'rgba(255,255,255,0.85)'; o.fill(ellipseP(x - r * 0.35, y - r * 0.42, r * 0.2, r * 0.1, -0.6));
      o.restore();
      o.lineWidth = Math.max(0.8, r * 0.025); o.strokeStyle = 'rgba(240,244,255,0.6)'; o.stroke(circleP(x, y, r - 0.5));
    };
    for (const [x, y, r] of [[603, 235, 13], [528, 330, 15], [147, 378, 12], [55, 404, 12], [183, 510, 9], [306, 598, 15], [540, 822, 22], [42, 317, 8], [185, 937, 8]]) bubble(x, y, r, true);
    bubble(682, 652, 32, false);
    bubble(420, 940, 96, false);
    E.grain(0.025, 105);
  }
});
