'use strict';
// u095 — "Neon-bound green sleeper": an airbrushed figure with a bandaged navy head and a glowing green face,
// a red mouth-oval and a red/green striated body, a dark hand raising a blue-violet orb, neon green outlines,
// a grey dripping mask behind, red smoke and starry navy night.
REC.register('u095', {
  w: 726, h: 1024,
  draw(E) {
    const S = E.S, o = E.out;
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      o.save(); if (clipP) o.clip(clipP); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore();
    };
    const clipO = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const img = (cv, alpha = 1, op = 'source-over') => { o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op; o.drawImage(cv, 0, 0); o.restore(); };
    const lin = (x0, y0, x1, y1, stops, c = o) => { const g = c.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, k]) => g.addColorStop(t, k)); return g; };
    const rad = (x, y, r, stops, c = o, x1 = x, y1 = y) => { const g = c.createRadialGradient(x, y, 0, x1, y1, r); stops.forEach(([t, k]) => g.addColorStop(t, k)); return g; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const fill = (path, c, x = o) => { x.fillStyle = c; x.fill(path); };
    const stroke = (path, c, wd, x = o) => { x.lineWidth = wd; x.strokeStyle = c; x.lineCap = x.lineJoin = 'round'; x.stroke(path); };
    const stars = (path, n, seed, rmax = 1.4) => clipO(path, () => { const r = rng(seed); for (let i = 0; i < n; i++) { o.globalAlpha = 0.3 + r() * 0.7; fill(circleP(r() * 726, r() * 1024, 0.4 + r() * r() * rmax), '#e8eef8'); } o.globalAlpha = 1; });
    const neon = (pts, core, glow, wd = 3, gw = 14) => {
      const p = line(pts);
      soft(x => stroke(p, glow, gw, x), gw * 0.7, 0.9, 'screen');
      soft(x => stroke(p, glow, wd * 2.2, x), 2, 1);
      stroke(p, core, wd);
    };

    // ── night, red smoke, black right edge ──
    o.fillStyle = '#151a28'; o.fillRect(0, 0, 726, 1024);
    soft(x => {
      fill(sm([[-20, 360], [60, 380], [150, 470], [200, 600], [220, 760], [200, 880], [120, 930], [-20, 940]]), '#5c1412', x);
      fill(sm([[580, 300], [660, 290], [746, 300], [746, 820], [680, 820], [600, 780], [570, 640], [570, 450]]), '#62120e', x);
      fill(rrect(640, -20, 120, 1080, 0), '#0c0b0e', x);
      fill(sm([[600, -20], [746, -20], [746, 300], [660, 300], [630, 220], [600, 120]]), '#0e0d10', x);
    }, 10);
    // red right panel texture: wavy stripes
    const RT = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = fbm(p * vec2(0.02, 0.006) + 3.) * 9.;
      float s = sin(p.y * 0.95 + w * 4. + sin(p.x * 0.06) * 3.);
      float m = smoothstep(-0.3, 0.3, s);
      vec3 c = mix(vec3(0.16, 0.02, 0.02), vec3(0.62, 0.09, 0.05), m);
      float holes = smoothstep(0.62, 0.7, fbm(p * 0.012 + 9.));
      return mix(c, vec3(0.03, 0.02, 0.03), holes); }`);
    const redR = sm([[624, 316], [690, 300], [746, 310], [746, 800], [690, 812], [628, 770], [600, 660], [612, 480]]);
    clipO(redR, () => img(RT, 0.9));
    soft(x => fill(sm([[-20, 640], [60, 660], [140, 760], [170, 860], [100, 900], [-20, 900]]), '#a02210', x), 30, 0.8);

    // ── the grey dripping mask (hood) ──
    const hood = sm([[26, 130], [36, 92], [70, 64], [130, 48], [220, 42], [300, 38], [330, -10], [560, -10], [610, 40], [636, 140], [640, 230], [600, 300], [520, 360], [420, 400], [330, 420], [240, 430], [150, 420], [60, 390], [30, 300]]);
    fill(hood, rad(360, 140, 380, [[0, '#6a88aa'], [0.45, '#506884'], [0.8, '#36445a'], [1, '#262e40']]));
    clipO(hood, () => {
      soft(x => {
        fill(ellipseP(470, 60, 160, 60, 0.1), 'rgba(140,170,205,0.7)', x);
        fill(ellipseP(200, 60, 120, 40, -0.1), 'rgba(140,165,195,0.6)', x);
        fill(ellipseP(80, 220, 50, 120, 0), 'rgba(120,145,175,0.5)', x);
        fill(ellipseP(260, 360, 90, 50, 0), 'rgba(100,125,160,0.5)', x);
      }, 18, 1);
      // tapering drip slits
      const taper = (cl, w0, w1) => { const L = [], Rr = [], n = cl.length; for (let i = 0; i < n; i++) { const q0 = cl[Math.max(0, i - 1)], q1 = cl[Math.min(n - 1, i + 1)]; let dx = q1[0] - q0[0], dy = q1[1] - q0[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d; const w = (w0 + (w1 - w0) * i / (n - 1)) / 2; L.push([cl[i][0] - dy * w, cl[i][1] + dx * w]); Rr.push([cl[i][0] + dy * w, cl[i][1] - dx * w]); } return sm([...L, ...Rr.reverse()]); };
      for (const [cl, w0, w1] of [[[[78, 118], [70, 180], [66, 240], [70, 290]], 15, 4], [[[118, 128], [108, 200], [104, 260], [110, 302]], 17, 4], [[[160, 140], [152, 210], [150, 270], [156, 312]], 17, 4],
        [[[200, 150], [194, 200], [192, 254]], 15, 4], [[[232, 120], [222, 170], [218, 222]], 15, 3], [[[270, 100], [258, 150], [248, 200], [244, 234]], 17, 4], [[[302, 86], [292, 122], [284, 162]], 12, 3]]) {
        const p = taper(cl, w0, w1);
        soft(x => stroke(p, 'rgba(170,198,228,0.85)', 7, x), 2.5, 0.8);
        fill(p, '#0b0e18');
      }
      soft(x => fill(ellipseP(190, 112, 130, 16, -0.08), 'rgba(150,175,205,0.55)', x), 8, 1);
      // dark top bowl
      soft(x => fill(ellipseP(200, 10, 140, 34, 0), '#0e121c', x), 5, 1);
    });
    soft(x => fill(ellipseP(10, 230, 30, 130, 0), '#c8ccd4', x), 14, 0.6);
    stars(hood, 120, 7, 1.6);
    // the rod with an orange flare
    soft(x => fill(ellipseP(306, 40, 22, 40, 0), '#ff7a2a', x), 10, 0.9, 'screen');
    stroke(line([[324, -10], [330, 80], [334, 156]]), '#b8c8d8', 8); stroke(line([[322, -10], [328, 80], [331, 156]]), '#f4f8ff', 3);

    // ── green face ──
    const face = sm([[452, 150], [520, 136], [580, 160], [620, 220], [624, 290], [590, 340], [540, 372], [522, 430], [560, 490], [610, 540], [580, 560], [530, 560], [470, 520], [420, 480], [380, 400], [400, 320], [440, 240]]);
    soft(x => fill(face, '#3c9a2e', x), 12, 0.9);
    fill(face, rad(560, 260, 260, [[0, '#4cae38'], [0.6, '#3a9030'], [1, '#2a6a24']]));
    clipO(face, () => { const r = rng(9); for (let i = 0; i < 500; i++) fill(circleP(380 + r() * 260, 130 + r() * 440, 0.6 + r()), r() < 0.5 ? '#2a6a22' : '#7ad060'); });
    stroke(line([[540, 220], [560, 250], [556, 300], [530, 330]]), 'rgba(30,70,30,0.7)', 6);
    stroke(sm([[538, 266], [560, 260], [574, 280], [560, 296], [540, 290]]), 'rgba(30,70,30,0.7)', 4);

    // ── bandaged navy head ──
    const head = sm([[300, 156], [356, 130], [430, 126], [500, 140], [540, 170], [550, 230], [520, 286], [480, 330], [440, 344], [390, 340], [360, 310], [320, 290], [292, 250], [300, 210]]);
    fill(head, lin(300, 130, 550, 340, [[0, '#2a3044'], [0.5, '#1c2030'], [1, '#262a3a']]));
    clipO(head, () => {
      for (let i = 0; i < 8; i++) {
        const y = 170 + i * 18;
        const p = line([[290, y + 6], [360, y - 2], [440, y + 4], [520, y + (i % 2 ? 10 : -4)]]);
        soft(x => stroke(p, 'rgba(150,180,215,0.8)', 4, x), 2.5, 0.8);
        stroke(p, 'rgba(10,12,20,0.7)', 3);
      }
      soft(x => fill(ellipseP(420, 150, 70, 22, 0), 'rgba(110,130,160,0.6)', x), 8, 1);
      soft(x => fill(ellipseP(500, 190, 30, 22, 0), 'rgba(90,110,140,0.8)', x), 6, 1);
    });
    for (const [x, y, r] of [[438, 284, 6], [362, 232, 4], [400, 296, 3]]) fill(circleP(x, y, r), '#e8f0f8');
    // chin / jaw with green neon lip
    fill(sm([[360, 300], [420, 296], [470, 318], [480, 344], [460, 350], [420, 340], [380, 330]]), '#1e2232');
    neon([[372, 312], [420, 300], [470, 318], [472, 340]], '#e8ffe0', '#5aff60', 2.5, 10);
    neon([[392, 302], [430, 306], [452, 324]], '#e8ffe0', '#5aff60', 2, 8);
    // red brow bar
    soft(x => fill(sm([[342, 356], [400, 350], [470, 356], [494, 372], [480, 384], [420, 376], [350, 380]]), '#e0401c', x), 2, 1);
    stroke(line([[352, 364], [420, 360], [480, 370]]), 'rgba(255,140,90,0.7)', 2);
    fill(circleP(500, 372, 5), '#0c0c10'); fill(circleP(498, 370, 2), '#ffffff');

    // ── striated red body ──
    const body = sm([[222, 424], [290, 400], [380, 398], [450, 414], [520, 440], [556, 520], [560, 700], [556, 900], [540, 950], [480, 972], [380, 980], [280, 968], [212, 920], [200, 780], [204, 600]]);
    const ST = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(660., 120.); float th = atan(d.x, d.y);
      float w = fbm(p * vec2(0.008, 0.003) + 1.7) * 2.2 + fbm(p * 0.025 + 4.) * 0.7;
      float s = sin(th * 430. + w * 9. + 2.5 * sin(p.y * 0.012 + p.x * 0.004));
      float top = smoothstep(600., 470., p.y) * smoothstep(250., 330., p.x);
      s = mix(s, sin(p.y * 0.85 + p.x * 0.12 + w * 8.), top);
      float lft = smoothstep(270., 215., p.x);
      s = mix(s, sin(p.x * 0.55 + w * 3.), lft);
      float g = smoothstep(420., 540., p.x + (fbm(p * 0.012) - .5) * 160.);
      vec3 red = vec3(0.8, 0.17, 0.07), dk = vec3(0.1, 0.16, 0.07), gr = vec3(0.24, 0.52, 0.2);
      vec3 c = mix(dk, red, smoothstep(-0.35 - lft * 0.3, 0.0, s));
      vec3 cg = mix(gr, red * 0.9, smoothstep(0.55, 0.8, s));
      return mix(c, cg, g * 0.9); }`);
    clipO(body, () => { img(ST); soft(x => fill(ellipseP(300, 700, 80, 260, 0), 'rgba(160,30,20,0.35)', x), 30, 1); });
    soft(x => stroke(body, 'rgba(0,0,0,0.6)', 10, x), 6, 0.6);

    // ── red mouth-oval with neon rim ──
    const mouth = P(blob(417, 486, 98, 52, 4, 16, 0.05, 0.03));
    soft(x => fill(mouth, '#ff3010', x), 20, 0.9, 'screen');
    fill(mouth, rad(417, 480, 100, [[0, '#d83420'], [0.7, '#c42818'], [1, '#a81c10']]));
    clipO(mouth, () => { const r = rng(12); for (let i = 0; i < 420; i++) fill(circleP(320 + r() * 200, 434 + r() * 106, 0.6 + r() * 1.8), r() < 0.7 ? '#2a0606' : '#ffd0c0'); });
    soft(x => stroke(mouth, '#ff4a2a', 10, x), 5, 1, 'screen');
    stroke(mouth, '#fff0e8', 2.5);
    neon([[380, 520], [420, 530], [460, 520]], '#fff0e0', '#ff5030', 2, 8);

    // ── blue-violet orb ──
    const orb = sm([[110, 470], [180, 440], [250, 444], [310, 480], [338, 560], [336, 640], [312, 700], [260, 724], [200, 724], [140, 700], [90, 640], [70, 560]]);
    fill(orb, rad(150, 500, 300, [[0, '#a8d8fc'], [0.25, '#7aa4ee'], [0.55, '#6a6ee4'], [0.8, '#5a48d0'], [1, '#3a2a9a']]));
    clipO(orb, () => {
      soft(x => { for (const [x0, w] of [[150, 26], [210, 18], [250, 14]]) stroke(line([[x0, 440], [x0 + 6, 600], [x0 - 4, 724]]), 'rgba(200,225,255,0.45)', w, x); }, 6, 1);
      stroke(line([[312, 560], [306, 640], [300, 700]]), 'rgba(220,235,255,0.8)', 2);
    });
    // dark navy profile in front of the orb
    const prof = sm([[52, 600], [96, 560], [150, 580], [190, 612], [214, 676], [196, 724], [160, 760], [110, 790], [64, 770], [48, 700]]);
    fill(prof, lin(50, 560, 214, 790, [[0, '#2a3460'], [0.4, '#121630'], [1, '#0a0c18']]));
    stars(prof, 40, 14, 1.2);
    soft(x => fill(ellipseP(150, 632, 14, 8, 0), '#f0f8ff', x), 3, 1);
    fill(ellipseP(148, 632, 7, 4, 0), '#ffffff');
    soft(x => stroke(line([[52, 600], [96, 560], [150, 580]]), '#9ab8ff', 4, x), 3, 0.7);

    // ── raised dark hand ──
    const palm = sm([[44, 430], [60, 392], [190, 384], [214, 420], [216, 470], [190, 500], [120, 506], [60, 490]]);
    const fingers = [[[74, 432], [50, 386], [32, 342]], [[104, 420], [94, 360], [88, 312]], [[140, 420], [134, 360], [130, 312]], [[176, 444], [200, 390], [190, 342]]];
    const fw = [30, 34, 34, 30];
    fingers.forEach((f, i) => stroke(line(f), '#bcd4f0', fw[i] + 4)); stroke(palm, '#bcd4f0', 4);
    const handG = lin(30, 310, 210, 500, [[0, '#2e3650'], [0.5, '#1e2234'], [1, '#141724']]);
    fingers.forEach((f, i) => stroke(line(f), handG, fw[i])); fill(palm, handG);
    soft(x => { fingers.forEach((f, i) => stroke(line(f.map(([px, py]) => [px - 5, py + 2])), 'rgba(110,135,180,0.55)', fw[i] * 0.3, x)); }, 4, 1);

    // ── smoke and glows on the left ──
    soft(x => {
      fill(sm([[-20, 830], [60, 846], [130, 870], [200, 880], [180, 920], [100, 940], [-20, 930]]), 'rgba(170,180,195,0.75)', x);
      fill(sm([[180, 700], [200, 690], [206, 760], [190, 800], [176, 760]]), '#ffffff', x);
    }, 8, 1);
    soft(x => { fill(circleP(116, 822, 26), '#ffb040', x); fill(circleP(4, 520, 24), '#ff9a40', x); fill(circleP(330, 542, 10), '#ffc070', x); }, 14, 0.9, 'screen');
    fill(circleP(116, 822, 7), '#fff0c0');
    soft(x => stroke(line([[186, 690], [196, 740], [190, 790]]), '#ff2a20', 18, x), 10, 0.8, 'screen');

    // ── lower right grey curl and dark red sphere ──
    soft(x => fill(sm([[566, 820], [620, 800], [690, 812], [746, 840], [746, 880], [690, 870], [630, 860], [590, 850]]), '#7a8aa8', x), 8, 0.9);
    fill(circleP(614, 598, 26), rad(608, 590, 28, [[0, '#a8342a'], [0.6, '#4a1010'], [1, '#1a0606']]));
    stars(sm([[560, 860], [746, 860], [746, 1034], [560, 1034]]), 160, 21, 1.6);
    stars(rrect(0, 930, 560, 100, 0), 200, 22, 1.6);
    soft(x => fill(ellipseP(380, 990, 220, 40, 0), 'rgba(60,80,110,0.6)', x), 20, 1);

    // ── neon outlines ──
    neon([[506, -4], [560, 30], [594, 70], [584, 104], [540, 118], [470, 118], [432, 130]], '#f0fff0', '#7aff8a', 3, 16);
    neon([[440, 120], [520, 126], [584, 158], [622, 222], [618, 290], [580, 332], [534, 364], [520, 420], [550, 474], [600, 520], [630, 556]], '#f0fff0', '#5aff60', 3.5, 18);
    neon([[612, 626], [630, 680], [668, 720], [706, 752], [726, 790]], '#f0fff4', '#4aff70', 4, 18);
    neon([[580, 818], [566, 860], [566, 920], [584, 970], [620, 1000]], '#f0faff', '#7ad0ff', 3, 12);
    soft(x => fill(sm([[200, 920], [300, 960], [420, 976], [540, 950], [560, 930], [480, 990], [300, 990]]), '#6a0e0a', x), 6, 0.6);

    E.bloom(0.15, 10);
    E.grain(0.05, 95);
  }
});
