'use strict';
// s24 — "Chrome zebra contact sheet": a 4×4 grid of solarised chrome figures, masks and
// emblems — black/white/ice-blue zebra stripes with red and blue halos on hot pink, red and sky blue.
REC.register('s24', {
  w: 1024, h: 1024,
  draw(E) {
    const W = 1024, S = E.S, o = E.out, C = 256;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const glow = (path, c, wd, px) => blurred(px, () => stroke(path, c, wd));
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops) => { const g = o.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const cell = (c, r) => rrect(c * C, r * C, C, C, 0);

    // ── solarised chrome zebra: per-cell stripe field (angle, period, warp, mode) + centre ──
    const zeb = pat(E.blur(E.fx(`
      const vec4 CA[16] = vec4[16](
        vec4(0.0, 11., 1.6, 0.), vec4(1.57, 9., 0.3, 0.), vec4(0.0, 9., 1.2, 0.), vec4(1.57, 12., 1.4, 0.),
        vec4(1.57, 10., 0.6, 0.), vec4(1.1, 13., 2.2, 0.), vec4(1.57, 9., 0.8, 0.), vec4(1.3, 8., 0.8, 0.),
        vec4(1.57, 12., 2.4, 0.), vec4(1.57, 11., 0.3, 0.), vec4(1.57, 9., 0.4, 0.), vec4(1.57, 9., 0.6, 0.),
        vec4(1.57, 10., 0.6, 0.), vec4(0.0, 9., 0.8, 1.), vec4(1.57, 10., 1.2, 0.), vec4(0.0, 10., 1.0, 1.));
      const vec2 CC[16] = vec2[16](vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(128.),
        vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(128.), vec2(175., 50.), vec2(128.), vec2(117., 60.));
      vec3 fx(vec2 uv, vec2 p){
        vec2 ci = floor(p / 256.); int k = int(ci.y) * 4 + int(ci.x);
        vec2 q = p - ci * 256.; vec4 A = CA[k];
        float w = A.z * (fbm(q * 0.012 + float(k) * 3.7) - .5) * 2.;
        float ph = A.w > .5 ? length(q - CC[k]) / A.y : dot(q, vec2(cos(A.x), sin(A.x))) / A.y;
        ph += w + .25 * sin(q.x * 0.03 + q.y * 0.02 + float(k));
        float v = sin(6.2832 * ph);
        vec3 dark = vec3(.02, .025, .05), ice = vec3(.62, .70, .84), wh = vec3(.96, .95, .96);
        vec3 c = mix(dark, ice, smoothstep(-.75, -.35, v));
        c = mix(c, wh, smoothstep(-.1, .5, v));
        return c; }`), 0.8));

    // ═════════ row 0 ═════════
    // (0,0) bearded man raising his hands, zebra robe
    clipped(cell(0, 0), () => {
      fill(cell(0, 0), lin(0, 0, 60, 256, [[0, '#ff5584'], [0.6, '#f3426c'], [1, '#e2345a']]));
      const robe = P([[18, 256], [22, 210], [30, 170], [48, 140], [80, 128], [110, 122], [165, 122], [196, 132], [222, 150], [236, 190], [240, 256]]);
      const sleeveL = P([[26, 200], [36, 160], [48, 132], [58, 118], [74, 124], [66, 150], [60, 190], [52, 215]], true);
      const sleeveR = P([[232, 200], [226, 160], [214, 130], [204, 116], [190, 124], [196, 150], [202, 190], [212, 215]], true);
      for (const s of [robe, sleeveL, sleeveR]) glow(s, 'rgba(255,255,255,0.9)', 14, 5);
      for (const s of [robe, sleeveL, sleeveR]) { fill(s, zeb); fill(s, 'rgba(20,24,40,0.3)'); stroke(s, '#0a0a14', 3); }
      fill(rrect(72, 236, 126, 12, 5), '#3d7fe0'); stroke(rrect(72, 236, 126, 12, 5), '#0a1840', 2);
      // hands
      const hand = (x, y, sgn) => {
        fill(ellipseP(x, y + 8, 14, 16, 0), '#2e2626');
        for (let i = 0; i < 4; i++) stroke(P([[x - 9 + i * 6, y + 2], [x - 12 + i * 7.5, y - 18 + Math.abs(i - 1.5) * 3]], false), '#2e2626', 6);
        stroke(P([[x - sgn * 12, y + 10], [x - sgn * 22, y]], false), '#2e2626', 6);
        stroke(P([[x - 4, y - 4], [x - 6, y - 14]], false), 'rgba(220,210,210,0.6)', 1.5);
      };
      hand(66, 100, 1); hand(210, 96, -1);
      // head: curly grey hair, dark face, beard
      const hr = rng(24);
      for (let i = 0; i < 60; i++) { const a = hr() * Math.PI * 2, rr = 22 + hr() * 20; fill(circleP(140 + Math.cos(a) * rr * 1.1, 70 + Math.sin(a) * rr * 0.9 - 6, 5 + hr() * 5), hr() < 0.5 ? '#1c1a1c' : '#8a8888'); }
      fill(ellipseP(140, 82, 24, 30, 0), '#3a2c2a');
      fill(ellipseP(140, 112, 22, 18, 0), '#221c1c');
      for (let i = 0; i < 8; i++) stroke(P([[128 + i * 3, 100], [126 + i * 3.4, 124]], false), 'rgba(160,150,150,0.5)', 1.2);
      fill(ellipseP(130, 78, 5, 3, 0), '#e8e0dc'); fill(ellipseP(152, 78, 5, 3, 0), '#e8e0dc');
      fill(ellipseP(140, 104, 7, 4, 0), '#5a2020');
    });

    // (1,0) chrome robot on a red plinth
    clipped(cell(1, 0), () => {
      fill(cell(1, 0), lin(256, 0, 512, 256, [[0, '#fbece6'], [0.5, '#eedbd4'], [1, '#f0d8d2']]));
      blurred(20, () => fill(P([[240, 120], [330, 190], [340, 270], [240, 270]]), '#8fb0e0'));
      blurred(18, () => fill(rrect(310, 180, 142, 76, 4), '#ff2848'));
      fill(rrect(318, 196, 126, 56, 3), '#e81948');
      fill(rrect(330, 176, 102, 32, 4), zeb); stroke(rrect(330, 176, 102, 32, 4), '#101018', 3);
      fill(rrect(342, 214, 80, 36, 2), '#1a0a10');
      const neck = rrect(360, 118, 50, 66, 14);
      glow(neck, 'rgba(255,60,80,0.7)', 12, 6);
      fill(neck, zeb); stroke(neck, '#101018', 2);
      const head = rrect(338, 16, 98, 96, 40);
      glow(head, 'rgba(255,50,70,0.8)', 16, 8);
      fill(head, lin(338, 16, 436, 112, [[0, '#0e1018'], [0.3, '#c8d8f0'], [0.45, '#10141c'], [0.7, '#f4f8ff'], [1, '#1a1c28']]));
      stroke(head, '#0a0a12', 3);
      fill(rrect(352, 40, 70, 42, 16), '#f4f6fa'); stroke(rrect(352, 40, 70, 42, 16), '#0a0a12', 3);
      fill(circleP(376, 60, 5), '#0a0a12'); fill(circleP(402, 60, 5), '#0a0a12');
      const jaw = rrect(344, 88, 88, 32, 12);
      fill(jaw, '#12080a'); stroke(jaw, '#ff5060', 2);
      const teeth = []; for (let i = 0; i <= 12; i++) teeth.push([350 + i * 6.5, i % 2 ? 106 : 94]);
      stroke(P(teeth, false, false), '#f4ece6', 3);
    });

    // (2,0) horned beast crouching, black gloss body, striped mane
    clipped(cell(2, 0), () => {
      fill(cell(2, 0), lin(512, 0, 512, 256, [[0, '#f27fc0'], [0.6, '#f79ccb'], [0.85, '#eac8e4'], [1, '#e8e4f4']]));
      blurred(8, () => fill(ellipseP(640, 245, 125, 12, 0), 'rgba(120,120,200,0.5)'));
      const body = P([[528, 244], [532, 204], [552, 172], [590, 152], [640, 146], [692, 152], [728, 172], [744, 206], [748, 244]]);
      glow(body, 'rgba(255,90,110,0.9)', 10, 5);
      fill(body, lin(528, 150, 748, 244, [[0, '#101018'], [0.35, '#1a1a26'], [0.6, '#0a0a10'], [1, '#161622']]));
      clipped(body, () => {
        stroke(P([[545, 230], [548, 200], [566, 176], [596, 162]], false), 'rgba(235,240,255,0.85)', 5);
        stroke(P([[735, 230], [732, 200], [716, 176], [690, 164]], false), 'rgba(235,240,255,0.85)', 5);
        blurred(4, () => { stroke(P([[560, 236], [600, 220], [640, 226]], false), 'rgba(255,80,90,0.8)', 6); stroke(P([[640, 226], [680, 220], [720, 236]], false), 'rgba(255,80,90,0.8)', 6); });
      });
      const mane = P([[598, 108], [682, 108], [690, 150], [676, 196], [654, 222], [640, 226], [626, 222], [604, 196], [590, 150]]);
      fill(mane, zeb); stroke(mane, '#1a0a10', 3);
      clipped(mane, () => { o.save(); o.globalCompositeOperation = 'multiply'; fill(mane, 'rgba(255,120,120,0.55)'); o.restore(); });
      fill(P([[634, 120], [646, 120], [644, 210], [636, 210]]), '#f8f4f4');
      // head, ears, crown spike
      fill(P([[598, 46], [572, 24], [582, 60], [604, 70]]), '#2a1a1a'); fill(P([[682, 46], [708, 24], [698, 60], [676, 70]]), '#2a1a1a');
      fill(P([[634, 30], [640, 8], [646, 30]]), '#3a2020');
      const head = ellipseP(640, 72, 38, 44, 0);
      glow(head, 'rgba(255,120,130,0.8)', 8, 4);
      fill(head, lin(600, 30, 680, 110, [[0, '#3a2626'], [0.5, '#1a1212'], [1, '#402a28']]));
      fill(ellipseP(640, 100, 20, 14, 0), '#241818'); fill(ellipseP(640, 96, 12, 6, 0), '#0a0606');
      for (const x of [622, 658]) { fill(circleP(x, 70, 8), '#f2eaea'); fill(circleP(x, 70, 4), '#140a0a'); stroke(circleP(x, 70, 9), '#ff6070', 1.5); }
    });

    // (3,0) zebra face with an "OQO" capsule
    clipped(cell(3, 0), () => {
      fill(cell(3, 0), zeb);
      fill(P([[772, 22], [834, 36], [790, 92]]), '#f24a48'); fill(P([[1024, 40], [1000, 70], [1024, 120]]), '#f24a48');
      blurred(6, () => { stroke(P([[768, 250], [1024, 250]], false), 'rgba(255,60,60,0.8)', 10); stroke(P([[790, 30], [860, 10]], false), 'rgba(255,80,80,0.6)', 12); });
      stroke(P([[768, 12], [850, 20], [930, 12], [1024, 4]], false), '#4a5a6c', 12);
      const band = rrect(794, 108, 198, 70, 34);
      glow(band, 'rgba(240,250,255,0.95)', 14, 6);
      fill(band, lin(794, 108, 794, 178, [[0, '#cfe0f4'], [0.4, '#f8fbff'], [1, '#b0c8e8']])); stroke(band, '#101018', 3);
      o.fillStyle = '#0a0a10'; o.font = 'bold 56px Georgia, serif'; o.textAlign = 'center'; o.textBaseline = 'middle'; o.fillText('0Q0', 893, 146);
      stroke(P([[790, 190], [840, 208], [893, 214], [948, 208], [998, 190]], false), '#0e1018', 10);
      stroke(P([[790, 190], [840, 208], [893, 214], [948, 208], [998, 190]], false), 'rgba(200,220,255,0.8)', 3);
      fill(P([[800, 236], [893, 226], [990, 236], [1000, 256], [790, 256]]), zeb);
    });

    // ═════════ row 1 ═════════
    // (0,1) beige chrome hooded mask on sky blue with red flags
    clipped(cell(0, 1), () => {
      fill(cell(0, 1), lin(0, 256, 256, 512, [[0, '#40bcfc'], [0.6, '#4ab4f0'], [1, '#8ab8e8']]));
      fill(P([[4, 284], [62, 272], [40, 300], [30, 332]]), '#f8363c');
      fill(P([[0, 330], [26, 322], [50, 360], [36, 420], [0, 440]]), '#f83c44');
      fill(P([[200, 290], [240, 270], [230, 330]]), '#f04448');
      stroke(P([[0, 268], [60, 276], [120, 266], [180, 274], [256, 262]], false), '#3a1a20', 5);
      stroke(P([[242, 262], [240, 340], [236, 430]], false), '#3a1a20', 4);
      const hood = P([[30, 512], [36, 470], [56, 440], [66, 380], [74, 326], [100, 298], [132, 290], [168, 298], [192, 326], [200, 380], [206, 430], [232, 456], [256, 470], [256, 512]]);
      glow(hood, 'rgba(255,255,240,0.9)', 12, 6);
      fill(hood, lin(30, 300, 256, 512, [[0, '#e8d8b0'], [0.3, '#a88c60'], [0.55, '#d8c8a0'], [0.8, '#8a6c44'], [1, '#c8b088']]));
      stroke(hood, '#2a2014', 3);
      clipped(hood, () => {
        const z = P([[20, 470], [256, 460], [256, 520], [20, 520]]);
        o.save(); o.globalAlpha = 0.75; fill(z, zeb); o.restore();
        o.save(); o.globalCompositeOperation = 'multiply'; fill(z, 'rgba(220,190,140,0.9)'); o.restore();
      });
      const face = P([[92, 322], [132, 314], [170, 322], [182, 360], [178, 400], [162, 432], [132, 440], [102, 432], [86, 400], [82, 360]]);
      fill(P([[96, 420], [168, 420], [160, 450], [104, 450]]), '#2e86e6');
      fill(face, lin(90, 320, 180, 440, [[0, '#fbf8f0'], [0.6, '#ece4d4'], [1, '#c8b898']])); stroke(face, '#2a2014', 3);
      for (const x of [110, 156]) { fill(ellipseP(x, 358, 16, 13, 0), '#16100c'); fill(circleP(x, 358, 6), '#f8f4ec'); fill(circleP(x, 358, 3), '#0a0808'); }
      stroke(P([[132, 364], [128, 392], [138, 396]], false), '#3a2a1a', 3);
      stroke(P([[112, 414], [132, 406], [152, 414]], false), '#2a1a10', 4);
    });

    // (1,1) red/white molten landscape with zebra blobs, blue at the bottom left
    clipped(cell(1, 1), () => {
      fill(cell(1, 1), lin(256, 256, 512, 512, [[0, '#f04c50'], [0.5, '#f26468'], [1, '#e0303a']]));
      const mr = rng(51);
      blurred(6, () => { for (let i = 0; i < 12; i++) fill(ellipseP(256 + mr() * 256, 256 + mr() * 256, 16 + mr() * 24, 6 + mr() * 10, mr() * 3), mr() < 0.5 ? 'rgba(255,225,225,0.7)' : 'rgba(250,120,130,0.8)'); });
      blurred(3, () => fill(P([[256, 420], [290, 400], [330, 440], [340, 512], [256, 512]]), '#1c72d4'));
      const blobs = [
        [[300, 330], [350, 300], [410, 296], [450, 320], [430, 360], [380, 370], [330, 372]],
        [[380, 380], [440, 360], [490, 380], [500, 430], [460, 470], [400, 470], [370, 430]],
        [[300, 420], [350, 400], [380, 440], [370, 500], [320, 505], [296, 470]],
        [[430, 270], [490, 258], [512, 262], [512, 340], [470, 350], [440, 320]]];
      for (const b of blobs) { const pth = P(b); glow(pth, 'rgba(255,255,255,0.9)', 10, 4); fill(pth, zeb); o.save(); o.globalCompositeOperation = 'multiply'; fill(pth, 'rgba(250,150,160,0.8)'); o.restore(); stroke(pth, '#1a0a0e', 2); }
      clipped(P(blobs[3]), () => { const tr = rng(3); for (let i = 0; i < 40; i++) fill(circleP(430 + tr() * 90, 262 + tr() * 90, 3 + tr() * 5), tr() < 0.5 ? '#2a2a2e' : '#9a9aa0'); });
    });

    // (2,1) ice-blue zebra maze blobs
    clipped(cell(2, 1), () => {
      fill(cell(2, 1), lin(512, 256, 768, 512, [[0, '#9cc4f4'], [0.5, '#b8d6f4'], [1, '#88b4ee']]));
      const br = rng(61);
      for (let i = 0; i < 24; i++) {
        const x = 512 + br() * 256, y = 256 + br() * 256, w = 60 + br() * 80, h = 34 + br() * 44;
        const pth = rrect(x - w / 2, y - h / 2, w, h, Math.min(w, h) * 0.45);
        glow(pth, 'rgba(255,255,255,0.95)', 10, 3);
        fill(pth, zeb); stroke(pth, '#101820', 2);
      }
      blurred(6, () => fill(P([[512, 496], [600, 486], [700, 500], [768, 490], [768, 520], [512, 520]]), '#f04040'));
      for (const [x, y] of [[735, 345], [640, 372], [524, 470]]) fill(circleP(x, y, 6), '#0a0a10');
    });

    // (3,1) black three-armed imp with a big eye, red hair rays
    clipped(cell(3, 1), () => {
      fill(cell(3, 1), rad(880, 390, 200, [[0, '#f4f6fc'], [0.5, '#c8d4ec'], [1, '#a8b8e0']]));
      const rr = rng(71);
      for (let i = 0; i < 160; i++) {
        const a = rr() * Math.PI * 2, r0 = 70 + rr() * 60, r1 = r0 + 20 + rr() * 60;
        stroke(P([[880 + Math.cos(a) * r0, 390 + Math.sin(a) * r0], [880 + Math.cos(a) * r1, 390 + Math.sin(a) * r1]], false), rr() < 0.7 ? 'rgba(232,50,56,0.8)' : 'rgba(40,20,30,0.6)', 1 + rr() * 2);
      }
      blurred(10, () => fill(P([[768, 256], [860, 256], [800, 330], [768, 360]]), 'rgba(230,60,70,0.6)'));
      const arms = [[[870, 380], [884, 330], [892, 300]], [[870, 380], [930, 372], [985, 368]], [[880, 395], [930, 410], [985, 412]], [[860, 390], [830, 405], [805, 425]]];
      for (const a of arms) glow(P(a, false), 'rgba(255,255,255,0.95)', 34, 4);
      for (const a of arms) { stroke(P(a, false), '#0a0a10', 26); stroke(P(a, false), 'rgba(200,215,240,0.9)', 3); }
      fill(ellipseP(868, 375, 34, 30, 0), '#0a0a10');
      fill(circleP(866, 356, 17), '#f8f8fc'); fill(circleP(870, 354, 7), '#0a0a10');
      glow(circleP(870, 455, 40), 'rgba(255,255,255,0.9)', 12, 4);
      fill(circleP(870, 455, 40), '#0c0c12'); fill(circleP(870, 455, 32), '#f4f4ee'); fill(circleP(870, 455, 20), '#e8dca0'); fill(circleP(870, 455, 9), '#101010');
      stroke(circleP(870, 455, 26), 'rgba(160,200,120,0.6)', 3);
    });

    // ═════════ row 2 ═════════
    // (0,2) swirling zebra blob with red and blue edges
    clipped(cell(0, 2), () => {
      fill(cell(0, 2), zeb);
      fill(P([[0, 540], [40, 530], [56, 580], [46, 640], [30, 690], [0, 700]]), '#f01a30');
      fill(P([[0, 690], [40, 700], [70, 740], [60, 768], [0, 768]]), '#34a0f8');
      fill(P([[220, 700], [256, 690], [256, 768], [230, 768]]), '#3a9cf0');
      fill(P([[60, 512], [180, 512], [230, 530], [240, 560], [200, 556], [150, 548], [100, 560], [70, 548]]), '#060810');
      fill(P([[70, 740], [120, 730], [170, 745], [200, 768], [60, 768]]), '#060810');
      fill(circleP(160, 745, 10), '#060810'); fill(circleP(240, 520, 12), '#060810');
      fill(ellipseP(186, 676, 26, 16, 0), '#f4f6fa'); stroke(ellipseP(186, 676, 26, 16, 0), '#0a0a10', 5); fill(circleP(186, 676, 6), '#0a0a10');
      glow(P([[40, 620], [80, 600], [120, 640]], false), 'rgba(80,160,255,0.7)', 10, 5);
    });

    // (1,2) circle emblem with an "M", red/black swirl frame
    clipped(cell(1, 2), () => {
      fill(cell(1, 2), '#f6f4f2');
      const fr = rng(91);
      for (let i = 0; i < 36; i++) {
        const side = i % 4, t = fr();
        const x = side === 0 ? 256 + t * 256 : side === 1 ? 500 + fr() * 12 : side === 2 ? 256 + t * 256 : 256 + fr() * 12;
        const y = side === 0 ? 516 + fr() * 12 : side === 1 ? 512 + t * 256 : side === 2 ? 756 + fr() * 10 : 512 + t * 256;
        const a = fr() * 6.28, L = 14 + fr() * 26;
        stroke(P([[x, y], [x + Math.cos(a) * L, y + Math.sin(a) * L], [x + Math.cos(a + 1) * L * 1.4, y + Math.sin(a + 1) * L * 1.4]], false), fr() < 0.5 ? '#e8242c' : '#101014', 3 + fr() * 4);
      }
      fill(P([[256, 700], [290, 740], [300, 768], [256, 768]]), '#3a8ce8'); fill(P([[470, 512], [512, 512], [512, 560]]), '#3a8ce8');
      const disc = circleP(384, 640, 112);
      glow(disc, 'rgba(40,40,60,0.8)', 10, 6);
      fill(disc, zeb);
      fill(disc, 'rgba(230,232,240,0.35)');
      stroke(disc, '#0c0c10', 8); stroke(circleP(384, 640, 104), 'rgba(255,255,255,0.9)', 3);
      fill(P([[328, 646], [330, 590], [384, 626], [438, 590], [440, 646], [420, 646], [420, 620], [384, 648], [348, 620], [348, 646]], true, false), '#0c0c10');
    });

    // (2,2) black graffiti squiggles on red around a chrome capsule
    clipped(cell(2, 2), () => {
      fill(cell(2, 2), lin(512, 512, 768, 768, [[0, '#ff4a5c'], [0.5, '#f04454'], [1, '#e83a4a']]));
      const sr = rng(22);
      for (let i = 0; i < 150; i++) {
        let x = 512 + sr() * 256, y = 512 + sr() * 256, ang = sr() * 6.28; const pts = [[x, y]];
        for (let k = 0; k < 5; k++) { ang += (sr() - 0.5) * 2.6; x += Math.cos(ang) * 11; y += Math.sin(ang) * 11; pts.push([x, y]); }
        const pth = P(pts, false); stroke(pth, 'rgba(255,230,230,0.7)', 12); stroke(pth, '#0a0608', 8);
      }
      for (let i = 0; i < 20; i++) fill(circleP(512 + sr() * 256, 512 + sr() * 256, 2 + sr() * 3), '#fff0f0');
      const cap = rrect(556, 600, 184, 88, 40);
      glow(cap, 'rgba(255,255,255,0.95)', 16, 6);
      fill(cap, zeb); stroke(cap, '#0a0a10', 3);
      fill(rrect(566, 674, 164, 12, 6), '#5fb1f7');
      o.fillStyle = '#0a0a10'; o.font = 'bold 34px Arial Black, Arial, sans-serif'; o.textAlign = 'center'; o.textBaseline = 'middle'; o.fillText('ƏCꟻɅ', 648, 646);
    });

    // (3,2) black three-armed imp over a pale yellow grille disc
    clipped(cell(3, 2), () => {
      fill(cell(3, 2), lin(768, 512, 1024, 640, [[0, '#ea98c6'], [0.35, '#e8def4'], [0.7, '#eceafc'], [1, '#6a9ce8']]));
      blurred(16, () => fill(P([[990, 512], [1024, 512], [1024, 768], [980, 768]]), '#5a90e8'));
      const arms = [[[872, 600], [884, 560], [896, 540]], [[872, 600], [930, 612], [990, 640]], [[860, 610], [830, 628], [814, 640]]];
      for (const a of arms) glow(P(a, false), 'rgba(255,80,70,0.9)', 34, 3);
      for (const a of arms) stroke(P(a, false), '#0a0a10', 26);
      fill(ellipseP(868, 600, 34, 30, 0), '#0a0a10');
      blurred(2, () => stroke(P([[890, 540], [900, 528], [912, 532]], false), '#d83030', 8));
      fill(circleP(866, 598, 18), '#f8f8fc'); fill(circleP(870, 598, 7), '#0a0a10');
      glow(circleP(870, 712, 44), 'rgba(90,150,240,0.9)', 16, 8);
      fill(circleP(870, 712, 42), '#f4f0c4');
      clipped(circleP(870, 712, 38), () => { for (let y = 680; y < 750; y += 10) for (let x = 834; x < 910; x += 12) fill(rrect(x, y, 8, 6, 2), '#2a2a24'); });
    });

    // ═════════ row 3 ═════════
    // (0,3) black chrome strongman
    clipped(cell(0, 3), () => {
      fill(cell(0, 3), lin(0, 0, 256, 0, [[0, '#f27a84'], [0.4, '#f6c4c4'], [0.6, '#fbeef0'], [0.85, '#8ab0e4'], [1, '#2a84d8']]));
      blurred(24, () => fill(ellipseP(118, 920, 70, 100, 0), 'rgba(220,40,50,0.7)'));
      const man = new Path2D();
      man.addPath(circleP(117, 815, 18));
      const limb = (pts, wd) => { const p = P(pts, false); glow(p, 'rgba(255,255,255,0.8)', wd + 8, 3); return p; };
      const limbs = [[[98, 850], [66, 848], [54, 826], [66, 806]], [[136, 850], [168, 848], [182, 826], [170, 806]],
        [[108, 930], [80, 950], [70, 980], [60, 1006]], [[128, 930], [156, 950], [168, 980], [180, 1006]]];
      const lp = limbs.map(l => limb(l, 24));
      const torso = P([[86, 838], [148, 838], [152, 870], [142, 936], [92, 936], [82, 870]]);
      glow(torso, 'rgba(255,255,255,0.8)', 8, 3);
      for (const p of lp) stroke(p, '#0a0a10', 24);
      fill(torso, '#0a0a10'); fill(circleP(117, 815, 18), '#0a0a10'); stroke(P([[117, 828], [117, 842]], false), '#0a0a10', 12);
      for (const p of lp) { stroke(p, 'rgba(160,180,210,0.7)', 3); o.save(); o.translate(-4, -3); stroke(p, 'rgba(220,230,250,0.35)', 5); o.restore(); }
      stroke(P([[104, 860], [117, 872], [130, 860]], false), 'rgba(170,190,220,0.8)', 2); stroke(P([[117, 876], [117, 920]], false), 'rgba(170,190,220,0.6)', 2);
      fill(ellipseP(111, 812, 3, 2, 0), '#e0e0e8'); fill(ellipseP(123, 812, 3, 2, 0), '#e0e0e8');
    });

    // (1,3) striped cream creature with two eyes on red, blue edge
    clipped(cell(1, 3), () => {
      fill(cell(1, 3), '#f23f59');
      blurred(10, () => fill(P([[470, 768], [512, 768], [512, 1024], [470, 1024]]), '#1686e6'));
      blurred(8, () => fill(P([[455, 768], [480, 768], [480, 1024], [455, 1024]]), 'rgba(255,255,255,0.8)'));
      const body = P([[296, 830], [330, 792], [380, 776], [440, 780], [472, 810], [472, 860], [484, 900], [470, 1030], [330, 1030], [300, 960], [290, 900]]);
      glow(body, 'rgba(255,255,255,0.95)', 14, 5);
      fill(body, zeb);
      o.save(); o.globalCompositeOperation = 'multiply'; clipped(body, () => fill(body, lin(290, 780, 480, 1024, [[0, '#f0d8c8'], [0.5, '#e8b0a0'], [1, '#f4e8e0']]))); o.restore();
      fill(body, 'rgba(250,240,232,0.3)');
      clipped(body, () => fill(P([[340, 800], [400, 790], [410, 850], [380, 900], [350, 880]]), 'rgba(120,40,30,0.55)'));
      stroke(body, '#1a0a0a', 2);
      for (const [x, y, r] of [[436, 815, 26], [400, 946, 22]]) { fill(circleP(x, y, r + 5), '#f4f4f4'); fill(circleP(x, y, r), '#0e0e12'); fill(ellipseP(x - r * 0.3, y - r * 0.3, r * 0.3, r * 0.2, -0.6), 'rgba(255,255,255,0.8)'); }
      const fist = P([[290, 830], [320, 812], [336, 830], [330, 860], [300, 868], [282, 852]]);
      fill(fist, zeb); stroke(fist, '#1a0a0a', 2);
    });

    // (2,3) horned shaggy monster with bug eyes
    clipped(cell(2, 3), () => {
      fill(cell(2, 3), lin(512, 768, 768, 1024, [[0, '#ff5078'], [0.6, '#fb4a68'], [1, '#f04a5a']]));
      const horns = P([[548, 772], [556, 790], [580, 800], [640, 796], [700, 800], [724, 790], [732, 772], [720, 792], [700, 786], [640, 782], [580, 786], [560, 792]]);
      stroke(horns, '#0a0808', 12);
      stroke(P([[548, 772], [542, 780]], false), '#0a0808', 8); stroke(P([[732, 772], [738, 780]], false), '#0a0808', 8);
      const body = P([[560, 800], [720, 800], [736, 850], [744, 920], [724, 984], [680, 1004], [600, 1004], [566, 960], [552, 900]]);
      glow(body, 'rgba(255,220,200,0.9)', 12, 5);
      fill(body, zeb);
      o.save(); o.globalCompositeOperation = 'multiply'; clipped(body, () => fill(body, 'rgba(250,236,220,0.9)')); o.restore();
      const fr = rng(14);
      for (let i = 0; i < 60; i++) { const a = fr() * 6.28, x = 648 + Math.cos(a) * 92, y = 900 + Math.sin(a) * 100; stroke(P([[x, y], [x + Math.cos(a) * 12, y + Math.sin(a) * 12]], false), '#f4e8d8', 2); }
      stroke(body, '#2a1a10', 1.5);
      for (const x of [622, 656]) { fill(circleP(x, 852, 15), '#0c0c0a'); fill(circleP(x, 852, 10), '#d8e070'); fill(circleP(x, 852, 4), '#0c0c0a'); }
      fill(ellipseP(636, 872, 34, 16, 0), 'rgba(160,80,60,0.6)');
      fill(ellipseP(636, 906, 20, 7, 0), '#1a0c08');
      stroke(P([[586, 930], [560, 970], [540, 1030]], false), '#a8d0f4', 22); stroke(P([[586, 930], [560, 970], [540, 1030]], false), 'rgba(40,80,140,0.5)', 2);
      stroke(P([[726, 900], [742, 960], [746, 1030]], false), '#0a0a10', 22);
      clipped(P([[716, 900], [760, 900], [760, 1030], [716, 1030]]), () => { for (let y = 900; y < 1030; y += 9) stroke(P([[720, y], [760, y + 4]], false), 'rgba(240,240,250,0.9)', 3); });
    });

    // (3,3) blue zebra face with a fanged mouth, red and white rays
    clipped(cell(3, 3), () => {
      fill(cell(3, 3), lin(768, 0, 1024, 0, [[0, '#d8363e'], [0.25, '#e87880'], [0.5, '#f0e8ec'], [1, '#e8eef8']]));
      const rr = rng(33);
      for (let i = 0; i < 120; i++) { const a = rr() * 6.28, r0 = 110 + rr() * 30; stroke(P([[896 + Math.cos(a) * r0, 900 + Math.sin(a) * r0], [896 + Math.cos(a) * (r0 + 60), 900 + Math.sin(a) * (r0 + 60)]], false), rr() < 0.5 ? 'rgba(255,255,255,0.8)' : 'rgba(70,110,200,0.5)', 1.5); }
      const face = P([[800, 832], [840, 790], [900, 774], [970, 788], [1012, 840], [1018, 920], [996, 990], [930, 1016], [850, 1002], [812, 962], [796, 900]]);
      glow(face, 'rgba(255,255,255,0.95)', 14, 5);
      fill(face, zeb);
      o.save(); o.globalCompositeOperation = 'multiply'; clipped(face, () => fill(face, lin(800, 780, 1010, 1010, [[0, '#9ec0f0'], [0.5, '#c8dcf8'], [1, '#88b0e8']]))); o.restore();
      stroke(face, '#101828', 2);
      fill(circleP(885, 822, 32), '#f2f4f8'); fill(circleP(885, 822, 26), '#20242c'); fill(circleP(885, 822, 16), '#6a7488'); fill(circleP(880, 816, 5), '#f8f8f8');
      const mouth = ellipseP(955, 918, 52, 34, -0.1);
      fill(mouth, '#1a0c0c');
      clipped(mouth, () => { fill(ellipseP(955, 940, 44, 16, -0.1), '#c89a70'); for (let i = 0; i < 12; i++) fill(P([[912 + i * 8, 890], [916 + i * 8, 906], [920 + i * 8, 890]]), '#f4f0e8'); });
      stroke(mouth, '#e8e8f0', 3);
      fill(P([[768, 900], [800, 894], [812, 920], [790, 940], [768, 936]]), '#e03040');
    });

    // thin seams between the cells
    for (let i = 1; i < 4; i++) { stroke(P([[i * C, 0], [i * C, W]], false), 'rgba(255,255,255,0.35)', 1); stroke(P([[0, i * C], [W, i * C]], false), 'rgba(255,255,255,0.35)', 1); }
    E.bloom(0.1, 8);
    E.grain(0.03, 24);
  }
});
