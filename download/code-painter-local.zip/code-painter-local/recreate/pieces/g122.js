'use strict';
// g122 — "Orange face collage": a paper-cut collage — an orange sun with a doodled eye, a tilted grey can,
// a zebra panel in an olive frame with a yellow-black feather, a grey leaf over a neon maze, blue steps and cream beads.
REC.register('g122', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H], al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const poly = pts => P(pts, true, false);
    const strokeA = (path, c, wd) => { a.save(); a.lineWidth = wd; a.strokeStyle = c; a.lineJoin = 'miter'; a.stroke(path); a.restore(); };
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    // local transform helper: maps local (u, v) into piece space
    const T = (cx, cy, rot) => pts => pts.map(([u, v]) => [cx + u * Math.cos(rot) - v * Math.sin(rot), cy + u * Math.sin(rot) + v * Math.cos(rot)]);

    // ── base: white paper, cyan sky top-left ──
    R.flat(all, '#fdfdfd', 0, 0);
    R.flat(rrect(-10, -10, 380, 260, 0), lin(0, 0, 0, 200, [[0, '#5cfbfa'], [0.35, '#88f0f0'], [0.7, '#e0f8f8'], [1, '#ffffff']]), 0, 0);
    // grey grid board (top-right)
    const grid = poly([[365, -10], [736, -10], [736, 300], [365, 300]]);
    const gridT = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + vec2(3. * sin(p.y * 0.05), 2. * sin(p.x * 0.04));
      float gx = abs(fract(q.x / 22.) - .5), gy = abs(fract(q.y / 22.) - .5);
      float l = smoothstep(0.43, 0.48, max(gx, gy));
      float gx2 = abs(fract(q.x / 7.3) - .5), gy2 = abs(fract(q.y / 7.3) - .5);
      float l2 = smoothstep(0.42, 0.49, max(gx2, gy2)) * 0.5;
      vec3 c = vec3(.56,.53,.54) * (0.9 + 0.2 * fbm(p * 0.05));
      c = mix(c, vec3(.75,.73,.74), l2);
      c = mix(c, vec3(.25,.23,.24), l * 0.8);
      float sp = smoothstep(0.55, 0.6, fbm(p * 0.045 + 3.)) * smoothstep(0.45, 0.52, vnoise(p * 0.3));
      return mix(c, vec3(.03), sp); }`);
    R.flat(grid, '#8a8488', 0.01, 0);
    clipA(grid, () => img(gridT));
    // green blob (top-left)
    R.dome(P([[-10, -10], [70, -10], [86, 20], [80, 60], [86, 84], [60, 102], [30, 96], [10, 120], [-10, 118]]), lin(0, 0, 80, 100, [[0, '#8cff30'], [1, '#52e000']]), 0.06, 0.2, 30, 6);
    // black starry strip
    const night = poly([[137, -10], [264, -10], [258, 262], [148, 266]]);
    R.flat(night, '#0a0a0a', 0.02, 0);
    { const r = rng(5); for (let i = 0; i < 26; i++) { const x = 140 + r() * 118, y = r() * 260; R.flat(circleP(x, y, 1.5 + r() * r() * 7), '#f8f8f8', 0.03, 0); } }
    R.flat(circleP(165, 42, 16), '#1840e0', 0.03, 0);
    R.flat(circleP(171, 48, 10), '#ffffff', 0.035, 0);
    R.flat(circleP(213, 128, 7), '#ffffff', 0.035, 0); R.flat(circleP(157, 215, 7), '#ffffff', 0.035, 0);

    // ── white paper + orange card (right) ──
    R.flat(poly([[515, 276], [736, 276], [736, 345], [520, 345]]), '#ffffff', 0.05, 2);
    R.flat(poly([[565, 336], [736, 336], [736, 650], [562, 646]]), '#fd6004', 0.08, 2);
    speck(poly([[565, 336], [736, 336], [736, 650], [562, 646]]), 60, 7, '#ffd0a0', 1.2);
    R.dome(circleP(617, 357, 6), '#787878', 0.1, 0.03, 3, 1);
    R.dome(circleP(660, 286, 27), '#ffffff', 0.08, 0.06, 8, 1);
    a.save(); a.fillStyle = '#111'; a.font = 'bold 34px sans-serif'; a.fillText('B', 710, 452); a.restore();

    // ── white hand ──
    const hand = P([[502, 168], [506, 150], [530, 124], [556, 100], [578, 70], [604, 42], [636, 22], [672, 8], [700, -6], [736, -6], [736, 70], [712, 86], [690, 104], [660, 116], [640, 126], [618, 132], [600, 150], [584, 160], [582, 132], [560, 140], [540, 156], [520, 168]]);
    R.flat(hand, '#f2f2f2', 0.06, 1);
    speck(hand, 500, 9, '#1a1a1a', 1.0, [500, 0, 736, 170]);
    R.flat(poly([[664, -10], [736, -10], [736, 60], [706, 66]]), '#1a1a1a', 0.07, 1);
    R.flat(poly([[686, -10], [698, -10], [736, 30], [736, 40]]), '#f0f0f0', 0.075, 1);
    R.flat(poly([[700, -10], [712, -10], [728, 44], [720, 48]]), '#f0f0f0', 0.075, 1);

    // ── orange sun with the doodled face ──
    const sun = circleP(387, 183, 165);
    R.flat(sun, '#fa6408', 0.06, 2);
    speck(sun, 700, 11, '#ff9a40', 2.2, [220, 18, 552, 348], 0.15);
    clipA(sun, () => {
      // striped dome (eyebrow arcs)
      a.save(); const arc = new Path2D(); arc.ellipse(348, 126, 56, 64, 0, Math.PI, 2 * Math.PI); a.clip(arc);
      a.fillStyle = '#111'; for (let i = 0; i < 6; i++) a.fill(poly([[290 + i * 20, 130], [300 + i * 20, 60], [311 + i * 20, 60], [301 + i * 20, 130]]));
      a.restore();
      a.lineCap = 'round'; a.strokeStyle = '#1d4fd0'; a.lineWidth = 6;
      a.stroke(P([[310, 155], [340, 140], [380, 146], [420, 140], [460, 132], [485, 128]], false));
      // eye
      const eye = P([[380, 170], [400, 152], [440, 148], [470, 172], [446, 196], [404, 198]]);
      a.fillStyle = '#111'; a.fill(eye);
      a.fillStyle = '#ffffff'; a.fill(P([[392, 174], [408, 162], [440, 160], [458, 174], [440, 188], [406, 190]]));
      a.fillStyle = '#30c8f0'; a.fill(circleP(418, 176, 15)); a.fillStyle = '#1d4fd0'; a.fill(ellipseP(388, 176, 8, 14, 0));
      a.fillStyle = '#f0b030'; for (let i = 0; i < 6; i++) a.fill(circleP(398 + i * 12, 155 - Math.sin(i / 5 * 3.14) * 3, 3.4));
      a.fillStyle = '#1d4fd0'; a.fill(circleP(348, 179, 12));
      a.lineWidth = 6; a.stroke(P([[418, 214], [408, 228], [418, 240], [428, 228], [430, 248], [412, 254]], false));
      a.stroke(P([[450, 216], [462, 222], [460, 236], [448, 240]], false));
      a.fillStyle = '#ff3aa8'; a.fill(circleP(426, 284, 12));
    });
    R.dome(circleP(448, 59, 16), '#ffffff', 0.1, 0.06, 6, 1);

    // ── grey-beige left board, yellow frame, blue steps ──
    R.flat(poly([[-10, 402], [210, 398], [210, 740], [-10, 740]]), '#bcb5ad', 0.02, 0);
    speck(poly([[-10, 402], [210, 398], [210, 740], [-10, 740]]), 120, 13, '#6a6460', 1.0);
    a.save(); a.lineWidth = 6; a.strokeStyle = '#f2ee10'; a.lineJoin = 'miter'; a.stroke(P([[-10, 302], [32, 306], [38, 448], [-10, 444]], false, false)); a.restore();
    R.pipe(P([[-10, 588], [30, 578], [42, 590], [70, 574], [86, 590], [96, 572], [118, 618], [140, 610], [150, 624], [182, 616]], false, false), 6, '#f4ee10', 0.06, 0.02, 1);
    R.flat(poly([[118, 528], [184, 528], [184, 552], [118, 552]]), '#18a8c8', 0.05, 1);
    R.flat(poly([[124, 533], [178, 533], [178, 547], [124, 547]]), '#e8f6f8', 0.055, 1);
    R.dome(circleP(58, 432, 8), '#40d8e8', 0.05, 0.02, 3, 1);
    const blue = poly([[-10, 738], [12, 730], [12, 716], [42, 712], [42, 694], [76, 690], [76, 676], [112, 672], [112, 658], [150, 656], [150, 644], [182, 640],
      [166, 812], [240, 870], [330, 1034], [-10, 1034]]);
    R.flat(poly([[180, 790], [736, 690], [736, 1034], [180, 1034]]), '#2c2a52', 0.02, 0);
    R.flat(blue, '#0a32ad', 0.03, 0);
    speck(blue, 70, 17, '#e8e8f0', 1.0, [0, 640, 330, 1024]);

    // ── olive frame + zebra panel ──
    const frameO = poly([[160, 812], [176, 500], [350, 330], [502, 252], [532, 282], [548, 500], [604, 640], [560, 704], [262, 818]]);
    R.dome(frameO, '#9a7c10', 0.08, 0.06, 6, 3);
    speck(frameO, 500, 19, '#3a2c04', 0.9);
    const zin = poly([[192, 790], [204, 524], [356, 362], [496, 292], [514, 310], [526, 508], [574, 640], [530, 690], [262, 792]]);
    R.flat(zin, '#ff6a10', 0.1, 0);
    const zin2 = poly([[196, 786], [208, 528], [358, 366], [494, 297], [510, 314], [522, 510], [568, 640], [528, 686], [262, 788]]);
    R.flat(zin2, '#ffffff', 0.1, 4);
    const zeb = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float x = p.x + 0.33 * (p.y - 550.) - 248. + 4. * sin(p.y * 0.012);
      float k = fract(x / 46.);
      float w = smoothstep(0.0, 0.03, k) * (1. - smoothstep(0.44, 0.47, k));
      return mix(vec3(.04), vec3(.99), w); }`);
    clipA(zin2, () => img(zeb));
    // floating blue tags + dots
    const tag = (cx, cy, w, h, rot) => {
      const pts = T(cx, cy, rot)([[-w / 2, -h / 2], [w / 2, -h / 2], [w / 2, h / 2], [-w / 2, h / 2]]);
      R.flat(poly(pts), '#1858d0', 0.14, 1);
      const ip = T(cx, cy, rot)([[-w / 2 + 5, -h / 2 + 5], [w / 2 - 5, -h / 2 + 5], [w / 2 - 5, h / 2 - 5], [-w / 2 + 5, h / 2 - 5]]);
      R.flat(poly(ip), '#ffffff', 0.15, 1);
    };
    tag(279, 597, 84, 24, 0.42); tag(267, 676, 68, 22, -0.18); tag(501, 612, 22, 52, -0.55); tag(338, 416, 52, 20, 0.45);
    for (const [x, y, r] of [[282, 572, 6], [256, 706, 5], [398, 610, 6], [207, 647, 7]]) R.dome(circleP(x, y, r), r > 6 ? '#40d8e8' : '#ffffff', 0.14, 0.03, 3, 1);

    // ── feather ──
    const fcl = [[560, 236], [534, 296], [512, 356], [492, 420], [476, 480], [462, 540], [450, 600], [440, 644]];
    const feather = P(lock(fcl, 96, 4, 0.6));
    R.dome(feather, '#b4b4b2', 0.14, 0.05, 12, 1);
    clipA(feather, () => {
      a.fillStyle = '#0c0c0c'; a.fill(poly([[470, 220], [620, 220], [620, 400], [540, 330], [512, 316], [480, 300]]));
      a.fillStyle = '#ffffff'; a.fill(P([[450, 330], [496, 304], [524, 326], [522, 380], [500, 430], [470, 470], [440, 500]]));
      a.strokeStyle = '#5a5a5a'; a.lineWidth = 1.5; a.stroke(P(fcl, false));
    });
    { const fyl = []; for (let i = 0; i <= 14; i++) { const t = i / 14; fyl.push([446 - t * 66 + (i % 2 ? -16 : 6), 300 + t * 206]); }
      R.flat(P([[476, 296], ...fyl, [410, 500], [430, 440], [450, 380], [466, 330]], true, false), '#f4ee08', 0.2, 1);
      R.flat(P([[476, 300], [500, 320], [496, 380], [470, 440], [440, 480], [426, 470], [450, 380], [466, 330]], true, true), '#ffffff', 0.2, 1); }

    // ── big grey leaf ──
    const leaf = P([[244, 850], [258, 788], [308, 734], [369, 695], [462, 665], [585, 642], [723, 624], [736, 626], [736, 700], [600, 734], [500, 760], [420, 776], [340, 800], [280, 824]]);
    R.dome(leaf, '#c4c3be', 0.16, 0.06, 18, 1);
    speck(leaf, 400, 23, '#5a5a58', 0.8, [230, 620, 736, 860]);
    a.save(); a.strokeStyle = '#3a3a3a'; a.lineWidth = 1.4;
    a.stroke(P([[240, 840], [300, 780], [380, 735], [480, 700], [600, 676], [726, 640]], false));
    a.stroke(P([[560, 668], [640, 650], [726, 634]], false)); a.restore();
    // dark shadow under the leaf on the orange card
    R.flat(poly([[680, 652], [736, 646], [736, 700], [700, 696]]), '#8a0c02', 0.09, 0);

    // ── maze in an olive frame ──
    R.flat(poly([[320, 1034], [330, 952], [736, 880], [736, 1034]]), '#5e4c3c', 0.04, 0);
    const mazeO = poly([[250, 806], [500, 762], [736, 700], [736, 896], [560, 962], [404, 1034], [330, 952]]);
    R.dome(mazeO, '#a08214', 0.12, 0.06, 6, 3);
    speck(mazeO, 600, 29, '#3a2c04', 0.9);
    const mazeI = poly([[284, 818], [500, 778], [736, 722], [736, 872], [560, 938], [414, 1000], [352, 944]]);
    R.flat(mazeI, '#0a0608', 0.14, 0);
    const maze = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.03,.02,.03);
      // pink zigzag polylines (parallel, running up-right)
      vec2 q = vec2(p.x * 0.92 + p.y * 0.4, p.y - p.x * 0.28);
      float z = q.y + 14. * abs(fract(q.x / 46.) - .5) * 2.;
      float pk = abs(fract(z / 30.) - .5) * 30.;
      c = mix(c, vec3(.92,.22,.72), 1. - smoothstep(1.6, 2.6, pk));
      // blue squiggles
      float n = vnoise(p * 0.035) + 0.5 * vnoise(p * 0.07 + 9.);
      float bl = abs(fract(n * 4.) - .5) * 2.;
      float m = (1. - smoothstep(0.06, 0.13, bl)) * step(pk, 9.0) * 0. + (1. - smoothstep(0.06, 0.13, bl)) * (1. - step(pk, 4.));
      c = mix(c, vec3(.12,.42,.92), m);
      return c; }`);
    clipA(mazeI, () => img(maze));

    // ── beige square frame ──
    { const f = T(435, 782, 0.12);
      const outer = poly(f([[-95, -100], [95, -100], [95, 100], [-95, 100]])), inner = poly(f([[-62, -66], [62, -66], [62, 66], [-62, 66]]));
      const ring = new Path2D(); ring.addPath(outer); ring.addPath(inner);
      a.save(); a.fillStyle = '#e8bc80'; a.fill(ring, 'evenodd'); a.restore();
      R.h.save(); R.h.clip(ring, 'evenodd'); R.dome(outer, null, 0.2, 0.08, 10, 3); R.h.restore();
      speck(outer, 300, 31, '#6a4a24', 0.9);
    }
    // beige wedge bottom-right
    R.dome(poly([[640, 1034], [700, 930], [736, 900], [736, 1034]]), '#e8b878', 0.14, 0.06, 8, 3);
    R.flat(poly([[404, 1034], [560, 962], [736, 896], [736, 912], [640, 1034]]), '#6a5858', 0.05, 0);

    // ── orange squiggles ──
    const sq = (pts, wd) => R.pipe(P(pts, false), wd, '#f45c10', 0.2, 0.08, 1);
    sq([[316, 1034], [304, 1006], [330, 990], [310, 966], [334, 950], [352, 960]], 14);
    sq([[598, 920], [620, 900], [640, 910], [664, 892], [690, 900]], 16);
    sq([[676, 832], [700, 820], [716, 846], [736, 838]], 14);

    // ── cream beads ──
    for (const [x, y, r] of [[2, 876, 24], [55, 893, 32], [133, 908, 32], [205, 1002, 32]]) {
      R.dome(circleP(x, y, r), '#f6e4c4', 0.12, 0.3, r, 5);
      speck(circleP(x, y, r), 40, x + 1, '#a07050', 0.9, [x - r, y - r, x + r, y + r]);
    }
    // black zigzag + blue ribs (bottom-left)
    const bz = poly([[-10, 920], [176, 942], [178, 1034], [-10, 1034]]);
    R.flat(bz, '#c8c2b4', 0.06, 0);
    const teeth = [[-10, 936]]; for (let i = 0; i <= 12; i++) teeth.push([i * 14, 944 + (i % 2 ? -14 : 6) + i * 1.2]);
    R.flat(poly([...teeth, [170, 960], [170, 1034], [-10, 1034]]), '#0a0a0a', 0.065, 0);
    const ribs = poly([[-10, 968], [160, 980], [160, 1034], [-10, 1034]]);
    clipA(ribs, () => { for (let x = -10; x < 170; x += 7) { a.fillStyle = '#1838d8'; a.fillRect(x, 968, 4, 70); } });

    // ── the tilted grey can ──
    { const f = T(200, 348, 0.62);
      const bodyPts = f([[-88, -96], [88, -96], [88, 118], [64, 134], [0, 140], [-64, 134], [-88, 118]]);
      const body = P(bodyPts, true, false);
      R.dome(body, lin(...f([[-88, 0]])[0], ...f([[88, 0]])[0], [[0, '#505357'], [0.3, '#7c8084'], [0.55, '#6c7074'], [1, '#3e4044']]), 0.16, 0.12, 50, 2);
      clipA(body, () => {
        a.fillStyle = '#fcfcfc'; a.fill(poly(f([[-70, -96], [0, -96], [0, 140], [-70, 140]])));
        a.fillStyle = '#f46010'; a.fill(poly(f([[-64, 4], [-36, 4], [-36, 92], [-64, 92]])));
        a.fillStyle = '#fcfcfc'; a.fill(poly(f([[6, -96], [26, -96], [26, 140], [6, 140]])));
        const r = rng(33); a.fillStyle = '#f8f8f8';
        for (let i = 0; i < 22; i++) { const u = r() < 0.3 ? -86 + r() * 14 : 26 + r() * 58; const [[x, y]] = f([[u, -90 + r() * 220]]); a.fill(circleP(x, y, 2 + r() * 4)); }
        a.fillStyle = '#111'; a.save(); a.translate(...f([[-60, -60]])[0]); a.rotate(0.62 + Math.PI / 2); a.font = 'bold 10px sans-serif';
        const txt = ['DAIR 6SI', 'WES EYTIOX', 'TS M UTERS', 'ORRECT', 'NOST', 'P USBU', '', '', 'VDC ORBOR'];
        for (let i = 0; i < txt.length; i++) a.fillText(txt[i], 0, 10 + i * 10.5);
        a.restore();
        a.strokeStyle = '#f8f8f8'; a.lineWidth = 2.5; a.lineCap = 'round';
        a.stroke(P(f([[40, 30], [62, 34], [84, 28]]), false));
        for (let i = 0; i < 4; i++) a.stroke(P(f([[46 + i * 9, 22], [50 + i * 9, 40]]), false));
        a.stroke(P(f([[50, 56], [60, 66], [72, 60]]), false));
      });
      // white lid (side band) and its grey top face
      const fl = T(...f([[0, -123]])[0], 0.74), lid = P(fl([[-98, 27], [-98, -27], [-64, -37], [0, -41], [64, -37], [98, -27], [98, 27], [64, 37], [0, 41], [-64, 37]]), true, true);
      R.dome(lid, lin(...f([[-104, 0]])[0], ...f([[104, 0]])[0], [[0, '#d8d8d8'], [0.4, '#ffffff'], [1, '#e0e0e0']]), 0.24, 0.12, 30, 1);
      R.dome(P(fl([[-90, -33], [-46, -47], [0, -51], [46, -47], [90, -33], [46, -23], [0, -19], [-46, -23]]), true, true), '#bdbdbd', 0.34, 0.03, 6, 1);
      R.pipe(P(fl([[-98, 23], [-56, 35], [0, 39], [56, 35], [98, 23]]), false), 6, '#ffffff', 0.3, 0.04, 1);
      // orange burst at the can's foot
      const burst = []; for (let i = 0; i <= 16; i++) { const t = i / 16; burst.push(f([[-80 + t * 160, 140 + (i % 2 ? 24 : 6)]])[0]); }
      R.flat(P([...burst, ...f([[80, 124], [-80, 124]])], true, false), '#f45c10', 0.15, 1);
    }
    R.dome(circleP(103, 262, 10), '#f45c10', 0.1, 0.05, 4, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.15, shin: 20, wrap: 0.6, ao: 0.3 }),                                     // 1 paper
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.4, ao: 0.4, coat: 0.05 }),                          // 2 can / painted
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.4, ao: 0.6, grain: 0.25 }),                         // 3 cork / frames
        E.mat({ dif: 1, spec: 0.05, shin: 10, wrap: 0.8, ao: 0.2 }),                                      // 4 zebra print
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.3, grain: 0.1 }),                           // 5 beads
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, coat: 0.25, rim: 0.3 })                          // 6 glossy green
      ],
      light: [-0.4, 0.55, 0.73], lc: [0.6, 0.6, 0.6], amb: [0.55, 0.55, 0.55],
      envTop: [1.1, 1.1, 1.1], envHor: [0.6, 0.6, 0.62], envBot: [0.2, 0.2, 0.22], envK: [0.2, 1.0, 0.3, 0],
      rimC: [0.2, 0.2, 0.2], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-6, 8, 0.65, 14]
    });
    E.grain(0.035, 122);
  }
});
