'use strict';
// s30 — "Gold honeycomb in glass": a gold cell network with cream floors and
// white rice-grain beads, sealed inside a clear glass tooth, on a studio blue sweep.
REC.register('s30', {
  w: 1024, h: 1024,
  draw(E) {
    const W = 1024, H = 1024;
    // ── cells: [cx, cy, rx, ry, rot, tone(0 cream..1 dark amber), beadScale]
    const CELLS = [
      [205, 248, 52, 46, 0.3, 0.0, 0.8], [372, 285, 100, 118, 0.1, 0.0, 1.0], [318, 505, 70, 92, -0.35, 0.05, 0.9],
      [488, 495, 76, 66, 0, 0.25, 0.55], [650, 262, 150, 92, -0.62, 0.0, 1.2], [655, 350, 205, 12, -0.72, 0.9, 0],
      [660, 468, 158, 66, -0.52, 0.05, 1.0], [852, 330, 28, 62, 0.1, 0.1, 0.9], [872, 482, 30, 52, 0, 0.95, 0.9],
      [540, 642, 62, 56, 0, 0.35, 0.8], [706, 628, 64, 68, 0, 0.45, 0.9], [818, 630, 26, 58, 0.1, 0.95, 0],
      [570, 778, 70, 68, 0, 0.5, 0.8], [722, 778, 58, 52, 0.2, 0.6, 1.0], [625, 935, 105, 82, -0.3, 0.55, 1.0],
      [450, 700, 24, 72, 0, 0.9, 0.5], [370, 762, 32, 128, 0.04, 0.45, 0.8], [272, 752, 52, 138, 0.02, 0.35, 0.9],
      [160, 635, 44, 60, 0, 0.5, 0.8], [172, 482, 50, 76, 0.1, 0.25, 0.8], [172, 808, 40, 88, 0, 0.6, 0.8],
      [445, 880, 56, 46, 0, 0.55, 0.8], [290, 968, 82, 62, 0, 0.55, 0.9], [440, 995, 38, 42, 0, 0.6, 0.8],
      [528, 1000, 44, 40, 0, 0.6, 0.8], [180, 970, 30, 44, 0, 0.8, 0.7], [800, 205, 42, 34, -0.4, 0.05, 1.2]
    ];
    // gold mass outline (outer edge of the gold rim)
    const GOLD = [[165, 200], [200, 168], [250, 150], [300, 140], [360, 136], [420, 140], [470, 150], [500, 160], [530, 150], [590, 146],
      [660, 150], [720, 146], [770, 140], [820, 148], [880, 160], [930, 180], [945, 215], [920, 250], [893, 278], [885, 320], [893, 360],
      [880, 400], [905, 428], [915, 470], [912, 520], [925, 570], [920, 620], [893, 655], [862, 690], [850, 740], [842, 790], [812, 832],
      [780, 862], [760, 900], [742, 950], [720, 992], [708, 1034], [200, 1034], [178, 965], [152, 905], [132, 845], [118, 770],
      [108, 690], [104, 600], [104, 520], [110, 440], [118, 370], [125, 310], [140, 255]];
    const GLASS = [[128, 1030], [112, 900], [96, 790], [82, 640], [70, 500], [66, 380], [76, 270], [100, 180], [145, 108], [210, 64],
      [282, 46], [345, 56], [400, 84], [440, 112], [472, 128], [520, 110], [600, 80], [700, 56], [800, 42], [872, 40], [932, 56],
      [976, 98], [1004, 168], [1012, 250], [1006, 350], [997, 480], [990, 600], [976, 720], [956, 820], [930, 900], [902, 968], [872, 1034]];

    for (const c of CELLS) if (c[3] > 20) { c[2] *= 1.6; c[3] *= 1.6; }
    // ── cell field on the CPU: e = distance into a cell floor (<0 gold), id = nearest cell, eo = depth inside gold outline
    const hsh = (x, y) => { let h = Math.sin(x * 127.1 + y * 311.7) * 43758.5453; return h - Math.floor(h); };
    const vn = (x, y) => { const ix = Math.floor(x), iy = Math.floor(y), fx = x - ix, fy = y - iy, ux = fx * fx * (3 - 2 * fx), uy = fy * fy * (3 - 2 * fy);
      const a0 = hsh(ix, iy), b0 = hsh(ix + 1, iy), a1 = hsh(ix, iy + 1), b1 = hsh(ix + 1, iy + 1);
      return (a0 + (b0 - a0) * ux) * (1 - uy) + (a1 + (b1 - a1) * ux) * uy; };
    const NCc = CELLS.length, cc = CELLS.map(c => [c[0], c[1], 1 / c[2], 1 / c[3], Math.cos(c[4]), Math.sin(c[4])]);
    const K = 7;
    // outline distance via a coarse distance grid (exact seg distance at 4px, bilinear)
    const G4 = 4, gw = W / G4 + 1, gh = H / G4 + 1, EO = new Float32Array(gw * gh);
    const gpath = P(GOLD, true, false), tctx = document.createElement('canvas').getContext('2d');
    for (let j = 0; j < gh; j++) for (let i = 0; i < gw; i++) {
      const x = i * G4, y = j * G4; let d = 1e9;
      for (let k = 0; k < GOLD.length; k++) {
        const A = GOLD[k], B = GOLD[(k + 1) % GOLD.length], ex = B[0] - A[0], ey = B[1] - A[1];
        const t = clamp(((x - A[0]) * ex + (y - A[1]) * ey) / (ex * ex + ey * ey)), dx = x - A[0] - ex * t, dy = y - A[1] - ey * t;
        d = Math.min(d, dx * dx + dy * dy);
      }
      EO[j * gw + i] = (tctx.isPointInPath(gpath, x, y) ? 1 : -1) * Math.sqrt(d);
    }
    const eoAt = (x, y) => { const gx = x / G4, gy = y / G4, i = Math.min(gw - 2, Math.floor(gx)), j = Math.min(gh - 2, Math.floor(gy)), u = gx - i, v = gy - j;
      return (EO[j * gw + i] * (1 - u) + EO[j * gw + i + 1] * u) * (1 - v) + (EO[(j + 1) * gw + i] * (1 - u) + EO[(j + 1) * gw + i + 1] * u) * v; };
    const field = (x, y, warp = true) => {
      let wx = x, wy = y;
      if (warp) { wx += 22 * (vn(x * 0.008, y * 0.008) - 0.5); wy += 22 * (vn(x * 0.008 + 7.3, y * 0.008 + 7.3) - 0.5); }
      let f1 = 1e5, S = 0, id = 0;
      for (let i = 0; i < NCc; i++) {
        const c = cc[i], dx = wx - c[0], dy = wy - c[1], qx = c[4] * dx + c[5] * dy, qy = -c[5] * dx + c[4] * dy;
        const L = Math.hypot(qx, qy), l = Math.hypot(qx * c[2], qy * c[3]), di = L * (1 - 1 / Math.max(l, 1e-3));
        S += Math.exp(-clamp(di / (2 * K), -40, 40));
        if (di < f1) { f1 = di; id = i; }
      }
      const eo = eoAt(x, y);
      let s2 = Math.max(S * Math.exp(clamp(f1 / (2 * K), -40, 40)) - 1, 1e-6);
      s2 += Math.exp(-clamp((eo - 26) / K, -30, 30)) + Math.exp(clamp(f1 / K, -30, 30));
      return [-K * Math.log(s2), id, eo];
    };
    const sstep = (a, b, x) => { const t = clamp((x - a) / (b - a)); return t * t * (3 - 2 * t); };
    const bgc = (u, v) => {
      let c = [0.165 + 0.07 * sstep(0, 1, u), 0.320 + 0.135 * sstep(0, 1, u), 0.525 + 0.105 * sstep(0, 1, u)];
      const f = 0.72 + 0.28 * sstep(0, 0.42, v); c = c.map(q => q * f);
      const cor = clamp(sstep(0.35, 0, v) * (sstep(0.35, 0, u) + sstep(0.7, 1, u)) * 0.8, 0, 0.85);
      c = c.map((q, i) => q + ([0.14, 0.13, 0.11][i] - q) * cor);
      const t1 = sstep(0.80, 0.86, v); c = c.map((q, i) => q + ([0.30, 0.50, 0.64][i] - q) * t1);
      const hu = sstep(0.1, 0.9, u), hz = [0.60 + 0.23 * hu, 0.68 + 0.17 * hu, 0.73 + 0.15 * hu], t2 = sstep(0.84, 0.97, v);
      return c.map((q, i) => q + (hz[i] - q) * t2);
    };
    const ALB = new ImageData(W, H), HGT = new ImageData(W, H), ad = ALB.data, hd = HGT.data;
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      const o = (y * W + x) * 4; ad[o + 3] = hd[o + 3] = 255;
      const eo0 = eoAt(x, y);
      if (eo0 <= 0) { const c = bgc(x / W, y / H); ad[o] = c[0] * 255; ad[o + 1] = c[1] * 255; ad[o + 2] = c[2] * 255; continue; }
      const [e, id, eo] = field(x, y);
      const t = clamp(e / 24);
      const hcv = 0.30 + 0.26 * Math.sqrt(Math.max(0, 1 - t * t)) + 0.12 * Math.sqrt(clamp(-e / 26));
      const hr = 0.54 * Math.sqrt(1 - Math.pow(1 - clamp(eo / 24), 2));
      const hv = Math.min(hcv, hr), m = e > 21 ? (CELLS[id][5] > 0.85 ? 4 : 2) : 1;
      const v = hv * 255, iv = Math.floor(v);
      hd[o] = iv; hd[o + 1] = m * 32; hd[o + 2] = Math.round((v - iv) * 255);
      // albedo
      const dk = sstep(250, 1000, y) * (0.85 + 0.25 * sstep(450, 850, x)), tone = CELLS[id][5];
      const gold = [1.0 - 0.38 * dk, 0.95 - 0.43 * dk, 0.85 - 0.45 * dk];
      let cream = [0.84 - 0.44 * dk, 0.68 - 0.40 * dk, 0.44 - 0.26 * dk];
      const am = 1 - 0.2 * dk; cream = cream.map((q, i) => q + ([0.78, 0.44, 0.12][i] * am - q) * tone * 0.75);
      const g = 0.85 + 0.3 * (0.6 * vn(x * 0.35, y * 0.35) + 0.4 * hsh(x, y));
      const kk = sstep(18, 23, e), lip = 0.5 * Math.exp(-Math.pow((e - 20) / 2.2, 2)) * (1 - dk * 0.3);
      for (let i = 0; i < 3; i++) { let c = gold[i] + (cream[i] * g - gold[i]) * kk; c += ([1.0, 0.62, 0.18][i] - c) * lip; ad[o + i] = clamp(c) * 255; }
    }
    const albC = document.createElement('canvas'); albC.width = W; albC.height = H; albC.getContext('2d').putImageData(ALB, 0, 0);
    const hgtC = document.createElement('canvas'); hgtC.width = W; hgtC.height = H; hgtC.getContext('2d').putImageData(HGT, 0, 0);
    const R = E.relief(), a = R.a, hx = R.h;
    a.drawImage(albC, 0, 0, W, H);
    hx.drawImage(hgtC, 0, 0, W, H);

    // beads: rice grains scattered in each cell
    const rr = rng(30), placed = [];
    const capsule = (x, y, L, r, ang) => {
      const c = Math.cos(ang), s = Math.sin(ang), hl = Math.max(0, L / 2 - r), p = new Path2D();
      p.arc(x + c * hl, y + s * hl, r, ang - Math.PI / 2, ang + Math.PI / 2);
      p.arc(x - c * hl, y - s * hl, r, ang + Math.PI / 2, ang + Math.PI * 1.5);
      p.closePath(); return p;
    };
    const cellE = (x, y) => field(x, y)[0];
    for (const [cx, cy, rx, ry, rot, tone, bs] of CELLS) {
      if (!bs) continue;
      const n = Math.round(rx * ry / 1500 * (0.8 + 0.3 * bs));
      const dk = clamp((cy - 250) / 750);
      for (let i = 0, tries = 0; i < n && tries < n * 30; tries++) {
        const t = rr() * Math.PI * 2, u = Math.sqrt(rr()) * 0.75;
        const lx = Math.cos(t) * rx * u, ly = Math.sin(t) * ry * u;
        const x = cx + lx * Math.cos(rot) - ly * Math.sin(rot), y = cy + lx * Math.sin(rot) + ly * Math.cos(rot);
        const big = rr() < 0.66;
        const r = (big ? 15 + rr() * 6 : 8 + rr() * 5) * bs * (1 - dk * 0.25);
        const L = big ? r * (2.6 + rr() * 2.4) : r * (1.2 + rr() * 1.6);
        const ang = rr() < 0.55 ? -1.2 + rr() * 0.8 : rr() * Math.PI;
        const clear = Math.max(L / 2, r) * 0.75 + 3;
        const hl2 = Math.max(0, L / 2 - r), ex2 = Math.cos(ang) * hl2, ey2 = Math.sin(ang) * hl2;
        if (cellE(x, y) < r + 7 || cellE(x + ex2, y + ey2) < r + 7 || cellE(x - ex2, y - ey2) < r + 7) continue;
        if (placed.some(q => Math.hypot(q[0] - x, q[1] - y) < clear + q[2])) continue;
        placed.push([x, y, clear]); i++;
        const col = mixHex(mixHex('#f4f0ea', '#8e929c', dk), '#c89a60', tone * 0.25);
        R.dome(capsule(x, y, L, r, ang), col, 0.3, 0.16 + r * 0.004, r * 0.95, 3);
      }
    }
    // right-edge protruding grains
    for (const [x, y, L, r, ang] of [[828, 700, 60, 17, 0.1], [822, 740, 62, 16, 0.05], [812, 782, 66, 17, 0.0], [850, 505, 36, 30, 1.3], [820, 330, 46, 22, 0.8]])
      R.dome(capsule(x, y, L, r, ang), '#ece6dc', 0.34, 0.2, r, 3);
    // big foam lump top-right
    R.dome(P([[800, 180], [845, 166], [895, 174], [922, 200], [905, 230], [860, 244], [815, 238], [795, 212]]), '#d8cab4', 0.4, 0.18, 30, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ metal: 1, spec: 0.75, shin: 14, rim: 0.4, tint: [1.0, 0.88, 0.58], coat: 0.08 }),        // 1 gold
        E.mat({ dif: 1, spec: 0.12, shin: 10, grain: 0.1, wrap: 0.35, ao: 0.5 }),                      // 2 cream floor
        E.mat({ dif: 1, spec: 0.3, shin: 18, wrap: 0.6, rim: 0.2, emis: 0.35 }),                     // 3 beads
        E.mat({ metal: 1, spec: 1.0, shin: 80, tint: [1.0, 0.62, 0.20], coat: 0.1 })                   // 4 amber pockets
      ],
      light: [-0.35, 0.45, 0.82], lc: [0.80, 0.74, 0.64], amb: [0.20, 0.18, 0.18],
      envTop: [1.45, 1.30, 0.92], envHor: [0.66, 0.52, 0.30], envBot: [0.12, 0.07, 0.03], envK: [0.2, 1.3, 0.0, 0],
      rimC: [0.25, 0.35, 0.5], rimD: [1, 0, 0.6], l2: [1, 0.2, -0.1, 1.5], l2c: [0.25, 0.35, 0.55],
      r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 170], shadow: [4, 6, 0.35, 6]
    });

    // ── glass overlay ──
    const o = E.out, gp = P(GLASS);
    o.save();
    o.fillStyle = 'rgba(190,215,245,0.10)'; o.fill(gp);
    o.clip(gp);
    // soft inner bevel: bright band along the edge inside
    o.lineJoin = 'round';
    for (const [lw, al] of [[90, 0.05], [46, 0.06], [26, 0.07], [12, 0.10]]) { o.lineWidth = lw; o.strokeStyle = `rgba(225,238,255,${al})`; o.stroke(gp); }
    // amber reflections of the gold in the right wall
    o.lineCap = 'round';
    const lg = o.createLinearGradient(880, 0, 990, 0);
    lg.addColorStop(0, 'rgba(200,225,245,0)'); lg.addColorStop(0.6, 'rgba(200,225,245,0.35)'); lg.addColorStop(1, 'rgba(200,225,245,0.1)');
    o.fillStyle = lg; o.fillRect(860, 240, 140, 700);
    o.strokeStyle = 'rgba(205,150,60,0.7)'; o.lineWidth = 20;
    o.stroke(P([[962, 190], [968, 300], [966, 450], [962, 600], [950, 740], [930, 850], [900, 940], [872, 1010]], false));
    o.strokeStyle = 'rgba(80,55,30,0.55)'; o.lineWidth = 5;
    o.stroke(P([[985, 170], [990, 300], [985, 450], [978, 600], [966, 720], [946, 820], [918, 910], [888, 980], [866, 1030]], false));
    o.strokeStyle = 'rgba(120,85,40,0.5)'; o.lineWidth = 7;
    o.stroke(P([[600, 118], [700, 92], [800, 78], [880, 80], [940, 110]], false));
    o.restore();
    // specular rim highlights
    o.save(); o.lineCap = 'round'; o.lineJoin = 'round';
    const hl = (pts, lw, al) => { o.lineWidth = lw; o.strokeStyle = `rgba(255,255,255,${al})`; o.stroke(P(pts, false)); };
    hl([[96, 190], [140, 116], [210, 72], [282, 54], [345, 62], [400, 90]], 3, 0.55);
    hl([[520, 116], [600, 88], [700, 64], [800, 50], [872, 48], [930, 62]], 3, 0.35);
    hl([[82, 330], [80, 450], [86, 600], [98, 760], [112, 890], [124, 1020]], 5, 0.18);
    hl([[100, 420], [104, 560], [112, 700]], 9, 0.10);
    hl([[440, 118], [472, 134], [505, 124]], 3, 0.5);
    o.restore();
    // bubbles
    const br = rng(7);
    for (let i = 0; i < 26; i++) {
      const x = 150 + br() * 780, y = 90 + br() * 90, r = 1.5 + br() * 3;
      o.fillStyle = `rgba(255,255,255,${0.5 + br() * 0.4})`; o.beginPath(); o.arc(x, y, r, 0, 7); o.fill();
    }
    for (const [x, y, r] of [[185, 122, 5], [150, 186, 3], [760, 124, 3], [790, 128, 3], [720, 132, 2]]) { o.fillStyle = 'rgba(255,255,255,0.8)'; o.beginPath(); o.arc(x, y, r, 0, 7); o.fill(); }
    E.grain(0.035, 5);
  }
});
