'use strict';
// g072 — "Gold-slab grin in glass": a glossy 3D toy — a black box head with a cyan visor band, goggle eyes and
// a yellow muzzle, half-buried under a sparkling gold slab of veins and white drops, inside a glass capsule
// lined with fine wavy zebra ridges; a yellow glove reaches in, sky and a tree behind.
REC.register('g072', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r0); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const clipBoth = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const inside = (path, x, y) => a.isPointInPath(path, x * S, y * S);
    const r = rng(72);

    // ── sky + tree (unlit) ──
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float t = p.y + 1.6 * p.x;
      vec3 c = mix(vec3(0.10, 0.18, 0.35), vec3(0.15, 0.25, 0.47), smoothstep(0., 380., t));
      c = mix(c, vec3(0.20, 0.39, 0.62), smoothstep(380., 640., t));
      c = mix(c, vec3(0.28, 0.57, 0.74), smoothstep(620., 800., t));
      c = mix(c, vec3(0.80, 0.89, 0.93), smoothstep(800., 1100., t));
      vec3 top = mix(vec3(0.12, 0.21, 0.40), vec3(0.05, 0.44, 0.66), smoothstep(150., 420., p.x));
      c = mix(top, c, smoothstep(60., 220., p.y));
      return c; }`));
    R.flat(rrect(-10, -10, 746, 1044, 0), sky, 0, 0);
    const tree = P([[440, 172], [446, 140], [470, 118], [496, 104], [520, 84], [552, 66], [580, 40], [612, 22], [650, 8], [700, -4], [731, -6], [731, 172]]);
    const treeTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = fbm(p * 0.06), m = fbm(p * 0.018 + 3.);
      vec3 c = mix(vec3(0.20, 0.28, 0.03), vec3(0.42, 0.55, 0.06), smoothstep(0.35, 0.7, n));
      c = mix(c, vec3(0.13, 0.18, 0.04), smoothstep(0.55, 0.75, m) * 0.7);
      return c; }`));
    R.flat(P(ragged([[440, 172], [446, 140], [470, 118], [496, 104], [520, 84], [552, 66], [580, 40], [612, 22], [650, 8], [700, -4], [731, -6], [731, 172]], 0, 10, 9, 6, 7)), treeTex, 0, 0);

    // ── glass capsule interior: fine wavy zebra ridges ──
    const capPts = [[176, 44], [258, 28], [330, 54], [362, 96], [452, 104], [560, 72], [648, 28], [700, 38], [720, 108], [726, 300], [728, 560], [720, 700], [700, 850], [678, 1029],
      [96, 1029], [58, 900], [44, 700], [52, 500], [76, 330], [116, 180]];
    const cap = P(capPts);
    const ZPH = `float zph(vec2 p){
        vec2 q = p + 14. * vec2(vnoise(p * 0.03) - .5, vnoise(p * 0.03 + 7.) - .5);
        q.y += 3.5 * sin(q.x * 0.21 + 2. * vnoise(p * 0.02));
        return dot(q, vec2(0.86, -0.52)) / 10.5; }`;
    const zAlb = pat(E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){ float f = fract(zph(p));
      float w = smoothstep(0.03, 0.09, f) * smoothstep(0.68, 0.62, f);
      return mix(vec3(0.02, 0.02, 0.025), vec3(0.97, 0.97, 0.98), w); }`));
    const zH = E.fx(ZPH + `vec3 fx(vec2 uv, vec2 p){ float f = fract(zph(p));
      float w = smoothstep(0.0, 0.1, f) * smoothstep(0.71, 0.6, f);
      float hv = 0.04 + 0.05 * w * sin(3.1416 * clamp(f / 0.71, 0., 1.));
      float v = hv * 255., i = floor(v); return vec3(i / 255., 7. * 32. / 255., fract(v)); }`);
    const zone = P([[100, 226], [240, 226], [300, 400], [360, 640], [726, 340], [731, 1029], [40, 1029], [40, 226]], true, false);
    clipBoth(cap, () => {
      R.flat(zone, zAlb, 0.05, 7);
      R.h.save(); R.h.clip(zone); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(zH, 0, 0); R.h.restore();
    });
    keep();

    // ── target rings behind the head ──
    clipBoth(cap, () => {
      R.flat(ellipseP(392, 292, 238, 196), '#050506', 0.08, 5);
      R.pipe(ellipseP(378, 286, 152, 168), 26, '#f2f2f4', 0.08, 0.05, 2);
    });

    // ── black box head, visor band ──
    const box = P([[266, 168], [708, 148], [716, 650], [266, 650]], true, false);
    R.dome(box, '#060607', 0.1, 0.04, 8, 5);
    R.flat(P([[652, 58], [700, 46], [708, 150], [648, 166]], true, false), '#26262c', 0.1, 5);
    R.dome(P([[276, 188], [712, 184], [712, 290], [276, 292]], true, false), lin(0, 188, 0, 292, [[0, '#18d8f0'], [0.6, '#0bcfe8'], [1, '#08a8c4']]), 0.14, 0.03, 5, 1);
    R.pipe(P([[268, 296], [652, 294]], false, false), 6, '#3a3a40', 0.12, 0.03, 5);
    keep();

    // ── eyes, nose, muzzle, lips ──
    R.dome(ellipseP(368, 360, 42, 40), rad(356, 344, 60, [[0, '#ffffff'], [0.7, '#f2f2f6'], [1, '#c8c8d4']]), 0.16, 0.22, 40, 2);
    R.dome(ellipseP(505, 366, 45, 44), rad(492, 350, 64, [[0, '#ffffff'], [0.7, '#f2f2f6'], [1, '#c8c8d4']]), 0.16, 0.22, 42, 2);
    R.bead(350, 356, 11, '#050506', 0.36, 0.04, 5);
    R.bead(482, 363, 12, '#050506', 0.36, 0.04, 5);
    const yel = (x0, y0, x1, y1) => lin(x0, y0, x1, y1, [[0, '#ffe81a'], [0.6, '#fdd808'], [1, '#e8a800']]);
    R.dome(P([[300, 498], [470, 494], [478, 530], [460, 574], [400, 588], [330, 580], [304, 548]]), yel(0, 500, 0, 590), 0.15, 0.14, 26, 1);
    R.dome(P([[326, 500], [462, 498], [458, 540], [400, 552], [334, 542]]), lin(0, 500, 0, 552, [[0, '#7a3a20'], [0.4, '#e8b088'], [1, '#d89870']]), 0.2, 0.06, 10, 1);
    R.dome(P([[278, 418], [370, 408], [460, 406], [542, 412], [548, 470], [534, 504], [470, 512], [400, 506], [320, 504], [284, 486], [276, 450]]), yel(0, 408, 0, 512), 0.16, 0.16, 34, 1);
    R.dome(P([[362, 404], [410, 394], [452, 400], [460, 424], [448, 448], [406, 452], [366, 446], [356, 424]]), yel(0, 394, 0, 452), 0.32, 0.12, 24, 1);
    keep();

    // ── red side panel + base with wheels ──
    R.flat(P([[596, 640], [716, 640], [700, 700], [660, 900], [640, 1029], [590, 1029]], true, false), '#060607', 0.1, 5);
    R.dome(P([[640, 708], [700, 690], [696, 760], [676, 880], [658, 1029], [598, 1029], [614, 900]], true, false), lin(600, 0, 700, 0, [[0, '#a00e06'], [0.4, '#ec1e10'], [1, '#f83a20']]), 0.12, 0.04, 8, 1);
    R.dome(ellipseP(205, 1012, 68, 38), '#3a3a40', 0.12, 0.1, 30, 6);
    R.dome(ellipseP(446, 1016, 64, 36), '#3a3a40', 0.12, 0.1, 30, 6);
    R.flat(P([[86, 952], [602, 952], [600, 984], [90, 984]], true, false), '#08080c', 0.2, 5);
    R.dome(P([[86, 893], [602, 893], [602, 956], [86, 956]], true, false), lin(0, 893, 0, 956, [[0, '#9a9aaa'], [0.5, '#7c7c8c'], [1, '#5a5a66']]), 0.24, 0.05, 6, 6);
    R.dome(P([[100, 876], [590, 876], [602, 894], [86, 894]], true, false), '#b0b0bc', 0.28, 0.02, 4, 6);
    keep();

    // ── gold slab with white drops and gold veins ──
    const slabPts = [[112, 884], [124, 842], [158, 792], [208, 742], [268, 692], [330, 646], [384, 608], [440, 570], [490, 530], [522, 478], [546, 420], [580, 370], [620, 328], [656, 290], [690, 262], [712, 262],
      [716, 300], [712, 380], [700, 480], [688, 560], [672, 640], [652, 720], [630, 800], [606, 860], [592, 884]];
    const slab = P(slabPts);
    const sparkle = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float s = hash(floor(p * 1.3)), n = fbm(p * 0.02);
      vec3 c = mix(vec3(0.82, 0.67, 0.42), vec3(0.93, 0.79, 0.53), n);
      c += vec3(0.12, 0.1, 0.06) * step(0.9, s) - vec3(0.08, 0.07, 0.04) * step(s, 0.15);
      return c; }`));
    R.dome(slab, sparkle, 0.24, 0.06, 18, 4);
    keep();
    // giraffe network: anisotropic Voronoi cells (stretched along the slab's diagonal); a white drop in each, gold veins on the edges
    const dx = 0.68, dy = -0.733, nx0 = 0.733, ny0 = 0.68, SQ = 0.62;
    const T = ([x, y]) => [(x * dx + y * dy) * SQ, x * nx0 + y * ny0];
    const Ti = ([u, v]) => [u / SQ * dx + v * nx0, u / SQ * dy + v * ny0];
    const seeds = [];
    for (let i = 0; i < 9000 && seeds.length < 220; i++) {
      const x = 100 + r() * 620, y = 250 + r() * 650;
      if (!inside(slab, x, y)) continue;
      const t = T([x, y]);
      if (seeds.some(s2 => Math.hypot(s2[0] - t[0], s2[1] - t[1]) < 36)) continue;
      seeds.push(t);
    }
    const clipHP = (poly, nx, ny, c) => { const out = [];
      for (let i = 0; i < poly.length; i++) { const A = poly[i], B = poly[(i + 1) % poly.length], da = nx * A[0] + ny * A[1] - c, db = nx * B[0] + ny * B[1] - c;
        if (da <= 0) out.push(A); if ((da < 0) !== (db < 0)) { const t = da / (da - db); out.push([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t]); } }
      return out; };
    const cells = seeds.map(([su, sv]) => {
      let cell = [[su - 40, sv - 40], [su + 40, sv - 40], [su + 40, sv + 40], [su - 40, sv + 40]], rin = 40;
      for (const [tu, tv] of seeds) { if (tu === su && tv === sv) continue; const d = Math.hypot(tu - su, tv - sv); if (d > 100) continue;
        cell = clipHP(cell, (tu - su) / d, (tv - sv) / d, ((tu - su) * (su + tu) + (tv - sv) * (sv + tv)) / (2 * d)); rin = Math.min(rin, d / 2); }
      return { s: [su, sv], cell, rin };
    });
    for (const { s: [su, sv], rin } of cells) {
      const k = 0.45 + r() * 0.32, pts = blob(su + (r() - 0.5) * 4, sv + (r() - 0.5) * 4, rin * k * 1.1, rin * k * (0.7 + r() * 0.25), 500 + Math.round(su), 9, 0.25, r() * 3).map(Ti);
      R.dome(P(pts), '#f2f2f6', 0.3, 0.08, 7, 2);
    }
    keep();
    clipBoth(slab, () => {
      const seen = new Set(), vr = rng(721);
      for (const { s: [su, sv], cell } of cells) for (let i = 0; i < cell.length; i++) {
        const A = cell[i], B = cell[(i + 1) % cell.length], M = [(A[0] + B[0]) / 2, (A[1] + B[1]) / 2];
        const key = Math.round(M[0] / 2) + ',' + Math.round(M[1] / 2);
        if (seen.has(key)) continue; seen.add(key);
        if (vr() < 0.3) continue;
        const L = Math.hypot(B[0] - A[0], B[1] - A[1]) || 1, w = (vr() - 0.5) * L * 0.35;
        const C = [M[0] - (B[1] - A[1]) / L * w, M[1] + (B[0] - A[0]) / L * w];
        R.pipe(P([A, C, B].map(Ti), false), 6 + vr() * 3, '#ffca24', 0.29, 0.08, 3);
      }
    });
    keep();
    R.pipe(slab, 12, '#f2b420', 0.27, 0.1, 3);
    keep();

    // ── gold drips down the left of the face ──
    const drips = [
      [[176, 244], [164, 270], [172, 300], [200, 336], [232, 372], [258, 410], [262, 450], [252, 486], [266, 520], [296, 556], [318, 596], [312, 632], [296, 660]],
      [[200, 336], [212, 300], [234, 284], [246, 262]],
      [[262, 450], [236, 452], [214, 470]],
      [[300, 600], [262, 600], [232, 594], [204, 604], [190, 626], [204, 654], [234, 664], [266, 650], [286, 628]],
      [[176, 600], [204, 604]],
      [[160, 244], [148, 262], [142, 300]],
      [[176, 588], [152, 600], [158, 620]],
    ];
    for (const d of drips) R.pipe(P(d, false), 8, '#f0b018', 0.3, 0.07, 3);
    for (const [x, y, rr] of [[170, 592, 10], [196, 616, 7], [246, 262, 6], [214, 470, 6]]) R.bead(x, y, rr, '#f0b018', 0.3, 0.07, 3);
    keep();

    // ── bubbles ──
    for (const [x, y, rr] of [[140, 48, 7], [184, 62, 9], [108, 22, 5], [126, 80, 4], [168, 366, 10], [210, 480, 11], [290, 602, 9], [302, 632, 8], [216, 640, 9], [168, 716, 11],
      [92, 832, 9], [70, 900, 5], [600, 240, 4], [620, 246, 3], [640, 240, 4], [612, 256, 3], [660, 228, 3], [110, 470, 4], [100, 600, 4]]) R.bead(x, y, rr, '#f4f4f8', 0.34, rr * 0.012 + 0.05, 2);
    R.dome(ellipseP(684, 264, 30, 22, -0.5), lin(660, 244, 710, 290, [[0, '#fff0d4'], [1, '#d8c098']]), 0.34, 0.06, 14, 2);

    // ── yellow glove + chick ──
    const hand = P([[-10, 116], [50, 110], [100, 98], [130, 72], [180, 58], [240, 56], [290, 70], [330, 96], [358, 124], [376, 146], [378, 160], [366, 168], [344, 164], [310, 156], [282, 160],
      [270, 170], [292, 180], [314, 194], [324, 212], [318, 226], [298, 230], [268, 222], [238, 214], [200, 214], [150, 226], [100, 246], [50, 270], [-10, 298]]);
    R.dome(hand, rad(150, 120, 260, [[0, '#ffe82a'], [0.6, '#fdd808'], [1, '#f0b800']]), 0.42, 0.28, 60, 1);
    const chick = P([[-10, 800], [18, 794], [44, 806], [56, 828], [72, 842], [74, 860], [54, 868], [42, 880], [46, 920], [70, 942], [62, 980], [40, 1029], [-10, 1029]]);
    R.dome(chick, rad(10, 840, 200, [[0, '#ffe020'], [0.6, '#f8c808'], [1, '#c88a00']]), 0.36, 0.2, 30, 1);
    R.bead(4, 826, 6, '#050506', 0.5, 0.05, 5);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 55, wrap: 0.35, ao: 0.35, coat: 0.12, rim: 0.2 }),          // 1 glossy plastic
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, ao: 0.3, coat: 0.25 }),                      // 2 white enamel
        E.mat({ dif: 1, spec: 1.7, shin: 70, metal: 0.3, ao: 0.25, wrap: 0.3, tint: [1.3, 1.05, 0.6] }), // 3 gold
        E.mat({ dif: 1.1, spec: 0.5, shin: 26, grain: 0.3, ao: 0.4, wrap: 0.4 }),                     // 4 gold sparkle
        E.mat({ dif: 1, spec: 1.3, shin: 90, coat: 0.3, ao: 0.2 }),                                  // 5 black gloss
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.4 }),                                  // 6 grey plastic
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.3, coat: 0.15, ao: 0.5 }),                      // 7 zebra ridges
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.8, 0.8, 0.8], amb: [0.36, 0.36, 0.38],
      envTop: [1.05, 1.05, 1.1], envHor: [0.5, 0.6, 0.7], envBot: [0.1, 0.1, 0.12], envK: [0.3, 1.1, 0.3, 0],
      rimC: [0.25, 0.3, 0.4], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 60], shadow: [-4, 6, 0.45, 6]
    });

    // ── glass capsule rim (overlay) ──
    const o = E.out;
    o.save(); o.lineCap = o.lineJoin = 'round';
    o.strokeStyle = 'rgba(230,240,255,0.55)'; o.lineWidth = 5; o.stroke(cap);
    o.filter = `blur(${2 * S}px)`; o.strokeStyle = 'rgba(255,255,255,0.5)'; o.lineWidth = 10; o.stroke(P([[176, 44], [258, 28], [330, 54], [362, 96], [452, 104], [560, 72], [648, 28], [700, 38]], false)); o.filter = 'none';
    const rim = P(capPts.map(([x, y]) => [x + (x < 363 ? 12 : y > 560 ? -34 : -10), y + (y < 120 ? 8 : 0)]));
    o.strokeStyle = '#7a4a08'; o.lineWidth = 4.5; o.stroke(rim);
    o.strokeStyle = '#f0b428'; o.lineWidth = 2.5; o.stroke(rim);
    o.restore();
    E.bloom(0.08, 8);
    E.grain(0.025, 2);
  }
});
