'use strict';
// g152 — "Spiral puddle machine": a teal clay puddle with a melting grey face, a chrome pipe, an olive egg, a black
// yellow-spotted bead and ribbed hoses, ringed by four zebra spiral discs on red, blue and terracotta.
REC.register('g152', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const hfx = (body, m) => E.fx(`${body}
      vec3 fx(vec2 uv, vec2 p){ float h = clamp(hgt(p), 0., 1.) * 255.; return vec3(floor(h) / 255., ${(m * 32 / 255).toFixed(5)}, fract(h)); }`);

    // ── background: red field, blue blob, white haze, terracotta clay ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#f61a10', 0, 0);
    soft(x => {
      x.fillStyle = '#0a48f6'; x.fill(sm([[-20, -20], [50, -20], [48, 40], [56, 100], [80, 150], [112, 178], [122, 210], [100, 240], [50, 252], [-20, 256]]));
      x.fillStyle = '#e2e0de'; x.fill(sm([[180, -20], [350, -20], [346, 40], [330, 100], [300, 128], [250, 126], [205, 80]]));
      x.fill(sm([[-20, 640], [20, 650], [34, 720], [40, 800], [64, 852], [120, 880], [210, 876], [170, 930], [120, 1000], [96, 1044], [-20, 1044]]));
    }, 6);
    const clayB = sm([[96, 1044], [150, 960], [200, 900], [240, 845], [262, 815], [300, 830], [340, 860], [440, 860], [520, 900], [600, 900], [690, 870], [690, 690], [736, 680], [736, 1044]]);
    R.flat(clayB, '#c9552e', 0.02, 1);
    R.flat(poly([[262, 1044], [318, 930], [336, 912], [344, 930], [300, 1044]]), '#f02a12', 0.03, 0);
    const clayT = sm([[350, -20], [736, -20], [736, 700], [660, 700], [600, 640], [560, 300], [430, 140], [360, 120]]);
    R.flat(clayT, '#cc5a30', 0.02, 1);
    // clay beads
    for (const [x, y, r] of [[385, 100, 14], [618, 196, 30], [688, 160, 26], [672, 214, 16], [700, 322, 10], [690, 344, 14], [434, 913, 14], [640, 893, 16], [700, 900, 14], [214, 920, 18]])
      R.bead(x, y, r, '#d4683c', 0.03, Math.min(0.12, r * 0.004 + 0.03), 1);

    // ── teal puddle ──
    const pud = sm([[330, 110], [380, 126], [420, 122], [432, 86], [470, 64], [520, 70], [560, 96], [578, 140], [590, 230], [628, 252], [640, 300], [652, 380], [700, 394], [736, 398], [736, 690],
      [690, 694], [640, 640], [560, 630], [470, 660], [440, 760], [440, 852], [404, 880], [390, 940], [372, 968], [340, 966], [328, 930], [304, 900], [282, 872], [266, 830],
      [248, 812], [270, 740], [180, 640], [130, 580], [178, 430], [160, 372], [165, 318], [215, 285], [270, 235], [320, 140]]);
    R.dome(pud, '#456a72', 0.03, 0.04, 8, 2);
    R.pipe(pud, 7, '#9a9a9c', 0.07, 0.03, 3);
    // teal splash dots on the right clay
    { const g = rng(77); for (let i = 0; i < 16; i++) { const x = 640 + g() * 60, y = 236 + g() * 140; R.dome(sm(blob(x, y, 6 + g() * 8, 5 + g() * 6, i + 3, 8, 0.3)), '#5a8890', 0.05, 0.05, 5, 2); } }
    // teal splash at the top + spikes
    R.dome(sm([[420, 110], [450, 80], [480, 92], [520, 88], [560, 100], [568, 140], [540, 160], [500, 150], [460, 140], [430, 132]]), '#4e7a82', 0.07, 0.05, 8, 2);
    for (const [x0, y0, x1, y1] of [[452, 88, 446, 30], [470, 84, 476, 26], [492, 84, 500, 36], [510, 84, 520, 40], [530, 90, 548, 40], [548, 96, 566, 50], [440, 100, 420, 60]])
      R.pipe(line([[x0, y0], [x1, y1]]), 7, '#7c7e82', 0.08, 0.04, 3);
    // teal blobs and worms on the puddle
    const worms = [[[360, 150], [400, 152]], [[400, 168], [440, 170]], [[340, 178], [400, 186]], [[440, 186], [480, 190]], [[490, 190], [560, 196]], [[470, 210], [520, 214]],
      [[520, 222], [560, 228]], [[500, 240], [540, 246]], [[420, 236], [450, 240]], [[620, 280], [650, 300]], [[640, 330], [660, 360]], [[620, 360], [640, 380]]];
    for (const w of worms) R.pipe(line(w), 12, '#4e7a82', 0.07, 0.05, 2);

    // ── grey plate ──
    const plate = poly([[125, 480], [165, 430], [200, 420], [230, 560], [300, 640], [295, 700], [275, 738], [255, 730], [240, 700], [150, 640], [130, 610]]);
    R.dome(plate, '#8a8a8e', 0.06, 0.03, 6, 3);
    R.pipe(plate, 6, '#a0a0a4', 0.09, 0.03, 3);

    // ── cyan pill in a grey frame on the left ──
    const frame = sm([[-20, 272], [50, 280], [110, 296], [150, 320], [172, 350], [160, 374], [100, 380], [40, 374], [-20, 362]]);
    R.dome(frame, '#6e7c84', 0.05, 0.05, 10, 3);
    R.dome(sm([[-20, 292], [60, 298], [118, 318], [150, 343], [140, 356], [80, 350], [-20, 336]]), '#96f2f2', 0.08, 0.02, 4, 1);

    // ── chrome pipe ──
    R.pipe(line([[40, -74], [217, 112]]), 118, '#9a9aa0', 0.1, 0.2, 7);
    R.pipe(line([[217, 112], [300, 190]]), 100, '#94949a', 0.1, 0.18, 7);
    const ang = Math.atan2(186, 177) + Math.PI / 2, ca = Math.cos(ang - Math.PI / 2), sa = Math.sin(ang - Math.PI / 2);
    for (const [x, y, rx, ry] of [[214, 110, 76, 20], [292, 184, 64, 17]]) {
      R.dome(ellipseP(x, y, rx, ry, ang), '#b4b4bc', 0.24, 0.1, 12, 7);
      R.groove(ellipseP(x + ca * 2, y + sa * 2, rx - 8, ry - 12, ang), 5, '#202026', 0.34, 0.06, 7, 1);
      R.dome(ellipseP(x + ca * 16, y + sa * 16, rx - 14, 6, ang), '#3a3a42', 0.12, 0.02, 3, 7);
    }
    R.pipe(line([[70, 0], [60, 20], [70, 40]]), 5, '#9a9aa0', 0.2, 0.04, 7);
    R.bead(75, 8, 8, '#b0b0b4', 0.2, 0.06, 7);
    // grey hose from the pipe into the puddle
    R.pipe(line([[205, 200], [180, 212], [163, 240], [165, 270], [185, 295], [205, 320], [215, 350], [222, 380]]), 13, '#8c8c90', 0.12, 0.08, 3);
    R.pipe(circleP(204, 202, 7), 3, '#30303a', 0.2, 0.02, 7);

    // ── zebra spiral discs ──
    const DISCS = [[78, 512, 74, 86, 0.0], [152, 748, 108, 104, -0.2], [566, 772, 128, 140, 0.15], [588, 4, 168, 148, 0.0]];
    // fitted spiral phase per disc: cx, cy, period, phase, aspect, c2, c3, c4, rot, dir
    const SPF = [[85.149, 504.18, 12.111, 0.9664, 1.2237, -2.4706, -0.3707, -3.8732, 0, 1], [144.565, 748.168, 15.026, 0.4791, 1.0509, -1.7716, 0.2745, -0.3271, -0.2, 1],
      [562.16, 779.13, 47.884, 0.2905, 1.1843, 0.4684, 0.331, -2.7979, 0.15, -1], [603.744, 19.327, 20.344, 0.5057, 0.9754, -0.5858, 0.2831, -0.1223, 0, -1]];
    const discP = DISCS.map(([x, y, rx, ry, rot]) => ellipseP(x, y, rx, ry, rot));
    const f1 = v => (Number.isInteger(v) ? v.toFixed(1) : String(v));
    const SPG = `
      const vec4 DC[4] = vec4[4](${DISCS.map(d => `vec4(${d.slice(0, 4).map(f1).join(', ')})`).join(', ')});
      const float DR[4] = float[4](${DISCS.map(d => f1(d[4])).join(', ')});
      const float SF[40] = float[40](${SPF.flat().map(f1).join(', ')});
      float spv(vec2 p){
        float best = 9.; int k = 0;
        for (int i = 0; i < 4; i++) {
          vec2 d = p - DC[i].xy; float c = cos(DR[i]), s = sin(DR[i]);
          vec2 q = vec2(c * d.x + s * d.y, -s * d.x + c * d.y) / DC[i].zw; float rn = length(q);
          if (rn < best) { best = rn; k = i; }
        }
        int j = k * 10; float c = cos(SF[j + 8]), s = sin(SF[j + 8]);
        vec2 d = p - vec2(SF[j], SF[j + 1]);
        vec2 q = vec2(c * d.x + s * d.y, (-s * d.x + c * d.y) / SF[j + 4]);
        float r = length(q), th = atan(q.y, q.x);
        float ph = r / SF[j + 2] + SF[j + 5] * (r / 100.) * (r / 100.) + SF[j + 9] * th / 6.2832 + SF[j + 3] + SF[j + 6] * cos(th - SF[j + 7]) * (r / 100.);
        return cos(6.2832 * ph); }`;
    const spCol = E.fx(`${SPG}
      vec3 fx(vec2 uv, vec2 p){ float v = spv(p); return mix(vec3(.95), vec3(.03), smoothstep(-.18, .18, v)); }`);
    const spH = hfx(`${SPG}
      float hgt(vec2 p){ float v = spv(p); return 0.12 + 0.06 * smoothstep(.4, -.7, v); }`, 4);
    for (const p of discP) { R.dome(p, '#9a9a9c', 0.08, 0.04, 6, 3); }
    for (let i = 0; i < 4; i++) {
      const [x, y, rx, ry, rot] = DISCS[i];
      clipAH(ellipseP(x, y, rx - 6, ry - 6, rot), () => { img(spCol); img(spH, R.h); });
    }

    // olive egg (behind the melt)
    R.dome(ellipseP(345, 265, 96, 62, -0.15), rad(345, 270, 100, [[0, '#aab886'], [0.45, '#7a8658'], [1, '#30362a']], 330, 225), 0.14, 0.2, 40, 5);
    R.pipe(line([[380, 205], [410, 208], [428, 218], [434, 240]]), 4, '#b8a060', 0.3, 0.02, 4);
    // ── melting grey face: dome + warped concentric folds ──
    const head = sm([[175, 430], [200, 386], [232, 352], [262, 336], [300, 330], [350, 312], [400, 282], [440, 246], [468, 252], [462, 300], [448, 340], [462, 384], [452, 448],
      [424, 516], [402, 580], [372, 630], [330, 648], [282, 640], [240, 620], [204, 566], [182, 500]]);
    const HG = `
      float fold(vec2 p){ vec2 c = vec2(286., 486.); vec2 d = p - c;
        float w = length(d * vec2(1., 0.85)) / 52. + 1.3 * fbm(p * 0.009 + 3.) + 0.3 * sin(atan(d.y, d.x) * 3. + 1.);
        return cos(6.2832 * w); }
      float base(vec2 p){ vec2 d = p - vec2(318., 452.); float c = cos(-0.45), s = sin(-0.45);
        vec2 q = vec2(c * d.x + s * d.y, -s * d.x + c * d.y) / vec2(150., 205.); return sqrt(max(0., 1. - dot(q, q))); }`;
    soft(x => { x.fillStyle = '#000'; x.fill(head); }, 10, 0.35);
    R.dome(head, null, 0.08, 0.06, 10, 3);
    clipAH(head, () => {
      img(E.fx(`${HG}
        vec3 fx(vec2 uv, vec2 p){ float f = fold(p); return vec3(.5, .5, .52) + vec3(.1) * f; }`));
      img(hfx(`${HG}
        float hgt(vec2 p){ return 0.1 + 0.18 * base(p) + 0.06 * fold(p); }`, 3), R.h);
    });

    // dark hollow under the capsule and hoses
    R.flat(sm([[440, 440], [520, 470], [600, 470], [736, 470], [736, 540], [640, 530], [560, 520], [470, 520], [436, 490]]), '#25292c', 0.04, 2);
    // ── black spotted bead, blue capsule ──
    R.dome(ellipseP(540, 320, 92, 74, -0.2), '#0c0c10', 0.12, 0.22, 46, 6);
    const dg = rng(152);
    for (const [x, y, r] of [[515, 292, 9], [538, 282, 10], [562, 288, 11], [522, 312, 8], [548, 306, 12], [576, 302, 9], [536, 322, 7], [500, 302, 7]])
      R.flat(ellipseP(x, y, r * 1.2, r * 0.9, 0), '#e6e45a', 0.33 + dg() * 0.0, 5);
    R.bead(497, 357, 9, '#36a8f0', 0.3, 0.05, 6);
    R.dome(ellipseP(525, 428, 74, 54, -0.1), lin(470, 380, 560, 480, [[0, '#5a94a4'], [0.4, '#2e5662'], [1, '#14242a']]), 0.1, 0.2, 40, 6);
    // ribbed hoses
    for (let i = 0; i < 9; i++) R.pipe(ellipseP(604 + i * 14, 438, 6, 28, 0), 9, '#8e9296', 0.16, 0.08, 3);
    R.dome(rrect(596, 412, 140, 54, 20), '#8a8e92', 0.1, 0.1, 18, 3);
    for (let i = 0; i < 9; i++) R.pipe(line([[612 + i * 14, 412], [612 + i * 14, 466]]), 6, '#a0a4a8', 0.2, 0.04, 3);
    for (let i = 0; i < 5; i++) R.pipe(ellipseP(596, 380 + i * 22, 14, 6, 0), 6, '#a0a4a8', 0.16, 0.06, 3);
    R.pipe(line([[640, 490], [668, 520], [668, 580]]), 64, '#9a9ea2', 0.08, 0.16, 3);
    for (let i = 0; i < 4; i++) R.pipe(ellipseP(652 + i * 4, 490 + i * 12, 34, 8, 0.2), 6, '#a8acb0', 0.18, 0.05, 3);
    R.bead(665, 596, 34, '#9a9ea2', 0.1, 0.16, 3);
    R.bead(665, 580, 6, '#f08060', 0.28, 0.02, 1);
    // grey worms on the puddle
    for (const w of [[[452, 540], [500, 552], [556, 560]], [[420, 580], [450, 576], [474, 586]], [[540, 590], [580, 588], [628, 584]], [[530, 528], [570, 530], [618, 532]]])
      R.pipe(line(w), 14, '#9a9a9e', 0.08, 0.06, 3);
    // small beads
    for (const [x, y, r, c, m] of [[372, 647, 22, '#0a0a0c', 6], [350, 710, 10, '#9aa0a2', 3], [372, 742, 11, '#2a2020', 7], [370, 770, 7, '#9aa0a2', 3], [465, 675, 9, '#9aa0a2', 3],
      [165, 582, 15, '#9a9a9e', 3], [452, 508, 6, '#c0c0c4', 7], [530, 605, 6, '#9aa0a2', 3], [283, 787, 5, '#9aa0a2', 3]]) R.bead(x, y, r, c, 0.07, Math.min(0.14, r * 0.006 + 0.03), m);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.15, shin: 20, wrap: 0.5, ao: 0.4, coat: 0.0 }),                   // 1 clay
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.4, grain: 0.1, coat: 0.06 }),      // 2 teal puddle
        E.mat({ dif: 1, spec: 0.4, shin: 26, wrap: 0.4, ao: 0.5, grain: 0.06, coat: 0.08 }),      // 3 grey clay
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.5, ao: 0.4, coat: 0.1 }),                   // 4 zebra
        E.mat({ dif: 1, spec: 0.1, shin: 20, wrap: 0.6, ao: 0.2, emis: 0.2 }),                   // 5 yellow spots / olive
        E.mat({ dif: 1, spec: 1, shin: 80, wrap: 0.4, ao: 0.3, coat: 0.3 }),                     // 6 gloss
        E.mat({ dif: 0.85, spec: 1, shin: 60, metal: 0.35, wrap: 0.3, ao: 0.3, coat: 0.25 }),    // 7 chrome
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.61, 0.61, 0.61], amb: [0.47, 0.47, 0.47],
      envTop: [0.95, 0.95, 0.95], envHor: [0.62, 0.62, 0.63], envBot: [0.1, 0.1, 0.1], envK: [0.4, 0.8, 0, 0],
      r1: 3, r2: 8, k: [0, 0.6, 0.4, 120], shadow: [-5, 7, 0.6, 9]
    });
    E.grain(0.02, 152);
  }
});
