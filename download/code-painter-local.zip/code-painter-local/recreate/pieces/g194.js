'use strict';
// g194 — "Enamel spiral slab": a grey glassy slab on violet, embossed with white enamel tubes, spirals, a gold ring
// with a copper button and a white lozenge in a black glossy rim, beside a big zebra spiral on a sandy gold plate.
REC.register('g194', {
  w: 1024, h: 726,
  draw(E) {
    const W = 1024, H = 726, R = E.relief(), a = R.a, S = E.S, o = E.out;
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, st, c = a) => { const g = c.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, k]) => g.addColorStop(t, k)); return g; };
    const rad = (x, y, r, st, x0 = x, y0 = y, c = a) => { const g = c.createRadialGradient(x0, y0, 0, x, y, r); st.forEach(([t, k]) => g.addColorStop(t, k)); return g; };
    const ring = (cx, cy, r0, r1) => { const p = new Path2D(); p.arc(cx, cy, r1, 0, 6.2832); p.moveTo(cx + r0, cy); p.arc(cx, cy, r0, 0, 6.2832, true); return p; };
    const soft = (ctx, blur, fn) => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x); ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore(); };
    // offset a centreline sideways (for parallel tubes)
    const offs = (cl, d) => cl.map((p, i) => { const q = cl[Math.max(0, i - 1)], s = cl[Math.min(cl.length - 1, i + 1)], dx = s[0] - q[0], dy = s[1] - q[1], L = Math.hypot(dx, dy) || 1; return [p[0] - dy / L * d, p[1] + dx / L * d]; });
    // raised white spiral ridge: arms × Archimedean spiral of pitch P (per arm) from r0 to r1
    const spiral = (cx, cy, P_, arms, dir, ph, r0, r1, wd, e = 1) => {
      for (let k = 0; k < arms; k++) {
        const pts = [];
        for (let t = 0; ; t += 0.06) { const r = r0 + P_ * arms * t / 6.2832 + k * P_; if (r > r1) break; const th = dir * t + ph; pts.push([cx + Math.cos(th) * r, cy + Math.sin(th) * r / e]); }
        R.pipe(line(pts), wd, '#ece8e6', 0.2, 0.06, 2);
      }
    };

    // ── backdrop: violet board, olive-grey right, film edges ──
    R.flat(rrect(-5, -5, W + 10, H + 10, 0), lin(0, 0, 300, 726, [[0, '#6560d4'], [1, '#524ec8']]), 0, 0);
    const olive = sm([[900, -5], [1030, -5], [1030, 730], [886, 730], [894, 635], [867, 569], [839, 555], [824, 477], [886, 470], [927, 446], [905, 380], [905, 100]]);
    R.flat(olive, '#3e4840', 0, 0);
    R.flat(poly([[360, 690], [400, 672], [660, 668], [690, 730], [360, 730]]), '#3d463e', 0, 0);
    R.flat(rrect(-5, -5, 14, H + 10, 0), '#151320', 0, 0);
    R.flat(rrect(1013, -5, 20, H + 10, 0), '#121010', 0, 0);

    // ── the slab ──
    const slab = sm([[330, 620], [307, 666], [285, 681], [172, 680], [155, 672], [144, 657], [125, 583], [124, 554], [156, 486], [164, 413], [184, 387], [235, 374], [250, 363], [280, 288], [336, 234], [388, 211], [405, 197], [420, 165], [445, 61], [466, 40], [490, 34], [513, 42], [583, 98], [620, 155], [636, 240], [654, 254], [690, 262], [760, 262], [800, 330], [880, 340], [930, 370], [935, 430], [900, 465], [835, 470], [824, 500], [836, 560], [800, 615], [740, 650], [680, 662], [600, 656], [520, 652], [450, 654], [400, 676], [372, 690]]);
    R.dome(slab, lin(150, 100, 800, 650, [[0, '#7e7e88'], [0.5, '#888894'], [1, '#9292a0']]), 0.04, 0.08, 18, 1);
    clipA(slab, () => { a.lineWidth = 30; a.strokeStyle = 'rgba(140,180,196,0.45)'; a.stroke(slab); a.lineWidth = 3; a.strokeStyle = 'rgba(240,230,170,0.7)'; a.stroke(slab); });
    // dark smears cast on the slab
    clipA(slab, () => { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.fillStyle = '#0c0a10'; x.fill(ellipseP(350, 466, 48, 34, 0.3)); x.fill(ellipseP(640, 366, 40, 12, -0.2)); x.fill(ellipseP(420, 590, 40, 10, 0.3)); a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.filter = `blur(${8 * S}px)`; a.drawImage(c, 0, 0); a.restore(); });
    // bubbles on the slab's crest
    for (const [x, y, r] of [[466, 64, 14], [488, 58, 12], [478, 80, 11], [500, 76, 9], [458, 82, 8]]) R.bead(x, y, r, '#b8dcdc', 0.12, 0.06, 6);

    // ── sandy gold plate + the big zebra spiral ──
    const plate = sm([[618, -5], [905, -5], [905, 60], [935, 95], [950, 150], [960, 250], [958, 330], [930, 385], [880, 350], [760, 262], [700, 240], [690, 150], [680, 115], [655, 105], [625, 82], [612, 45]]);
    R.dome(plate, lin(620, 0, 960, 380, [[0, '#b89c66'], [0.6, '#a08454'], [1, '#8a7044']]), 0.06, 0.06, 6, 3);
    clipA(plate, () => R.paint(rrect(615, -5, 295, 92, 0), '#5c4c32'));
    for (let x = 640; x < 900; x += 27) R.pipe(line([[x, -5], [x + 2, 70 + ((x * 7) % 23)]]), 13, '#d8bc80', 0.12, 0.06, 3);
    R.flat(circleP(822, 207, 142), '#2c2426', 0.12, 4);
    spiral(825, 206, 14.7, 2, -1, 0.4, 4, 140, 10.5);

    // ── white enamel tubes ──
    const cl = [[200, 528], [218, 476], [242, 424], [266, 382], [290, 334], [320, 294], [360, 270], [410, 260], [455, 254], [488, 240]];
    for (const d of [-26, -9, 8, 25]) R.pipe(line(offs(cl, d)), 11, '#eceae8', 0.12, 0.1, 2);
    R.pipe(line([[466, 252], [494, 232], [502, 204], [482, 172], [474, 138], [490, 112], [518, 106], [544, 124]]), 18, '#eceae8', 0.12, 0.12, 2);
    R.pipe(line([[300, 600], [300, 560], [262, 520], [244, 524]]), 10, '#eceae8', 0.12, 0.08, 2);
    // spirals
    R.flat(circleP(424, 345, 50), '#4a4a58', 0.08, 1);
    spiral(424, 345, 11.8, 1, -1, 0.2, 3, 48, 6.5, 1.15);
    R.flat(circleP(220, 577, 68), '#4a4a58', 0.08, 1);
    spiral(220, 577, 10.2, 1, 1, 2.5, 3, 66, 6, 1.04);

    // ── gold ring with a copper button ──
    R.dome(ring(533, 312, 46, 61), lin(480, 260, 590, 370, [[0, '#f0c050'], [0.5, '#b08020'], [1, '#e8b840']]), 0.16, 0.12, 7, 5);
    R.dome(ring(533, 312, 35, 47), '#1a1414', 0.14, 0.1, 5, 3);
    R.dome(circleP(533, 310, 36), '#c08a72', 0.18, 0.08, 5, 6);
    R.flat(circleP(533, 310, 28), '#b0705c', 0.25, 6);

    // ── the white lozenge in its black glossy rim ──
    R.dome(ellipseP(516, 488, 142, 99, -0.03), '#121218', 0.08, 0.14, 12, 3);
    R.dome(ellipseP(514, 486, 126, 86, -0.03), lin(400, 400, 640, 580, [[0, '#ececf2'], [1, '#c8c8d2']]), 0.12, 0.14, 26, 7);
    R.groove(line([[392, 470], [450, 456], [520, 452], [600, 446], [640, 440]]), 4, '#606070', 0.26, 0.06, 7);
    R.pipe(line([[520, 372], [522, 420], [527, 500], [531, 568]]), 12, '#d0d0da', 0.26, 0.08, 7);
    R.bead(522, 428, 9, '#d8d8e0', 0.3, 0.06, 7);
    for (const [x, y] of [[462, 497], [496, 495], [482, 532], [574, 491], [580, 470], [600, 518], [478, 455]]) R.groove(circleP(x, y, 2), 4, '#202028', 0.28, 0.08, 7);
    // black glossy capsules
    for (const pts of [[[322, 492], [322, 552]], [[668, 362], [702, 410]], [[636, 384], [650, 420], [652, 450]], [[364, 494], [380, 540], [420, 570]]]) R.pipe(line(pts), 16, '#121216', 0.14, 0.12, 3);

    // ── donut, beads ──
    R.dome(ring(735, 550, 30, 55), '#d0d0de', 0.08, 0.14, 14, 1);
    R.flat(circleP(735, 550, 30), '#5a5a6c', 0.06, 1);
    for (const [x, y, r] of [[205, 430, 12], [195, 495, 12], [410, 262, 10], [445, 405, 12], [548, 176, 13], [575, 182, 6], [665, 112, 12], [882, 58, 9], [375, 325, 6], [588, 300, 4], [612, 418, 4], [676, 302, 5], [633, 220, 4]]) R.bead(x, y, r, '#f0eeee', 0.16, 0.1, 7);
    R.groove(line([[690, 440], [700, 452], [712, 446], [720, 456]]), 3, '#8a8a9a', 0.12, 0.03, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 26, wrap: 0.3, ao: 0.6, grain: 0.12, coat: 0.08 }),                       // 1 grey slab
        E.mat({ dif: 1, spec: 0.9, shin: 45, wrap: 0.25, ao: 0.6, coat: 0.15, rim: 0.2 }),                        // 2 white enamel
        E.mat({ dif: 1, spec: 1.2, shin: 70, wrap: 0.1, coat: 0.4, ao: 0.3, rim: 0.4 }),                          // 3 black gloss
        E.mat({ dif: 1, spec: 0.35, shin: 14, wrap: 0.3, grain: 0.9, ao: 0.5, metal: 0.15 }),                                   // 4 sandy plate
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.1, shin: 50, ao: 0.4, tint: [1.1, 0.95, 0.6] }),                    // 5 gold
        E.mat({ dif: 1, spec: 0.7, shin: 30, wrap: 0.3, coat: 0.1 }),                                             // 6 copper button
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.35, ao: 0.6, coat: 0.12 })                                   // 7 lozenge
      ],
      light: [-0.55, 0.6, 0.6], lc: [0.72, 0.72, 0.76], amb: [0.42, 0.42, 0.48],
      envTop: [1.0, 1.0, 1.04], envHor: [0.45, 0.45, 0.6], envBot: [0.1, 0.1, 0.16], envK: [0.4, 1.0, 0.3, 0],
      rimC: [0.3, 0.32, 0.5], rimD: [0.3, 0.6, 0.3], r1: 2, r2: 10, k: [0, 0.6, 0.4, 100], shadow: [-9, 10, 0.6, 9]
    });

    // ── soft focus: blurred white pebbles, orange glow, glassy ghost spiral ──
    soft(o, 7, x => { x.fillStyle = '#e6e6ea'; x.fill(ellipseP(266, 222, 66, 76, 0)); x.fill(circleP(381, 163, 20)); x.fillStyle = '#c8c8e0'; for (const [cx, cy, r] of [[185, 290, 8], [238, 333, 11], [218, 355, 7]]) x.fill(circleP(cx, cy, r)); });
    soft(o, 12, x => { x.fillStyle = '#f4b23e'; x.fill(sm([[996, 0], [1013, 0], [1013, 180], [990, 240], [965, 300], [938, 360], [906, 362], [926, 300], [950, 220], [972, 130]])); });
    soft(o, 10, x => { x.fillStyle = 'rgba(176,132,62,0.95)'; x.fill(sm([[864, 593], [833, 568], [804, 616], [772, 645], [735, 655], [691, 655], [660, 680], [654, 730], [883, 730], [870, 660]])); });
    soft(o, 14, x => { x.fillStyle = 'rgba(190,196,236,0.35)'; x.fill(ellipseP(850, 392, 92, 70, 0)); x.fill(sm([[700, 260], [780, 255], [830, 330], [900, 340], [940, 400], [930, 460], [860, 470], [800, 440], [740, 360]])); x.strokeStyle = 'rgba(235,235,250,0.4)'; x.lineWidth = 5; for (let r = 30; r < 90; r += 13) x.stroke(ellipseP(850, 392, r, r * 0.75, 0)); });
    soft(o, 3, x => { x.strokeStyle = 'rgba(200,220,255,0.45)'; x.lineWidth = 4; x.stroke(sm([[380, 690], [450, 656], [600, 656], [740, 650], [800, 615], [836, 560], [824, 500], [835, 470], [900, 465], [935, 430]])); });
    E.grain(0.04, 194);
  }
});
