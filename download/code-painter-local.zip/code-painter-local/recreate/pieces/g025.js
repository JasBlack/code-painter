'use strict';
// g025 — "Robot at the cassette deck": a comic-ink scene — a mesh-faced robot and a zebra-swirl figure
// at a tape deck, rainbow tentacles and grey boulders bursting through a glitch-streaked window onto a park.
REC.register('g025', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const drawCv = (cv, alpha = 1) => { o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.drawImage(cv, 0, 0); o.restore(); };
    // draw a full-canvas pattern masked by whatever fn paints (strokes allowed)
    const masked = (cv, fn) => {
      const m = E.newCanvas(), x = m.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      const c2 = E.newCanvas(), y = c2.getContext('2d'); y.drawImage(cv, 0, 0); y.globalCompositeOperation = 'destination-in'; y.drawImage(m, 0, 0);
      drawCv(c2);
    };
    const INK = '#0a0a0e', ROCK = '#837b95';

    // ── black frame + glitch streaks ──
    fill(rrect(-10, -10, 746, 1044, 0), '#050507');
    const streak = E.fx(`vec3 pal(float t){ t = fract(t);
        vec3 c = t < .14 ? vec3(.95,.25,.3) : t < .28 ? vec3(.98,.6,.2) : t < .42 ? vec3(.95,.9,.3) : t < .56 ? vec3(.4,.85,.5) : t < .7 ? vec3(.3,.55,.95) : t < .84 ? vec3(.65,.4,.9) : vec3(.9,.9,.92);
        return c; }
      vec3 fx(vec2 uv, vec2 p){
        float row = floor(p.y / 2.6 + 0.6 * sin(p.x * 0.01));
        float h = hash(vec2(row, 3.)), on = step(0.35, hash(vec2(row, floor(p.x / (40. + 80. * h)))));
        vec3 c = pal(h * 1.7 + floor(p.x / 120.) * 0.13) * (0.55 + 0.45 * hash(vec2(row, 7.)));
        return mix(vec3(0.03), c, on); }`);
    masked(streak, x => {
      x.fillStyle = '#fff';
      x.fill(rrect(0, 0, 22, 1024, 0)); x.fill(rrect(660, 40, 66, 960, 0)); x.fill(P([[0, 0], [240, 0], [260, 50], [20, 30], [0, 40]], true, false));
      x.fill(P([[0, 690], [40, 700], [60, 960], [0, 960]], true, false)); x.fill(P([[520, 30], [560, 20], [600, 0], [726, 0], [726, 50], [560, 50]], true, false));
      x.fill(P([[0, 180], [40, 180], [40, 470], [0, 470]], true, false));
    });

    // ── window onto a park ──
    const win = P([[22, 30], [120, 40], [250, 50], [400, 40], [560, 40], [672, 70], [676, 470], [560, 520], [100, 520], [22, 470]], true, false);
    clipped(win, () => {
      fill(win, lin(0, 30, 0, 260, [[0, '#1a62f0'], [0.55, '#2a78f6'], [1, '#90bef2']]));
      // clouds: pale cyan heads with grey-blue undersides, massed on the left
      const cr = rng(11);
      for (let i = 0; i < 18; i++) { const x = 40 + cr() * 180, y = 70 + cr() * 120; fill(ellipseP(x, y + 8, 24 + cr() * 26, 14 + cr() * 12, 0), '#8a94b8'); }
      for (let i = 0; i < 22; i++) { const x = 40 + cr() * 190, y = 50 + cr() * 120; fill(ellipseP(x, y, 18 + cr() * 24, 12 + cr() * 14, 0), cr() < 0.6 ? '#cfe6fb' : '#a8dcf8'); }
      for (let i = 0; i < 6; i++) fill(ellipseP(250 + cr() * 110, 170 + cr() * 30, 16 + cr() * 16, 8 + cr() * 8, 0), '#d8e6f8');
      // blue glitch columns behind the building
      for (let i = 0; i < 30; i++) { const x = 370 + i * 6.5; fill(rrect(x, 40, 3 + cr() * 3, 130 + cr() * 60, 0), cr() < 0.5 ? '#2a5ad8' : '#4a7ae8'); }
      // buildings
      fill(rrect(445, 75, 100, 135, 0), '#f2c49c'); stroke(rrect(445, 75, 100, 135, 0), INK, 2);
      for (let y = 90; y < 200; y += 16) for (let x = 455; x < 540; x += 18) fill(rrect(x, y, 9, 8, 1), '#5a4a5a');
      fill(rrect(330, 150, 120, 90, 0), '#b8b4b4'); stroke(rrect(330, 150, 120, 90, 0), INK, 2);
      for (let y = 160; y < 230; y += 14) stroke(P([[334, y], [446, y]], false), '#6a6870', 1.5);
      fill(rrect(560, 160, 30, 60, 0), '#d8d0c8');
      // tree line
      const tr = rng(12), trees = new Path2D();
      for (let x = 15; x < 690; x += 8) { const hgt = 40 + tr() * 50, base = x < 340 ? 255 : 262; trees.moveTo(x - 7, base); trees.lineTo(x, base - hgt); trees.lineTo(x + 7, base); trees.closePath(); }
      trees.addPath(rrect(15, 215, 680, 50, 0));
      fill(trees, '#2a5a3a');
      fill(P([[50, 250], [70, 225], [96, 238], [100, 262], [56, 262]], true, true), '#e05a20');
      for (const [x, y] of [[120, 225], [200, 225]]) { fill(rrect(x, y, 34, 22, 1), '#d8d4cc'); stroke(rrect(x, y, 34, 22, 1), INK, 1.5); }
      // grass and paths
      fill(P([[15, 262], [200, 255], [340, 262], [340, 520], [15, 520]], true, false), '#c6d258');
      fill(P([[560, 262], [690, 262], [690, 312], [560, 312]], true, false), '#b8c860');
      const gr = rng(13); for (let i = 0; i < 400; i++) { const x = 15 + gr() * 325, y = 262 + gr() * 250; stroke(P([[x, y], [x + (gr() - 0.5) * 3, y - 4 - gr() * 4]], false), gr() < 0.5 ? '#8a9a38' : '#e0e888', 1); }
      const path = P([[250, 262], [200, 280], [175, 300], [170, 330], [190, 360], [240, 380], [290, 390], [300, 370], [240, 355], [205, 330], [210, 300], [260, 272]], true, true);
      fill(path, '#b4b0b8'); stroke(path, INK, 1.5);
      fill(P([[15, 340], [80, 360], [150, 400], [150, 520], [15, 520]], true, false), '#9a96a0');
      for (let y = 360; y < 520; y += 14) stroke(P([[15, y], [150, y + 30]], false), '#6a6672', 1.2);
      // river
      fill(P([[560, 312], [690, 305], [690, 470], [560, 470]], true, false), '#4a86d8');
      for (let i = 0; i < 40; i++) { const x = 560 + gr() * 120, y = 315 + gr() * 150; stroke(P([[x, y], [x + 10 + gr() * 14, y]], false), gr() < 0.5 ? '#c8e0f8' : '#2a5aa8', 1.6); }
      // tiny people
      const man = (x, y, k, c) => { fill(ellipseP(x, y - 50 * k, 6 * k, 7 * k, 0), '#e0b090'); fill(P([[x - 9 * k, y - 42 * k], [x + 9 * k, y - 42 * k], [x + 8 * k, y - 10 * k], [x + 6 * k, y + 10 * k], [x - 6 * k, y + 10 * k], [x - 8 * k, y - 10 * k]], true, false), c); stroke(P([[x - 9 * k, y - 42 * k], [x + 9 * k, y - 42 * k], [x + 6 * k, y + 10 * k], [x - 6 * k, y + 10 * k]], true, false), INK, 1.2); };
      man(97, 325, 1.15, '#3a4a7a'); man(137, 340, 0.75, '#4a5a7a'); man(35, 345, 1, '#2a3a5a'); man(195, 272, 0.3, '#6a4a2a');
      // dark rocks in the grass
      for (const [x, y, rx, ry] of [[205, 210, 22, 18], [178, 350, 28, 22], [130, 300, 10, 6], [240, 295, 12, 6], [280, 320, 14, 6]]) { const b = P(blob(x, y, rx, ry, x + y, 10, 0.2)); fill(b, '#5a5866'); stroke(b, INK, 1.5); }
    });
    stroke(win, INK, 3);

    // ── falling man in a yellow jacket ──
    { const SKN = '#e8b088';
      stroke(P([[277, 165], [277, 255]], false), '#5a6070', 4);
      const arm = P([[250, 80], [220, 95], [193, 110], [173, 127], [166, 140], [177, 145], [200, 132], [227, 122], [250, 117], [264, 110]], true, true);
      fill(arm, '#7a8a2a'); stroke(arm, INK, 2);
      const hl = P([[168, 138], [178, 146], [174, 162], [164, 170], [155, 160], [158, 146]], true, true); fill(hl, SKN); stroke(hl, INK, 1.5);
      const body = P([[257, 80], [297, 80], [307, 90], [327, 110], [343, 133], [356, 158], [342, 162], [327, 140], [300, 122], [297, 153], [302, 167], [287, 166], [273, 143], [263, 117]], true, true);
      fill(body, '#e2c020'); stroke(body, INK, 2);
      clipped(body, () => { for (const pp of [[[270, 90], [285, 120], [282, 150]], [[300, 95], [320, 118], [345, 150]]]) stroke(P(pp, false), '#5a4a10', 4); });
      const hr = P([[288, 166], [304, 168], [318, 182], [322, 198], [312, 196], [300, 186], [290, 180]], true, true); fill(hr, SKN); stroke(hr, INK, 1.5);
      const hr2 = P([[344, 158], [356, 160], [362, 172], [352, 175]], true, true); fill(hr2, SKN); stroke(hr2, INK, 1.2);
      fill(ellipseP(318, 95, 14, 17, 0.2), SKN); stroke(ellipseP(318, 95, 14, 17, 0.2), INK, 1.5);
      fill(P([[304, 86], [314, 76], [328, 78], [332, 90], [318, 86]], true, true), '#d8a040');
      stroke(P([[307, 195], [316, 215], [327, 235]], false), 'rgba(160,140,230,0.8)', 7); stroke(P([[309, 195], [318, 215], [329, 235]], false), 'rgba(240,200,120,0.8)', 2.5); }
    // striped tumbling figure top right
    { const b = P([[540, 120], [600, 110], [630, 140], [620, 170], [580, 180], [560, 160]], true, true); fill(b, '#f2f2f4');
      clipped(b, () => { for (let k = 0; k < 10; k++) stroke(P([[540, 110 + k * 8], [640, 100 + k * 10]], false), INK, 3.5); }); stroke(b, INK, 2);
      fill(P([[556, 160], [590, 176], [600, 200], [580, 200], [560, 184]], true, true), '#5a6aa8'); }

    // ── zebra-swirl figure ──
    const zeb = P([[300, 248], [330, 232], [365, 236], [384, 262], [388, 300], [396, 340], [422, 380], [432, 450], [432, 560], [430, 700], [380, 712], [300, 714], [200, 700], [140, 660], [90, 600], [64, 560], [78, 500], [120, 440], [180, 392], [250, 360], [300, 340], [304, 300]], true, true);
    // zebra stripes: angle / period / phase fitted per tile (numbers measured offline)
    const zcv = E.fx(`const vec2 ZC[60] = vec2[60](vec2(289., 257.), vec2(339., 257.), vec2(289., 307.), vec2(339., 307.), vec2(389., 307.), vec2(189., 357.), vec2(239., 357.), vec2(289., 357.), vec2(339., 357.), vec2(389., 357.), vec2(139., 407.), vec2(189., 407.), vec2(239., 407.), vec2(289., 407.), vec2(339., 407.), vec2(389., 407.), vec2(439., 407.), vec2(89., 457.), vec2(139., 457.), vec2(189., 457.), vec2(239., 457.), vec2(289., 457.), vec2(339., 457.), vec2(389., 457.), vec2(439., 457.), vec2(89., 507.), vec2(139., 507.), vec2(189., 507.), vec2(239., 507.), vec2(289., 507.), vec2(339., 507.), vec2(389., 507.), vec2(439., 507.), vec2(89., 557.), vec2(139., 557.), vec2(189., 557.), vec2(239., 557.), vec2(289., 557.), vec2(339., 557.), vec2(389., 557.), vec2(439., 557.), vec2(89., 607.), vec2(139., 607.), vec2(189., 607.), vec2(239., 607.), vec2(289., 607.), vec2(339., 607.), vec2(389., 607.), vec2(439., 607.), vec2(139., 657.), vec2(189., 657.), vec2(239., 657.), vec2(289., 657.), vec2(339., 657.), vec2(389., 657.), vec2(189., 707.), vec2(239., 707.), vec2(289., 707.), vec2(339., 707.), vec2(389., 707.));
const float ZK[360] = float[360](-1.0205, -4.2409, -1.1364, -2.5961, 6.4369, 3.4328, 1.1443, -8.0121, 1.0893, -5.8672, 1.2629, 1.7850, 1.9894, -7.8311, 1.0328, 11.6801, 7.4247, 0.5187, 8.1172, 1.6461, 3.6763, 1.9428, -0.2096, -2.2066, 6.2680, 2.2250, 2.8957, -0.1226, -1.7482, -1.9016, 3.2986, -4.8104, -13.2852, 1.7773, 6.5587, 15.3797, 5.2110, 0.1798, 11.1858, -2.8065, 1.1386, -14.7767, 1.3053, 1.6472, -3.1317, -1.9342, -1.4947, -0.4481, -30.6574, -1.0431, -2.8762, -0.8560, 2.9259, 0.2640, 6.3419, 1.2676, 1.5067, 0.2077, -2.4643, -1.3498, 2.2699, -1.4236, -4.0447, -1.2857, 0.7402, 1.1313, 0.6986, 2.7030, 1.3075, -3.1310, 1.0629, -0.2568, 5.5148, 1.0363, 1.8795, -1.1520, 1.4787, -0.6611, -8.5815, 0.5251, -3.3232, 0.5236, -3.5115, 1.1452, 2.3332, -0.5418, 3.5978, -1.1025, -1.8178, -0.1578, 6.1069, 0.1265, -1.9581, -1.4349, 3.5289, -2.2648, 3.2646, 2.7252, 1.1134, 7.6548, 0.8431, 0.0293, -12.0867, -4.2563, -2.4210, 2.3878, 0.0768, -0.8373, 0.5369, 1.5767, 2.9875, -2.5255, -0.2000, -1.1502, 1.6329, -2.2317, -2.0734, 0.2806, 1.3662, -0.6935, 4.3257, 1.4529, 1.7955, -0.4999, -0.0544, 0.3075, -1.0506, 0.6551, 2.0895, -1.0592, 1.3392, -0.7372, 1.0255, 0.7542, -2.6460, 1.6706, -0.9045, 0.8364, -6.3469, 0.9513, -2.9779, -0.7168, -0.5413, 0.4149, -1.1671, -5.8969, 0.9577, -0.6282, -4.7804, -1.1098, -5.4515, 4.4965, 3.1517, -4.3787, -2.9082, -1.3165, -0.2193, 1.3267, 2.1915, -1.6240, -0.1533, -0.7994, 0.0126, -0.2635, -2.4218, -0.1502, -0.7771, 0.0579, -0.6712, 1.0892, 2.2984, -0.2469, -1.2939, 0.4900, 1.8181, 0.9382, 1.9457, 0.0935, -0.2642, 0.4125, 1.1796, -0.2352, 2.2246, -2.0119, 0.9912, -0.2592, -7.3309, -1.2883, 2.2261, -0.1906, -0.7925, -0.5952, 1.0559, -4.2551, 3.8330, 2.4217, 5.9703, -0.3344, 2.6537, 2.9254, 1.3059, -3.0769, -2.0349, -1.4890, 0.5563, 1.5073, 0.9860, -0.5541, 1.1079, -1.3294, 1.1590, 0.9864, 1.8251, -0.3399, 2.0929, -1.3032, -0.4461, 0.7228, 2.2907, -0.5140, -0.3960, -0.2570, -1.1691, 0.8671, 2.1456, 0.9496, -0.1646, -0.0848, -0.6736, -0.4121, 1.9011, -3.9800, -0.9895, -0.2866, 6.1775, -3.0930, 1.5935, -0.5461, -0.1062, 0.0284, 6.4492, -4.2512, 2.1557, -1.3791, 1.2445, -1.3353, -4.8013, -4.0628, 1.6982, -1.8321, -3.7894, 5.2542, -59.2071, 1.6020, 0.1021, 0.4190, 0.5708, -0.8041, 7.7162, 1.6943, 0.3012, -0.1864, 0.5748, -1.5996, -0.5550, -0.9991, -0.6654, 1.1930, -0.8878, 3.0356, -0.1809, 0.4108, 1.5756, 1.2570, -1.8241, -1.0670, -8.5027, 2.4205, 1.5862, 1.9595, 2.2370, -2.0602, -5.3347, -4.1537, -0.9866, -0.7746, -3.8418, -4.5870, -4.4556, 4.5516, 3.1018, 0.4795, 3.0005, 5.5529, -5.3857, 1.1993, -1.2201, 1.7128, -0.5722, -2.0166, 9.5189, -1.5272, 1.3407, 0.5299, 1.0506, 1.6726, -1.1270, -1.0022, 1.9032, 0.7981, 1.0336, 1.5627, -32.3569, 1.6877, -0.3001, 1.4854, 3.2627, 1.6903, -0.0178, 4.0072, 1.4314, 3.7185, 4.1712, 0.7766, 6.7797, 5.8302, 2.7595, 0.1869, 1.7264, -0.8111, 5.1316, 0.8107, 0.9066, -1.5555, 3.3136, -0.7051, -0.0053, -0.7706, 0.1493, -1.2337, -0.1007, 3.4115, 0.9160, 2.5895, 0.6796, 0.8734, 0.0738, -0.4438, -5.4753, 4.8516, 0.0125, 3.8931, -0.1188, -2.1099, 0.6371, 6.6994, -0.2066, 0.0769, 2.0024, -3.9625);
float zv(vec2 p){ float s = 0., ws = 1e-30;
  for (int i = 0; i < 60; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.1513);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.96, .96, .95), vec3(.02), smoothstep(-.15, .15, zv(p))); }`);
    clipped(zeb, () => {
      drawCv(zcv);
      const sp = new Path2D(); for (let i = 0; i < 160; i++) { const t = i * 0.12, r = 2 + t * 4.5; const x = 360 + Math.cos(t) * r, y = 268 + Math.sin(t) * r * 0.95; if (i) sp.lineTo(x, y); else sp.moveTo(x, y); }
      o.save(); o.clip(ellipseP(352, 270, 36, 34, 0)); fill(ellipseP(352, 270, 36, 34, 0), '#f4f4f4'); stroke(sp, INK, 2.2); o.restore();
    });
    stroke(zeb, INK, 3.5);

    // ── the robot ──
    const mesh = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 4. * vec2(sin(p.y * 0.02), sin(p.x * 0.02));
      float a = abs(fract(q.x / 6.) - .5), b = abs(fract(q.y / 6.) - .5);
      float l = max(smoothstep(.28, .5, a), smoothstep(.28, .5, b));
      float sh = 0.86 + 0.14 * sin(p.x * 0.015 + 0.5) - 0.12 * smoothstep(300., 380., p.y) * (1. - smoothstep(380., 420., p.y));
      return mix(vec3(0.96, 0.96, 0.95) * sh, vec3(0.2, 0.2, 0.23), l * 0.9); }`);
    const body = P([[392, 400], [450, 392], [530, 396], [600, 420], [612, 500], [596, 560], [560, 600], [520, 720], [420, 720], [420, 560], [400, 470]], true, true);
    clipped(body, () => drawCv(mesh)); stroke(body, INK, 3);
    for (const [x0, y0, x1, y1] of [[470, 480, 500, 470], [520, 470, 560, 490], [480, 520, 510, 540]]) stroke(P([[x0, y0], [x1, y1]], false), INK, 2);
    fill(P([[560, 380], [600, 420], [610, 470], [590, 470], [570, 420]], true, true), '#3a4ab0');
    // head
    const head = P([[372, 210], [380, 200], [470, 196], [560, 210], [572, 260], [570, 330], [540, 370], [480, 384], [420, 380], [384, 350], [372, 300]], true, true);
    clipped(head, () => drawCv(mesh)); stroke(head, INK, 3);
    const helmet = P([[368, 236], [380, 190], [410, 160], [460, 142], [510, 150], [550, 180], [570, 230], [540, 222], [480, 214], [420, 216]], true, true);
    fill(helmet, lin(380, 140, 560, 240, [[0, '#ffffff'], [0.6, '#eceaee'], [1, '#c8c6cc']])); stroke(helmet, INK, 3);
    stroke(P([[420, 160], [460, 150], [510, 160]], false), INK, 1.5);
    fill(rrect(462, 128, 16, 18, 3), '#e8e4e4'); stroke(rrect(462, 128, 16, 18, 3), INK, 2);
    const fin = P([[470, 58], [482, 90], [486, 112], [470, 126], [456, 112], [460, 90]], true, true);
    fill(fin, lin(456, 60, 486, 126, [[0, '#ffffff'], [1, '#d8d4d8']])); stroke(fin, INK, 2);
    fill(ellipseP(556, 296, 12, 28, 0), '#f0f0f0'); stroke(ellipseP(556, 296, 12, 28, 0), INK, 2.5); fill(ellipseP(558, 296, 5, 16, 0), INK);
    for (const [x, y] of [[388, 234], [445, 240]]) { fill(circleP(x, y, 23), '#f8f8f8'); stroke(circleP(x, y, 23), INK, 3); fill(circleP(x + 4, y + 2, 9), INK); fill(circleP(x + 1, y - 2, 3), '#fff'); }
    stroke(P([[411, 236], [422, 238]], false), INK, 3);
    const nose = P([[402, 254], [442, 262], [428, 312], [410, 316]], true, true); fill(nose, '#5a5c6a'); stroke(nose, INK, 2.5);
    const mouth = rrect(380, 300, 106, 34, 6); fill(mouth, '#f6f6f6'); stroke(mouth, INK, 3);
    fill(rrect(396, 312, 80, 8, 2), INK); fill(circleP(388, 316, 3), INK); fill(circleP(478, 316, 3), INK);
    fill(P([[405, 330], [430, 330], [426, 346], [410, 346]], true, true), '#b84a5a');
    const collar = P([[398, 372], [530, 370], [536, 400], [400, 410]], true, false);
    fill(collar, '#a8a8b0'); stroke(collar, INK, 3);
    for (let x = 410; x < 530; x += 20) stroke(rrect(x, 380, 14, 18, 2), INK, 1.5);
    fill(P([[560, 380], [575, 360], [590, 420], [600, 470], [585, 470]], true, true), '#2a4ab8');

    // ── tape deck ──
    const deck = P([[300, 730], [470, 726], [480, 790], [300, 800]], true, false);
    fill(deck, '#3a3a40'); stroke(deck, INK, 2.5);
    for (const [x, y, w, h, c] of [[312, 740, 40, 22, '#e8e0d8'], [360, 742, 50, 20, '#c06048'], [418, 744, 44, 18, '#d8d0c8'], [320, 770, 60, 16, '#a85040'], [400, 770, 50, 14, '#f0e8e0']]) { fill(rrect(x, y, w, h, 2), c); stroke(rrect(x, y, w, h, 2), INK, 1.5); }

    // ── blue arm and hand ──
    fill(P([[517, 545], [570, 530], [610, 500], [632, 488], [636, 530], [615, 600], [570, 615], [540, 630], [525, 600]], true, true), '#2c2c78');
    const arm = P([[455, 525], [500, 530], [512, 555], [522, 590], [525, 620], [505, 645], [478, 680], [482, 730], [465, 756], [448, 742], [410, 732], [356, 742], [340, 726], [370, 700], [405, 670], [436, 640], [436, 590], [442, 550]], true, true);
    fill(arm, '#3f58b0'); stroke(arm, INK, 3);
    const hr = rng(21); clipped(arm, () => { for (let i = 0; i < 140; i++) fill(ellipseP(420 + hr() * 150, 520 + hr() * 240, 1 + hr() * 3, 1 + hr() * 2, hr() * 3), '#141a40'); });
    for (const f of [[[440, 700], [400, 720], [360, 738]], [[460, 720], [420, 742], [380, 758]], [[480, 730], [460, 752], [440, 770]]]) { stroke(P(f, false), INK, 14); stroke(P(f, false), '#4a5cb4', 10); }

    // ── rainbow floor ──
    // radial stripes from a vanishing point (650, 660); the colour of each 1/80-radian band is read off the reference
    const floor = E.fx(`const int FS[120] = int[120](6,6,6,6,6,6,4,4,4,4,2,2,2,2,2,1,1,1,1,1,1,1,2,1,1,6,6,0,0,0,0,0,0,0,0,0,0,0,0,0,0,6,6,0,2,1,4,0,0,0,0,0,0,2,2,2,1,1,1,2,2,2,2,5,5,2,0,0,0,0,0,0,0,0,0,2,2,3,3,3,4,4,4,4,2,2,1,1,1,1,1,3,0,3,1,1,1,1,4,1,1,2,2,3,3,0,0,0,0,0,2,5,0,6,6,6,6,1,1,4);
      const vec3 FP[7] = vec3[7](vec3(.96,.53,.75), vec3(.5,.93,.63), vec3(.23,.31,.88), vec3(.91,.93,.22), vec3(.89,.45,.09), vec3(.13,.82,.43), vec3(.05,.05,.07));
      vec3 fx(vec2 uv, vec2 p){ float v = atan(p.y - 660., p.x - 650.) * 80.;
        int i = clamp(int(floor(v)) - 104, 0, 119);
        return FP[FS[i]]; }`);
    masked(floor, x => { x.fillStyle = '#fff'; x.fill(P([[0, 900], [200, 880], [420, 872], [560, 880], [560, 1034], [0, 1034]], true, true)); x.fill(P([[640, 960], [726, 940], [726, 1034], [630, 1034]], true, false)); });

    // ── rainbow tentacles ──
    const rain = E.fx(`vec3 pal(float t){ t = fract(t); return t < .16 ? vec3(.92,.2,.22) : t < .32 ? vec3(.98,.55,.15) : t < .48 ? vec3(.98,.9,.25) : t < .64 ? vec3(.3,.8,.35) : t < .8 ? vec3(.2,.45,.95) : vec3(.55,.3,.85); }
      vec3 fx(vec2 uv, vec2 p){
        float v = (p.x + 30. * sin(p.y * 0.02) + 20. * fbm(p * 0.02)) / 7.5 + (p.y + 25. * sin(p.x * 0.025)) / 7.5 * step(800., p.y) * step(180., p.x);
        vec3 c = pal(v / 6.);
        float edge = abs(fract(v) - .5);
        return mix(c, vec3(0.05), smoothstep(0.42, 0.5, edge)); }`);
    const tent = [
      [[[110, 550], [120, 600], [130, 650], [120, 700], [90, 760], [60, 830], [40, 880], [60, 930]], 52],
      [[[130, 650], [170, 680], [200, 690]], 30],
      [[[392, 835], [340, 850], [290, 860], [240, 868], [215, 882], [205, 920], [200, 945]], 40],
      [[[212, 900], [186, 950], [172, 985]], 14], [[[222, 905], [214, 960], [210, 998]], 12], [[[232, 900], [244, 950], [256, 985]], 12],
      [[[515, 662], [545, 640], [580, 625], [610, 610], [645, 595]], 30], [[[440, 650], [472, 668]], 18],
      [[[585, 455], [600, 490], [625, 525], [642, 560]], 28], [[[650, 380], [668, 352]], 12]
    ];
    masked(rain, x => { x.strokeStyle = '#fff'; for (const [pts, wd] of tent) { x.lineWidth = wd; x.stroke(P(pts, false)); } });
    for (const [pts, wd] of tent) { o.save(); o.globalCompositeOperation = 'destination-over'; stroke(P(pts, false), INK, wd + 5); o.restore(); }

    // ── hands, sleeve, jar ──
    const coat = P([[60, 760], [140, 730], [210, 760], [240, 830], [230, 900], [150, 920], [70, 900]], true, true);
    fill(coat, '#26252c'); clipped(coat, () => { for (let i = 0; i < 40; i++) stroke(P([[60 + i * 5, 760], [80 + i * 5, 920]], false), '#5a5964', 1.2); }); stroke(coat, INK, 2);
    const sleeve = P([[130, 740], [180, 730], [220, 760], [232, 800], [200, 830], [150, 820], [130, 790]], true, true);
    fill(sleeve, '#d8803a'); stroke(sleeve, INK, 2.5); stroke(P([[150, 770], [200, 780]], false), '#8a4a1a', 2);
    const SK = '#ecbca4';
    const hand1 = P([[170, 680], [210, 662], [250, 656], [280, 662], [296, 690], [280, 696], [262, 684], [240, 690], [216, 700], [180, 704]], true, true);
    fill(hand1, SK); stroke(hand1, INK, 2.2); fill(rrect(178, 664, 14, 40, 3), INK);
    const hand2 = P([[200, 740], [230, 700], [260, 694], [290, 700], [306, 724], [300, 740], [280, 734], [272, 760], [240, 772], [210, 780]], true, true);
    fill(hand2, SK); stroke(hand2, INK, 2.2);
    for (const [x0, y0, x1, y1] of [[240, 706], [262, 704], [282, 708]].map(([x, y]) => [x, y, x + 6, y + 24])) stroke(P([[x0, y0], [x1, y1]], false), '#a86a5a', 1.5);
    const jar = P([[236, 762], [300, 760], [304, 840], [240, 846]], true, false);
    fill(jar, lin(236, 0, 304, 0, [[0, '#f2d8dc'], [0.5, '#fff4f6'], [1, '#e4c4ca']])); stroke(jar, INK, 2.5);
    fill(ellipseP(268, 762, 34, 10, 0), '#f8f0f0'); stroke(ellipseP(268, 762, 34, 10, 0), INK, 2.5);
    fill(rrect(244, 790, 54, 34, 6), '#38b868'); stroke(rrect(244, 790, 54, 34, 6), INK, 1.5);
    o.fillStyle = INK; o.font = 'bold 10px Arial'; o.textAlign = 'center'; o.fillText('ALARDS', 271, 804); o.fillText('BHOTE', 271, 816);

    // ── beads and flowers ──
    const br = rng(31);
    for (let i = 0; i < 90; i++) { const x = 595 + br() * 110, y = 740 + br() * 120; if (x > 660 && y < 830 && br() < 0.7) continue; fill(circleP(x, y, 6), '#40c8e8'); stroke(circleP(x, y, 6), INK, 1.2); fill(circleP(x - 2, y - 2, 1.8), '#e0f8ff'); }
    for (let i = 0; i < 16; i++) { const x = 660 + br() * 60, y = 744 + br() * 96; const c = br() < 0.6 ? '#e83a20' : '#f8d020'; for (let k = 0; k < 5; k++) { const t = k * 1.2566; fill(circleP(x + Math.cos(t) * 5, y + Math.sin(t) * 5, 4), c); } fill(circleP(x, y, 2.5), '#f8e060'); }

    // ── grey boulders ──
    const rock = (x, y, rx, ry, seed, rot = 0) => {
      const p = P(blob(x, y, rx, ry, seed, 11, 0.22, rot), true, true);
      fill(p, ROCK);
      clipped(p, () => { const r = rng(seed + 5); fill(P(blob(x - rx * 0.25, y - ry * 0.3, rx * 0.6, ry * 0.45, seed + 1, 8, 0.2)), 'rgba(170,164,186,0.5)');
        for (let k = 0; k < 3; k++) { const cx = x + (r() - 0.5) * rx, cy = y + (r() - 0.5) * ry; stroke(P([[cx, cy], [cx + (r() - 0.5) * 20, cy + r() * 14], [cx + (r() - 0.5) * 30, cy + r() * 20]], false), INK, 1.5); }
        stroke(p, 'rgba(40,36,56,0.6)', 10); });
      stroke(p, INK, 3);
    };
    const rocks = [   // positions / sizes measured from the reference's rock masses
      [287, 42, 46, 46, 5], [360, 30, 32, 36, 6], [437, 40, 54, 50, 7], [16, 6, 22, 14, 4],
      [80, 78, 30, 44, 1], [46, 165, 48, 54, 2], [207, 203, 14, 13, 3],
      [618, 62, 56, 44, 9], [670, 150, 38, 60, 10], [656, 230, 37, 60, 11], [610, 306, 18, 22, 12],
      [662, 450, 40, 58, 13], [703, 439, 15, 22, 14], [82, 420, 42, 33, 16],
      [28, 552, 36, 58, 17], [45, 648, 50, 60, 18], [57, 740, 18, 28, 19],
      [695, 594, 36, 44, 20], [668, 665, 60, 62, 21],
      [530, 718, 60, 43, 23], [487, 811, 100, 64, 24, -0.25], [592, 890, 110, 84, 25], [701, 931, 22, 20, 26]
    ];
    for (const r of rocks) rock(...r);

    E.grain(0.03, 25);
  }
});
