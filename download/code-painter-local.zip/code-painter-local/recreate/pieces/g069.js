'use strict';
// g069 — "Porcelain bubble menagerie": a lit display box of glossy white porcelain — a one-eyed
// antennaed blob, a V-eared bunny, noodle tentacles and heaps of bubbles — on a curving black-and-white
// zebra band under a starry black sky, with a black donut, a glass cup and a tufted cushion below.
REC.register('g069', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const himg = (path, cv) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const r = rng(69);
    const WH = '#eae9e7', RIM = '#e4e6c4';
    // porcelain blob with a pale rim line
    const por = (path, h0 = 0.2, dh = 0.18, wd = 30, alb = WH) => { R.dome(path, alb, h0, dh, wd, 1); a.save(); a.clip(path); a.lineWidth = 5; a.strokeStyle = RIM; a.stroke(path); a.restore(); };
    const ball = (x, y, rr, h0 = 0.22) => por(circleP(x, y, rr), h0, Math.min(0.3, rr * 0.006 + 0.08), rr * 0.95);
    const glass = (x, y, rr) => { R.dome(circleP(x, y, rr), '#b8bcc4', 0.3, 0.08, rr, 3); };
    const noodle = (pts, w, h0 = 0.3) => { R.pipe(P(pts, false), w + 3, RIM, h0, 0.04, 1); R.pipe(P(pts, false), w, WH, h0 + 0.01, w * 0.006 + 0.06, 1); };

    // ── black starry box + grey back wall ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#060506', 0, 0);
    clipA(rrect(0, 0, 660, 600, 0), () => { for (let i = 0; i < 260; i++) { a.globalAlpha = 0.3 + r() * 0.7; a.fillStyle = '#f4f2ee'; a.fill(circleP(r() * 660, r() * 520, 0.4 + r() * 1.3)); } a.globalAlpha = 1; });
    { a.strokeStyle = '#d8dae8'; a.lineWidth = 1.6; for (let k = 0; k < 6; k++) { const an = k * Math.PI / 3; a.beginPath(); a.moveTo(287, 100); a.lineTo(287 + Math.cos(an) * 16, 100 + Math.sin(an) * 16); a.stroke();
      for (const t of [0.5, 0.75]) { const bx = 287 + Math.cos(an) * 16 * t, by = 100 + Math.sin(an) * 16 * t; a.beginPath(); a.moveTo(bx, by); a.lineTo(bx + Math.cos(an + 0.8) * 5, by + Math.sin(an + 0.8) * 5); a.moveTo(bx, by); a.lineTo(bx + Math.cos(an - 0.8) * 5, by + Math.sin(an - 0.8) * 5); a.stroke(); } } }
    const wall = P([[120, 380], [450, 300], [460, 600], [120, 600]], true, false);
    R.flat(wall, '#b4b0b2', 0.02, 0);

    // ── zebra band: per-zone stripe fields (angle, period, phase) fitted by eye to the folds ──
    const ZB = `
      const vec4 ZL[4] = vec4[4](vec4(-63., 47.5, 0.879, 0.), vec4(-45., 42.5, -0.072, 0.), vec4(-57., 54., -1.331, 0.), vec4(-36., 43., 2.919, 0.));
      float zs(vec2 p){
        if (p.x < 160. && p.y < 430.) return cos(6.2832 * length(p - vec2(175., -25.)) / 21.5 + 1.76);
        if (p.y < 545. && p.x > 430.) return cos(6.2832 * length(p - vec2(270., 390.)) / 34. + 0.143);
        bool up = p.y + 14. * sin(p.x * 0.03) < 730.; bool lf = p.x + 16. * sin(p.y * 0.035) < 450.;
        vec4 Z = ZL[up ? (lf ? 0 : 1) : (lf ? 2 : 3)]; float th = radians(Z.x);
        float u = p.x * cos(th) + p.y * sin(th);
        return cos(6.2832 * u / Z.y - Z.z);
      }`;
    const zAlb = pat(E.fx(ZB + `vec3 fx(vec2 uv, vec2 p){ float s = zs(p);
      return mix(vec3(0.05, 0.045, 0.05), vec3(0.93, 0.92, 0.89), smoothstep(-0.15, 0.15, s)); }`));
    const zH = E.fx(ZB + `vec3 fx(vec2 uv, vec2 p){ float s = zs(p);
      float hv = 0.06 + 0.035 * smoothstep(-0.3, 0.6, s); float v = hv * 255., i = floor(v);
      return vec3(i / 255., 4. * 32. / 255., fract(v)); }`);
    const lobe = P([[-10, 84], [40, 74], [96, 80], [128, 104], [134, 150], [122, 220], [112, 290], [128, 350], [160, 400], [120, 420], [60, 410], [-10, 400]]);
    const band = P([[436, 60], [470, 30], [540, 16], [610, 18], [646, 40], [652, 120], [652, 880], [630, 920], [560, 936], [470, 932], [380, 920], [250, 880], [150, 830], [60, 780], [-10, 760],
      [-10, 520], [80, 540], [180, 560], [300, 590], [440, 560], [450, 400], [440, 260], [430, 150]], true, true);
    for (const pth of [band, lobe]) R.dome(pth, '#f4f2dc', 0.04, 0.05, 6, 4);
    const bandIn = P([[446, 70], [476, 40], [540, 28], [606, 30], [636, 50], [640, 120], [640, 876], [622, 908], [560, 922], [470, 918], [380, 906], [250, 866], [150, 818], [60, 768], [-10, 748],
      [-10, 532], [80, 552], [180, 572], [300, 602], [452, 572], [462, 400], [452, 260], [442, 150]], true, true);
    const lobeIn = P([[-10, 94], [40, 86], [92, 92], [118, 110], [122, 150], [110, 220], [100, 290], [116, 350], [140, 396], [110, 408], [60, 398], [-10, 390]]);
    for (const pth of [bandIn, lobeIn]) { R.flat(pth, zAlb, 0.06, 4); himg(pth, zH); }
    keep();

    // ── right frame: glowing white post + light strip on top ──
    R.flat(rrect(650, -10, 90, 1044, 0), '#8e8c94', 0.02, 0);
    R.pipe(P([[668, -10], [668, 940]], false), 26, '#f3f2dd', 0.1, 0.08, 6);
    R.pipe(P([[-10, 6], [668, 6]], false), 14, '#d8d2b8', 0.1, 0.05, 6);
    R.dome(P([[700, 0], [740, 0], [740, 60], [712, 40]]), '#cbc3a6', 0.1, 0.05, 10, 1);
    por(ellipseP(728, 390, 34, 70, 0), 0.2, 0.2, 30);
    R.flat(rrect(686, 640, 50, 300, 0), '#030303', 0.02, 0);

    // ── left lobe beads + bunny-ear wires ──
    for (const [x, y, rr] of [[80, 150, 13], [160, 228, 10], [148, 328, 14], [300, 156, 11], [420, 80, 11], [492, 42, 14], [580, 30, 13], [494, 84, 10], [610, 446, 14], [600, 524, 9]]) glass(x, y, rr);
    R.pipe(P([[20, 270], [40, 300], [56, 340]], false), 3, '#c8ccd4', 0.3, 0.04, 3);
    R.pipe(P([[60, 260], [80, 200], [90, 196], [82, 260], [70, 330]], false), 3, '#c8ccd4', 0.3, 0.04, 3);

    // ── antennaed blob (head) + tentacles ──
    noodle([[346, 136], [350, 170], [352, 206]], 14);
    noodle([[246, 196], [270, 184], [300, 186], [326, 206], [334, 230]], 14);
    const head = P([[290, 250], [320, 210], [372, 196], [420, 210], [460, 236], [474, 280], [462, 330], [420, 372], [360, 388], [314, 370], [292, 320]]);
    por(head, 0.2, 0.26, 50);
    R.groove(circleP(360, 256, 5), 6, '#3a3838', 0.4, 0.1, 1);
    por(ellipseP(240, 380, 84, 64, 0.2), 0.16, 0.16, 50);
    const tent = [[[300, 240], [250, 236], [200, 262], [176, 300], [180, 344]], [[300, 262], [256, 268], [222, 300], [212, 350], [222, 400]], [[306, 290], [270, 310], [250, 350], [250, 410], [262, 450]],
      [[320, 310], [292, 340], [280, 390], [292, 440]]];
    for (const t of tent) noodle(t, 16, 0.32);
    // creature arm reaching right
    noodle([[310, 410], [360, 430], [410, 460], [440, 488]], 34, 0.34);
    ball(300, 412, 34, 0.3);
    keep();

    // ── paddle + bunny on the right ──
    const paddle = P([[456, 330], [500, 300], [560, 296], [604, 316], [620, 360], [610, 420], [580, 470], [530, 500], [480, 494], [452, 450], [448, 390]]);
    R.dome(paddle, RIM, 0.12, 0.03, 4, 1); R.dome(paddle, '#d6d4d2', 0.13, 0.06, 18, 1);
    const bunny = P([[440, 520], [470, 486], [510, 478], [548, 492], [568, 530], [560, 580], [530, 612], [490, 618], [452, 596], [436, 560]]);
    por(bunny, 0.24, 0.2, 40);
    R.pipe(P([[512, 492], [490, 450], [486, 424], [500, 446], [518, 486]], false), 6, '#c8ccd4', 0.42, 0.05, 3);
    R.pipe(P([[524, 492], [548, 444], [566, 412], [560, 446], [534, 494]], false), 6, '#c8ccd4', 0.42, 0.05, 3);
    ball(410, 528, 20, 0.3);
    // arm entering from the right with a chrome ring
    noodle([[740, 540], [690, 560], [640, 580], [610, 600]], 52, 0.3);
    por(ellipseP(588, 628, 36, 40, 0.3), 0.3, 0.18, 30);
    R.pipe(circleP(552, 640, 16), 6, '#b8bcc8', 0.42, 0.05, 3);
    R.pipe(ellipseP(572, 566, 22, 12, 0), 6, '#b8bcc8', 0.42, 0.05, 3);
    ball(522, 704, 34, 0.26);
    keep();

    for (const [x, y, rr] of [[448, 160, 38], [506, 228, 38], [578, 176, 32]]) ball(x, y, rr, 0.24);
    // ── bubble heaps in the middle ──
    for (const [x, y, rr] of [[230, 520, 44], [312, 520, 52], [264, 612, 46], [230, 640, 64], [310, 576, 30], [120, 440, 50], [70, 470, 40], [160, 470, 38], [26, 590, 44], [20, 430, 46], [40, 520, 50], [60, 380, 36]]) ball(x, y, rr, 0.22);
    // left creature with a glass visor
    const lc = P([[60, 420], [110, 400], [170, 410], [200, 450], [190, 500], [150, 520], [90, 516], [60, 480]]);
    por(lc, 0.26, 0.18, 34);
    R.dome(ellipseP(150, 488, 34, 16, -0.05), '#c4c6cc', 0.4, 0.06, 10, 3);
    ball(90, 380, 30, 0.24);
    // big egg + bubbles lower right
    por(ellipseP(410, 668, 58, 70, 0.5), 0.24, 0.22, 46);
    ball(396, 806, 46, 0.24);
    ball(288, 808, 64, 0.2);
    // big blob lower left
    por(P([[-10, 600], [40, 590], [100, 600], [150, 640], [170, 700], [150, 760], [90, 780], [30, 770], [-10, 750]]), 0.2, 0.22, 60);
    // segmented limbs
    noodle([[-20, 830], [60, 800], [130, 790]], 72, 0.26);
    noodle([[90, 880], [150, 900], [170, 960]], 70, 0.24);
    noodle([[-20, 920], [60, 930]], 60, 0.24);
    for (const [pts, w] of [[[[0, 880], [40, 830], [100, 800], [150, 790]], 56], [[[150, 800], [190, 830], [210, 880], [210, 940]], 48], [[[30, 960], [20, 900]], 50]]) noodle(pts, w, 0.3);
    for (const [x, y, rr] of [[150, 796, 34], [205, 884, 28], [40, 850, 30]]) ball(x, y, rr, 0.34);
    R.pipe(circleP(196, 746, 22), 9, '#c0c4cc', 0.4, 0.06, 3); R.pipe(circleP(196, 746, 11), 5, '#a0a4ac', 0.4, 0.04, 3);
    keep();

    // ── cushion, donut, glass cup ──
    const cush = P([[-10, 936], [740, 936], [740, 1044], [-10, 1044]], true, false);
    R.flat(cush, '#d8d4d0', 0.1, 1);
    for (let i = 0; i < 6; i++) por(rrect(-60 + i * 170, 934, 176, 74, 30), 0.12, 0.1, 22, '#ece8e3');
    for (let i = 0; i < 6; i++) por(rrect(-140 + i * 170, 1004, 176, 60, 26), 0.12, 0.08, 18, '#e8e4df');
    const donut = new Path2D(); donut.addPath(ellipseP(346, 910, 104, 50, 0));
    R.dome(donut, '#1c1a1c', 0.3, 0.18, 34, 2);
    R.dome(ellipseP(346, 900, 48, 18, 0), '#2a2622', 0.3, 0.0, 2, 0);
    R.pipe(ellipseP(346, 904, 44, 14, 0), 4, '#fff8d8', 0.31, 0.0, 6);
    R.pipe(P([[250, 930], [300, 948], [346, 952], [396, 948], [442, 930]], false), 3, '#f0ecd0', 0.5, 0.02, 6);
    const cup = P([[470, 830], [540, 830], [548, 950], [478, 952]], true, false);
    R.pipe(cup, 4, '#c8ccd0', 0.4, 0.04, 3);
    R.pipe(P([[530, 840], [552, 806], [578, 796], [584, 830], [560, 880]], false), 4, '#c8ccd0', 0.4, 0.04, 3);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 1.3, shin: 90, wrap: 0.35, ao: 0.6, coat: 0.3, rim: 0.45 }),                      // 1 porcelain
        E.mat({ dif: 0.8, spec: 1.3, shin: 80, metal: 0.2, ao: 0.4, coat: 0.3, rim: 0.3 }),                        // 2 black gloss donut
        E.mat({ dif: 0.4, metal: 0.7, spec: 1.2, shin: 90, ao: 0.3, rim: 0.4 }),                                    // 3 glass / chrome
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.3, ao: 0.6, coat: 0.12, rim: 0.2 }),                           // 4 zebra band
        E.mat({}),
        E.mat({ dif: 0.6, emis: 0.55, spec: 0.5, shin: 30, wrap: 0.5 })                                              // 6 light strips
      ],
      light: [-0.4, 0.62, 0.68], lc: [0.85, 0.85, 0.83], amb: [0.27, 0.27, 0.28],
      envTop: [1.05, 1.05, 1.0], envHor: [0.55, 0.55, 0.52], envBot: [0.12, 0.12, 0.12], envK: [0.25, 1.3, 0.3, 0],
      rimC: [0.28, 0.3, 0.18], rimD: [0, 1, 0.2],
      r1: 3.5, r2: 10, k: [0, 0.6, 0.4, 150], shadow: [-5, 7, 0.65, 7]
    });
    // glow of the light strips
    { const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.strokeStyle = '#fffbe0'; x.lineCap = 'round';
      x.lineWidth = 12; x.beginPath(); x.moveTo(668, -10); x.lineTo(668, 930); x.stroke(); x.lineWidth = 8; x.beginPath(); x.moveTo(0, 6); x.lineTo(668, 6); x.stroke();
      E.draw(E.blur(c, 12), 0.7, 'screen'); }
    E.grain(0.025, 69);
  }
});
