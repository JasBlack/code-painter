'use strict';
// u023 — "Glass tray toy box": a rounded glass tray of glossy clay toys — a sand-coloured car with blue
// windows and an orange band, a zebra scarf, a pink coral hand, a gold filigree web on slate, a gold
// sponge, a red box, a green coral fan, teal pebbles and yellow balls, under a sky with orange glitter clouds.
REC.register('u023', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, clip) => { a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const Q = (pts, sm = true) => P(pts, true, sm);
    const line = (pts, wd, col) => { a.lineWidth = wd; a.strokeStyle = col; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, false, true)); };
    const dots = (path, n, seed, col, r0, r1) => clipA(path, () => { const r = rng(seed); a.fillStyle = col; for (let i = 0; i < n; i++) { a.beginPath(); a.arc(r() * 726, r() * 1024, r0 + r() * (r1 - r0), 0, 6.3); a.fill(); } });

    // ── outside the tray: blue sky top-left, black top-right, lavender speckled floor ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(0.25, 0.55, 0.85), vec3(0.62, 0.80, 0.80), smoothstep(0., 500., p.y));
      c = mix(c, vec3(0.83, 0.84, 0.66), smoothstep(200., 330., p.y) * smoothstep(520., 380., p.y));
      c = mix(c, vec3(0.40, 0.36, 0.38), smoothstep(450., 620., p.y));
      c = mix(c, vec3(0.02, 0.02, 0.04), smoothstep(450., 640., p.x) * smoothstep(400., 150., p.y));
      c = mix(c, vec3(0.84, 0.88, 0.9), smoothstep(60., 20., p.x) * smoothstep(610., 660., p.y) * smoothstep(780., 740., p.y));
      c = mix(c, vec3(0.68, 0.70, 0.76), smoothstep(670., 705., p.x) * smoothstep(720., 780., p.y));
      vec3 fl = vec3(0.52, 0.46, 0.62) * (0.85 + 0.3 * hash(floor(p / 1.5)));
      fl = mix(fl, vec3(0.92, 0.9, 0.95), step(0.985, hash(floor(p / 2.) + 7.)));
      c = mix(c, fl, smoothstep(690., 720., p.y));
      return c; }`));

    // ── the glass tray ──
    const trayPts = [[70, 22], [200, 8], [300, 18], [420, 36], [520, 22], [620, 26], [684, 56], [712, 120], [722, 250], [724, 400], [722, 560], [714, 700], [698, 820], [668, 900],
      [618, 960], [556, 996], [456, 1012], [330, 1006], [200, 992], [128, 960], [80, 900], [58, 820], [48, 720], [36, 640], [12, 560], [4, 450], [8, 300], [18, 150], [34, 70]];
    const tray = Q(trayPts);
    R.dome(tray, '#c4ccd2', 0.02, 0.06, 20, 3);
    const inner = Q(trayPts.map(([x, y]) => [363 + (x - 363) * 0.95, 512 + (y - 512) * 0.965]));
    // sky and clouds inside the top of the tray
    R.flat(inner, '#b6c8d8', 0.04, 0);
    soft(x => { for (const [cx, cy, rx, ry] of [[250, 120, 70, 40], [330, 160, 80, 30], [190, 170, 60, 26], [430, 140, 50, 30], [110, 40, 60, 20], [300, 60, 50, 22]]) fe(x, cx, cy, rx, ry, 0, '#f2f2f4'); }, 8, 0.95, inner);
    // purple corner + starry black
    const purp = Q([[480, 30], [620, 30], [680, 60], [700, 120], [706, 230], [700, 330], [600, 330], [560, 300], [520, 220], [470, 180], [470, 100]]);
    R.flat(purp, '#6052a8', 0.05, 1);
    R.flat(Q([[636, 226], [706, 196], [710, 330], [630, 320]]), '#0c0a10', 0.05, 0);
    dots(purp, 120, 3, '#14101c', 0.6, 2);
    R.pipe(P([[600, 90], [640, 110], [672, 150], [690, 200], [690, 240]], false), 7, '#e8641e', 0.1, 0.05, 2);
    // orange glitter blobs
    const orL = Q([[141, 62], [168, 75], [165, 112], [188, 116], [193, 132], [159, 143], [175, 168], [164, 184], [148, 210], [105, 214], [87, 209], [77, 177], [111, 142], [135, 118],
      [111, 99], [129, 92], [132, 62]]);
    const orL2 = Q([[60, 90], [100, 64], [140, 60], [150, 100], [120, 160], [80, 200], [50, 170], [44, 120]]);
    for (const p of [orL, orL2]) R.dome(p, '#e89236', 0.08, 0.06, 10, 4);
    const orT = Q([[484, 184], [460, 175], [462, 143], [456, 130], [463, 123], [458, 98], [478, 66], [483, 29], [431, 36], [404, 45], [351, 43], [353, 66], [329, 67], [312, 93],
      [316, 108], [337, 123], [370, 116], [376, 128], [394, 131], [396, 147], [426, 142], [440, 109], [447, 141], [438, 168], [467, 190]]);
    R.dome(orT, '#ea7a30', 0.08, 0.06, 10, 4);
    dots(orL, 180, 5, '#ffd870', 0.6, 2.2); dots(orL2, 90, 6, '#ffd870', 0.6, 2.2); dots(orT, 120, 7, '#f8c050', 0.6, 2);
    for (const [x, y, r] of [[340, 60, 6], [366, 100, 7], [404, 104, 7], [410, 160, 6], [432, 150, 6], [460, 158, 6], [388, 66, 6], [96, 58, 4]]) R.bead(x, y, r, '#141014', 0.12, 0.08, 5);
    // striped bees
    for (const [x, y] of [[490, 90], [530, 92]]) {
      const b = ellipseP(x, y, 22, 40, 0.5); R.dome(b, '#e8c838', 0.1, 0.14, 12, 5);
      clipA(b, () => { for (let k = -3; k <= 3; k++) line([[x - 30 + k * 10, y - 30 + k * 12], [x + 30 + k * 10, y - 4 + k * 12]], 5, '#141014'); });
    }
    R.flat(rrect(462, 150, 12, 14, 2), '#2a50c8', 0.1, 4);
    R.bead(583, 76, 8, '#e8641e', 0.1, 0.08, 5);

    // ── slate floor of the tray, starry black on the right ──
    const slate = Q([[50, 470], [130, 520], [280, 500], [440, 470], [600, 400], [700, 380], [712, 560], [704, 700], [688, 820], [656, 900], [610, 950], [550, 990], [456, 1004],
      [330, 998], [210, 984], [140, 952], [92, 896], [70, 820], [62, 720], [54, 640], [40, 560]]);
    R.flat(slate, '#46525a', 0.05, 1);
    const night = Q([[440, 380], [600, 350], [700, 360], [712, 560], [690, 700], [640, 790], [560, 800], [480, 770], [440, 700], [470, 600], [430, 520]]);
    R.flat(night, '#18141a', 0.05, 0);
    dots(night, 400, 9, '#d8d0e0', 0.4, 1.1);
    clipA(Q([[440, 380], [700, 380], [700, 480], [440, 480]], false), () => { for (const pts of [[[500, 410], [530, 400], [560, 418], [600, 404], [640, 420]], [[510, 430], [540, 446], [580, 432], [610, 448], [650, 436]]]) line(pts, 3, '#2a50c8'); });

    // ── gold filigree web ──
    {
      // jittered points joined to their nearest neighbours -> a web of gold cords, clipped to the web's measured outline
      const r = rng(11), pts = [];
      for (let y = 520; y < 840; y += 52) for (let x = 90 + (y / 52 % 2) * 26; x < 600; x += 56) pts.push([x + (r() - 0.5) * 30, y + (r() - 0.5) * 26]);
      const webArea = Q([[120, 560], [200, 520], [300, 500], [420, 470], [470, 500], [440, 560], [440, 620], [500, 650], [460, 700], [420, 760], [380, 820], [300, 830],
        [230, 800], [160, 760], [110, 740], [96, 700], [140, 660], [110, 610]]);
      const web = new Path2D(), seen = new Set();
      pts.forEach((p, i) => {
        const nn = pts.map((q, j) => [Math.hypot(q[0] - p[0], q[1] - p[1]), j]).sort((u, v) => u[0] - v[0]).slice(1, 4);
        for (const [, j] of nn) { const k = Math.min(i, j) + ',' + Math.max(i, j); if (seen.has(k)) continue; seen.add(k);
          const q = pts[j], mx = (p[0] + q[0]) / 2 + (r() - 0.5) * 18, my = (p[1] + q[1]) / 2 + (r() - 0.5) * 18; web.addPath(P([p, [mx, my], q], false, true)); }
      });
      R.h.save(); R.h.clip(webArea); a.save(); a.clip(webArea); R.pipe(web, 10, '#ecc468', 0.1, 0.1, 2); a.restore(); R.h.restore();
      R.pipe(webArea, 10, '#ecc468', 0.1, 0.1, 2);
      R.pipe(P([[60, 700], [70, 820], [100, 900], [150, 950], [230, 980]], false), 8, '#d8b060', 0.1, 0.1, 2);
    }
    R.dome(circleP(320, 650, 18), '#2a50c8', 0.12, 0.05, 6, 4);

    // ── gold sponge with white spots ──
    const sponge = Q([[676, 411], [650, 410], [638, 432], [577, 431], [545, 439], [525, 429], [513, 456], [484, 465], [445, 501], [426, 511], [427, 553], [447, 590], [438, 610],
      [420, 631], [459, 637], [501, 646], [537, 620], [569, 570], [610, 542], [643, 540], [661, 532], [673, 490], [692, 467], [692, 440]]);
    R.dome(sponge, '#ead4a4', 0.1, 0.12, 14, 1);
    R.pipe(sponge, 8, '#e0b858', 0.12, 0.08, 2);
    { const r = rng(13); for (let i = 0; i < 46; i++) { const x = 450 + r() * 230, y = 430 + r() * 200; R.dome(P(blob(x, y, 5 + r() * 9, 3 + r() * 5, i, 8, 0.25, r() * 3)), '#f4f2ec', 0.2, 0.05, 3, 3); } }

    // ── the sand car: top face, orange side band, windows ──
    const side = Q([[64, 368], [150, 470], [300, 440], [440, 386], [560, 342], [592, 292], [598, 330], [560, 352], [440, 402], [300, 456], [156, 512], [80, 440]], false);
    R.dome(side, '#e8862c', 0.1, 0.08, 8, 4);
    R.flat(Q([[72, 420], [150, 520], [156, 548], [90, 470]], false), '#c03030', 0.14, 4);
    const top = Q([[64, 368], [238, 214], [448, 148], [540, 196], [592, 292], [560, 342], [440, 386], [300, 440], [150, 470]], false);
    R.dome(top, '#d6b898', 0.12, 0.06, 10, 1);
    dots(top, 160, 15, '#2a2020', 0.5, 1.4);
    R.pipe(P([[64, 368], [150, 470], [300, 440], [440, 386], [560, 342], [592, 292]], false, false), 5, '#f0ece4', 0.18, 0.04, 4);
    for (const w of [[[208, 262], [238, 232], [262, 228], [248, 282], [212, 290]], [[262, 250], [300, 214], [358, 206], [350, 262], [300, 272]], [[366, 206], [392, 190], [470, 186], [478, 224], [372, 250]]]) {
      const p = Q(w, false); R.flat(p, '#2a4cc0', 0.12, 4); R.pipe(p, 4, '#d8b060', 0.15, 0.04, 2);
      clipA(p, () => { const r = rng(w[0][0]); a.fillStyle = '#f0d838'; for (let i = 0; i < 9; i++) a.fill(ellipseP(w[0][0] + r() * 100, w[2][1] - 20 + r() * 70, 3 + r() * 4, 2 + r() * 3, 0)); });
    }
    // white drips on the car
    { const r = rng(17); for (let i = 0; i < 26; i++) { const x = 220 + r() * 340, y = 220 + r() * 160; R.dome(P(blob(x, y, 4 + r() * 10, 3 + r() * 5, i + 50, 8, 0.25, -0.4)), '#f6f4f0', 0.2, 0.06, 4, 3); } }
    R.dome(P([[460, 330], [500, 310], [540, 300], [550, 318], [500, 340], [462, 346]], true, true), '#f6f4f0', 0.18, 0.06, 6, 3);
    // gold glitter wedge on the purple
    R.dome(Q([[480, 198], [600, 168], [606, 210], [580, 250], [530, 270], [500, 250]]), '#e8d070', 0.1, 0.08, 8, 4);

    // ── zebra scarf ──
    const zeb = Q([[30, 270], [60, 228], [120, 196], [200, 176], [290, 158], [352, 160], [330, 190], [240, 215], [150, 290], [64, 368], [40, 350], [28, 310]]);
    R.dome(zeb, '#f2f0ec', 0.1, 0.08, 10, 3);
    clipA(zeb, () => { for (let k = 0; k < 26; k++) { const x = -20 + k * 15; line([[x, 380], [x + 24, 300], [x + 60, 230], [x + 110, 150]], 4.6, '#141014'); } });
    R.bead(80, 216, 13, '#141014', 0.2, 0.12, 5);

    // ── pink coral and blue hand ──
    const coral = P(ragged([[110, 380], [150, 350], [190, 330], [230, 330], [270, 350], [300, 380], [290, 430], [260, 470], [240, 500], [210, 470], [170, 440],
      [130, 430]], 0, 12, 16, 10, 21), true, true);
    { const r = rng(27); // short lobed branches all round the coral
      for (let k = 0; k < 16; k++) { const ang = k / 16 * 6.283 + r() * 0.3, L = 40 + r() * 40, cx = 205, cy = 410;
        const x0 = cx + Math.cos(ang) * 60, y0 = cy + Math.sin(ang) * 55, x1 = x0 + Math.cos(ang + (r() - 0.5)) * L, y1 = y0 + Math.sin(ang + (r() - 0.5)) * L;
        R.pipe(P([[x0, y0], [(x0 + x1) / 2 + (r() - 0.5) * 16, (y0 + y1) / 2 + (r() - 0.5) * 16], [x1, y1]], false), 16 + r() * 8, '#e878c0', 0.12, 0.08, 1);
        R.dome(P(blob(x1, y1, 10 + r() * 6, 8 + r() * 5, 60 + k, 8, 0.3)), '#e878c0', 0.12, 0.08, 6, 1); } }
    R.dome(coral, '#e878c0', 0.12, 0.08, 8, 1);
    dots(coral, 120, 25, '#f4a8d8', 0.6, 1.6);
    const hand = Q([[150, 400], [180, 360], [200, 330], [214, 362], [228, 340], [236, 380], [250, 366], [256, 410], [240, 440], [200, 452], [160, 446], [134, 432]]);
    R.dome(hand, '#2a50c0', 0.16, 0.06, 6, 4);
    for (const fg of [[[170, 400], [150, 370], [146, 350]], [[184, 392], [176, 350], [178, 330]], [[160, 420], [128, 410], [112, 400]], [[200, 440], [196, 470]]]) R.pipe(P(fg, false), 12, '#2a50c0', 0.16, 0.06, 4);
    R.dome(ellipseP(256, 400, 30, 26, 0), '#2a50c0', 0.16, 0.08, 10, 4);
    for (const [x, y] of [[248, 396], [262, 396], [255, 410]]) R.bead(x, y, 3.2, '#0e0e18', 0.24, 0.02, 0);
    R.bead(272, 392, 16, '#f2f2f4', 0.2, 0.15, 3);
    R.bead(200, 436, 14, '#f2f2f4', 0.2, 0.08, 1);

    // ── red box, flags, target ──
    const box = Q([[553, 670], [651, 617], [682, 592], [708, 642], [697, 654], [658, 673], [645, 689], [618, 695], [570, 717]], false);
    R.dome(box, '#d43432', 0.1, 0.1, 8, 4);
    R.flat(Q([[580, 700], [630, 680], [640, 700], [590, 722]], false), '#f2f0ee', 0.16, 4);
    R.flat(Q([[650, 668], [700, 650], [706, 680], [656, 696]], false), '#f2f0ee', 0.16, 4);
    R.flat(Q([[623, 364], [636, 332], [654, 314], [712, 310], [719, 369], [690, 372], [640, 372]], false), '#cd2e2d', 0.1, 4);
    for (const pts of [[[450, 790], [520, 740], [570, 700]], [[470, 700], [520, 760], [560, 800]], [[520, 670], [530, 760], [520, 820]]]) R.pipe(P(pts, false, false), 7, '#d43432', 0.12, 0.05, 4);
    R.bead(530, 760, 9, '#f4f4f6', 0.2, 0.08, 5);
    { const t = P(star(510, 828, 40, 40, 4, 0.4), true, false); R.dome(t, '#d43432', 0.1, 0.08, 6, 4); R.flat(circleP(510, 828, 28), '#f2f0ee', 0.15, 4); R.flat(circleP(510, 828, 18), '#2a50c0', 0.16, 4); R.flat(circleP(510, 828, 9), '#0e0e14', 0.17, 0); }

    // ── green coral fan ──
    const fan = Q([[566, 760], [610, 730], [660, 730], [700, 740], [696, 820], [672, 890], [620, 950], [560, 960], [520, 940], [490, 910], [540, 860], [560, 800]]);
    R.dome(fan, '#2e8a70', 0.1, 0.08, 10, 4);
    clipA(fan, () => { for (let k = 0; k < 16; k++) line([[540 + k * 4, 940], [560 + k * 8, 850], [570 + k * 9, 740]], 2.4, '#0e2a24'); });

    // ── teal pebbles, balls, daisy ──
    const TEAL = '#3aa892';
    R.dome(Q([[100, 806], [130, 790], [176, 796], [216, 818], [250, 840], [246, 870], [200, 876], [150, 862], [110, 840]]), TEAL, 0.12, 0.14, 16, 5);
    R.dome(ellipseP(422, 862, 40, 66, 0.05), TEAL, 0.12, 0.16, 20, 5);
    R.dome(Q([[400, 960], [440, 944], [490, 950], [494, 980], [450, 990], [406, 984]]), TEAL, 0.12, 0.12, 12, 5);
    R.pipe(P([[408, 480], [400, 430], [410, 390], [440, 376], [460, 380]], false), 34, TEAL, 0.12, 0.16, 5);
    R.dome(Q([[22, 470], [50, 466], [60, 500], [40, 510], [24, 500]]), TEAL, 0.12, 0.1, 8, 5);
    R.dome(Q([[28, 520], [64, 524], [70, 548], [40, 552]]), TEAL, 0.12, 0.1, 8, 5);
    R.dome(Q([[460, 405], [500, 400], [518, 440], [470, 450]], false), '#f4dc6c', 0.14, 0.06, 6, 4);
    R.bead(140, 640, 56, '#3060c8', 0.12, 0.3, 1);
    for (const [x, y] of [[76, 620], [68, 806], [558, 980]]) R.bead(x, y, 22, '#f0d028', 0.15, 0.24, 5);
    R.bead(664, 594, 22, '#e85a24', 0.15, 0.24, 5);
    for (let k = 0; k < 18; k++) { const t = k / 18 * 6.283; R.dome(ellipseP(230 + Math.cos(t) * 34, 726 + Math.sin(t) * 34, 18, 7, t), '#f4f4f2', 0.14, 0.06, 5, 1); }
    R.dome(circleP(230, 726, 24), '#e2c4a4', 0.16, 0.06, 8, 1);
    R.dome(circleP(140, 548, 16), '#d8b060', 0.12, 0.06, 6, 2);

    // ── bottom: black and white bars, red slab, white box ──
    const bars = Q([[86, 880], [130, 940], [200, 976], [262, 990], [264, 950], [200, 930], [150, 900], [110, 862]]);
    R.flat(bars, '#f2f0ee', 0.08, 1);
    clipA(bars, () => { a.fillStyle = '#141014'; for (let k = 0; k < 14; k++) a.fill(P([[80 + k * 26, 1010], [100 + k * 26, 860], [116 + k * 26, 860], [96 + k * 26, 1010]], true, false)); });
    R.flat(Q([[270, 1000], [300, 960], [380, 930], [450, 910], [450, 960], [380, 990], [300, 1004]], false), '#d43432', 0.1, 4);
    const wbox = Q([[240, 880], [350, 840], [360, 860], [250, 905]], false);
    R.dome(wbox, '#f2f0ee', 0.12, 0.06, 6, 4);
    R.pipe(P([[250, 888], [352, 850]], false), 4, '#2a50c0', 0.18, 0.02, 4);
    R.pipe(P([[252, 896], [354, 858]], false), 3, '#d43432', 0.18, 0.02, 4);
    R.pipe(tray, 5, '#d8b060', 0.12, 0.06, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 24, wrap: 0.5, ao: 0.5, grain: 0.15 }),             // 1 clay
        E.mat({ dif: 0.7, metal: 0.5, spec: 1.0, shin: 40, rim: 0.3, ao: 0.5, tint: [1.1, 1.0, 0.7] }),  // 2 gold
        E.mat({ dif: 0.8, spec: 1.0, shin: 70, rim: 0.4, coat: 0.25, ao: 0.4 }),              // 3 glass / glossy white
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.4, ao: 0.5, grain: 0.1 }),               // 4 matte toy
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.3, coat: 0.2, ao: 0.4 })                 // 5 glossy
      ],
      light: [-0.35, 0.6, 0.72], lc: [0.62, 0.62, 0.62], amb: [0.48, 0.48, 0.5],
      envTop: [1, 1, 1], envHor: [0.5, 0.52, 0.56], envBot: [0.12, 0.12, 0.14], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.3, 0.32, 0.36], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 85], shadow: [5, 7, 0.45, 6]
    });
    // glass sheen on the tray rim
    o.save(); o.globalAlpha = 0.5; o.lineWidth = 3; o.strokeStyle = '#ffffff'; o.stroke(P([[40, 600], [14, 450], [20, 250], [40, 110], [80, 40], [200, 16]], false)); o.restore();
    E.grain(0.05, 23);
  }
});
