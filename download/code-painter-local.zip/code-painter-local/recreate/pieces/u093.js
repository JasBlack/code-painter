'use strict';
// u093 — "Chrome dreamer, gold moon": a sleeping white face melts out of swirling chrome inside a ringed
// grey moon with gold flecks and crater holes; an orange-pink flame ribbon, a black arm with a gold hand and a
// polished gold sphere drift below, framed by red, violet and cobalt bands and black starfield.
REC.register('u093', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, r0 = 0) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const stars = (path, n, seed, big = 2) => clipA(path, () => { const r = rng(seed); for (let i = 0; i < n; i++) { a.globalAlpha = 0.5 + r() * 0.5; fill(circleP(r() * 726, r() * 1024, r() < 0.85 ? 0.6 + r() : 1.6 + r() * big), '#f4f2f0'); } a.globalAlpha = 1; });

    // ── frame bands: cobalt, violet, red; black starfield top right ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 260, [[0, '#2a50b0'], [0.05, '#5a3a8a'], [0.13, '#7a3a70'], [0.2, '#d81a20'], [0.8, '#d02024'], [1, '#4a1418']]), 0, 0);
    R.flat(P([[-10, 300], [736, 300], [736, 1034], [-10, 1034]], true, false), '#08070a', 0, 0);
    const blackTR = P([[470, 56], [736, 56], [736, 260], [470, 260]], true, false);
    R.flat(blackTR, '#070608', 0.01, 0);
    stars(blackTR, 200, 1);
    R.pipe(line([[500, 66], [600, 70], [700, 62], [716, 30], [716, -10]]), 14, '#b8b4b0', 0.06, 0.06, 3);

    // ── the ringed moon disc (centre 356,545) ──
    const C = [356, 545], disc = circleP(C[0], C[1], 484), inner = circleP(C[0], C[1], 434);
    const top = P([[-10, -10], [736, -10], [736, 560], [-10, 560]], true, false);
    clipA(top, () => { R.h.save(); R.h.clip(top); R.dome(disc, '#b4b0b0', 0.06, 0.06, 6, 3); R.dome(circleP(C[0], C[1], 472), lin(0, 60, 0, 300, [[0, '#2a1a16'], [0.5, '#140c0c'], [1, '#201410']]), 0.1, 0.06, 14, 2); R.h.restore(); });
    soft(x => { stroke(line([[60, 236], [140, 156], [230, 112]]), '#c84a20', 6, x); stroke(ellipseP(150, 176, 30, 8, -0.5), '#ff7020', 4, x); }, 3, 0.9);
    R.dome(inner, lin(0, 300, 300, 900, [[0, '#8a807a'], [0.6, '#857a74'], [1, '#7a706c']]), 0.04, 0.04, 30, 1);
    { const r = rng(21); for (let i = 0; i < 70; i++) fill(circleP(r() * 726, 300 + r() * 700, 1.5 + r() * 5), '#1a1618'); }
    // black pools inside the moon (around the sphere, under the arm, right side)
    const pools = new Path2D();
    pools.addPath(sm([[60, 560], [130, 540], [220, 560], [300, 600], [380, 640], [430, 600], [470, 560], [520, 520], [600, 470], [736, 430], [736, 1040], [380, 1040], [300, 980], [200, 940], [130, 880], [110, 760], [70, 640]]));
    R.flat(pools, '#07060a', 0.04, 0);
    stars(pools, 420, 2, 2.5);
    stroke(circleP(C[0], C[1], 434), '#c02018', 2);
    // blue sky in the upper part of the disc
    const sky = sm([[30, 300], [70, 230], [130, 170], [210, 132], [300, 112], [400, 106], [500, 118], [560, 140], [540, 190], [450, 230], [380, 270], [300, 300], [200, 320], [100, 360], [40, 420]]);
    R.flat(sky, lin(0, 110, 0, 400, [[0, '#3e64b0'], [1, '#4a6ab0']]), 0.05, 0);
    stars(sky, 60, 3);
    soft(x => { fill(ellipseP(240, 200, 60, 30, -0.3), 'rgba(220,225,235,0.8)', x); fill(ellipseP(150, 250, 50, 24, -0.4), 'rgba(200,205,220,0.7)', x); }, 14, 0.8);
    // blue planet on the left
    R.dome(circleP(28, 330, 78), rad(10, 310, 90, [[0, '#f8f8ff'], [0.25, '#7aa8e8'], [0.6, '#3a74c8'], [1, '#1a3a90']]), 0.08, 0.1, 30, 4);
    // grey moon surface with craters and gold flecks (right)
    const moon = sm([[300, 286], [340, 236], [420, 186], [500, 150], [580, 134], [650, 152], [736, 214], [736, 410], [680, 402], [600, 410], [560, 418], [530, 360], [490, 300], [420, 272], [350, 284]]);
    R.dome(moon, lin(300, 140, 736, 410, [[0, '#8c8480'], [0.5, '#8a8078'], [1, '#867a72']]), 0.08, 0.08, 20, 1);
    R.groove(circleP(615, 265, 34), 10, '#3a3434', 0.14, 0.08, 1);
    R.flat(circleP(615, 265, 31), '#050506', 0.06, 0);
    stars(circleP(615, 265, 31), 30, 4, 1);
    R.bead(676, 268, 13, '#5aa8f0', 0.16, 0.06, 4);
    { const r = rng(5); for (let i = 0; i < 40; i++) { const x = 360 + r() * 360, y = 160 + r() * 240, rr = 2 + r() * 6; fill(circleP(x, y, rr), '#141214'); }
      for (let i = 0; i < 240; i++) { const t = r(), x = (i < 120 ? 470 + t * 160 : 440 + t * 200) + (r() - 0.5) * 30, y = (i < 120 ? 150 + r() * 70 : 330 + r() * 40); R.bead(x, y, 1.5 + r() * 3, r() < 0.7 ? '#c89a30' : '#f0d070', 0.2, 0.04, 2); }
      for (const pts of [[[380, 230], [420, 210], [460, 190], [500, 170]], [[300, 280], [330, 250], [350, 236]]]) R.pipe(line(pts), 5, '#c89a30', 0.2, 0.04, 2); }

    // ── swirling chrome ──
    const CHR = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p - vec2(240., 420.);
      float an = atan(q.y, q.x), r = length(q * vec2(1., 1.3));
      float h = r * .014 + an * .34 + fbm(p * .01) * 1.4 + fbm(p * .045) * 1.1 * smoothstep(450., 560., p.y);
      float t = fract(h);
      vec3 c = vec3(.9, .9, .92);
      c = mix(c, vec3(.56, .56, .6), smoothstep(.5, .58, t));
      c = mix(c, vec3(.05, .05, .06), smoothstep(.64, .69, t));
      c = mix(c, vec3(.42, .42, .46), smoothstep(.78, .84, t));
      c = mix(c, vec3(.9, .9, .92), smoothstep(.9, .98, t));
      return c; }`);
    const chrome = sm([[54, 570], [46, 486], [66, 404], [92, 300], [130, 226], [200, 182], [262, 168], [302, 180], [292, 232], [262, 262], [302, 292], [362, 274], [440, 284], [500, 304], [540, 364], [560, 424], [520, 474], [470, 522], [420, 562], [380, 604], [340, 646], [300, 664], [240, 654], [180, 624], [120, 604]]);
    R.dome(chrome, null, 0.1, 0.12, 30, 3);
    clipA(chrome, () => img(CHR));
    R.dome(ellipseP(250, 415, 52, 42, -0.3), rad(236, 400, 60, [[0, '#d8c8c0'], [0.5, '#8a6a60'], [1, '#3a2420']]), 0.2, 0.1, 20, 4);
    // the sleeping white face
    const face = sm([[302, 302], [340, 290], [420, 292], [482, 302], [520, 332], [548, 382], [540, 432], [518, 480], [478, 518], [438, 540], [398, 540], [358, 520], [330, 480], [312, 420], [302, 360]]);
    R.dome(face, lin(300, 290, 550, 540, [[0, '#dcdcd8'], [0.6, '#c4c2bc'], [1, '#aeaaa2']]), 0.16, 0.1, 30, 1);
    soft(x => stroke(line([[318, 330], [306, 400], [316, 470], [350, 520], [390, 548]]), '#40a8e8', 10, x), 2, 0.9);
    for (const [pts, w] of [[[[370, 316], [420, 306], [470, 318], [500, 340]], 7], [[[400, 350], [430, 344], [460, 356]], 5], [[[470, 380], [492, 376], [510, 386]], 5], [[[436, 380], [432, 410], [446, 418]], 4], [[[360, 450], [390, 430], [420, 436], [450, 428]], 5], [[[350, 470], [358, 490]], 4]])
      stroke(line(pts), '#0a0a0c', w);
    for (const [x, y, r] of [[470, 456, 20], [500, 400, 9], [440, 520, 10], [330, 410, 5], [520, 360, 6], [410, 470, 4], [480, 500, 7]]) fill(circleP(x, y, r), '#0a0a0c');
    // yellow glow to the right of the face
    R.dome(sm([[500, 400], [540, 390], [570, 420], [560, 480], [520, 530], [470, 556], [440, 540], [480, 500], [510, 460]]), '#e8b838', 0.14, 0.06, 14, 4);

    // ── flame ribbon: pink band, orange edges, blue gap, orange column ──
    R.flat(sm([[470, 560], [560, 520], [610, 500], [600, 600], [590, 700], [570, 790], [480, 850], [420, 830], [440, 720]]), '#3a62b8', 0.04, 0);
    stars(sm([[470, 560], [560, 520], [610, 500], [600, 600], [590, 700], [570, 790], [480, 850], [420, 830], [440, 720]]), 40, 6);
    R.dome(sm([[292, 764], [318, 704], [366, 644], [428, 592], [490, 552], [552, 520], [596, 500], [606, 524], [566, 562], [522, 606], [482, 664], [444, 728], [414, 796], [380, 806], [338, 794]]), lin(300, 780, 600, 500, [[0, '#f6d0cc'], [0.6, '#f2b8b4'], [1, '#e89088']]), 0.1, 0.06, 20, 4);
    R.pipe(line([[296, 700], [370, 610], [460, 540], [560, 486], [650, 446], [716, 418]]), 26, lin(300, 700, 716, 418, [[0, '#e85018'], [0.5, '#f88a28'], [1, '#f07020']]), 0.12, 0.06, 4);
    R.dome(sm([[612, 452], [652, 432], [692, 420], [688, 470], [680, 520], [660, 620], [636, 720], [612, 780], [584, 784], [566, 762], [586, 690], [600, 590], [606, 520]]), lin(570, 0, 700, 0, [[0, '#e05818'], [0.4, '#f4a030'], [0.65, '#f8c848'], [1, '#e06818']]), 0.12, 0.08, 16, 4);
    R.dome(circleP(604, 694, 18), '#1a1a1a', 0.2, 0.06, 6, 2); R.bead(604, 694, 11, '#4aa0f0', 0.24, 0.06, 4);
    // small chrome creature in the blue gap
    R.dome(sm([[520, 600], [550, 586], [574, 600], [560, 640], [540, 680], [520, 670], [530, 630]]), '#c8c8cc', 0.12, 0.08, 8, 3);

    // ── lower field: grey moon edge, orange glow, gold sphere and drape, black arm, gold hand ──
    R.dome(sm([[-10, 560], [40, 590], [100, 620], [140, 680], [120, 760], [130, 850], [100, 900], [-10, 900]]), '#8a8480', 0.06, 0.06, 20, 1);
    soft(x => fill(ellipseP(80, 750, 80, 46, 0), '#f05828', x), 14, 0.9);
    soft(x => stroke(line([[10, 620], [40, 700], [30, 780], [50, 860]]), '#e8e8e8', 5, x), 3, 0.7);
    for (const [x, y, r] of [[160, 560, 7], [80, 610, 10], [190, 620, 6], [240, 628, 6]]) R.bead(x, y, r, '#c8a050', 0.2, 0.06, 2);
    R.dome(sm([[40, 620], [90, 616], [110, 640], [70, 668], [30, 660]]), '#d8b860', 0.08, 0.04, 6, 2);
    const drape = sm([[226, 664], [290, 670], [336, 702], [374, 762], [404, 822], [432, 882], [452, 922], [420, 952], [350, 962], [280, 952], [210, 900], [196, 780], [206, 700]]);
    R.dome(drape, lin(230, 660, 450, 960, [[0, '#f0d488'], [0.5, '#d0a858'], [1, '#e0bc68']]), 0.14, 0.14, 26, 2);
    R.pipe(line([[380, 860], [450, 850], [520, 820], [570, 790]]), 74, '#141214', 0.12, 0.16, 5);
    for (const pts of [[[520, 760], [560, 740], [600, 750], [620, 790], [600, 830], [560, 840], [530, 820]], [[560, 760], [600, 730], [640, 740], [650, 780], [630, 800]], [[540, 800], [560, 840], [550, 870], [530, 860]], [[580, 830], [610, 850], [600, 880]]]) R.pipe(line(pts), 7, '#d8b050', 0.3, 0.06, 2);
    R.bead(200, 800, 102, rad(176, 764, 140, [[0, '#fff8e0'], [0.22, '#ead084'], [0.6, '#a87c2c'], [1, '#3a2808']]), 0.2, 0.5, 6);
    // lower-right orange wedge
    soft(x => fill(P([[650, 790], [736, 780], [736, 900], [690, 900], [660, 860]]), '#d04a20', x), 8, 0.6);
    // bottom: cobalt band with a pink stroke, red frame
    R.flat(sm([[10, 880], [80, 900], [160, 930], [250, 950], [350, 940], [440, 930], [470, 960], [440, 990], [10, 990]]), '#2e5ec8', 0.08, 0);
    soft(x => fill(ellipseP(250, 968, 80, 12, 0), '#f070a0', x), 4, 0.9);
    R.flat(P([[-10, 990], [736, 990], [736, 1034], [-10, 1034]], true, false), lin(0, 990, 0, 1024, [[0, '#a02018'], [1, '#2a1010']]), 0.1, 0);
    R.flat(P([[14, 880], [24, 880], [24, 992], [14, 992]], true, false), '#d03020', 0.1, 0);
    stars(P([[0, 0], [726, 0], [726, 1024], [0, 1024]], true, false), 60, 9, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.3 }),                                     // 1 matte moon / face
        E.mat({ dif: 0.6, metal: 0.6, spec: 1.2, shin: 40, ao: 0.4, rim: 0.3, tint: [1.12, 1.0, 0.72] }), // 2 gold
        E.mat({ dif: 0.8, spec: 1.2, shin: 70, wrap: 0.3, coat: 0.2, rim: 0.3 }),                       // 3 chrome / gloss
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.5, emis: 0.15 }),                                  // 4 glowing paint
        E.mat({ dif: 1, spec: 1.4, shin: 80, coat: 0.3, rim: 0.6 }),                                    // 5 black gloss
        E.mat({ dif: 1, spec: 1.2, shin: 30, wrap: 0.3, metal: 0.15, tint: [1.1, 1.0, 0.8] })        // 6 polished gold ball
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.85, 0.82, 0.8], amb: [0.42, 0.42, 0.44],
      envTop: [1.0, 0.98, 0.95], envHor: [0.45, 0.42, 0.42], envBot: [0.06, 0.05, 0.05], envK: [0.3, 1.0, 0.4, 0],
      rimC: [0.9, 0.4, 0.2], rimD: [0.4, 0.5, 0.4], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-4, 5, 0.5, 6]
    });
    E.grain(0.05, 93);
  }
});
