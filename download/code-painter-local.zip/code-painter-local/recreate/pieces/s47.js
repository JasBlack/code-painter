'use strict';
// s47 — "Yellow-face totem": a speckled grey pipe sculpture (S-bend, ribbed column,
// banded horseshoe ring) with a melting yellow face, a lime ring and a yellow virus
// ball, against black gear silhouettes, riveted green steel, a purple grid panel,
// neon green blocks and op-art zebra; a bearded wizard in a zebra coat on the left.
REC.register('s47', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const speck = (path, n, seed, col, al = 0.8) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al * (0.4 + r() * 0.6); a.beginPath(); a.arc(r() * 726, r() * 1024, 0.4 + r() * 0.8, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const zebraFx = (k, ang, seed) => E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = mat2(cos(${ang.toFixed(3)}), -sin(${ang.toFixed(3)}), sin(${ang.toFixed(3)}), cos(${ang.toFixed(3)})) * p;
      float w = q.x + 14. * sin(q.y * 0.035 + ${seed.toFixed(1)}) + 8. * (fbm(p * 0.02 + ${seed.toFixed(1)}) - 0.5) * 3.;
      float s = sin(6.2832 * w / ${k.toFixed(1)});
      return vec3(smoothstep(-0.12, 0.12, s)) * 0.94 + 0.02; }`);

    // ── background panels ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#020302', 0, 0);
    // riveted green steel (left middle)
    const steel = P([[-10, 170], [300, 170], [300, 800], [-10, 800]], true, false);
    R.flat(steel, '#23493d', 0.02, 0);
    clipA(steel, () => {
      const r = rng(3); for (let i = 0; i < 1400; i++) { a.fillStyle = `rgba(${r() < 0.6 ? '10,30,24' : '90,130,110'},0.3)`; a.beginPath(); a.arc(r() * 300, 170 + r() * 630, 0.5 + r() * 2.5, 0, 6.283); a.fill(); }
      a.strokeStyle = '#4e8272'; a.lineWidth = 8;
      for (const [x0, y0, x1, y1] of [[40, 250, 300, 560], [300, 250, 40, 560], [-10, 470, 150, 650], [150, 650, 300, 470], [140, 560, 300, 760], [300, 560, 140, 760]]) { a.beginPath(); a.moveTo(x0, y0); a.lineTo(x1, y1); a.stroke(); }
      a.strokeStyle = '#78a898'; a.lineWidth = 6; for (const y of [182, 470]) { a.beginPath(); a.moveTo(0, y); a.lineTo(300, y); a.stroke(); }
      a.lineWidth = 6; for (const x of [262, 280]) { a.beginPath(); a.moveTo(x, 170); a.lineTo(x, 800); a.stroke(); }
    });
    for (const [x, y] of [[168, 232], [168, 454], [52, 462], [168, 630], [52, 650]]) { R.dome(circleP(x, y, 12), '#4a7a6a', 0.06, 0.08, 5, 5); R.bead(x, y, 6, '#6a9a8a', 0.12, 0.05, 5); }
    // neon green, tan strip, fabric, wood
    R.flat(rrect(421, -10, 124, 128, 0), '#18f424', 0.02, 0);
    R.flat(rrect(443, 118, 102, 22, 0), '#cbb88e', 0.02, 0); speck(rrect(443, 118, 102, 22, 0), 300, 4, '#5a4a30', 0.8);
    const fab = P([[546, -10], [662, -10], [662, 160], [656, 186], [640, 176], [620, 180], [600, 170], [580, 176], [560, 172], [546, 160]], true, true);
    R.flat(fab, '#8ea68a', 0.03, 7);
    clipA(fab, () => { const r = rng(6); a.strokeStyle = 'rgba(60,80,60,0.35)'; for (let i = 0; i < 160; i++) { const x = 546 + r() * 116; a.lineWidth = 0.6 + r(); a.beginPath(); a.moveTo(x, 0); a.lineTo(x + (r() - 0.5) * 6, 190); a.stroke(); } });
    R.flat(rrect(662, -10, 80, 152, 0), '#7c6a4c', 0.02, 7);
    clipA(rrect(662, -10, 80, 152, 0), () => { a.strokeStyle = '#b0b0a8'; a.lineWidth = 1.5; for (let y = 0; y < 110; y += 5) { a.beginPath(); a.moveTo(698, y); a.lineTo(716, y + 3); a.stroke(); } });
    // purple grid panel
    const purple = P([[443, 139], [736, 139], [736, 800], [543, 800], [543, 560], [443, 560]], true, false);
    R.flat(purple, '#7c14f6', 0.02, 0);
    clipA(purple, () => { a.strokeStyle = '#5a12b8'; a.lineWidth = 14; for (let k = -4; k < 8; k++) { a.beginPath(); a.moveTo(443 + k * 110, 139); a.lineTo(443 + k * 110 + 420, 560); a.stroke(); a.beginPath(); a.moveTo(443 + k * 110 + 420, 139); a.lineTo(443 + k * 110, 560); a.stroke(); } });
    // lower panels
    R.flat(rrect(86, 512, 52, 450, 0), '#6c7c6a', 0.02, 7);
    R.flat(rrect(621, 490, 74, 465, 0), '#4c4c42', 0.02, 7);
    R.flat(rrect(521, 800, 104, 145, 0), '#16a012', 0.02, 0);
    R.flat(rrect(236, 790, 310, 36, 0), '#20e418', 0.02, 0);
    // wood floor
    const floorG = a.createLinearGradient(0, 950, 0, 1024); floorG.addColorStop(0, '#b88a5c'); floorG.addColorStop(1, '#c89a6a');
    R.flat(rrect(-10, 952, 746, 80, 0), floorG, 0.02, 0);
    clipA(rrect(-10, 952, 746, 80, 0), () => { a.strokeStyle = 'rgba(120,80,40,0.3)'; a.lineWidth = 1; for (let i = 0; i < 40; i++) { a.beginPath(); a.moveTo(i * 20, 952); a.lineTo(i * 20 - 30, 1024); a.stroke(); } });
    // black pedestal + gear silhouettes
    R.flat(rrect(236, 826, 286, 180, 4), '#030303', 0.02, 0);
    const gear = (cx, cy, r0, n, lobe) => { const p = new Path2D(); p.addPath(circleP(cx, cy, r0)); for (let i = 0; i < n; i++) { const t = i / n * 6.283; p.addPath(circleP(cx + Math.cos(t) * r0, cy + Math.sin(t) * r0, lobe)); } return p; };
    a.fillStyle = '#020202';
    for (const g of [gear(240, 270, 60, 6, 26), gear(470, 262, 56, 6, 24), gear(170, 430, 56, 6, 24), gear(560, 410, 44, 6, 20), gear(548, 560, 40, 6, 18), gear(170, 560, 46, 5, 22)]) a.fill(g);
    a.fillRect(300, 0, 120, 260); a.fill(P([[300, 0], [440, 0], [470, 260], [270, 260]], true, false));
    // lamp hook + box with forks
    R.pipe(P([[398, 110], [372, 70], [382, 40], [410, 30], [436, 44], [440, 80], [430, 110]], false), 8, '#9ab0b8', 0.2, 0.08, 3);
    R.dome(P([[322, 64], [336, 64], [340, 90], [336, 118], [322, 118], [318, 90]]), '#9ec4cc', 0.2, 0.08, 6, 3);
    R.dome(rrect(293, 118, 150, 64, 4), '#9a8672', 0.1, 0.08, 4, 6);
    a.fillStyle = 'rgba(60,40,30,0.5)'; a.fillRect(293, 140, 150, 3); a.fillRect(293, 160, 150, 3);
    for (const x of [348, 360, 373, 386]) R.pipe(P([[x, 100], [x, 160]], false), 3, '#c8c8cc', 0.2, 0.04, 3);
    R.pipe(P([[326, 172], [410, 172]], false), 8, '#1a1a1a', 0.22, 0.04, 3);
    // white machine + orange grid on the right
    R.dome(P([[662, 262], [736, 262], [736, 680], [662, 672]], true, false), '#aebaa8', 0.1, 0.1, 6, 7);
    R.bead(708, 311, 9, '#e87818', 0.2, 0.06, 7); R.bead(690, 368, 8, '#8a8070', 0.2, 0.06, 7);
    R.dome(P([[700, 420], [710, 450], [700, 480]], true, false), '#303030', 0.18, 0.02, 3, 7);
    R.pipe(P([[707, 90], [707, 250]], false), 20, '#f0e224', 0.1, 0.12, 7);
    R.flat(rrect(696, 676, 40, 300, 0), '#f08812', 0.03, 0);
    clipA(rrect(696, 676, 40, 300, 0), () => { a.strokeStyle = 'rgba(120,50,0,0.6)'; a.lineWidth = 1; for (let y = 676; y < 980; y += 10) { a.beginPath(); a.moveTo(696, y); a.lineTo(736, y); a.stroke(); } for (let x = 696; x < 740; x += 10) { a.beginPath(); a.moveTo(x, 676); a.lineTo(x, 980); a.stroke(); } });

    // ── zebra (top-left) ──
    const zTL = P([[-10, -10], [322, -10], [300, 30], [271, 71], [240, 110], [214, 143], [180, 180], [143, 214], [100, 236], [71, 243], [30, 250], [-10, 252]], true, true);
    R.flat(zTL, null, 0.02, 0);
    clipA(zTL, () => img(zebraFx(20, 0.55, 1.3)));
    a.save(); a.strokeStyle = '#050505'; a.lineWidth = 10; a.stroke(P([[322, -10], [300, 30], [271, 71], [240, 110], [214, 143], [180, 180], [143, 214], [100, 236], [71, 243], [30, 250], [-10, 252]], false)); a.restore();

    // ── the sculpture ──
    const GR = '#c4c4cc';
    // lime ring
    const RC = [362, 382], RX = 200, RY = 204;
    R.pipe(ellipseP(RC[0], RC[1], RX - 8, RY - 8, 0), 12, '#30d020', 0.2, 0.08, 2);
    { const cr = new Path2D(); cr.ellipse(RC[0], RC[1], RX - 22, RY - 22, 0, -1.2, 1.0); R.pipe(cr, 26, '#36d82a', 0.2, 0.12, 2); }
    R.pipe(ellipseP(RC[0], RC[1], RX, RY, 0), 26, '#dcdc2c', 0.24, 0.16, 2);
    R.dome(rrect(146, 350, 24, 72, 10), '#dcdc2c', 0.3, 0.1, 8, 2); R.dome(rrect(554, 350, 24, 70, 10), '#dcdc2c', 0.3, 0.1, 8, 2);
    // ribbed column (upper)
    for (let k = 0; k < 5; k++) R.dome(ellipseP(366, 420 + k * 20, 64 - k * 2, 12, 0), GR, 0.24, 0.1, 6, 1);
    R.dome(P([[340, 408], [346, 370], [366, 352], [386, 370], [392, 408]]), GR, 0.26, 0.14, 10, 1);
    R.bead(366, 348, 8, GR, 0.3, 0.06, 1);
    // lower horseshoe ring with bands
    const LC = [378, 744];
    R.pipe(rrect(184, 606, 392, 300, 120), 80, GR, 0.2, 0.36, 1);
    // S-pipe
    const sPipe = [[244, 336], [214, 372], [204, 420], [210, 470], [236, 516], [290, 548], [360, 560], [430, 570], [480, 596]];
    R.pipe(P(sPipe, false), 78, GR, 0.22, 0.36, 1);
    R.dome(P([[300, 560], [450, 560], [440, 620], [410, 636], [380, 626], [350, 636], [320, 622]]), GR, 0.3, 0.2, 14, 1);
    for (let k = 0; k < 4; k++) R.dome(ellipseP(372, 650 + k * 20, 62, 11, 0), GR, 0.24, 0.1, 6, 1);
    const bnd = (x, y, rot, L = 44) => { const c = Math.cos(rot), sn = Math.sin(rot), pts = [[-L / 2, -8], [L / 2, -8], [L / 2, 8], [-L / 2, 8]].map(([u, v]) => [x + u * c - v * sn, y + u * sn + v * c]); R.dome(P(pts, true, false), '#d4d4dc', 0.46, 0.1, 6, 1); };
    for (const [x, y, rot] of [[226, 640, 0.8], [534, 640, -0.8], [184, 740, 0], [576, 740, 0], [226, 872, -0.8], [534, 872, 0.8], [370, 906, 1.57], [388, 906, 1.57], [226, 460, 0.1], [286, 548, 1.3]]) bnd(x, y, rot);
    speck(rrect(140, 560, 480, 390, 140), 2500, 8, '#5a5a62', 0.8);
    speck(P(lock(sPipe, 78, 78, 1)), 800, 18, '#5a5a62', 0.8);
    // yellow face blob
    const face = P([[216, 330], [226, 290], [260, 250], [300, 222], [360, 208], [420, 214], [448, 240], [456, 290], [446, 318], [420, 330], [400, 320], [398, 336], [380, 332], [360, 336],
      [340, 332], [320, 318], [306, 306], [280, 300], [256, 312], [240, 330], [226, 336]]);
    R.dome(face, '#dede38', 0.3, 0.16, 16, 3);
    R.dome(P([[310, 290], [330, 252], [352, 238], [372, 252], [392, 290], [400, 320], [380, 334], [360, 330], [340, 334], [316, 322]]), '#e0e03a', 0.4, 0.12, 14, 3);
    R.dome(ellipseP(232, 318, 18, 24, 0.2), '#dede38', 0.3, 0.12, 10, 3);
    for (const [x, y, r] of [[312, 281, 5], [430, 281, 5], [350, 251, 3], [380, 251, 3]]) R.flat(circleP(x, y, r), '#0a0a0a', 0.5, 0);
    speck(face, 600, 9, '#7a7a20', 0.7);
    // virus ball
    R.dome(circleP(365, 786, 52), '#e2e236', 0.3, 0.3, 36, 3);
    for (let i = 0; i < 9; i++) { const t = i / 9 * 6.283 - 1.2; R.bead(365 + Math.cos(t) * 56, 786 + Math.sin(t) * 54, 13, '#e2e236', 0.3, 0.16, 3); }
    for (const [x, y] of [[332, 752], [390, 745], [340, 790], [385, 785], [362, 810], [400, 755], [310, 792]]) R.flat(circleP(x, y, 4), '#0a0a0a', 0.62, 0);

    // ── wizard + zebra coat (left) ──
    const coat = P([[40, 600], [88, 560], [124, 600], [150, 680], [190, 780], [232, 880], [262, 960], [276, 1034], [40, 1034]], true, true);
    R.flat(coat, null, 0.1, 0);
    clipA(coat, () => img(zebraFx(26, -0.45, 4.1)));
    const beard = P([[0, 372], [24, 380], [36, 450], [42, 560], [66, 650], [96, 760], [126, 900], [138, 1034], [-10, 1034], [-10, 372]], true, true);
    R.flat(beard, '#d6d6d2', 0.12, 7);
    clipA(beard, () => { const r = rng(12); a.strokeStyle = 'rgba(90,90,90,0.6)'; for (let i = 0; i < 110; i++) { const x = r() * 110; a.lineWidth = 0.6 + r() * 0.6; a.beginPath(); a.moveTo(x, 380); a.bezierCurveTo(x + 10, 600, x - 10, 800, x + r() * 40, 1030); a.stroke(); } });
    R.flat(P([[0, 256], [34, 246], [58, 260], [66, 292], [44, 304], [0, 304]], true, true), '#1a50e0', 0.12, 7);
    R.flat(ellipseP(22, 280, 10, 12, 0), '#f0a018', 0.14, 7); R.flat(ellipseP(24, 282, 5, 6, 0), '#101010', 0.15, 0);
    R.flat(P([[0, 300], [44, 300], [52, 340], [44, 374], [24, 388], [0, 384]], true, true), '#d88a4a', 0.12, 7);
    R.flat(P([[0, 300], [40, 300], [40, 312], [0, 316]], true, false), '#1a1a1a', 0.13, 0);
    R.flat(ellipseP(10, 332, 4, 3, 0), '#101010', 0.14, 0);
    R.pipe(P([[48, 330], [48, 390], [44, 410]], false), 12, '#f0a018', 0.14, 0.06, 7);
    R.flat(P([[70, 500], [110, 488], [130, 492], [112, 500], [96, 510], [74, 512]], true, true), '#e8a070', 0.14, 7);
    R.dome(rrect(30, 540, 60, 40, 8), '#1a1a1c', 0.14, 0.06, 6, 7);
    R.flat(rrect(0, 880, 40, 110, 6), '#141414', 0.14, 0);
    for (let y = 890; y < 985; y += 16) R.flat(rrect(4, y, 30, 5, 2), '#b0b0b0', 0.15, 0);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.35, ao: 0.6, coat: 0.2 }),                 // 1 speckled grey pipe
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.35, ao: 0.4, coat: 0.2, emis: 0.1 }),      // 2 lime ring
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.4, ao: 0.5, coat: 0.2, emis: 0.12 }),      // 3 yellow blobs
        E.mat({ dif: 1, spec: 0.6, shin: 30, wrap: 0.3, metal: 0.3 }),                        // 4 lamp / wires
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, emis: 0.2 }),                         // 5 rivets
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, emis: 0.2 }),                         // 6 box
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, emis: 0.35 })                         // 7 flat illustrated bits
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.66, 0.66, 0.66], amb: [0.46, 0.46, 0.46],
      envTop: [1.05, 1.05, 1.05], envHor: [0.55, 0.55, 0.55], envBot: [0.12, 0.12, 0.12], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.1, 0.1, 0.1], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-6, 8, 0.6, 6]
    });
    E.grain(0.04, 47);
  }
});
