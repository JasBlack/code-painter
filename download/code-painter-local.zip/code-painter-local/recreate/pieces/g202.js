'use strict';
// g202 — "Pearl spiral monster": a blue paper-cutout monster with a spiky white crown, a teal shield and a red leg
// among chrome pearls, zebra spiral discs and a fingerprint swirl, on blue, brushed grey and rust.
REC.register('g202', {
  w: 1024, h: 726,
  draw(E) {
    const W = 1024, H = 726, R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a, alpha = 1, op = 'source-over') => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a, x0 = x, y0 = y) => { const g = ctx.createRadialGradient(x0, y0, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fillA = (p, c) => { a.fillStyle = c; a.fill(p); };
    const strokeA = (p, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(p); };
    const soft = (px, fn, alpha = 1) => { a.save(); a.filter = `blur(${px * S}px)`; a.globalAlpha = alpha; fn(); a.restore(); };

    // ── background: brushed grey, blue field, dark band, rust ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), null, 0, 0);
    fillA(rrect(-10, -10, W + 20, H + 20, 0), lin(0, 0, 640, 0, [[0, '#adb1b3'], [0.08, '#a3a8ab'], [0.16, '#879096'], [0.26, '#66737c'], [0.4, '#566570'], [0.62, '#4a5762'], [0.8, '#3c434d'], [1, '#3a3e48']]));
    soft(40, () => fillA(sm([[0, 140], [120, 300], [260, 360], [330, 440], [300, 520], [160, 470], [60, 380], [0, 330]]), 'rgba(96,110,160,0.55)'));
    const sky = sm([[-10, -10], [770, -10], [744, 20], [728, 50], [710, 82], [690, 110], [662, 135], [626, 148], [580, 150], [530, 152], [490, 164], [450, 188], [400, 214], [358, 238], [330, 262], [305, 312], [262, 312], [205, 302], [145, 280], [98, 252], [56, 212], [24, 166], [-10, 118]]);
    soft(10, () => fillA(sky, lin(0, 0, 400, 300, [[0, '#4b4ec2'], [0.4, '#5357cc'], [1, '#575bd0']])));
    // black backdrop behind the monster, rust plain
    const rust = sm([[836, -10], [1034, -10], [1034, 736], [652, 736], [648, 640], [660, 560], [700, 520], [705, 420], [695, 300], [700, 190], [740, 156], [770, 130], [790, 100], [806, 60], [822, 20]]);
    fillA(poly([[330, 262], [358, 238], [400, 214], [450, 188], [490, 164], [530, 152], [580, 150], [626, 148], [662, 135], [690, 110], [710, 82], [744, 20], [770, -10], [840, -10], [720, 200], [705, 420], [690, 520], [620, 600], [560, 600], [480, 560], [400, 420], [330, 380], [318, 300]]), '#0f0e10');
    fillA(rust, lin(0, 0, 0, H, [[0, '#93492e'], [0.4, '#874029'], [0.75, '#783624'], [1, '#6a2e1e']]));
    soft(14, () => fillA(sm([[362, 448], [430, 432], [500, 446], [570, 478], [645, 520], [652, 600], [610, 640], [560, 610], [520, 560], [470, 590], [400, 600], [356, 560]]), '#5a2218'));
    strokeA(line([[790, -10], [762, 32], [746, 64], [728, 98], [706, 128], [674, 157], [630, 172], [580, 174], [530, 176], [496, 188], [458, 210], [410, 236], [368, 260], [338, 290]]), '#3b3a3c', 50);
    strokeA(line([[812, -10], [786, 40], [766, 80], [744, 116], [718, 148], [682, 178], [634, 196], [580, 199], [532, 201], [500, 212], [464, 234], [418, 260], [380, 284]]), '#e8cbc2', 4);
    for (const pts of [[[700, 196], [738, 164], [772, 140], [796, 104]], [[708, 206], [746, 176], [780, 152], [806, 116]]]) strokeA(line(pts), 'rgba(40,14,8,0.6)', 2.5);
    // brushed texture over everything so far
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float s = vnoise(vec2(p.x * 0.012, p.y * 0.55)) * .6 + vnoise(vec2(p.x * 0.03, p.y * 1.3)) * .4;
      return vec3(.5 + (s - .5) * .16 + (hash(p) - .5) * .05); }`), a, 1, 'overlay');

    // ── fingerprint swirl (top right) ──
    const fpP = sm([[855, -10], [1034, -10], [1034, 222], [980, 214], [940, 211], [900, 199], [873, 172], [858, 120], [851, 60]]);
    R.dome(fpP, '#f0ebe4', 0.04, 0.05, 6, 3);
    clipA(sm([[861, -10], [1034, -10], [1034, 214], [980, 207], [940, 204], [903, 192], [879, 167], [865, 118], [858, 60]]), () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(955.93, 112.93); float c = cos(0.1793), s = sin(0.1793);
      float u = min(d.x * c + d.y * s, 0.), v = (-d.x * s + d.y * c) * 1.0756, dd = length(vec2(u, v));
      float f = dd / 23.295 + 0.3121 + 0.0241 * sin(dd / 40.) + 0.1854 * cos(v / 30.) + 0.08 * (fbm(p * 0.02) - .5);
      return mix(vec3(.05, .045, .05), vec3(.94, .92, .89), smoothstep(0.05, 0.3, cos(6.2832 * f))); }`)));

    // ── spiral discs ──
    const spiral = (cx, cy, e, Pd, k, ph, cB, cW, duty) => E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(${cx.toFixed(2)}, ${cy.toFixed(2)}); d.y *= ${e.toFixed(4)};
      float f = length(d) / ${Pd.toFixed(3)} + ${k.toFixed(1)} * atan(d.y, d.x) / 6.2832 + ${ph.toFixed(3)};
      float v = cos(6.2832 * f);
      return mix(vec3(${cB}), vec3(${cW}), smoothstep(${duty.toFixed(2)} - .12, ${duty.toFixed(2)} + .12, v)); }`);
    // big spiral, bottom right
    soft(12, () => fillA(ellipseP(816, 580, 134, 152, 0), 'rgba(30,8,4,0.35)'));
    R.dome(ellipseP(823, 568, 133, 152, 0), '#efe9e2', 0.06, 0.06, 10, 3);
    clipA(ellipseP(823, 570, 121, 139, 0), () => img(spiral(816.4, 581.2, 0.9116, 25.17, 1, 0.916, '.06, .055, .06', '.93, .91, .88', 0.3)));
    // small spiral, centre left, with a red glow
    soft(10, () => strokeA(ellipseP(419, 522, 58, 62, 0), 'rgba(205,60,30,0.85)', 12));
    R.dome(ellipseP(419, 521, 55, 59, 0), '#f2ede6', 0.06, 0.05, 8, 3);
    clipA(ellipseP(419, 521, 49, 53, 0), () => img(spiral(418.6, 524.3, 1.0, 10.4, 1, -0.33, '.07, .06, .07', '.95, .93, .9', 0.1)));
    // pink spiral on the grey
    R.dome(ellipseP(222, 502, 61, 62, 0.1), '#eec4c8', 0.04, 0.04, 6, 3);
    clipA(ellipseP(222, 502, 56, 57, 0.1), () => img(spiral(222.7, 507, 0.8837, 9.0, 2, -0.47, '.12, .07, .1', '.92, .7, .74', -0.15)));

    // ── left white scroll behind the pearl cluster ──
    R.dome(sm([[338, 352], [334, 300], [352, 262], [392, 244], [440, 238], [486, 250], [476, 278], [444, 272], [424, 300], [430, 342], [416, 384], [384, 404], [350, 396], [356, 378]]), '#ece4dc', 0.08, 0.06, 6, 3);
    fillA(sm([[350, 330], [356, 296], [380, 278], [404, 284], [410, 330], [400, 368], [372, 384], [356, 366]]), '#141316');
    R.pipe(line([[352, 384], [370, 376], [372, 392]]), 10, '#f0d8d4', 0.1, 0.06, 3);
    // pink swirl blob above the shield
    R.dome(ellipseP(530, 232, 32, 32, 0), '#d9a6c6', 0.1, 0.05, 8, 3);
    clipA(ellipseP(530, 232, 28, 28, 0), () => img(spiral(532, 236, 1.0, 9.0, 1, 0.2, '.85, .62, .78', '.96, .9, .92', 0.2)));

    // ── monster ──
    // crown spikes (white) behind the head
    const crown = []; for (let i = 0; i <= 22; i++) { const t = Math.PI * (1.08 + i * 0.84 / 22), r = i % 2 ? 92 : 112; crown.push([628 + Math.cos(t) * r * 0.95, 292 + Math.sin(t) * r]); }
    R.flat(poly([[548, 300], ...crown, [712, 300]]), '#f4efea', 0.12, 3);
    // torso
    R.flat(poly([[545, 368], [702, 368], [702, 470], [664, 506], [560, 506], [538, 462]]), '#1d1d22', 0.12, 3);
    for (const y of [390, 411, 432, 454]) R.dome(rrect(562, y, 86, 16, 7), '#f8e2de', 0.16, 0.04, 4, 6);
    // head
    const head = sm([[548, 300], [556, 248], [584, 210], [628, 198], [672, 212], [700, 250], [710, 300], [706, 350], [690, 372], [628, 378], [566, 372], [550, 350]]);
    R.dome(head, rad(610, 260, 130, [[0, '#4d58c6'], [1, '#3a43a8']]), 0.16, 0.1, 22, 1);
    { const sp = []; for (let i = 0; i <= 16; i++) { const t = Math.PI * (1.12 + i * 0.76 / 16), r = i % 2 ? 70 : 96; sp.push([628 + Math.cos(t) * r, 300 + Math.sin(t) * r * 1.05]); }
      clipA(head, () => R.paint(poly([[540, 300], ...sp, [716, 300], [716, 160], [540, 160]]), '#f4efea')); }
    a.lineJoin = 'miter';
    R.pipe(P([[552, 352], [567, 374], [582, 346], [598, 374], [613, 344], [629, 374], [645, 344], [661, 374], [676, 347], [691, 370], [704, 344]], false, false), 7, '#f6f2ee', 0.26, 0.03, 3);
    a.lineJoin = 'round';
    R.dome(ellipseP(608, 292, 24, 40, 0), '#d7a9d9', 0.26, 0.04, 6, 3);
    R.dome(ellipseP(608, 292, 13, 27, 0), '#f2c290', 0.3, 0.04, 6, 3);
    // shield
    const shield = sm([[432, 280], [466, 262], [520, 258], [556, 270], [562, 304], [556, 350], [538, 386], [504, 402], [470, 396], [444, 374], [432, 330]]);
    R.dome(shield, '#2d3437', 0.16, 0.05, 8, 3);
    strokeA(shield, '#e6a28c', 3);
    R.flat(sm(blob(496, 332, 50, 46, 7, 16, 0.12)), '#4a7c80', 0.2, 3);
    { const r = rng(202); for (let i = 0; i < 70; i++) { const x = 440 + r() * 115, y = 270 + r() * 125; if (a.isPointInPath(shield, x * S, y * S)) fillA(circleP(x, y, r() < 0.3 ? 2.5 : 1.2), r() < 0.5 ? '#f4f0ee' : '#1a2224'); } }
    // arms, hands, leg
    R.pipe(line([[474, 398], [456, 424], [418, 422], [386, 396]]), 30, '#3c46b6', 0.2, 0.12, 1);
    R.pipe(line([[688, 404], [736, 414], [784, 406]]), 30, '#3c46b6', 0.2, 0.12, 1);
    R.pipe(line([[690, 438], [706, 468], [718, 494]]), 26, '#3c46b6', 0.2, 0.1, 1);
    for (const [x, y, s] of [[366, 382, -1], [794, 400, 1]]) R.dome(poly([[x - 12 * s, y + 10], [x, y - 16], [x + 4 * s, y - 2], [x + 16 * s, y - 10], [x + 10 * s, y + 6], [x + 14 * s, y + 16], [x - 4 * s, y + 14]]), '#f2e2dc', 0.22, 0.04, 4, 3);
    R.bead(722, 498, 8, '#f0d8d0', 0.22, 0.04, 3);
    R.pipe(line([[736, 352], [742, 328], [764, 318], [778, 334], [764, 352], [748, 364], [752, 382]]), 12, '#f4ece8', 0.22, 0.05, 3);
    strokeA(line([[742, 334], [764, 326], [770, 338], [756, 352]]), '#e48aa4', 3);
    R.pipe(line([[584, 518], [570, 566], [561, 616], [558, 660], [562, 684]]), 34, '#a3291f', 0.18, 0.14, 1);
    R.dome(sm([[544, 682], [562, 674], [580, 682], [584, 696], [562, 700], [540, 696]]), '#f2b47e', 0.22, 0.04, 5, 3);
    R.bead(580, 512, 20, '#18171a', 0.2, 0.1, 3);
    R.dome(ellipseP(646, 565, 19, 36, 0), '#f2eee8', 0.16, 0.12, 14, 3);
    R.bead(521, 420, 9, '#f4f2f0', 0.2, 0.05, 3);
    for (const pts of [[[488, 410], [494, 446]], [[540, 450], [548, 470], [556, 452], [566, 488]], [[640, 486], [676, 470]]]) strokeA(line(pts), '#d8d4d0', 1.6);

    // ── chrome pearls ──
    const pearl = (x, y, r, c) => R.bead(x, y, r, lin(x, y - r, x, y + r, [[0, mixHex(c, '#ffffff', 0.5)], [0.42, c], [0.52, mixHex(c, '#000000', 0.45)], [0.75, mixHex(c, '#000000', 0.2)], [1, mixHex(c, '#ffffff', 0.15)]]), 0.3, 0.3, 5);
    R.dome(circleP(500, 478, 38), '#e89a50', 0.2, 0.12, 12, 1);
    for (const [x, y, r, c] of [[318, 212, 35, '#9a9a88'], [310, 303, 30, '#949482'], [365, 276, 30, '#a4bccb'], [410, 305, 23, '#acc4d0'], [366, 320, 18, '#a8c0cc'], [800, 188, 30, '#a4b8bc'], [759, 262, 30, '#a6c0d0'], [955, 287, 32, '#a6c0d0'], [863, 337, 30, '#a6c0d0'], [818, 590, 33, '#a6c0d0'], [497, 323, 22, '#8aa6b4'], [500, 478, 25, '#a6c0d0']]) pearl(x, y, r, c);

    // ── pink and white droplets ──
    for (const [x, y, r] of [[160, 213, 7], [150, 262, 8], [167, 343, 3], [146, 418, 3], [110, 466, 4], [155, 506, 6], [162, 582, 8], [236, 606, 5], [262, 637, 8], [198, 690, 4], [368, 664, 8], [672, 708, 8], [404, 34, 4], [124, 468, 3], [300, 562, 3]])
      R.bead(x, y, r, '#eeb0bc', 0.05, 0.06, 6);
    { const r = rng(9); for (let i = 0; i < 40; i++) { const x = r() * 400, y = 130 + r() * 590; R.bead(x, y, 1 + r() * 1.6, '#e8e4e4', 0.03, 0.03, 6); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.35, coat: 0.25, rim: 0.3 }),          // 1 glossy plastic
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.6, emis: 0.05 }),                      // 3 paper cutouts
        E.mat({}),
        E.mat({ dif: 0.85, spec: 1.4, shin: 90, metal: 0.4, coat: 0.35, wrap: 0.4, emis: 0.15 }),  // 5 chrome pearls
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.5, emis: 0.1 })                         // 6 droplets
      ],
      light: [-0.35, 0.6, 0.72], lc: [0.75, 0.75, 0.78], amb: [0.33, 0.33, 0.35],
      envTop: [1.1, 1.1, 1.15], envHor: [0.4, 0.46, 0.52], envBot: [0.06, 0.06, 0.08], envK: [0.5, 1.2, 0.3, 0],
      r1: 1.4, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-6, 8, 0.75, 7]
    });
    E.grain(0.04, 202);
  }
});
