'use strict';
// u048 — "Gold slabs at dusk": a molten-gold frame around a pink-blue dusk — red clouds, a blue liquid pool holding two
// gold slabs, lens flares, a zebra ripple and a moonlit road with grass tufts — set in a snowy starfield.
REC.register('u048', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const specks = (path, n, seed, col, rmax = 1.1, x0 = 0, y0 = 0, w = 726, h = 1024) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.35 + r() * 0.65; a.beginPath(); a.arc(x0 + r() * w, y0 + r() * h, 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const ALL = poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034]]);

    // ── frame outline (wobbly rounded rectangle) ──
    const FR = [[96, 92], [200, 88], [300, 88], [400, 86], [500, 88], [600, 90], [640, 104], [652, 140], [650, 220], [660, 320], [668, 420], [672, 520], [676, 620],
      [678, 720], [676, 820], [662, 880], [620, 906], [520, 910], [400, 908], [300, 910], [200, 906], [120, 896], [70, 860], [50, 780], [46, 680], [46, 560], [48, 440],
      [46, 320], [48, 200], [54, 130]];
    const FRP = sm(FR);

    // ── night sky + snow ──
    R.flat(ALL, '#141018', 0, 0);
    soft(x => { fill(ellipseP(80, 20, 120, 40, 0), 'rgba(160,70,90,0.7)', x); fill(ellipseP(560, 10, 200, 30, 0), 'rgba(150,60,80,0.7)', x); fill(ellipseP(700, 120, 40, 60, 0), 'rgba(150,60,80,0.6)', x); fill(ellipseP(20, 10, 40, 30, 0), 'rgba(90,110,200,0.8)', x); }, 18, 1);
    specks(ALL, 900, 2, '#e8e8f0', 0.9);
    { const r = rng(5); for (let i = 0; i < 260; i++) { const x = r() * 726, y = r() * 1024, rr = 2.5 + r() * r() * 11; if (x > 40 && x < 680 && y > 80 && y < 915) continue; fill(circleP(x, y, rr), rad(x - rr * 0.3, y - rr * 0.3, rr * 1.3, [[0, '#ffffff'], [0.7, '#f0f0f4'], [1, '#c8c8d0']])); } }

    // ── dusk sky inside the frame ──
    a.save(); a.clip(FRP);
    fill(ALL, lin(0, 90, 0, 510, [[0, '#a6ccec'], [0.18, '#b2d2f0'], [0.45, '#cac0d6'], [0.7, '#dcb0b8'], [1, '#eca6a2']]));
    // red clouds: lumpy crisp tops, darker undersides
    const cloud = (cx, cy, w, h, seed, n) => { const r = rng(seed), pp = new Path2D();
      for (let k = 0; k < n; k++) { const t = (k + 0.5) / n, rr = h * (0.22 + 0.42 * Math.sin(Math.PI * t)) * (0.7 + r() * 0.5), x = cx - w / 2 + w * t;
        pp.addPath(ellipseP(x, cy - rr * 0.5, rr * 1.1, rr, 0)); }
      pp.addPath(ellipseP(cx, cy - h * 0.04, w * 0.52, h * 0.16, 0));
      const cut = new Path2D(); cut.addPath(pp); return { pp, clip: poly([[cx - w, cy - h * 3], [cx + w, cy - h * 3], [cx + w, cy + h * 0.15], [cx - w, cy + h * 0.15]]) }; };
    for (const [cx, cy, w, h, sd, n] of [[150, 280, 190, 120, 1, 6], [290, 258, 210, 50, 2, 8], [384, 240, 100, 22, 3, 5], [100, 220, 80, 80, 4, 3], [186, 376, 130, 22, 5, 6],
      [560, 188, 170, 30, 6, 7], [580, 338, 150, 56, 7, 6], [640, 306, 50, 40, 8, 2], [520, 334, 80, 20, 9, 4]]) {
      const { pp: c, clip: cc } = cloud(cx, cy, w, h, sd, n);
      clipA(cc, () => { fill(c, '#b4404c'); clipA(c, () => soft(x => { fill(ellipseP(cx, cy + h * 0.05, w * 0.5, h * 0.3, 0), 'rgba(112,30,44,0.8)', x); fill(ellipseP(cx - w * 0.1, cy - h * 0.75, w * 0.3, h * 0.3, 0), 'rgba(222,124,134,0.55)', x); }, 7, 1)); });
    }
    // horizon hills
    fill(sm([[50, 500], [100, 488], [160, 480], [230, 478], [260, 500], [260, 520], [50, 520]]), '#3a3248');
    fill(sm([[560, 506], [620, 498], [680, 504], [680, 520], [560, 520]]), '#3a3248');
    // ground + road
    const GR = poly([[40, 512], [690, 512], [690, 920], [40, 920]]);
    fill(GR, lin(0, 512, 0, 920, [[0, '#7880a8'], [0.15, '#a0a8c8'], [1, '#aab2d2']]));
    // black side stripes (right) and dashed road lines converging to the vanishing point
    const VP = [372, 545];
    clipA(poly([[440, 560], [690, 560], [690, 900], [440, 900]]), () => {
      for (const [y0, x0, wd] of [[566, 470, 6], [586, 470, 7], [606, 470, 8], [632, 470, 10], [660, 480, 12], [690, 500, 13], [722, 520, 14], [758, 540, 16], [800, 560, 18], [846, 590, 20]])
        fill(poly([[x0 + (y0 - 560) * 0.2, y0], [690, y0 - 4], [690, y0 + wd - 2], [x0 + (y0 - 560) * 0.2, y0 + wd]]), '#121016');
    });
    for (const [bx, wd, dash] of [[372, 10, 1], [470, 9, 1], [560, 12, 1], [292, 8, 0], [250, 7, 0]]) {
      const t0 = 0.05;
      for (let t = t0; t < 1; t += 0.06) { const t1 = Math.min(1, t + 0.035 * (dash ? 1 : 1.6)), p0 = [VP[0] + (bx - VP[0]) * t * t * 0 + (bx - VP[0]) * t, VP[1] + (920 - VP[1]) * t], p1 = [VP[0] + (bx - VP[0]) * t1, VP[1] + (920 - VP[1]) * t1];
        stroke(line([p0, p1]), '#141218', wd * (0.3 + t)); }
    }
    // grass tufts along the lines
    { const r = rng(9);
      for (const bx of [300, 470, 700]) for (let t = 0.1; t < 1; t += 0.05) {
        const x = VP[0] + (bx - VP[0]) * t, y = VP[1] + (920 - VP[1]) * t, s = 8 + t * 46;
        fill(ellipseP(x, y - s * 0.3, s * 0.32, s * 0.5, 0), '#2a1a1c');
        for (let k = 0; k < 9; k++) { const ang = -1.57 + (r() - 0.5) * 1.4; stroke(line([[x + (r() - 0.5) * s * 0.5, y], [x + Math.cos(ang) * s * 0.8, y - s * 0.2 + Math.sin(ang) * s * 0.8]]), r() < 0.5 ? '#3a2224' : '#5a3634', 1 + t * 2); }
      } }
    // blue liquid pool + swoosh
    const POOL = sm([[96, 470], [140, 500], [190, 520], [176, 580], [214, 640], [240, 700], [262, 770], [276, 700], [310, 640], [350, 580], [372, 548],
      [410, 590], [470, 580], [530, 600], [560, 640], [600, 610], [610, 560], [580, 540], [540, 548], [460, 550], [400, 540], [330, 500], [250, 470], [160, 470]]);
    fill(POOL, lin(0, 470, 0, 660, [[0, '#2c5cc0'], [0.5, '#2a64c8'], [1, '#2050b0']]));
    soft(x => { stroke(line([[200, 520], [300, 560], [380, 600]]), 'rgba(160,200,255,0.5)', 10, x); stroke(line([[420, 570], [520, 600], [580, 620]]), 'rgba(160,200,255,0.4)', 6, x); }, 6, 1);
    const SWB = [[214, -10], [180, 80], [150, 170], [124, 260], [106, 340], [98, 420], [100, 480], [120, 520], [160, 545], [200, 560]];
    stroke(line(SWB), '#141a40', 18);
    stroke(line(SWB.map(([x, y]) => [x + 12, y + 2])), '#eef0f8', 6);
    soft(x => fill(sm([[98, 300], [120, 280], [130, 380], [150, 460], [190, 520], [130, 520], [100, 470]]), '#1c3a9c', x), 3, 1);
    soft(x => fill(sm([[96, 400], [140, 420], [170, 470], [140, 500], [100, 490]]), '#2850b8', x), 6, 1);
    // smoke column
    soft(x => fill(sm([[402, -10], [438, -10], [444, 40], [456, 90], [446, 150], [440, 210], [448, 270], [450, 330], [436, 336], [428, 280], [422, 220], [418, 160], [406, 100], [400, 40]]), '#8a88d8', x), 2, 1);
    // zebra ripple (fitted)
    const RG = poly([[50, 580], [140, 585], [176, 580], [200, 640], [226, 700], [250, 760], [256, 800], [220, 840], [190, 870], [140, 890], [50, 890]]);
    const ZR = E.fx(`
      const vec2 ZC[23] = vec2[23](vec2(78., 608.), vec2(134., 608.), vec2(190., 608.), vec2(78., 664.), vec2(134., 664.), vec2(190., 664.), vec2(246., 664.), vec2(302., 664.), vec2(78., 720.), vec2(134., 720.), vec2(190., 720.), vec2(246., 720.), vec2(302., 720.), vec2(78., 776.), vec2(134., 776.), vec2(190., 776.), vec2(246., 776.), vec2(78., 832.), vec2(134., 832.), vec2(190., 832.), vec2(78., 888.), vec2(134., 888.), vec2(190., 888.));
      const float ZK[138] = float[138](-1.709, 2.701, 5.364, 1.555, 1.750, -4.561, -5.613, 4.281, 5.251, 0.270, -1.208, -4.049, -0.438, -0.035, 1.075, 0.242, 0.332, -1.566, 1.134, 3.229, 2.584, 1.056, -0.106, -0.398, -0.893, 3.259, 0.608, -0.360, -2.353, -4.419, -8.554, -1.636, 0.781, 1.294, 0.440, 2.696, -6.342, -0.037, 3.050, 0.234, -0.931, -0.199, -4.537, -0.268, 5.204, 1.992, 6.567, -4.485, 2.065, -2.651, 1.734, 0.099, 1.308, 1.704, -22.304, -2.318, 2.300, 0.506, 0.806, 0.827, -6.356, -1.274, 2.703, 1.365, 0.776, 0.297, 5.449, 0.355, 3.374, 1.126, 1.619, -0.021, -0.526, -0.443, -0.422, 4.064, -7.574, -1.137, 2.425, -2.339, 2.130, 0.073, 0.107, -1.014, 1.132, -2.019, 2.382, 0.551, 0.555, -0.513, 19.225, -0.785, 2.893, 1.467, 1.006, 0.048, 1.311, 1.294, 3.393, 2.052, 0.786, 0.182, 1.049, 1.567, 0.467, 0.259, -2.081, 1.932, 5.380, 1.990, 2.220, -0.779, -0.331, 0.834, 8.148, 1.131, 2.460, 0.145, 1.528, 1.448, -3.432, 1.697, 1.230, 0.384, -1.055, -3.703, -1.293, 1.826, 1.924, -0.440, -0.239, -1.211, 0.792, 1.235, 3.186, -1.385, 1.314, 0.282);
      float zv(vec2 p){ float s = 0., ws = 1e-4;
        for (int i = 0; i < 23; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.190);
          float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
          s += w * cos(6.283 * ph); ws += w; }
        return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.93, .94, .97), vec3(.06, .05, .08), smoothstep(-.15, .15, zv(p))); }`);
    clipA(RG, () => img(ZR));
    // white streams / cracks
    for (const [pts, w] of [[[[176, 580], [200, 640], [226, 700], [250, 760], [256, 800]], 10], [[[372, 545], [350, 600], [320, 660], [290, 720], [268, 790]], 14],
      [[[250, 640], [290, 650], [330, 660]], 6], [[[200, 560], [250, 500], [300, 470], [370, 450], [420, 380]], 8]]) {
      stroke(line(pts), '#121018', w + 4); stroke(line(pts), '#f2f4fa', w); }
    a.restore();

    // ── gold slabs ──
    const G1 = sm([[245, 345], [265, 322], [300, 318], [330, 326], [352, 336], [382, 330], [412, 340], [440, 352], [452, 382], [446, 422], [442, 470], [430, 500], [400, 520], [350, 530], [300, 526], [260, 506], [240, 470], [236, 420], [240, 380]]);
    R.dome(G1, lin(240, 320, 450, 530, [[0, '#d8c8a0'], [0.4, '#f0e2c0'], [0.7, '#e8d6b0'], [1, '#a88c5a']]), 0.2, 0.22, 26, 1);
    const G2 = sm([[420, 392], [440, 378], [480, 374], [520, 378], [560, 384], [594, 400], [604, 440], [602, 500], [598, 540], [580, 562], [540, 564], [480, 560], [440, 554], [420, 532], [416, 470], [418, 420]]);
    R.dome(G2, '#bca478', 0.22, 0.14, 10, 1);
    R.flat(sm([[446, 404], [480, 398], [540, 402], [578, 412], [584, 450], [580, 510], [570, 540], [520, 544], [470, 540], [444, 530], [438, 470], [440, 420]]), lin(440, 400, 580, 540, [[0, '#e4d2a8'], [1, '#c8b084']]), 0.3, 1);
    { const RIM = [[426, 400], [450, 382], [490, 378], [530, 382], [570, 390], [598, 412], [602, 450], [601, 490], [599, 530], [584, 558], [546, 563], [506, 561], [466, 558], [432, 548], [419, 516], [418, 476], [418, 436]];
      for (let k = 0; k < RIM.length; k++) { const p0 = RIM[k], p1 = RIM[(k + 1) % RIM.length], mx = (p0[0] + p1[0]) / 2, my = (p0[1] + p1[1]) / 2, ang = Math.atan2(p1[1] - p0[1], p1[0] - p0[0]), L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]);
        R.dome(ellipseP(mx, my, L * 0.55, 10, ang), lin(mx, my - 10, mx, my + 10, [[0, '#e8d4a8'], [1, '#9a7c48']]), 0.24, 0.12, 8, 1); } }
    stroke(line([[290, 445], [330, 452], [370, 446], [420, 455]]), '#3a2a18', 1.5);
    stroke(line([[385, 340], [380, 380], [372, 410]]), '#3a2a18', 1.5);
    R.dome(ellipseP(341, 105, 18, 7, 0), '#c8a868', 0.4, 0.06, 3, 1);

    // ── molten gold frame ──
    R.pipe(FRP, 22, '#dcb880', 0.3, 0.3, 2);
    clipA(P(lock([...FR, FR[0]], 22, 22), true, true), () => soft(x => { const r = rng(13);
      for (let i = 0; i < 160; i++) { const k = Math.floor(r() * FR.length), p = FR[k]; fill(ellipseP(p[0] + (r() - 0.5) * 40, p[1] + (r() - 0.5) * 40, 4 + r() * 12, 2 + r() * 4, r() * 3), r() < 0.55 ? '#fff0c8' : '#4a2a10', x); } }, 2, 1));

    // ── teal cracks ──
    for (const pts of [[[690, 250], [700, 300], [696, 340], [708, 380], [716, 420]], [[310, 920], [306, 960], [312, 1000], [306, 1034]], [[498, 930], [494, 970], [500, 1000], [492, 1034]], [[712, 690], [720, 740], [716, 780]], [[2, 770], [6, 800]]])
      { stroke(line(pts), '#78d0c0', 6); stroke(line(pts), '#e8fff8', 2); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.6, metal: 0.55, spec: 1.3, shin: 50, rim: 0.2, ao: 0.4, tint: [1.12, 1.02, 0.84], emis: 0.2, wrap: 0.3 }),   // 1 gold
        E.mat({ dif: 0.5, metal: 0.7, spec: 1.4, shin: 60, rim: 0.3, ao: 0.4, tint: [1.2, 1.0, 0.72], emis: 0.15 })                   // 2 molten gold frame
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.85, 0.85, 0.85], amb: [0.45, 0.45, 0.48],
      envTop: [1.05, 1.0, 0.95], envHor: [0.6, 0.55, 0.5], envBot: [0.15, 0.12, 0.1], envK: [0.5, 1.2, 0.3, 0],
      r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-5, 7, 0.45, 6]
    });

    // ── light beam + lens flares ──
    const flare = (x, y, r, k) => {
      const g = o.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(0.3, 'rgba(240,246,255,0.9)'); g.addColorStop(0.55, 'rgba(200,220,255,0.35)'); g.addColorStop(1, 'rgba(160,190,255,0)');
      o.fillStyle = g; o.fillRect(x - r, y - r, 2 * r, 2 * r);
      o.save(); o.globalCompositeOperation = 'screen';
      for (let i = 0; i < 12; i++) { const t = i / 12 * 6.283 + 0.13, L = (i % 2 ? 0.55 : 1) * r * k; const gg = o.createLinearGradient(x, y, x + Math.cos(t) * L, y + Math.sin(t) * L);
        gg.addColorStop(0, 'rgba(255,255,255,0.9)'); gg.addColorStop(1, 'rgba(200,220,255,0)'); o.strokeStyle = gg; o.lineWidth = 2.2; o.beginPath(); o.moveTo(x, y); o.lineTo(x + Math.cos(t) * L, y + Math.sin(t) * L); o.stroke(); }
      o.restore();
    };
    { const g = o.createLinearGradient(230, 1024, 256, 800); g.addColorStop(0, 'rgba(120,160,255,0.2)'); g.addColorStop(1, 'rgba(230,240,255,0.9)'); o.fillStyle = g; o.fill(poly([[214, 1034], [246, 1034], [262, 800], [250, 800]])); }
    flare(430, 352, 60, 2.0); flare(372, 540, 75, 2.2); flare(176, 576, 55, 2.0); flare(256, 800, 60, 2.0);
    E.grain(0.035, 11);
  }
});
