'use strict';
// s52 — "Leather sun head": a cracked tan leather ball-face with lavender spots and a golden
// petal halo, over fine black-and-white zebra fingerprint lines, green ground with red
// labyrinth coral and a white S-curve, and a glossy machine of pale-blue knobs on gold stalks.
REC.register('s52', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      const src = E.blur(c, blur);
      if (clip) { const m = src.getContext('2d'); m.setTransform(S, 0, 0, S, 0, 0); m.globalCompositeOperation = 'destination-in'; m.fillStyle = '#fff'; m.fill(clip); }
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(src, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); for (const [t, c] of st) g.addColorStop(t, c); return g; };
    const rad = (x, y, r, st, fx = x, fy = y) => { const g = a.createRadialGradient(fx, fy, 0, x, y, r); for (const [t, c] of st) g.addColorStop(t, c); return g; };

    // ── ground: green with red labyrinth coral (reaction-diffusion look) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#04c906', 0, 0);
    a.fillStyle = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float mid = smoothstep(420., 480., p.y) * (1. - smoothstep(600., 660., p.y)) * smoothstep(230., 280., p.x) * (1. - smoothstep(540., 600., p.x));
      float low = smoothstep(560., 620., p.y) * (1. - smoothstep(380., 430., p.x));
      float dens = 0.4 + 0.25 * smoothstep(420., 560., p.y) + 0.4 * mid + 0.25 * low;
      float sc = mix(1., 1.35, smoothstep(520., 700., p.y) * (1. - smoothstep(330., 420., p.x)));
      vec2 q = p * sc; q += 40. * vec2(vnoise(q * 0.02), vnoise(q * 0.02 + 4.));
      float n = vnoise(q * 0.014) + 0.45 * vnoise(q * 0.03 + 5.) + 0.2 * vnoise(q * 0.06 + 9.);
      float v = abs(sin(n * 5.5 * 3.1416));
      float red = 1. - smoothstep(dens - 0.05, dens + 0.05, v);
      return mix(vec3(.02,.79,.03), vec3(.98,.05,.02), red); }`));
    a.fillRect(0, 0, 726, 1024);
    // blue sky (top)
    R.flat(P([[-10, -10], [540, -10], [520, 20], [470, 40], [420, 62], [300, 70], [120, 60], [40, 110], [-10, 110]], true, true), lin(0, 0, 0, 100, [[0, '#0490f4'], [1, '#1a98f0']]), 0, 0);
    // white S-curve stripe
    a.save(); a.strokeStyle = '#fbfdf8'; a.lineWidth = 22; a.lineCap = 'round';
    a.stroke(P([[505, -10], [510, 30], [560, 90], [578, 160], [560, 230], [506, 298]], false, true));
    a.stroke(P([[540, 470], [600, 466], [660, 440], [700, 390], [722, 300], [740, 220]], false, true));
    a.restore();
    // red lower-left field
    R.flat(P([[-10, 540], [20, 620], [50, 700], [100, 770], [170, 810], [190, 1040], [-10, 1040]], true, true), '#f81e08', 0, 0);

    // ── fine zebra fingerprint lines ─────────────────────────
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float t = smoothstep(260., 460., p.y + 0.3 * p.x);
      float f = mix(p.y + 0.12 * p.x, p.x + 0.2 * p.y, t) + 22. * fbm(p * 0.008) + 8. * fbm(p * 0.025 + 5.);
      float s = sin(6.2832 * f / 11.);
      float v = smoothstep(-0.05, 0.25, s);
      return mix(vec3(.01), vec3(.97,.98,.98), v); }`));
    const zL = P([[-10, 100], [60, 96], [140, 108], [120, 200], [140, 330], [200, 420], [250, 450], [320, 470], [382, 468], [384, 540], [340, 600], [270, 650], [220, 700], [170, 800], [110, 780],
      [60, 720], [20, 630], [-10, 560]], true, true);
    R.flat(zL, zeb, 0.02, 0);
    const zR = P([[418, 380], [450, 330], [500, 290], [530, 300], [548, 360], [546, 420], [520, 450], [470, 455], [420, 430]], true, true);
    R.flat(zR, zeb, 0.02, 0);

    // ── golden petal halo + flare ────────────────────────────
    const petal = (pts, c) => R.dome(P(pts, true, true), c, 0.05, 0.12, 30, 3);
    petal([[36, 40], [60, 4], [150, -6], [220, 20], [200, 90], [150, 126], [80, 130], [40, 100]], lin(40, 0, 200, 130, [[0, '#dcb050'], [0.6, '#c89430'], [1, '#b07820']]));
    petal([[230, -10], [360, -10], [350, 30], [300, 50], [240, 40]], lin(230, 0, 360, 50, [[0, '#f0c050'], [1, '#d09030']]));
    a.save(); a.fillStyle = 'rgba(200,190,240,0.8)'; a.fill(ellipseP(80, 82, 22, 22, 0)); a.restore();
    soft(x => { x.fillStyle = '#ffd820'; x.beginPath(); x.arc(200, 40, 70, 0, 6.283); x.fill(); x.fillStyle = '#fff8a0'; x.beginPath(); x.arc(210, 40, 36, 0, 6.283); x.fill(); x.fillStyle = '#ffffff'; x.beginPath(); x.arc(215, 38, 16, 0, 6.283); x.fill(); }, 14, 1);

    // ── leather ball face ────────────────────────────────────
    const ball = ellipseP(324, 252, 214, 200, 0.05);
    R.dome(ellipseP(318, 258, 218, 200, 0.05), '#e02010', 0.05, 0.2, 60, 1);
    R.dome(ball, rad(360, 150, 330, [[0, '#fcec9c'], [0.25, '#f8cc6c'], [0.55, '#eaa850'], [0.85, '#d08838'], [1, '#a86820']], 420, 120), 0.08, 0.4, 150, 1);
    // soft lobes (the face's puffed cheeks)
    for (const [x, y, rx, ry] of [[250, 300, 120, 80], [420, 270, 100, 70], [330, 380, 110, 55]]) R.dome(ellipseP(x, y, rx, ry, 0), null, 0.36, 0.05, 60, 1);
    soft(x => { x.fillStyle = '#9a6a2a'; x.beginPath(); x.ellipse(200, 380, 90, 60, 0.5, 0, 6.283); x.fill(); }, 30, 0.35, 'multiply', ball);
    // lavender spots
    for (const [x, y, rx, ry] of [[226, 166, 36, 30], [402, 96, 36, 22]]) { a.save(); a.fillStyle = 'rgba(196,186,236,0.9)'; a.fill(ellipseP(x, y, rx, ry, 0)); a.restore(); }
    // cracks (mouth + seams)
    const crack = (pts, w0, w1) => { R.groove(P(pts, false, true), w0 + 4, null, 0.46, 0.2, 1); a.save(); a.fillStyle = '#140c06'; a.fill(P(lock(pts, w0, w1, 0.9), true, true)); a.restore(); };
    crack([[470, 150], [420, 164], [370, 186], [320, 200], [270, 214], [236, 232]], 18, 2);
    crack([[470, 234], [430, 252], [390, 272], [350, 284], [310, 292]], 12, 2);
    crack([[416, 372], [380, 388], [340, 392], [300, 386], [276, 376]], 12, 2);
    crack([[404, 214], [414, 256], [430, 300], [438, 340]], 5, 2);
    crack([[160, 120], [200, 108], [250, 94], [290, 88]], 3, 1);
    a.save(); a.strokeStyle = '#e8c050'; a.lineWidth = 2; a.setLineDash([6, 5]);
    a.stroke(P([[120, 180], [150, 120], [200, 100], [290, 84], [380, 90]], false, true)); a.stroke(P([[130, 330], [170, 400], [240, 440]], false, true)); a.restore();
    R.bead(237, 58, 14, '#d81010', 0.44, 0.1, 3); R.bead(237, 57, 5, '#401010', 0.52, 0.02, 3);

    // ── glossy machine: dark ring disc ───────────────────────
    R.dome(ellipseP(410, 1030, 262, 222, 0), '#101014', 0.1, 0.2, 40, 2);
    R.dome(ellipseP(412, 1044, 244, 176, 0), lin(0, 860, 0, 1024, [[0, '#f0e0d0'], [1, '#c8b0a0']]), 0.2, 0.1, 20, 2);
    R.dome(ellipseP(414, 1070, 226, 150, 0), '#1a1a22', 0.24, 0.1, 20, 2);
    R.dome(ellipseP(420, 1010, 110, 70, 0), '#26262e', 0.3, 0.08, 20, 2);
    // fuzzy puff balls
    const puff = (x, y, r) => {
      soft(z => { z.fillStyle = '#e8f4ff'; z.beginPath(); z.arc(x, y, r * 1.05, 0, 6.283); z.fill(); z.strokeStyle = '#f4faff'; z.lineWidth = 2; const pr = rng(x + y); for (let i = 0; i < 60; i++) { const t = pr() * 6.283, r0 = r * 0.8, r1 = r * (1.05 + pr() * 0.25); z.beginPath(); z.moveTo(x + Math.cos(t) * r0, y + Math.sin(t) * r0); z.lineTo(x + Math.cos(t) * r1, y + Math.sin(t) * r1); z.stroke(); } }, 1.5, 1);
      R.dome(circleP(x, y, r * 0.9), rad(x, y, r, [[0, '#dcecfc'], [0.7, '#a8c8e8'], [1, '#90b0d8']], x - r * 0.3, y - r * 0.3), 0.2, 0.2, r * 0.8, 4);
    };
    for (const [x, y, r] of [[380, 800, 40], [506, 812, 44], [620, 904, 50], [112, 906, 44], [650, 866, 30], [232, 1004, 40], [560, 1010, 36]]) puff(x, y, r);
    // gold stalks + knob heads
    const GOLD = lin(0, 0, 40, 40, [[0, '#fff0a0'], [0.4, '#e0a020'], [1, '#8a5a08']]);
    const stalk = (pts, w) => { R.pipe(P(pts, false, true), w, '#e8a820', 0.2, 0.2, 5); };
    stalk([[430, 690], [418, 780], [400, 860]], 28); stalk([[586, 650], [556, 740], [520, 850]], 28); stalk([[160, 750], [168, 850], [150, 1000]], 22); stalk([[700, 880], [680, 1000]], 20);
    for (const [x, y] of [[395, 858], [516, 850], [152, 930], [640, 960]]) R.dome(ellipseP(x, y, 26, 14, 0), '#e0a828', 0.3, 0.14, 10, 5);
    R.pipe(P([[430, 700], [420, 780], [406, 850]], false, true), 8, '#f8f8f8', 0.4, 0.06, 3);
    R.pipe(P([[584, 660], [556, 750], [526, 840]], false, true), 8, '#f8f8f8', 0.4, 0.06, 3);
    const knob = (x, y, r) => {
      R.dome(ellipseP(x, y, r * 1.05, r * 0.8, 0), lin(0, y - r * 0.8, 0, y + r * 0.8, [[0, '#d8e4f0'], [0.35, '#b8c4d4'], [0.5, '#384050'], [0.8, '#202630'], [1, '#606878']]), 0.3, 0.3, r * 0.7, 3);
      soft(z => { z.fillStyle = '#ffffff'; z.beginPath(); z.ellipse(x - r * 0.1, y - r * 0.35, r * 0.55, r * 0.3, 0, 0, 6.283); z.fill(); }, 3, 0.9);
    };
    knob(436, 646, 58); knob(594, 600, 48); knob(148, 702, 48); knob(444, 978, 58); knob(722, 850, 40);
    // pale blue balls + white tube (left)
    R.pipe(P([[96, 620], [70, 700], [30, 760], [6, 800]], false, true), 16, '#f4f8fc', 0.3, 0.12, 3);
    R.pipe(P([[14, 800], [20, 880], [50, 960], [100, 1040]], false, true), 16, '#f4f8fc', 0.3, 0.12, 3);
    for (const [x, y, r] of [[100, 580, 44], [40, 772, 46], [0, 140, 24]]) R.dome(circleP(x, y, r), rad(x, y, r, [[0, '#e8f6ff'], [0.7, '#a8d0f0'], [1, '#78a8d8']], x - r * 0.3, y - r * 0.4), 0.3, 0.3, r * 0.85, 3);
    // little gold squares + white dot on the green
    for (const [x, y, s_] of [[516, 488, 16], [538, 492, 10], [530, 456, 8]]) { a.fillStyle = '#f8f080'; a.fillRect(x - s_ / 2, y - s_ / 2, s_, s_); }
    a.fillStyle = '#ffffff'; a.fill(circleP(466, 561, 8));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 18, wrap: 0.35, ao: 0.6, grain: 0.3, rim: 0.3 }),      // 1 leather
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.2, coat: 0.25 }),                          // 2 lacquer ring
        E.mat({ dif: 1, spec: 1, shin: 70, wrap: 0.3, coat: 0.2, emis: 0.05 }),                 // 3 glossy knobs
        E.mat({ dif: 1, spec: 0.2, shin: 10, wrap: 0.6, emis: 0.15 }),                          // 4 fuzzy puffs
        E.mat({ dif: 0.8, spec: 1.2, shin: 60, metal: 0.6, wrap: 0.2, tint: [1, 0.85, 0.45] })  // 5 gold
      ],
      light: [-0.3, 0.6, 0.75], lc: [0.6, 0.58, 0.54], amb: [0.5, 0.5, 0.52],
      envTop: [1.1, 1.08, 1.0], envHor: [0.6, 0.62, 0.7], envBot: [0.15, 0.12, 0.1], envK: [0.3, 1.0, 0.3, 0],
      r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-8, 12, 0.5, 6]
    });
    E.bloom(0.2, 14);
    E.grain(0.03, 52);
  }
});
