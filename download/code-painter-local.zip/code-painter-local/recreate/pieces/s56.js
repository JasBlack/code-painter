'use strict';
// s56 — "Badge sheet": a 6×4 contact sheet of glossy psychedelic badges — molten discs
// pitted with holes, bubbles, eyes and faces (golden sponge, pink crater, iridescent glass,
// green monster, milk-white swirls, rainbow bubble) on flat coloured backgrounds.
REC.register('s56', {
  w: 1024, h: 683,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); for (const [t, c] of st) g.addColorStop(t, c); return g; };
    const rad = (x, y, r, st, fx = x, fy = y) => { const g = a.createRadialGradient(fx, fy, 0, x, y, r); for (const [t, c] of st) g.addColorStop(t, c); return g; };
    const CW = 1024 / 6, CH = 683 / 4;
    // [bg top-left, bg bottom-right, disc light, disc dark, rim, blobs [dx, dy, r, colour, kind], holes [n, colour]]
    // blob kinds: 0 glossy dome, 1 eye (dark pupil), 2 ring, 3 pit, 4 flat paint
    const cells = [
      ['#a8c878', '#6a8a48', '#b08a38', '#6a4a18', '#c89a40', [[-14, -24, 40, '#6e706a', 4], [-20, -14, 12, '#c8d8a8', 0], [16, 4, 10, '#6a7a82', 1], [0, 34, 26, '#a07020', 0]], [34, '#3a3a36']],
      ['#5a86b0', '#4a80a0', '#e8a0a8', '#b85060', '#f0b0b8', [[4, 4, 20, '#50302a', 3], [-26, -20, 14, '#4a9a90', 1], [24, -24, 11, '#3a3050', 3], [-10, 36, 10, '#8a3a40', 3], [32, 20, 10, '#e07070', 0]], [16, '#7a2a32']],
      ['#2f3034', '#2f3034', '#c6c4c4', '#6a6866', '#dcdcdc', [[-34, -22, 26, '#c87a28', 2], [-34, -22, 12, '#2a1a10', 3], [16, -12, 30, '#1a1a1a', 4], [22, 30, 24, '#101010', 4], [2, 46, 16, '#d8b860', 0], [-6, 12, 10, '#e8e8e8', 0]], [8, '#222222']],
      ['#10607a', '#1050a0', '#98b0a0', '#3a6a8a', '#50d0e0', [[-20, -22, 20, '#e8e040', 2], [30, 10, 14, '#f03070', 0], [-26, 24, 12, '#f03070', 0], [20, -30, 10, '#c040a0', 0], [0, 40, 12, '#50c070', 0], [26, 36, 10, '#f09030', 0]], [10, '#1a3a5a']],
      ['#24243a', '#2850b0', '#90a8c8', '#b06040', '#f09060', [[-26, -26, 20, '#50a060', 1], [-4, 26, 16, '#3060a0', 3], [26, -20, 12, '#20304a', 3], [30, 26, 14, '#3a70b0', 3], [0, 52, 26, '#d07a50', 4]], [12, '#2a3a60']],
      ['#fd3d4f', '#0c161b', '#3a58a0', '#1a2050', '#2a3470', [[-34, -26, 18, '#f0c030', 2], [-34, -26, 9, '#e03020', 0], [10, 10, 30, '#28306a', 4], [30, -10, 8, '#8ab0f0', 0], [0, 40, 12, '#4a60b0', 0]], [6, '#101838']],
      ['#fe3b58', '#030103', '#e0e4e8', '#707a80', '#a0a8ac', [[-20, -12, 22, '#101010', 4], [-18, -12, 10, '#f4f4f4', 0], [16, -6, 18, '#101010', 4], [16, -6, 7, '#f0f0f0', 0], [0, 26, 22, '#181818', 4], [0, 24, 10, '#e8e8e8', 4], [-50, 40, 16, '#2060d0', 0]], [10, '#303030']],
      ['#161132', '#080a17', '#a0d888', '#40804a', '#306080', [[-30, -6, 22, '#c05838', 0], [20, -26, 20, '#e8f090', 4], [26, 20, 22, '#f8f8a0', 4], [0, 42, 18, '#2a4a3a', 3], [-10, 30, 8, '#e04030', 0]], [10, '#6a2a20']],
      ['#3c61ac', '#5283c0', '#d8b888', '#7a5030', '#a88060', [[-20, -10, 30, '#c89858', 0], [18, -30, 14, '#b08050', 0], [10, 30, 14, '#402818', 3], [-22, 30, 10, '#402818', 3], [30, 10, 10, '#e0c090', 0]], [22, '#3a2414']],
      ['#b0a8aa', '#8d9295', '#f4a888', '#c04a40', '#60c0d0', [[0, 0, 30, '#f4e8e0', 4], [-30, 20, 16, '#e04a30', 0], [30, -10, 14, '#e05a40', 0], [-10, -32, 12, '#f08060', 0]], [14, '#101010']],
      ['#fd3c56', '#fb3c57', '#e84838', '#a03028', '#e8c0b0', [[0, -46, 42, '#e8bcac', 4], [-24, -46, 11, '#402020', 1], [24, -46, 11, '#402020', 1], [-20, 10, 14, '#301010', 3], [20, 26, 14, '#f0a0a0', 0]], [6, '#401010']],
      ['#385a63', '#40758e', '#c0a8e0', '#402a60', '#50d0a0', [[-26, -26, 18, '#e0e040', 0], [30, -26, 16, '#f03070', 0], [0, 8, 24, '#c8b0e8', 0], [0, 42, 24, '#0e2038', 4], [-12, 24, 8, '#e0f0a0', 0]], [10, '#302050']],
      ['#82b0ca', '#79a9c9', '#e09080', '#a05048', '#8a5a40', [[-30, -26, 18, '#6a1a20', 1], [30, 16, 18, '#f0c860', 0], [0, 16, 10, '#50b0c0', 0], [-50, 10, 22, '#6a4030', 4]], [8, '#6a2a2a']],
      ['#fdcdb9', '#221f32', '#a898b0', '#2a3a70', '#7040a0', [[-30, -16, 20, '#c03040', 0], [20, -30, 12, '#40a0e0', 0], [10, 20, 16, '#c0e090', 0], [-6, 36, 14, '#2a4080', 0], [36, 6, 10, '#f0a0c0', 0]], [12, '#1a1a3a']],
      ['#484752', '#0f0c10', '#a494a4', '#5a4c5c', '#6a5a6a', [[-26, -16, 14, '#5a4a5c', 3], [26, -16, 10, '#e0e060', 1], [0, 22, 24, '#8a7a8a', 0], [-40, 0, 7, '#c040ff', 0], [20, 12, 8, '#60f0a0', 0]], [14, '#3a2e3a']],
      ['#53737b', '#80958c', '#4a6a7e', '#0e2a3c', '#123446', [[-16, -20, 20, '#b8b8a8', 0], [16, 6, 16, '#c07070', 0], [22, -30, 10, '#e0e0e0', 0], [-20, 26, 12, '#8a7040', 2]], [10, '#08202e']],
      ['#2e2533', '#342b3b', '#8098b0', '#3a4a5c', '#8a9ab0', [[-26, -26, 28, '#e09a40', 1], [26, 26, 26, '#f07860', 4], [24, -30, 8, '#1a2028', 3]], [14, '#1a2028']],
      ['#1d2932', '#111f28', '#eee6ea', '#a8b0c0', '#f4f4f4', [[-10, -12, 20, '#e0a8a8', 4], [-6, 4, 8, '#303030', 3], [16, 16, 6, '#303030', 3], [20, -20, 14, '#e8e8f0', 0]], [6, '#8a8a98']],
      ['#abd9ef', '#2b3a40', '#4a90c8', '#1a3060', '#80e0f0', [[-26, -10, 20, '#8040b0', 0], [-24, -6, 9, '#f0f0f0', 0], [20, 20, 16, '#80e0f0', 0], [20, -26, 10, '#1a2a50', 3]], [12, '#0a1a3a']],
      ['#453e48', '#444355', '#e8b070', '#7a3a30', '#c08040', [[-16, -16, 26, '#f5e0a0', 0], [26, 16, 16, '#e07060', 0], [-20, 26, 12, '#6080c0', 0], [30, -20, 10, '#402020', 3]], [16, '#3a1a10']],
      ['#938ea0', '#83899c', '#7a98a8', '#10304a', '#325057', [[-16, -20, 22, '#f0c0d0', 0], [26, 6, 14, '#c05070', 0], [0, 26, 16, '#101820', 3], [-26, 30, 8, '#f0f0f0', 0]], [14, '#08182a']],
      ['#bbc1c4', '#28373a', '#e6e4ea', '#a0a8b8', '#f4f4f4', [[-20, -16, 24, '#d8d8e2', 0], [0, 12, 10, '#607080', 3], [16, 22, 6, '#505060', 3], [22, -4, 8, '#8090a0', 3]], [6, '#707888']],
      ['#fdd8c9', '#1d141c', '#f4d0c0', '#c08888', '#301830', [[-16, -20, 14, '#e03020', 2], [16, -20, 14, '#e03020', 2], [-16, -20, 6, '#f0d020', 0], [16, -20, 6, '#f0d020', 0], [0, 22, 26, '#2a2a70', 4], [0, -48, 8, '#f0f0f0', 0]], [4, '#301830']],
      ['#0301c3', '#0400b0', '#4a70e0', '#80209a', '#c0c8ff', [[-16, -10, 22, '#f0d040', 0], [-22, 16, 16, '#30a030', 0], [26, 16, 22, '#f09050', 0], [20, -26, 14, '#b090e0', 0], [0, 36, 14, '#c030a0', 0]], [6, '#202080']]
    ];
    const rr = rng(56);
    // marbled luminance (molten swirls) laid over each disc
    const marble = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p * 0.03; q += 1.6 * vec2(fbm(q + 3.), fbm(q + 8.));
      float v = fbm(q * 1.4);
      float l = 0.55 + 0.9 * (v - 0.5) + 0.25 * sin(v * 18.);
      return vec3(clamp(l, 0., 1.)); }`);
    cells.forEach(([bg0, bg1, d0, d1, rim, blobs, [nh, hc]], k) => {
      const i = k % 6, j = Math.floor(k / 6), x0 = i * CW, y0 = j * CH, cx = x0 + CW / 2 + (rr() - 0.5) * 8, cy = y0 + CH / 2 + (rr() - 0.5) * 8, rd = 82 + rr() * 6;
      a.save(); a.beginPath(); a.rect(x0, y0, CW + 0.5, CH + 0.5); a.clip(); R.h.save(); R.h.beginPath(); R.h.rect(x0, y0, CW + 0.5, CH + 0.5); R.h.clip();
      R.flat(rrect(x0, y0, CW + 1, CH + 1, 0), lin(x0, y0, x0 + CW, y0 + CH, [[0, bg0], [1, bg1]]), 0, 0);
      // outer glossy rim + molten disc
      R.dome(circleP(cx, cy, rd + 4), mixHex(rim, d1, 0.45), 0.05, 0.2, 8, 1);
      R.dome(circleP(cx, cy, rd), rad(cx, cy, rd, [[0, d0], [0.55, mixHex(d0, d1, 0.5)], [0.9, d1], [1, mixHex(d1, '#000000', 0.4)]], cx - rd * 0.3, cy - rd * 0.35), 0.15, 0.35, rd * 0.8, 1);
      a.save(); a.clip(circleP(cx, cy, rd)); R.h.save(); R.h.clip(circleP(cx, cy, rd));
      a.save(); a.globalCompositeOperation = 'overlay'; a.globalAlpha = 1; a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(marble, 0, 0); a.restore();
      for (const [dx, dy, r, c, kind] of blobs) {
        const x = cx + dx, y = cy + dy, p = P(blob(x, y, r, r * (0.85 + rr() * 0.3), 1000 + k * 17 + dx, 12, 0.12), true, true);
        if (kind === 4) { a.fillStyle = c; a.fill(p); }
        else if (kind === 3) R.dome(p, c, 0.4, -0.12, r * 0.8, 1);
        else if (kind === 2) { R.pipe(circleP(x, y, r * 0.8), r * 0.4, c, 0.4, 0.08, 1); }
        else { R.dome(p, c, 0.38, 0.12, r * 0.8, 1); if (kind === 1) { R.bead(x + r * 0.1, y, r * 0.45, '#101010', 0.48, 0.05, 1); a.fillStyle = '#ffffff'; a.fill(circleP(x - r * 0.1, y - r * 0.2, r * 0.15)); } }
      }
      // pits + bubbles scattered over the disc
      for (let n = 0; n < nh; n++) { const t = rr() * 6.283, q = Math.sqrt(rr()) * rd * 0.85, r = 2 + rr() * 5; R.dome(circleP(cx + Math.cos(t) * q, cy + Math.sin(t) * q, r), hc, 0.42, -0.1, r, 1); }
      for (let n = 0; n < 8; n++) { const t = rr() * 6.283, q = Math.sqrt(rr()) * rd * 0.9, r = 2 + rr() * 4; R.bead(cx + Math.cos(t) * q, cy + Math.sin(t) * q, r, mixHex(d0, '#ffffff', 0.4), 0.44, 0.06, 1); }
      // swirling cyan / light rivulets
      a.save(); a.strokeStyle = rgbaHex(mixHex(rim, '#ffffff', 0.5), 0.7); a.lineWidth = 2.5;
      for (let n = 0; n < 3; n++) { const t0 = rr() * 6.283; const pts = []; for (let m = 0; m < 6; m++) { const t = t0 + m * 0.5, q = rd * (0.45 + 0.35 * Math.sin(m + n)); pts.push([cx + Math.cos(t) * q, cy + Math.sin(t) * q]); } a.stroke(P(pts, false, true)); }
      a.restore();
      a.restore(); R.h.restore();
      // bubbles on the background around the badge
      for (let n = 0; n < 5; n++) { const t = rr() * 6.283, q = rd + 8 + rr() * 12, r = 3 + rr() * 6; R.bead(cx + Math.cos(t) * q, cy + Math.sin(t) * q, r, mixHex(rim, '#ffffff', 0.3), 0.3, 0.1, 1); }
      a.restore(); R.h.restore();
    });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.35, ao: 0.6, coat: 0.08, rim: 0.2 })   // 1 glossy molten badge
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.45, 0.45, 0.45], amb: [0.62, 0.62, 0.63],
      envTop: [1, 1, 1], envHor: [0.45, 0.45, 0.5], envBot: [0.1, 0.1, 0.12], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.3, 0.3, 0.35], rimD: [0, 1, 0],
      r1: 1.2, r2: 5, k: [0, 0.6, 0.4, 70], shadow: [-4, 5, 0.5, 6]
    });
    E.grain(0.03, 56);
  }
});
