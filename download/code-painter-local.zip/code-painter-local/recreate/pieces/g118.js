'use strict';
// g118 — "Smiley porthole plate": a tilted cream plate swept by black zebra stripes, a blue grinning face
// in a concrete porthole, glossy white pebbles and a molten blue-orange-magenta-yellow paint pool.
REC.register('g118', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };

    // ── textures ──
    const stripes = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = (p - vec2(315.1, 305.5)) / 100.; float u = q.x, v = q.y;
      float ph = 1.16006*v + -0.09537*v*v + 0.12565*v*v*v + -0.00281*v*v*v*v + -0.01608*v*v*v*v*v + 1.24817*u + -0.10890*u*v + 0.29383*u*v*v + -0.06263*u*v*v*v
        + -0.04779*u*v*v*v*v + -0.03593*u*u + 0.24872*u*u*v + -0.10043*u*u*v*v + -0.04886*u*u*v*v*v + 0.07486*u*u*u + -0.04305*u*u*u*v + -0.01936*u*u*u*v*v
        + 0.00021*u*u*u*u + -0.00779*u*u*u*u*v + -0.00520*u*u*u*u*u + 0.4758;
      float s = cos(6.2832 * ph);
      vec3 cream = vec3(.91, .885, .855) - 0.04 * smoothstep(300., 0., p.x + p.y * 0.3);
      float zone = smoothstep(8., -8., p.y - (700. - 0.33 * p.x));
      return mix(cream, mix(vec3(.07, .065, .065), cream, smoothstep(-0.55, -0.31, s)), zone); }`));
    // paint pool colours: soft blend of measured colour patches
    const paint = pat(E.fx(`
      const int N = 30;
      const vec2 PP[N] = vec2[N](vec2(240.,650.), vec2(300.,630.), vec2(160.,640.), vec2(100.,775.), vec2(60.,765.), vec2(22.,880.), vec2(195.,745.), vec2(175.,700.), vec2(630.,770.), vec2(700.,705.), vec2(700.,780.), vec2(650.,640.), vec2(710.,600.), vec2(330.,690.), vec2(300.,750.), vec2(420.,800.), vec2(250.,850.), vec2(150.,920.), vec2(60.,960.), vec2(20.,820.), vec2(400.,880.), vec2(110.,1000.), vec2(380.,730.), vec2(420.,640.), vec2(500.,700.), vec2(480.,800.), vec2(550.,650.), vec2(545.,600.), vec2(560.,820.), vec2(540.,740.));
      const vec3 PC[N] = vec3[N](vec3(0.97,0.42,0.04), vec3(0.96,0.44,0.09), vec3(0.96,0.54,0.13), vec3(0.97,0.39,0.04), vec3(0.94,0.41,0.08), vec3(0.82,0.29,0.06), vec3(0.98,0.83,0.11), vec3(0.94,0.78,0.25), vec3(0.98,0.85,0.13), vec3(0.98,0.84,0.12), vec3(0.91,0.78,0.22), vec3(0.97,0.42,0.05), vec3(0.96,0.39,0.18), vec3(0.25,0.35,0.77), vec3(0.23,0.38,0.77), vec3(0.15,0.41,0.78), vec3(0.04,0.34,0.69), vec3(0.03,0.36,0.76), vec3(0.02,0.36,0.76), vec3(0.03,0.35,0.77), vec3(0.15,0.40,0.77), vec3(0.03,0.36,0.76), vec3(0.16,0.40,0.79), vec3(0.61,0.34,0.76), vec3(0.61,0.35,0.75), vec3(0.40,0.37,0.76), vec3(0.96,0.30,0.51), vec3(0.75,0.38,0.66), vec3(0.76,0.52,0.67), vec3(0.91,0.31,0.56));
      vec3 fx(vec2 uv, vec2 p){
        vec3 s = vec3(0.); float ws = 0.;
        vec2 q = p + 22. * vec2(fbm(p * 0.009) - .5, fbm(p * 0.009 + 3.) - .5);
        for (int i = 0; i < N; i++) { vec2 d = q - PP[i]; float w = exp(-dot(d, d) / (2. * 27. * 27.)) + 1e-12; s += w * PC[i]; ws += w; }
        return s / ws; }`));
    const concrete = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.25) * .6 + vnoise(p * 0.9) * .4; float d = step(0.82, hash(floor(p / 1.5)));
      vec3 c = mix(vec3(.42, .40, .39), vec3(.80, .78, .76), n); return c * (1. - .4 * d); }`));
    const glitter = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float h = hash(floor(p / 1.4)); return vec3(.45, .43, .41) + (h - .5) * .35; }`));

    // ── dark backdrop ──
    { const g = a.createRadialGradient(0, 420, 10, 0, 300, 420); g.addColorStop(0, '#4a464c'); g.addColorStop(0.5, '#1e1c20'); g.addColorStop(1, '#0a090a');
      R.flat(rrect(-10, -10, 746, 1044, 0), g, 0, 0); }

    // ── the plate ──
    const PLATE = [[232, -10], [222, 30], [203, 52], [108, 93], [64, 139], [47, 189], [54, 243], [50, 269], [0, 337], [-10, 345], [-10, 1034], [421, 1034], [575, 940], [736, 828], [736, -10]];
    R.dome(P(PLATE, true, true), stripes, 0.04, 0.1, 30, 1);
    // glitter rim band + white lip at the top-left edge
    const RIM = [[-10, 340], [24, 300], [40, 262], [44, 205], [56, 150], [100, 100], [196, 58], [214, 36], [226, -10]];
    R.pipe(P(RIM, false, true), 34, glitter, 0.08, 0.06, 2);
    R.pipe(P(RIM.map(([x, y]) => [x + 22, y + 10]), false, true), 18, '#e8e4e0', 0.1, 0.06, 1);
    // plate side and corner at the bottom right
    { const sg = a.createLinearGradient(560, 930, 620, 1010); sg.addColorStop(0, '#6a5a52'); sg.addColorStop(1, '#4a3c36');
      R.flat(P([[421, 1034], [575, 940], [736, 828], [736, 916], [575, 1034]], true, false), sg, 0.02, 0); }
    R.flat(P([[575, 1034], [736, 916], [736, 986], [670, 1034]], true, false), '#050505', 0.0, 0);
    R.flat(P([[670, 1034], [736, 986], [736, 1034]], true, false), '#7e7a7c', 0.0, 0);
    soft(x => { x.strokeStyle = '#fbf6ee'; x.lineWidth = 7; x.stroke(P([[415, 1030], [575, 934], [736, 822]], false, true)); }, 2.5, 0.9);

    // ── paint: top-left yellow + cyan drip, top-right orange ──
    soft(x => { x.strokeStyle = '#ecd02a'; x.lineWidth = 34; x.lineCap = 'round'; x.stroke(P([[104, 212], [104, 160], [140, 122], [200, 96], [244, 70], [264, 40], [268, -10]], false, true)); }, 2);
    const CY = [[181, 131], [168, 145], [145, 138], [115, 145], [139, 143], [135, 177], [155, 165], [167, 167], [176, 185], [175, 205], [157, 232], [124, 252], [107, 268], [78, 319], [55, 339], [62, 345], [102, 317], [166, 289], [196, 258], [205, 237], [210, 192], [227, 179], [215, 174], [201, 153], [180, 163], [166, 149], [183, 143]];
    R.dome(P(CY, true, true), '#14b0e8', 0.14, 0.03, 4, 2);
    R.dome(ellipseP(131, 212, 14, 9, -0.4), '#f05a14', 0.14, 0.03, 4, 2);
    const OR = [[597, -10], [637, 16], [648, 30], [662, 70], [652, 100], [628, 128], [606, 150], [606, 176], [636, 207], [666, 193], [693, 205], [736, 197], [736, -10]];
    R.dome(P(OR, true, true), '#f8620c', 0.14, 0.03, 4, 2);

    // ── paint pool ──
    const POOL = [[736, 520], [560, 560], [470, 575], [400, 592], [321, 621], [246, 601], [207, 605], [175, 620], [151, 646], [147, 669], [183, 707], [187, 763], [154, 818], [124, 826], [110, 817], [115, 800], [153, 751], [153, 733], [137, 718],
      [108, 720], [59, 755], [39, 758], [-10, 749], [-10, 914], [41, 904], [50, 916], [41, 944], [46, 952], [24, 993], [20, 1034], [165, 1034], [173, 986], [164, 968], [181, 933], [295, 895], [357, 901], [400, 928], [448, 924], [470, 910], [498, 875],
      [506, 878], [545, 852], [624, 825], [736, 767]];
    R.dome(P(POOL, true, true), paint, 0.14, 0.04, 10, 2);
    clipA(P(POOL, true, true), () => soft(x => { x.strokeStyle = '#f06018'; x.lineWidth = 14; x.stroke(P([[20, 1034], [24, 993], [46, 952], [41, 944], [50, 916], [41, 904], [-10, 914]], false, true));
      x.stroke(P([[165, 1034], [173, 986], [164, 968], [181, 933], [295, 895], [357, 901], [400, 928], [448, 924], [470, 910], [498, 875]], false, true)); }, 3, 0.9));

    // ── porthole housing ──
    const HOUSE = [[318, 330], [400, 288], [500, 252], [600, 232], [736, 210], [736, 540], [640, 560], [560, 575], [480, 592], [400, 604], [338, 606], [316, 566], [312, 460], [314, 390]];
    R.dome(P(HOUSE, true, true), '#ece8e4', 0.2, 0.08, 18, 1);
    for (const [x, y, rx, ry] of [[370, 380, 10, 8], [357, 415, 4, 4], [357, 462, 5, 5]]) R.flat(ellipseP(x, y, rx, ry, 0), '#141010', 0.12, 0);
    // glass ring, concrete, blue face
    R.dome(ellipseP(566, 390, 176, 140, -0.22), '#b0c4d6', 0.28, 0.05, 10, 3);
    R.dome(ellipseP(564, 392, 160, 128, -0.22), concrete, 0.26, 0.04, 6, 4);
    R.dome(ellipseP(555, 384, 114, 103, -0.18), '#2e72cc', 0.32, 0.06, 12, 3);
    const MOUTH = P([[468, 372], [520, 383], [600, 386], [636, 382], [632, 412], [604, 442], [552, 458], [500, 448], [474, 414]], true, true);
    R.pipe(MOUTH, 12, '#38b4ec', 0.36, 0.04, 3);
    R.flat(MOUTH, '#050506', 0.3, 0);
    R.dome(ellipseP(516, 463, 26, 12, -0.15), '#f2601a', 0.34, 0.06, 8, 3);
    for (const [x, y, rx, ry] of [[530, 330, 33, 30], [604, 343, 34, 30]]) {
      R.dome(ellipseP(x, y, rx, ry, 0), '#f2f0ee', 0.36, 0.1, 12, 3);
      R.dome(circleP(x - 2, y - 2, rx * 0.4), '#141212', 0.46, 0.04, 6, 3);
      R.bead(x - 2, y + 4, 4, '#c89a30', 0.5, 0.02, 3);
    }
    { const sr = rng(4); for (let i = 0; i < 14; i++) R.bead(560 + sr() * 90, 300 + sr() * 70, 2 + sr() * 4, '#d8e4f4', 0.36, 0.04, 3); }

    // ── glossy white pebbles ──
    const PEB = [[225, 506, 92, 56, -0.33], [316, 770, 86, 56, -0.25], [608, 562, 72, 44, -0.32], [468, 625, 34, 25, -0.3], [378, 232, 54, 31, -0.2], [682, 132, 62, 46, -0.2],
      [665, 213, 28, 21, -0.2], [716, 232, 28, 24, 0], [14, 448, 34, 30, 0], [250, 133, 46, 36, -0.25]];
    for (const [x, y, rx, ry, rot] of PEB) R.dome(ellipseP(x, y, rx, ry, rot), '#e8e6e8', 0.22, 0.22, Math.min(rx, ry) * 0.9, 3);
    R.dome(P([[306, 300], [340, 286], [380, 296], [412, 300], [436, 310], [438, 330], [410, 340], [384, 326], [350, 324], [310, 320]], true, true), '#e8e6e8', 0.26, 0.14, 16, 3);
    R.dome(P([[360, 492], [372, 500], [384, 530], [404, 560], [398, 592], [360, 598], [322, 588], [318, 556], [340, 540], [350, 510]], true, true), '#e8e6e8', 0.26, 0.16, 18, 3);
    R.dome(ellipseP(466, 550, 30, 18, 0.35), '#f05a10', 0.24, 0.08, 10, 3);
    R.flat(ellipseP(288, 460, 12, 10, 0), '#0a0808', 0.3, 0);
    // the eye pebble's pupil
    R.dome(ellipseP(244, 128, 20, 18, -0.2), '#0c0a0a', 0.42, 0.06, 8, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.6, coat: 0.05 }),                  // 1 cream ceramic
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.4, ao: 0.4, coat: 0.2 }),                    // 2 glossy paint
        E.mat({ dif: 1, spec: 1.3, shin: 90, wrap: 0.35, ao: 0.5, coat: 0.3 }),                   // 3 glossy pebbles
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.4, ao: 0.6, grain: 0.3 })                    // 4 concrete
      ],
      light: [0.45, 0.6, 0.66], lc: [0.55, 0.54, 0.52], amb: [0.5, 0.5, 0.5],
      envTop: [1, 1, 1], envHor: [0.6, 0.58, 0.56], envBot: [0.2, 0.18, 0.18], envK: [0.2, 0.9, 0.3, 0],
      rimC: [0.2, 0.2, 0.2], rimD: [0, 1, 0], r1: 1.6, r2: 9, k: [0, 0.6, 0.4, 90], shadow: [7, 8, 0.6, 6]
    });
    E.bloom(0.08, 8);
    E.grain(0.02, 118);
  }
});
