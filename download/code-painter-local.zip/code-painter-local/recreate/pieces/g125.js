'use strict';
// g125 — "Zebra-spined beast": a tan leather creature head with a sly eye and white teeth biting a dark spine
// crowned with white vertebrae, a striped body below, a blurred zebra horn and a pink-cyan-blue sky with a white moon.
REC.register('g125', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H], al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    const WH = '#ececf0';

    // ── blurred sky: blue, lavender, pink, cyan, magenta, pale blue bands ──
    const sky = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y + 0.04 * p.x;
      vec3 c = mix(vec3(.29,.55,.88), vec3(.42,.59,.9), smoothstep(0., 220., y));
      c = mix(c, vec3(.56,.6,.88), smoothstep(200., 250., y));
      c = mix(c, vec3(.8,.55,.86), smoothstep(255., 280., y));
      c = mix(c, vec3(.76,.95,.98), smoothstep(290., 318., y));
      c = mix(c, vec3(.64,.83,.98), smoothstep(345., 365., y));
      c = mix(c, vec3(.74,.56,.88), smoothstep(368., 385., y));
      c = mix(c, vec3(.98,.36,.77), smoothstep(385., 400., y));
      c = mix(c, vec3(.8,.78,.92), smoothstep(440., 462., y));
      c = mix(c, vec3(.72,.83,.95), smoothstep(462., 485., y));
      c = mix(c, vec3(.86,.87,.89), smoothstep(540., 620., y) * smoothstep(450., 600., p.x));
      c = mix(c, vec3(1., .99, .9), smoothstep(110., 0., length(p - vec2(0., 0.))));
      return c; }`);
    R.flat(all, '#88a8e0', 0, 0);
    img(sky);
    soft(x => { x.fillStyle = '#ffffff'; x.fill(circleP(186, 230, 48)); }, 4);
    soft(x => { x.fillStyle = '#e8e8f4'; x.fill(circleP(176, 218, 30)); }, 10, 0.6);
    // warm bokeh (bottom-left)
    soft(x => { const r = rng(3); for (let i = 0; i < 14; i++) { x.fillStyle = r() < 0.5 ? '#f0a020' : '#ffd060'; x.fill(circleP(20 + r() * 190, 700 + r() * 170, 10 + r() * 24)); } }, 10, 0.9);

    // ── blurred zebra horn (top-left) ──
    const horn = P([[96, -10], [214, -10], [190, 40], [150, 120], [100, 200], [60, 280], [30, 350], [8, 390], [-10, 400], [-10, 60], [40, 40]], true, true);
    R.flat(horn, '#eeeeee', 0.04, 0);
    clipA(horn, () => { a.fillStyle = '#1e1414';
      for (let i = -2; i < 12; i++) { const y0 = i * 44; a.fill(P([[-20, y0 + 6], [240, y0 + 6 + 110], [240, y0 + 30 + 110], [-20, y0 + 30]], true, false)); } });

    soft(x => { const g = x.createRadialGradient(10, 0, 10, 10, 0, 150); g.addColorStop(0, 'rgba(255,252,232,1)'); g.addColorStop(0.5, 'rgba(250,236,200,0.85)'); g.addColorStop(1, 'rgba(250,220,180,0)');
      x.fillStyle = g; x.fillRect(0, 0, 200, 160); }, 6);
    // warm dark ground behind the bones (bottom-left)
    soft(x => { x.fillStyle = '#7a6058'; x.fill(P([[-10, 830], [200, 860], [360, 940], [380, 1034], [-10, 1034]], true, true)); }, 20, 0.85);
    // dark brown hair under the shell (right)
    R.flat(P([[600, 300], [736, 270], [736, 440], [680, 430], [640, 400]], true, true), '#3a1a10', 0.05, 0);
    // ── thin background tubes (soft) ──
    soft(x => { x.strokeStyle = '#d8b4a8'; x.lineWidth = 9; x.lineCap = 'round';
      x.stroke(P([[600, 420], [540, 450], [505, 520], [508, 600], [540, 660], [600, 690], [660, 680]], false));
      x.stroke(P([[380, 640], [420, 690], [480, 700]], false)); }, 2, 0.9);

    // ── white tubes (top-right) ──
    const tube = (pts, wd) => R.pipe(P(pts, false), wd, WH, 0.3, 0.12, 2);
    tube([[736, 36], [700, 42], [676, 66], [666, 110], [676, 150], [700, 172], [736, 176]], 24);
    tube([[736, 206], [690, 208], [652, 224], [632, 262], [628, 320], [634, 390], [646, 470]], 22);
    tube([[648, 300], [668, 330], [700, 342], [736, 326]], 20);
    tube([[360, 18], [380, 4], [400, -10]], 18);

    // ── cranium shell + snout ──
    const shell = P([[338, 142], [332, 104], [344, 62], [372, 26], [410, -10], [736, -10], [736, 262], [700, 300], [640, 330], [580, 342], [546, 332], [522, 292], [482, 242], [424, 194], [374, 162]], true, true);
    R.dome(shell, radg(470, 60, 20, 360, [[0, '#f0d0a8'], [0.6, '#e4bf94'], [1, '#c89a70']]), 0.3, 0.28, 90, 1);
    a.save(); a.strokeStyle = 'rgba(140,90,50,0.6)'; a.lineWidth = 1.2;
    { const r = rng(5); for (let i = 0; i < 16; i++) { const x = 470 + r() * 220, y = 120 + r() * 180; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 40 + r() * 40, y - 30 - r() * 30); a.stroke(); } }
    a.restore();
    const snout = P([[338, 142], [374, 162], [424, 194], [482, 242], [522, 292], [546, 332], [540, 382], [510, 422], [470, 446], [400, 456], [330, 456], [296, 440], [278, 400], [272, 340], [280, 262], [302, 198]], true, true);
    R.dome(snout, radg(380, 290, 20, 220, [[0, '#f2c8a0'], [0.6, '#eab88a'], [1, '#d09868']]), 0.3, 0.3, 80, 1);
    R.groove(P([[338, 142], [374, 162], [424, 194], [482, 242], [522, 292], [546, 332]], false), 3, '#6a4020', 0.6, 0.05, 1, 0.9);
    // brown mane
    const mane = P([[530, 330], [600, 318], [652, 330], [634, 380], [590, 404], [544, 398]], true, true);
    R.dome(mane, '#8a5a3e', 0.32, 0.08, 14, 4);
    speck(mane, 260, 6, '#4a2a18', 1.2, [520, 310, 660, 410]);
    // eye
    R.dome(P([[388, 380], [410, 360], [440, 354], [462, 362], [452, 396], [424, 410], [398, 404]], true, true), '#c49068', 0.56, 0.04, 6, 1);
    R.dome(ellipseP(426, 386, 22, 20, 0), '#1a1414', 0.58, 0.06, 10, 5);
    R.dome(circleP(434, 380, 4), '#ffffff', 0.66, 0.02, 2, 5);
    R.groove(P([[392, 372], [414, 356], [446, 352], [464, 360]], false), 4, '#3a2418', 0.6, 0.04, 1);

    // ── teeth / cheeks (white) ──
    R.dome(P([[246, 400], [290, 408], [322, 438], [312, 462], [284, 452], [262, 428]], true, true), WH, 0.4, 0.12, 14, 2);
    R.dome(P([[480, 410], [540, 386], [590, 384], [596, 400], [550, 418], [500, 432]], true, true), WH, 0.4, 0.1, 10, 2);
    R.dome(ellipseP(436, 500, 70, 60, 0.1), '#c8b2b0', 0.4, 0.26, 50, 2);
    R.dome(ellipseP(332, 502, 46, 40, 0), WH, 0.42, 0.26, 36, 2);
    R.dome(ellipseP(296, 470, 24, 20, 0), WH, 0.42, 0.16, 18, 2);
    R.dome(ellipseP(384, 548, 34, 26, 0.3), WH, 0.42, 0.2, 22, 2);
    R.dome(ellipseP(450, 566, 44, 22, 0.2), '#d8cccc', 0.38, 0.16, 18, 2);

    // ── lower jaw + tusk ──
    const jaw = P([[78, 642], [110, 600], [170, 576], [250, 560], [330, 560], [386, 576], [404, 606], [380, 642], [330, 676], [262, 702], [190, 714], [140, 706], [96, 690]], true, true);
    R.dome(jaw, radg(200, 600, 20, 230, [[0, '#eec094'], [0.6, '#e0ac7c'], [1, '#b88050']]), 0.32, 0.28, 70, 1);
    R.groove(P([[140, 706], [150, 690], [160, 682]], false), 3, '#6a4020', 0.5, 0.05, 1);
    R.dome(P([[66, 576], [120, 566], [200, 548], [268, 518], [296, 504], [302, 518], [272, 540], [200, 568], [130, 586], [80, 586]], true, true), '#f0c898', 0.42, 0.08, 8, 1);

    // ── striped lower body ──
    const body = P([[360, 1034], [372, 960], [420, 890], [496, 828], [580, 776], [660, 736], [736, 708], [736, 1034]], true, true);
    R.dome(body, '#f4f4f6', 0.3, 0.3, 110, 2);
    clipA(body, () => { const z = E.fx(`vec3 fx(vec2 uv, vec2 p){
        float x = p.x + 0.0009 * (p.y - 760.) * (p.y - 760.) - 0.35 * (p.y - 900.) + 10. * sin(p.y * 0.02);
        float k = fract(x / 54.);
        return mix(vec3(.96), vec3(.08,.06,.06), smoothstep(0.5, 0.54, k) * (1. - smoothstep(0.94, 0.98, k))); }`);
      a.save(); a.globalCompositeOperation = 'multiply'; img(z); a.restore(); });

    // lower striped tube (behind the spine)
    { const LT = [[100, 1090], [300, 975], [500, 870], [736, 740]];
      const lt = P(lock(LT, 92, 92, 1), true, true);
      R.pipe(P(LT, false), 92, '#f0f0f2', 0.3, 0.14, 2);
      clipA(lt, () => { a.fillStyle = '#16100f'; for (let i = 0; i < 16; i++) { const x = 140 + i * 40; a.fill(P([[x, 1100 - (x - 100) * 0.55 + 60], [x + 22, 1100 - (x - 100) * 0.55 + 60], [x + 22 + 60, 1100 - (x - 100) * 0.55 - 120], [x + 60, 1100 - (x - 100) * 0.55 - 120]], true, false)); } }); }
    // ── dark spine rod with white vertebrae ──
    const CL = [[-20, 1075], [150, 958], [250, 916], [400, 828], [500, 770], [600, 690], [700, 612], [750, 575]];
    R.pipe(P(CL, false), 84, '#2a2020', 0.4, 0.12, 3);
    speck(P(lock(CL, 84, 84, 1)), 900, 9, '#c0a080', 0.6, [0, 500, 736, 1024], 0.2);
    const along = (t) => { const n = CL.length - 1, f = Math.min(n - 1e-6, Math.max(0, t * n)), i = Math.floor(f), u = f - i;
      return [CL[i][0] + (CL[i + 1][0] - CL[i][0]) * u, CL[i][1] + (CL[i + 1][1] - CL[i][1]) * u]; };
    const spike = (x, y, ang, len, wd, h0) => {
      const c = Math.cos(ang), s = Math.sin(ang), q = (u, v) => [x + u * c - v * s, y + u * s + v * c];
      const pts = [q(-10, -wd / 2), q(len * 0.3, -wd * 0.52), q(len * 0.62, -wd * 0.4), q(len * 0.86, -wd * 0.26), q(len, -wd * 0.08), q(len, wd * 0.08), q(len * 0.86, wd * 0.26), q(len * 0.62, wd * 0.4), q(len * 0.3, wd * 0.52), q(-10, wd / 2)];
      R.dome(P(pts, true, true), WH, h0, 0.2, wd * 0.45, 2);
    };
    // lower side (behind), then upper side (in front)
    for (const t of [0.3, 0.42, 0.54, 0.66, 0.78, 0.9]) { const [x, y] = along(t); spike(x + 22, y + 34, 0.9, 64, 60, 0.5); }
    for (const t of [0.04, 0.15, 0.26, 0.37, 0.48, 0.59, 0.7, 0.81, 0.92]) { const [x, y] = along(t); spike(x - 16, y - 30, -1.95, 80, 74, 0.55); }

    // ── bottom-left white bones ──
    R.dome(P(blob(140, 760, 100, 66, 11, 16, 0.08)), WH, 0.5, 0.3, 50, 2);
    for (const [x, y, rx, ry, sd] of [[40, 900, 44, 60, 12], [100, 960, 40, 56, 13], [30, 1000, 36, 40, 14], [180, 1000, 40, 30, 15], [10, 800, 30, 40, 16]])
      R.dome(P(blob(x, y, rx, ry, sd, 14, 0.1)), WH, 0.45, 0.24, 30, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 18, wrap: 0.55, ao: 0.4, grain: 0.06, rim: 0.25 }),            // 1 tan leather
        E.mat({ dif: 1, spec: 0.55, shin: 30, wrap: 0.5, ao: 0.35, coat: 0.08, rim: 0.3 }),              // 2 white clay
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.3, ao: 0.5 }),                                      // 3 dark rod
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.4, ao: 0.6, grain: 0.4 }),                          // 4 mane
        E.mat({ dif: 0.8, spec: 1.6, shin: 120, coat: 0.5 })                                              // 5 eye
      ],
      light: [-0.5, 0.55, 0.68], lc: [0.6, 0.58, 0.56], amb: [0.42, 0.42, 0.46],
      envTop: [1.1, 1.1, 1.15], envHor: [0.7, 0.68, 0.75], envBot: [0.3, 0.28, 0.32], envK: [0.2, 0.8, 0.3, 0],
      rimC: [0.35, 0.3, 0.45], rimD: [0.3, 0.6, 0.3], r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-6, 8, 0.5, 6]
    });
    // depth of field: horn + bottom-left
    { const bl = E.blur(E.snapshot(), 10), x = bl.getContext('2d');
      x.globalCompositeOperation = 'destination-in'; x.setTransform(S, 0, 0, S, 0, 0);
      x.fillStyle = '#000'; x.fill(P([[-10, -10], [240, -10], [120, 260], [60, 420], [-10, 430]], true, false));
      const g = x.createRadialGradient(40, 1000, 40, 40, 1000, 260); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 700, 300, 324);
      E.draw(bl); }
    E.grain(0.03, 125);
  }
});
