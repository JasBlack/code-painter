'use strict';
// g087 — "Glow ghosts and zebra suns": airbrushed pale-blue glowing figures on violet sky and pink haze, a
// diagonal zebra torrent with two ring-eyes and a black star, an orange sun — beside three gold-framed panels.
REC.register('g087', {
  w: 726, h: 1024,
  draw(E) {
    const S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (x, path, c) => { x.fillStyle = c; x.fill(path); };
    const stroke = (x, path, c, wd) => { x.lineWidth = wd; x.strokeStyle = c; x.lineCap = x.lineJoin = 'round'; x.stroke(path); };
    // soft layer: draw with fn into a fresh canvas, composite with blur
    const L = (blur, fn, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      o.save(); if (clip) o.clip(clip); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op;
      if (blur) o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore();
    };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, r0 = 0) => { const g = o.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // glowing pale-blue outline
    const glowLine = (path, wd = 3, clip = null) => {
      L(5, x => stroke(x, path, '#9fd0ff', wd * 3), 0.7, 'source-over', clip);
      L(0.6, x => stroke(x, path, '#cfe8ff', wd), 0.95, 'source-over', clip);
    };
    // tube limb with glow rims
    const tube = (pts, wd, col, clip = null) => {
      const pth = P(pts, false);
      L(3, x => { stroke(x, pth, '#a8d4ff', wd + 6); }, 0.8, 'source-over', clip);
      L(2, x => { stroke(x, pth, col, wd); }, 1, 'source-over', clip);
      L(4, x => { x.translate(-wd * 0.12, -wd * 0.12); stroke(x, pth, 'rgba(235,245,255,0.55)', wd * 0.25); }, 1, 'source-over', clip);
    };
    const LP = rrect(0, 0, 444, 1024, 0);
    // glossy ribs across a band (centre line cl, band width bw)
    const ribs = (cl, bw, seed) => L(1.2, x => {
      const r = rng(seed);
      for (let k = 0; k < cl.length - 1; k++) {
        const [x0, y0] = cl[k], [x1, y1] = cl[k + 1], Ls = Math.hypot(x1 - x0, y1 - y0), tx = (x1 - x0) / Ls, ty = (y1 - y0) / Ls, nx = -ty, ny = tx;
        for (let d = 0; d < Ls; d += 22) {
          const cx = x0 + tx * d, cy = y0 + ty * d;
          for (let j = -1; j <= 1; j++) {
            const off = j * bw * 0.3 + (r() - 0.5) * 14 - 12, len = 18 + r() * 20, w = (r() - 0.5) * 10;
            const a0 = [cx + nx * off - ny * 0, cy + ny * off], pts = [a0, [a0[0] + nx * len * 0.5 + tx * w, a0[1] + ny * len * 0.5 + ty * w], [a0[0] + nx * len, a0[1] + ny * len]];
            stroke(x, P(pts, false), 'rgba(90,116,170,0.5)', 9);
            x.save(); x.translate(-2, -2); stroke(x, P(pts, false), 'rgba(250,252,255,0.92)', 3.2); x.restore();
          }
        }
      }
    });

    // ═════════ left panel ═════════
    clipped(LP, () => {
      o.fillStyle = '#8aa0b8'; o.fillRect(0, 0, 444, 1024);
      // violet sky + lavender glows
      L(10, x => {
        fill(x, P([[-20, -20], [390, -20], [372, 60], [345, 140], [300, 210], [270, 250], [258, 300], [-20, 300]], true, false), '#4f45bc');
        fill(x, ellipseP(352, 60, 40, 80, 0), '#b8bce8');
        fill(x, ellipseP(250, 150, 30, 50, 0), '#6a60cc');
        fill(x, ellipseP(20, 260, 60, 50, 0), '#9a96de');
      });
      L(24, x => { fill(x, ellipseP(352, 70, 34, 70, 0), '#d4d8f2'); fill(x, ellipseP(10, 10, 40, 40, 0), '#8a80d0'); }, 0.8);
      // pale area under the head (lighter blue), dark smudge
      L(10, x => {
        fill(x, P([[-10, 300], [210, 296], [215, 380], [210, 460], [-10, 470]], true, true), '#a2bcd6');
        fill(x, ellipseP(135, 340, 70, 18, 0), '#c0d4ee');
        fill(x, ellipseP(160, 360, 50, 25, 0), '#aca8c2');
      });
      L(16, x => fill(x, ellipseP(132, 395, 52, 26, 0), '#3c3842'), 0.9);
      // body mass
      L(14, x => {
        fill(x, P([[-10, 440], [120, 430], [220, 440], [300, 470], [330, 560], [310, 650], [320, 720], [260, 760], [150, 760], [60, 740], [-10, 720]], true, true), '#7e96ae');
        fill(x, ellipseP(20, 560, 40, 70, 0), '#60789c');
      });

      // head
      const head = ellipseP(157, 180, 98, 112, 0);
      L(6, x => fill(x, head, '#86afc9'));
      L(5, x => fill(x, P([[78, 110], [110, 98], [150, 102], [185, 110], [200, 140], [198, 175], [185, 200], [160, 206], [140, 216], [115, 222], [90, 212], [76, 180], [74, 140]], true, true), '#dedede'));
      glowLine(head, 3.5);
      for (const [x0, y0, r] of [[181, 250, 17], [216, 226, 7], [237, 212, 11]]) L(1, x => fill(x, circleP(x0, y0, r), '#f6a284'));
      L(0.5, x => { const pk = P([[194, 208], [204, 186], [220, 174], [232, 162], [240, 150], [234, 168], [222, 180], [208, 196]], false); stroke(x, pk, '#ff7aa8', 4); stroke(x, pk, '#ffd0e0', 1.2); });
      L(0.5, x => { for (let i = 0; i < 4; i++) stroke(x, P([[218 + i * 3, 255 - i * 6], [232 + i * 2, 240 - i * 4], [242, 228 - i * 3]], false), '#e8f4ff', 1.4); });
      // small creature at top-left edge
      L(1, x => { fill(x, P([[0, 128], [22, 120], [40, 132], [44, 150], [20, 152], [0, 146]], true, true), '#3a3236'); stroke(x, P([[12, 80], [8, 92], [14, 100], [24, 110], [28, 124]], false), '#d8d0d8', 3); });

      // limbs
      tube([[72, 236], [36, 280], [18, 350], [20, 430], [42, 500]], 36, '#8cb2d0');
      tube([[-10, 336], [60, 322], [130, 306], [205, 302]], 28, '#9cbcd8');
      tube([[80, 168], [40, 176], [-10, 186]], 44, '#94b2d4');
      L(10, x => fill(x, ellipseP(280, 250, 40, 40, 0), '#9cb0c8'));
      glowLine(P([[60, 300], [120, 288], [200, 290], [260, 300]], false), 2.5);

      // fingerprint arcs + white contour lines on the body
      clipped(ellipseP(150, 560, 120, 105, 0), () => L(0.4, x => {
        for (let r = 50; r < 220; r += 9) { x.beginPath(); x.arc(170, 650 + r * 0.1, r, Math.PI * 1.02, Math.PI * 1.98); x.lineWidth = 1.7; x.strokeStyle = 'rgba(236,244,255,0.9)'; x.stroke(); }
      }));
      L(0.6, x => {
        stroke(x, P([[0, 640], [30, 600], [40, 560], [70, 520], [60, 470]], false), 'rgba(235,245,255,0.85)', 2.5);
        stroke(x, P([[0, 710], [30, 690], [20, 650]], false), 'rgba(235,245,255,0.85)', 2.5);
        stroke(x, P([[250, 450], [270, 500], [280, 560], [300, 600], [290, 650], [310, 680]], false), 'rgba(235,245,255,0.85)', 2.5);
        for (const [cx, cy, r] of [[195, 435, 8], [254, 455, 6], [82, 692, 6], [258, 500, 5], [240, 560, 4]]) stroke(x, circleP(cx, cy, r), 'rgba(235,245,255,0.9)', 2);
      });
      L(0.5, x => { fill(x, P([[180, 528], [192, 522], [198, 530], [186, 534]], true, true), '#101010'); fill(x, P([[268, 603], [276, 600], [282, 610], [272, 612]], true, true), '#101010'); fill(x, ellipseP(94, 659, 4, 5, 0), '#101010'); });

      // ── zebra torrent ──
      const Zp = P([[380, -10], [446, -10], [446, 650], [420, 642], [380, 622], [330, 584], [292, 524], [262, 452], [226, 404], [210, 352], [222, 318], [262, 296], [306, 250], [330, 190], [352, 118], [370, 56]], true, true);
      const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
        vec2 n = normalize(vec2(1., 0.42));
        float ph = dot(p, n) / 31. + 0.6 * sin(p.y * 0.018 + 1.2) + 0.35 * sin(p.y * 0.05 + p.x * 0.02) + 0.5 * (fbm(p * 0.012) - .5)
                   - 0.25 * smoothstep(250., 0., p.y) * (p.x - 300.) / 60.;
        float v = sin(6.2832 * ph);
        vec3 c = mix(vec3(.03, .03, .04), vec3(.95, .95, .96), smoothstep(-.25, .25, v));
        return mix(c, vec3(.72, .74, .78), .12 * (1. - abs(v))); }`);
      L(4, x => stroke(x, Zp, '#e8eef8', 8), 0.8);
      clipped(Zp, () => { o.fillStyle = pat(zcv); o.fillRect(0, 0, 444, 1024); });

      glowLine(P([[370, 56], [352, 118], [330, 190], [306, 250], [262, 296], [222, 318], [210, 352], [226, 404], [262, 452], [292, 524]], false), 2.5);
      // black star around the lower eye
      const st = P([[244, 404], [312, 452], [330, 436], [372, 440], [430, 462], [404, 494], [420, 530], [434, 612], [394, 572], [372, 586], [342, 642], [330, 586], [304, 566], [282, 556], [300, 520], [292, 482]], true, true);
      L(1.5, x => fill(x, st, '#050506'));
      L(3, x => fill(x, P([[214, 330], [250, 312], [300, 330], [310, 400], [270, 420], [216, 396]], true, true), '#060608'), 1, 'source-over', Zp);

      // ring eyes
      const ringEye = (cx, cy, r, per, core, coreR) => {
        const cv = E.fx(`vec3 fx(vec2 uv, vec2 p){
          vec2 d = p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)}); float rr = length(d) + 1.5 * sin(atan(d.y, d.x) * 7.) * smoothstep(10., 40., length(d));
          float v = sin(6.2832 * rr / ${per.toFixed(2)});
          return mix(vec3(.95, .95, .96), vec3(.04), smoothstep(.1, .5, v)); }`);
        clipped(circleP(cx, cy, r), () => { o.fillStyle = pat(cv); o.fillRect(cx - r, cy - r, 2 * r, 2 * r); });
        L(0, x => fill(x, circleP(cx, cy, coreR + 6), '#e8e8ea'), 0.9);
        L(coreR * 0.4, x => fill(x, circleP(cx, cy, coreR), core));
      };
      ringEye(255, 360, 50, 6.5, '#fff6f4', 12);
      ringEye(357, 511, 58, 6, '#c8c8d0', 10);
      L(0, x => { fill(x, circleP(357, 511, 6), '#50505c'); fill(x, circleP(357, 511, 2.5), '#101018'); });

      // orange sun with pink halo
      L(8, x => fill(x, circleP(205, 680, 96), '#b8b4c4'), 0.9);
      L(10, x => fill(x, circleP(205, 680, 70), '#f0a8bc'));
      L(0, x => stroke(x, P(Array.from({ length: 40 }, (_, i) => { const t = Math.PI * (0.9 + i / 39 * 1.25); return [205 + Math.cos(t) * 96, 682 + Math.sin(t) * 96]; }), false), 'rgba(245,250,255,0.95)', 3));
      L(0.8, x => { fill(x, circleP(205, 678, 46), '#ff8aa8'); fill(x, circleP(205, 678, 43), '#fc920c'); });

      // dark blob right of the sun, legs, pink haze
      L(10, x => { fill(x, ellipseP(70, 800, 70, 30, 0.2), '#e070a0'); fill(x, ellipseP(380, 800, 70, 22, 0), '#f070a8'); });
      L(3, x => fill(x, P([[312, 724], [332, 702], [380, 692], [446, 690], [446, 782], [400, 786], [344, 772], [314, 752]], true, true), '#331820'));
      L(14, x => {
        fill(x, P([[-10, 850], [60, 850], [160, 860], [250, 860], [300, 870], [230, 900], [180, 940], [100, 990], [-10, 1000]], true, true), '#fa5cae');
        fill(x, ellipseP(210, 830, 80, 26, -0.05), '#f8d4ea');
        fill(x, ellipseP(260, 800, 40, 16, 0), '#7a3e58');
        fill(x, ellipseP(20, 990, 40, 20, 0), '#fb84bc');
      });
      tube([[150, 728], [110, 770], [70, 840], [40, 900], [16, 930]], 52, '#8aa4c6');
      tube([[300, 700], [312, 770], [320, 840], [332, 874], [370, 884]], 50, '#90a8c8');

      // bottom ribbon with ridges
      const rib = P([[-10, 1034], [60, 1010], [130, 975], [190, 915], [230, 890], [300, 878], [380, 860], [446, 830], [446, 950], [330, 1034]], true, true);
      L(3, x => fill(x, rib, '#a0b6ce'));
      clipped(rib, () => ribs([[60, 1060], [200, 990], [320, 950], [446, 896]], 130, 87));
      glowLine(P([[60, 1010], [130, 975], [190, 915], [230, 890], [300, 878], [380, 860], [446, 830]], false), 2.5);
      L(6, x => fill(x, P([[330, 1034], [446, 946], [446, 1034]], true, false), '#0a0a0c'));
      // crumb
      L(0.8, x => {
        fill(x, P(blob(80, 935, 28, 26, 5, 14, 0.25)), '#3a2c2c');
        const r = rng(9); for (let i = 0; i < 40; i++) fill(x, circleP(58 + r() * 44, 912 + r() * 46, 1 + r() * 3), r() < 0.5 ? '#1a1212' : '#6a5a58');
      });
    });

    // ═════════ right panels ═════════
    const TP = rrect(450, 0, 276, 227, 0), MP = rrect(450, 233, 276, 456, 0), BP = rrect(450, 694, 276, 330, 0);
    // top: squarish zebra rings
    const rcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = abs(p - vec2(622., 74.));
      float k = smoothstep(30., 150., length(q)) * 0.55;
      float d = mix(length(q), max(q.x, q.y * 1.05), k) + 7. * (fbm(p * 0.012) - .5);
      float ph = log(1. + 0.035 * d / 8.5) / 0.035;
      float v = sin(6.2832 * ph);
      return mix(vec3(.03), vec3(.96), smoothstep(-.2, .2, v)); }`);
    clipped(TP, () => {
      o.fillStyle = pat(rcv); o.fillRect(450, 0, 276, 227);
      L(0.8, x => { fill(x, circleP(622, 76, 21), '#fff4e4'); fill(x, circleP(622, 76, 18), '#f4b060'); });
      L(1, x => fill(x, circleP(701, 198, 21), rad(694, 190, 22, [[0, '#ffe0f0'], [1, '#f0a8c8']])));
    });
    // middle: white with a dark blurred moon and raised blue hands
    clipped(MP, () => {
      o.fillStyle = '#fcfcfc'; o.fillRect(450, 233, 276, 456);
      L(20, x => fill(x, ellipseP(632, 408, 122, 112, 0), '#2c181c'));
      L(16, x => { fill(x, ellipseP(500, 640, 70, 66, 0), '#2a171a'); fill(x, ellipseP(700, 640, 80, 70, 0), '#020202'); fill(x, ellipseP(570, 690, 70, 24, 0), '#2a1a20'); });
      L(4, x => fill(x, circleP(627, 414, 22), '#ff9cb0'), 0.9);
      L(1, x => fill(x, circleP(627, 414, 19), rad(622, 408, 20, [[0, '#ffe4ea'], [1, '#f8a4b8']])));
      L(2, x => fill(x, circleP(728, 470, 12), '#f8b0c8'));
      const hand = (cx, cy, s) => {
        tube([[cx - 10 * s, cy + 30 * s], [cx, cy]], 46 * s, '#a2c0e8', MP);
        for (const [dx, len] of [[-20, 40], [-7, 52], [6, 52], [19, 44]]) tube([[cx + dx * s, cy - 5 * s], [cx + dx * s * 1.15, cy - len * s]], 12 * s, '#a2c0e8', MP);
        tube([[cx + 22 * s, cy + 10 * s], [cx + 40 * s, cy - 4 * s]], 12 * s, '#a2c0e8', MP);
      };
      tube([[440, 600], [480, 560], [520, 520], [548, 486]], 42, '#9cbae6', MP);
      tube([[452, 440], [470, 500], [500, 560], [530, 640], [560, 700]], 30, '#9cbae6', MP);
      tube([[586, 700], [598, 640], [628, 600], [648, 586]], 42, '#9cbae6', MP);
      hand(556, 466, 1); hand(652, 570, 0.9);
      L(0.5, x => { stroke(x, P([[540, 470], [556, 462], [570, 470]], false), '#e0eeff', 2); stroke(x, circleP(640, 578, 9), '#e0eeff', 2); });
    });
    // bottom: black with the glowing slug
    clipped(BP, () => {
      o.fillStyle = '#020202'; o.fillRect(450, 694, 276, 330);
      L(14, x => { fill(x, ellipseP(520, 715, 90, 25, 0), '#5a2a3a'); fill(x, ellipseP(520, 980, 30, 60, 0.2), '#584a5a'); });
      const slug = P([[440, 800], [470, 760], [520, 730], [580, 712], [640, 700], [740, 696], [740, 822], [650, 850], [560, 885], [500, 910], [440, 930]], true, true);
      L(4, x => stroke(x, slug, '#9fd0ff', 8), 0.7);
      L(2, x => fill(x, slug, '#b0c4e6'));
      clipped(slug, () => ribs([[440, 868], [520, 822], [600, 794], [680, 760]], 120, 88));
      L(0, x => { fill(x, circleP(690, 765, 46), '#060606'); fill(x, circleP(690, 765, 32), '#ece8ec'); fill(x, circleP(690, 765, 25), rad(688, 760, 26, [[0, '#a8a0a8'], [1, '#5a4a52']])); });
      L(0.4, x => stroke(x, P([[600, 900], [612, 890], [640, 885], [660, 870], [668, 846]], false), '#f4f0e8', 2.2));
    });

    // gold frame lines
    const gold = (pth) => { o.fillStyle = '#9a8a70'; o.fill(pth); clipped(pth, () => { const r = rng(11); for (let i = 0; i < 900; i++) { o.fillStyle = r() < 0.5 ? '#6a5a48' : '#d8c8a0'; o.fillRect(444 + r() * 282, r() * 1024, 1.2, 1.2); } }); };
    gold(rrect(443, 0, 7, 1024, 0)); gold(rrect(450, 226, 276, 7, 0)); gold(rrect(450, 688, 276, 6, 0));
    o.fillStyle = '#f2f2f2'; o.fillRect(450, 233, 4, 456);

    E.grain(0.035, 87);
  }
});
