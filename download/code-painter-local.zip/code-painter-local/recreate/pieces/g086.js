'use strict';
// g086 — "Clay cosmos control board": a tan-rimmed clay board on a starry night — zebra waves and
// fingerprint spirals, a grey gloss blob with a yellow moon, orange caterpillars, a TV screen, chrome pebbles, a blue L.
REC.register('g086', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const line = (pts, c, wd, closed = false) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(P(pts, closed)); };
    const rim = (path, c = '#e7a77c', wd = 3) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r, stops, x1 = x, y1 = y) => { const g = a.createRadialGradient(x1, y1, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.25 + r() * 0.5; a.beginPath(); a.arc(r() * 726, r() * 1024, 0.3 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });

    // ── night sky with white star dots ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 0, 1024, [[0, '#15283a'], [0.5, '#0f1c27'], [1, '#0b131a']]), 0, 0);
    { const r = rng(86); a.fillStyle = '#f4f6f8';
      for (let i = 0; i < 150; i++) { const x = r() * 726, y = r() * 1024; const inside = x > 26 && x < 702 && y > 70 && y < 996; if (inside) continue; a.beginPath(); a.arc(x, y, 1 + r() * 2.6, 0, 6.283); a.fill(); } }

    // ── the board ──
    const board = P([[34, 78], [180, 76], [330, 86], [440, 80], [560, 84], [690, 84], [700, 140], [697, 400], [700, 700], [697, 985], [500, 994], [300, 988], [80, 995], [32, 990], [30, 700], [36, 400], [30, 100]], true, false);
    R.flat(board, '#0b0a0c', 0.06, 6);
    speck(board, 220, 3, '#f0f0f4', 1.6);

    // stripe fields
    const zebL = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = vec2(330., 360.), hs = vec2(160., 230.);
      vec2 q = abs(p - c) - hs; float d = length(max(q, 0.)) + min(max(q.x, q.y), 0.);
      d += 9. * sin(p.y * 0.035 + p.x * 0.01) + 14. * (fbm(p * 0.008) - .5) + 4. * sin(p.x * 0.05);
      float v = sin(6.2832 * d / 17.5);
      return mix(vec3(.03), vec3(.97, .96, .94), smoothstep(-.15, .15, v)); }`);
    const ringsTR = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(593., 206.); float r = length(d * vec2(1., .95)); float th = atan(d.y, d.x);
      float ph = r / 5.2 + 0.8 * (fbm(p * 0.03) - .5) - th / 6.2832;
      float v = cos(6.2832 * ph);
      vec3 c = mix(vec3(.96, .95, .93), vec3(.08, .07, .07), smoothstep(.55, .85, v));
      return mix(vec3(.05), c, smoothstep(5., 8., r)); }`);
    const spiralBL = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(165., 647.); float r = length(d); float th = atan(d.y, d.x);
      float ph = r / 10.75 + th / 6.2832 + 0.026;
      float v = cos(6.2832 * ph);
      return mix(vec3(.03), vec3(.96, .95, .93), smoothstep(-.4, -.2, v)); }`);
    const spiralSm = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d1 = p - vec2(380., 300.), d2 = p - vec2(355., 556.);
      vec2 d = length(d1) < 60. ? d1 : d2; float r = length(d); float th = atan(d.y, d.x);
      float ph = r / 5.5 - th / 6.2832;
      float v = sin(6.2832 * ph);
      return mix(vec3(.25, .22, .22), vec3(.95, .93, .9), smoothstep(-.4, .3, v)); }`);

    // cream top-left slab
    const cream = P([[34, 80], [160, 78], [150, 92], [112, 100], [96, 118], [90, 170], [82, 250], [74, 330], [62, 380], [48, 412], [36, 422], [32, 300], [33, 150]], true, true);
    R.dome(cream, '#f2efe6', 0.08, 0.05, 10, 1);
    clipA(cream, () => { const r = rng(5); for (let i = 0; i < 40; i++) { const x = 40 + r() * 70, y = 90 + r() * 320; line([[x, y], [x + 14 + r() * 10, y + (r() - 0.5) * 8]], 'rgba(200,196,186,0.6)', 1); } });
    line([[52, 126], [55, 138], [78, 138], [96, 124], [104, 128], [100, 110]], '#1a1a1a', 1.5);
    soft(x => { x.fillStyle = '#e8d070'; for (let i = 0; i < 20; i++) x.fillRect(32 + (i * 7) % 18, 130 + (i * 13) % 30, 2, 2); }, 0.5, 0.8);
    rim(cream);

    // zebra wave band (left + top)
    const zeb = P([[112, 100], [162, 84], [300, 88], [440, 84], [445, 100], [400, 130], [360, 148], [300, 140], [230, 132], [180, 140], [160, 170], [156, 220], [162, 300], [168, 340], [160, 400], [150, 425], [120, 440], [108, 470], [104, 510], [96, 540], [80, 556], [40, 556], [36, 424], [50, 412], [64, 380], [76, 330], [84, 250], [92, 170], [96, 120]], true, true);
    R.dome(zeb, '#888', 0.08, 0.06, 6, 4);
    clipA(zeb, () => img(zebL));

    // brown block top right
    const brown = P([[612, 86], [690, 86], [698, 110], [696, 165], [682, 172], [664, 150], [640, 120], [618, 104]], true, true);
    R.dome(brown, '#913a30', 0.08, 0.04, 6, 1);
    speck(brown, 300, 7, '#5a1a14', 1.2);
    rim(brown);

    // big fingerprint rings (top right)
    const ringP = P([[560, 98], [620, 98], [662, 122], [686, 175], [688, 232], [672, 285], [640, 322], [600, 340], [575, 352], [575, 380], [560, 400], [548, 370], [520, 345], [490, 318], [462, 285], [452, 250], [470, 195], [500, 140], [530, 110]], true, true);
    R.dome(ringP, '#999', 0.08, 0.08, 18, 4);
    clipA(ringP, () => img(ringsTR));
    rim(ringP, '#e0a888', 2.5);

    // purple top blob
    const purpT = P([[360, 160], [395, 128], [432, 104], [458, 112], [470, 136], [495, 150], [500, 178], [478, 196], [440, 204], [408, 210], [378, 202], [362, 182]], true, true);
    R.dome(purpT, '#8a74d0', 0.08, 0.06, 10, 1);
    clipA(purpT, () => { for (let i = 0; i < 6; i++) line([[395 + i * 4, 168 + i * 6], [430, 162 + i * 6], [460, 168 + i * 5], [490, 160 + i * 4]], 'rgba(90,70,170,0.55)', 1.4); });
    rim(purpT, '#e0a888', 2);

    // blue field behind the caterpillar and small spiral
    const blueM = P([[262, 312], [290, 262], [340, 244], [400, 236], [440, 238], [470, 250], [495, 282], [503, 318], [485, 330], [440, 306], [410, 300], [360, 318], [300, 322]], true, true);
    R.dome(blueM, '#2648d6', 0.08, 0.05, 8, 2);
    clipA(blueM, () => soft(x => { x.fillStyle = '#0a1850'; x.fill(ellipseP(320, 285, 60, 30, 0)); }, 12, 0.7));
    R.dome(P([[440, 255], [452, 272], [470, 268], [455, 282], [462, 300], [445, 288], [425, 296], [436, 280], [420, 268], [438, 268]], true, false), '#0c0c14', 0.14, 0.03, 3, 6);

    // grey gloss blob + yellow moon
    const grey = P([[152, 196], [164, 156], [198, 130], [250, 124], [302, 132], [342, 150], [372, 176], [392, 205], [386, 232], [344, 246], [312, 262], [298, 292], [278, 316], [248, 323], [218, 314], [198, 290], [178, 258], [160, 232]], true, true);
    R.dome(grey, rad(260, 210, 10, 170, [[0, '#c4c2ca'], [0.7, '#b0aeb8'], [1, '#8e8c96']], 230, 170), 0.1, 0.24, 40, 2);
    rim(grey, '#c89a90', 2);
    R.dome(ellipseP(222, 164, 19, 15, -0.3), '#fafafa', 0.32, 0.02, 4, 0);
    R.dome(circleP(173, 258, 43), rad(173, 258, 5, 46, [[0, '#f8fca0'], [1, '#e8ee70']], 160, 245), 0.12, 0.14, 26, 2);
    rim(circleP(173, 258, 43), '#d0a080', 2);
    R.pipe(P([[193, 252], [193, 292]], false), 9, '#141414', 0.3, 0.06, 6);
    R.pipe(P([[193, 245], [193, 252]], false), 4, '#202020', 0.36, 0.04, 6);
    line([[193, 296], [194, 330]], '#30302e', 1.2);

    // orange caterpillars
    const cater = (pts, wd, n) => {
      R.pipe(P(pts, false), wd, '#ff9810', 0.16, 0.16, 2);
      const pl = P(pts, false);
      for (let i = 0; i <= n; i++) {
        const t = i / n, k = t * (pts.length - 1), j = Math.min(pts.length - 2, Math.floor(k)), u = k - j;
        const x = pts[j][0] + (pts[j + 1][0] - pts[j][0]) * u, y = pts[j][1] + (pts[j + 1][1] - pts[j][1]) * u;
        R.dome(circleP(x, y, wd * 0.52), '#ff9810', 0.16, 0.12, wd * 0.3, 2);
      }
      void pl;
    };
    cater([[322, 212], [372, 216], [420, 226]], 38, 4);
    cater([[470, 322], [470, 420], [468, 508]], 42, 6);

    // small spirals
    for (const [x, y, r] of [[380, 300, 30], [355, 556, 45]]) {
      const c = circleP(x, y, r);
      R.dome(c, '#ddd', 0.12, 0.05, 6, 4);
      clipA(c, () => img(spiralSm));
      rim(c, '#d0a08a', 3);
    }

    // short striped tube behind small spiral, tall red/white tube
    const stripes = (pts, wd, n, seed) => {
      R.pipe(P(pts, false), wd, '#f4eeee', 0.14, 0.14, 2);
      const tot = pts.length - 1;
      for (let i = 0; i < n; i++) {
        const t = (i + 0.5) / n, k = t * tot, j = Math.min(tot - 1, Math.floor(k)), u = k - j;
        const x = pts[j][0] + (pts[j + 1][0] - pts[j][0]) * u, y = pts[j][1] + (pts[j + 1][1] - pts[j][1]) * u;
        const dx = pts[j + 1][0] - pts[j][0], dy = pts[j + 1][1] - pts[j][1], L = Math.hypot(dx, dy);
        const nx = -dy / L * wd * 0.5, ny = dx / L * wd * 0.5;
        line([[x - nx, y - ny], [x + nx, y + ny]], '#b81c28', wd / n * tot * 0.45 + 2.5);
      }
      void seed;
    };
    stripes([[300, 296], [352, 294]], 26, 6, 1);
    stripes([[238, 320], [236, 380], [232, 440], [230, 462]], 48, 14, 2);

    // dark pole + small blue/white chip
    R.pipe(P([[196, 340], [196, 455]], false), 16, '#1c1c1e', 0.12, 0.1, 6);
    R.dome(rrect(262, 426, 16, 28, 7), '#cfd8e8', 0.14, 0.05, 5, 2);
    R.dome(rrect(266, 432, 8, 16, 4), '#4060c0', 0.18, 0.03, 3, 2);

    // TV screen
    const scrO = rrect(270, 341, 165, 112, 12), scrI = rrect(277, 348, 151, 98, 9);
    R.dome(scrO, '#e4c0a8', 0.12, 0.05, 4, 1);
    R.dome(scrI, lin(277, 348, 428, 446, [[0, '#a4c0cc'], [0.6, '#8eaab8'], [1, '#6e8a98']]), 0.14, 0.02, 6, 4);
    clipA(scrI, () => {
      a.fillStyle = '#28323a'; a.fill(P([[360, 412], [372, 400], [382, 404], [392, 398], [404, 404], [410, 418], [396, 424], [370, 426]], true, true));
      a.fillStyle = '#3c4e5a'; a.fill(P([[310, 380], [330, 372], [342, 378], [330, 390], [314, 392]], true, true));
      a.fillStyle = 'rgba(40,50,60,0.25)'; a.fillRect(277, 428, 151, 20);
    });

    // robot head + blue tassel
    const tr = rng(12);
    for (let i = 0; i < 16; i++) {
      const x0 = 225 + (tr() - 0.5) * 24, ang = 1.2 + (i / 15) * 0.9 + (tr() - 0.5) * 0.2, L = 90 + tr() * 50;
      const pts = [[x0, 470], [x0 + Math.cos(ang) * L * 0.5 + 6, 470 + Math.sin(ang) * L * 0.5], [x0 + Math.cos(ang + 0.2) * L, 470 + Math.sin(ang + 0.2) * L]];
      R.pipe(P(pts, false), 7, i % 3 ? '#5a88d8' : '#3d66c0', 0.12, 0.08, 2);
    }
    R.pipe(P([[200, 486], [175, 498], [168, 512]], false), 9, '#5a88d8', 0.14, 0.08, 2);
    R.pipe(P([[255, 486], [270, 500], [270, 516]], false), 9, '#5a88d8', 0.14, 0.08, 2);
    R.dome(rrect(222, 434, 32, 40, 8), '#c8c8cc', 0.18, 0.06, 6, 3);
    R.dome(rrect(230, 452, 16, 18, 4), '#e8e8ea', 0.22, 0.04, 3, 3);
    R.bead(232, 444, 4, '#202020', 0.26, 0.03, 6); R.bead(246, 444, 4, '#202020', 0.26, 0.03, 6);

    // purple capsule, chrome pear, purple bar, orange foot
    R.dome(rrect(330, 482, 122, 34, 16), '#7c84e2', 0.12, 0.08, 12, 2);
    rim(rrect(330, 482, 122, 34, 16), '#e0a888', 2);
    const pear = P([[524, 420], [546, 412], [568, 422], [580, 455], [598, 500], [602, 545], [588, 578], [548, 590], [506, 580], [488, 548], [490, 505], [506, 462]], true, true);
    R.dome(pear, rad(530, 500, 4, 90, [[0, '#ffffff'], [0.5, '#c4c6ce'], [1, '#6a6e76']], 515, 470), 0.12, 0.26, 40, 3);
    R.dome(rrect(538, 344, 25, 270, 11), '#8d90e6', 0.22, 0.06, 10, 2);
    R.dome(P([[496, 586], [536, 582], [598, 580], [602, 612], [500, 616]], true, false), '#ff8c12', 0.14, 0.06, 8, 2);

    // left purple / pink blobs
    const purL = P([[112, 470], [125, 440], [150, 428], [168, 445], [172, 500], [165, 552], [130, 556], [112, 520]], true, true);
    R.dome(purL, '#8a70d0', 0.1, 0.05, 8, 1); rim(purL, '#e0a888', 2);
    const pink = P([[96, 500], [118, 488], [136, 505], [138, 545], [128, 578], [108, 582], [94, 548]], true, true);
    R.dome(pink, '#f96189', 0.11, 0.05, 8, 1); rim(pink, '#e0a888', 2);

    // ── lower half ──
    // light-blue right column + bottom strip, left patch
    const lbR = P([[575, 352], [610, 342], [650, 336], [690, 340], [697, 420], [697, 700], [697, 980], [600, 986], [420, 986], [280, 984], [270, 960], [560, 940], [600, 600], [575, 470]], true, true);
    R.dome(lbR, '#86aaba', 0.08, 0.04, 8, 1);
    soft(x => { x.fillStyle = '#efe6d4'; x.fill(ellipseP(660, 960, 60, 26, -0.3)); }, 10, 0.95);
    speck(lbR, 900, 9, '#ffffff', 0.8);
    rim(lbR);
    const lbL = P([[38, 548], [80, 556], [92, 575], [78, 640], [72, 700], [66, 760], [52, 784], [36, 780]], true, true);
    R.dome(lbL, '#b2d3df', 0.08, 0.04, 8, 1); rim(lbL);
    // chrome/grey dial on the light blue
    R.dome(circleP(652, 518, 30), '#96bccc', 0.12, 0.03, 6, 1);
    R.bead(655, 517, 13, '#f2f0ee', 0.15, 0.12, 2);
    { const r = rng(4); for (let i = 0; i < 14; i++) { const t = -1 + i * 0.32; line([[660 + Math.cos(t) * 40, 440 + Math.sin(t) * 30], [660 + Math.cos(t) * 46, 440 + Math.sin(t) * 34]], '#33505c', 1.5 + r()); } }

    // grey felt field
    const felt = P([[60, 700], [80, 660], [110, 600], [190, 572], [260, 592], [330, 600], [400, 588], [470, 600], [600, 600], [600, 880], [500, 890], [380, 905], [300, 930], [270, 958], [60, 962], [56, 820]], true, true);
    R.flat(felt, '#7a828a', 0.07, 5);
    speck(felt, 6000, 13, '#5a626a', 0.9); speck(felt, 3000, 14, '#a8b0b8', 0.7);
    // dark brown lower-left strip
    const brownL = P([[34, 785], [58, 790], [62, 960], [270, 960], [280, 986], [100, 992], [34, 988]], true, true);
    R.dome(brownL, '#55403f', 0.07, 0.03, 6, 5);
    soft(x => { x.fillStyle = '#b08a76'; x.fill(ellipseP(160, 980, 90, 8, 0)); }, 4, 0.7);
    rim(brownL);
    // black edge between left patch and felt
    R.dome(P([[70, 560], [100, 580], [96, 640], [86, 700], [74, 780], [58, 790], [66, 720]], true, true), '#0d0b0c', 0.08, 0.03, 4, 6);

    // blue L
    const blueL = P([[596, 586], [642, 590], [660, 622], [664, 700], [670, 800], [664, 900], [648, 936], [600, 950], [500, 958], [400, 960], [320, 966], [282, 960], [272, 940], [292, 916], [340, 905], [400, 898], [460, 890], [520, 884], [566, 880], [598, 858], [604, 760], [598, 650]], true, true);
    R.dome(blueL, '#133ed8', 0.1, 0.06, 10, 2);
    rim(blueL, '#d8a890', 2.5);

    // black ring with chrome eye
    R.dome(ellipseP(560, 822, 73, 72, 0), rad(560, 822, 30, 74, [[0, '#4a4648'], [0.6, '#2e2a2c'], [1, '#141214']], 545, 800), 0.12, 0.2, 30, 3);
    rim(ellipseP(560, 822, 73, 72, 0), '#e4c4b4', 2.5);
    R.dome(ellipseP(562, 823, 37, 36, 0), rad(562, 823, 2, 40, [[0, '#ffffff'], [0.45, '#c8c8cc'], [1, '#5a5a60']], 552, 810), 0.24, 0.1, 18, 3);
    rim(ellipseP(562, 823, 37, 36, 0), '#d8a080', 2);

    // bottom-left zebra spiral with black tail
    const tail = P([[230, 600], [260, 592], [300, 592], [330, 610], [325, 645], [290, 660], [255, 668], [240, 700], [228, 720], [220, 690]], true, true);
    R.dome(tail, '#0b0a0b', 0.1, 0.06, 10, 6);
    const spP = P([[90, 620], [110, 590], [150, 572], [200, 574], [236, 596], [250, 640], [240, 690], [210, 715], [160, 722], [118, 708], [90, 680], [84, 650]], true, true);
    R.dome(spP, '#888', 0.1, 0.1, 18, 4);
    clipA(spP, () => img(spiralBL));
    a.lineWidth = 5; a.strokeStyle = '#0a0a0a'; a.stroke(spP);
    line([[240, 700], [236, 740], [228, 790]], '#0b0a0b', 4);

    // chrome pebble bottom left
    const peb = P([[92, 812], [130, 796], [182, 806], [226, 832], [252, 868], [250, 910], [222, 932], [160, 932], [110, 912], [88, 870]], true, true);
    R.dome(peb, '#0c0c0e', 0.1, 0.04, 6, 6);
    const pebI = P([[102, 818], [134, 806], [180, 815], [220, 838], [244, 870], [242, 905], [218, 922], [160, 922], [114, 904], [97, 868]], true, true);
    R.dome(pebI, '#e4e4e8', 0.14, 0.22, 34, 3);
    clipA(pebI, () => soft(x => {
      x.fillStyle = '#ffffff'; x.fill(ellipseP(140, 838, 36, 24, 0.2)); x.fill(ellipseP(212, 866, 28, 22, 0)); x.fill(ellipseP(150, 902, 34, 14, 0)); x.fill(ellipseP(226, 912, 14, 8, 0));
      x.fillStyle = '#56565c'; x.fill(ellipseP(124, 874, 16, 22, 0)); x.fill(ellipseP(186, 846, 16, 12, 0)); x.fill(ellipseP(236, 886, 9, 20, 0)); x.fill(ellipseP(186, 896, 24, 9, 0));
    }, 8, 0.9));
    rim(pebI, '#d8b0a0', 1.5);

    // scratches on felt
    { const r = rng(21);
      for (let i = 0; i < 7; i++) line([[92 + r() * 8, 735 + i * 10], [132 + r() * 10, 728 + i * 10 + r() * 4]], '#c8ccd0', 2);
      for (let i = 0; i < 5; i++) line([[72, 905 + i * 8], [100 + r() * 10, 890 + i * 10]], '#c8ccd0', 2); }
    // pale trail
    line([[248, 700], [280, 685], [320, 670], [360, 662], [390, 650], [420, 640], [450, 625], [490, 620]], '#b8b6b8', 4);

    // ── beads ──
    for (const [x, y, r] of [[85, 510, 11], [168, 527, 11], [70, 718, 11], [58, 953, 11], [510, 108, 11], [683, 292, 8], [612, 483, 8], [680, 630, 10]])
      R.bead(x, y, r, '#ff5a1a', 0.16, 0.12, 2);
    for (const [x, y, r] of [[328, 253, 8], [440, 540, 8], [357, 622, 9]]) R.bead(x, y, r, '#e8f070', 0.16, 0.1, 2);
    for (const [x, y, r] of [[273, 769, 7], [435, 742, 7], [442, 847, 7], [365, 934, 7], [478, 902, 7], [640, 730, 7], [588, 636, 6], [631, 897, 6], [66, 862, 7], [159, 451, 7], [336, 178, 7], [455, 145, 6], [308, 482, 6], [660, 352, 5], [690, 398, 5], [607, 596, 5], [260, 706, 5], [215, 718, 5]])
      R.bead(x, y, r, '#f4f2f0', 0.16, 0.1, 2);
    { const r = rng(31); for (let i = 0; i < 26; i++) { const x = 250 + r() * 240, y = 600 + r() * 80; R.bead(x, y, 3 + r() * 6, r() < 0.5 ? '#a8a4a4' : '#c8c4c0', 0.1, 0.06, 1); } }
    for (const [x, y, r] of [[212, 100, 10], [372, 130, 10], [432, 160, 8], [124, 488, 8], [290, 530, 9]]) R.bead(x, y, r, '#a8a0a0', 0.12, 0.08, 1);
    // light-blue knobs on the right edge
    R.dome(P([[690, 560], [710, 548], [726, 556], [726, 600], [700, 604], [684, 588]], true, true), '#8cc0d8', 0.12, 0.08, 10, 2);
    R.dome(P([[684, 830], [704, 818], [726, 826], [726, 868], [702, 872], [684, 856]], true, true), '#8cc0d8', 0.12, 0.08, 10, 2);
    R.pipe(P([[710, 545], [726, 470]], false), 7, '#a8d4e8', 0.14, 0.05, 2);

    // tan rim of the whole board
    a.lineWidth = 5; a.strokeStyle = '#e8a46a'; a.stroke(board);
    R.groove(board, 5, null, 0.1, 0.02, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.15, shin: 14, wrap: 0.6, ao: 0.5, grain: 0.05 }),                 // 1 matte clay
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.12 }),                   // 2 glossy plastic
        E.mat({ dif: 0.85, metal: 0.2, spec: 1.0, shin: 60, rim: 0.2, ao: 0.3, emis: 0.18 }),     // 3 chrome
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.05 }),                  // 4 zebra enamel
        E.mat({ dif: 1, spec: 0.05, shin: 8, wrap: 0.6, grain: 0.25 }),                           // 5 felt
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.3, coat: 0.1, ao: 0.4 })                     // 6 black gloss
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.55, 0.55, 0.55],
      envTop: [1, 1, 1], envHor: [0.5, 0.5, 0.52], envBot: [0.1, 0.1, 0.12], envK: [0.3, 1.0, 0.4, 0],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.5, 7]
    });
    E.grain(0.03, 86);
  }
});
