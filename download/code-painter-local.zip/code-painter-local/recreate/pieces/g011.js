'use strict';
// g011 — "Chrome drip on zebra": a coral clay nose curls over a grey-blue cheek with one eye and
// drips into a pooled blue chrome blob, all set in flowing zebra stripes, blue sky, rust fur, orange glows.
REC.register('g011', {
  w: 701, h: 1024,
  draw(E) {
    const W = 701, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // fur: many short hair strokes along an outline
    const fur = (pts, len, col, n, seed, wd = 1.2, dir = 1) => {
      const r = rng(seed); a.save(); a.strokeStyle = col; a.lineWidth = wd; a.lineCap = 'round';
      for (let i = 0; i < n; i++) {
        const k = Math.floor(r() * (pts.length - 1)), u = r(), p = pts[k], q = pts[k + 1];
        const x = p[0] + (q[0] - p[0]) * u, y = p[1] + (q[1] - p[1]) * u, L = Math.hypot(q[0] - p[0], q[1] - p[1]) || 1;
        const nx = dir * (q[1] - p[1]) / L, ny = -dir * (q[0] - p[0]) / L, l = len * (0.4 + r() * 0.9), j = (r() - 0.5) * 0.6;
        a.beginPath(); a.moveTo(x - nx * 3, y - ny * 3); a.lineTo(x + (nx + j * ny) * l, y + (ny - j * nx) * l); a.stroke();
      }
      a.restore();
    };

    // ── zebra field: upper stripes sweep from steep (left) to flat (right); lower ones fan from the right ──
    const zeb = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 w = vec2(fbm(p * 0.006), fbm(p * 0.006 + 7.3)) - .5;
        vec2 q = p + w * 60.;
        // upper: level sets of y - c*ln(x - x0)
        float x0 = 110., c = 120.;
        float xx = max(q.x - x0, 12.);
        float f1 = q.y - c * log(xx / 100.);
        float g1 = sqrt(1. + pow(c / xx, 2.));
        float ph1 = f1 / g1 / 27.;
        // lower: fan of lines from a point right of the frame
        vec2 d = q - vec2(750., 520.);
        float rr = length(d);
        float ph2 = atan(d.y, -d.x) * 100. / 6.2832 * pow(rr / 400., 0.12) + 0.3 * sin(rr * 0.02);
        float m = smoothstep(-20., 20., p.y - 578. + 0.12 * (p.x - 300.));
        float ph = mix(ph1, ph2, m) + 0.35 * (fbm(p * 0.02) - .5);
        float v = sin(6.2832 * ph);
        float wh = smoothstep(-0.25, 0.15, v);
        float sheen = 0.78 + 0.22 * smoothstep(0.1, 0.95, sin(6.2832 * (ph + 0.06)));
        vec3 white = vec3(0.93, 0.94, 0.96) * sheen;
        vec3 black = vec3(0.025, 0.025, 0.035);
        return mix(black, white, wh); }`);
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#777b80', 0, 0);
    img(zeb);

    // ── sky (top right) with a sunset glow and a far mountain ──
    const sky = P([[548, -10], [711, -10], [711, 330], [690, 326], [640, 330], [600, 352], [566, 336], [548, 300], [524, 250], [508, 190], [516, 120], [528, 60]], true, false);
    R.flat(sky, lin(600, 0, 640, 340, [[0, '#2a70d4'], [0.5, '#2580e4'], [0.85, '#2c86e6'], [1, '#4a90d8']]), 0, 0);
    clipA(sky, () => {
      soft(x => fe(x, 690, 300, 70, 16, 0, '#f0a050'), 12, 0.9);
      a.fillStyle = '#3c78c8'; a.fill(P([[560, 360], [600, 322], [640, 312], [660, 298], [680, 306], [711, 312], [711, 360]], true, true));
      soft(x => fe(x, 620, 200, 80, 120, 0, '#3c90f0'), 30, 0.5);
    });

    // ── slate "ear" patch (top) ──
    const slate = [[322, -10], [548, -10], [540, 60], [528, 110], [516, 150], [480, 170], [450, 180], [420, 196], [400, 222], [380, 200], [356, 176], [336, 120], [326, 60]];
    R.flat(P(slate, true, true), lin(330, 0, 520, 200, [[0, '#3c485c'], [0.5, '#304058'], [1, '#22324c']]), 0.02, 0);
    clipA(P(slate, true, true), () => soft(x => { fe(x, 420, 70, 70, 60, 0, '#4a5870'); fe(x, 360, 150, 30, 40, 0, '#405070'); }, 25, 0.7));
    fur(slate.slice(7, 12), 14, '#141820', 400, 3, 1.4, -1);

    // ── rust fur + black on the right ──
    const rust = [[711, 334], [690, 340], [660, 350], [630, 370], [604, 400], [582, 440], [566, 490], [558, 540], [556, 600], [562, 680], [576, 760], [604, 820], [640, 880], [680, 930], [711, 960]];
    const rustP = P(rust, true, true);
    R.flat(rustP, lin(560, 400, 711, 900, [[0, '#561a10'], [0.5, '#4c140c'], [1, '#46120a']]), 0.02, 0);
    clipA(rustP, () => fur(rust.concat([[711, 334]]), 30, 'rgba(120,40,24,0.6)', 900, 7, 1, 1));
    fur(rust.slice(1, 14), 16, '#5a1a10', 700, 8, 1.4, -1);
    const blk = P([[711, 330], [680, 340], [660, 370], [650, 420], [644, 520], [654, 620], [668, 700], [690, 760], [711, 790]], true, true);
    R.flat(blk, '#060404', 0.02, 0);
    clipA(rustP, () => fur([[680, 340], [660, 370], [650, 420], [644, 520], [654, 620], [668, 700], [690, 760]], 14, '#2a0c06', 500, 9, 1.2, 1));

    // ── left glow panel: grey-blue lichen with orange lights ──
    const panel = [[-10, 470], [30, 500], [70, 560], [110, 590], [140, 600], [132, 650], [148, 700], [118, 760], [70, 820], [30, 870], [-10, 900]];
    const panelP = P(panel, true, true);
    R.flat(panelP, lin(0, 500, 140, 880, [[0, '#66728c'], [0.5, '#6c7a94'], [1, '#5a6880']]), 0.01, 0);
    clipA(panelP, () => {
      const r = rng(11); a.fillStyle = '#b0b6c2';
      for (let i = 0; i < 26; i++) a.fill(P(blob(r() * 130, 600 + r() * 280, 8 + r() * 14, 5 + r() * 8, 100 + i, 10, 0.5, r() * 3)));
      for (const [x, y] of [[14, 594], [74, 586], [97, 710], [14, 812]]) {
        a.fillStyle = rad(x, y, 46, [[0, 'rgba(255,250,200,1)'], [0.22, 'rgba(255,200,90,1)'], [0.45, 'rgba(250,120,40,0.75)'], [1, 'rgba(240,90,30,0)']]);
        a.fillRect(x - 50, y - 50, 100, 100);
      }
    });
    fur(panel.slice(0, 5), 24, '#ff6a20', 500, 12, 1.4, -1);
    fur(panel.slice(4, 11), 12, '#2a2a40', 300, 13, 1.2, -1);

    // ── grey-blue cheek under the nose ──
    const cheek = [[-10, 290], [40, 296], [83, 317], [125, 333], [167, 375], [200, 417], [250, 442], [333, 467], [400, 492], [440, 500], [440, 540], [400, 560], [330, 572], [250, 580], [180, 580], [130, 586], [90, 578], [50, 540], [10, 500], [-10, 480]];
    const cheekP = P(cheek, true, true);
    R.dome(cheekP, lin(0, 300, 120, 600, [[0, '#8a7072'], [0.4, '#6e5e68'], [0.7, '#4c5060'], [1, '#343c50']]), 0.05, 0.08, 30, 1);
    clipA(cheekP, () => {
      soft(x => { fe(x, 70, 340, 70, 30, 0, '#98787a'); fe(x, 340, 525, 80, 30, 0, '#8a92aa'); fe(x, 90, 556, 100, 30, 0, '#323a50'); fe(x, 10, 440, 40, 70, 0, '#3c4052'); fe(x, 250, 470, 70, 30, 0, '#6a5660'); }, 30, 0.8);
      const r = rng(21); a.fillStyle = '#20202a';
      for (let i = 0; i < 90; i++) { a.globalAlpha = 0.4 + r() * 0.6; a.beginPath(); a.arc(r() * 440, 300 + r() * 280, 0.5 + r() * 1.5, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    fur([[90, 580], [130, 586], [180, 582], [230, 582]], 12, '#141826', 250, 14, 1.3, 1);

    // ── coral clay mass + nose tube ──
    const skin = [[-10, -10], [160, -10], [146, 40], [142, 108], [150, 208], [179, 275], [233, 333], [308, 367], [383, 392], [425, 408], [450, 440], [452, 474], [440, 492], [417, 498], [400, 492], [333, 467], [250, 442], [200, 417], [167, 375], [125, 333], [83, 317], [40, 300], [-10, 296]];
    const skinP = P(skin, true, true);
    // gold band + dark seam along the top of the zebra edge
    R.flat(P([[146, -10], [210, -10], [196, 40], [178, 90], [166, 140], [154, 170], [146, 108], [148, 40]], true, true), lin(150, 0, 190, 140, [[0, '#e0a020'], [1, '#b07010']]), 0.02, 0);
    R.pipe(P([[200, -10], [184, 50], [168, 110], [158, 170], [166, 230]], false), 5, '#0a0a10', 0.04, 0.02, 0);
    R.dome(skinP, lin(0, 0, 200, 420, [[0, '#d08e84'], [0.35, '#c87e74'], [0.6, '#c06a5c'], [1, '#b85848']]), 0.08, 0.3, 46, 1);
    clipA(skinP, () => soft(x => {
      fe(x, 60, 80, 90, 80, 0, '#d09088'); fe(x, 30, 276, 80, 26, 0, '#6a2420'); fe(x, 120, 310, 40, 20, 0.5, '#8a3a30'); fe(x, 220, 250, 60, 40, 0.5, '#a84a3e');
      fe(x, 330, 455, 120, 18, 0.35, '#923c30'); fe(x, 380, 400, 60, 20, 0.35, '#de8068');
    }, 22, 0.8));
    // black dots on the skin
    R.bead(425, 434, 7, '#0a0a0e', 0.4, 0.06, 3);
    R.bead(115, 370, 4, '#1a1a24', 0.15, 0.03, 3);
    R.bead(55, 437, 9, '#08080c', 0.15, 0.05, 3);

    // ── eye ──
    const eye = P([[14, 310], [30, 298], [50, 294], [70, 300], [82, 312], [64, 320], [44, 322], [26, 318]], true, true);
    R.flat(eye, '#e8e4e6', 0.2, 0);
    clipA(eye, () => { a.fillStyle = rad(48, 308, 14, [[0, '#304050'], [0.3, '#5a7890'], [0.9, '#7a98b0'], [1, '#283040']]); a.fill(circleP(48, 308, 14)); a.fillStyle = '#0a0a10'; a.fill(circleP(48, 308, 5)); a.fillStyle = '#fff'; a.fill(circleP(44, 304, 2)); });
    R.pipe(P([[12, 312], [30, 297], [52, 292], [72, 298], [84, 312]], false), 3, '#2a1a1a', 0.21, 0.01, 0);

    // ── chrome: drip from the nose tip, droplet, pooled blob ──
    const blobPts = [[212, 600], [250, 572], [300, 566], [360, 562], [410, 552], [446, 540], [486, 556], [522, 590], [545, 640], [546, 700], [530, 755], [496, 790], [446, 806], [390, 808], [330, 794], [272, 784], [230, 768], [206, 724], [204, 660]];
    const blobP = P(blobPts, true, true);
    R.dome(blobP, '#e6eaff', 0.12, 0.42, 72, 2);
    R.pipe(P([[454, 452], [464, 482], [460, 510], [446, 536], [430, 556]], false), 16, '#dfe4ff', 0.2, 0.16, 2);
    R.dome(P([[380, 560], [420, 534], [450, 520], [474, 530], [480, 556], [450, 572], [400, 574]], true, true), '#dfe4ff', 0.16, 0.14, 14, 2);
    R.pipe(P([[166, 580], [190, 588], [214, 600]], false), 9, '#dfe4ff', 0.12, 0.12, 2);
    R.bead(162, 578, 11, '#dfe4ff', 0.12, 0.2, 2);
    

    // ── white beads along the zebra / fur edge ──
    for (const [x, y, r] of [[568, 390, 10], [488, 472, 9], [510, 560, 14], [555, 625, 10], [612, 617, 13], [600, 730, 16], [552, 680, 7], [548, 436, 6]]) {
      R.bead(x, y, r + 3, '#0a0a10', 0.15, 0.08, 4);
      R.bead(x, y, r, '#f2f2f6', 0.2, 0.12, 4);
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 26, wrap: 0.45, ao: 0.5, grain: 0.12, coat: 0.05, rim: 0.2 }),          // 1 clay skin
        E.mat({ dif: 0.1, metal: 1, spec: 1.2, shin: 80, coat: 0.2, rim: 0.3, ao: 0.3, tint: [0.55, 0.68, 1.1] }),  // 2 blue chrome
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.15 }),                                            // 3 gloss black
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, coat: 0.1 })                                              // 4 white beads
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.72, 0.7, 0.7], amb: [0.36, 0.34, 0.37],
      envTop: [1.6, 1.6, 1.5], envHor: [0.8, 0.88, 1.0], envBot: [0.06, 0.08, 0.3], envK: [0.3, 1.6, 0.1, 0],
      rimC: [0.3, 0.35, 0.6], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 120], shadow: [-5, 6, 0.5, 6]
    });
    // hand-painted chrome reflections
    const o = E.out;
    const sOut = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      o.save(); o.setTransform(1, 0, 0, 1, 0, 0); o.globalAlpha = alpha; o.globalCompositeOperation = op; o.filter = `blur(${blur * S}px)`; o.drawImage(c, 0, 0); o.restore();
    };
    const inner = P(blobPts.map(([x, y]) => [375 + (x - 375) * 0.96, 685 + (y - 685) * 0.95]), true, true);
    o.save(); o.clip(inner);
    sOut(x => { fe(x, 300, 660, 70, 60, 0, '#6a8ee8'); fe(x, 450, 670, 60, 70, 0, '#6688ea'); fe(x, 385, 600, 50, 22, 0, '#c8f0fa'); fe(x, 300, 610, 40, 18, 0, '#80b8f8'); }, 18, 0.55);
    sOut(x => { fe(x, 365, 710, 14, 50, 0.1, '#28389a'); fe(x, 330, 760, 60, 14, 0, '#3a4aa0'); fe(x, 470, 680, 40, 30, 0, '#5078e0'); }, 10, 0.8);
    sOut(x => { fe(x, 392, 650, 12, 60, 0.05, '#ffffff'); fe(x, 512, 650, 10, 60, 0, '#ffffff'); fe(x, 226, 682, 10, 22, 0, '#ffffff'); fe(x, 262, 742, 22, 12, 0.3, '#f0f4ff'); fe(x, 300, 640, 30, 10, 0.2, '#e8f8ff'); fe(x, 240, 610, 26, 8, -0.5, '#ffffff'); fe(x, 500, 590, 24, 8, 0.6, '#ffffff'); }, 6, 0.95);
    o.restore();
    // wavy rim: dark line outside, bright line inside
    o.save(); o.lineJoin = 'round';
    o.strokeStyle = '#141a3a'; o.lineWidth = 3; o.stroke(blobP);
    o.strokeStyle = 'rgba(235,240,255,0.85)'; o.lineWidth = 1.5; o.stroke(P(blobPts.map(([x, y]) => [375 + (x - 375) * 0.985, 685 + (y - 685) * 0.98]), true, true));
    o.restore();
    // hole
    o.fillStyle = '#020204'; o.fill(circleP(471, 735, 23));
    o.strokeStyle = 'rgba(120,140,220,0.7)'; o.lineWidth = 1.5; o.stroke(circleP(471, 735, 23.5));
    E.bloom(0.08, 10);
    E.grain(0.035, 11);
  }
});
