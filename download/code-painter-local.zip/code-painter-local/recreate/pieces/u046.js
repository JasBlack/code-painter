'use strict';
// u046 — "Tongue over the runway": a huge fleshy tongue under a striped lettered arch, a grey stippled giant, a zebra
// spine of ribs arching onto a grey runway, a wavy rainbow flag, blue sky and a graph-paper map in black space.
REC.register('u046', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const specks = (path, n, seed, col, rmax = 1.1, x0 = 0, y0 = 0, w = 726, h = 1024) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.35 + r() * 0.65; a.beginPath(); a.arc(x0 + r() * w, y0 + r() * h, 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const ALL = poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034]]);

    // ── black space + stars ──
    R.flat(ALL, '#0c0a0c', 0, 0);
    specks(ALL, 700, 2, '#e8e8f0', 0.9);
    // blue sky right
    const SKY = poly([[560, 8], [736, 8], [736, 668], [560, 668]]);
    fill(SKY, lin(0, 0, 0, 660, [[0, '#5aa2ec'], [0.5, '#4698ee'], [1, '#4c90e0']]));
    soft(x => { stroke(line([[640, 345], [690, 320], [736, 296]]), 'rgba(240,226,120,0.85)', 16, x); stroke(line([[640, 70], [700, 40], [736, 24]]), 'rgba(240,226,120,0.6)', 14, x); }, 7, 1);
    // mountains
    fill(sm([[560, 640], [600, 606], [640, 596], [680, 604], [736, 614], [736, 668], [560, 668]]), '#6e6a86');
    fill(poly([[560, 650], [736, 648], [736, 668], [560, 668]]), '#3a3a56');
    // pink / pale-blue sky top middle
    const PINK = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float n = fbm(p * .012 + 3.);
        vec3 c = mix(vec3(.72, .80, .92), vec3(.94, .46, .66), smoothstep(.35, .65, n + .25 * sin(p.y * .02)));
        c = mix(c, vec3(.55, .72, .93), smoothstep(.55, .8, fbm(p * .02 + 9.)) * .7);
        return c; }`);
    clipA(poly([[44, 8], [420, 8], [420, 400], [44, 400]]), () => img(PINK));
    // orange woven textile
    const TEX = sm([[380, 8], [570, 8], [560, 50], [500, 70], [460, 66], [420, 80], [380, 70]]);
    fill(TEX, '#c08060');
    clipA(TEX, () => { for (let x = 300; x < 620; x += 7) stroke(line([[x, 90], [x + 60, 0]]), 'rgba(110,60,40,0.55)', 2.4); });

    // ── grey stippled giant ──
    const GI = sm([[396, 60], [450, 52], [520, 58], [580, 40], [640, 10], [656, 12], [640, 80], [612, 140], [596, 190], [604, 240], [636, 290], [664, 350], [684, 420],
      [660, 480], [600, 530], [520, 590], [440, 640], [360, 660], [300, 640], [250, 600], [214, 560], [220, 500], [330, 460], [384, 400], [396, 330], [394, 240], [372, 190],
      [336, 150], [338, 100], [366, 80]]);
    const GT = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float g = .5 + .5 * smoothstep(320., 620., p.x) - .35 * smoothstep(380., 600., p.y) * smoothstep(560., 380., p.x);
        g = mix(.42, .66, g) + .08 * (fbm(p * .02) - .5);
        g += (hash(floor(p * .8)) - .5) * .35;
        float sh = smoothstep(160., 0., abs(p.x - 470.)) * .06;
        return vec3(g * .93 + sh, g * .95 + sh, g * 1.08 + sh); }`);
    fill(GI, '#000'); clipA(GI, () => img(GT));
    // dark stipple shadow lower-left of the giant
    clipA(GI, () => soft(x => { fill(sm([[250, 520], [330, 470], [390, 480], [400, 560], [360, 640], [280, 620]]), 'rgba(20,18,24,0.85)', x); }, 18, 1));
    // pink-beige patch + olive panel left
    fill(poly([[200, 470], [300, 470], [312, 560], [290, 650], [200, 650]]), '#dcb6b0');
    soft(x => fill(sm([[318, 490], [350, 476], [372, 560], [350, 650], [320, 630]]), 'rgba(40,36,44,0.8)', x), 14, 1);
    fill(poly([[74, 380], [216, 380], [216, 760], [74, 760]]), '#aa9a68');

    // ── window frame in the sky ──
    fill(poly([[344, 300], [410, 296], [410, 392], [344, 392]]), '#90b4e8');
    stroke(poly([[344, 320], [410, 318], [410, 390], [344, 390]]), '#e8eef8', 4);
    stroke(line([[376, 320], [376, 390]]), '#e8eef8', 3); stroke(line([[344, 355], [410, 355]]), '#e8eef8', 3);
    fill(sm([[340, 312], [356, 300], [380, 302], [394, 312], [380, 318], [350, 318]]), '#5a5a8a');
    // thin rod
    stroke(line([[322, 300], [360, 180]]), '#3a3a44', 3);

    // ── fingerprint rings on the giant ──
    const FP = sm([[506, 300], [530, 256], [580, 236], [630, 250], [664, 300], [684, 370], [690, 430], [676, 490], [620, 470], [580, 446], [540, 424], [516, 380]]);
    const FPT = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 d = (p - vec2(470., 560.)) * vec2(1., .92);
        float r = length(d) + 4. * sin(atan(d.y, d.x) * 5.);
        float s = smoothstep(-.25, .25, sin(r * 6.2832 / 12.));
        return mix(vec3(.10, .10, .13), vec3(.93, .93, .96), s); }`);
    clipA(FP, () => { img(FPT); soft(x => fill(sm([[506, 300], [540, 250], [560, 300], [540, 380]]), 'rgba(120,124,140,0.8)', x), 16, 1); });

    // ── rainbow flag ──
    const BANDS = ['#ee2a1c', '#f47e1e', '#f6e22a', '#2e9a3a', '#2a64e4', '#8a3cb8'];
    const T0 = [444, 488, 528, 564, 600, 640, 668], SL = [-0.2, -0.25, -0.3, -0.325, -0.375, -0.425, -0.5];
    const edge = k => { const pts = []; for (let x = -10; x <= 206; x += 8) pts.push([x, T0[k] + SL[k] * x + 10 * Math.sin(x * 0.07 - 0.18 + k * 0.05)]); return pts; };
    fill(sm([[-10, 650], [100, 620], [200, 590], [220, 700], [-10, 700]]), '#141016');
    for (let k = 0; k < 6; k++) fill(P([...edge(k), ...edge(k + 1).reverse()], true, true), BANDS[k]);
    clipA(poly([[202, 400], [240, 400], [240, 680], [202, 680]]), () => fill(poly([[200, 380], [260, 380], [260, 700], [200, 700]]), '#aa9a68'));

    // ── white pipes top-left + coil cable ──
    const PIPE = '#e6e6ea';
    for (const [pts, w] of [[[[20, -10], [24, 60], [10, 120], [0, 200]], 18], [[[60, -10], [70, 40], [110, 60], [160, 30], [170, -10]], 16], [[[120, -10], [140, 20], [180, 26]], 12],
      [[[-10, 330], [30, 340], [60, 360]], 20], [[[300, 160], [290, 110], [300, 70], [330, 60], [350, 80], [350, 120]], 12]])
      R.pipe(line(pts), w, PIPE, 0.1, 0.16, 1);
    for (const [pts, w] of [[[[50, 120], [90, 100], [140, 84], [200, 78]], 26], [[[30, 230], [26, 180], [44, 140], [70, 120]], 24], [[[0, 140], [20, 120], [50, 110]], 18], [[[0, 60], [40, 70], [70, 110], [60, 160], [30, 200]], 22], [[[90, -10], [96, 40], [130, 70], [180, 64]], 18], [[[-10, 250], [20, 280], [30, 330]], 16]])
      R.pipe(line(pts), w, '#e2e2e8', 0.12, 0.16, 1);
    const COIL = [[26, 230], [30, 300], [48, 350], [80, 395], [110, 425], [138, 440]];
    R.pipe(line(COIL), 14, '#c8c8cc', 0.2, 0.1, 2);
    clipA(P(lock(COIL, 16, 16), true, true), () => { for (let y = 220; y < 460; y += 4.5) stroke(line([[0, y], [160, y - 40]]), 'rgba(60,60,66,0.7)', 1.4); });

    // ── tongue ──
    const TONG = sm([[30, 196], [58, 150], [110, 136], [180, 142], [214, 160], [226, 228], [252, 296], [292, 346], [342, 378], [400, 396], [458, 414], [494, 442], [502, 460],
      [470, 472], [400, 482], [330, 492], [262, 496], [200, 486], [150, 460], [104, 420], [62, 368], [36, 302], [26, 244]]);
    R.dome(TONG, lin(40, 0, 500, 0, [[0, '#962f2a'], [0.25, '#a43c36'], [0.45, '#b85854'], [0.62, '#c06664'], [0.8, '#b4524e'], [1, '#a8443e']]), 0.2, 0.3, 50, 1);
    clipA(TONG, () => soft(x => {
      fill(ellipseP(240, 320, 70, 150, -0.25), 'rgba(236,186,184,0.85)', x); fill(ellipseP(330, 420, 60, 30, 0), 'rgba(226,170,170,0.7)', x);
      fill(sm([[120, 440], [260, 470], [400, 456], [500, 462], [470, 490], [300, 500], [150, 480]]), 'rgba(50,14,12,0.85)', x);
      fill(ellipseP(60, 280, 30, 120, 0.1), 'rgba(110,30,26,0.6)', x);
    }, 20, 1));
    clipA(TONG, () => { const r = rng(15); for (let i = 0; i < 200; i++) { const x = 30 + r() * 470, y = 140 + r() * 350; stroke(line([[x, y], [x + 8 + r() * 10, y + (r() - 0.5) * 3]]), 'rgba(120,40,40,0.18)', 1); } });
    R.bead(252, 476, 6, '#f0f0f2', 0.5, 0.06, 2);
    fill(ellipseP(252, 470, 10, 6, 0), '#6a2420');
    R.bead(198, 170, 3, '#f4f4f4', 0.5, 0.04, 2);

    // ── striped arch with lettering ──
    const ARC_C = [180, 300];
    const arcBand = (r0, r1, t0, t1) => { const pts = []; for (let k = 0; k <= 30; k++) { const t = t0 + (t1 - t0) * k / 30; pts.push([ARC_C[0] + Math.cos(t) * r1, ARC_C[1] + Math.sin(t) * r1 * 1.05]); }
      for (let k = 30; k >= 0; k--) { const t = t0 + (t1 - t0) * k / 30; pts.push([ARC_C[0] + Math.cos(t) * r0, ARC_C[1] + Math.sin(t) * r0 * 1.05]); } return poly(pts); };
    const OUT = arcBand(156, 194, -2.95, -0.5), INB = arcBand(126, 158, -2.95, -0.5);
    R.pipe(arcBand(212, 214, -3.1, -0.35), 16, '#e8e8ec', 0.25, 0.14, 1);
    R.dome(OUT, '#ecebee', 0.3, 0.12, 12, 1);
    clipA(OUT, () => { for (let k = 0; k < 26; k++) { const t = -2.95 + k * 0.095; fill(poly([[ARC_C[0] + Math.cos(t) * 160, ARC_C[1] + Math.sin(t) * 168], [ARC_C[0] + Math.cos(t + 0.045) * 160, ARC_C[1] + Math.sin(t + 0.045) * 168],
      [ARC_C[0] + Math.cos(t + 0.05) * 196, ARC_C[1] + Math.sin(t + 0.05) * 206], [ARC_C[0] + Math.cos(t) * 196, ARC_C[1] + Math.sin(t) * 206]]), '#141216'); } });
    R.dome(INB, '#f0eff2', 0.32, 0.08, 6, 1);
    a.save(); a.fillStyle = '#18161a'; a.font = 'bold 19px serif';
    const TXT = 'ЕІRІBАIBUSІTC@@@';
    for (let k = 0; k < TXT.length; k++) { const t = -2.8 + k * 0.145; a.save(); a.translate(ARC_C[0] + Math.cos(t) * 138, ARC_C[1] + Math.sin(t) * 145); a.rotate(t + Math.PI / 2); a.fillText(TXT[k], -6, 7); a.restore(); }
    a.restore();
    // zebra wedge right of the tongue
    const ZW = sm([[222, 170], [262, 190], [296, 236], [312, 300], [306, 328], [270, 330], [244, 290], [226, 230]]);
    fill(ZW, '#f0eef0');
    clipA(ZW, () => { for (let k = 0; k < 14; k++) stroke(line([[200, 160 + k * 15], [330, 220 + k * 15]]), '#121014', 6); });
    // striped ring
    R.dome(ellipseP(334, 356, 34, 38, 0), '#ecebee', 0.3, 0.18, 12, 1);
    clipA(ellipseP(334, 356, 34, 38, 0), () => { for (let k = 0; k < 6; k++) fill(poly([[298, 326 + k * 14], [372, 318 + k * 14], [372, 324 + k * 14], [298, 332 + k * 14]]), '#141216'); });
    R.flat(ellipseP(348, 356, 18, 28, 0), '#0e0c0e', 0.35, 0);
    // white foam top
    for (const [x, y, r] of [[200, 30, 18], [230, 40, 16], [250, 64, 14], [214, 70, 18], [186, 60, 14], [240, 92, 12], [262, 100, 10], [196, 92, 10]]) R.bead(x, y, r, '#dcdce2', 0.2, 0.12, 1);

    // ── grey runway slab ──
    const TOP = poly([[-10, 902], [150, 840], [300, 784], [340, 700], [560, 652], [736, 650], [736, 690], [600, 734], [450, 795], [300, 852], [150, 902], [-10, 964]]);
    const RW = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float v = p.y + .33 * p.x;
        float g = mix(.86, .74, smoothstep(880., 950., v));
        float dash = step(.6, fract(p.x * .09 + hash(vec2(floor(p.x * .09), floor(v / 7.))) * 3.)) * step(.55, hash(vec2(floor(v / 7.), floor(p.x / 60.))));
        g -= dash * .5 * smoothstep(900., 930., v + 40. * hash(vec2(floor(p.x / 40.), 3.))) * smoothstep(420., 200., p.x);
        g += (hash(floor(p)) - .5) * .05;
        return vec3(g * .97, g * .98, g); }`);
    fill(TOP, '#000'); clipA(TOP, () => img(RW));
    fill(poly([[-10, 964], [150, 902], [300, 852], [450, 795], [600, 734], [736, 690], [736, 700], [600, 744], [450, 805], [300, 862], [150, 912], [-10, 974]]), '#3a3a40');

    // ── graph paper map ──
    const MAP = sm([[150, 1034], [200, 988], [250, 969], [300, 947], [363, 920], [420, 895], [480, 869], [540, 842], [600, 815], [640, 784], [670, 756], [700, 744], [736, 745], [736, 1034]]);
    fill(MAP, '#e8e6e4');
    clipA(MAP, () => {
      for (let x = 150; x < 736; x += 12) stroke(line([[x, 740], [x, 1034]]), 'rgba(100,100,110,0.45)', 1);
      for (let y = 740; y < 1034; y += 12) stroke(line([[150, y], [736, y]]), 'rgba(100,100,110,0.45)', 1);
      for (const [pts, w] of [[[[150, 1010], [300, 960], [450, 920], [600, 890], [736, 880]], 22], [[[480, 1034], [540, 950], [600, 880], [660, 800], [700, 760]], 22],
        [[[620, 860], [680, 900], [736, 950]], 18], [[[560, 780], [620, 830], [700, 870]], 16], [[[600, 990], [680, 960], [736, 940]], 10]]) stroke(line(pts), '#f2e04a', w);
      stroke(line([[492, 997], [712, 997]]), '#e02828', 3); fill(poly([[700, 990], [716, 997], [700, 1004]]), '#e02828');
      const r = rng(81); for (let i = 0; i < 18; i++) { const x = 560 + r() * 170, y = 780 + r() * 200; stroke(line([[x, y], [x + 8, y - 3]]), ['#e04080', '#4080e0', '#f0a020'][i % 3], 3); }
    });
    stroke(line([[150, 1012], [200, 988], [250, 969], [300, 947], [363, 920], [420, 895], [480, 869], [522, 850]]), '#ec2c80', 8);
    stroke(line([[522, 850], [540, 842], [600, 815], [640, 784], [670, 756], [692, 746]]), '#3a68e8', 8);
    stroke(line([[692, 746], [736, 745]]), '#ec2c80', 7);
    // moons
    for (const [x, y, r] of [[588, 786, 13], [512, 838, 8]]) { fill(circleP(x, y, r), '#f4f2e8'); fill(circleP(x + r * 0.45, y - r * 0.3, r * 0.9), '#0c0a0c'); }

    // ── zebra spine of ribs ──
    const SP = [[96, 690], [200, 676], [300, 652], [370, 640], [430, 618], [480, 584], [524, 532], [562, 472], [590, 410], [604, 350], [608, 296], [606, 256]];
    // walk the spine at a fixed rib spacing
    const segs = []; let acc = 0;
    for (let i = 0; i < SP.length - 1; i++) { const [x0, y0] = SP[i], [x1, y1] = SP[i + 1], L = Math.hypot(x1 - x0, y1 - y0); segs.push([x0, y0, x1, y1, L, acc]); acc += L; }
    const ribs = [];
    for (let s = 6; s < acc; s += 27) { const g = segs.find(q => s >= q[5] && s < q[5] + q[4]) || segs[segs.length - 1], u = (s - g[5]) / g[4];
      ribs.push([g[0] + (g[2] - g[0]) * u, g[1] + (g[3] - g[1]) * u, Math.atan2(g[3] - g[1], g[2] - g[0]), s / acc]); }
    const RIBEND = (x, y, ang, f) => { const n0 = Math.sin(ang), n1 = -Math.cos(ang), l = 0.5 * Math.max(0, 1 - f * 2.2), nx = n0 * Math.cos(l) - n1 * Math.sin(l), ny = n0 * Math.sin(l) + n1 * Math.cos(l);
      return [nx, ny, 6, 104 + Math.sin(f * 3.1416) * 30 - f * 30]; };
    // dark band behind the ribs
    for (const [x, y, ang, f] of ribs) { const [nx, ny, up, dn] = RIBEND(x, y, ang, f), cx = -ny * 15, cy = nx * 15;
      fill(poly([[x - nx * dn * 0.9 - cx, y - ny * dn * 0.9 - cy], [x + nx * up - cx, y + ny * up - cy], [x + nx * up + cx, y + ny * up + cy], [x - nx * dn * 0.9 + cx, y - ny * dn * 0.9 + cy]]), '#121014'); }
    for (const [x, y, ang, f] of ribs) {
      const [nx, ny, up, dn] = RIBEND(x, y, ang, f), cx = -ny, cy = nx, w = 10.5;
      const w2 = w * 0.75, rib = sm([[x + nx * up - cx * w, y + ny * up - cy * w], [x + nx * (up + 5), y + ny * (up + 5)], [x + nx * up + cx * w, y + ny * up + cy * w],
        [x - nx * dn * 0.5 + cx * w * 0.95, y - ny * dn * 0.5 + cy * w * 0.95], [x - nx * (dn - 6) + cx * w2, y - ny * (dn - 6) + cy * w2], [x - nx * dn, y - ny * dn],
        [x - nx * (dn - 6) - cx * w2, y - ny * (dn - 6) - cy * w2], [x - nx * dn * 0.5 - cx * w * 0.9, y - ny * dn * 0.5 - cy * w * 0.9]]);
      R.dome(rib, lin(x + nx * up, y + ny * up, x - nx * dn, y - ny * dn, [[0, '#f6f6f8'], [0.6, '#e4e4e8'], [1, '#b0b0b8']]), 0.25, 0.22, 7, 1);
      clipA(rib, () => stroke(line([[x + nx * up + cx * w * 0.45, y + ny * up + cy * w * 0.45], [x - nx * dn * 0.5 + cx * w * 0.5, y - ny * dn * 0.5 + cy * w * 0.5], [x - nx * dn + cx * w * 0.3, y - ny * dn + cy * w * 0.3]]), 'rgba(24,22,28,0.85)', 4.5));
    }
    // microphone + film reel
    R.dome(ellipseP(566, 462, 32, 30, -0.3), '#b8b8c0', 0.4, 0.14, 12, 2);
    clipA(ellipseP(566, 462, 32, 30, -0.3), () => { for (let k = 0; k < 12; k++) stroke(line([[530, 440 + k * 6], [600, 430 + k * 6]]), 'rgba(30,30,36,0.7)', 2); });
    R.dome(circleP(486, 536, 30), '#e8e8ec', 0.4, 0.14, 10, 2);
    for (const [x, y] of [[486, 520], [472, 544], [500, 544], [486, 536]]) fill(circleP(x, y, 6), '#141216');
    R.pipe(line([[500, 466], [530, 470]]), 8, '#d0d0d6', 0.4, 0.06, 2);

    // ── red ball + white tentacles lower-left ──
    R.dome(circleP(30, 790, 66), lin(0, 730, 60, 850, [[0, '#c86a6a'], [1, '#a04848']]), 0.1, 0.3, 50, 3);
    for (const [pts, w] of [[[[-10, 700], [20, 720], [60, 760], [80, 820], [70, 850]], 18], [[[140, 720], [120, 780], [96, 840]], 16], [[[150, 740], [190, 790], [220, 830]], 14],
      [[[110, 760], [150, 800], [170, 850]], 12]]) R.pipe(line(pts), w, '#e8e8ec', 0.2, 0.18, 1);

    // ── black dots ──
    for (const [x, y, r] of [[514, 298, 15], [700, 526, 12], [635, 700, 25], [552, 588, 10], [611, 546, 8], [672, 565, 6], [352, 731, 8], [543, 740, 7], [576, 340, 6], [524, 352, 6], [432, 380, 5], [474, 365, 4]])
      R.dome(circleP(x, y, r), '#0a080a', 0.4, 0.12, r * 0.6, 4);

    // ── texts + borders ──
    fill(poly([[-10, -10], [736, -10], [736, 9], [-10, 9]]), '#08060a');
    fill(poly([[-10, 1010], [736, 1010], [736, 1034], [-10, 1034]]), '#08060a');
    a.save(); a.font = 'bold 13px sans-serif'; a.fillStyle = '#f4f4f4'; a.fillText('STRASER MOCKNTHANADYA', 8, 999);
    a.fillStyle = '#141216'; a.fillText('DLB.IB.SHY TO1RG REST  D6RADANOSIT', 228, 999); a.restore();
    // graph paper strip top-left
    fill(poly([[-10, 9], [26, 9], [26, 130], [-10, 130]]), '#e8e8ea');
    clipA(poly([[-10, 9], [26, 9], [26, 130], [-10, 130]]), () => { for (let y = 9; y < 130; y += 9) stroke(line([[-10, y], [26, y]]), 'rgba(90,90,100,0.6)', 1); for (let x = 0; x < 26; x += 9) stroke(line([[x, 9], [x, 130]]), 'rgba(90,90,100,0.6)', 1); });
    fill(poly([[26, 9], [44, 9], [44, 100], [26, 100]]), lin(0, 9, 0, 100, [[0, '#4060e0'], [0.5, '#e04060'], [1, '#f0a030']]));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 22, wrap: 0.5, ao: 0.5, emis: 0.1 }),              // 1 white plastic / flesh
        E.mat({ dif: 0.8, metal: 0.3, spec: 0.9, shin: 40, wrap: 0.3, ao: 0.4 }),           // 2 metal
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4 }),                          // 3 ball
        E.mat({ dif: 1, spec: 0.8, shin: 60, wrap: 0.2 })                                    // 4 glossy black
      ],
      light: [0.35, 0.55, 0.76], lc: [0.72, 0.72, 0.74], amb: [0.42, 0.42, 0.45],
      envTop: [1, 1, 1], envHor: [0.6, 0.62, 0.66], envBot: [0.2, 0.2, 0.22], envK: [0.3, 0.8, 0.3, 0],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [5, 7, 0.45, 6]
    });
    E.grain(0.05, 13);
  }
});
