'use strict';
// g066 — "Koala keyboard rapture": flat comic collage — a fuzzy grey koala flings an arm past a wavy
// zebra flag, a yelling yellow-haired kid in a brown hood on a spiky purple aura, an orange lattice
// creature with a lens eye playing a white keyboard, lilac coral maze, teal moon disc and yellow crescent.
REC.register('g066', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, o = E.out, S = E.S;
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const FK = (path, c, wd = 3, kc = '#08060a') => { F(path, c); K(path, kc, wd); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = o.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const shadowed = (path, dx, dy, c = '#08060a') => { o.save(); o.translate(dx, dy); F(path, c); o.restore(); };
    const poly = pts => P(pts, true, false);
    const r = rng(66);

    // ── backdrop: grey wall, teal moon disc, yellow crescent ──
    F(rrect(0, 0, W, H, 0), '#a4a4a4');
    const teal = P([[362, -10], [740, -10], [740, 980], [420, 980], [380, 700], [372, 400], [372, 200], [366, 60]], true, false);
    F(teal, '#9bbeb8');
    const yellow = P([[600, -10], [660, 20], [700, 60], [722, 100], [740, 160], [740, 990], [640, 960], [520, 982], [420, 1000], [440, 968], [510, 940], [600, 862], [670, 780], [726, 716], [726, 120], [690, 60], [640, 20]], true, true);
    F(yellow, '#fbef99');
    F(P([[650, -10], [740, -10], [740, 50], [712, 40], [680, 14]]), '#fd7905');
    K(P([[600, -10], [660, 20], [700, 60], [722, 100], [730, 160]], false), '#3a3a30', 2);
    // grey ground with grass bottom right
    F(P([[380, 1030], [420, 1000], [520, 982], [640, 960], [740, 935], [740, 1030]]), '#8e928c');
    K(P([[420, 1000], [520, 982], [640, 960], [740, 935]], false), '#d8a840', 4);

    // ── top-left board with ruler edge, black strip, brown pole ──
    F(rrect(-10, -10, 128, 246, 0), '#a69d9c');
    F(rrect(104, -10, 16, 246, 0), '#a8733e'); F(rrect(-10, 222, 130, 14, 0), '#a8733e');
    for (let y = 4; y < 222; y += 9) K(P([[106, y], [y % 27 < 9 ? 114 : 110, y]], false), '#4a2a10', 1.5);
    for (let x = 4; x < 104; x += 9) K(P([[x, 224], [x, x % 27 < 9 ? 232 : 228]], false), '#4a2a10', 1.5);
    K(rrect(-10, -10, 130, 246, 0), '#1a1008', 2.5);
    F(P([[-10, 236], [48, 236], [40, 320], [30, 420], [18, 520], [-10, 540]]), '#050505');
    F(rrect(-10, 556, 30, 300, 6), '#b57643'); K(rrect(-10, 556, 30, 300, 6), '#1a0a04', 2.5);
    for (const y of [640, 660, 790, 810]) F(rrect(-10, y, 32, 10, 3), '#4a3020');
    F(P(blob(4, 592, 12, 12, 3, 10, 0.3)), '#f4efe6');

    // ── wavy zebra flag ──
    const flag = P([[124, -10], [312, -10], [348, 80], [396, 160], [446, 236], [450, 336], [240, 336], [206, 290], [168, 200], [126, 100]], true, false);
    const zeb = pat(E.fx(`const float YB[18] = float[18](118., 130., 138., 147., 160., 163., 161., 167., 182., 191., 194., 198., 216., 236., 244., 252., 264., 276.);
      vec3 fx(vec2 uv, vec2 p){
      float t = clamp((p.x - 110.) / 20., 0., 16.999); int i = int(t);
      float yb = mix(YB[i], YB[i + 1], fract(t));
      float s = cos(6.2832 * (p.y - yb) / 56.);
      return mix(vec3(0.99), vec3(0.01), smoothstep(-0.12, 0.12, s)); }`));
    shadowed(flag, 6, 6, 'rgba(0,0,0,0.35)');
    FK(flag, zeb, 3);
    K(P([[150, -10], [170, 40], [210, 90], [256, 128]], false), '#f4f4f4', 3);
    FK(P([[244, 122], [262, 112], [276, 126], [266, 134], [258, 146], [252, 132]]), '#c8ccd8', 1.5);

    // ── snow flakes ──
    for (const [x, y, rx, ry, a] of [[58, 100, 10, 26, 0.1], [8, 40, 6, 12, 0.3], [128, 300, 6, 30, -0.7], [66, 620, 8, 20, -0.9], [372, 34, 6, 12, 0.2], [446, 92, 14, 10, 0.4],
      [600, 112, 14, 10, -0.3], [682, 84, 10, 8, 0.2], [520, 148, 6, 5, 0], [548, 60, 4, 6, 0], [700, 230, 4, 5, 0]]) F(ellipseP(x, y, rx, ry, a), '#f6efe2');

    // ── silver ring + crack ──
    const ring = P(Array.from({ length: 40 }, (_, i) => { const t = -1.15 + i / 39 * 5.0; return [90 + Math.cos(t) * 55, 466 + Math.sin(t) * 58]; }), false);
    K(ring, '#0c0c10', 22); K(ring, '#d8dce6', 15); K(ring, '#7a7e8c', 6);
    o.save(); o.translate(-3, -4); K(ring, 'rgba(255,255,255,0.9)', 3); o.restore();
    { const pts = []; for (let x = 150; x <= 330; x += 6) pts.push([x, 434 + (r() - 0.5) * 8 + (x > 220 && x < 280 ? -6 : 0)]); K(P(pts, false, false), '#2a2a2a', 1.2); }

    // ── purple board with lilac coral maze ──
    const board = P([[548, 178], [600, 132], [640, 112], [690, 108], [740, 118], [740, 640], [700, 660], [660, 720], [600, 790], [520, 856], [440, 906], [370, 942], [300, 962], [260, 960], [330, 860], [460, 760], [540, 640], [560, 420], [540, 300]]);
    shadowed(board, 0, 18);
    F(board, '#5f3294');
    const coral = pat(E.fx(`float Fm(vec2 p){ vec2 q = p + 34. * vec2(fbm(p * 0.01), fbm(p * 0.01 + 5.)); return sin(q.x * 0.07) * sin(q.y * 0.06 + 0.6) + 0.25 * sin((q.x - q.y) * 0.05); }
      vec3 fx(vec2 uv, vec2 p){
      float f = Fm(p);
      vec2 g = vec2(Fm(p + vec2(1., 0.)) - Fm(p - vec2(1., 0.)), Fm(p + vec2(0., 1.)) - Fm(p - vec2(0., 1.))) * 0.5;
      float d = abs(f) / (length(g) + 1e-4);
      vec3 pur = vec3(0.37, 0.20, 0.58), lil = vec3(0.98, 0.90, 0.94), edge = vec3(0.72, 0.58, 0.88);
      vec3 c = mix(pur, edge, smoothstep(8.5, 7., d));
      c = mix(c, lil, smoothstep(6., 4.5, d));
      return c; }`));
    C(P([[600, 132], [690, 104], [740, 110], [740, 650], [690, 660], [640, 600], [620, 400], [600, 250]]), () => F(board, coral));
    // board lip: pink rim + purple edge along the lower-left
    const lipPts = [[740, 640], [700, 662], [662, 722], [604, 792], [524, 858], [444, 908], [372, 944], [300, 964]];
    K(P(lipPts, false), '#3a1a6a', 18); K(P(lipPts, false), '#f6dcea', 10); K(P(lipPts.map(([x, y]) => [x - 2, y - 8]), false), '#7a4ac8', 5);

    // ── spiky purple aura + cyan zigzag ──
    const auraC = [[248, 512], [300, 520], [360, 560], [400, 640], [404, 760], [380, 880], [330, 950], [250, 968], [170, 950], [118, 880], [96, 760], [100, 660], [130, 580], [180, 528]];
    const spikes = P(ragged(auraC, 0, auraC.length, 16, 16, 9));
    K(spikes, '#5bbddc', 7);
    F(spikes, '#aa60c3');
    C(spikes, () => { for (let i = 0; i < 520; i++) F(ellipseP(80 + r() * 340, 500 + r() * 480, 2 + r() * 2.5, 1.5 + r() * 2, r() * 3), '#6a2a8a'); });
    K(spikes, '#1a0a20', 1.5);

    // ── koala ──
    const fur = (pts, seed, amp = 6) => P(ragged(P2(pts), 0, 9999, 4, amp, seed), true, false);
    const P2 = pts => { const out = []; const n = pts.length; for (let i = 0; i < n; i++) { const a = pts[(i - 1 + n) % n], b = pts[i], c = pts[(i + 1) % n], d = pts[(i + 2) % n]; for (let k = 0; k < 4; k++) { const t = k / 4, t2 = t * t, t3 = t2 * t; out.push([0, 1].map(j => 0.5 * ((2 * b[j]) + (-a[j] + c[j]) * t + (2 * a[j] - 5 * b[j] + 4 * c[j] - d[j]) * t2 + (-a[j] + 3 * b[j] - 3 * c[j] + d[j]) * t3))); } } return out; };
    const arm = fur([[184, 336], [240, 326], [320, 318], [400, 310], [440, 320], [440, 400], [400, 396], [330, 376], [250, 372], [190, 362]], 31, 3.5);
    const body = fur([[330, 380], [380, 360], [440, 360], [470, 400], [470, 500], [440, 540], [400, 536], [360, 500], [336, 450]], 32, 6);
    const head = fur([[430, 260], [460, 200], [486, 160], [512, 210], [560, 190], [626, 196], [618, 250], [640, 300], [626, 380], [580, 400], [520, 404], [470, 390], [430, 350]], 33, 4.5);
    for (const p of [arm, body, head]) shadowed(p, -6, 8);
    F(body, '#b0a39b'); K(body, '#08060a', 2.5);
    F(arm, '#b6a9a1'); K(arm, '#08060a', 2.5);
    F(head, '#b6a9a1'); K(head, '#08060a', 2.5);
    C(head, () => { F(ellipseP(500, 230, 30, 50, 0.4), '#c8bdb4'); F(ellipseP(600, 250, 26, 40, -0.3), '#c8bdb4'); });
    for (const [x, y] of [[475, 288], [555, 326]]) { FK(circleP(x, y, 15), '#fbfbf8', 3); F(circleP(x + 1, y + 1, 8), '#08060a'); F(circleP(x - 2, y - 3, 2.5), '#fff'); }
    FK(P([[444, 334], [470, 318], [496, 312], [494, 340], [482, 372], [468, 386], [456, 372], [446, 352]]), '#43403f', 2.5);
    K(P([[404, 394], [414, 402], [410, 410]], false), '#08060a', 2); F(circleP(412, 398, 4), '#08060a');

    // ── orange lens creature ──
    const OR = '#f99a0a', ORk = '#2a1004';
    // tail curling up-right
    const tail = P([[540, 420], [588, 396], [632, 410], [650, 452], [660, 520], [690, 556], [712, 580], [700, 604], [664, 590], [636, 556], [622, 500], [612, 456], [586, 440], [556, 450]]);
    shadowed(tail, -5, 8); FK(tail, OR, 3, ORk);
    // lattice body
    const lat = P([[430, 540], [500, 516], [580, 520], [612, 580], [612, 680], [590, 740], [520, 770], [460, 770], [430, 720], [420, 640]]);
    shadowed(lat, -6, 8);
    FK(lat, '#6b5544', 3);
    C(lat, () => {
      const gl = (pts) => { K(P(pts, false), ORk, 15); };
      const go = (pts) => { K(P(pts, false), OR, 10); };
      const rows = [], cols = [];
      for (let j = 0; j < 7; j++) { const y = 548 + j * 38; rows.push([[400, y + 30], [470, y + 8], [520, y], [570, y + 4], [630, y + 22]]); }
      for (let i = 0; i < 6; i++) { const x = 446 + i * 36; cols.push([[x + (x - 520) * 0.1, 520], [x + (x - 520) * 0.25, 640], [x + (x - 520) * 0.45, 790]]); }
      for (const l of [...rows, ...cols]) gl(l);
      for (const l of [...rows, ...cols]) go(l);
      F(P([[430, 540], [612, 540], [612, 570], [430, 570]]), 'rgba(0,0,0,0.25)');
    });
    for (const [x, y] of [[566, 578], [422, 654], [566, 652], [430, 716]]) { F(circleP(x + 2, y + 3, 11), '#2a1408'); FK(circleP(x, y, 11), '#f6f4f2', 2); F(ellipseP(x - 3, y - 4, 4, 3, 0), '#fff'); }
    // head: orange shell round a dark speaker and a white lens
    const shell = P([[410, 470], [430, 420], [472, 396], [530, 392], [570, 412], [580, 470], [560, 540], [520, 580], [470, 586], [430, 566], [412, 520]]);
    shadowed(shell, -6, 8); FK(shell, OR, 3, ORk);
    const spk = ellipseP(490, 488, 70, 80, 0.15);
    FK(spk, '#3c2a1e', 2.5, ORk);
    for (let k = 1; k < 6; k++) K(ellipseP(498 - k * 2, 490, 70 - k * 9, 80 - k * 9, 0.15), 'rgba(110,80,60,0.6)', 1.5);
    FK(ellipseP(476, 486, 42, 50, 0.1), '#c8cfd3', 2.5);
    F(ellipseP(468, 474, 26, 30, 0.1), '#f4f6f8');
    C(ellipseP(476, 486, 42, 50, 0.1), () => { for (let i = 0; i < 90; i++) F(circleP(440 + r() * 76, 440 + r() * 96, 0.8), '#7a8088'); });

    // ── hooded kid ──
    const hood = ellipseP(262, 742, 122, 190, -0.12);
    shadowed(hood, -6, 8);
    FK(hood, '#846e43', 3);
    C(hood, () => { for (let i = 0; i < 700; i++) F(circleP(130 + r() * 260, 550 + r() * 390, 0.9), 'rgba(40,28,10,0.45)'); });
    const opening = ellipseP(262, 688, 96, 112, -0.2);
    F(opening, '#08060a');
    const face = P([[200, 620], [260, 600], [320, 610], [350, 650], [352, 720], [330, 780], [282, 804], [230, 790], [200, 750], [186, 700]]);
    F(face, '#b6a99f');
    F(ellipseP(194, 722, 14, 18, 0), '#b6a99f'); K(ellipseP(194, 722, 14, 18, 0), '#08060a', 2.5); K(ellipseP(196, 722, 7, 9, 0), '#5a4a40', 2);
    // beard tufts
    F(P([[220, 770], [240, 790], [252, 776], [268, 796], [282, 780], [300, 794], [314, 774], [330, 784], [324, 806], [280, 816], [236, 806]]), '#8a7c72');
    // hair
    const hair = P([[184, 670], [190, 628], [214, 600], [250, 584], [296, 580], [330, 592], [330, 604], [300, 600], [284, 612], [256, 606], [230, 624], [214, 650], [204, 690]]);
    FK(hair, '#f4ea10', 2.5);
    for (let i = 0; i < 6; i++) K(P([[200 + i * 16, 640 - i * 8], [214 + i * 18, 612 - i * 4]], false), '#8a7a00', 1.5);
    // mouth
    const mouth = P([[226, 700], [256, 664], [300, 644], [330, 640], [332, 668], [314, 700], [280, 724], [244, 728]]);
    FK(mouth, '#08060a', 3);
    C(mouth, () => {
      F(P([[240, 720], [270, 690], [310, 666], [334, 664], [326, 700], [284, 724]]), '#fb0890');
      for (let i = 0; i < 5; i++) F(ellipseP(250 + i * 18, 680 - i * 8, 9, 8, -0.4), '#fbfbfb');
      for (let i = 0; i < 4; i++) F(ellipseP(264 + i * 18, 724 - i * 9, 8, 7, -0.4), '#fbfbfb');
    });
    // brown drum + scalloped white rim
    const pot = P([[206, 862], [378, 742], [400, 800], [396, 880], [330, 940], [250, 960], [214, 930]], true, false);
    FK(pot, '#79655c', 3);
    C(pot, () => { for (let i = 0; i < 500; i++) F(circleP(200 + r() * 200, 740 + r() * 220, 0.9), 'rgba(40,28,20,0.35)'); });
    const band = P([[204, 846], [376, 728], [384, 752], [212, 872]], true, false);
    FK(band, '#f4f2ee', 2.5);
    { const pts = []; for (let i = 0; i <= 16; i++) { const t = i / 16; pts.push([210 + 172 * t, 870 - 120 * t + (i % 2 ? 9 : 0)]); } K(P(pts, false), '#f4f2ee', 7); }
    // hook / tail at the left of the drum
    K(P([[230, 900], [200, 880], [170, 868], [146, 878], [136, 900], [150, 912]], false), '#08060a', 16);
    K(P([[230, 900], [200, 880], [170, 868], [146, 878], [136, 900], [150, 912]], false), '#846e43', 10);
    // flame bits
    F(P([[272, 790], [290, 752], [300, 780], [318, 744], [326, 782], [306, 800]]), '#f08a10');

    // ── white keyboard ──
    const KA = -0.595, kc = Math.cos(KA), ks = Math.sin(KA);
    const kb = new Path2D(); { const m = new DOMMatrix().translate(478, 782).rotate(KA * 180 / Math.PI); kb.addPath(rrect(-178, -32, 356, 64, 30), m); }
    shadowed(kb, -4, 16);
    FK(kb, '#f8f8f6', 3);
    const kr = rng(7);
    for (let i = 0; i < 5; i++) {
      const u = -96 + i * 62, x = 478 + kc * u + ks * 6, y = 782 + ks * u - kc * 6;
      o.save(); o.translate(x, y); o.rotate(-0.3 + (kr() - 0.5) * 0.3);
      const man = new Path2D();
      man.addPath(circleP(0, -26, 12));
      man.addPath(rrect(-11, -18, 22, 36, 10));
      man.addPath(rrect(-27, -13, 54, 14, 7));
      shadowed(man, 3, 4, 'rgba(60,40,80,0.5)');
      F(man, '#08060a');
      K(P([[-5, 14], [-13, 38]], false), '#08060a', 12);
      K(P([[5, 14], [13, 38]], false), '#08060a', 12);
      o.restore();
    }
    o.save(); o.translate(352, 866); o.rotate(KA); F(rrect(-18, -8, 36, 16, 2), '#3a3a3a'); o.fillStyle = '#ddd'; o.font = '9px sans-serif'; o.textAlign = 'center'; o.fillText('hnmo', 0, 3); o.restore();

    // leg/arm reaching down-left
    const leg = P([[446, 604], [410, 640], [384, 676], [380, 720], [392, 770], [404, 796], [396, 808], [380, 800], [362, 760], [358, 716], [366, 668], [400, 624], [434, 588]]);
    shadowed(leg, -4, 6); FK(leg, OR, 3, ORk);

    // ── clouds + grass along the bottom ──
    const cloud = new Path2D();
    for (const [x, y, rr] of [[20, 990, 46], [90, 975, 40], [160, 990, 36], [230, 968, 40], [300, 975, 46], [370, 985, 40], [440, 998, 34], [-10, 960, 30]]) cloud.addPath(circleP(x, y, rr));
    cloud.addPath(rrect(-10, 980, 480, 60, 0));
    o.save(); o.lineWidth = 5; o.strokeStyle = '#4a4a48'; o.stroke(cloud); o.restore();
    F(cloud, '#fdf6ec');
    const cloud2 = new Path2D();
    for (const [x, y, rr] of [[60, 1030, 26], [130, 1022, 22], [250, 1018, 26], [330, 1022, 24], [410, 1030, 22]]) cloud2.addPath(circleP(x, y, rr));
    F(cloud2, '#979c96');
    for (let i = 0; i < 26; i++) {
      const x = 420 + r() * 300, h = 30 + r() * 80, lean = (r() - 0.5) * 40;
      K(P([[x, 1030], [x + lean * 0.4, 1030 - h * 0.5], [x + lean, 1030 - h]], false), '#121212', 1.5 + r() * 1.5);
    }
    for (let i = 0; i < 10; i++) { const x = 20 + r() * 420, h = 20 + r() * 50; K(P([[x, 1030], [x + (r() - 0.5) * 20, 1030 - h]], false), '#121212', 1.5); }

    E.grain(0.035, 66);
  }
});
