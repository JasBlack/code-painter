'use strict';
// g093 — "Porcelain hypnosis garden": glossy white clay plates and lobes with spiral eyes, a fingerprint-maze
// disc, black and brown spots and blurred target rings, against a pink-to-mint pastel sky, with a blue glint.
REC.register('g093', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // procedural height (and albedo) from GLSL: hgt(p) in 0..1 -> height-buffer colour for material m
    const hfx = (body, m) => E.fx(`${body}
      vec3 fx(vec2 uv, vec2 p){ float h = clamp(hgt(p), 0., 1.) * 255.; return vec3(floor(h) / 255., ${(m * 32 / 255).toFixed(5)}, fract(h)); }`);
    const spiral = (cx, cy, r, turns, col, wd, rot = 0) => {
      const pts = []; for (let i = 0; i <= turns * 40; i++) { const t = i / 40, ang = rot + t * 6.2832, rr = r * t / turns; pts.push([cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr]); }
      a.save(); a.lineWidth = wd; a.strokeStyle = col; a.lineCap = 'round'; a.stroke(P(pts, false, false)); a.restore();
    };

    // ── pastel sky ──
    const sky = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y + 6. * sin(p.x * 0.01);
      vec3 c = vec3(.96, .93, .74);
      c = mix(c, vec3(.97, .6, .62), smoothstep(110., 190., y));
      c = mix(c, vec3(.98, .55, .8), smoothstep(200., 270., y));
      c = mix(c, vec3(.96, .6, .95), smoothstep(280., 330., y));
      c = mix(c, vec3(.78, .72, .97), smoothstep(320., 380., y));
      c = mix(c, vec3(.8, .87, .98), smoothstep(370., 420., y));
      c = mix(c, vec3(.82, .95, .99), smoothstep(420., 470., y));
      c = mix(c, vec3(.74, .84, .98), smoothstep(500., 545., y));
      c = mix(c, vec3(.58, .68, .58), smoothstep(548., 565., y));
      // left side slightly more lavender in the pink band
      c = mix(c, vec3(.78, .58, .87), (1. - smoothstep(180., 420., p.x)) * smoothstep(230., 280., y) * (1. - smoothstep(320., 360., y)) * .6);
      c += 0.02 * sin(y * 0.21) ;
      return c; }`);
    R.flat(rrect(-10, -10, 746, 1044, 0), '#c8d0e8', 0, 0);
    img(sky);

    // ── rods behind ──
    R.pipe(P([[112, -10], [108, 50], [100, 118]], false), 30, '#4c4048', 0.05, 0.12, 3);
    R.pipe(P([[622, 196], [622, 260], [612, 330], [596, 392], [574, 446]], false), 26, '#3a3038', 0.05, 0.14, 3);

    const O = [720, 480], U = [-0.6917, 0.7222], N = [0.7222, 0.6917];
    const edge = [];
    for (let t = 0; t <= 770; t += 5) {
      const base = 95 - 130 * Math.pow(0.5 + 0.5 * Math.cos(2 * Math.PI * (t - 295) / 130), 3);
      const d = t < 190 ? 60 : t < 240 ? 60 + (base - 60) * (t - 190) / 50 : base;
      edge.push([O[0] + U[0] * t + N[0] * d, O[1] + U[1] * t + N[1] * d]);
    }
    // ── brown field lower right with blurred target rings ──
    const field = P([[560, 540], [700, 470], [746, 470], [746, 1044], [140, 1044]], true, false);
    R.flat(field, lin(560, 500, 500, 1024, [[0, '#5e4c48'], [0.4, '#3c302e'], [1, '#2a2424']]), 0.0, 2);
    { const gr = rng(931); clipA(field, () => { for (let i = 0; i < 2500; i++) { a.fillStyle = gr() < 0.5 ? 'rgba(120,100,95,0.5)' : 'rgba(10,8,8,0.5)'; a.fillRect(140 + gr() * 600, 400 + gr() * 640, 1.4, 1.4); } }); }
    const rings = E.blur(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float r = length(p - vec2(697.5, 927.5));
      float v = cos(6.2832 * (r + 36.63) / 61.94);
      return mix(vec3(.08), vec3(.92, .92, .9), smoothstep(-.25, .25, -v)); }`), 2.5);
    clipA(P([[500, 700], [746, 700], [746, 1044], [420, 1044]], true, false), () => img(rings));
    clipA(field, () => soft(x => { x.translate(10, 12); x.lineWidth = 46; x.strokeStyle = '#030202'; x.stroke(P(edge.slice(38), false, true)); }, 9, 0.92));
    clipAH(P([[500, 700], [746, 700], [746, 1044], [420, 1044]], true, false), () => {
      img(E.blur(hfx(`float hgt(vec2 p){ float r = length(p - vec2(697.5, 927.5)); return 0.02 + 0.12 * smoothstep(-.3, .5, -cos(6.2832 * (r + 36.63) / 61.94)); }`, 2), 2), R.h);
    });

    // ── fingerprint-maze disc (top right) ──
    const disc = P([[432, -10], [746, -10], [746, 248], [682, 233], [639, 204], [576, 179], [495, 160], [455, 142], [436, 100], [430, 40]], true, true);
    R.dome(disc, '#d6d8e2', 0.06, 0.08, 10, 1);
    // maze flow fitted per 60-px tile (quadratic phase each), blended; mz > 0 on the white ridges
    const mazeG = `const vec2 ZC[18] = vec2[18](vec2(475., 30.), vec2(535., 30.), vec2(595., 30.), vec2(655., 30.), vec2(715., 30.), vec2(475., 90.), vec2(535., 90.), vec2(595., 90.), vec2(655., 90.), vec2(715., 90.), vec2(475., 150.), vec2(535., 150.), vec2(595., 150.), vec2(655., 150.), vec2(715., 150.), vec2(595., 210.), vec2(655., 210.), vec2(715., 210.));
const float ZK[108] = float[108](2.0570, 4.2426, 0.2091, 1.1242, 0.0152, -1.6238, -5.0661, 4.8227, 0.1420, -0.2351, -0.2756, -1.7018, 0.5570, 4.3159, 0.2384, 0.7067, 0.4582, -1.9105, 1.5819, 5.2487, 0.3122, -0.4091, -0.4531, -2.7488, 2.4721, 1.2748, 3.1306, -5.5119, 1.3695, -0.8615, -5.3693, 3.6670, -1.5893, 1.5321, -1.7290, -1.6204, -5.3183, -4.7644, 2.0986, -0.2738, -0.1064, 1.8950, -0.0624, -4.2887, 2.0253, 0.0250, 0.4332, 1.7515, 5.3411, -3.6159, 2.8867, 2.0473, 2.2496, 1.7940, -1.2193, -0.4212, -3.7115, -3.8435, -0.8391, -1.6774, 4.6664, -3.3675, 3.0994, 2.3174, -2.8042, 2.1584, 5.5326, -4.9542, 3.3420, -0.9283, -0.4337, 0.4861, 6.3897, 3.6077, -3.0930, -0.6747, -1.7069, -0.1062, 12.3261, 2.4308, -4.1571, -1.8298, -1.8051, -0.1165, 0.9909, 0.5728, 4.9594, 2.9067, 0.9262, 0.1787, 1.7438, -4.9516, 2.9791, 2.2769, -1.7764, -1.0286, 4.8033, -1.0051, 2.0038, 1.2106, 2.2722, -2.2650, -1.4361, 0.3750, 2.7379, 1.8318, 0.1240, -2.3282);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 18; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.2178);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
    float mz(vec2 p){ return -zv(p); }`;
    const discIn = P([[446, -10], [746, -10], [746, 232], [682, 218], [639, 190], [576, 165], [500, 146], [466, 130], [450, 96], [445, 40]], true, true);
    clipA(discIn, () => img(E.fx(`${mazeG}
      vec3 fx(vec2 uv, vec2 p){ float v = mz(p); return mix(vec3(.2, .2, .22), vec3(.86, .87, .92), smoothstep(.05, .35, v)); }`)));
    clipAH(discIn, () => img(hfx(`${mazeG}
      float hgt(vec2 p){ return 0.1 + 0.16 * smoothstep(-.1, .6, mz(p)); }`, 1), R.h));
    R.bead(695, 47, 22, '#a8a8ac', 0.3, 0.2, 3);

    // ── hanging tubes under the disc ──
    R.pipe(P([[486, 150], [482, 200], [472, 250], [478, 296], [496, 340], [520, 378]], false), 30, '#dcdee6', 0.08, 0.22, 1);
    R.pipe(P([[500, 222], [520, 248], [570, 262], [636, 258], [656, 270], [640, 284], [580, 286], [530, 278], [510, 264]], false), 20, '#d8dae2', 0.12, 0.16, 1);
    R.groove(P([[530, 266], [580, 274], [636, 270]], false), 6, '#505058', 0.24, 0.08, 1);

    // ── the upper plate with the eye and two ridges ──
    const plate = P([[118, -14], [446, -14], [440, 60], [450, 118], [472, 150], [468, 178], [430, 196], [400, 213], [350, 232], [300, 253], [250, 268], [200, 277], [160, 282],
      [133, 288], [110, 300], [87, 314], [60, 345], [40, 382], [20, 430], [8, 473], [-14, 505], [-14, 142], [30, 138], [70, 128], [104, 112], [120, 80], [124, 40]], true, true);
    R.dome(plate, '#c6c7cd', 0.06, 0.16, 18, 1);
    clipA(plate, () => { a.lineCap = a.lineJoin = 'round'; a.lineWidth = 46; a.strokeStyle = '#acadb3'; a.stroke(P([[-10, 410], [24, 340], [64, 290], [120, 258], [200, 238], [300, 218], [400, 190], [470, 166]], false)); });
    R.pipe(P([[-10, 330], [20, 290], [40, 262], [70, 233], [100, 214], [167, 194], [267, 180], [333, 168], [427, 148], [474, 142]], false), 22, '#dadce4', 0.18, 0.12, 1);
    // top-left loop
    R.pipe(ellipseP(60, 56, 54, 58, 0), 22, '#d6d8e0', 0.08, 0.16, 1);
    // eye
    R.dome(circleP(272, 93, 50), '#cacbd1', 0.2, 0.08, 16, 1);
    R.pipe(circleP(272, 93, 37), 8, '#e4e6ec', 0.28, 0.06, 1);
    R.flat(circleP(272, 93, 33), '#060606', 0.24, 5);
    R.pipe(circleP(272, 93, 29), 3, '#e8e8ea', 0.25, 0.02, 5);
    // squiggle and a bean
    R.pipe(P([[168, 112], [184, 100], [204, 96], [208, 112], [194, 124], [204, 140], [222, 150], [240, 148], [236, 160]], false), 8, '#d4d6de', 0.22, 0.06, 1);
    R.dome(ellipseP(362, 150, 16, 11, 0.2), '#d6d8e0', 0.22, 0.08, 8, 1);

    // ── the big lower mass: spiky plate + lobed body ──
    const massPts = [[-14, 580], [40, 575], [100, 568], [150, 566], [174, 548], [204, 536], [240, 522], [247, 474], [240, 448], [220, 414], [173, 381], [140, 346],
      [200, 354], [267, 358], [293, 346], [306, 316], [322, 294], [347, 283], [373, 292], [387, 320], [384, 352], [394, 374], [412, 366], [433, 336], [440, 380], [480, 392], [505, 384],
      [518, 364], [530, 402], [556, 428], [576, 468], [610, 486], [640, 468], [648, 420], [664, 382], [694, 362], [746, 356], ...edge, [-14, 1044]];
    const mass = P(massPts, true, false);
    R.dome(mass, lin(0, 400, 600, 1000, [[0, '#d0d0d4'], [1, '#c8c8ce']]), 0.06, 0.24, 34, 1);
    // flat grey lobe at the left of the spiky plate
    R.dome(P([[176, 548], [220, 534], [262, 528], [290, 556], [286, 598], [250, 620], [200, 612], [176, 588]], true, true), '#b4b5ba', 0.24, 0.04, 10, 1);
    // dark hollow at the right edge
    R.flat(ellipseP(704, 512, 30, 28, 0.3), '#0a0808', 0.1, 2);

    // spiral eye with brown ring
    clipA(mass, () => { a.fillStyle = '#7a6458'; a.fill(ellipseP(440, 512, 80, 74, 0)); a.fillStyle = '#d0d2d8'; a.fill(ellipseP(462, 494, 62, 56, 0)); });
    R.flat(circleP(452, 500, 47), '#0a0a0a', 0.3, 5);
    spiral(452, 501, 42, 5.5, '#f2f2f2', 3.4, 1.2);
    // black oval eye + white glint, brown spot
    R.dome(ellipseP(518, 603, 41, 34, -0.35), '#070707', 0.28, 0.04, 8, 5);
    R.flat(circleP(512, 592, 10), '#ffffff', 0.34, 0);
    R.flat(circleP(606, 641, 41), '#7a6056', 0.28, 1);
    // left spiral eye on its raised bump
    R.dome(circleP(97, 668, 80), '#cfd1d8', 0.24, 0.08, 20, 1);
    R.flat(circleP(97, 668, 56), '#080808', 0.32, 5);
    spiral(97, 668, 50, 6, '#f2f2f2', 3.8, 0.4);
    R.flat(ellipseP(36, 716, 9, 6, 0.6), '#7a6056', 0.3, 1);
    R.groove(P([[128, 784], [148, 776]], false), 8, '#8a8a92', 0.3, 0.06, 1);
    // spheres bottom-left
    R.bead(70, 962, 36, '#c8c8cc', 0.3, 0.3, 4);
    R.bead(14, 950, 28, '#c4c4c8', 0.3, 0.3, 4);
    R.bead(36, 1016, 22, '#c4c4c8', 0.3, 0.2, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, spec: 0.5, shin: 26, wrap: 0.35, ao: 0.5, rim: 1.0, coat: 0.12 }),     // 1 white glossy clay
        E.mat({ dif: 1, spec: 0.05, shin: 10, wrap: 0.2 }),                                         // 2 brown field / dark
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.3, ao: 0.4, rim: 0.4, coat: 0.15 }),           // 3 rods / rings
        E.mat({ dif: 0.9, spec: 0.5, shin: 30, wrap: 0.4, rim: 0.8, coat: 0.15 }),                 // 4 spheres
        E.mat({ dif: 1, spec: 1.0, shin: 70, coat: 0.2 })                                          // 5 gloss black
      ],
      light: [-0.45, 0.4, 0.55], lc: [0.75, 0.75, 0.78], amb: [0.4, 0.4, 0.42],
      envTop: [1, 1, 1.05], envHor: [0.72, 0.72, 0.8], envBot: [0.28, 0.28, 0.32], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.5, 0.54, 0.72], rimD: [0, 0, 0], r1: 2.4, r2: 10, k: [0, 0.6, 0.4, 95], shadow: [-10, 12, 0.75, 8]
    });

    // ── blue-white glints and the glare streak ──
    soft(x => { x.fillStyle = '#c8d4ff'; x.fill(ellipseP(390, 600, 90, 50, -0.8)); x.fill(ellipseP(250, 720, 70, 40, -0.8)); x.fill(ellipseP(560, 520, 50, 40, 0)); }, 30, 0.35, 'screen', o);
    soft(x => { x.lineWidth = 70; x.strokeStyle = '#7888d0'; x.beginPath(); x.moveTo(60, 1060); x.lineTo(480, 590); x.stroke(); }, 26, 0.75, 'screen', o);
    soft(x => { x.lineWidth = 16; x.strokeStyle = '#b8c4ff'; x.beginPath(); x.moveTo(60, 1060); x.lineTo(480, 590); x.stroke(); }, 8, 0.5, 'screen', o);
    soft(x => { x.lineWidth = 4; x.strokeStyle = '#ffffff'; x.beginPath(); x.moveTo(100, 1010); x.lineTo(440, 630); x.stroke(); }, 2, 0.6, 'screen', o);
    { const fx0 = 262, fy0 = 792;
      o.fillStyle = rad(fx0, fy0, 40, [[0, 'rgba(255,255,255,1)'], [0.3, 'rgba(220,230,255,0.5)'], [1, 'rgba(200,210,255,0)']], o); o.fill(circleP(fx0, fy0, 40));
      soft(x => { x.fillStyle = '#ffffff'; for (const [dx, dy] of [[90, 0], [0, 70], [60, -60], [-55, 60]]) x.fill(P([[fx0 - dx, fy0 - dy], [fx0 + dy * 0.04, fy0 - dx * 0.04], [fx0 + dx, fy0 + dy], [fx0 - dy * 0.04, fy0 + dx * 0.04]], true, false)); }, 1.5, 0.75, 'screen', o); }
    E.grain(0.035, 93);
  }
});
