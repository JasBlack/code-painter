'use strict';
// g095 — "Golden reel, green tablet": a brushed-gold flower disc with triangle windows on a grommeted white
// clay creature, a grey coiled hose and wheel, purple weave, a green "EDUCTION" tablet, zebra maze and foam spheres.
REC.register('g095', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const CLAY = '#d4d4d8';
    const grommet = (x, y, r) => {
      R.dome(circleP(x, y, r), '#d6d6dc', 0.3, 0.08, r * 0.5, 1);
      R.flat(circleP(x, y, r * 0.72), '#1c1a1c', 0.34, 4);
      R.pipe(circleP(x, y, r * 0.5), r * 0.22, '#c8a868', 0.36, 0.04, 3);
      R.flat(circleP(x, y, r * 0.32), '#ece6da', 0.36, 0);
    };

    // ── grey scratched background ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#cbcbcf', 0, 0);
    { const r = rng(95); a.lineWidth = 0.8;
      for (let i = 0; i < 900; i++) { const x = r() * 330, y = r() * 760, l = 6 + r() * 14, an = -0.9 + (r() - 0.5) * 0.6; a.strokeStyle = r() < 0.5 ? 'rgba(150,150,156,0.55)' : 'rgba(235,235,240,0.6)'; a.beginPath(); a.moveTo(x, y); a.lineTo(x + Math.cos(an) * l, y + Math.sin(an) * l); a.stroke(); } }

    // ── lavender foam spheres behind everything ──
    { const r = rng(951), balls = [];
      for (let i = 0; i < 150; i++) balls.push([150 + r() * 600, 200 + r() * 380, 20 + r() * 26]);
      balls.push([400, 20, 34], [450, 30, 30], [520, 18, 30], [360, 40, 26], [640, 520, 40], [700, 540, 36], [560, 560, 30]);
      balls.sort((p, q) => p[1] - q[1]);
      for (const [x, y, rr] of balls) R.bead(x, y, rr, '#dcdae6', 0.02, 0.12, 2);
    }

    // ── navy yarn ball and the black/white grid dome ──
    R.bead(156, 34, 78, '#14284a', 0.05, 0.25, 5);
    clipA(circleP(156, 34, 78), () => { const r = rng(9); a.strokeStyle = 'rgba(70,100,150,0.45)'; a.lineWidth = 1;
      for (let i = 0; i < 160; i++) { const an = r() * 6.283, rr = r() * 76; a.beginPath(); a.arc(156, 34, rr, an, an + 0.4); a.stroke(); } });
    const gridP = ellipseP(112, 102, 52, 90, -0.25);
    R.dome(gridP, '#141414', 0.08, 0.14, 26, 4);
    clipA(gridP, () => { a.strokeStyle = '#f2eee6'; a.lineWidth = 3.4;
      for (let k = -8; k <= 8; k++) { a.beginPath(); a.ellipse(170, 120, 40 + Math.abs(k) * 0, 0, 0, 0, 0); }
      for (let rr = 30; rr < 170; rr += 13) { a.beginPath(); a.arc(185, 115, rr, 2.0, 4.6); a.stroke(); }
      for (let t = 2.0; t < 4.6; t += 0.13) { a.beginPath(); a.moveTo(185 + Math.cos(t) * 30, 115 + Math.sin(t) * 30); a.lineTo(185 + Math.cos(t) * 170, 115 + Math.sin(t) * 170); a.stroke(); } });

    // ── striped top piece ──
    const zt = P([[198, -12], [352, -12], [358, 40], [342, 100], [304, 142], [256, 152], [214, 124], [196, 64]], true, true);
    R.dome(zt, null, 0.08, 0.2, 26, 1);
    clipA(zt, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 q = (p - vec2(269.5, 61.8)) / 100.; float X = q.x, Y = q.y;
      float v = cos(6.2832 * (6.66694 + 0.96429 * Y + 0.1387 * Y * Y + 2.05379 * X - 0.93531 * X * Y + 0.27971 * X * X));
      return mix(vec3(.96, .95, .93), vec3(.03), smoothstep(-.12, .12, v)); }`)));

    // ── purple fan dome ──
    const fan = circleP(246, 262, 98);
    R.dome(fan, '#8c6ad6', 0.08, 0.14, 30, 2);
    clipA(fan, () => { a.strokeStyle = '#f0ecfa'; a.lineWidth = 3; for (let i = 0; i < 48; i++) { const t = i / 48 * 6.283; a.beginPath(); a.moveTo(246 + Math.cos(t) * 22, 262 + Math.sin(t) * 22); a.lineTo(246 + Math.cos(t) * 98, 262 + Math.sin(t) * 98); a.stroke(); }
      a.lineWidth = 4; a.beginPath(); a.arc(246, 262, 24, 0, 6.283); a.stroke(); a.beginPath(); a.arc(246, 262, 70, 0, 6.283); a.stroke(); });

    // ── zebra maze field (lower left) ──
    const zf = P([[-12, 714], [110, 560], [200, 500], [348, 486], [390, 570], [560, 900], [578, 1036], [-12, 1036]], true, false);
    R.flat(zf, '#f0eee8', 0.02, 2);
    clipA(zf, () => {
      // stripe flow fitted per 75-px tile (quadratic phase each), blended
      img(E.fx(`const vec2 ZC[36] = vec2[36](vec2(112., 524.), vec2(188., 524.), vec2(38., 598.), vec2(112., 598.), vec2(188., 598.), vec2(262., 598.), vec2(38., 674.), vec2(112., 674.), vec2(188., 674.), vec2(262., 674.), vec2(38., 748.), vec2(112., 748.), vec2(188., 748.), vec2(262., 748.), vec2(38., 824.), vec2(112., 824.), vec2(188., 824.), vec2(38., 898.), vec2(112., 898.), vec2(188., 898.), vec2(38., 974.), vec2(112., 974.), vec2(188., 974.), vec2(262., 974.), vec2(338., 974.), vec2(412., 974.), vec2(488., 974.), vec2(562., 974.), vec2(38., 1048.), vec2(112., 1048.), vec2(188., 1048.), vec2(262., 1048.), vec2(338., 1048.), vec2(412., 1048.), vec2(488., 1048.), vec2(562., 1048.));
const float ZK[216] = float[216](-0.9827, 1.6251, 2.0660, -0.2249, 1.3065, -0.2811, -1.1522, -1.3085, -2.8043, 0.4159, -0.9078, 0.1043, -0.1858, 2.8212, 1.8156, -3.4580, -0.3392, -1.6735, 2.4049, 2.3353, 1.5093, 0.0838, 0.6574, -0.8670, -0.1449, -2.0791, -2.2046, 0.3626, -1.2495, 0.9211, 4.5477, -1.3304, -3.2295, 0.5576, -1.3900, 0.9266, 0.0048, 1.9080, -1.2875, 0.0587, -0.1391, -0.7347, -2.5080, -1.9933, 1.2826, 0.1369, 0.5645, 1.3417, 0.9432, -1.9727, -0.0397, -1.4870, -0.1390, 1.6452, 6.7819, 1.1780, 0.3435, -1.6753, 0.6649, -1.9618, 2.2626, -1.8246, 1.7778, -0.0349, 0.0961, 0.0225, -2.1499, -1.8292, 1.7432, 0.1120, -0.1855, 0.1099, 0.5391, -2.2133, 1.2754, -1.0832, -0.6737, 0.4330, -5.3443, 3.1830, -0.2393, 1.3364, -1.3924, 1.3916, 7.4101, 1.8129, -1.7171, 0.0160, 0.0051, 0.1105, 0.1839, -2.0073, 1.5718, -0.1003, -0.2809, -0.2718, -2.2973, -1.7625, 1.5752, 0.2949, 0.2829, -0.2199, 3.3119, 1.9361, -1.0010, 0.0159, 0.1153, 0.6048, 0.1434, -1.9333, 1.2145, 0.0920, 0.4960, 0.0074, -4.2018, -1.5119, 1.3617, 0.3547, -0.0011, 0.0807, 1.3758, -1.7541, 1.2710, 0.0459, 0.3772, 0.3670, 2.1190, -1.6760, 1.3819, 0.0701, 0.0721, 0.0031, -0.1399, -1.7104, 1.4204, -0.0348, 0.0587, -0.0255, 1.3322, 1.5533, -1.2257, 0.0982, 0.2508, -0.1260, 1.1344, -2.1307, 1.9638, 0.1551, 0.8244, -0.4639, 1.2385, 1.5073, -2.4371, 0.0117, -0.0671, 0.5781, 6.5629, -1.6943, 2.6096, 0.0053, 0.4757, -0.5179, -4.3799, 1.7618, -3.7634, 0.5771, -4.4652, 0.1510, -0.5922, -1.7064, 1.2737, -0.0285, -0.0719, -0.1306, -1.8218, -1.7150, 1.4746, 0.0191, -0.0742, 0.1088, -2.1714, 1.9159, -2.9403, 0.1086, 0.6099, -2.2363, 0.4260, -1.7365, 0.1628, -0.0797, -0.2111, -1.5074, 2.6538, 1.5124, -1.2675, -0.1551, -0.8244, 0.4644, 5.2679, -1.4586, 1.5889, -0.0105, 0.0631, -0.5562, -8.9968, -1.2307, 0.6563, -0.0864, 0.7220, -1.8611, 0.1355, -0.2090, 6.1705, -0.4663, -1.2310, 7.0513);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 36; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.3403);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){
        float v = zv(p);
        vec3 wh = mix(vec3(.97, .96, .93), vec3(.86, .85, .8), smoothstep(.3, .7, vnoise(p * 0.004 + 2.)) * .5);
        return mix(wh, vec3(.02), smoothstep(-.14, .14, v)); }`));
      const r = rng(5); a.fillStyle = '#0a0a0a';
      for (let i = 0; i < 40; i++) a.fill(circleP(r() * 560, 560 + r() * 470, 1.5 + r() * 4));
    });

    // ── black braided ropes + yellow rope ──
    const braid = (pts, w) => {
      const pth = P(pts, false, true);
      R.pipe(pth, w, '#1a1a1c', 0.12, 0.14, 5);
      a.save(); a.setLineDash([5, 5]); a.lineWidth = w * 0.7; a.strokeStyle = '#4a4a50'; a.stroke(pth); a.restore();
    };
    braid([[216, 212], [194, 256], [186, 318], [198, 378], [228, 418], [258, 432]], 16);
    braid([[566, 276], [588, 328], [608, 396], [616, 462], [606, 520], [590, 566]], 18);
    R.pipe(P([[300, 440], [326, 404], [352, 380], [384, 360]], false, true), 14, '#ecc828', 0.14, 0.12, 3);

    // ── white clay creature (left), right blob, stem ──
    const cfig = P([[128, 172], [176, 150], [232, 138], [292, 150], [312, 190], [300, 218], [250, 216], [210, 226], [186, 252], [175, 300], [172, 362], [182, 402], [226, 410], [262, 394], [292, 400],
      [312, 430], [302, 462], [284, 482], [304, 502], [312, 540], [282, 562], [230, 562], [196, 540], [160, 520], [120, 516], [90, 536], [64, 520], [58, 460], [56, 380], [64, 318], [80, 258], [100, 210]], true, true);
    R.dome(cfig, CLAY, 0.16, 0.3, 30, 1);
    const rblob = P([[548, -12], [746, -12], [746, 476], [704, 474], [672, 444], [652, 402], [640, 350], [604, 318], [582, 280], [568, 226], [560, 170], [554, 100], [544, 40]], true, true);
    R.dome(rblob, CLAY, 0.16, 0.3, 34, 1);
    R.flat(ellipseP(712, 26, 34, 44, 0), '#111112', 0.4, 5);
    const topc = P([[340, -12], [560, -12], [566, 40], [530, 70], [470, 66], [400, 60], [350, 40]], true, true);
    R.dome(topc, '#e2e2e8', 0.14, 0.2, 20, 1);
    const stem = P([[402, 326], [472, 326], [484, 380], [504, 420], [522, 470], [522, 520], [502, 556], [452, 560], [432, 520], [420, 470], [410, 420], [400, 380]], true, true);
    R.dome(stem, CLAY, 0.18, 0.28, 24, 1);
    // bumps and grommets
    for (const [x, y, rr] of [[640, 104, 12], [664, 160, 10], [700, 200, 14], [610, 40, 8], [118, 412, 10], [138, 416, 10], [680, 300, 10], [710, 360, 12]]) R.bead(x, y, rr, CLAY, 0.4, 0.1, 1);
    for (const [x, y, rr] of [[90, 336, 18], [118, 268, 12], [250, 506, 17], [570, 72, 18], [591, 153, 18], [505, 62, 10], [176, 207, 7], [190, 437, 8], [465, 463, 6], [608, 247, 7], [668, 236, 7], [148, 448, 5]]) grommet(x, y, rr);

    // ── gold flower disc with triangular windows ──
    const disc = []; for (let i = 0; i < 120; i++) { const t = i / 120 * 6.283, r = 146 + 8 * Math.cos(t * 7 + 0.5) + 4 * Math.sin(t * 3); disc.push([426 + Math.cos(t) * r * 1.0, 208 + Math.sin(t) * r * 1.06]); }
    const discP = P(disc, true, true);
    R.dome(discP, lin(320, 70, 540, 340, [[0, '#f8e870'], [0.35, '#e8c42c'], [0.7, '#cc9c14'], [1, '#a47608']]), 0.3, 0.1, 10, 3);
    clipA(discP, () => { const r = rng(3); for (let i = 0; i < 260; i++) { const y = 60 + r() * 300; a.strokeStyle = r() < 0.5 ? 'rgba(255,240,170,0.25)' : 'rgba(140,100,10,0.2)'; a.lineWidth = 0.8; a.beginPath(); a.moveTo(280, y); a.lineTo(590, y + (r() - 0.5) * 6); a.stroke(); } });
    const tri = (pts, inner) => {
      const c = [(pts[0][0] + pts[1][0] + pts[2][0]) / 3, (pts[0][1] + pts[1][1] + pts[2][1]) / 3];
      const q = pts.map(p => [c[0] + (p[0] - c[0]) * 0.86, c[1] + (p[1] - c[1]) * 0.86]), rp = [];
      for (let k = 0; k < 3; k++) { const A = q[k], B = q[(k + 1) % 3]; rp.push([A[0] + (B[0] - A[0]) * 0.2, A[1] + (B[1] - A[1]) * 0.2], [A[0] + (B[0] - A[0]) * 0.8, A[1] + (B[1] - A[1]) * 0.8]); }
      const pth = P(rp, true, true);
      R.flat(pth, inner, 0.12, 0);
      R.pipe(pth, 13, '#e6e4ec', 0.4, 0.12, 1);
    };
    tri([[361, 108], [318, 207], [396, 188]], '#0a1634');
    tri([[440, 93], [520, 155], [443, 178]], '#3e3858');
    tri([[407, 328], [330, 266], [405, 244]], '#8a84a2');
    tri([[480, 311], [534, 219], [456, 230]], '#ecebf2');
    // white curl emblem on the gold
    R.pipe(P([[312, 160], [300, 190], [302, 222], [316, 248], [330, 262], [318, 272], [306, 262]], false, true), 8, '#f4f2f0', 0.42, 0.06, 1);
    R.pipe(P([[318, 150], [296, 174], [292, 200]], false, true), 5, '#f4f2f0', 0.42, 0.04, 1);

    // ── dark rock, purple dish, yellow stick ──
    R.flat(P([[350, 640], [420, 620], [480, 660], [470, 750], [380, 760], [340, 720]], true, true), '#363632', 0.1, 2);
    { const d = P([[330, 640], [360, 604], [396, 620], [400, 660], [370, 690], [336, 682]], true, true); R.dome(d, '#9070d8', 0.12, 0.08, 10, 2);
      clipA(d, () => { a.strokeStyle = '#f0ecfa'; a.lineWidth = 2; for (let i = 0; i < 14; i++) { a.beginPath(); a.moveTo(380, 650); a.lineTo(380 + Math.cos(2 + i * 0.25) * 60, 650 + Math.sin(2 + i * 0.25) * 60); a.stroke(); } }); }

    // ── dark green board + tablet ──
    const board = P([[560, 556], [746, 540], [746, 1036], [566, 1036], [558, 900]], true, false);
    R.flat(board, '#123a2e', 0.04, 2);
    clipA(board, () => { const r = rng(12); for (let i = 0; i < 500; i++) { const y = 540 + r() * 500, x = 550 + r() * 200; a.strokeStyle = r() < 0.5 ? 'rgba(60,110,90,0.5)' : 'rgba(5,20,15,0.6)'; a.lineWidth = 0.6 + r() * 1.4; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 10 + r() * 40, y + (r() - 0.5) * 3); a.stroke(); } });
    const tab = P([[428, 662], [572, 513], [746, 640], [746, 700], [598, 838], [460, 750]], true, false);
    R.dome(tab, '#3a3a3e', 0.2, 0.04, 6, 5);
    const scr = P([[472, 708], [604, 584], [746, 690], [746, 708], [600, 830]], true, false);
    R.flat(scr, '#10cc10', 0.24, 0);
    a.save(); a.translate(640, 662); a.rotate(0.72); a.fillStyle = '#0a0a0a'; a.font = 'bold 30px Arial, sans-serif'; a.fillText('EDUCTION', -66, 10);
    a.font = '9px Arial, sans-serif'; for (let i = 0; i < 6; i++) a.fillRect(-60 + (i % 2) * 10, 30 + i * 13, 50 + (i * 17) % 40, 2.5); a.restore();
    a.save(); a.translate(470, 650); a.rotate(-0.8); a.fillStyle = '#e8e8e8'; for (let i = 0; i < 5; i++) for (let j = 0; j < 3; j++) a.fillRect(j * 40, i * 22, 26, 3); a.restore();
    a.save(); a.translate(570, 525); a.rotate(0.6); a.fillStyle = '#ffffff'; a.font = 'bold 10px Arial, sans-serif'; a.fillText('21', 0, 0); a.restore();

    // ── the coiled hose ──
    const curve = [[474, 516], [420, 500], [360, 512], [312, 548], [286, 608], [282, 690], [300, 752], [346, 792], [400, 806]];
    const offs = (pts, d) => pts.map((p, i) => { const q = pts[Math.max(0, i - 1)], s2 = pts[Math.min(pts.length - 1, i + 1)], dx = s2[0] - q[0], dy = s2[1] - q[1], L = Math.hypot(dx, dy) || 1; return [p[0] - dy / L * d, p[1] + dx / L * d]; });
    for (let k = -3; k <= 3; k++) R.pipe(P(offs(curve, k * 15), false, true), 15, '#bab8c0', 0.24, 0.12, 1);
    for (let i = 9; i >= 0; i--) { const x = 386 + i * 21; R.pipe(ellipseP(x, 858, 24, 94, 0.05), 16, '#bcbac2', 0.26, 0.12, 1); }
    // purple woven ribbon
    const rib = P(lock([[226, 846], [300, 816], [380, 800], [440, 780], [482, 762], [524, 742]], 52, 56, 1), true, true);
    R.dome(rib, '#8848cc', 0.4, 0.06, 10, 2);
    clipA(rib, () => { a.strokeStyle = 'rgba(40,10,80,0.55)'; a.lineWidth = 1.4; for (let i = -40; i < 60; i++) { a.beginPath(); a.moveTo(200 + i * 8, 700); a.lineTo(200 + i * 8 + 160, 900); a.stroke(); a.beginPath(); a.moveTo(200 + i * 8, 900); a.lineTo(200 + i * 8 + 160, 700); a.stroke(); } });
    // wheel
    R.dome(circleP(290, 916, 82), '#c2c0c8', 0.3, 0.16, 26, 1);
    for (const rr of [70, 56, 44]) R.groove(circleP(290, 916, rr), 4, '#8a8892', 0.46, 0.04, 1);
    R.dome(circleP(290, 916, 26), '#1a1818', 0.44, 0.06, 6, 5);
    R.pipe(circleP(290, 916, 15), 5, '#c8a868', 0.5, 0.04, 3);
    R.flat(circleP(290, 916, 9), '#ece6da', 0.5, 0);
    // little white hands
    for (const [pts] of [[[[180, 820], [210, 812], [236, 816], [246, 800]]], [[[430, 870], [440, 900], [452, 926], [472, 940]]]]) R.pipe(P(pts, false, true), 12, '#e2e2e8', 0.4, 0.12, 1);
    // yellow stick
    R.pipe(P([[256, 612], [362, 680], [462, 742]], false), 5, '#e8c020', 0.5, 0.04, 3);
    // purple star + pencil
    R.pipe(P([[640, 960], [700, 1018]], false), 12, '#f2eee0', 0.2, 0.08, 1);
    R.pipe(P([[688, 1004], [702, 1018]], false), 13, '#f0b020', 0.24, 0.08, 3);
    R.dome(P(star(632, 958, 48, 22, 5, -1.57), true, false), '#a43cee', 0.2, 0.12, 12, 2);
    R.pipe(P([[590, 924], [600, 932]], false), 8, '#f0c020', 0.3, 0.04, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.45, ao: 0.5, rim: 0.25, coat: 0.06 }),            // 1 white clay
        E.mat({ dif: 1, spec: 0.2, shin: 18, wrap: 0.5, ao: 0.4 }),                                      // 2 matte colour
        E.mat({ dif: 0.8, metal: 0.35, spec: 0.9, shin: 30, ao: 0.4, tint: [1.05, 0.98, 0.8], emis: 0.2 }), // 3 gold
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.3, ao: 0.3 }),                                      // 4 dark matte
        E.mat({ dif: 1, spec: 0.9, shin: 60, coat: 0.15, ao: 0.3 })                                      // 5 gloss dark
      ],
      light: [-0.4, 0.5, 0.75], lc: [0.72, 0.72, 0.73], amb: [0.32, 0.32, 0.34],
      envTop: [1, 1, 1.02], envHor: [0.6, 0.6, 0.66], envBot: [0.2, 0.2, 0.24], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.3, 0.3, 0.38], rimD: [0, 0, 0], r1: 1.6, r2: 9, k: [0, 0.6, 0.4, 110], shadow: [-6, 8, 0.55, 6]
    });
    E.grain(0.03, 95);
  }
});
