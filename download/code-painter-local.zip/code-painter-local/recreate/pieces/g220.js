'use strict';
// g220 — "Twin pods and green cells": a pale-blue clay creature nuzzles a zebra-cased pair of glass pods over a hot-pink
// glow, green cells with white cores below, a starry black sky, plus two inset panels (zebra chevrons with eyes, a pale pipe).
REC.register('g220', {
  w: 1024, h: 726,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = (cv, al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const CLAY = 1, GLASS = 2, FLAT = 3, GLOSS = 4;
    const LINE = '#e8f0c4';

    // ── textures ──
    const ZI = E.fx(`
      // <zi>
const float ZIC[120] = float[120](-2.966,-2.542,-2.969,-4.742,-7.029,-8.348,-7.051,-3.177,1.616,5.940,9.725,13.218,-2.422,-2.239,-2.741,-2.499,-3.101,-4.720,-5.280,-0.145,4.183,7.303,9.376,10.763,-1.604,-2.908,-4.468,-1.503,0.188,0.296,-2.029,2.542,5.306,8.101,8.528,7.927,0.351,-2.492,-2.529,-5.336,-0.281,-2.760,0.831,0.390,3.068,7.406,6.064,4.561,-3.819,-1.668,-2.789,-2.566,-1.406,0.140,-1.004,1.767,1.900,0.517,1.022,1.292,-1.282,2.183,-4.873,-1.580,-1.393,0.486,0.584,0.678,3.129,-2.505,-2.265,-1.180,-0.266,-3.076,-2.832,-1.605,-0.364,0.255,1.634,1.402,1.784,-0.690,-1.857,-1.886,-4.550,-3.822,-1.945,-0.934,-0.241,0.867,1.585,2.093,1.791,0.975,0.043,-0.595,-4.187,-1.434,-1.609,-0.859,0.206,0.867,2.130,2.544,2.587,2.554,2.305,1.961,-9.506,-6.801,-1.011,0.471,-0.001,1.499,2.142,2.846,3.532,4.166,4.643,4.970);
float zi(vec2 p){ vec2 u = clamp((p - vec2(724.0, 168.0)) / vec2(33.3333, 33.7143), vec2(0.), vec2(8.999, 6.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZIC[(i.y + b) * 12 + i.x + a] * bx[a] * by[b];
  return f; }
      // </zi>
      vec3 fx(vec2 uv, vec2 p){
        float s = cos(6.2832 * zi(p));
        return mix(vec3(0.03, 0.03, 0.04), vec3(0.96, 0.96, 0.97), smoothstep(-0.12, 0.12, s)); }`);
    const POD = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec2 q = p - vec2(505., 318.);
        float d = length(q * vec2(0.55, 1.0));
        float s = sin(d * 0.2 + atan(q.y, q.x) * 0.0);
        return mix(vec3(0.1, 0.13, 0.17), vec3(0.88, 0.9, 0.92), smoothstep(0.35, 0.75, s)); }`);
    const FIB = E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        float w = fbm(p * 0.01) * 6.0;
        float f = sin((p.x * 0.3 + p.y * 0.95) * 1.4 + w * 3.0) * 0.5 + 0.5;
        return vec3(0.75 + 0.25 * f); }`);

    // ── 1. main scene: black sky, cyan panel, wave, olive ──
    R.flat(rrect(-10, -10, 1044, 746, 0), '#030304', 0, 0);
    R.flat(Q([-10, -10, 252, -10, 252, 210, 120, 300, -10, 380], true, false), rg(40, 50, 10, 60, 90, 330, [[0, '#f2a86b'], [0.22, '#f2a86b'], [0.3, '#38bdf6'], [0.55, '#4ab4f0'], [0.75, '#8cc0fc'], [1, '#9cc4fc']]), 0.01, 0);
    soft(x => { fe(x, 40, 50, 46, 66, 0.25, '#f2a86b'); }, 3, 1);
    const wave = Q([470, -10, 1034, -10, 1034, 172, 990, 168, 950, 158, 900, 140, 860, 120, 820, 104, 780, 92, 740, 80, 700, 60, 640, 46, 580, 32, 530, 18, 480, 8], true, false);
    R.flat(wave, lg(500, 0, 1024, 150, [[0, '#2f88c0'], [0.5, '#3f9fd0'], [1, '#3a86b8']]), 0.02, 0);
    R.flat(Q([915, -10, 1034, -10, 1034, 96, 990, 90, 955, 64, 930, 30], true, false), lg(920, 0, 1024, 90, [[0, '#7a7ea0'], [1, '#2a2440']]), 0.03, 0);
    R.pipe(Q([915, -10, 930, 30, 955, 64, 990, 90, 1034, 96], true, false), 5, LINE, 0.05, 0.03, FLAT);
    const olive = Q([500, 272, 560, 246, 620, 216, 680, 186, 722, 164, 760, 110, 800, 96, 850, 116, 900, 142, 960, 162, 1034, 170, 1034, 200, 722, 200, 722, 282], true, false);
    R.flat(olive, '#2e4821', 0.02, 0);
    R.pipe(Q([470, 6, 530, 18, 580, 32, 640, 46, 700, 60, 750, 84, 800, 96, 850, 116, 900, 140, 950, 158, 1000, 166, 1034, 168], true, false), 7, LINE, 0.06, 0.03, FLAT);
    R.pipe(Q([500, 270, 560, 246, 620, 216, 680, 186, 722, 166], true, false), 6, LINE, 0.06, 0.03, FLAT);
    R.pipe(Q([660, 46, 664, 58, 672, 64], true, false), 6, LINE, 0.06, 0.03, FLAT);
    // stars: green / red glows
    for (const [x, y, rx, ry, c] of [[365, 113, 15, 12, '#45fa5a'], [492, 165, 14, 11, '#45fa5a'], [690, 135, 19, 17, '#ec1a08']]) {
      soft(xx => fe(xx, x, y, rx * 1.4, ry * 1.4, 0, c), 6, 0.8);
      R.flat(ellipseP(x, y, rx, ry, 0), c, 0.02, 0); R.flat(ellipseP(x - 2, y - 1, rx * 0.35, ry * 0.3, 0), '#e8fff0', 0.02, 0);
    }
    // purple, pink glow, maroon band
    R.flat(Q([-10, 352, 30, 352, 60, 380, 110, 398, 160, 410, 205, 422, 210, 452, -10, 455], true, false), '#7837fc', 0.02, 0);
    const pink = Q([280, 380, 330, 350, 400, 352, 500, 362, 600, 356, 680, 350, 722, 340, 722, 412, 680, 424, 600, 445, 500, 462, 400, 470, 300, 478, 250, 470, 240, 440, 255, 405], true, false);
    R.flat(pink, '#fc0385', 0.02, 0);
    soft(x => { fe(x, 335, 445, 50, 30, 0, '#ff5020'); fe(x, 335, 445, 28, 20, 0, '#fbfc0b'); fe(x, 640, 380, 80, 30, 0, '#ff6070'); }, 10, 1, 'source-over', pink);
    const maroon = Q([-10, 440, 100, 466, 200, 478, 300, 479, 400, 471, 500, 463, 600, 446, 680, 426, 722, 412, 722, 445, 600, 490, 500, 512, 400, 520, 300, 528, 200, 532, 100, 525, -10, 515], true, false);
    R.flat(maroon, lg(0, 450, 0, 530, [[0, '#80275a'], [0.7, '#6a1e4a'], [1, '#2a0a1e']]), 0.02, 0);
    R.pipe(Q([-10, 438, 100, 464, 200, 476, 260, 479, 300, 477, 400, 469, 500, 461, 600, 444, 680, 424, 722, 410], true, false), 6, LINE, 0.06, 0.03, FLAT);
    R.pipe(Q([-10, 446, 100, 472, 200, 484, 300, 485, 400, 477, 500, 469, 600, 452, 680, 432, 722, 418], true, false), 3, '#1a2a40', 0.05, 0.01, 0);

    // ── 2. green cells with white cores ──
    const cells = [[705, 455, 29, 40, 52], [78, 537, 32, 50, 77], [458, 502, 26, 50, 78], [583, 503, 31, 51, 72], [192, 558, 31, 50, 81], [311, 564, 32, 49, 74], [436, 580, 28, 56, 70], [548, 596, 32, 54, 70],
      [677, 545, 39, 47, 66], [47, 622, 34, 53, 66], [189, 632, 31, 54, 78], [330, 657, 34, 54, 68], [631, 641, 33, 53, 73], [88, 698, 29, 50, 78], [213, 703, 32, 48, 73], [342, 728, 34, 52, 80], [451, 672, 35, 54, 64],
      [560, 726, 32, 52, 75], [-18, 530, 32, 50, 80], [-14, 690, 32, 50, 80], [722, 615, 30, 50, 70]];
    for (const [x, y, w, h, ang] of cells) {
      const rot = (ang - 90) * Math.PI / 180;
      R.flat(ellipseP(x + 2, y + 3, h + 2, w + 2, rot), '#305878', 0.04, 0);
      R.dome(ellipseP(x, y, h, w, rot), '#18f40e', 0.06, 0.06, 8, FLAT);
      R.dome(P(blob(x, y, h * 0.6, w * 0.6, Math.round(x + y), 9, 0.22, rot)), '#fcfcfc', 0.1, 0.06, 10, FLAT);
    }
    R.pipe(Q([140, 700, 200, 672, 250, 640, 300, 612, 350, 586, 400, 566, 450, 546, 488, 527], true, false), 7, LINE, 0.12, 0.04, FLAT);
    R.dome(Q([536, 488, 548, 476, 566, 484, 560, 498, 540, 500]), '#c8e0f0', 0.12, 0.05, 6, CLAY);

    // ── 3. zebra-cased glass pods ──
    const casing = Q([290, 300, 312, 262, 360, 242, 420, 236, 480, 250, 505, 266, 530, 250, 590, 236, 660, 238, 722, 250, 722, 378, 680, 372, 600, 368, 510, 362, 420, 368, 340, 364, 300, 340]);
    R.dome(casing, '#ffffff', 0.08, 0.12, 30, GLOSS);
    clipA(casing, () => img(POD));
    for (const [cx, cy, rx, ry, hl] of [[415, 318, 86, 46, '#ff9a60'], [605, 318, 98, 46, '#60d8ff']]) {
      R.dome(ellipseP(cx, cy, rx + 6, ry + 6, 0), '#c8a090', 0.18, 0.04, 6, GLASS);
      R.dome(ellipseP(cx, cy, rx, ry, 0), rg(cx, cy - 10, 5, cx, cy, rx, [[0, '#62748a'], [0.6, '#3e4c5e'], [1, '#7a8a9c']]), 0.2, 0.2, 30, GLASS);
      soft(x => fe(x, cx - (hl === '#ff9a60' ? 40 : 0), cy, 34, 9, 0, hl), 5, 0.9);
      clipA(ellipseP(cx, cy, rx, ry, 0), () => { const r = rng(cx); for (let i = 0; i < 120; i++) R.paint(circleP(cx - rx + r() * rx * 2, cy - 15 + r() * 30, 0.6), '#e8f4ff'); });
    }
    R.dome(circleP(498, 316, 9), '#f0e040', 0.3, 0.05, 5, GLOSS); R.dome(circleP(512, 316, 9), '#f0e040', 0.3, 0.05, 5, GLOSS);
    R.flat(circleP(498, 316, 3), '#200808', 0.32, 0); R.flat(circleP(512, 316, 3), '#200808', 0.32, 0);

    // ── 4. pale-blue clay creature ──
    const crt = Q([120, -10, 252, -10, 248, 40, 240, 120, 246, 182, 262, 206, 300, 218, 340, 228, 380, 238, 420, 250, 440, 262, 400, 280, 360, 300, 330, 330, 310, 370, 280, 392, 240, 402, 200, 420, 170, 440, 130, 450, 90, 445, 50, 430, 25, 400, 20, 340, 25, 280, 40, 230, 70, 200, 100, 180, 120, 140, 118, 60]);
    R.dome(crt, lg(100, 0, 200, 450, [[0, '#a0c0d8'], [0.45, '#7c9eb4'], [1, '#5e8094']]), 0.1, 0.3, 60, CLAY);
    clipA(crt, () => { const r = rng(220); for (let i = 0; i < 70; i++) R.paint(ellipseP(30 + r() * 260, 30 + r() * 400, 1.6, 2.4, r()), '#c8f4ff'); });
    R.dome(Q([160, -10, 240, -10, 250, 30, 245, 70, 220, 82, 190, 70, 165, 40]), '#b0d0e8', 0.2, 0.15, 30, CLAY);
    R.dome(ellipseP(230, 135, 18, 42, 0), '#a8c8e0', 0.2, 0.12, 16, CLAY);
    // hairy tufts, eye, leaf
    for (const [x, y, rx, ry] of [[62, 208, 18, 26], [320, 245, 32, 16]]) clipA(ellipseP(x, y, rx, ry, -0.4), () => { const r = rng(x); for (let i = 0; i < 40; i++) R.pipe(Q([x - rx + r() * rx * 2, y - ry + r() * ry * 2, x - rx + r() * rx * 2, y - ry + r() * ry * 2], true, false), 2.5, r() < 0.5 ? '#6a7890' : '#a8b4c4', 0.42, 0.03, CLAY); });
    R.dome(circleP(148, 344, 16), '#141820', 0.42, 0.04, 6, GLOSS); R.dome(circleP(148, 344, 9), '#8ef0ff', 0.45, 0.04, 5, GLOSS);
    R.flat(Q([178, 372, 200, 350, 222, 336, 214, 360, 200, 382, 186, 386], true, true), '#6a9a4a', 0.42, 0);
    soft(x => fe(x, 272, 305, 14, 14, 0, '#f0a070'), 3, 0.9);
    // the bone leg
    const leg = Q([190, 410, 215, 380, 250, 372, 290, 380, 305, 405, 290, 425, 255, 432, 245, 470, 240, 500, 225, 512, 205, 505, 200, 470, 182, 440]);
    R.dome(leg, lg(180, 370, 300, 510, [[0, '#c0dcf0'], [1, '#8ab0c8']]), 0.2, 0.25, 30, CLAY);
    // the mushroom stem top right
    R.dome(Q([770, 175, 782, 130, 776, 100, 752, 78, 756, 40, 780, 18, 810, 15, 832, 32, 836, 60, 822, 82, 822, 112, 834, 150, 850, 175]), lg(750, 20, 850, 170, [[0, '#d0e4f4'], [1, '#90b4d0']]), 0.12, 0.25, 30, CLAY);

    // ── 5. upper inset: zebra chevrons with eyes ──
    const ins1 = Q([722, 166, 1034, 166, 1034, 405, 722, 405], false, true);
    R.flat(ins1, '#ffffff', 0.04, FLAT); clipA(ins1, () => img(ZI));
    R.flat(Q([890, 166, 1034, 166, 1034, 285, 1000, 272, 970, 245, 945, 210, 915, 185], true, true), lg(900, 170, 1024, 280, [[0, '#4a7090'], [1, '#3e6686']]), 0.05, 0);
    R.pipe(Q([722, 230, 780, 220, 830, 228, 900, 214, 960, 205, 1034, 196], true, false), 4, LINE, 0.08, 0.02, FLAT);
    R.pipe(Q([740, 330, 800, 300, 860, 288, 920, 278, 980, 270, 1034, 268], true, false), 4, LINE, 0.08, 0.02, FLAT);
    for (const [x, y, rx, ry, core] of [[820, 225, 40, 38, 1], [775, 318, 24, 20, 1], [957, 228, 22, 20, 2], [915, 345, 46, 42, 2], [1002, 335, 42, 44, 2]]) {
      R.dome(ellipseP(x + 2, y + 3, rx + 3, ry + 3, 0), '#e8a080', 0.08, 0.03, 4, CLAY);
      R.dome(ellipseP(x, y, rx, ry, 0), rg(x - rx * 0.3, y - ry * 0.3, 2, x, y, rx, [[0, '#7aa8c8'], [1, '#3a5a74']]), 0.1, 0.18, rx * 0.7, GLASS);
      if (core === 1) { R.dome(circleP(x + rx * 0.25, y + 5, rx * 0.3), '#8ad0e8', 0.3, 0.03, 4, GLOSS); R.flat(circleP(x + rx * 0.25, y + 5, rx * 0.13), '#102030', 0.32, 0); }
      else R.dome(P(blob(x, y + 3, rx * 0.55, ry * 0.5, x, 8, 0.2)), '#fafafa', 0.3, 0.05, 8, GLOSS);
    }
    R.dome(circleP(765, 186, 30), rg(765, 186, 4, 765, 186, 30, [[0, '#f8f020'], [0.45, '#f8e020'], [0.6, '#f04018'], [1, '#e83010']]), 0.1, 0.08, 10, GLOSS);
    R.flat(circleP(765, 186, 3), '#a0a0a0', 0.2, 0);

    // ── 6. lower inset: slate, orange fibre swoosh, pale pipe ──
    const ins2 = Q([722, 405, 1034, 405, 1034, 736, 722, 736], false, true);
    R.flat(ins2, '#466f90', 0.02, 0);
    clipA(ins2, () => {
      a.globalCompositeOperation = 'multiply'; img(FIB, 1); a.globalCompositeOperation = 'source-over';
      R.paint(Q([800, 430, 900, 418, 1034, 410, 1034, 560, 980, 560, 940, 540, 900, 500, 860, 520, 820, 560, 790, 540], true, true), '#1a0c0e');
      R.paint(Q([722, 520, 780, 540, 830, 570, 880, 560, 930, 540, 1000, 520, 1034, 518, 1034, 560, 990, 570, 950, 590, 900, 610, 840, 610, 790, 590, 740, 580, 722, 575], true, true), '#c57761');
      R.paint(Q([722, 640, 800, 600, 880, 615, 960, 600, 1034, 590, 1034, 736, 722, 736], true, true), '#9a4a2c');
      soft(x => { fe(x, 960, 700, 120, 50, 0, '#7a3418'); }, 20, 0.8);
    });
    R.pipe(Q([742, 736, 760, 690, 800, 650, 850, 630, 910, 620, 950, 600, 940, 560, 920, 500, 895, 450, 880, 432, 810, 434], true, false), 44, '#a8cce4', 0.1, 0.22, CLAY);
    R.dome(rrect(800, 418, 30, 48, 8), '#c0e0f0', 0.3, 0.06, 8, CLAY);
    for (const [x, y, r] of [[768, 462, 8], [757, 444, 4], [783, 467, 4]]) R.dome(circleP(x, y, r), '#f0e8f0', 0.12, 0.04, r, GLOSS);
    // inset frames
    R.pipe(Q([722, 166, 722, 736], false, false), 3, '#e8eef4', 0.3, 0.02, FLAT);
    R.pipe(Q([722, 405, 1034, 405], false, false), 3, '#e8eef4', 0.3, 0.02, FLAT);
    R.pipe(Q([722, 166, 1034, 166], false, false), 2, '#c8d0d8', 0.3, 0.02, FLAT);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.6, shin: 30, wrap: 0.7, ao: 0.3, emis: 0.15, rim: 0.4 }),               // 1 soft clay
        E.mat({ dif: 0.8, spec: 1.6, shin: 90, wrap: 0.4, coat: 0.35, emis: 0.1 }),                       // 2 glass
        E.mat({ dif: 0.3, spec: 0.3, shin: 30, wrap: 0.6, emis: 0.8 }),                                   // 3 flat print
        E.mat({ dif: 0.6, spec: 0.9, shin: 50, wrap: 0.5, emis: 0.4 })                                    // 4 glossy flat colours
      ],
      light: [-0.4, 0.6, 0.68], lc: [0.75, 0.76, 0.8], amb: [0.4, 0.42, 0.46],
      envTop: [1.1, 1.12, 1.15], envHor: [0.6, 0.66, 0.72], envBot: [0.1, 0.12, 0.16], envK: [0.3, 1.0, 0, 0],
      rimC: [0.5, 0.7, 0.9], rimD: [0, 1, 0], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-4, 6, 0.5, 6]
    });
  }
});
