'use strict';
// s55 — "Night jungle otters": two glossy, ridged brown creatures (a maned otter and a small
// horned one with an orange eye) in a black night jungle of knobby pink-violet trunks,
// teal fern fans and glowing cyan-blue grass blades.
REC.register('s55', {
  w: 1024, h: 580,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      const src = E.blur(c, blur);
      if (clip) { const m = src.getContext('2d'); m.setTransform(S, 0, 0, S, 0, 0); m.globalCompositeOperation = 'destination-in'; m.fillStyle = '#fff'; m.fill(clip); }
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(src, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); for (const [t, c] of st) g.addColorStop(t, c); return g; };
    const ell = (x, cx, cy, rx, ry, c, rot = 0) => { x.fillStyle = c; x.beginPath(); x.ellipse(cx, cy, rx, ry, rot, 0, 6.283); x.fill(); };
    const r = rng(55);

    // ── black night + navy haze ──────────────────────────────
    R.flat(rrect(-10, -10, 1044, 600, 0), '#020308', 0, 0);
    soft(x => {
      ell(x, 170, 110, 110, 70, '#0e2448', 0.2); ell(x, 60, 250, 90, 90, '#0a2a44'); ell(x, 900, 120, 120, 60, '#081830'); ell(x, 990, 300, 60, 120, '#0a3a70');
      ell(x, 520, 200, 70, 60, '#10205a'); ell(x, 700, 360, 120, 60, '#0a1a40');
    }, 24, 1);

    // ── fern fans (teal-grey fronds) ─────────────────────────
    const frond = (x0, y0, ang, len, curl, w, col) => {
      const pts = [];
      for (let i = 0; i <= 12; i++) { const t = i / 12, aa = ang + curl * t; pts.push([x0 + Math.cos(ang + curl * t * 0.5) * len * t, y0 + Math.sin(ang + curl * t * 0.5) * len * t]); }
      a.save(); a.strokeStyle = col; a.fillStyle = col; a.lineCap = 'round';
      for (let i = 1; i < 12; i++) {
        const [px, py] = pts[i], [qx, qy] = pts[i + 1], d = Math.atan2(qy - py, qx - px), L = w * Math.sin(Math.PI * (i / 12) * 0.9 + 0.2);
        a.lineWidth = 2.5 + w * 0.12;
        for (const sgn of [-1, 1]) { const b = d + sgn * 1.0; a.beginPath(); a.moveTo(px, py); a.quadraticCurveTo(px + Math.cos(b) * L * 0.6, py + Math.sin(b) * L * 0.6, px + Math.cos(b + sgn * 0.3) * L, py + Math.sin(b + sgn * 0.3) * L + L * 0.25); a.stroke(); }
      }
      a.lineWidth = 2.2; a.stroke(P(pts, false, true)); a.restore();
    };
    const fan = (cx, cy, n, a0, a1, len, w, col) => { for (let i = 0; i < n; i++) { const t = n > 1 ? i / (n - 1) : 0.5; frond(cx, cy, a0 + (a1 - a0) * t + (r() - 0.5) * 0.15, len * (0.75 + r() * 0.35), (r() - 0.5) * 0.8, w, col); } };
    fan(40, 200, 9, -2.6, -0.3, 150, 22, '#6a8490'); fan(190, 290, 11, -2.9, 0.1, 110, 16, '#2a4a52'); fan(90, 350, 9, -3.0, -0.1, 120, 18, '#3a5c68');
    fan(40, 460, 8, -2.6, 0.0, 130, 20, '#3a5868'); fan(170, 400, 7, -2.8, -0.2, 90, 14, '#1a3a44');
    fan(820, 200, 12, -2.9, -0.2, 120, 16, '#3a5a68'); fan(930, 270, 12, -3.1, 0.0, 120, 16, '#1a4058'); fan(990, 190, 9, -2.8, -0.4, 100, 14, '#4a6a80');
    fan(960, 360, 10, -3.0, -0.2, 110, 16, '#1a4a70'); fan(700, 250, 8, -2.6, -0.6, 80, 12, '#183a50'); fan(40, 40, 8, -2.4, -0.4, 90, 14, '#7a9098');
    soft(x => { ell(x, 180, 330, 80, 50, '#10304a'); ell(x, 60, 420, 60, 40, '#0c2438'); }, 18, 0.5, 'screen');

    // ── knobby pink / violet trunks ──────────────────────────
    const trunk = (pts, w, c0, c1, n) => {
      const p = P(pts, false, true);
      R.pipe(p, w, lin(pts[0][0] - w, 0, pts[0][0] + w, 0, [[0, c0], [0.5, mixHex(c0, c1, 0.5)], [1, c1]]), 0.05, 0.25, 2);
      for (let i = 0; i < n; i++) {
        const t = r(), k = Math.min(pts.length - 2, Math.floor(t * (pts.length - 1))), u = t * (pts.length - 1) - k;
        const x = pts[k][0] + (pts[k + 1][0] - pts[k][0]) * u + (r() - 0.5) * w * 0.8, y = pts[k][1] + (pts[k + 1][1] - pts[k][1]) * u;
        const side = (x - pts[k][0]) / (w * 0.5);
        R.bead(x, y, 4 + r() * w * 0.1, side < 0 ? mixHex(c0, '#e070a0', r() * 0.4) : mixHex(c1, '#4a50ff', r() * 0.5), 0.2, 0.1, 2);
      }
    };
    trunk([[300, -20], [300, 100], [292, 220], [280, 330], [262, 420]], 110, '#983868', '#3038c8', 150);
    trunk([[360, -20], [370, 120], [360, 260], [340, 380]], 60, '#7a3a7a', '#3036c0', 120);
    trunk([[180, -20], [210, 60], [240, 130], [262, 190]], 30, '#c880a0', '#7070d0', 60);
    trunk([[610, -20], [612, 100], [620, 200], [628, 300]], 44, '#7050a8', '#2830c8', 110);
    trunk([[660, -20], [652, 80], [640, 180]], 30, '#b080c0', '#4a58e0', 50);
    trunk([[790, -20], [800, 60], [820, 130], [830, 200]], 22, '#d0b0d0', '#8080e0', 50);
    trunk([[860, -20], [850, 60], [830, 130]], 18, '#e0c0e0', '#8a90e8', 30);
    trunk([[920, -20], [912, 80], [900, 160], [890, 240]], 24, '#c0a0d8', '#6a70e8', 50);
    trunk([[770, 100], [730, 160], [700, 220], [680, 260]], 18, '#c090c0', '#5a60e0', 30);
    soft(x => { x.strokeStyle = '#5a40ff'; x.lineWidth = 30; x.stroke(P([[350, 0], [360, 200], [330, 380]], false)); }, 20, 0.35, 'screen');

    // ── creatures: ridged glossy brown ───────────────────────
    const ridges = (c0, c1, freq) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float f = p.x + 0.6 * p.y + fbm(p * 0.008) * 60. + fbm(p * 0.03 + 3.) * 10.;
      float s = 0.5 + 0.5 * sin(f * 0.5 * ${freq.toFixed(2)});
      float g = smoothstep(0.1, 0.9, s);
      return mix(vec3(${c0}), vec3(${c1}), g); }`));
    const otter = P([[118, 592], [140, 530], [185, 478], [245, 438], [300, 398], [360, 330], [400, 252], [438, 196], [480, 176], [520, 180], [560, 196], [600, 214], [628, 246], [646, 266], [632, 284],
      [610, 302], [590, 320], [578, 352], [580, 410], [600, 466], [640, 488], [700, 478], [780, 466], [850, 460], [870, 480], [840, 500], [760, 506], [680, 514], [600, 522], [572, 592]], true, true);
    R.dome(otter, ridges('.3,.16,.12', '.66,.42,.32', 1.0), 0.1, 0.4, 70, 1);
    // flowing mane ridges (tubes) clipped to the body
    a.save(); a.clip(otter); R.h.save(); R.h.clip(otter);
    for (let i = 0; i < 46; i++) {
      const t = i / 45, sx = 430 + t * 170 - (r() * 30), sy = 190 + t * 190 + r() * 30;
      const len = 140 + r() * 240, pts = [];
      for (let k = 0; k <= 8; k++) { const u = k / 8; pts.push([sx - len * u * (0.55 + 0.1 * Math.sin(i)) + Math.sin(u * 4 + i) * 10, sy + len * u * 0.8 + Math.cos(u * 3 + i * 0.7) * 6]); }
      R.pipe(P(pts, false, true), 14 + r() * 10, mixHex('#7a4430', '#c0806a', r()), 0.3, 0.16, 1);
    }
    a.restore(); R.h.restore();
    // face: smoother muzzle and cheek
    R.dome(P([[520, 196], [580, 210], [620, 236], [646, 266], [630, 286], [596, 304], [556, 300], [528, 270], [512, 230]], true, true), lin(520, 200, 640, 300, [[0, '#8a5a4a'], [1, '#a87462']]), 0.3, 0.12, 30, 1);
    R.dome(ellipseP(466, 218, 26, 22, -0.3), '#a07060', 0.3, 0.1, 12, 1); R.dome(ellipseP(466, 220, 15, 12, -0.3), '#5a3028', 0.36, -0.04, 8, 1);
    R.bead(630, 266, 12, '#3a1a14', 0.42, 0.08, 1);
    R.bead(557, 236, 10, '#f0b060', 0.42, 0.05, 1); R.bead(558, 236, 5, '#1a0a06', 0.46, 0.03, 1);
    for (let i = 0; i < 26; i++) { const x = 380 + r() * 200, y = 340 + r() * 190; R.bead(x, y, 2 + r() * 3.5, '#ffd8a0', 0.5, 0.05, 3); }
    // small horned creature
    const body2 = P([[610, 444], [614, 380], [640, 332], [680, 316], [720, 346], [760, 362], [790, 382], [820, 420], [852, 450], [846, 472], [790, 466], [740, 458], [700, 472], [640, 472]], true, true);
    R.dome(body2, ridges('.26,.2,.18', '.5,.42,.38', 0.5), 0.08, 0.35, 40, 1);
    for (const [x0, y0, x1, y1] of [[746, 262, 750, 228], [792, 266, 798, 234]]) R.dome(P([[x0 - 8, y0], [x1, y1], [x0 + 8, y0]], true, true), '#8a7a74', 0.3, 0.1, 5, 1);
    const head2 = P([[674, 300], [682, 270], [720, 250], [764, 252], [800, 270], [824, 300], [838, 326], [832, 346], [800, 356], [760, 356], [720, 350], [690, 332]], true, true);
    R.dome(head2, lin(680, 250, 830, 350, [[0, '#7a6660'], [1, '#56463f']]), 0.2, 0.3, 36, 1);
    R.dome(ellipseP(696, 284, 22, 18, -0.2), '#8a7a74', 0.4, 0.1, 10, 1); R.dome(ellipseP(697, 286, 12, 10, -0.2), '#4a3430', 0.45, -0.03, 6, 1);
    R.bead(752, 306, 14, '#f08030', 0.45, 0.08, 1); R.bead(753, 306, 6, '#140806', 0.5, 0.03, 1);
    R.bead(826, 330, 8, '#2a1a18', 0.45, 0.06, 1);
    soft(x => { ell(x, 752, 306, 20, 18, '#ff9040'); ell(x, 557, 236, 14, 12, '#ffb060'); }, 6, 0.6, 'screen');

    // red flowers
    soft(x => { ell(x, 960, 356, 34, 16, '#e02040'); ell(x, 175, 430, 16, 10, '#e04030'); }, 4, 0.9);

    // ── glowing grass blades (front) ─────────────────────────
    const blade = (x0, y0, h, lean, w, col) => {
      const x1 = x0 + lean, y1 = y0 - h, mx = x0 + lean * 0.35, my = y0 - h * 0.6;
      const p = new Path2D(); p.moveTo(x0 - w, y0); p.quadraticCurveTo(mx - w * 0.5, my, x1, y1); p.quadraticCurveTo(mx + w * 0.5, my, x0 + w, y0); p.closePath();
      R.dome(p, col, 0.3 + r() * 0.2, 0.12, w * 0.6, 4);
    };
    const cols = ['#105a98', '#1a80c8', '#30a0e0', '#60b8e0', '#90cce0', '#0a4488', '#08b8f0'];
    for (let i = 0; i < 420; i++) {
      const x = r() * 1060 - 20, base = 590, side = x < 140 || x > 830, h = side ? 80 + r() * 170 : 30 + r() * 90;
      if (x > 440 && x < 650 && r() < 0.5) continue;
      blade(x, base, h, (r() - 0.5) * 160, 3 + r() * 5, cols[Math.floor(r() * cols.length)]);
    }
    for (let i = 0; i < 60; i++) { const x = 600 + r() * 420; blade(x, 480 + r() * 40, 40 + r() * 60, (r() - 0.5) * 100, 2.5 + r() * 3, cols[Math.floor(r() * cols.length)]); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 40, wrap: 0.3, rim: 0.3, coat: 0.06, ao: 0.5, tint: [1, 0.8, 0.7] }),  // 1 glossy creature skin
        E.mat({ dif: 1, spec: 0.4, shin: 24, wrap: 0.3, rim: 0.5, ao: 0.4 }),                  // 2 knobby trunks
        E.mat({ dif: 0.4, emis: 1.2, spec: 0.3 }),                                              // 3 glowing dots
        E.mat({ dif: 1, spec: 0.6, shin: 30, wrap: 0.3, rim: 0.9 })                             // 4 grass
      ],
      light: [-0.3, 0.5, 0.8], lc: [0.75, 0.62, 0.52], amb: [0.26, 0.26, 0.36],
      envTop: [0.6, 0.6, 0.8], envHor: [0.2, 0.2, 0.35], envBot: [0.05, 0.05, 0.1], envK: [0.1, 0.8, 0.3, 0],
      rimC: [0.2, 0.45, 0.8], rimD: [0.3, 0.5, 0.3], l2: [0.7, 0.2, 0.5, 4], l2c: [0.1, 0.18, 0.4],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.5, 6]
    });
    E.bloom(0.18, 8, 'brightness(0.7) contrast(2.2)');
    E.grain(0.03, 55);
  }
});
