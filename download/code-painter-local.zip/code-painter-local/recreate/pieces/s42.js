'use strict';
// s42 — "Pearl tide": black starfield with pale-blue bubbles; a speckled pearl-cream
// flow with wavy tube fingers, glossy grey drops, pink coral arms with grey shadows,
// a lavender spiky urchin, a pink coiled yarn mass, a little blue lizard, a silver star.
REC.register('s42', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const speckle = (path, n, seed, col, al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al * (0.4 + r() * 0.6); a.beginPath(); a.arc(r() * 726, r() * 1024, 0.4 + r() * 0.7, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    // ragged ribbon (coral arm): centreline, root width, tip width
    const coral = (cl, w0, w1, seed, amp = 5) => {
      const pts = lock(cl, w0, w1, 1), n = pts.length, r = rng(seed), out = [];
      for (let i = 0; i < n; i++) {
        const p = pts[i], q = pts[(i + 1) % n], L = Math.hypot(q[0] - p[0], q[1] - p[1]), k = Math.max(1, Math.round(L / 7));
        for (let j = 0; j < k; j++) { const u = j / k, nx = (q[1] - p[1]) / (L || 1), ny = -(q[0] - p[0]) / (L || 1), d = (j % 2 ? 1 : -0.3) * amp * r(); out.push([p[0] + (q[0] - p[0]) * u + nx * d, p[1] + (q[1] - p[1]) * u + ny * d]); }
      }
      return P(out, true, true);
    };
    const PINK = '#ff9e9a', SHAD = '#6c6c70';

    // ── black ground + bubbles ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#0b0b0d', 0, 0);
    const br = rng(42);
    for (let i = 0; i < 260; i++) {
      const x = br() * 726, y = br() * 1024, r = 2 + Math.pow(br(), 2.2) * 12;
      R.dome(circleP(x, y, r), '#b4c0f6', 0.06, Math.min(0.2, r * 0.02), r * 0.8, 5);
    }
    for (const [x, y, r] of [[678, 61, 14], [690, 38, 9], [612, 30, 6], [542, 97, 10], [700, 180, 10], [648, 600, 12], [655, 830, 10], [676, 940, 14], [658, 993, 9], [700, 880, 12],
      [600, 1010, 10], [256, 640, 16], [86, 608, 12], [60, 915, 8], [36, 750, 8], [243, 422, 10], [190, 205, 8], [230, 850, 10], [320, 868, 6], [690, 790, 9], [18, 360, 8], [56, 430, 7]])
      R.dome(circleP(x, y, r), '#b8c4f8', 0.08, 0.18, r * 0.8, 5);

    // ── top-left grey panel, lavender blob, porthole ──
    R.flat(P([[-10, -10], [214, -10], [214, 60], [189, 79], [189, 100], [146, 100], [146, 200], [152, 230], [152, 310], [-10, 310]], true, false), '#b4b4b8', 0.04, 4);
    speckle(rrect(0, 0, 214, 310, 0), 3000, 3, '#6a6a70', 0.5);
    R.flat(P([[-10, 120], [40, 100], [80, 97], [115, 105], [138, 130], [148, 170], [146, 205], [160, 232], [158, 272], [140, 292], [100, 302], [40, 304], [-10, 304]], true, true), '#a6b4f0', 0.06, 4);
    R.dome(circleP(89, 43, 20), '#8c8c94', 0.06, 0.1, 6, 3);
    R.flat(circleP(89, 43, 13), '#070708', 0.02, 0);
    a.save(); a.strokeStyle = '#6a6a72'; a.lineWidth = 2; for (let i = 0; i < 12; i++) { a.beginPath(); a.moveTo(i * 8 - 20, 0); a.lineTo(i * 8 + 10, 36); a.moveTo(i * 8 + 20, 0); a.lineTo(i * 8 - 10, 36); a.stroke(); } a.restore();
    R.flat(rrect(-10, -10, 80, 20, 0), '#0b0b0d', 0.02, 0);
    R.flat(rrect(140, -10, 14, 44, 3), '#a4b2f0', 0.06, 4); R.flat(rrect(162, -10, 14, 50, 3), '#a4b2f0', 0.06, 4);

    // ── right grey panel behind the yarn ──
    R.flat(rrect(420, 90, 300, 246, 40), '#b6b6ba', 0.04, 4);
    speckle(rrect(420, 90, 300, 246, 40), 1400, 4, '#707078', 0.5);

    // ── coral arms with grey shadows ──
    const arms = [
      [[[229, -10], [243, 57], [257, 114], [271, 164], [290, 205]], 32, 18, 1], [[[307, -10], [321, 57], [329, 114], [336, 171], [330, 215]], 30, 16, 2],
      [[[393, -10], [400, 57], [393, 114], [379, 171], [350, 212]], 32, 16, 3], [[[-10, 318], [71, 300], [143, 293], [200, 286], [240, 279]], 30, 20, 4],
      [[[-10, 410], [57, 371], [114, 350], [171, 336], [220, 316]], 34, 22, 5], [[[250, 340], [214, 386], [186, 429], [166, 470], [160, 520], [166, 556]], 32, 16, 6],
      [[[400, 300], [412, 330], [404, 360]], 22, 10, 7], [[[470, 318], [490, 345], [486, 372]], 20, 10, 8], [[[545, 330], [570, 350], [596, 368]], 22, 10, 9],
      [[[610, 310], [636, 336], [650, 360]], 22, 10, 10], [[[660, 300], [690, 320], [690, 346]], 18, 8, 11], [[[590, 60], [610, 70], [612, 95], [605, 112]], 16, 8, 12]];
    const branches = [[[[57, 371], [40, 400], [20, 420]], 16, 6, 21], [[[114, 350], [100, 380], [110, 404]], 16, 6, 22], [[[186, 429], [150, 440], [120, 450]], 16, 6, 23],
      [[[166, 470], [140, 488], [128, 510]], 14, 6, 24], [[[160, 520], [190, 540], [210, 560]], 14, 6, 25], [[[166, 556], [150, 570]], 12, 6, 26],
      [[[143, 293], [130, 262], [140, 240]], 14, 6, 27], [[[71, 300], [60, 330]], 12, 6, 28], [[[200, 286], [214, 256]], 12, 6, 29]];
    for (const [cl, w0, w1, sd] of [...arms, ...branches]) R.flat(coral(cl.map(([x, y]) => [x + 9, y + 9]), w0 * 1.3, w1 * 1.3, sd, 7), SHAD, 0.05, 4);
    for (const [cl, w0, w1, sd] of [...arms, ...branches]) R.dome(coral(cl, w0 * 1.3, w1 * 1.3, sd, 7), PINK, 0.12, 0.12, 7, 1);

    // ── pink yarn mass ──
    const yarn = P([[420, 135], [500, 118], [571, 121], [643, 136], [700, 164], [716, 214], [708, 271], [680, 300], [640, 312], [600, 330], [560, 340], [510, 330], [470, 320], [430, 300], [392, 280], [372, 240], [386, 190]]);
    R.flat(P([[430, 145], [510, 128], [580, 131], [650, 146], [710, 174], [726, 224], [718, 281], [690, 310], [600, 340], [520, 342], [440, 312], [382, 250], [396, 200]]), SHAD, 0.05, 4);
    R.dome(yarn, PINK, 0.12, 0.14, 10, 1);
    a.save(); a.clip(yarn); R.h.save(); R.h.clip(yarn);
    R.flat(rrect(360, 100, 370, 260, 0), '#b0585c', 0.1, 1);
    { const yr = rng(5); for (let i = 0; i < 26; i++) { const y0 = 120 + i * 8.5 + yr() * 4, pts = [], x0 = 360 + yr() * 60, x1 = 600 + yr() * 140, ph = yr() * 6;
      for (let x = x0; x <= x1; x += 14) pts.push([x, y0 + Math.sin(x * 0.03 + ph) * 5 + (x - 540) * 0.05 * (i - 13) / 13]);
      R.pipe(P(pts, false), 10 + yr() * 3, PINK, 0.14, 0.1, 1); } }
    a.restore(); R.h.restore();
    // ── lavender urchin ──
    const UC = [293, 279];
    for (let i = 0; i < 18; i++) {
      const t = i / 18 * 6.283 + 0.1, L = 108 + (i % 3) * 14, w = 15;
      const c = Math.cos(t), s = Math.sin(t), bx = UC[0] + c * 58, by = UC[1] + s * 58;
      R.dome(P([[bx - s * w, by + c * w], [UC[0] + c * L, UC[1] + s * L], [bx + s * w, by - c * w]], true, false), '#a8b4f2', 0.14, 0.1, 5, 2);
      R.bead(UC[0] + c * (L - 6), UC[1] + s * (L - 6), 6, '#b4c0f6', 0.2, 0.05, 2);
    }
    R.dome(circleP(UC[0], UC[1], 66), '#a8b4f2', 0.14, 0.2, 30, 2);

    // ── pearl-cream flow ──
    const CREAM = '#f1e8cf';
    const plate = P([[-20, 480], [30, 490], [80, 483], [120, 470], [150, 482], [190, 492], [225, 478], [260, 450], [300, 429], [350, 405], [400, 350], [450, 335], [500, 335],
      [560, 330], [620, 330], [680, 325], [746, 322], [746, 436], [700, 434], [650, 467], [600, 465], [578, 482], [566, 530], [558, 572], [538, 604], [522, 648], [508, 700],
      [496, 752], [470, 790], [450, 801], [400, 808], [372, 826], [350, 850], [330, 830], [300, 806], [260, 795], [220, 783], [180, 800], [150, 840], [110, 860], [80, 869],
      [40, 890], [20, 909], [-20, 915]], true, true);
    const pearl = a.createLinearGradient(0, 400, 700, 1000); pearl.addColorStop(0, '#e6e0d2'); pearl.addColorStop(0.5, '#ece5d2'); pearl.addColorStop(1, '#e2d9c4');
    R.dome(plate, pearl, 0.06, 0.4, 64, 3);
    const tubes = [
      [[[560, 545], [600, 540], [630, 522], [650, 515], [680, 504], [700, 497], [750, 485]], 42],
      [[[480, 705], [520, 700], [550, 689], [575, 668], [600, 655], [625, 628], [650, 617], [680, 606], [700, 597], [750, 585]], 62],
      [[[230, 1050], [260, 992], [300, 960], [350, 937], [400, 931], [430, 915], [450, 898], [500, 875], [550, 860], [575, 840], [600, 812], [625, 780], [650, 760], [700, 716], [750, 690]], 64],
      [[[370, 1050], [410, 1026], [450, 1013], [500, 1000], [555, 978]], 52], [[[372, 834], [336, 856], [298, 862]], 54]];
    const wavy = (cl, amp, per) => { const out = []; let acc = 0; for (let i = 0; i < cl.length - 1; i++) { const p = cl[i], q = cl[i + 1], L = Math.hypot(q[0] - p[0], q[1] - p[1]), k = Math.max(1, Math.round(L / 6)), nx = -(q[1] - p[1]) / L, ny = (q[0] - p[0]) / L;
      for (let j = 0; j < k; j++) { const u = j / k, d = amp * Math.sin((acc + L * u) / per * 6.283); out.push([p[0] + (q[0] - p[0]) * u + nx * d, p[1] + (q[1] - p[1]) * u + ny * d]); } acc += L; } out.push(cl[cl.length - 1]); return out; };
    for (const t of tubes) if (t[0].length > 3) t[0] = wavy(t[0], 9, 90);
    for (const [cl, wd] of tubes) R.pipe(P(cl, false), wd, pearl, 0.06, 0.34, 3);
    R.dome(ellipseP(30, 1020, 86, 56, 0.1), pearl, 0.06, 0.34, 40, 3);
    // holes in the flow
    R.dome(ellipseP(78, 600, 36, 28, 0.2), '#0b0b0d', 0.0, 0.02, 4, 0);
    R.dome(ellipseP(4, 728, 26, 22, 0), '#0b0b0d', 0.0, 0.02, 4, 0);
    R.dome(circleP(86, 608, 12), '#b8c4f8', 0.1, 0.18, 10, 5);
    // flat pale top: soften the albedo toward cream in the plateau
    soft(x => { x.fillStyle = '#f6eed8'; x.fill(P([[300, 470], [420, 400], [540, 370], [700, 360], [700, 420], [560, 460], [520, 560], [490, 700], [440, 770], [340, 760], [290, 700], [250, 560]])); }, 24, 0.8);
    speckle(plate, 14000, 8, '#9a8a6a', 0.35);
    for (const [cl, wd] of tubes) speckle(P(lock(cl, wd, wd, 1)), 2500, 9, '#9a8a6a', 0.4);

    // ── glossy grey drops ──
    const drops = P([[423, 346], [485, 338], [546, 346], [631, 369], [692, 385], [736, 392], [736, 427], [677, 423], [631, 423], [585, 446], [554, 469], [538, 531], [531, 608],
      [515, 669], [500, 731], [462, 762], [400, 771], [338, 754], [308, 715], [308, 662], [323, 638], [369, 615], [423, 577], [455, 531], [460, 490], [452, 468], [438, 470],
      [400, 515], [354, 562], [315, 592], [285, 596], [262, 569], [262, 523], [292, 469], [346, 423], [400, 385], [415, 362]]);
    R.dome(drops, '#6c6c73', 0.12, 0.3, 26, 6);

    // ── little blue lizard ──
    const LZ = '#a8c4d2';
    R.dome(P([[726, 262], [700, 250], [676, 254], [650, 262], [628, 268], [624, 280], [640, 290], [668, 296], [690, 304], [704, 320], [726, 330]]), LZ, 0.14, 0.16, 12, 2);
    R.dome(P([[700, 330], [690, 346], [696, 360], [714, 356], [726, 344]]), LZ, 0.14, 0.12, 8, 2);
    R.bead(686, 266, 7, '#f4f4f0', 0.28, 0.06, 2); R.bead(687, 266, 3.5, '#101010', 0.32, 0.03, 0);
    R.groove(P([[632, 282], [660, 284], [686, 290]], false), 3, '#5a7480', 0.3, 0.05, 2);
    for (const [x, y] of [[670, 250], [690, 244], [706, 248]]) R.bead(x, y, 5, LZ, 0.2, 0.06, 2);

    // ── silver star ──
    { const cx = 175, cy = 915, pts = []; for (let i = 0; i < 10; i++) { const t = -1.72 + i / 10 * 6.283, r = i % 2 ? 30 : 104; pts.push([cx + Math.cos(t) * r, cy + Math.sin(t) * r * 1.02]); }
      R.flat(P(pts.map(([x, y]) => [x + 7, y + 8]), true, false), '#050506', 0.04, 0);
      for (let i = 0; i < 10; i++) {
        const p = pts[i], q = pts[(i + 1) % 10], tri = P([[cx, cy], p, q], true, false);
        const lit = ((i % 2) ? 0.2 : 0) + 0.5 + 0.35 * Math.cos(Math.atan2((p[1] + q[1]) / 2 - cy, (p[0] + q[0]) / 2 - cx) + 2.4);
        R.flat(tri, mixHex('#6a6c74', '#e4e6ec', clamp(lit)), 0.2, 7);
      } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.5, ao: 0.4, emis: 0.12 }),                          // 1 pink clay
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.8, ao: 0.4 }),                                       // 2 lavender urchin / lizard
        E.mat({ dif: 1, spec: 1.1, shin: 20, wrap: 0.3, ao: 0.6, coat: 0.3, metal: 0.25, tint: [1.08, 1.02, 0.9], grain: 0.1 }), // 3 pearl cream
        E.mat({ dif: 1, spec: 0.05, shin: 10, wrap: 0.4 }),                                                // 4 flat panels
        E.mat({ dif: 1, spec: 1.1, shin: 60, wrap: 0.3, coat: 0.2 }),                                      // 5 bubbles
        E.mat({ dif: 1, spec: 1.0, shin: 50, wrap: 0.25, coat: 0.2, ao: 0.4 }),                            // 6 glossy grey
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.2 })                                                  // 7 star facets
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.72, 0.7, 0.66], amb: [0.5, 0.5, 0.52],
      envTop: [1.1, 1.05, 0.95], envHor: [0.75, 0.68, 0.55], envBot: [0.25, 0.22, 0.18], envK: [0.3, 0.9, 0.3, 0],
      rimC: [0.2, 0.18, 0.12], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [6, 8, 0.6, 6]
    });
    E.grain(0.05, 42);
  }
});
