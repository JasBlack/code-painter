'use strict';
// g075 — "Coin avalanche at sea": a surreal collage on black — a sky-and-sea window, a gold bottle spraying
// purple grit under a smoke plume, a heap of gold and white coins spilling onto a fanning zebra floor,
// a hot-pink tube letter in cream slime, a magenta tube arm, a wooden plank and a bead-track ramp.
REC.register('g075', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r0); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const inside = (path, x, y) => a.isPointInPath(path, x * S, y * S);
    const r = rng(75);

    // ── black ground + sky/sea window (unlit) ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#020203', 0, 0);
    const skyWin = P([[140, 8], [580, 8], [610, 40], [630, 350], [632, 430], [560, 440], [300, 430], [170, 460], [20, 460], [4, 350], [12, 252], [40, 200], [86, 172], [146, 162], [152, 110], [134, 50]]);
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float y = p.y;
      vec3 c = mix(vec3(0.21, 0.36, 0.50), vec3(0.32, 0.52, 0.70), smoothstep(0., 100., y));
      c = mix(c, vec3(0.49, 0.62, 0.71), smoothstep(100., 165., y));
      c = mix(c, vec3(0.73, 0.76, 0.76), smoothstep(160., 225., y));
      c = mix(c, vec3(1.0, 1.0, 0.99), smoothstep(222., 268., y));
      c = mix(c, vec3(0.97, 0.92, 0.82), smoothstep(282., 298., y));
      c = mix(c, vec3(0.40, 0.50, 0.58), smoothstep(298., 322., y));
      c = mix(c, vec3(0.17, 0.41, 0.60), smoothstep(320., 360., y));
      float glint = smoothstep(0.75, 0.95, vnoise(vec2(p.x * 0.08, p.y * 0.6))) * smoothstep(300., 330., y) * (1. - smoothstep(360., 380., y));
      return c + glint * 0.35; }`));
    R.flat(skyWin, sky, 0, 0);
    // clouds
    soft(x => {
      const cl = (cx, cy, rr, c) => { x.fillStyle = c; x.fill(circleP(cx, cy, rr)); };
      for (const [cx, cy, rr] of [[20, 380, 30], [55, 362, 32], [95, 372, 30], [130, 388, 26], [160, 404, 22], [10, 420, 30], [60, 410, 34], [110, 420, 28], [30, 445, 26], [140, 440, 18],
        [580, 360, 18], [602, 350, 20], [620, 372, 18], [590, 392, 22], [612, 408, 20], [575, 412, 14]]) cl(cx, cy, rr, '#a7a4b4');
      for (const [cx, cy, rr] of [[22, 372, 24], [56, 354, 26], [96, 364, 24], [128, 380, 20], [158, 398, 16], [12, 410, 22], [62, 398, 26], [110, 410, 20],
        [582, 352, 13], [604, 342, 15], [620, 364, 13], [592, 384, 15]]) cl(cx, cy, rr, '#f6f4f2');
    }, 3);

    // ── zebra floor fanning out from the coin heap ──
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(560., 560.); float rr = length(d);
      float ph = atan(d.y, d.x) / 0.29 + 0.8 * sin(rr * 0.011 - 0.6) + 0.25 + 0.15 * (fbm(p * 0.01) - .5);
      float f = fract(ph);
      vec3 c = mix(vec3(0.03), vec3(0.98, 0.97, 0.95), smoothstep(0.47, 0.51, f) * smoothstep(0.99, 0.95, f));
      float cr = smoothstep(0.02, 0.0, abs(fbm(p * 0.03) - .5)) * 0.4;
      return mix(c, vec3(0.6), cr * step(0.5, f)); }`));
    const floor = P([[70, 720], [80, 620], [120, 520], [190, 470], [260, 456], [320, 470], [400, 560], [560, 650], [656, 700], [656, 860], [500, 900], [300, 970], [150, 1000], [90, 940], [72, 860]]);
    R.dome(floor, zeb, 0.04, 0.03, 30, 5);
    keep();

    // ── pink tube arm (left) with blue hole ──
    R.flat(P([[76, 560], [130, 520], [190, 540], [190, 640], [150, 720], [76, 720]]), '#020203', 0.05, 0);
    R.dome(P([[80, 572], [110, 540], [150, 532], [176, 548], [150, 566], [110, 590], [86, 630]]), '#0a4cf8', 0.05, 0.02, 10, 1);
    R.dome(P([[76, 660], [96, 650], [110, 690], [90, 720], [76, 716]]), '#0a4cf8', 0.05, 0.02, 6, 1);
    R.dome(P([[-10, 870], [60, 890], [130, 930], [180, 980], [200, 1034], [-10, 1034]]), '#0a4cf8', 0.04, 0.02, 10, 1);
    R.dome(P([[656, 840], [736, 850], [736, 1000], [700, 990]]), '#0a4cf8', 0.04, 0.02, 10, 1);
    const arm = P([[300, 352], [240, 372], [170, 392], [100, 420], [50, 450], [10, 490], [-10, 520], [-10, 905], [40, 925], [100, 940], [150, 940], [130, 920], [90, 895], [78, 850],
      [74, 780], [74, 700], [76, 630], [86, 575], [110, 535], [150, 500], [200, 476], [260, 465], [300, 462]]);
    R.dome(arm, lin(0, 400, 300, 900, [[0, '#ff98e2'], [0.5, '#f986d8'], [1, '#e874cc']]), 0.12, 0.2, 40, 1);
    // splatter marks on the arm
    for (const [x, y, rx, ry, rot, c] of [[220, 420, 22, 4, -0.7, '#c01818'], [196, 452, 6, 3, 0, '#2a0808'], [50, 540, 14, 5, -0.9, '#2a0808'], [20, 600, 8, 14, 0, '#3a0a0a'], [10, 700, 4, 12, 0, '#3a0a0a'],
      [26, 880, 16, 5, 0.6, '#2a0808'], [70, 910, 18, 5, 0.4, '#2a0808'], [40, 520, 5, 3, 0, '#c01818']]) a.fillStyle = c, a.fill(ellipseP(x, y, rx, ry, rot));
    keep();

    // ── wooden plank + purple blob ──
    const woodTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float g = fbm(vec2(p.x * 0.02 + p.y * 0.015, (p.x - p.y) * 0.25));
      return mix(vec3(0.90, 0.72, 0.58), vec3(0.98, 0.80, 0.66), g); }`));
    R.dome(P([[364, 336], [444, 222], [482, 236], [598, 392], [470, 380]], true, false), woodTex, 0.06, 0.03, 6, 4);
    a.strokeStyle = 'rgba(80,40,20,0.7)'; a.lineWidth = 1.5; a.stroke(P([[440, 260], [470, 300], [480, 296], [520, 360]], false, false));
    const blobP = P([[285, 320], [320, 310], [390, 330], [440, 350], [470, 380], [480, 450], [470, 520], [420, 560], [370, 570], [330, 530], [300, 470], [280, 400]]);
    R.dome(blobP, rad(360, 420, 180, [[0, '#b892d6'], [0.7, '#a880c6'], [1, '#9068b0']]), 0.08, 0.05, 30, 1);
    for (let i = 0; i < 40; i++) { const x = 300 + r() * 170, y = 320 + r() * 220; if (inside(blobP, x, y)) R.bead(x, y, 1.5 + r() * 2, r() < 0.5 ? '#40d0e0' : '#f0f0f8', 0.14, 0.02, 3); }
    keep();

    // ── cream noodles ──
    for (const pts of [[[124, 476], [160, 470], [200, 490], [240, 520], [280, 532], [300, 520]], [[326, 400], [328, 440], [322, 480], [340, 500], [356, 480], [340, 460], [316, 480], [304, 520], [320, 548], [350, 548], [356, 520]],
      [[300, 500], [296, 560], [300, 600], [330, 620], [340, 600]], [[318, 450], [300, 470], [290, 520]]])
      R.pipe(P(pts, false), 16, '#f4ecd0', 0.24, 0.07, 3);
    keep();

    // ── cream slime + pink tube letter (right) ──
    const slime = P([[548, 32], [600, 26], [660, 30], [672, 80], [660, 150], [690, 210], [700, 300], [660, 320], [690, 380], [710, 430], [700, 520], [726, 560], [736, 640],
      [690, 660], [670, 760], [680, 840], [650, 860], [636, 760], [630, 600], [610, 470], [640, 380], [650, 260], [620, 140], [570, 100], [548, 70]]);
    R.dome(slime, lin(560, 0, 726, 0, [[0, '#fafcc0'], [1, '#eef4b0']]), 0.06, 0.06, 26, 1);
    R.flat(P([[690, 240], [736, 228], [736, 330], [700, 320]]), '#020203', 0.06, 0);
    R.flat(P([[700, 660], [736, 650], [736, 850], [690, 840]]), '#020203', 0.06, 0);
    const letter = P([[492, 250], [520, 170], [550, 112], [580, 92], [612, 104], [636, 170], [650, 260], [648, 340], [636, 410], [616, 466]], false);
    R.pipe(letter, 50, '#a01048', 0.12, 0.04, 1);
    R.pipe(letter, 44, lin(480, 0, 660, 0, [[0, '#ff5c8c'], [0.5, '#fc4a80'], [1, '#f03a74']]), 0.13, 0.16, 1);
    R.pipe(P([[498, 262], [570, 268], [640, 276]], false), 26, '#fc4a80', 0.13, 0.1, 1);
    R.groove(P([[600, 110], [628, 180], [640, 260], [636, 340], [624, 410]], false), 7, '#7a0828', 0.26, 0.05, 1, 0.9);
    keep();

    // ── gold bottle, smoke, purple grit ──
    soft(x => {
      x.lineCap = 'round';
      for (const [w, c] of [[70, 'rgba(70,80,92,0.7)'], [42, 'rgba(40,46,54,0.9)']]) { x.lineWidth = w; x.strokeStyle = c; x.stroke(P([[306, 270], [312, 210], [326, 150], [344, 90], [370, 40], [396, -10]], false)); }
      for (let i = 0; i < 26; i++) { const t = i / 25, cx = 306 + t * 80 + Math.sin(i * 1.7) * 22, cy = 268 - t * 270; x.fillStyle = 'rgba(30,34,40,0.55)'; x.fill(circleP(cx, cy, 14 + t * 22)); }
    }, 7);
    const goldA = (x0, y0, x1, y1) => lin(x0, y0, x1, y1, [[0, '#fff2b0'], [0.3, '#f2c850'], [0.65, '#c89028'], [1, '#d070e8']]);
    R.dome(P([[86, -10], [134, -10], [150, 40], [144, 96], [112, 106], [100, 60]]), goldA(86, 0, 154, 100), 0.3, 0.12, 30, 2);
    R.dome(P([[104, 70], [136, 60], [150, 96], [120, 108]]), '#c868f0', 0.32, 0.04, 8, 1);
    R.dome(P([[150, 40], [200, 26], [252, 32], [282, 80], [288, 140], [272, 190], [240, 206], [200, 196], [168, 160], [148, 110]]), lin(150, 30, 290, 210, [[0, '#fff2b0'], [0.3, '#f4cc58'], [0.6, '#d8a030'], [0.85, '#e098c0'], [1, '#c060f0']]), 0.3, 0.2, 50, 2);
    soft(x => { x.fillStyle = '#d070f0'; x.fill(ellipseP(156, 100, 22, 34, 0.3)); x.fill(ellipseP(200, 182, 30, 16, 0.4)); }, 8, 0.85);
    R.dome(P([[208, 186], [252, 176], [302, 286], [284, 298]], true, false), goldA(208, 180, 300, 300), 0.34, 0.08, 10, 2);
    for (const [y, w] of [[196, 52], [214, 46]]) R.pipe(P([[232 - w / 2 + (y - 190) * 0.4, y + 6], [232 + w / 2 + (y - 190) * 0.4, y - 8]], false), 10, '#e8c870', 0.4, 0.06, 2);
    R.dome(ellipseP(258, 32, 18, 24, 0.2), '#f080d0', 0.4, 0.06, 10, 1);
    R.dome(P([[140, 118], [160, 110], [164, 130], [150, 146], [138, 136]]), '#f0dcb8', 0.42, 0.05, 6, 3);
    for (let i = 0; i < 70; i++) { const t = r() * Math.PI * 2, d = Math.sqrt(r()) * 26; R.bead(306 + Math.cos(t) * d, 292 + Math.sin(t) * d * 0.9, 2.5 + r() * 2.5, r() < 0.7 ? '#3a1050' : '#6a2a90', 0.4, 0.03, 3); }
    keep();

    // ── coin heap ──
    const heap = P([[486, 392], [512, 388], [540, 420], [564, 480], [584, 545], [604, 610], [612, 670], [580, 704], [520, 712], [450, 704], [400, 686], [386, 630], [400, 560], [424, 490], [454, 430]]);
    R.dome(heap, '#4a3a22', 0.24, 0.06, 30, 3);
    const coins = [];
    for (let i = 0; i < 8000 && coins.length < 150; i++) { const x = 360 + r() * 280, y = 360 + r() * 380; if (inside(heap, x, y) && !coins.some(([cx, cy]) => Math.abs(cx - x) < 22 && Math.abs(cy - y) < 14)) coins.push([x, y]); }
    for (const p of [[375, 750], [405, 790], [475, 740], [527, 742], [552, 783], [412, 718], [352, 690], [385, 705], [448, 730], [500, 714], [570, 404], [618, 368], [642, 424], [570, 348]]) coins.push(p);
    coins.sort((p, q) => p[1] - q[1]);
    for (const [x, y] of coins) {
      const gold = r() < 0.42, rx = 21 + r() * 7, ry = 11 + r() * 9, rot = (r() - 0.5) * 1.1;
      R.dome(ellipseP(x + 1, y + 5, rx + 1, ry + 1, rot), '#2a1e10', 0.28, 0.01, 2, 3);
      R.dome(ellipseP(x, y + 3.5, rx, ry, rot), gold ? '#a87a10' : '#9a948a', 0.3, 0.02, 3, gold ? 7 : 3);
      R.dome(ellipseP(x, y, rx, ry, rot), gold ? rad(x - rx * 0.3, y - ry * 0.4, rx * 1.5, [[0, '#fff4b0'], [0.45, '#f8d040'], [1, '#d8a010']]) : '#f6f4f0', 0.32, 0.04, 4, gold ? 7 : 3);
      if (gold) R.groove(ellipseP(x, y, rx * 0.72, ry * 0.72, rot), 2, '#c08a10', 0.36, 0.01, 7, 0.8);
      else for (let k = 0; k < 6; k++) a.fillStyle = '#3a3030', a.fill(circleP(x + (r() - 0.5) * rx * 1.2, y + (r() - 0.5) * ry * 1.1, 0.8));
    }
    keep();

    // ── wooden ramp with bead track, cookie ──
    const ramp = P([[24, 1034], [650, 836], [736, 1012], [736, 1034]], true, false);
    const rampTex = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float g = fbm(vec2((p.x * 0.95 + p.y * 0.3) * 0.25, (p.y - p.x * 0.3) * 0.02));
      return mix(vec3(0.70, 0.48, 0.32), vec3(0.86, 0.62, 0.44), g); }`));
    R.dome(ramp, rampTex, 0.2, 0.02, 6, 4);
    R.pipe(P([[24, 1022], [650, 834]], false), 7, '#c8ccd4', 0.24, 0.05, 6);
    R.pipe(P([[60, 1034], [660, 846]], false), 3, '#6a5040', 0.22, 0.01, 4);
    R.flat(P([[498, 868], [528, 858], [470, 1034], [436, 1034]], true, false), '#1a1a20', 0.22, 6);
    R.pipe(P([[498, 866], [436, 1034]], false), 5, '#d0d4dc', 0.26, 0.05, 6);
    R.pipe(P([[528, 856], [470, 1034]], false), 5, '#d0d4dc', 0.26, 0.05, 6);
    for (let i = 0; i < 9; i++) { const t = i / 8.6; R.bead(512 - t * 60, 870 + t * 160, 11, '#0c0c10', 0.26, 0.1, 6); }
    R.dome(ellipseP(618, 924, 24, 15), '#1a1414', 0.26, 0.06, 8, 3);
    R.dome(ellipseP(618, 914, 24, 15), '#f4f2ee', 0.3, 0.05, 8, 3);
    for (let k = 0; k < 10; k++) a.fillStyle = '#2a2020', a.fill(circleP(618 + (r() - 0.5) * 34, 914 + (r() - 0.5) * 20, 1));
    R.dome(ellipseP(706, 372, 22, 13, -0.2), '#f4f2ee', 0.3, 0.05, 6, 3);
    R.dome(ellipseP(548, 262, 16, 10, 0), '#f2c840', 0.3, 0.06, 6, 2);
    R.dome(ellipseP(644, 466, 15, 10, 0.3), '#f2c840', 0.3, 0.06, 6, 2);
    // specks on black
    for (const [x, y, c] of [[38, 404, '#e83030'], [110, 615, '#f0e0a0'], [690, 437, '#e02020'], [12, 932, '#ffffff'], [586, 590, '#e83030'], [498, 172, '#e83030'], [690, 182, '#f0e060']])
      a.fillStyle = c, a.fill(circleP(x, y, 2.5));
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, ao: 0.35, coat: 0.15, rim: 0.2 }),          // 1 glossy plastic
        E.mat({ dif: 1, spec: 1.5, shin: 60, metal: 0.2, wrap: 0.3, ao: 0.25, tint: [1.2, 1.0, 0.7] }), // 2 gold
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.35, ao: 0.4 }),                                // 3 ceramic / matte
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.4, ao: 0.3, grain: 0.15 }),                     // 4 wood
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.3 }),                                // 5 zebra floor
        E.mat({ dif: 1, spec: 1.6, shin: 90, coat: 0.4, ao: 0.2 }),                                 // 6 chrome / black beads
        E.mat({ dif: 1.05, spec: 1.3, shin: 60, wrap: 0.3, ao: 0.25, coat: 0.1 }),                    // 7 coin gold
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.85, 0.84, 0.82], amb: [0.4, 0.4, 0.42],
      envTop: [1, 1, 1.02], envHor: [0.6, 0.6, 0.62], envBot: [0.1, 0.1, 0.12], envK: [0.25, 1.0, 0.3, 0],
      rimC: [0.2, 0.2, 0.25], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 55], shadow: [-4, 6, 0.45, 6]
    });
    // horizon glow
    const o = E.out;
    o.save(); o.globalCompositeOperation = 'screen'; o.filter = `blur(${10 * S}px)`; o.fillStyle = 'rgba(255,250,235,0.6)'; o.fill(ellipseP(240, 290, 90, 10)); o.restore();
    E.grain(0.025, 5);
  }
});
