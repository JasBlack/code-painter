'use strict';
// u090 — "Leopard bear, blue drum": a leopard-print teddy perches on a lavender-blue drum with a fan-grille
// cushion, among white airbrushed ribbons, mint rings round a violet moon, grey chevrons, a white sun with
// red rays and a beige cloud, all cut out against a dense black starfield.
REC.register('u090', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, r0 = 0) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    // tapered ribbon along a centreline (thick in the middle)
    const ribbon = (cl, wd, p0 = 0.5) => {
      const A = [], B = [], n = cl.length;
      for (let i = 0; i < n; i++) {
        const p = cl[i], q = cl[Math.max(0, i - 1)], r = cl[Math.min(n - 1, i + 1)];
        let dx = r[0] - q[0], dy = r[1] - q[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
        const t = i / (n - 1), w = wd * 0.5 * Math.pow(Math.sin(Math.PI * clamp(t * (1 - p0) + p0 * t * t + 0.02, 0.02, 0.98)), 0.6);
        A.push([p[0] - dy * w, p[1] + dx * w]); B.push([p[0] + dy * w, p[1] - dx * w]);
      }
      return P([...A, ...B.reverse()]);
    };

    // ── black starfield ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#050505', 0, 0);
    const stars = (n, seed, rmax) => { const r = rng(seed); for (let i = 0; i < n; i++) { const x = r() * 726, y = r() * 1024, rr = r() < 0.75 ? 0.8 + r() * 1.4 : 2 + r() * rmax; a.globalAlpha = 0.5 + r() * 0.5; fill(circleP(x, y, rr), '#f4f4f0'); } a.globalAlpha = 1; };
    stars(900, 90, 3.5);

    // ── maroon panel top right with royal-blue patches ──
    R.flat(poly([[600, -10], [736, -10], [736, 470], [700, 470], [640, 430], [600, 300]]), lin(600, 0, 736, 400, [[0, '#5a1a22'], [0.5, '#6e2228'], [1, '#7a1a20']]), 0.01, 0);
    fill(sm([[662, -10], [736, -10], [736, 60], [700, 70], [672, 40]]), '#1c3cb0');
    fill(sm([[640, 110], [690, 100], [736, 96], [736, 220], [700, 214], [660, 196], [630, 160]]), '#1a3aae');
    stars(60, 91, 1.5);
    // rusty nebula with orange sparks
    soft(x => { fill(P(blob(548, 90, 62, 110, 4, 16, 0.3)), '#7a4428', x); fill(P(blob(520, 40, 40, 40, 9, 10, 0.3)), '#6a3a22', x); }, 5, 1);
    { const r = rng(5); for (let i = 0; i < 160; i++) { const x = 490 + r() * 120, y = r() * 210; fill(circleP(x, y, 0.8 + r() * 2.2), r() < 0.5 ? '#f0a050' : '#3050a0'); } }
    soft(x => { const r = rng(6); for (let i = 0; i < 9; i++) { let px = 430, py = 10 + r() * 140; const pts = [[px, py]]; for (let k = 0; k < 6; k++) { px += 10 + r() * 8; py += (r() - 0.5) * 14; pts.push([px, py]); } stroke(P(pts, false, false), '#ff9a40', 1.5, x); } }, 0.6, 0.9);
    fill(sm([[520, 140], [560, 130], [575, 170], [560, 240], [540, 300], [520, 260]]), '#5a80c0');

    // ── royal blue textured patches + grey chevrons ──
    R.flat(sm([[432, 228], [476, 206], [520, 220], [540, 300], [560, 380], [560, 440], [520, 450], [480, 430], [450, 380], [460, 300]]), '#1c34a4', 0.02, 0);
    clipA(sm([[432, 228], [476, 206], [520, 220], [540, 300], [560, 380], [560, 440], [520, 450], [480, 430], [450, 380], [460, 300]]), () => { const r = rng(8); for (let i = 0; i < 900; i++) fill(circleP(430 + r() * 140, 200 + r() * 260, 0.8), r() < 0.5 ? '#3050c8' : '#0c1c70'); });
    // leopard ribbon
    const leoP = ribbon([[444, 152], [480, 162], [510, 182], [536, 214], [556, 250], [570, 280]], 26, 0);
    R.dome(leoP, '#d07a28', 0.1, 0.06, 8, 4);
    const LEO = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p / 9. + vec2(fbm(p * .04), fbm(p * .04 + 3.)) * 1.2; vec2 i = floor(q), f = fract(q); float d = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 o = vec2(hash(i + g), hash(i + g + 7.3)); d = min(d, length(g + o - f)); }
      float spot = smoothstep(.42, .34, d + (vnoise(p * .3) - .5) * .25);
      vec3 c = mix(vec3(.82, .40, .10), vec3(.95, .58, .20), vnoise(p * .05));
      return mix(c, vec3(.07, .03, .02), spot); }`);
    clipA(leoP, () => img(LEO));
    // chevron A
    const chevA = ribbon([[488, 330], [520, 260], [560, 170], [592, 112], [612, 120], [640, 150], [664, 186]], 28, 0.3);
    R.dome(chevA, lin(480, 330, 664, 120, [[0, '#b0b0ae'], [0.5, '#8c8c8a'], [1, '#a8a8a6']]), 0.12, 0.1, 9, 1);
    // chevron B (wide blade)
    const chevB = sm([[438, 446], [470, 410], [530, 360], [590, 318], [632, 292], [646, 300], [640, 330], [610, 360], [550, 400], [500, 436], [460, 460]]);
    R.dome(chevB, lin(440, 450, 646, 290, [[0, '#c4c4c0'], [0.5, '#9c9c98'], [1, '#bcbcb8']]), 0.12, 0.1, 12, 1);
    // white sun with red rays
    { const rays = []; for (let i = 0; i < 26; i++) { const ang = i / 26 * Math.PI * 2 + 0.1, r = i % 2 ? 46 : (i % 4 ? 96 : 80); rays.push([645 + Math.cos(ang) * r, 358 + Math.sin(ang) * r]); }
      R.flat(poly(rays), '#ec4a1a', 0.06, 0); R.dome(circleP(645, 358, 41), '#fafaf6', 0.08, 0.04, 6, 1); }
    // white-edged ridge line and glittering dark ground (right)
    const ground = sm([[480, 470], [540, 432], [600, 440], [650, 470], [736, 520], [736, 820], [680, 800], [660, 740], [640, 680], [600, 560], [540, 520]]);
    R.flat(ground, '#100e14', 0.02, 0);
    clipA(ground, () => { const r = rng(12); for (let i = 0; i < 700; i++) { const x = 470 + r() * 270, y = 420 + r() * 400; fill(ellipseP(x, y, 1 + r() * 5, 0.8 + r() * 2.5, r() * 3), ['#3a2a3a', '#2a3a6a', '#5a3a2a', '#1c1c30'][i % 4]); }
      for (let i = 0; i < 26; i++) { const x = 520 + r() * 210, y = 480 + r() * 320; soft(x2 => fill(circleP(x, y, 4), '#ffa040', x2), 3, 1); fill(circleP(x, y, 1.6), '#ffe0a0'); } });
    stroke(line([[520, 440], [580, 446], [640, 466], [690, 496], [736, 520]]), '#f0e8e8', 3);
    stroke(line([[540, 418], [600, 412], [660, 440], [736, 470]]), '#e8e0e0', 2);
    // white stripes bottom right
    for (let i = 0; i < 6; i++) { const y = 820 + i * 32; R.flat(ribbon([[650, y], [690, y + 14], [736, y + 30]], 12, 0), '#ece8e0', 0.05, 0); }
    R.flat(poly([[696, 980], [736, 970], [736, 1034], [690, 1034]]), '#7a1420', 0.02, 0);

    // ── beige airbrushed cloud top left ──
    const cloud = sm([[-20, -20], [196, -20], [222, 24], [248, 66], [262, 110], [258, 150], [240, 186], [206, 212], [170, 230], [130, 228], [96, 214], [60, 206], [20, 206], [-20, 206]]);
    R.flat(cloud, '#a49c92', 0.02, 0);
    clipA(cloud, () => soft(x => {
      for (const [r, w, c] of [[110, 26, '#7a7268'], [170, 22, '#857d73'], [225, 30, '#766f66'], [280, 18, '#8a8278']]) stroke(ellipseP(10, -70, r * 1.15, r, 0.2), c, w, x);
      fill(ellipseP(120, 150, 110, 40, 0), 'rgba(205,198,188,0.6)', x);
    }, 9, 1));
    stroke(line([[196, -6], [236, 40], [290, 92], [344, 128]]), '#f0f0f0', 4);
    // lavender-white blade
    R.flat(sm([[330, 126], [360, 138], [384, 166], [394, 222], [398, 282], [396, 336], [378, 332], [366, 300], [357, 256], [357, 210], [350, 170]]), '#dfe0f6', 0.04, 0);
    // red streaks + navy strip on the left edge
    R.flat(sm([[-10, 120], [10, 140], [36, 220], [50, 300], [54, 360], [40, 380], [10, 370], [-10, 360]]), '#e2481c', 0.03, 0);
    for (let i = 0; i < 5; i++) stroke(line([[-4 + i * 8, 140 + i * 8], [16 + i * 8, 240], [26 + i * 6, 360]]), '#8a1a10', 2);
    fill(sm([[-10, 280], [12, 296], [22, 380], [-10, 386]]), '#1a2470');

    // ── violet moon in a mint ring ──
    R.flat(circleP(282, 356, 57), '#6a3ae2', 0.04, 0);
    for (const [cx, cy, rx, ry, w] of [[278, 372, 92, 90, 6], [276, 370, 84, 82, 2], [100, 546, 90, 102, 7], [100, 546, 82, 94, 2]]) R.pipe(ellipseP(cx, cy, rx, ry, 0.1), w, '#5ccaa2', 0.06, 0.04, 2);
    // mint swirls
    for (const pts of [[[100, 268], [140, 260], [180, 300], [200, 360]], [[80, 290], [130, 286], [170, 330]], [[120, 440], [160, 470], [190, 520], [200, 560]], [[30, 560], [90, 520], [150, 490]]])
      R.pipe(line(pts), 5, '#5ccaa2', 0.06, 0.04, 2);
    for (const [x, y, r] of [[272, 373, 10], [280, 424, 11], [238, 514, 9], [290, 470, 8], [500, 432, 11], [330, 44, 8]]) R.bead(x, y, r, '#8ae0c0', 0.08, 0.1, 2);

    // ── white airbrushed ribbons (left / centre) ──
    const WH = lin(0, 0, 0, 1024, [[0, '#f2f2ee'], [1, '#e6e6e0']]);
    for (const [cl, w] of [[[[0, 396], [50, 404], [110, 420], [170, 440], [210, 470]], 9], [[[0, 430], [40, 440], [80, 470]], 7], [[[0, 650], [50, 680], [100, 696], [150, 690]], 22], [[[64, 568], [68, 610], [70, 660]], 10], [[[90, 560], [94, 600], [96, 640]], 9],
      [[[150, 640], [180, 670], [214, 700]], 14]])
      R.flat(ribbon(cl, w, 0.2), WH, 0.04, 0);
    R.flat(sm([[198, 524], [222, 514], [238, 552], [258, 508], [282, 516], [298, 580], [312, 640], [306, 686], [270, 700], [220, 712], [160, 724], [112, 728], [96, 712], [140, 690], [186, 652], [200, 600]]), WH, 0.04, 0);
    soft(x => { fill(ellipseP(250, 600, 14, 40, 0.3), '#050505', x); }, 3, 1);
    R.dome(ellipseP(282, 680, 44, 34, -0.3), rad(270, 690, 50, [[0, '#6a6662'], [0.6, '#c8c4bf'], [1, '#f0f0ec']]), 0.04, 0.04, 16, 0);
    for (const [x0, xm, x1, y0, y1, w] of [[190, 172, 178, 712, 940, 19], [220, 204, 206, 730, 905, 17], [252, 236, 242, 700, 955, 20], [280, 264, 268, 700, 935, 20], [306, 292, 294, 700, 945, 19]])
      R.flat(ribbon([[x0, y0], [xm, (y0 + y1) / 2], [x1, y1]], w, 0.1), lin(0, 690, 0, 960, [[0, '#6a6460'], [0.35, '#d8d6d0'], [1, '#eeeeea']]), 0.04, 0);

    // ── mint splash bottom left ──
    const mint = sm([[-20, 700], [40, 688], [96, 676], [124, 700], [108, 740], [128, 776], [140, 812], [128, 856], [136, 904], [150, 960], [200, 1000], [260, 1034], [-20, 1034]]);
    R.flat(mint, lin(0, 700, 160, 1024, [[0, '#76c8a4'], [0.6, '#7ad4b0'], [1, '#62b494']]), 0.03, 0);
    clipA(mint, () => { const r = rng(21); for (const [x, y, rx, ry] of [[40, 760, 26, 12], [60, 810, 30, 14], [20, 880, 18, 30], [90, 760, 12, 30], [80, 920, 28, 16], [110, 860, 14, 22], [30, 980, 20, 12], [120, 990, 30, 10]]) fill(P(blob(x, y, rx, ry, r() * 99 | 0, 10, 0.3)), '#060807'); });
    // bottom dark teal + mint ribbon
    R.flat(sm([[180, 970], [300, 950], [460, 960], [640, 950], [736, 980], [736, 1034], [180, 1034]]), '#0c1616', 0.02, 0);
    R.flat(sm([[300, 960], [380, 950], [470, 968], [560, 952], [610, 940], [646, 960], [640, 990], [600, 990], [540, 978], [470, 992], [380, 980], [310, 990]]), '#5ccaa2', 0.05, 0);

    // ── the lavender-blue drum ──
    const drum = sm([[318, 622], [372, 604], [470, 600], [600, 610], [652, 646], [660, 740], [656, 860], [652, 950], [620, 964], [420, 966], [302, 958], [298, 900], [306, 780], [312, 690]]);
    R.dome(drum, lin(300, 600, 660, 960, [[0, '#6878a8'], [0.4, '#4c5c94'], [1, '#485a96']]), 0.12, 0.08, 18, 1);
    const cushion = sm([[380, 600], [410, 556], [470, 528], [540, 524], [600, 546], [638, 590], [646, 650], [630, 712], [580, 754], [510, 766], [440, 754], [396, 716], [376, 660]]);
    R.dome(cushion, rad(520, 640, 150, [[0, '#94a0c8'], [0.7, '#7a88b4'], [1, '#5a6aa0']]), 0.2, 0.16, 40, 1);
    for (let i = 0; i < 9; i++) { const t = -0.3 + i * 0.42; R.groove(line([[510 + Math.cos(t + 1.6) * 90, 650 + Math.sin(t + 1.6) * 40], [510 + Math.cos(t + 1.6) * 125, 650 + Math.sin(t + 1.6) * 100]]), 4, '#dfe6ff', 0.34, 0.03, 1, 0.8); }
    const grille = ellipseP(508, 598, 80, 52, 0.12);
    R.flat(grille, '#18263a', 0.3, 2);
    for (let i = 0; i < 28; i++) { const t = i / 28 * Math.PI * 2; R.pipe(line([[508 + Math.cos(t) * 14, 598 + Math.sin(t) * 9], [508 + Math.cos(t + 0.25) * 72, 598 + Math.sin(t + 0.25) * 46]]), 4, '#8aa8c0', 0.32, 0.03, 2); }
    R.bead(508, 598, 12, '#2a3a50', 0.34, 0.04, 2);
    R.pipe(grille, 4, '#2a2420', 0.32, 0.04, 3);
    // black strap with holes on the drum
    const strap = sm([[322, 640], [340, 628], [366, 660], [380, 720], [410, 780], [440, 840], [450, 870], [430, 880], [400, 830], [360, 770], [334, 720], [320, 680]]);
    R.dome(strap, '#141c2a', 0.24, 0.06, 8, 2);
    for (const [x, y] of [[344, 652], [354, 700], [370, 740], [398, 790]]) fill(circleP(x, y, 5), '#050608');
    stroke(line([[440, 870], [500, 910], [560, 940], [600, 966]]), '#1a2030', 3);
    // ── leopard teddy ──
    const bear = new Path2D();
    bear.addPath(ellipseP(380, 466, 70, 56, 0));
    bear.addPath(ellipseP(428, 396, 20, 40, 0.5));
    bear.addPath(ellipseP(320, 420, 16, 26, -0.4));
    bear.addPath(sm([[328, 506], [420, 506], [430, 560], [410, 604], [350, 610], [330, 570]]));
    bear.addPath(sm([[292, 560], [320, 530], [344, 540], [330, 574], [300, 580]]));
    R.dome(bear, '#d07a28', 0.14, 0.14, 18, 4);
    clipA(bear, () => img(LEO));
    for (const [x, y] of [[352, 470], [410, 470]]) R.bead(x, y, 9, '#7ae0b8', 0.3, 0.06, 2);
    R.dome(ellipseP(382, 518, 14, 9, 0), '#7ae0b8', 0.3, 0.05, 6, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.5, ao: 0.3, rim: 0.5 }),                       // 1 lavender plastic
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.15 }),                              // 2 glossy
        E.mat({ dif: 0.7, metal: 0.5, spec: 0.9, shin: 40, rim: 0.3 }),                              // 3 chrome blades
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.5, ao: 0.4 })                                   // 4 fur
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.75, 0.75, 0.78], amb: [0.42, 0.42, 0.46],
      envTop: [0.95, 0.95, 1.0], envHor: [0.45, 0.45, 0.5], envBot: [0.05, 0.05, 0.08], envK: [0.2, 0.7, 0.4, 0],
      rimC: [0.6, 0.7, 1.0], rimD: [0.3, 0.4, 0.3], r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 70], shadow: [-3, 4, 0.4, 6]
    });
    // glowing white edges on the drum and strap
    const glow = (path, c, wd, px, al = 1) => { o.save(); o.globalAlpha = al; o.filter = `blur(${px * S}px)`; stroke(path, c, wd, o); o.restore(); };
    glow(drum, '#e8f0ff', 3, 1, 0.8); glow(cushion, '#e8f0ff', 3, 1.2, 0.7); glow(strap, '#c0e0ff', 2, 0.8, 0.8);
    E.bloom(0.12, 8);
    E.grain(0.035, 90);
  }
});
