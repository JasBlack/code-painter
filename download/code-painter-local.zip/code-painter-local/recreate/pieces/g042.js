'use strict';
// g042 — "Porcelain mask, zebra tongue": a pale-blue porcelain mask crowned with glossy petals, a grey stone
// hexagon pendant of enamel cells, gold ring eyes and a glowing red mouth spilling a wavy zebra cloth,
// over green / black / purple tiles on grey concrete with a gold-and-lime drip and a black fur creature.
REC.register('g042', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const rect = (x, y, w, h) => P([[x, y], [x + w, y], [x + w, y + h], [x, y + h]], true, false);
    const rr = rng(42);
    keep();
    // club-shaped petal: narrow at base (bx,by), round fat tip at (tx,ty)
    const club = (bx, by, tx, ty, wm, wb = 0.3) => {
      const L = Math.hypot(tx - bx, ty - by), ux = (tx - bx) / L, uy = (ty - by) / L, nx = -uy, ny = ux, Rr = wm / 2;
      const cx = tx - ux * Rr, cy = ty - uy * Rr, N = 14, pts = [];
      const side = (s, rev) => { for (let k = 0; k <= N; k++) { const i = rev ? N - k : k, t = i / N, d = t * (L - Rr), hw = Rr * (wb + (1 - wb) * Math.sin(t * Math.PI / 2));
        pts.push([bx + ux * d + s * nx * hw, by + uy * d + s * ny * hw]); } };
      side(1, false);
      for (let i = 1; i < N; i++) { const t = Math.PI / 2 - i / N * Math.PI; pts.push([cx + (ux * Math.cos(t) + nx * Math.sin(t)) * Rr, cy + (uy * Math.cos(t) + ny * Math.sin(t)) * Rr]); }
      side(-1, true);
      return P(pts, true, false);
    };

    // ── grey concrete ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.012), m = fbm(p * 0.05 + 3.1);
      vec3 c = vec3(.66, .655, .66) * (0.93 + 0.12 * n) + 0.03 * (m - .5);
      float sp = smoothstep(0.78, 0.86, vnoise(p * 0.22) * 0.6 + vnoise(p * 0.07) * 0.5);
      c = mix(c, vec3(.38, .36, .37), sp * 0.7);
      c *= 0.97 + 0.06 * hash(floor(p));
      return c; }`));
    // ── tile columns ──
    const GR = '#078812', BK = '#040404', PU = '#7b40e2';
    const tiles = [
      [18, -5, 120, 80, GR], [17, 74, 98, 71, BK], [0, 145, 135, 56, GR], [0, 201, 78, 65, PU], [0, 266, 140, 86, GR], [0, 351, 88, 76, BK],
      [0, 426, 125, 70, GR], [0, 496, 71, 89, PU], [70, 496, 75, 90, GR], [0, 585, 93, 103, GR], [93, 560, 98, 150, PU], [0, 688, 70, 77, BK],
      [70, 688, 72, 102, GR],
      [565, -5, 133, 811, GR], [627, 15, 50, 36, PU], [605, 55, 92, 57, BK], [600, 198, 97, 67, BK], [620, 394, 77, 71, BK], [606, 529, 101, 271, PU]];
    for (const [x, y, w, h, c] of tiles) R.flat(rect(x, y, w, h), c, 0.0, 0);
    // scuffs on purple tiles
    for (const [x, y, w, h] of [[0, 201, 78, 65], [0, 496, 71, 89], [93, 560, 98, 150], [606, 529, 101, 271]]) clipA(rect(x, y, w, h), () => {
      for (let i = 0; i < 40; i++) { a.strokeStyle = `rgba(40,20,60,${0.3 + rr() * 0.4})`; a.lineWidth = 0.6 + rr(); const px = x + rr() * w, py = y + rr() * h; a.beginPath(); a.moveTo(px, py); a.lineTo(px + (rr() - 0.5) * 8, py + (rr() - 0.5) * 8); a.stroke(); }
    });
    R.flat(P([[108, 600], [118, 596], [120, 610], [110, 612]]), '#2a9a20', 0.0, 0);

    // ── black fur creature (bottom right) ──
    const fur = P(ragged([[640, 782], [656, 772], [670, 786], [674, 820], [681, 860], [692, 900], [686, 940], [690, 980], [680, 1010], [640, 1030], [450, 1030], [471, 980],
      [493, 940], [504, 900], [540, 880], [583, 860], [633, 820], [636, 800]], 0, 18, 6, 4, 5));
    R.flat(fur, null, 0.02, 0);
    soft(x => { x.fillStyle = '#1a1818'; x.fill(fur); }, 2.5);
    clipA(fur, () => { for (let i = 0; i < 700; i++) { const x = 450 + rr() * 250, y = 770 + rr() * 260; a.strokeStyle = rr() < 0.5 ? 'rgba(110,100,96,0.6)' : 'rgba(40,36,36,0.8)'; a.lineWidth = 0.8 + rr() * 1.2;
      const ang = rr() * 6.28; a.beginPath(); a.moveTo(x, y); a.quadraticCurveTo(x + Math.cos(ang) * 6, y + Math.sin(ang) * 6, x + Math.cos(ang + 0.5) * 12, y + Math.sin(ang + 0.5) * 12); a.stroke(); } });
    R.flat(circleP(658, 790, 6), '#3a3634', 0.03, 0);

    // ── the porcelain mask ──
    const face = P([[150, 250], [128, 360], [121, 470], [132, 520], [155, 580], [178, 622], [198, 666], [230, 696], [330, 706], [470, 700], [530, 668], [558, 636],
      [588, 588], [608, 530], [619, 470], [624, 380], [614, 270], [580, 170], [480, 120], [380, 110], [280, 120], [190, 170]]);
    { const g = a.createLinearGradient(0, 110, 0, 700); g.addColorStop(0, '#8a90a6'); g.addColorStop(0.25, '#a8b4c8'); g.addColorStop(0.45, '#cadff2'); g.addColorStop(1, '#c2d8ee');
      R.dome(face, g, 0.05, 0.3, 110, 1); }
    // cheek bulbs
    R.dome(circleP(200, 515, 52), '#dcecf8', 0.24, 0.12, 52, 1);
    keep();
    R.dome(circleP(550, 492, 60), '#dcecf8', 0.24, 0.12, 60, 1);
    keep();

    // ── crown of petals ──
    const petals = [
      [350, -10, 300, 150, 56], [300, 30, 205, 190, 60], [430, -12, 490, 100, 54], [470, 10, 540, 130, 60], [520, 60, 562, 210, 58], [330, 70, 250, 200, 56],
      [500, 100, 600, 190, 56], [270, 60, 140, 118, 60], [450, 30, 600, 70, 56],
      [225, 110, 180, 238, 56], [235, 190, 62, 280, 66], [250, 165, 32, 190, 62], [290, 40, 95, 140, 64], [300, -15, 80, 72, 62],
      [560, 140, 606, 276, 56], [590, 160, 640, 332, 56], [540, 100, 708, 206, 66], [520, 50, 695, 132, 62], [480, 18, 665, 45, 60]];
    // draw back-to-front: centre petals first, outer ones on top
    for (const [bx, by, tx, ty, w] of petals) {
      const L = Math.hypot(tx - bx, ty - by), ang = Math.atan2(ty - by, tx - bx), f = 0.52;
      const p = ellipseP(bx + (tx - bx) * f, by + (ty - by) * f, L * 0.5, w * 0.5, ang);
      R.dome(p, '#a0bce2', 0.36, 0.16, w * 0.5, 1);
      keep();
    }
    keep();
    // cord and carabiner
    R.pipe(P([[372, -6], [380, 40], [392, 98]], false), 4, '#121212', 0.52, 0.03, 3);
    R.pipe(P([[426, -6], [446, 50], [462, 108], [470, 150]], false), 4, '#121212', 0.52, 0.03, 3);
    R.pipe(rrect(398, -10, 12, 104, 6), 4, '#d8dde0', 0.56, 0.05, 5);

    // ── hexagon stone pendant ──
    const hexPts = [[391, 100], [516, 182], [516, 284], [380, 386], [236, 304], [233, 206]];
    const hex = P(hexPts, true, false);
    R.dome(hex, '#dfe4dc', 0.56, 0.05, 6, 3);
    const hexIn = P([[391, 114], [504, 188], [504, 278], [380, 372], [248, 298], [245, 212]], true, false);
    R.flat(hexIn, '#727470', 0.58, 3);
    clipA(hexIn, () => { for (let i = 0; i < 4200; i++) { a.fillStyle = rr() < 0.55 ? 'rgba(20,20,20,0.75)' : 'rgba(235,238,232,0.6)'; a.fillRect(236 + rr() * 280, 100 + rr() * 286, 1.4, 1.4); } });
    const cells = [[330, 187, 32, 18, 0.05], [443, 171, 30, 16, 0.08], [486, 189, 22, 6, -0.1], [279, 214, 22, 7, -0.5], [332, 225, 32, 17, 0.0],
      [429, 214, 30, 16, -0.1], [275, 264, 21, 19, 0.4], [332, 271, 34, 14, -0.05], [425, 268, 30, 19, -0.3], [484, 246, 16, 19, 0.3], [430, 318, 14, 9, -0.6]];
    for (const [x, y, rx, ry, rt] of cells) { R.groove(ellipseP(x, y, rx + 3, ry + 3, rt), 5, '#2a2c2a', 0.6, 0.04, 3, 0.9); R.dome(ellipseP(x, y, rx, ry, rt), '#dfe4dc', 0.6, 0.06, Math.min(rx, ry) * 0.9, 4); }
    // the "I" bar with a loop, and a root net below
    R.dome(rrect(381, 158, 18, 72, 6), '#dfe4dc', 0.6, 0.06, 8, 4);
    R.flat(rrect(387, 166, 6, 30, 3), '#2a2c2a', 0.62, 3);
    const roots = [[[390, 230], [388, 252], [372, 262], [372, 280], [350, 290], [330, 300], [300, 304]], [[372, 280], [392, 286], [410, 300], [440, 306], [470, 296], [488, 286]],
      [[350, 290], [345, 314], [326, 326]], [[392, 286], [384, 310], [360, 318], [340, 340]], [[410, 300], [420, 324], [446, 330], [470, 320]], [[440, 306], [452, 290]],
      [[384, 310], [398, 336], [380, 346]], [[330, 300], [316, 320], [300, 322]], [[388, 252], [404, 262], [400, 280]]];
    for (const r of roots) { R.pipe(P(r, false), 8, '#2a2c2a', 0.6, 0.02, 3); R.pipe(P(r, false), 4.5, '#e0e6de', 0.62, 0.04, 4); }
    // lime flecks
    R.flat(P([[484, 296], [496, 288], [508, 292], [500, 306], [488, 306]]), '#a8e828', 0.64, 0);
    R.flat(P([[398, 352], [416, 340], [432, 344], [418, 360], [402, 364]]), '#a8e828', 0.64, 0);
    keep();

    // ── gold ring eyes ──
    for (const [x, y, rx, ry, hx, hy, hrx, hry] of [[182, 386, 68, 60, 164, 389, 18, 33], [546, 353, 68, 60, 552, 360, 18, 35]]) {
      const ring = new Path2D(); ring.addPath(ellipseP(x, y, rx, ry, 0.05)); ring.addPath(ellipseP(hx, hy, hrx, hry, 0.05));
      a.save(); a.fillStyle = '#eab444'; a.fill(ring, 'evenodd'); a.restore();
      R.h.save(); R.h.clip(ring, 'evenodd');
      R.dome(ellipseP(x, y, rx, ry, 0.05), null, 0.44, 0.1, 30, 2);
      R.h.restore();
      R.groove(ellipseP(hx, hy, hrx, hry, 0.05), 8, '#7a5010', 0.54, 0.06, 2, 0.6);
      // engraved squiggles around the rim
      for (let k = 0; k < 9; k++) { const t = k / 9 * 6.283 + 0.3, cx = x + Math.cos(t) * rx * 0.72, cy = y + Math.sin(t) * ry * 0.72;
        R.groove(P([[cx - 4, cy - 5], [cx + 2, cy - 1], [cx - 1, cy + 6]], false), 3.5, '#6a4008', 0.56, 0.04, 2, 0.8); }
    }
    keep();

    // ── red mouth pill ──
    const mouth = rrect(279, 400, 196, 46, 23);
    R.dome(mouth, '#d01208', 0.5, 0.05, 10, 7);
    clipA(mouth, () => { for (let i = 0; i < 90; i++) { a.fillStyle = rr() < 0.6 ? '#f8e040' : '#ffb030'; a.beginPath(); a.arc(285 + rr() * 186, 404 + rr() * 38, 0.8 + rr() * 2, 0, 6.283); a.fill(); } });

    // ── zebra cloth ──
    const zc = E.fx(`
      const float T[60] = float[60](
        270.,315.,360.,405.,  256.,309.,363.,412.,  231.,291.,352.,410.,  235.,290.,366.,445.,  225.,302.,405.,495.,
        231.,328.,424.,490.,  251.,341.,429.,518.,  276.,352.,460.,560.,  296.,368.,498.,590.,  302.,387.,513.,610.,
        293.,387.,506.,610.,  265.,370.,470.,570.,  258.,364.,460.,560.,  261.,343.,440.,540.,  265.,345.,440.,540.);
      float band(int r, int i){ return T[r * 4 + i]; }
      vec3 fx(vec2 uv, vec2 p){
        float fr = clamp((p.y - 460.) / 40., 0., 13.999);
        int r = int(floor(fr)); float t = fr - float(r); int r2 = min(r + 1, 14);
        float b0 = mix(band(r, 0), band(r2, 0), t), b1 = mix(band(r, 1), band(r2, 1), t), b2 = mix(band(r, 2), band(r2, 2), t), b3 = mix(band(r, 3), band(r2, 3), t);
        float u;
        if (p.x < b1) u = (p.x - b1) / (b1 - b0) + 1.;
        else if (p.x < b2) u = (p.x - b1) / (b2 - b1) + 1.;
        else u = (p.x - b2) / (b3 - b2) + 2.;
        float s = cos(6.2832 * u);
        float wv = smoothstep(0.08, 0.22, s);
        vec3 wh = vec3(.95, .94, .91) * (0.96 + 0.05 * vnoise(p * 0.6));
        return mix(vec3(.012), wh, wv);
      }`);
    const cloth = P([[300, 452], [450, 452], [443, 540], [467, 557], [527, 580], [550, 620], [518, 660], [535, 700], [552, 730], [567, 780], [575, 800], [570, 830],
      [550, 865], [479, 905], [443, 945], [350, 985], [280, 1030], [231, 1030], [229, 980], [226, 940], [229, 900], [243, 860], [262, 820], [262, 780], [233, 730],
      [211, 700], [199, 660], [213, 620], [228, 580], [251, 540], [267, 510], [280, 490]], true, true);
    R.flat(cloth, '#000', 0.08, 0);
    clipA(cloth, () => img(zc));
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.35)'; x.fill(P([[540, 590], [552, 625], [520, 660], [535, 700], [560, 760], [575, 800], [560, 840], [540, 800], [520, 720], [508, 660]])); }, 8, 1);

    // ── gold tube with lime core, black drip ──
    R.pipe(P([[116, 696], [140, 692], [162, 708], [176, 740], [186, 800], [188, 860], [184, 930], [176, 980], [168, 1030]], false), 34, '#f0c030', 0.2, 0.16, 6);
    R.pipe(P([[166, 730], [180, 780], [186, 850], [182, 930], [175, 990], [168, 1030]], false), 14, '#62c010', 0.34, 0.04, 0);
    R.flat(P(lock([[108, 738], [104, 780], [102, 820], [102, 860], [106, 900], [122, 940], [138, 980], [135, 1030]], 10, 6)), '#0a0a0a', 0.05, 0);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, spec: 0.8, shin: 40, wrap: 0.5, ao: 0.6, coat: 0.25, rim: 0.3 }),                           // 1 porcelain / petals
        E.mat({ dif: 0.7, metal: 0.55, spec: 1.3, shin: 45, ao: 0.5, tint: [1.2, 0.95, 0.5], rim: 0.3, emis: 0.12 }),  // 2 gold rings
        E.mat({ dif: 1, spec: 0.2, shin: 20, wrap: 0.3, ao: 0.7, grain: 0.15 }),                                      // 3 stone
        E.mat({ dif: 0.95, spec: 1.0, shin: 70, wrap: 0.3, ao: 0.5, coat: 0.3 }),                                     // 4 enamel cells
        E.mat({ dif: 0.4, metal: 0.9, spec: 1.4, shin: 80, ao: 0.3 }),                                                // 5 chrome clip
        E.mat({ dif: 0.7, metal: 0.55, spec: 1.5, shin: 70, ao: 0.4, tint: [1.25, 1.0, 0.4], coat: 0.2, emis: 0.15 }), // 6 gold tube
        E.mat({ dif: 0.6, emis: 0.6, spec: 0.8, shin: 40, wrap: 0.4 })                                               // 7 glowing mouth
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.82, 0.82, 0.86], amb: [0.38, 0.4, 0.44],
      envTop: [1.1, 1.1, 1.12], envHor: [0.62, 0.64, 0.7], envBot: [0.2, 0.22, 0.26], envK: [0.3, 1.1, 0.3, 0],
      rimC: [0.3, 0.35, 0.45], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-5, 7, 0.5, 6]
    });

    // ── mouth glow ──
    o.save(); { const hole = new Path2D(); hole.addPath(rrect(-10, -10, 746, 1044, 0)); hole.addPath(rrect(281, 402, 192, 42, 21)); o.clip(hole, 'evenodd'); }
    o.globalCompositeOperation = 'screen';
    o.filter = `blur(${10 * S}px)`; o.fillStyle = 'rgba(255,90,40,0.9)'; o.fill(rrect(266, 388, 222, 70, 35));
    o.filter = 'none';
    o.fillStyle = '#ffe890';
    for (let i = 0; i < 40; i++) { const t = i / 40 * 6.283, cx = 377 + Math.cos(t) * 104, cy = 423 + Math.sin(t) * 28, ox = Math.cos(t) * 12, oy = Math.sin(t) * 10;
      o.beginPath(); o.moveTo(cx - Math.sin(t) * 3, cy + Math.cos(t) * 3); o.lineTo(cx + ox, cy + oy); o.lineTo(cx + Math.sin(t) * 3, cy - Math.cos(t) * 3); o.fill(); }
    o.restore();
    o.save(); o.globalCompositeOperation = 'screen'; o.filter = `blur(${8 * S}px)`; o.fillStyle = 'rgba(255,40,20,0.7)';
    o.fill(P([[300, 450], [450, 450], [440, 490], [300, 490]])); o.restore();
    E.grain(0.025, 42);
  }
});
