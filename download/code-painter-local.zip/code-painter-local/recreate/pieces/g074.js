'use strict';
// g074 — "Tube-bearded goggle beast": a pale-blue clay creature with goggle eyes and a lilac swirl face sprays a
// beard of glossy blue tubes tipped with orange beads across a violet sky, wrapped by a black-and-white
// striped ribbon that sweeps from the top right down into black space.
REC.register('g074', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, st) => { const g = a.createRadialGradient(x, y, 0, x, y, r0); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const r = rng(74);

    // ── violet sky + black space (unlit) ──
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(0.39, 0.41, 0.73), vec3(0.32, 0.34, 0.69), smoothstep(0., 600., p.y + 0.3 * p.x));
      c = mix(c, vec3(0.30, 0.31, 0.62), smoothstep(700., 1000., p.y));
      return c; }`));
    R.flat(rrect(-10, -10, 746, 1044, 0), sky, 0, 0);
    a.fillStyle = '#ffffff';
    for (const [x, y, rr] of [[56, 20, 2], [52, 80, 1.5], [322, 120, 1.2], [282, 265, 1.8], [232, 303, 1.8], [548, 15, 1.2], [470, 60, 1], [140, 180, 1], [400, 30, 1]]) a.fill(circleP(x, y, rr));
    const outer = [[736, -10], [736, 320], [690, 345], [640, 420], [620, 500], [612, 600], [592, 690], [576, 745], [540, 800], [490, 860], [430, 920], [370, 975], [320, 1034]];
    R.flat(P([...outer, [736, 1034]], true, false), '#030304', 0, 0);

    // ── striped ribbon ──
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float t = smoothstep(300., 950., p.y);
      vec2 n = normalize(mix(vec2(0.70, -0.72), vec2(0.40, -0.92), t));
      float per = mix(36., 48., smoothstep(600., 1024., p.y));
      float ph = dot(p, n) / per + 0.25 * sin(p.y * 0.01 + p.x * 0.006);
      float f = fract(ph);
      vec3 wh = vec3(0.95, 0.95, 0.96), bk = vec3(0.04, 0.04, 0.045);
      return mix(bk, wh, smoothstep(0.47, 0.53, f) * smoothstep(1.0, 0.96, f) + smoothstep(0.04, 0.0, f)); }`));
    const band = P([[-10, 1034], [-10, 895], [150, 860], [300, 800], [400, 700], [420, 600], [430, 420], [440, 290], [480, 245], [530, 215], [565, 165], [595, 95], [640, 40], [682, -10], ...outer], true, true);
    R.dome(band, zeb, 0.04, 0.12, 60, 2);
    keep();

    // ── coral sponge behind the tubes ──
    const sponge = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){ float n = vnoise(p * 0.12), m = fbm(p * 0.03);
      vec3 c = mix(vec3(0.96, 0.38, 0.26), vec3(1.0, 0.52, 0.38), m);
      return mix(c, vec3(0.55, 0.12, 0.12), smoothstep(0.62, 0.72, n)); }`));
    for (const pts of [[[60, 610], [110, 600], [140, 620], [130, 660], [90, 676], [60, 660]], [[20, 735], [80, 728], [110, 750], [90, 785], [40, 790], [16, 770]], [[290, 580], [330, 590], [330, 620], [290, 620]]])
      R.dome(P(pts), sponge, 0.06, 0.05, 14, 4);
    keep();

    // ── creature: back body, horns ──
    const body = P([[560, 330], [620, 340], [660, 380], [680, 440], [690, 500], [700, 560], [640, 580], [560, 560], [520, 470], [530, 380]]);
    R.dome(body, '#88a6d8', 0.14, 0.12, 30, 1);
    const horn = [[640, 440], [660, 400], [676, 370], [692, 340], [702, 318]];
    R.pipe(P(horn, false), 22, '#78a4ec', 0.2, 0.08, 1);
    for (let i = 0; i < 9; i++) { const t = 0.15 + i * 0.09, k = Math.min(3, Math.floor(t * 4)), u = t * 4 - k, A = horn[k], B = horn[k + 1];
      R.pipe(P([[A[0] + (B[0] - A[0]) * u - 10, A[1] + (B[1] - A[1]) * u - 4], [A[0] + (B[0] - A[0]) * u + 10, A[1] + (B[1] - A[1]) * u + 4]], false), 4, '#a8c8f8', 0.3, 0.03, 1); }
    R.pipe(P([[650, 440], [690, 452], [736, 466]], false), 18, '#78a4ec', 0.2, 0.07, 1);
    for (let x = 664; x < 730; x += 9) R.pipe(P([[x, 436 + (x - 650) * 0.3], [x, 462 + (x - 650) * 0.3]], false), 3.5, '#a8c8f8', 0.28, 0.03, 1);
    // translucent bubble behind left eye
    soft(x => { x.fillStyle = 'rgba(190,190,240,0.55)'; x.fill(circleP(420, 268, 62)); }, 3, 0.8);
    keep();

    // ── tube beard ──
    const ends = [[290, 405], [343, 410], [240, 425], [193, 440], [252, 452], [273, 488], [318, 495], [186, 538], [105, 540], [142, 575], [352, 477], [392, 494], [305, 525], [268, 578],
      [212, 628], [70, 610], [230, 595], [-6, 655], [125, 698], [12, 700], [175, 710], [247, 710], [278, 735], [105, 762], [155, 760], [38, 800], [15, 840], [118, 852],
      [145, 828], [78, 882], [60, 925], [210, 855], [240, 840], [268, 810], [300, 760], [350, 760], [375, 845], [342, 898], [410, 830], [290, 890], [255, 960],
      [330, 445], [212, 482], [150, 505], [58, 562], [28, 604], [160, 652], [58, 662], [200, 676], [322, 622], [334, 688], [80, 732], [200, 782], [52, 770], [176, 800],
      [30, 880], [108, 912], [182, 896], [320, 818], [392, 782], [380, 560], [120, 470], [420, 900]];
    ends.sort((p, q) => (p[1] - p[0] * 0.3) - (q[1] - q[0] * 0.3));
    const tubeAlb = '#6f9ae6';
    for (const [ex, ey] of ends) {
      const ry = Math.max(470, Math.min(700, 470 + (ey - 400) * 0.45)), rx = 450 + r() * 30;
      const mx = (rx + ex) / 2 + (r() - 0.5) * 40, my = (ry + ey) / 2 + (r() - 0.5) * 30 - 10, wv = (r() - 0.5) * 30;
      const pts = [[rx, ry], [rx + (mx - rx) * 0.5, ry + (my - ry) * 0.5 + wv], [mx, my], [mx + (ex - mx) * 0.5, my + (ey - my) * 0.5 - wv], [ex, ey]];
      R.pipe(P(pts, false), 28, '#3a4a8a', 0.16, 0.02, 3);
      R.pipe(P(pts, false), 25, tubeAlb, 0.17, 0.11, 3);
      // printed text: faint dashes along the tube
      a.save(); a.setLineDash([2, 3, 4, 2, 1, 3]); a.lineWidth = 2.2; a.strokeStyle = 'rgba(30,50,110,0.45)';
      a.stroke(P([[rx + (mx - rx) * 0.3, ry + (my - ry) * 0.3 - 2], [mx, my - 2], [mx + (ex - mx) * 0.6, my + (ey - my) * 0.6 - 2]], false)); a.restore();
      R.bead(ex, ey, 15 + r() * 4, rad(ex - 5, ey - 6, 20, [[0, '#ffb08a'], [0.4, '#ff6a3c'], [1, '#d83a1c']]), 0.25, 0.12, 4);
      if (r() < 0.9) { const t = 0.3 + r() * 0.4, bx = (1 - t) * (1 - t) * rx + 2 * t * (1 - t) * mx + t * t * ex, by = (1 - t) * (1 - t) * ry + 2 * t * (1 - t) * my + t * t * ey;
        R.bead(bx + (r() - 0.5) * 10, by - 8, 11 + r() * 4, rad(bx - 5, by - 14, 18, [[0, '#ffb08a'], [0.4, '#ff6a3c'], [1, '#d83a1c']]), 0.3, 0.1, 4); }
    }
    keep();

    // ── face: lobes, swirl, brows, lower blob ──
    R.dome(ellipseP(560, 402, 42, 32, 0.1), '#8ca8d4', 0.24, 0.1, 22, 1);
    R.dome(ellipseP(472, 412, 52, 38, -0.1), '#8ca8d4', 0.24, 0.12, 26, 1);
    const swirl = ellipseP(532, 528, 112, 66, 0);
    R.dome(swirl, rad(532, 528, 112, [[0, '#d8c4ec'], [0.6, '#c6aedc'], [1, '#a88cc8']]), 0.2, 0.05, 20, 5);
    for (let k = 1; k <= 8; k++) R.groove(ellipseP(532 + k * 0.6, 528 + k * 0.4, 112 * k / 8.6, 66 * k / 8.6, 0.04 * k), 3, '#8a6aa8', 0.25, 0.025, 5, 0.6);
    R.dome(ellipseP(536, 530, 28, 17), '#cdb8e8', 0.25, 0.03, 8, 5);
    for (const pts of [[[445, 368], [470, 345], [500, 350], [506, 382]], [[500, 350], [530, 342], [548, 360]], [[506, 382], [520, 420], [540, 450], [566, 472]], [[470, 345], [456, 382], [446, 424]]])
      R.pipe(P(pts, false), 16, '#6c98e8', 0.32, 0.1, 1);
    const low = P([[430, 590], [470, 578], [540, 572], [620, 564], [680, 558], [712, 585], [716, 620], [700, 650], [672, 660], [650, 690], [610, 700], [570, 690], [530, 676], [480, 668], [440, 650], [425, 620]]);
    R.dome(low, rad(560, 610, 170, [[0, '#a2b6d4'], [0.7, '#8ea2c2'], [1, '#7a8eb0']]), 0.22, 0.1, 30, 1);
    R.dome(ellipseP(496, 608, 40, 15, -0.03), '#d8d4ee', 0.32, 0.05, 8, 2);
    R.groove(P([[470, 608], [520, 606]], false), 2.5, '#3a3a7a', 0.36, 0.01, 2);
    R.dome(ellipseP(618, 592, 22, 9, -0.2), '#d8d4ee', 0.32, 0.04, 6, 2);
    R.dome(ellipseP(664, 538, 26, 10, 0.25), '#f4a090', 0.3, 0.06, 8, 2);
    for (let i = 0; i < 14; i++) R.bead(450 + r() * 250, 590 + r() * 80, 1.5 + r() * 1.5, '#c8d4ec', 0.3, 0.02, 2);
    keep();
    // orange beads around the swirl
    for (const [x, y, rr] of [[455, 490, 15], [470, 520, 13], [442, 548, 12], [392, 592, 14], [388, 632, 15], [420, 660, 14], [455, 662, 15], [440, 692, 14], [480, 690, 14], [510, 684, 13],
      [474, 716, 12], [360, 620, 16], [352, 660, 14], [400, 700, 15], [430, 728, 13], [372, 700, 13], [330, 740, 14], [500, 712, 13], [420, 596, 13], [310, 690, 13], [346, 590, 12],
      [380, 540, 13], [404, 560, 12], [300, 650, 12], [268, 700, 13], [452, 740, 12], [604, 470, 10], [622, 452, 9], [580, 482, 10], [610, 520, 10], [628, 498, 9], [604, 568, 11], [630, 562, 12], [590, 540, 9], [420, 520, 12], [462, 455, 9]])
      R.bead(x, y, rr, rad(x - 4, y - 5, rr * 1.4, [[0, '#ffb08a'], [0.4, '#ff6a3c'], [1, '#d83a1c']]), 0.32, 0.1, 4);
    keep();

    // ── goggle eyes ──
    for (const [x, y, rr, ix, iy] of [[412, 330, 50, 420, 332], [585, 322, 50, 588, 322]]) {
      R.dome(circleP(x, y, rr), rad(x - 18, y - 18, rr * 1.6, [[0, '#c4d4ee'], [0.5, '#98acd0'], [1, '#6a7ea8']]), 0.3, 0.22, rr, 1);
      R.dome(circleP(ix, iy, 29), rad(ix - 6, iy - 8, 34, [[0, '#d4bcf0'], [0.6, '#a684d0'], [1, '#7a5aa8']]), 0.5, 0.05, 10, 2);
      for (let k = 0; k < 9; k++) { const t = -2.6 + k * 0.32; R.groove(P([[ix + Math.cos(t) * 15, iy + Math.sin(t) * 15], [ix + Math.cos(t) * 22, iy + Math.sin(t) * 22]], false), 3, '#2a1a40', 0.56, 0.02, 2, 1); }
      R.bead(ix - 2, iy + 2, x < 500 ? 9 : 5, x < 500 ? '#ff6a3c' : '#f07090', 0.55, 0.04, 4);
    }
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.35, ao: 0.4, coat: 0.12, rim: 0.3 }),   // 1 blue clay
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.3, ao: 0.4, coat: 0.15 }),             // 2 striped satin
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, ao: 0.5, coat: 0.2, rim: 0.3 }),     // 3 blue tubes
        E.mat({ dif: 1, spec: 1.3, shin: 80, wrap: 0.2, coat: 0.25, ao: 0.3 }),             // 4 orange beads / sponge
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.4, ao: 0.6 }),                        // 5 lilac swirl
      ],
      light: [-0.5, 0.55, 0.66], lc: [0.88, 0.87, 0.86], amb: [0.36, 0.36, 0.39],
      envTop: [0.95, 0.95, 1.0], envHor: [0.5, 0.5, 0.56], envBot: [0.06, 0.06, 0.1], envK: [0.2, 0.9, 0.3, 0],
      rimC: [0.3, 0.35, 0.6], rimD: [0.3, 0.6, 0.3], l2: [0.8, -0.3, 0.5, 8], l2c: [0.25, 0.3, 0.6],
      r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 60], shadow: [-5, 7, 0.5, 6]
    });
    E.bloom(0.06, 10);
    E.grain(0.025, 4);
  }
});
