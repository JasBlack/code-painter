'use strict';
// g006 — "Enamel gadget board": a lavender gear-edged board on pastel fabric, holding a zebra swirl,
// a chrome spiral disc, a dotted lime pear, an orange-piped brown face plate, a polka-dot ball and grey bars.
REC.register('g006', {
  w: 701, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipBoth = (path, fn) => { a.save(); hx.save(); a.clip(path); hx.clip(path); fn(); a.restore(); hx.restore(); };
    const sparkle = (path, n, seed, col, rmax = 0.9, box = [0, 0, 701, 1024]) => { a.save(); a.clip(path); const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.25 + r() * 0.6; a.beginPath(); a.arc(box[0] + r() * box[2], box[1] + r() * box[3], 0.3 + r() * rmax, 0, 6.283); a.fill(); }
      a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // gear-tooth outline along a polyline (open) or polygon
    const gear = (pts, step, amp, open = false) => {
      const out = [], n = pts.length;
      for (let i = 0; i < (open ? n - 1 : n); i++) {
        const p0 = pts[i], p1 = pts[(i + 1) % n], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), k = Math.max(1, Math.round(L / step));
        const nx = (p1[1] - p0[1]) / L, ny = -(p1[0] - p0[0]) / L;
        for (let j = 0; j < k; j++) { const u = j / k, d = (j % 2 ? amp : 0); out.push([p0[0] + (p1[0] - p0[0]) * u + nx * d, p0[1] + (p1[1] - p0[1]) * u + ny * d]); }
      }
      return out;
    };
    const gearCircle = (cx, cy, rx, ry, teeth, amp) => { const pts = []; for (let i = 0; i < teeth * 2; i++) { const t = i / (teeth * 2) * 6.2832, k = i % 2 ? 1 : 1 + amp; pts.push([cx + Math.cos(t) * rx * k, cy + Math.sin(t) * ry * k]); } return P(pts, true, false); };
    const PURP = '#71609a';

    // ── pastel fabric on the left (soft, out of focus) ──
    R.flat(rrect(-10, -10, 721, 1044, 0), '#2a1c14', 0, 0);
    soft(x => {
      const F = (c, pts) => { x.fillStyle = c; x.fill(P(pts)); };
      F('#e6dc9c', [[66, -10], [116, -10], [84, 70], [54, 130], [36, 190], [22, 250], [8, 310], [-10, 330], [-10, 280], [4, 250], [18, 190], [30, 130], [48, 70]]);
      F('#ecdf9e', [[-10, 700], [30, 710], [60, 760], [76, 790], [84, 850], [92, 910], [104, 970], [110, 1034], [44, 1034], [42, 970], [40, 910], [36, 850], [-10, 840]]);
      F('#e8eeec', [[158, -10], [300, -10], [275, 25], [240, 70], [200, 108], [160, 140], [128, 178], [106, 225], [92, 290], [78, 370], [68, 450], [66, 520], [74, 620], [104, 720], [150, 800], [130, 850], [100, 780], [60, 760], [40, 740], [10, 680], [20, 650], [36, 610], [36, 490], [32, 430], [38, 370], [44, 310], [66, 250], [102, 190], [114, 130], [126, 70]]);
      F('#b2cece', [[116, -10], [158, -10], [126, 70], [114, 130], [102, 190], [66, 250], [44, 310], [38, 370], [32, 430], [36, 490], [36, 610], [20, 650], [-10, 650], [-10, 490], [6, 430], [8, 370], [10, 310], [22, 250], [36, 190], [54, 130], [84, 70]]);
      F('#b4d0d0', [[60, 760], [100, 770], [120, 820], [130, 850], [168, 910], [180, 970], [198, 1034], [110, 1034], [104, 970], [92, 910], [84, 850], [76, 790]]);
      x.fillStyle = 'rgba(120,130,135,0.5)'; x.fill(ellipseP(180, 50, 30, 26, 0));
      x.fillStyle = 'rgba(70,60,40,0.7)'; x.fill(P([[84, 60], [96, 64], [70, 140], [56, 150]]));
      x.fillStyle = '#ffa058'; x.fill(ellipseP(14, 800, 26, 70, 0));
      F('#120806', [[-10, 850], [20, 856], [40, 910], [42, 1034], [-10, 1034]]);
    }, 3);

    // ── lavender board with gear-tooth edge ──
    const boardEdge = [[300, -20], [275, 25], [240, 70], [200, 108], [160, 140], [128, 178], [106, 225], [92, 290], [78, 370], [68, 450], [66, 520], [74, 620], [104, 720], [150, 800], [180, 890], [194, 1044]];
    const board = P([...gear(boardEdge, 9, 9, true), [194, 1044], [721, 1044], [721, -20]], true, false);
    R.flat(board, PURP, 0.03, 6);
    sparkle(board, 12000, 3, '#4a3a70', 1.0);
    sparkle(board, 6000, 4, '#c8bce6', 0.7);

    // ── peach field ──
    const peach = P([[290, 170], [330, 150], [540, 200], [640, 226], [656, 330], [612, 380], [600, 470], [480, 480], [462, 700], [440, 784], [350, 806], [180, 806], [130, 770], [140, 700], [200, 470], [240, 300], [260, 215]]);
    R.flat(peach, '#eaa696', 0.05, 1);
    soft(x => { x.fillStyle = '#c87868'; x.fill(ellipseP(390, 730, 70, 40, 0)); x.fill(ellipseP(160, 780, 40, 20, 0)); x.fillStyle = '#f6bcac'; x.fill(ellipseP(520, 380, 70, 60, 0)); }, 20, 0.6);
    R.flat(P([[600, 440], [721, 400], [721, 520], [640, 540]]), '#e0a090', 0.05, 1);

    // ── zebra swirl (black enamel ridges on white) ──
    const zeb = P([[290, -20], [460, -20], [455, 20], [400, 50], [340, 90], [305, 140], [290, 175], [250, 215], [222, 300], [208, 380], [190, 440], [110, 480], [88, 440], [92, 360], [104, 290], [118, 225], [136, 185], [166, 150], [205, 118], [245, 80], [275, 40]]);
    R.dome(zeb, '#eeeeec', 0.06, 0.06, 10, 2);
    clipBoth(zeb, () => {
      const zr = rng(11);
      for (let k = 0; k < 9; k++) {
        const r0 = 318 + k * 19.5 + (zr() - 0.5) * 4, pts = [];
        for (let t = 0; t <= 48; t++) { const ang = 3.1 + t / 48 * 1.9, rr = r0 + 4 * Math.sin(ang * 6 + k) + 3 * Math.sin(ang * 13 + k * 2); pts.push([520 + Math.cos(ang) * rr, 420 + Math.sin(ang) * rr]); }
        R.pipe(P(pts, false), 7 + zr() * 8, '#16171c', 0.1, 0.07, 2);
      }
    });

    // ── spiral disc (white enamel with black spiral grooves) ──
    const sdC = [425, 188];
    R.flat(gearCircle(sdC[0], sdC[1], 118, 112, 36, 0.06), PURP, 0.05, 6);
    R.dome(ellipseP(sdC[0], sdC[1], 102, 96, 0), '#e8eaee', 0.08, 0.08, 12, 2);
    { const pts = []; for (let t = 0; t < 14 * 6.2832; t += 0.08) { const rr = 3 + t / 6.2832 * 6.6; pts.push([sdC[0] + 10 - rr * 0.1 + Math.cos(t) * rr, sdC[1] + 4 - rr * 0.04 + Math.sin(t) * rr * 0.96]); }
      R.pipe(P(pts, false, false), 3.6, '#121216', 0.13, 0.03, 2); }
    R.pipe(ellipseP(sdC[0], sdC[1], 99, 93, 0), 5, '#16161a', 0.12, 0.04, 2);

    // ── lime pear with silver dots ──
    const pear = P([[462, 140], [500, 110], [560, 96], [606, 74], [640, 46], [662, 56], [664, 100], [644, 150], [614, 200], [572, 238], [520, 248], [478, 232], [458, 190]]);
    R.dome(pear, '#b0bc68', 0.1, 0.22, 44, 2);
    { const pr = rng(21); a.save(); a.clip(pear);
      for (let i = 0; i < 90; i++) { const x = 460 + pr() * 205, y = 48 + pr() * 200; if (!a.isPointInPath(pear, x * S, y * S)) continue; R.bead(x, y, 1.4 + pr() * 1.8, '#e0e2e6', 0.3, 0.05, 3); }
      a.restore(); }

    // ── batteries / caps ──
    R.pipe(P([[350, 14], [440, 22]], false), 22, '#f0f0f0', 0.08, 0.1, 2);
    R.pipe(P([[452, 14], [566, 10]], false), 34, '#141418', 0.12, 0.14, 2);
    R.pipe(P([[470, 13], [546, 11]], false), 32, '#d8a830', 0.12, 0.14, 3);
    R.pipe(P([[478, 13], [486, 13]], false), 32, '#3a7ad0', 0.12, 0.14, 2);
    R.pipe(P([[700, 206], [656, 318]], false), 50, '#16161a', 0.12, 0.14, 2);
    R.pipe(P([[688, 240], [672, 280]], false), 48, '#e0a020', 0.12, 0.14, 3);
    R.pipe(P([[694, 224], [690, 234]], false), 48, '#3a78c8', 0.12, 0.14, 2);
    R.bead(692, 44, 22, '#141418', 0.1, 0.12, 2);
    R.bead(608, 6, 12, '#f0f0f0', 0.08, 0.08, 2);

    // ── dark grey bar (top right) ──
    const bar1 = P([[690, 136], [721, 136], [721, 190], [570, 362], [536, 354], [530, 334]], true, false);
    R.dome(bar1, '#424244', 0.1, 0.06, 5, 4);
    R.bead(560, 328, 4, '#101012', 0.17, 0.02, 4);

    // ── purple gear scallops ──
    R.flat(gearCircle(668, 440, 80, 112, 22, 0.08), PURP, 0.05, 6);
    R.flat(gearCircle(565, 598, 140, 108, 30, 0.06), PURP, 0.05, 6);
    R.flat(gearCircle(372, 440, 60, 50, 16, 0.1), PURP, 0.05, 6);
    const wsq = (pts, w) => { R.pipe(P(pts, false), w + 6, '#18161c', 0.08, 0.1, 2); R.pipe(P(pts, false), w, '#f4f2f0', 0.12, 0.1, 2); };
    wsq([[721, 380], [680, 370], [640, 380], [620, 410], [640, 440], [680, 446], [700, 470], [680, 500], [650, 510], [660, 540], [700, 548], [721, 540]], 18);
    wsq([[721, 420], [700, 410], [672, 416]], 14);

    // ── green dots, button, pyramids ──
    const gdot = (x, y, r) => { R.bead(x, y, r + 3, '#202018', 0.08, 0.04, 2); R.dome(circleP(x, y, r), '#c8d47e', 0.12, 0.06, r * 0.5, 2); };
    gdot(270, 228, 17); gdot(287, 294, 23); gdot(385, 357, 21);
    R.bead(286, 365, 30, '#283848', 0.08, 0.12, 3);
    R.dome(circleP(286, 365, 23), '#6a8aa8', 0.15, 0.08, 6, 3);
    R.bead(286, 364, 10, '#101418', 0.2, 0.06, 2);
    const pyr = pts => R.dome(P(pts, true, false), '#3a5272', 0.08, 0.22, 30, 3);
    pyr([[196, 278], [246, 274], [222, 326]]);
    pyr([[348, 318], [378, 316], [362, 292]]);
    pyr([[428, 314], [506, 318], [466, 384]]);
    pyr([[468, 462], [550, 464], [508, 396]]);
    R.bead(430, 410, 7, '#d8d8dc', 0.1, 0.1, 3);

    // ── brown face plate ──
    const plate = P([[200, 450], [260, 420], [330, 410], [400, 430], [430, 490], [440, 560], [430, 640], [400, 700], [340, 740], [270, 752], [190, 745], [130, 720], [106, 660], [102, 580], [114, 520], [150, 470]]);
    R.dome(plate, '#6a5444', 0.08, 0.1, 12, 1);
    soft(x => { x.fillStyle = '#80644e'; x.fill(ellipseP(230, 600, 70, 60, 0)); }, 16, 0.45);
    R.dome(P([[98, 540], [142, 528], [152, 560], [142, 640], [112, 652], [94, 620]]), '#d4d8da', 0.14, 0.06, 5, 3);
    const spiral = (cx, cy, r, turns) => { R.dome(circleP(cx, cy, r), '#e0e0e2', 0.14, 0.04, 4, 2); const pts = []; for (let t = 0; t < turns * 6.2832; t += 0.1) { const rr = 2 + t / 6.2832 * (r - 4) / turns; pts.push([cx + Math.cos(t) * rr, cy + Math.sin(t) * rr]); } R.pipe(P(pts, false, false), 2.6, '#18181a', 0.18, 0.02, 2); };
    spiral(345, 455, 30, 6); spiral(150, 690, 28, 6); spiral(240, 690, 28, 6);
    // gadget block (grey chrome)
    const gad = P([[122, 418], [210, 394], [262, 400], [272, 440], [250, 470], [216, 480], [140, 490], [116, 470]], true, false);
    R.dome(gad, '#c0c4c8', 0.16, 0.08, 6, 3);
    R.groove(circleP(166, 432, 8), 6, '#202024', 0.24, 0.1, 2);
    R.groove(circleP(196, 432, 6), 5, '#202024', 0.24, 0.1, 2);
    R.bead(232, 458, 14, '#2a2c30', 0.24, 0.06, 3); R.bead(232, 458, 6, '#a0a4a8', 0.3, 0.04, 3);
    // yellow hair squiggle and pink zigzags
    { const pts = []; for (let i = 0; i <= 22; i++) { const x = 154 + i * 5.8; pts.push([x, 556 - Math.sin(i / 22 * 3.14) * 18 + (i % 2 ? -9 : 6)]); } R.pipe(P(pts, false), 10, '#e4dc3c', 0.16, 0.06, 2); }
    { const pts = []; for (let i = 0; i <= 16; i++) pts.push([178 + i * 6.5, 618 - i * 1.6 + (i % 2 ? -9 : 6)]); R.pipe(P(pts, false, false), 10, '#e8649c', 0.16, 0.06, 2); }
    { const pts = []; for (let i = 0; i <= 16; i++) pts.push([176 + i * 6.5, 642 - i * 1.6 + (i % 2 ? -9 : 6)]); R.pipe(P(pts, false, false), 10, '#e8649c', 0.16, 0.06, 2); }
    R.groove(P([[168, 592], [200, 584], [232, 594]], false), 4, '#2a1a10', 0.18, 0.05, 1);
    R.groove(P([[250, 480], [280, 470], [300, 490], [280, 506], [256, 500]], true), 4, '#2a1a10', 0.18, 0.05, 1);
    R.groove(P([[300, 470], [320, 500], [306, 520]], false), 4, '#2a1a10', 0.18, 0.05, 1);
    // orange piping
    const OR = '#f89a28';
    const opipe = (pts, w) => R.pipe(P(pts, false), w, OR, 0.18, 0.1, 2);
    opipe([[330, 386], [348, 400], [380, 420], [412, 440], [428, 480], [432, 540], [430, 600], [416, 660], [390, 700], [350, 720], [300, 724], [270, 716]], 18);
    R.dome(P(blob(340, 392, 24, 18, 5, 10, 0.2)), OR, 0.18, 0.1, 8, 2);
    opipe([[270, 716], [240, 730], [200, 736], [176, 740], [156, 752], [146, 772]], 16);
    R.pipe(circleP(150, 690, 35), 14, OR, 0.18, 0.08, 2);
    R.pipe(circleP(240, 690, 35), 14, OR, 0.18, 0.08, 2);
    opipe([[184, 688], [206, 688]], 12);
    opipe([[116, 690], [108, 704], [112, 730]], 12);
    for (let i = 0; i < 5; i++) { opipe([[284, 572 + i * 25], [372, 566 + i * 25]], 10); opipe([[290 + i * 19, 558], [296 + i * 19, 676]], 9); }
    opipe([[300, 692], [340, 704]], 10); opipe([[284, 560], [300, 540]], 10);
    // chrome pearl
    R.bead(356, 536, 50, '#1a1a1e', 0.18, 0.08, 2);
    R.bead(356, 536, 40, '#3a3c42', 0.22, 0.06, 3);
    R.bead(356, 536, 32, '#d8dce2', 0.26, 0.2, 3);
    // black heart
    R.dome(P([[336, 782], [306, 754], [304, 732], [322, 724], [336, 736], [352, 724], [370, 732], [368, 754]]), '#08080c', 0.12, 0.12, 12, 2);

    // ── copper braid ──
    const braid = (pts, w) => {
      R.pipe(P(pts, false), w, '#c87848', 0.2, 0.08, 5);
      const pp = P(pts, false); a.save(); a.setLineDash([3, 3]); a.lineWidth = w * 0.7; a.strokeStyle = '#7a3a1c'; a.stroke(pp); a.restore();
    };
    braid([[136, 494], [96, 516], [62, 562], [46, 630], [52, 696], [80, 748], [120, 788], [168, 816], [206, 830], [224, 856], [216, 880], [182, 888], [134, 882], [98, 862]], 12);
    braid([[148, 506], [120, 540], [100, 600], [98, 660], [112, 712], [148, 750], [186, 786], [208, 812]], 11);
    R.dome(rrect(118, 482, 38, 38, 6), '#c07038', 0.24, 0.06, 4, 5);
    R.dome(rrect(198, 812, 34, 36, 6), '#c07038', 0.24, 0.06, 4, 5);

    // ── cream dotted oval with a lime cap ──
    const cap = P([[490, 540], [520, 506], [580, 498], [630, 512], [648, 556], [600, 560], [540, 560]]);
    R.dome(cap, '#b8c870', 0.14, 0.08, 14, 2);
    const oval = P([[450, 580], [470, 540], [520, 530], [600, 548], [660, 570], [682, 620], [668, 668], [620, 690], [540, 680], [470, 650], [446, 614]]);
    R.dome(oval, '#ece2d0', 0.14, 0.14, 22, 2);
    { const dr = rng(31); a.save(); a.clip(oval);
      for (let i = 0; i < 46; i++) { const x = 455 + dr() * 225, y = 540 + dr() * 145; if (!a.isPointInPath(oval, x * S, y * S)) continue; const r = 4 + dr() * 7; R.bead(x, y, r, '#141418', 0.28, 0.06 + r * 0.008, 2); }
      a.restore(); }

    // ── black cassette ──
    { const cv = new DOMMatrix().translate(536, 724).rotate(17);
      const tp = pts => pts.map(([x, y]) => { const q = cv.transformPoint({ x, y }); return [q.x, q.y]; });
      R.dome(P(tp([[-98, -33], [98, -33], [98, 33], [-98, 33]]), true, false), '#121216', 0.1, 0.08, 4, 2);
      R.dome(P(tp([[-88, -23], [88, -23], [88, 23], [-88, 23]]), true, false), '#1c1c22', 0.14, 0.02, 2, 4);
      const cr = rng(41);
      for (let i = 0; i < 9; i++) { const x = -80 + cr() * 150, y = -18 + cr() * 26, w = 10 + cr() * 30, h = 6 + cr() * 12; R.groove(P(tp([[x, y], [x + w, y], [x + w, y + h], [x, y + h]]), true, false), 3, '#0a0a0c', 0.16, 0.04, 4); }
      R.bead(...tp([[50, 4]])[0], 9, '#d8907a', 0.12, 0.02, 1); }

    // ── grey frame bars (bottom right) ──
    const arm = P([[386, 742], [396, 735], [592, 784], [560, 832], [530, 832], [392, 800], [384, 790]], true, false);
    const diag = P([[530, 830], [590, 786], [721, 702], [721, 718], [408, 1044], [352, 1044]], true, false);
    R.dome(diag, '#424244', 0.1, 0.06, 5, 4);
    R.dome(arm, '#4a4a4c', 0.1, 0.06, 5, 4);
    R.bead(462, 848, 18, '#141414', 0.1, 0.04, 2); R.bead(462, 846, 13, '#f4f4f4', 0.14, 0.08, 2);
    wsq([[555, 1044], [548, 980], [545, 920], [560, 880], [600, 858], [630, 870], [640, 910], [625, 960], [640, 990], [680, 985], [700, 960]], 26);
    wsq([[721, 850], [700, 860], [690, 900], [700, 940], [721, 945]], 22);
    wsq([[440, 1044], [470, 1015], [510, 1005], [540, 1020]], 22);
    R.pipe(P([[721, 800], [690, 830], [660, 860], [650, 900]], false), 22, '#1e1e24', 0.14, 0.12, 3);

    // ── polka-dot ball ──
    const ball = circleP(328, 910, 116);
    R.dome(ball, '#56442f', 0.1, 0.34, 100, 2);
    { const br = rng(51); clipBoth(ball, () => {
      for (let la = -80; la <= 80; la += 14) { const cl = Math.cos(la * Math.PI / 180), n = Math.max(1, Math.round(25 * cl)), off = br() * 6.28;
        for (let j = 0; j < n; j++) { const lo = off + j / n * 6.2832, sx = Math.sin(lo), cz = Math.cos(lo); if (cz < 0.05) continue;
          const z = cl * cz, x = 328 + 116 * cl * sx, y = 910 - 116 * Math.sin(la * Math.PI / 180) * 0.97 - 8 * z, r = 8.5 + br() * 3.5;
          const nx = x - 328, ny = y - 910, rot = Math.atan2(ny, nx), k = Math.max(0.25, Math.sqrt(Math.max(0, 1 - (nx * nx + ny * ny) / 13456)));
          R.dome(ellipseP(x, y, r * k, r, rot), '#d2d696', 0.12 + 0.3 * k, 0.04, 3, 2); } }
    }); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.5, ao: 0.5 }),                                     // 1 matte paint
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, ao: 0.5, coat: 0.12, rim: 0.2 }),                  // 2 gloss enamel
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.2, shin: 60, ao: 0.4, rim: 0.3 }),                           // 3 chrome
        E.mat({ dif: 1, spec: 0.35, shin: 18, wrap: 0.3, ao: 0.4 }),                                       // 4 grey plastic
        E.mat({ dif: 0.8, metal: 0.3, spec: 0.8, shin: 30, ao: 0.5, tint: [1.1, 0.8, 0.6] }),             // 5 copper / leather
        E.mat({ dif: 1, spec: 0.08, shin: 10, wrap: 0.5, grain: 0.3, ao: 0.5 })                            // 6 purple felt
      ],
      light: [-0.55, 0.6, 0.6], lc: [1.0, 0.98, 0.94], amb: [0.34, 0.33, 0.36],
      envTop: [1.1, 1.08, 1.05], envHor: [0.55, 0.52, 0.56], envBot: [0.1, 0.08, 0.1], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.2, 0.2, 0.25], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 120], shadow: [-7, 9, 0.7, 7]
    });
    E.bloom(0.1, 10);
    E.grain(0.03, 7);
  }
});
