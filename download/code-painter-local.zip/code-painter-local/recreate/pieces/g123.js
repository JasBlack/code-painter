'use strict';
// g123 — "Fingerprint chrome dreamer": a peach face with a yellow-blue eye under a huge zebra fingerprint whorl,
// chrome bubble clusters, a cream hexagon frame holding three silver spiral discs, an orange tube and a pink zigzag on a lavender moon.
REC.register('g123', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const imgH = (cv, path) => { R.h.save(); R.h.clip(path); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(cv, 0, 0); R.h.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H], al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const poly = pts => P(pts, true, false);
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    // GLSL helper: encode height h (0..1) + material m as the relief height colour
    const HC = `vec3 hc(float h, float m){ float v = clamp(h, 0., 1.) * 255.; float i = floor(v); return vec3(i / 255., m * 32. / 255., v - i); }`;

    // ── black field + lavender moon ──
    R.flat(all, '#0e0e0e', 0, 0);
    const moon = circleP(386, 583, 587);
    R.flat(moon, radg(330, 80, 60, 700, [[0, '#9a92fa'], [0.45, '#8a84ee'], [0.8, '#5c5cc4'], [1, '#4a4fa8']]), 0.01, 0);
    R.flat(poly([[200, 330], [430, 340], [560, 480], [640, 500], [640, 560], [600, 560], [600, 900], [520, 940], [470, 1034], [200, 1034]]), '#0b0b0c', 0.015, 0);
    // white arc + dark band (top-left)
    R.flat(P([[-10, 160], [40, 150], [110, 120], [180, 100], [230, 92], [230, 140], [100, 200], [-10, 250]], true, true), '#262626', 0.02, 0);
    R.pipe(P([[-10, 182], [50, 146], [120, 112], [190, 88], [262, 72]], false), 24, '#f8f8f6', 0.03, 0.03, 1);

    // ── zebra fingerprint whorl ──
    const fp = P([[214, 300], [208, 240], [214, 180], [228, 128], [256, 86], [300, 58], [370, 40], [450, 34], [530, 40], [592, 60], [642, 98], [680, 148], [702, 206], [714, 268],
      [716, 330], [706, 390], [690, 436], [660, 470], [606, 492], [560, 474], [500, 420], [430, 380], [380, 352], [320, 336]]);
    const fpH = E.fx(HC + `
      vec3 fx(vec2 uv, vec2 p){
        vec2 c = vec2(462., 206.); vec2 d = p - c;
        float r = length(d * vec2(1., 1.08)), th = atan(d.y, d.x);
        float cz = smoothstep(62., 80., r); float f = mix(r / 8.5 - th / 6.2832, r / 16. + 2.2 * vnoise(p * 0.009) + 0.8 * vnoise(p * 0.028 + 7.) * smoothstep(60., 160., r) + 0.45 * sin(th * 3. + r * 0.01), cz);
        float s = abs(fract(f) - .5) * 2.;
        float ridge = smoothstep(0.25, 0.6, s) * mix(0.5, 1., cz);
        return hc(0.16 + 0.07 * ridge, 3.); }`);
    const fpA = E.fx(`vec3 fx(vec2 uv, vec2 p){
        vec2 c = vec2(462., 206.); vec2 d = p - c;
        float r = length(d * vec2(1., 1.08)), th = atan(d.y, d.x);
        float cz = smoothstep(62., 80., r); float f = mix(r / 8.5 - th / 6.2832, r / 16. + 2.2 * vnoise(p * 0.009) + 0.8 * vnoise(p * 0.028 + 7.) * smoothstep(60., 160., r) + 0.45 * sin(th * 3. + r * 0.01), cz);
        float s = abs(fract(f) - .5) * 2.;
        float w = smoothstep(mix(0.5, 0.22, cz), mix(0.62, 0.34, cz), s);
        vec3 wc = mix(vec3(.82,.82,.86), vec3(1.), smoothstep(0.4, 0.9, s));
        return mix(mix(vec3(.55,.55,.6), vec3(.03), cz), wc, w); }`);
    R.dome(fp, '#e8e8ea', 0.1, 0.06, 12, 3);
    clipA(fp, () => img(fpA));
    { const inner = P([[226, 290], [222, 240], [228, 186], [242, 140], [266, 102], [306, 74], [372, 56], [450, 50], [526, 56], [584, 74], [628, 108], [664, 154], [684, 208], [696, 268],
      [698, 328], [690, 384], [674, 426], [648, 456], [606, 474], [560, 458], [500, 404], [430, 366], [380, 340], [320, 326]]);
      imgH(fpH, inner); }
    R.pipe(P([[250, 66], [320, 48], [400, 40], [470, 42], [540, 50], [580, 62]], false), 10, '#38b8e0', 0.24, 0.04, 2);

    // ── orange cap + peach face with the eye ──
    R.flat(poly([[-10, 150], [60, 140], [60, 250], [-10, 250]]), '#2a2a2a', 0.04, 0);
    R.flat(P([[46, 252], [48, 180], [84, 144], [150, 118], [226, 100], [238, 140], [214, 186], [186, 214], [120, 236]], true, true), '#f27a1a', 0.05, 1);
    R.flat(ellipseP(112, 172, 44, 14, -0.38), '#2448d0', 0.055, 1);
    const skin = P([[-10, 238], [40, 232], [100, 224], [160, 224], [205, 214], [242, 220], [270, 238], [292, 264], [318, 292], [330, 322], [312, 346], [272, 352], [232, 360],
      [204, 392], [170, 418], [120, 432], [60, 440], [-10, 444]], true, true);
    R.flat(skin, '#f4bca2', 0.06, 1);
    a.save(); a.strokeStyle = '#c8806a'; a.lineWidth = 1.2; a.globalAlpha = 0.8;
    for (const pts of [[[20, 280], [40, 270], [62, 282], [60, 300], [40, 306]], [[240, 330], [262, 340], [280, 322]], [[60, 380], [90, 370], [110, 390]], [[260, 250], [280, 270], [300, 290]], [[10, 360], [30, 350], [44, 368]]])
      a.stroke(P(pts, false));
    a.restore();
    R.flat(P(blob(145, 410, 22, 10, 3, 10, 0.3)), '#f07a20', 0.065, 1);
    R.flat(P(blob(62, 425, 16, 8, 4, 10, 0.3)), '#f07a20', 0.065, 1);
    { const r = rng(7); for (let i = 0; i < 18; i++) R.flat(circleP(120 + r() * 120, 200 + r() * 30, 1 + r() * 2), '#d8a080', 0.06, 1); }
    const eye = P([[94, 312], [128, 284], [172, 270], [224, 278], [250, 300], [222, 324], [174, 338], [124, 334]], true, true);
    R.flat(eye, '#0a0a0a', 0.07, 1);
    R.flat(P([[106, 311], [134, 290], [172, 280], [218, 286], [238, 301], [216, 318], [174, 328], [128, 326]], true, true), '#f6ee8e', 0.075, 1);
    R.flat(ellipseP(160, 312, 52, 18, -0.04), '#1e3ad8', 0.08, 1);
    R.flat(circleP(186, 304, 13), '#f6ee8e', 0.085, 1);
    R.dome(circleP(91, 524, 5), '#a090e0', 0.06, 0.02, 2, 2);

    const CH = '#d4d0c4';
    const bub = (x, y, r, k = 1) => R.dome(circleP(x, y, r), CH, 0.24 + 0.02 * k, Math.min(0.4, r * 0.006 + 0.1), r, 5);
    // left column (out of focus)
    R.dome(P([[-10, 430], [60, 420], [150, 440], [220, 470], [210, 560], [160, 620], [140, 720], [190, 820], [200, 900], [210, 1034], [-10, 1034]], true, true), '#b0aca0', 0.18, 0.2, 60, 5);
    for (const [x, y, r] of [[60, 474, 52], [176, 470, 48], [228, 450, 26], [24, 562, 42], [96, 566, 40], [40, 652, 48], [108, 640, 34], [70, 762, 62], [150, 740, 40], [30, 878, 55],
      [112, 862, 50], [86, 962, 55], [170, 984, 45], [20, 1000, 40], [165, 900, 30]]) bub(x, y, r, -2);
    // ── navy night panel ──
    const night = P([[322, 392], [398, 376], [462, 450], [482, 560], [474, 700], [430, 760], [350, 720], [322, 600]], true, true);
    R.flat(night, lin(330, 400, 470, 720, [[0, '#24306a'], [1, '#18204e']]), 0.04, 0);
    clipA(night, () => { const r = rng(9); a.strokeStyle = 'rgba(200,210,255,0.5)'; a.lineWidth = 0.8;
      for (let i = 0; i < 40; i++) { const x = 360 + r() * 100, y = 430 + r() * 260; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 30 + r() * 30, y - 12 - r() * 12); a.stroke(); }
      a.fillStyle = '#ffffff'; for (let i = 0; i < 30; i++) a.fill(circleP(330 + r() * 150, 390 + r() * 360, 0.6 + r() * 1.2)); });
    R.dome(circleP(398, 578, 5), '#ffffff', 0.06, 0.03, 3, 4);

    // ── cream hexagon frame with tiles ──
    const FR = [[488, 500], [400, 346], [225, 368], [94, 668], [206, 932], [394, 954]];
    const fr = P(FR, false, false);
    a.save(); a.lineJoin = 'miter'; a.lineCap = 'butt';
    a.lineWidth = 44; a.strokeStyle = '#f07818'; a.stroke(fr); a.restore();
    R.h.save(); R.h.lineJoin = 'miter'; R.h.lineCap = 'butt'; R.h.lineWidth = 44; R.h.strokeStyle = hc(0.12, 4); R.h.stroke(fr); R.h.restore();
    a.save(); a.lineJoin = 'miter'; a.lineCap = 'butt'; a.lineWidth = 33; a.strokeStyle = '#f0e296'; a.stroke(fr); a.restore();
    R.h.save(); R.h.lineJoin = 'miter'; R.h.lineCap = 'butt'; R.h.lineWidth = 33; R.h.strokeStyle = hc(0.16, 4); R.h.stroke(fr); R.h.restore();
    R.groove(P([[386, 362], [404, 388], [414, 380], [396, 356]], true, false), 2.5, '#a08848', 0.16, 0.03, 4);
    R.groove(P([[410, 398], [430, 426], [446, 420]], false, false), 2.5, '#a08848', 0.16, 0.03, 4);
    // tiles along the inner edge
    { // tiles along the inner edge: walk the frame centreline, offset inwards
      const segs = [[1, 2, 6], [2, 3, 8], [3, 4, 7], [4, 5, 6]]; let i = 0;
      for (const [s0, s1, n] of segs) {
        const [x0, y0] = FR[s0], [x1, y1] = FR[s1], L = Math.hypot(x1 - x0, y1 - y0), nx = (y1 - y0) / L, ny = -(x1 - x0) / L;
        for (let k = 0; k < n; k++) {
          const t = (k + 0.5) / n, x = x0 + (x1 - x0) * t + nx * 31, y = y0 + (y1 - y0) * t + ny * 31, ang = Math.atan2(y1 - y0, x1 - x0);
          const sq = P([[-14, -12], [14, -12], [14, 12], [-14, 12]].map(([u, v]) => [x + u * Math.cos(ang) - v * Math.sin(ang), y + u * Math.sin(ang) + v * Math.cos(ang)]), true, false);
          const wood = (i++ % 2) === 1;
          R.dome(sq, wood ? '#a88660' : '#7a70d8', 0.1, 0.04, 3, wood ? 4 : 1);
        }
      }
    }

    // ── silver spiral discs ──
    const discs = [[304, 476, 66], [254, 650, 104], [288, 826, 88]];
    const spA = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(0.);
      ${discs.map(([x, y]) => `{ vec2 d = p - vec2(${x}., ${y}.); float r = length(d), th = atan(d.y, d.x);
        float s = abs(fract(r / 7.4 - th / 6.2832) - .5) * 2.; c = max(c, vec3(step(r, ${discs.find(q => q[0] === x)[2]}.)) * mix(vec3(.04), mix(vec3(.72,.72,.76), vec3(.97,.97,.99), s), smoothstep(0.18, 0.32, s))); }`).join('\n')}
      return c; }`);
    const spH = E.fx(HC + `vec3 fx(vec2 uv, vec2 p){
      float h = 0.;
      ${discs.map(([x, y]) => `{ vec2 d = p - vec2(${x}., ${y}.); float r = length(d), th = atan(d.y, d.x);
        float s = abs(fract(r / 7.4 - th / 6.2832) - .5) * 2.; h = max(h, step(r, ${discs.find(q => q[0] === x)[2]}.) * (0.2 + 0.05 * smoothstep(0.35, 0.65, s))); }`).join('\n')}
      return hc(h, 3.); }`);
    const discP = new Path2D(); for (const [x, y, r] of discs) discP.addPath(circleP(x, y, r));
    for (const [x, y, r] of discs) { a.fillStyle = '#f08020'; a.fill(circleP(x, y, r + 4)); R.flat(circleP(x, y, r + 4), null, 0.2, 3); }
    clipA(discP, () => img(spA));
    imgH(spH, discP);

    // ── orange tube ──
    R.pipe(P([[484, 512], [454, 542], [442, 592], [450, 642], [474, 690], [462, 728], [410, 748], [370, 744]], false), 44, '#f86c0c', 0.22, 0.14, 2);
    R.bead(372, 740, 34, '#f86c0c', 0.22, 0.2, 2);
    R.bead(484, 512, 22, '#f86c0c', 0.22, 0.12, 2);

    // ── grey slab + pink zigzag (right) ──
    R.flat(poly([[600, 560], [736, 540], [736, 1034], [470, 1034], [520, 940], [600, 900]]), '#6a6264', 0.03, 0);
    soft(x => { x.fillStyle = '#4a5ac0'; x.fill(P(blob(690, 870, 40, 30, 5))); x.fill(P(blob(520, 975, 70, 30, 6))); x.fill(P(blob(320, 990, 90, 40, 7))); x.fill(P(blob(700, 500, 30, 60, 8))); }, 4);
    const pink = (pts, wd = 12) => R.pipe(P(pts, false, false), wd, '#fa70c8', 0.3, 0.06, 2);
    pink([[462, 384], [548, 390], [600, 504], [668, 462], [690, 490], [632, 566], [660, 592], [736, 556]]);
    pink([[640, 620], [628, 700], [690, 690], [736, 676]]);
    pink([[560, 900], [600, 860], [640, 880], [680, 822], [650, 770], [700, 740], [736, 720]]);
    pink([[400, 1000], [430, 994], [470, 960], [520, 950], [560, 920], [640, 860], [690, 840], [736, 800]]);
    pink([[460, 1034], [520, 990], [600, 970], [660, 900], [736, 880]]);
    for (const [x, y, r] of [[685, 650, 32], [692, 955, 33]]) R.bead(x, y, r, '#fa6a0a', 0.2, 0.1, 2);
    R.dome(circleP(545, 985, 28), '#857070', 0.12, 0.03, 6, 1);
    R.bead(545, 985, 14, '#fa6a0a', 0.16, 0.08, 2);

    // ── chrome bubbles ──
    for (const [x, y, r] of [[450, 285, 32], [500, 276, 36], [548, 300, 30], [438, 340, 32], [492, 336, 40], [548, 346, 30], [470, 372, 24]]) bub(x, y, r);
    // right mass
    R.dome(P([[540, 556], [610, 574], [652, 604], [624, 630], [560, 640]], true, true), CH, 0.24, 0.14, 34, 5);
    for (const [x, y, rx, ry, sd] of [[506, 582, 64, 60, 1], [596, 606, 40, 36, 2], [512, 700, 62, 56, 3], [590, 712, 34, 40, 4], [552, 798, 66, 60, 5], [536, 866, 42, 30, 6]])
      R.dome(P(blob(x, y, rx, ry, sd, 16, 0.08)), CH, 0.24, 0.3, Math.min(rx, ry), 5);
    // eyeballs
    for (const [x, y, r] of [[120, 532, 22], [160, 500, 14], [78, 442, 14], [222, 272, 13], [395, 148, 10], [565, 268, 10]]) {
      R.bead(x, y, r, '#2a2a30', 0.4, 0.12, 6);
      R.dome(circleP(x, y, r * 0.62), '#4a62d8', 0.5, 0.04, r * 0.3, 6);
      R.dome(circleP(x, y, r * 0.28), '#0a0a12', 0.54, 0.02, 2, 6);
    }
    soft(x => { x.fillStyle = '#f4f2ec'; x.fill(poly([[-10, 690], [22, 700], [44, 820], [46, 1034], [-10, 1034]])); }, 6);
    R.flat(poly([[-10, 690], [22, 700], [44, 820], [46, 1034], [-10, 1034]]), null, 0.5, 0);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.1, shin: 14, wrap: 0.6, ao: 0.2 }),                                      // 1 flat paper / skin
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.3, coat: 0.2, ao: 0.3, rim: 0.3 }),                  // 2 glossy plastic
        E.mat({ dif: 1, spec: 0.9, shin: 40, wrap: 0.45, coat: 0.2, ao: 0.6, metal: 0.1, bump: 1.2, emis: 0.08 }),  // 3 silver ridges
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.4, ao: 0.6, grain: 0.15 }),                          // 4 cream frame / wood
        E.mat({ dif: 1.05, metal: 0.45, spec: 1.6, shin: 45, rim: 0.15, ao: 0.6, wrap: 0.0, tint: [1.05, 1.0, 0.9] }), // 5 chrome
        E.mat({ dif: 0.8, spec: 1.4, shin: 100, coat: 0.4, ao: 0.2 })                                      // 6 eyeball
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.75, 0.74, 0.72], amb: [0.42, 0.42, 0.45],
      envTop: [1.3, 1.28, 1.2], envHor: [0.95, 0.92, 0.86], envBot: [0.12, 0.12, 0.12], envK: [0.5, 1.4, 0.45, 0],
      rimC: [0.25, 0.25, 0.35], rimD: [0.3, 0.6, 0.3], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-6, 8, 0.6, 7]
    });
    // soft focus on the far left
    { const bl = E.blur(E.snapshot(), 3), x = bl.getContext('2d');
      x.globalCompositeOperation = 'destination-in'; x.setTransform(S, 0, 0, S, 0, 0);
      const g = x.createLinearGradient(0, 0, 150, 0); g.addColorStop(0, 'rgba(0,0,0,1)'); g.addColorStop(1, 'rgba(0,0,0,0)');
      x.fillStyle = g; x.fillRect(0, 440, W, H);
      E.draw(bl); }
    E.grain(0.035, 123);
  }
});
