'use strict';
// s43 — "Op-art cosmos": a zebra-striped op-art body wrapping a starfield
// burst, a blue sky with a purple ribbon, rainbow comet flames, a red open
// mouth, a red octopus and a red scorpion.
REC.register('s43', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };

    // ── op-art zebra: concentric wavy rings around a few centres, seams where the ring sets meet
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 C[4]; C[0] = vec2(235.,150.); C[1] = vec2(310.,770.); C[2] = vec2(600.,700.); C[3] = vec2(470.,236.);
      float B[4]; B[0] = 0.; B[1] = 30.; B[2] = 60.; B[3] = 40.;
      float best = 1e9, ph = 0.;
      for (int i = 0; i < 4; i++) {
        vec2 d = p - C[i]; float r = length(d), a = atan(d.y, d.x);
        float sc = r - B[i];
        if (sc < best) { best = sc; ph = r/15.5 + 0.35*sin(a*5. + r*0.03 + float(i)) + 0.25*sin(p.x*0.05 + p.y*0.02); }
      }
      float s = sin(6.2832*ph) + 0.45*(1. - smoothstep(110., 190., p.x))*(1. - smoothstep(240., 320., p.y));   // whiter left body
      return vec3(smoothstep(-.2, .2, s))*.97 + .015; }`));
    fill(rrect(0, 0, W, H, 0), zebra);

    // ── black areas: far-left strip, around the mouth, bottom right
    const BLACK = '#020203';
    fill(P([[0, 0], [130, 0], [110, 40], [60, 60], [40, 120], [36, 250], [44, 330], [30, 440], [0, 450]], true, false), BLACK);
    fill(P([[110, 0], [400, 0], [400, 100], [330, 90], [250, 60], [150, 40]], true, false), BLACK);
    fill(P([[600, 800], [660, 780], [700, 790], [726, 780], [726, 1024], [650, 1024], [640, 940], [600, 900]], true, false), BLACK);
    fill(P([[630, 540], [672, 590], [688, 640], [700, 690], [712, 740], [726, 772], [726, 800], [690, 800], [650, 790], [630, 700], [620, 600]], true, false), BLACK);

    // ── blue sky with a purple ribbon (top right)
    const sky = P([[392, 0], [726, 0], [726, 770], [712, 740], [700, 690], [688, 640], [672, 590], [650, 530], [630, 495], [600, 462], [570, 430], [540, 390], [505, 335], [478, 270], [452, 200], [424, 110]], true, false);
    fill(sky, '#3271fa');
    clipped(sky, () => { stroke(P([[428, -20], [480, 100], [538, 200], [598, 300], [652, 400], [684, 500], [712, 560], [736, 620]], false), '#914df8', 74); fill(P([[700, 590], [726, 580], [726, 760], [712, 740]]), '#3ea0fc'); });
    fill(circleP(697, 120, 20), '#fdfdfd'); fill(circleP(706, 250, 5), '#f4f4f8'); fill(circleP(530, 18, 6), '#f4f4f8');
    fill(P([[528, 30], [545, 38], [560, 60], [556, 68], [538, 52]]), '#f060e0');

    // ── starfield burst
    const starsP = P([[398, 246], [430, 262], [470, 292], [500, 332], [530, 382], [560, 432], [600, 482], [625, 522], [640, 562], [640, 640], [610, 700], [600, 780],
      [640, 830], [620, 880], [600, 940], [560, 965], [480, 968], [400, 968], [330, 950], [270, 920], [230, 900], [190, 860], [150, 800], [100, 760], [60, 720],
      [50, 660], [90, 620], [160, 610], [200, 600], [210, 560], [130, 560], [90, 530], [60, 470], [90, 440], [140, 420], [200, 400], [240, 390], [260, 410],
      [300, 400], [330, 380], [350, 330], [370, 290], [390, 262]], true, false);
    const stars = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = floor(p/3.); float h = hash(c);
      vec2 q = fract(p/3.) - vec2(hash(c+3.1), hash(c+5.7));
      float s = step(.8, h) * smoothstep(.45, .1, length(q)) * (.4 + .6*hash(c+9.));
      vec2 c2 = floor(p/11.); float g = hash(c2+41.);
      vec2 q2 = p/11. - c2 - vec2(hash(c2+7.), hash(c2+9.))*.7 - .15;
      s += step(.84, g) * smoothstep(.2, .1, length(q2));
      return vec3(.115, .095, .105) + vec3(min(s,1.)) * .85; }`));
    fill(starsP, stars);
    // glowing orbs
    for (const [x, y, r] of [[176, 352, 34], [190, 440, 28], [268, 522, 30], [492, 492, 30], [500, 742, 24], [350, 38, 14]]) {
      const g = o.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,255,235,1)'); g.addColorStop(0.25, 'rgba(240,240,190,0.7)'); g.addColorStop(1, 'rgba(200,200,150,0)');
      fill(circleP(x, y, r), g);
    }

    // ── rainbow comet flames: tail -> tip, base width
    const comet = (tail, tip, wd, cols, bend = 0.06) => {
      const dx = tip[0] - tail[0], dy = tip[1] - tail[1], L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      const cp = u => { const b = bend * L * 4 * u * (1 - u); return [tail[0] + dx * u + nx * b, tail[1] + dy * u + ny * b]; };
      const wAt = u => wd * 0.5 * Math.pow(1 - u, 0.8);
      const A = [], B = [];
      for (let i = 0; i <= 14; i++) { const u = i / 14, [x, y] = cp(u), w = wAt(u); A.push([x + nx * w, y + ny * w]); B.push([x - nx * w, y - ny * w]); }
      const jr = rng(Math.round(tail[0] * 13 + tip[1])), base = [];
      for (let k = 1; k < 8; k++) { const v = wd * 0.5 * (1 - 2 * k / 8); base.push([tail[0] + nx * v - dx / L * (6 + 26 * jr()), tail[1] + ny * v - dy / L * (6 + 26 * jr())]); }
      const path = P([...A, ...B.reverse(), ...base.reverse()], true, false);
      const g = o.createLinearGradient(tail[0], tail[1], tip[0], tip[1]);
      cols.forEach((c, i) => g.addColorStop(i / (cols.length - 1), c));
      fill(path, g);
      clipped(path, () => { for (let k = 0; k < 6; k++) { const v = wd * 0.5 * (jr() * 2 - 1), l0 = 0.02 + jr() * 0.1; stroke(P([[tail[0] + nx * v, tail[1] + ny * v], [tail[0] + nx * v * 0.8 + dx * l0 * 3, tail[1] + ny * v * 0.8 + dy * l0 * 3]], false), 'rgba(20,10,30,0.6)', 2); } });
    };
    const FIRE = ['#20e0f0', '#40f0c0', '#f0f040', '#ffa020', '#ff5018'];
    const SUN = ['#30d0f0', '#f0f030', '#fff020', '#ffe010'];
    comet([436, 156], [522, 50], 64, FIRE); comet([488, 290], [620, 150], 80, FIRE); comet([572, 404], [670, 282], 68, ['#f050c0', '#f0f040', '#fff020', '#fff840']);
    comet([590, 524], [672, 404], 66, ['#30b0f0', '#ff8020', '#ff4818', '#ff3010']); comet([414, 724], [492, 590], 50, ['#20c0f0', '#60f060', '#f0f030']);
    comet([-10, 836], [210, 734], 104, ['#fff020', '#f0f040', '#30e0f0', '#b040f0']); comet([100, 944], [280, 830], 92, ['#fff020', '#f0f040', '#f09020', '#4060f0']);
    comet([468, 1004], [356, 876], 70, ['#ff9020', '#f0f040', '#20c0f0']); comet([500, 915], [600, 968], 56, ['#f040a0', '#ff6020', '#ff4010']);
    comet([-10, 414], [104, 444], 60, ['#a040f0', '#c050f0', '#f060e0']);
    // big green-yellow crescent + small yellow crescent
    fill(P([[364, 544], [340, 480], [350, 420], [392, 372], [450, 344], [515, 336], [500, 362], [456, 380], [418, 408], [398, 448], [388, 496], [376, 544]]),
      (() => { const g = o.createLinearGradient(360, 540, 515, 340); g.addColorStop(0, '#306020'); g.addColorStop(0.3, '#f0e020'); g.addColorStop(0.7, '#40e060'); g.addColorStop(1, '#20e0f0'); return g; })());
    fill(P([[476, 440], [510, 424], [550, 416], [590, 420], [560, 428], [520, 436]]), '#f8e818');
    // yellow ring flame on the left
    const ring = P([[20, 500], [50, 478], [90, 480], [130, 510], [170, 560], [200, 585], [140, 590], [90, 600], [40, 580], [14, 540]]);
    fill(ring, (() => { const g = o.createLinearGradient(20, 520, 200, 590); g.addColorStop(0, '#f8f020'); g.addColorStop(0.6, '#e0f040'); g.addColorStop(1, '#30e0f0'); return g; })());
    fill(ellipseP(66, 528, 30, 18, 0.35), '#020203');

    // ── red open mouth (top): black opening, two-tone red lip, maroon lower mouth
    fill(P([[112, 0], [396, 0], [412, 60], [416, 125], [380, 150], [345, 170], [330, 200], [310, 235], [270, 264], [210, 262], [165, 228], [130, 190], [112, 110]], true, false), '#301a1e');
    fill(P([[150, 0], [392, 0], [402, 60], [410, 112], [360, 106], [300, 96], [250, 80], [200, 56], [166, 30]], true, false), '#030203');
    const lipG = o.createLinearGradient(120, 120, 400, 110); lipG.addColorStop(0, '#f41818'); lipG.addColorStop(0.45, '#e01010'); lipG.addColorStop(0.6, '#b8100d'); lipG.addColorStop(1, '#b0100c');
    const lip = P([[114, 30], [104, 90], [118, 140], [150, 172], [200, 184], [262, 180], [322, 166], [372, 150], [412, 134], [408, 116], [360, 108], [300, 98], [250, 84], [200, 60], [160, 34]]);
    fill(lip, lipG); stroke(lip, 'rgba(255,90,90,0.8)', 2);
    fill(P([[170, 25], [190, 20], [215, 48], [240, 78], [238, 100], [214, 90], [190, 64]]), '#f8f020');
    fill(P([[252, 232], [258, 200], [276, 178], [306, 164], [334, 158], [314, 180], [292, 200], [274, 226]]), '#1090f0');
    // purple stick and the little eye-pod
    stroke(P([[318, 248], [262, 395]], false), '#8a2ad8', 11);
    fill(ellipseP(458, 232, 42, 30, 0), '#141216'); fill(ellipseP(456, 240, 28, 12, 0), '#d8a0d8'); fill(ellipseP(456, 240, 22, 8, 0), '#1a1020');
    for (const [x, c] of [[446, '#e02030'], [456, '#f0f0f0'], [466, '#2060f0']]) fill(rrect(x - 2, 234, 4, 12, 2), c);

    // ── red octopus
    const rg = (x, y, r, c0, c1) => { const g = o.createRadialGradient(x - r * 0.3, y - r * 0.3, r * 0.1, x, y, r); g.addColorStop(0, c0); g.addColorStop(1, c1); return g; };
    for (const pts of [[[330, 760], [360, 800], [350, 850], [300, 880], [250, 890]], [[380, 840], [360, 900], [330, 940], [300, 960]], [[420, 860], [440, 920], [420, 960]],
      [[300, 870], [260, 860], [230, 870]]]) stroke(P(pts, false), '#e82018', 26);
    fill(ellipseP(272, 702, 78, 58, 0.1), rg(272, 702, 80, '#ff3a30', '#a00808'));
    fill(ellipseP(290, 712, 50, 40, 0.1), 'rgba(40,0,6,0.8)');
    fill(circleP(240, 700, 26), '#f080a0'); fill(circleP(240, 700, 19), '#fefefe');
    fill(P([[340, 772], [372, 752], [420, 760], [470, 790], [500, 840], [490, 890], [440, 910], [390, 900], [350, 870], [330, 820]]), rg(420, 820, 90, '#ff5040', '#c01010'));
    const fr = rng(43);
    for (let i = 0; i < 12; i++) { const x = 360 + fr() * 120, y = 780 + fr() * 110; stroke(P([[x, y], [x + 12, y - 8], [x + 22, y + 2]], false), '#b00c0c', 4); }
    for (const [x, y] of [[340, 796], [338, 762]]) { fill(ellipseP(x, y, 12, 14), '#fefefe'); fill(ellipseP(x + 2, y, 6, 8), '#101010'); }
    fill(P([[476, 830], [510, 818], [545, 828], [552, 856], [530, 878], [494, 872], [474, 852]]), '#d8b870');
    stroke(P([[486, 840], [510, 850], [540, 846]], false), '#a08040', 3);

    // ── red scorpion (right)
    const scG = rg(610, 700, 190, '#ff4030', '#c01410');
    fill(ellipseP(600, 802, 92, 54, -0.05), scG);
    stroke(P([[630, 600], [616, 660], [608, 720], [612, 770]], false), scG, 62);
    fill(P([[596, 604], [592, 560], [598, 520], [612, 540], [626, 570], [650, 580], [656, 548], [652, 516], [672, 530], [690, 570], [684, 610], [650, 628], [616, 626]]), scG);
    fill(circleP(583, 798, 19), '#585659');
    // coloured dots
    for (const [x, y, r, c] of [[535, 693, 15, '#30e070'], [630, 725, 13, '#f020e0'], [705, 770, 8, '#f020a0'], [530, 793, 10, '#c0f020'], [415, 490, 12, '#20f0f0'],
      [185, 840, 12, '#20f0f0'], [65, 880, 8, '#f04020'], [45, 905, 7, '#f020e0'], [610, 915, 10, '#f020e0'], [650, 948, 7, '#9040f0'], [10, 130, 22, '#2aff83'],
      [18, 205, 14, '#f01010'], [128, 470, 6, '#f04020'], [298, 432, 7, '#40e040'], [612, 562, 8, '#40e040'], [275, 975, 7, '#f020e0'], [42, 322, 6, '#f0e020']])
      fill(circleP(x, y, r), c);
    // white dots
    for (const [x, y, r] of [[292, 46, 6], [56, 365, 9], [100, 410, 8], [240, 700, 0], [440, 170, 4], [572, 474, 6], [338, 630, 7], [430, 640, 8], [576, 716, 7],
      [240, 832, 5], [694, 912, 7], [705, 646, 4], [566, 634, 6], [462, 628, 6], [598, 668, 6], [230, 568, 5], [140, 596, 5]])
      if (r) fill(circleP(x, y, r), '#fbfbfb');

    E.grain(0.03, 43);
  }
});
