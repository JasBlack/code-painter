'use strict';
// g116 — "Zebra egg and coil": a lavender clay slab with soft cow spots holds a black-and-white zebra egg,
// a white-and-black coiled spring with red glints runs across it, grey pipes and a white tube loop against a pink-to-violet sky.
REC.register('g116', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const rev = pts => pts.slice().reverse();
    const area = pts => pts.reduce((s, p, i) => { const q = pts[(i + 1) % pts.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0);
    const holeOf = (outer, pts) => Math.sign(area(outer)) === Math.sign(area(pts)) ? rev(pts) : pts;
    const cap = (cx, cy, ang, L, W) => {
      const t = ang * Math.PI / 180, dx = Math.cos(t), dy = Math.sin(t), r = W / 2, hl = Math.max(0, L / 2 - r), p = new Path2D();
      p.arc(cx + dx * hl, cy + dy * hl, r, t - Math.PI / 2, t + Math.PI / 2);
      p.arc(cx - dx * hl, cy - dy * hl, r, t + Math.PI / 2, t + Math.PI * 1.5);
      p.closePath(); return p;
    };

    // ── textures ──
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float y = p.y + 14. * sin(p.x * 0.012);
      vec3 c = vec3(.98, .80, .78);
      c = mix(c, vec3(.98, .55, .78), smoothstep(120., 175., y));
      c = mix(c, vec3(.97, .43, .83), smoothstep(170., 230., y));
      c = mix(c, vec3(.78, .58, .96), smoothstep(250., 305., y));
      c = mix(c, vec3(.71, .73, .95), smoothstep(305., 345., y));
      c = mix(c, vec3(.78, .90, .98), smoothstep(350., 420., y));
      c = mix(c, vec3(.70, .78, .97), smoothstep(440., 480., y));
      c = mix(c, vec3(.58, .54, .96), smoothstep(480., 525., y));
      c = mix(c, vec3(.53, .38, .67), smoothstep(540., 610., y));
      return c; }`));
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = (p - vec2(296.6, 356.5)) / 100.; float u = q.x, v = q.y;
      float ph = 2.37072*v + -0.38237*v*v + 0.06985*v*v*v + 0.05068*v*v*v*v + -1.28956*u + -0.03295*u*v + 0.26842*u*v*v + 0.05280*u*v*v*v
        + 0.29766*u*u + -0.03313*u*u*v + 0.23837*u*u*v*v + 0.05906*u*u*u + 0.04925*u*u*u*v + 0.10044*u*u*u*u - 0.3158;
      float s = cos(6.2832 * ph);
      return mix(vec3(.05, .05, .07), vec3(.95, .95, .95), smoothstep(-0.12, 0.12, s)); }`));
    const stars = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.17, .08, .11), vec3(.24, .12, .15), fbm(p * 0.01));
      float h = hash(floor(p / 2.)); c += vec3(.75, .7, .75) * step(0.985, h) * hash(floor(p / 2.) + 3.1);
      return c; }`));

    // ── sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), sky, 0, 0);

    // ── white rod behind the egg, star stem ──
    R.pipe(P([[369, -10], [369, 150]], false), 18, '#e6e8f4', 0.08, 0.1, 1);

    // ── upper-right slab with brown maze spots ──
    const URS = [[380, -10], [380, 22], [394, 48], [414, 58], [452, 58], [470, 68], [490, 98], [514, 132], [534, 170], [538, 212], [528, 246], [517, 282], [513, 318], [526, 345], [556, 372], [600, 392], [650, 386], [736, 380], [736, -10]];
    const hole = [[598, 304], [628, 287], [652, 290], [690, 322], [716, 346], [736, 364], [736, 372], [680, 356], [640, 349], [610, 330]];
    const urs = P(URS, true, true); urs.addPath(P(holeOf(URS, hole), true, true));
    R.dome(urs, '#cdd4ea', 0.06, 0.1, 14, 1);
    const spotsUR = [
      [[570, 95], [568, 110], [575, 136], [568, 172], [575, 189], [588, 200], [608, 202], [627, 188], [627, 173], [621, 169], [603, 170], [596, 161], [596, 149], [613, 127], [629, 115], [643, 116], [653, 125], [667, 164], [697, 149], [711, 150], [736, 158], [736, 74], [703, 94], [679, 99], [662, 92], [636, 68], [616, 65], [578, 86]],
      [[631, 236], [598, 241], [567, 265], [560, 278], [558, 297], [570, 318], [588, 321], [607, 293], [615, 292], [620, 298], [648, 283]],
      [[590, -5], [537, -5], [508, 61], [506, 81], [513, 92], [523, 93], [530, 87], [543, 40], [559, 28], [578, 23]],
      [[699, 199], [683, 220], [676, 243], [703, 279], [736, 279], [736, 217]],
      [[646, -5], [656, 22], [679, 37], [691, 36], [713, 18], [736, 15], [736, -5]],
      [[424, -5], [437, 20], [458, 22], [480, 12], [490, -5]]];
    const spP = new Path2D(); for (const s of spotsUR) spP.addPath(P(s, true, true));
    clipA(urs, () => soft(x => { x.fillStyle = '#4a2a32'; x.fill(spP); }, 1.2));
    clipA(spP, () => { const r = rng(5); a.fillStyle = 'rgba(240,220,230,0.7)'; for (let i = 0; i < 120; i++) a.fill(circleP(400 + r() * 330, r() * 330, 0.5 + r() * 0.8)); });
    // dark outline shadow along its left edge
    soft(x => { x.strokeStyle = '#3a2028'; x.lineWidth = 5; x.stroke(P(URS.slice(0, 18), false, true)); }, 2, 0.8);

    // ── white tube loop in the sky ──
    R.pipe(P([[416, 350], [416, 250], [418, 160], [428, 115], [450, 92], [475, 95], [490, 120], [492, 200], [494, 262], [507, 300], [530, 325], [548, 336]], false), 19, '#e2e4f2', 0.24, 0.1, 1);

    // ── zebra egg ──
    const EGG = [[338, 132], [372, 150], [404, 190], [430, 250], [438, 320], [428, 400], [400, 466], [352, 520], [290, 552], [228, 562], [180, 545], [152, 505], [142, 440], [148, 360], [168, 300], [205, 250], [260, 205], [305, 160]];
    R.dome(P(EGG), zebra, 0.06, 0.26, 70, 2);

    // ── main clay slab (left + bottom) with holes ──
    const MAIN = [[-10, -10], [302, -10], [306, 95], [330, 140], [334, 210], [320, 250], [302, 262], [297, 290], [284, 303], [266, 298], [255, 275], [242, 249], [222, 242], [196, 262], [176, 295],
      [158, 345], [146, 420], [150, 490], [170, 535], [205, 560], [262, 560], [330, 530], [384, 496], [420, 472], [470, 503], [530, 528], [600, 556], [660, 585], [736, 615], [736, 1034], [-10, 1034]];
    const H1 = [[736, 804], [697, 817], [641, 801], [619, 808], [607, 832], [617, 871], [612, 897], [588, 912], [552, 907], [532, 912], [522, 929], [523, 968], [517, 986], [498, 1005], [458, 1034], [736, 1034]];
    const H2 = [[684, 742], [658, 732], [630, 745], [591, 781], [532, 865], [453, 897], [439, 923], [446, 951], [465, 963], [483, 960], [491, 948], [492, 922], [502, 900], [520, 884], [572, 858], [586, 803], [596, 788], [623, 773], [679, 777], [690, 760]];
    R.flat(P(H1), stars, 0.0, 0); R.flat(P(H2), stars, 0.0, 0);
    const main = P(MAIN, true, false); main.addPath(P(holeOf(MAIN, H1), true, true)); main.addPath(P(holeOf(MAIN, H2), true, true));
    const mg = a.createLinearGradient(0, 0, 300, 1024); mg.addColorStop(0, '#d6e0f2'); mg.addColorStop(0.5, '#d0d8ec'); mg.addColorStop(1, '#c8cce4');
    R.dome(main, mg, 0.08, 0.12, 22, 1);
    // cream puddle, lavender smears, soft cow spots, top hollow
    clipA(main, () => {
      soft(x => { x.fillStyle = '#eef0d0'; x.fill(P([[40, 457], [32, 484], [41, 521], [37, 562], [45, 582], [66, 597], [126, 603], [153, 631], [158, 672], [199, 671], [226, 704], [237, 708], [247, 681], [229, 642], [220, 635], [183, 629], [162, 611], [160, 559], [152, 539], [108, 511], [69, 456], [49, 452]])); }, 3);
      soft(x => { x.fillStyle = '#a090b8'; x.fill(P([[125, 186], [111, 189], [95, 210], [83, 271], [90, 394], [102, 446], [112, 457], [120, 452], [112, 305], [138, 215], [136, 197]])); x.fill(ellipseP(80, 118, 14, 22, 0.3)); x.fill(ellipseP(108, 120, 10, 20, -0.2)); }, 7, 0.85);
      soft(x => { x.fillStyle = '#9a7ca0'; x.fill(ellipseP(80, 720, 60, 40, 0.2)); x.fill(ellipseP(26, 340, 50, 75, 0)); x.fill(ellipseP(8, 150, 30, 60, 0)); }, 16, 0.8);
      soft(x => { x.fillStyle = '#2c1a22';
        x.fill(P([[0, 637], [15, 694], [24, 705], [62, 724], [84, 717], [103, 701], [109, 668], [92, 642], [52, 636], [22, 621]]));
        x.fill(P([[-5, 282], [-5, 387], [16, 400], [31, 402], [53, 383], [55, 339], [37, 287], [22, 276]]));
        x.fill(P([[19, 95], [-5, 112], [-5, 201], [17, 183], [28, 155], [25, 103]])); }, 6);
      soft(x => { x.fillStyle = '#86709a'; x.fill(P([[176, -10], [250, -10], [256, 40], [248, 90], [226, 102], [196, 92], [180, 50]])); }, 6, 0.95);
      soft(x => { x.fillStyle = '#fbf8d4'; x.fill(P([[-10, -10], [70, -10], [40, 20], [-10, 40]])); }, 6, 0.9);
    });
    R.groove(P([[214, -10], [212, 50], [222, 92]], false), 40, null, 0.2, 0.08, 1);

    // ── metal pipes ──
    const GREY = '#b4bcc8';
    R.pipe(P([[430, 360], [428, 470], [424, 580], [432, 600], [448, 612]], false), 40, GREY, 0.3, 0.16, 3);
    R.pipe(P([[418, 356], [482, 356]], false), 30, '#9a9ea8', 0.42, 0.1, 3);
    R.pipe(P([[408, 578], [440, 578]], false), 46, '#80848e', 0.36, 0.1, 3);
    R.dome(rrect(478, 351, 22, 22, 3), '#a8d020', 0.48, 0.06, 4, 4);
    R.dome(circleP(489, 362, 5), '#205030', 0.52, 0.02, 3, 4);
    R.pipe(P([[602, 560], [604, 440], [612, 404], [640, 393], [736, 393]], false), 40, GREY, 0.3, 0.16, 3);
    R.pipe(P([[592, 456], [618, 456]], false), 44, '#9a9ea8', 0.4, 0.1, 3);
    R.pipe(P([[650, 393], [650, 393.5]], false), 48, '#9a9ea8', 0.42, 0.1, 3);
    R.pipe(P([[690, 393], [690, 393.5]], false), 48, '#9a9ea8', 0.42, 0.1, 3);
    R.pipe(P([[640, 560], [736, 500]], false), 70, '#8a8e9a', 0.3, 0.18, 3);

    // ── white bent pipe top right, tube bottom left ──
    R.pipe(P([[740, 172], [690, 160], [655, 182], [640, 236], [650, 292], [684, 334], [720, 362], [740, 372]], false), 52, '#e4e6f2', 0.3, 0.16, 5);
    R.pipe(P([[-30, 828], [20, 840], [48, 880], [56, 940], [46, 1000], [36, 1040]], false), 46, '#e0e2f0', 0.3, 0.16, 5);

    // ── spring: dark glossy segments under white capsules ──
    const CAPS = [[650, 568, 62, 140, 62], [588, 604, 58, 150, 58], [527, 630, 60, 150, 56], [472, 662, 55, 150, 56], [425, 698, 57, 145, 55], [376, 726, 59, 140, 52],
      [334, 760, 52, 140, 50], [291, 790, 45, 135, 50], [246, 816, 43, 135, 50], [198, 844, 39, 150, 52], [141, 868, 34, 115, 48], [96, 905, 29, 115, 52]];
    const LOW = [[262, 968, 35, 120, 46], [214, 992, 31, 120, 44], [140, 1004, 22, 110, 46], [72, 990, 30, 100, 46]];
    // dark strand peeking along both edges of the coil
    const edge = (L, k) => L.map(([x, y]) => [x + 0.52 * k, y + 0.854 * k]);
    R.pipe(P(edge(CAPS, 66), false), 48, '#1e1214', 0.2, 0.16, 4);
    R.pipe(P(edge(CAPS, -60), false), 40, '#2a1614', 0.2, 0.16, 4);
    R.pipe(P(edge(LOW, 50), false), 40, '#1e1214', 0.18, 0.14, 4);
    const darkA = (x, y) => (y < 700 && x < 420) ? '#8a1810' : '#241414';
    for (const L of [LOW, CAPS]) for (let i = 0; i < L.length - 1; i++) {
      const A = L[i], B = L[i + 1], cx = (A[0] + B[0]) / 2 + 6, cy = (A[1] + B[1]) / 2 + 6;
      R.dome(cap(cx + 6, cy + 8, (A[2] + B[2]) / 2, (A[3] + B[3]) / 2 * 1.08, 66), darkA(cx, cy), 0.22, 0.18, 26, 4);
    }
    // red glossy beads at the top edge near the glow
    for (const [x, y, r, c] of [[376, 630, 24, '#d01808'], [318, 682, 20, '#b81408'], [262, 728, 20, '#a01408'], [470, 590, 18, '#5a1810'], [212, 768, 18, '#601810'], [160, 802, 18, '#3a1410'], [116, 836, 18, '#2a1410']]) R.bead(x, y, r, c, 0.3, 0.16, 4);
    for (const L of [LOW, CAPS]) for (const [cx, cy, an, len, wd] of L) R.dome(cap(cx, cy, an, len * 1.04, wd * 1.16), '#e4e6f4', 0.34, 0.3, 28, 5);
    // ring round the grey pipe
    R.pipe(ellipseP(652, 562, 30, 56, 0.95), 34, '#e8eaf6', 0.5, 0.2, 5);

    // ── cones, beads, pink nugget, crystal ──
    const cone = (tx, ty, bx, by, w) => { const dx = bx - tx, dy = by - ty, L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      return P([[tx, ty], [bx + nx * w, by + ny * w], [bx + dx / L * w * 0.6, by + dy / L * w * 0.6], [bx - nx * w, by - ny * w]], true, true); };
    R.dome(cone(296, 592, 336, 668, 26), '#eef0f8', 0.4, 0.3, 22, 5);
    R.dome(cone(152, 712, 200, 760, 20), '#eef0f8', 0.4, 0.26, 18, 5);
    R.bead(226, 567, 10, '#c8c020', 0.3, 0.12, 4);
    R.bead(177, 591, 8, '#c8c020', 0.3, 0.1, 4);
    const nr = rng(9); for (let i = 0; i < 10; i++) R.bead(262 + (nr() - 0.5) * 30, 702 + (nr() - 0.5) * 26, 8 + nr() * 5, '#f0d4d4', 0.42, 0.08, 1);
    R.bead(282, 690, 12, '#f0c840', 0.42, 0.08, 4);
    R.dome(P([[424, 600], [440, 592], [454, 604], [446, 622], [430, 624]], true, false), '#c8ccd8', 0.5, 0.06, 4, 3);

    // ── star on its stem ──
    R.pipe(P([[312, 96], [298, 140]], false), 12, '#e0e2ee', 0.24, 0.08, 1);
    const st = [];
    for (let i = 0; i < 12; i++) { const an = -Math.PI / 2 + i / 12 * Math.PI * 2, rr = i % 2 ? 24 : (i === 0 ? 50 : 48); st.push([320 + Math.cos(an) * rr * 1.55, 64 + Math.sin(an) * rr * 0.8]); }
    R.dome(P(st, true, true), '#eceef8', 0.3, 0.2, 14, 1);
    for (const [x, y] of [[300, 108], [318, 112], [334, 104], [340, 90], [296, 92]]) R.bead(x, y, 9, '#e6e8f4', 0.3, 0.1, 1);
    // glass bubble base
    R.bead(87, 117, 31, '#c8d2e6', 0.22, 0.12, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.55, ao: 0.6, rim: 0.2 }),                 // 1 clay
        E.mat({ dif: 1, spec: 0.9, shin: 70, wrap: 0.3, ao: 0.4, coat: 0.12 }),                 // 2 glossy zebra
        E.mat({ dif: 0.9, metal: 0.3, spec: 1.2, shin: 40, ao: 0.4, rim: 0.2, tint: [0.9, 0.95, 1.05] }), // 3 grey metal
        E.mat({ dif: 1, spec: 1.3, shin: 90, wrap: 0.2, ao: 0.4, coat: 0.3 }),                  // 4 dark gloss
        E.mat({ dif: 1, spec: 0.35, shin: 30, wrap: 0.5, ao: 0.6, rim: 0.25 }),                 // 5 white capsules
      ],
      light: [-0.5, 0.55, 0.68], lc: [0.58, 0.56, 0.6], amb: [0.42, 0.42, 0.48],
      envTop: [1, 0.98, 1.0], envHor: [0.75, 0.62, 0.85], envBot: [0.2, 0.15, 0.22], envK: [0.2, 0.8, 0.3, 0],
      rimC: [0.5, 0.4, 0.7], rimD: [0, 1, 0.3], r1: 1.6, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-6, 8, 0.5, 6]
    });

    // ── red glow, glass bubble, finishing ──
    for (const [x, y, r, al] of [[370, 640, 90, 0.75], [310, 670, 70, 0.55], [190, 745, 75, 0.65], [250, 715, 60, 0.45]]) {
      const g = o.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(255,30,40,${al})`); g.addColorStop(0.5, `rgba(255,40,60,${al * 0.45})`); g.addColorStop(1, 'rgba(255,0,0,0)');
      o.fillStyle = g; o.fillRect(x - r, y - r, 2 * r, 2 * r);
    }
    { const g = o.createRadialGradient(80, 108, 2, 87, 117, 31); g.addColorStop(0, 'rgba(255,255,255,0.9)'); g.addColorStop(0.3, 'rgba(200,210,225,0.3)'); g.addColorStop(0.85, 'rgba(90,90,110,0.5)'); g.addColorStop(1, 'rgba(40,40,60,0.8)');
      o.fillStyle = g; o.fill(circleP(87, 117, 31)); o.lineWidth = 2; o.strokeStyle = 'rgba(60,60,80,0.7)'; o.stroke(circleP(87, 117, 30)); }
    E.bloom(0.12, 10);
    E.grain(0.03, 116);
  }
});
