'use strict';
// g198 — "Zebra wave, ember eye": a glassy black-and-white zebra wave rising on a violet field, a frosted glass
// disc holding a glowing ember eye, a bronze plate studded with glass bubbles, and a dark gold-lit lattice at the edge.
REC.register('g198', {
  w: 1024, h: 726,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const img = (cv, al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipB = (path, fn) => { a.save(); hx.save(); a.clip(path); hx.clip(path); fn(); hx.restore(); a.restore(); };
    const soft = (fn, blur, al = 1, op) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; if (op) a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fp = f => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return q; };
    const rad = (x, y, r0, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const line = (pts, w, c, ctx = a) => { ctx.lineWidth = w; ctx.strokeStyle = c; ctx.stroke(P(pts, false, true)); };

    // ── 1. violet field: soft radial glow (fitted centre, radii and colours) ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = (p - vec2(474., 366.)) / vec2(539., 521.);
        vec3 c = vec3(0.075, 0.116, 0.63) + vec3(0.421, 0.323, 0.248) * exp(-dot(d, d)) + vec3(0.007, -0.032, -0.167) * (p.y / 726.);
        return c + (hash(p * .71) - .5) * .03; }`));

    // ── 2. zebra wave (fitted stripe phase field) with a glassy blue rim ──
    const U = P(fp([925,63,790,63,740,1,761,59,714,94,705,131,720,167,751,181,790,232,791,261,768,285,740,277,693,191,646,177,611,182,622,215,603,239,569,238,549,202,496,249,470,309,483,339,472,379,513,445,554,473,569,501,584,500,588,451,625,409,600,385,597,367,624,346,650,367,642,401,672,417,686,439,683,461,614,515,598,541,575,541,559,512,529,517,469,503,430,468,399,417,373,401,345,406,327,426,308,488,316,516,303,533,276,525,282,488,258,459,242,463,233,528,240,587,322,725,557,725,548,701,510,665,516,645,542,628,570,649,577,677,606,689,600,725,944,725,949,496,929,305]), true, true);
    soft(x => { x.strokeStyle = 'rgba(30,24,110,0.6)'; x.lineWidth = 14; x.translate(4, 8); x.stroke(U); }, 8);
    const ZEB = E.fx(`const float ZBC[252] = float[252](-10.923,-10.778,-10.620,-10.454,-10.318,-10.257,-10.283,-10.382,-10.473,-10.395,-9.937,-9.047,-8.472,-8.532,-7.524,-6.196,-4.907,-3.701,-10.314,-9.986,-9.714,-9.494,-9.294,-9.121,-9.020,-8.983,-8.936,-8.821,-8.616,-7.880,-7.298,-6.755,-5.674,-4.687,-3.824,-2.916,-9.722,-9.195,-8.816,-8.594,-8.382,-8.116,-7.923,-7.760,-7.514,-7.128,-6.566,-6.012,-5.889,-5.588,-4.854,-3.515,-2.899,-2.104,-9.104,-8.450,-7.944,-7.746,-7.626,-7.388,-7.198,-6.843,-6.276,-5.610,-5.016,-4.725,-4.318,-4.071,-3.839,-3.219,-2.100,-1.314,-8.258,-7.898,-7.200,-6.739,-6.726,-7.093,-6.951,-6.171,-5.169,-4.297,-3.681,-3.319,-2.986,-2.623,-2.197,-2.191,-1.301,-0.794,-6.817,-7.602,-6.960,-5.159,-4.782,-7.486,-6.844,-5.281,-3.924,-3.092,-2.453,-2.084,-1.557,-1.357,-0.755,-0.620,-0.673,-0.461,-4.730,-6.626,-7.821,-2.648,-1.459,-7.676,-5.610,-3.465,-2.308,-1.950,-1.696,-0.442,-0.161,0.193,0.536,0.897,0.445,0.149,-3.358,-2.250,-7.921,0.975,-1.607,2.889,-2.905,-0.538,-0.576,-0.359,0.070,0.982,1.509,1.602,1.924,2.081,1.489,1.241,-4.744,3.346,1.090,1.410,0.936,2.334,1.565,2.622,0.601,1.827,2.323,2.866,2.804,3.090,3.215,3.867,3.376,2.863,-4.407,2.954,3.000,2.729,2.781,4.209,3.369,3.616,3.336,4.455,4.157,4.127,4.308,4.544,4.771,5.083,5.003,4.718,-0.399,5.446,3.989,4.339,4.053,5.530,5.324,5.255,5.350,4.964,5.189,5.365,5.617,5.890,6.156,6.372,6.501,6.535,5.380,7.124,4.643,5.378,5.907,6.019,6.976,6.716,7.542,6.517,6.380,6.574,6.857,7.155,7.447,7.716,7.986,8.249,10.154,8.600,6.652,6.132,6.932,8.008,8.300,9.517,8.876,8.175,7.886,7.921,8.114,8.385,8.707,9.069,9.469,9.892,14.181,11.052,8.824,7.517,7.050,7.050,7.784,8.520,9.335,9.619,9.524,9.394,9.412,9.611,9.960,10.419,10.948,11.508);
float zb(vec2 p){ vec2 u = clamp((p - vec2(220.0, 60.0)) / vec2(49.3333, 60.5455), vec2(0.), vec2(14.999, 10.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZBC[(i.y + b) * 18 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * zb(p));
        return mix(vec3(0.05, 0.045, 0.06), vec3(0.95, 0.93, 0.94), smoothstep(-0.18, 0.18, c)); }`);
    clipB(U, () => { img(ZEB); R.dome(U, null, 0.02, 0.1, 16, 1); });
    R.pipe(U, 11, '#a4b2e2', 0.12, 0.05, 4);
    a.lineWidth = 1.5; a.strokeStyle = 'rgba(40,40,110,0.8)'; a.stroke(U);

    // left glass ring
    { const rg = new Path2D(); rg.ellipse(318, 652, 30, 50, -0.35, 0, 6.2832); rg.ellipse(318, 652, 17, 34, -0.35, 0, 6.2832, true);
      R.dome(rg, '#c8b4e0', 0.14, 0.12, 8, 4); a.fillStyle = '#5e3060'; a.fill(ellipseP(318, 652, 16, 33, -0.35)); }

    // ── 3. dark lattice at the right edge with gold-lit strands ──
    const DK = P([[738, 0], [1030, 0], [1030, 730], [870, 730], [905, 640], [945, 560], [952, 480], [935, 440], [915, 380], [908, 300], [906, 200], [896, 150], [872, 112], [835, 82], [800, 62], [760, 40]], true, true);
    a.fillStyle = lin(740, 0, 1024, 726, [[0, '#1e2a3e'], [0.5, '#16212e'], [1, '#141e2a']]); a.fill(DK);
    clipA(DK, () => {
      soft(x => { for (const [cx, cy, w, h, rr] of [[935, 110, 80, 120, 26], [960, 245, 90, 95, 26], [945, 365, 95, 115, 30], [935, 500, 90, 120, 30], [915, 630, 100, 110, 30], [790, 2, 70, 50, 18], [990, -10, 60, 90, 20]]) {
        x.fillStyle = '#10161f'; x.fill(rrect(cx, cy, w, h, rr)); x.strokeStyle = 'rgba(58,78,98,0.7)'; x.lineWidth = 10; x.stroke(rrect(cx, cy, w, h, rr)); } }, 5);
      soft(x => { x.strokeStyle = 'rgba(70,90,110,0.5)'; x.lineWidth = 26;
        for (const pts of [[[960, -10], [940, 120], [990, 230], [1030, 260]], [[930, 300], [990, 360], [1030, 420]], [[950, 480], [1000, 540], [1030, 560]], [[920, 640], [980, 700]]]) x.stroke(P(pts, false, true)); }, 10);
      soft(x => { x.strokeStyle = 'rgba(240,160,50,0.9)'; x.lineWidth = 7;
        for (const pts of [[[876, 40], [884, 80], [888, 130], [900, 170], [912, 205]], [[880, 50], [905, 45], [935, 62], [948, 85]], [[918, 256], [930, 300], [930, 340], [922, 372]],
          [[985, 322], [1010, 312], [1030, 318]], [[960, 420], [990, 440], [1025, 460]]]) x.stroke(P(pts, false, true)); }, 4);
      soft(x => { x.fillStyle = '#ffd25a'; x.fill(circleP(1000, 322, 14)); x.fill(circleP(888, 58, 9)); }, 6);
    });
    soft(x => { x.strokeStyle = 'rgba(245,165,55,0.9)'; x.lineWidth = 5; x.stroke(P([[770, 50], [800, 70], [840, 105], [870, 130]], false, true));
      x.lineWidth = 7; x.stroke(P([[704, 700], [730, 680], [760, 650], [790, 615], [830, 590]], false, true)); x.stroke(P([[700, 640], [740, 625]], false, true)); }, 3);

    // ── 4. bronze plate with glass bubbles ──
    const PL = P(fp([925,449,902,449,892,422,842,420,839,433,818,445,766,458,738,434,729,460,636,514,570,599,534,622,482,635,482,700,526,710,537,725,584,725,595,704,627,685,655,701,645,725,671,725,678,712,705,702,725,706,732,725,780,725,816,693,841,690,852,662,825,656,819,636,852,622,881,590,899,583,913,591,909,628,918,630,929,570,912,556,907,529,929,511,921,486]), true, true);
    soft(x => { x.fillStyle = 'rgba(10,6,20,0.7)'; x.translate(-6, 10); x.fill(PL); }, 8);
    R.dome(PL, lin(560, 470, 880, 720, [[0, '#9a6054'], [0.45, '#7c4a46'], [1, '#664040']]), 0.2, 0.05, 12, 2);
    clipA(PL, () => { const r = rng(198); for (let i = 0; i < 260; i++) { a.fillStyle = r() < 0.5 ? 'rgba(255,220,150,0.5)' : 'rgba(60,30,20,0.4)'; a.fill(circleP(500 + r() * 420, 420 + r() * 306, 0.8 + r() * 1.6)); } });
    soft(x => { x.strokeStyle = 'rgba(255,170,60,0.95)'; x.lineWidth = 5; x.stroke(P([[505, 700], [530, 640], [570, 600], [630, 560], [690, 505], [740, 470], [800, 452], [850, 436], [885, 424]], false, true)); }, 3);
    for (const [x, y, r] of [[781,553,28],[664,629,26],[764,694,18],[585,659,16],[818,585,14],[678,672,14],[777,616,13],[546,719,13],[844,455,12],[832,498,12],[852,549,12],[731,646,12],[887,515,11],[712,495,20],[633,542,17],[754,454,6],[905,461,6],[906,513,6],[819,661,6],[629,686,6],[621,598,5],[569,635,5],[682,690,5],[572,608,4]]) {
      soft(c => { c.fillStyle = 'rgba(30,14,10,0.6)'; c.fill(circleP(x + 2, y + 3, r)); }, 2);
      R.bead(x, y, r, rad(x - r * 0.3, y - r * 0.3, 0, r * 1.2, [[0, '#e0e4f4'], [0.6, '#a8aed0'], [1, '#7a7aa8']]), 0.25, Math.min(0.3, 0.04 + r * 0.01), 3);
    }
    { a.save(); hx.save(); for (const c of [a, hx]) { c.translate(726, 590); c.rotate(0.35); c.translate(-726, -590); }
      R.dome(rrect(712, 572, 28, 36, 5), '#d8d8e4', 0.28, 0.04, 4, 3); R.flat(rrect(718, 580, 16, 20, 2), '#3a2a30', 0.3, 0); hx.restore(); a.restore(); }
    // dark lattice cells overlapping the plate's lower edge
    soft(x => { x.fillStyle = '#16202c'; x.fill(P([[700, 726], [740, 690], [790, 676], [830, 640], [880, 620], [920, 600], [940, 726]], true, true)); }, 3);
    soft(x => { x.strokeStyle = 'rgba(240,160,50,0.85)'; x.lineWidth = 6; x.stroke(P([[700, 726], [740, 690], [790, 676], [830, 640], [880, 620], [920, 595]], false, true)); }, 4);

    // ── 5. frosted glass disc with the ember eye ──
    const DC = circleP(597, 310, 128);
    soft(x => { x.fillStyle = 'rgba(160,180,230,0.25)'; x.fill(DC); }, 2);
    const CAP = new Path2D(); CAP.moveTo(472, 360); CAP.arc(597, 310, 128, Math.atan2(50, -125), Math.atan2(-78, 123));
    [[700, 225], [670, 232], [645, 240], [610, 255], [575, 268], [540, 285], [510, 300], [490, 330]].forEach(([x, y]) => CAP.lineTo(x, y)); CAP.closePath();
    R.dome(CAP, lin(500, 200, 680, 300, [[0, '#cdcde8'], [0.5, '#b4bce0'], [1, '#9eaad8']]), 0.18, 0.04, 14, 4);
    for (const [x, y, rx, ry, rr] of [[640, 230, 20, 11, -0.3], [512, 293, 16, 10, 0.2], [570, 252, 14, 6, -0.2], [690, 232, 12, 8, 0], [478, 340, 10, 20, 0.1], [552, 270, 10, 7, 0]]) {
      a.fillStyle = '#5a34d0'; a.fill(ellipseP(x, y, rx, ry, rr)); }
    a.lineWidth = 5; a.strokeStyle = 'rgba(180,196,240,0.9)'; a.stroke(DC);
    // glass ring around the eye
    { const gr = new Path2D(); gr.arc(619, 366, 92, 0, 6.2832); gr.arc(619, 366, 78, 0, 6.2832, true); R.dome(gr, null, 0.22, 0.05, 6, 4); a.fillStyle = 'rgba(170,186,236,0.3)'; a.fill(gr); a.lineWidth = 2; a.strokeStyle = 'rgba(200,215,250,0.8)'; a.stroke(circleP(619, 366, 91)); }
    // purple drip and lilac flow
    R.dome(P([[572, 405], [665, 405], [680, 440], [668, 478], [640, 498], [600, 500], [578, 482], [568, 445]], true, true), '#5c22c8', 0.24, 0.04, 8, 4);
    R.dome(P([[556, 480], [600, 490], [630, 502], [640, 530], [626, 560], [596, 566], [565, 548], [548, 512]], true, true), '#c08ae8', 0.2, 0.05, 10, 4);
    // eye
    R.dome(circleP(619, 366, 77), '#0e1428', 0.26, 0.04, 8, 4);
    a.lineWidth = 3.5; a.strokeStyle = '#8a40e8'; a.stroke(circleP(619, 366, 76));
    for (let i = 0; i < 26; i++) { const t = i / 26 * 6.2832; if (i % 5 === 3) continue;
      a.save(); a.translate(619 + Math.cos(t) * 60, 366 + Math.sin(t) * 60); a.rotate(t); a.fillStyle = i % 3 ? '#3858c8' : '#5a78e0'; a.fillRect(-7, -4, 14, 8); a.restore(); }
    R.flat(circleP(619, 366, 44), rad(619, 366, 4, 44, [[0, '#4a1608'], [0.3, '#b04a10'], [0.45, '#ffb030'], [0.7, '#fff0b0'], [0.85, '#ffb040'], [1, '#d05a10']]), 0.3, 0);
    clipA(circleP(619, 366, 40), () => { a.strokeStyle = 'rgba(255,240,180,0.85)'; a.lineWidth = 2; for (let i = 0; i < 18; i++) { const t = i / 18 * 6.2832; a.beginPath(); a.moveTo(619 + Math.cos(t) * 14, 366 + Math.sin(t) * 14); a.lineTo(619 + Math.cos(t) * 40, 366 + Math.sin(t) * 40); a.stroke(); } });
    a.fillStyle = '#2a0a06'; a.fill(circleP(619, 366, 10));
    R.flat(circleP(589, 316, 7), '#38e0f8', 0.3, 0);
    // small glass droplets on the zebra
    for (const [x, y, r] of [[798, 282, 9], [806, 408, 7], [740, 438, 6], [770, 312, 4], [408, 590, 7], [442, 602, 5], [472, 618, 6], [748, 104, 6], [785, 128, 7]]) R.bead(x, y, r, '#c8cce0', 0.15, 0.1, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.6, shin: 50, wrap: 0.5, ao: 0.3, coat: 0.15, rim: 0.4 }),               // 1 glossy zebra
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.45, ao: 0.4, grain: 0.2 }),                       // 2 bronze plate
        E.mat({ dif: 0.6, spec: 1.2, shin: 80, metal: 0.4, coat: 0.3, rim: 0.5 }),                      // 3 glass bubbles
        E.mat({ dif: 1, spec: 0.7, shin: 60, wrap: 0.5, coat: 0.2, rim: 0.5 })                          // 4 glass / jelly
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.75, 0.74, 0.8], amb: [0.34, 0.33, 0.38],
      envTop: [1.1, 1.1, 1.2], envHor: [0.5, 0.45, 0.8], envBot: [0.25, 0.15, 0.1], envK: [0.4, 1.4, 0.3, 0],
      rimC: [0.4, 0.45, 0.9], rimD: [-1, 0.4, 0.5], l2: [1, -0.2, 0.4, 2], l2c: [0.6, 0.35, 0.1], r1: 2, r2: 8, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.4, 6]
    });
    // ember glow
    o.save(); o.globalCompositeOperation = 'lighter'; o.fillStyle = rad(619, 366, 20, 95, [[0, 'rgba(255,170,60,0.55)'], [1, 'rgba(255,120,30,0)']], o); o.fillRect(500, 250, 240, 240); o.restore();
    E.bloom(0.14, 10);
    E.grain(0.035, 198);
  }
});
