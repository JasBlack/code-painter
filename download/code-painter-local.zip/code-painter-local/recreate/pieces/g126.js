'use strict';
// g126 — "Visor sage, zebra coat": a pop-comic profile — a grey halftone face behind a glass visor with green
// goggles, coral lips and a silver zebra-wave beard, curly brown hair under a pale headband, a red sun and a
// blue-striped "Vold" poster on lime, a black-and-white striped coat, a dark-haired figure and a pink-capped pole.
REC.register('g126', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const F = (path, c) => { o.fillStyle = c; o.fill(path); };
    const K = (path, c = INK, wd = 3) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const FK = (path, c, wd = 3) => { F(path, c); K(path, INK, wd); };
    const C = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const B = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const INK = '#060606', LIME = '#d1f288', RED = '#fc0220', NAVY = '#0c2a8c';

    // ── textures ──
    const halftone = (base, dot, sp, r0) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p / uSp; q.x += 0.5 * mod(floor(q.y), 2.);
      vec2 f = fract(q) - 0.5;
      float r = uR * (0.8 + 0.5 * hash(floor(q)));
      float d = smoothstep(r + 0.06, r - 0.06, length(f));
      return mix(uB, uD, d); }`, { uB: base, uD: dot, uSp: sp, uR: r0 }));
    const zebra = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = (p.x - 363.) / 100., v = (p.y - 512.) / 100.;   // phase fitted offline to the coat stripes
      float ph = 1.699 - 0.87122 * u + 1.93479 * v + 0.01914 * u * u + 0.04762 * u * v - 0.08285 * v * v;
      float s = fract(ph);
      float w = smoothstep(0.0, 0.03, s) * smoothstep(0.5, 0.47, s);
      return mix(vec3(0.015), vec3(0.98), w); }`));
    const hairT = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p * 0.018;
      float n = fbm(q + vec2(fbm(q * 1.5 + 3.1), fbm(q * 1.5 + 7.7)) * 1.4);
      float m = fbm(p * 0.03 + 11.);
      float band = sin(n * 28.);
      vec3 c = vec3(0.33, 0.23, 0.15);
      c = mix(c, vec3(0.64, 0.55, 0.42), smoothstep(0.0, 0.07, band));
      c = mix(c, vec3(0.95, 0.89, 0.66), smoothstep(0.86, 0.9, band) * smoothstep(0.45, 0.5, m));
      c = mix(c, vec3(0.20, 0.13, 0.08), smoothstep(-0.8, -0.86, band));
      return c; }`));
    const beardT = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = normalize(vec2(-0.78, 0.62));
      vec2 nrm = vec2(d.y, -d.x);
      float t = dot(p, d), s = dot(p, nrm);
      float w = fbm(p * 0.006) * 70. + 12. * sin(t * 0.026 + s * 0.006) + 2. * sin(t * 0.07);
      float ph = (s + w) / 46.;
      float k = sin(6.2832 * ph) + 0.35 * (fbm(p * 0.02 + 9.) - 0.5);
      vec3 c = vec3(0.74, 0.84, 0.90);
      c = mix(c, vec3(0.29, 0.34, 0.38), smoothstep(0.22, 0.36, k));
      float hl = sin(6.2832 * (ph + 0.5) * 1.0 + fbm(p * 0.03) * 3.);
      c = mix(c, vec3(0.97, 0.98, 1.0), smoothstep(0.82, 0.92, hl) * smoothstep(0.3, 0.6, fbm(p * 0.02 + 4.)));
      return c; }`));

    // ── lime ground ──
    F(rrect(0, 0, 726, 1024, 0), LIME);

    // ── "Vold" poster: red header, blue-striped sheet ──
    F(rrect(0, 0, 182, 492, 0), '#f6fdfd');
    F(rrect(0, 0, 182, 83, 0), RED);
    F(rrect(0, 99, 182, 20, 0), RED);
    for (const [y0, y1] of [[138, 150], [171, 182], [200, 209], [225, 236], [248, 258], [274, 284], [296, 310], [325, 335], [350, 360], [372, 381], [402, 415], [430, 439], [453, 460], [471, 481]])
      F(rrect(0, y0, 182, y1 - y0, 0), '#4a9de2');
    o.save(); o.font = 'bold 80px Arial, Helvetica, sans-serif'; o.fillStyle = '#ffffff'; o.textBaseline = 'alphabetic';
    o.translate(8, 53); o.scale(0.82, 1); o.fillText('Vold', 0, 0); o.restore();

    // ── red sun with a hot orange rim ──
    B(9, () => F(circleP(272, 292, 166), '#f6701c'));
    B(4, () => F(circleP(272, 292, 152), RED));

    // ── snow dots ──
    for (const [x, y, r] of [[290, 55, 7], [265, 103, 7], [107, 293, 7], [160, 325, 7], [55, 403, 5], [104, 422, 6], [56, 470, 5], [130, 475, 4],
      [57, 533, 8], [27, 617, 8], [128, 590, 5], [100, 688, 10], [105, 736, 8], [10, 712, 8], [125, 885, 9], [65, 543, 4]])
      F(circleP(x, y, r), '#ffffff');

    // ── pole with a pink cap (bottom-left) ──
    const pole = poly([[-10, 640], [20, 660], [92, 905], [60, 935], [-10, 940]]);
    FK(pole, '#ef5a2c', 3);
    F(poly([[-10, 662], [8, 675], [70, 915], [40, 935], [-10, 935]]), '#86362a');
    FK(poly([[-10, 925], [88, 912], [96, 945], [-10, 960]]), '#f36c80', 3);
    FK(poly([[-10, 958], [70, 950], [76, 995], [-10, 1000]]), '#f36c80', 3);
    FK(poly([[-10, 995], [96, 985], [100, 1034], [-10, 1034]]), '#f36c80', 3);

    // ── striped coat ──
    const coat = poly([[40, 830], [160, 792], [582, 538], [556, 760], [576, 1034], [70, 1034], [60, 900]]);
    F(coat, zebra);
    // halftone strip beside the coat
    const strip = poly([[548, 680], [600, 680], [630, 1034], [560, 1034]]);
    F(strip, halftone([0.62, 0.62, 0.64], [0.05, 0.05, 0.06], 4.2, 0.26));

    // ── dark-haired figure: black hair, neck, navy collar, grey shirt, blue panel ──
    const hairBk = P([[600, 300], [640, 290], [690, 140], [726, 150], [726, 760], [600, 740], [560, 742], [548, 712], [530, 726], [520, 700], [500, 714], [490, 690],
      [470, 702], [466, 668], [452, 680], [450, 640], [500, 590], [560, 540], [600, 470]], true, false);
    F(hairBk, '#050304');
    { const r = rng(126); for (let i = 0; i < 14; i++) { const x = 470 + r() * 90, y = 600 + r() * 60; K(P([[x, y], [x - 6 + r() * 6, y + 40 + r() * 40]], false), '#050304', 6); } }
    const neck = P([[628, 505], [640, 510], [644, 560], [652, 610], [662, 646], [600, 650], [546, 646], [574, 612], [600, 580], [618, 540]]);
    F(neck, '#f8b688');
    const shirt = poly([[536, 640], [726, 610], [726, 1034], [600, 1034], [570, 900], [548, 760]]);
    F(shirt, halftone([0.55, 0.55, 0.58], [0.04, 0.04, 0.05], 4.0, 0.3));
    const collar = P([[530, 628], [600, 648], [660, 640], [716, 612], [726, 660], [700, 684], [620, 694], [545, 690]]);
    FK(collar, NAVY, 3);
    const panel = P([[600, 790], [626, 760], [690, 742], [726, 740], [726, 1034], [620, 1034], [604, 930]]);
    F(panel, '#45a6f6');
    K(P([[596, 800], [612, 760], [660, 742], [726, 735]], false), '#9a9a9e', 10);
    K(P([[596, 800], [592, 900], [604, 970]], false), '#9a9a9e', 10);
    K(P([[590, 790], [606, 750], [660, 732], [726, 727]], false), INK, 2);
    FK(rrect(642, 712, 22, 34, 3), '#f06aa0', 2);

    // ── ear + earring ──
    const ear = P([[655, 200], [690, 168], [726, 172], [726, 340], [700, 348], [668, 332], [652, 290], [650, 240]]);
    F(ear, '#f8b688');
    F(P([[684, 215], [705, 200], [726, 210], [726, 300], [706, 300], [700, 270], [712, 250], [700, 232]]), INK);
    K(P([[690, 128], [676, 170], [656, 230], [644, 300], [644, 340], [652, 400]], false), '#ffffff', 3);
    K(circleP(676, 338, 7), INK, 3); F(circleP(676, 338, 4), '#4a6a80');
    K(P([[676, 345], [668, 370], [676, 398], [686, 380], [682, 352]], false), '#ffffff', 2);

    // ── curly brown hair ──
    const hair = P([[465, 45], [520, 0], [726, 0], [726, 150], [690, 140], [672, 190], [650, 250], [640, 300], [600, 315], [545, 320], [505, 356], [478, 380], [458, 360],
      [470, 330], [500, 305], [530, 282], [556, 255], [560, 215], [540, 165], [520, 120], [500, 80]]);
    FK(hair, hairT, 3);

    // ── face (grey halftone) ──
    const face = P([[352, 36], [470, 42], [500, 78], [528, 122], [552, 175], [565, 230], [552, 262], [512, 300], [482, 335], [468, 384], [430, 440], [380, 480], [330, 498],
      [302, 500], [300, 460], [282, 440], [276, 388], [288, 350], [294, 334], [282, 315], [262, 300], [250, 290], [300, 236], [338, 100]]);
    F(face, halftone([0.68, 0.66, 0.70], [0.04, 0.04, 0.06], 5.2, 0.22));
    K(face, INK, 3);
    // blush
    C(face, () => F(ellipseP(500, 260, 36, 18, -0.35), halftone([0.95, 0.35, 0.45], [0.55, 0.05, 0.12], 4.6, 0.24)));

    // ── glass visor: outline from the forehead down past the nose, pink glow inside ──
    const glassIn = poly([[262, 300], [282, 318], [292, 340], [282, 370], [276, 395], [282, 440], [300, 462], [302, 505], [280, 515], [212, 540], [250, 300]]);
    C(glassIn, () => {
      F(glassIn, LIME);
      F(poly([[200, 280], [320, 280], [320, 440], [200, 470]]), '#f9718c');
      B(14, () => F(poly([[240, 420], [320, 420], [320, 470], [230, 480]]), '#f3a090'));
    });
    const visor = P([[352, 24], [338, 72], [314, 92], [294, 116], [282, 160], [276, 210], [262, 252], [248, 288], [205, 545]], false);
    K(visor, INK, 9); K(visor, '#ffffff', 5);
    K(P([[340, 40], [326, 84], [300, 104]], false), '#c8e890', 3);
    // nose fly
    FK(P(blob(244, 268, 20, 14, 7, 9, 0.45)), '#59636c', 2);

    // ── goggles ──
    const gog = (cx, cy, rx, ry, rot) => {
      F(ellipseP(cx + 6, cy + 8, rx + 10, ry + 10, rot), INK);
      F(ellipseP(cx, cy, rx + 8, ry + 8, rot), NAVY);
      K(ellipseP(cx, cy, rx + 8, ry + 8, rot), INK, 2.5);
      FK(ellipseP(cx, cy, rx, ry, rot), '#62935c', 2.5);
    };
    gog(428, 170, 60, 66, -0.15);
    F(circleP(410, 145, 18), '#ffffff');
    K(P([[428, 150], [460, 160]], false), '#ffffff', 10);
    gog(318, 180, 26, 52, 0.18);
    F(circleP(306, 152, 12), '#ffffff'); K(P([[316, 164], [326, 166]], false), '#ffffff', 6);

    // ── nose, lips, teeth ──
    K(P([[300, 262], [320, 280], [326, 300], [316, 316], [292, 322]], false), INK, 5);
    F(P([[262, 300], [288, 312], [300, 326], [290, 334], [272, 320]]), INK);
    const lips = P([[278, 388], [300, 382], [340, 384], [390, 382], [428, 388], [400, 410], [370, 430], [340, 450], [312, 462], [298, 452], [300, 432], [290, 410]]);
    FK(lips, '#f3355c', 3);
    F(P([[302, 410], [330, 402], [380, 396], [416, 392], [390, 412], [350, 430], [312, 434]]), '#1a0606');
    F(P([[304, 412], [330, 404], [384, 398], [410, 394], [396, 406], [350, 418], [312, 424]]), '#f2e6aa');
    for (let i = 0; i < 6; i++) K(P([[318 + i * 15, 404 - i * 1.5], [320 + i * 15, 422 - i * 3]], false), '#8a7040', 2);
    K(P([[300, 393], [320, 390]], false), '#ffc8d4', 4); K(P([[322, 448], [340, 442]], false), '#ffc8d4', 4);

    // ── headband ──
    const band = P([[340, 30], [372, 8], [430, 0], [500, 0], [565, 26], [627, 54], [690, 86], [726, 100], [726, 165], [690, 142], [627, 108], [565, 79], [500, 52], [440, 34], [380, 44], [348, 48]]);
    FK(band, '#bcd6e4', 3);
    K(P([[346, 44], [380, 38], [440, 30], [500, 48], [565, 75], [627, 104], [690, 138], [726, 160]], false), NAVY, 6);
    K(P([[350, 26], [380, 10], [430, 2], [500, 4], [565, 30], [627, 58], [690, 90], [726, 104]], false), NAVY, 5);
    FK(poly([[700, 64], [726, 70], [726, 148], [702, 134]]), NAVY, 2);

    // ── zebra-wave beard + black underside ──
    const under = poly([[600, 520], [520, 540], [440, 556], [370, 580], [300, 620], [250, 680], [200, 740], [160, 792]]);
    F(under, INK);
    C(under, () => { const r = rng(9); for (let i = 0; i < 18; i++) { const x = 280 + r() * 260, y = 570 + r() * 110, L = 30 + r() * 60;
      K(P([[x, y], [x + L * 0.4, y - L * 0.5], [x + L * 0.6, y - L * 0.7]], false), r() < 0.5 ? '#4c5a64' : '#9ab4c4', 2 + r() * 4); } });
    const beard = P([[640, 304], [648, 400], [600, 470], [602, 522], [584, 534], [540, 547], [490, 557], [440, 568], [400, 582], [360, 606], [330, 636], [305, 666], [290, 692], [230, 740], [152, 792],
      [165, 710], [190, 622], [202, 541], [221, 525], [246, 529], [277, 510], [302, 500], [346, 491], [421, 454], [452, 397], [477, 379], [507, 358], [544, 317], [586, 308], [619, 292]]);
    FK(beard, beardT, 3.5);
    K(P([[584, 538], [160, 794]], false), INK, 5); K(P([[584, 538], [270, 728]], false), '#ffffff', 2.5);

    E.grain(0.03, 126);
  }
});
