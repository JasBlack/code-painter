'use strict';
// s26 — "Iridescent wreck on mint": a low-poly slate-and-khaki wreck — a draped cloth, a long
// dagger spike, leaning poles — carrying rainbow crystal bars and a crumpled black mass with
// white cloud puffs, against a flat mint sky.
REC.register('s26', {
  w: 1024, h: 1024,
  draw(E) {
    const W = 1024, H = 1024, S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const poly = pts => P(pts, true, false);
    const SL = '#3c3e54', SLD = '#23262f', SLL = '#55566c', KH = '#9d966e', KHD = '#6e6c58';

    // ── mint sky ──
    fill(rrect(0, 0, W, H, 0), lin(0, 0, 1024, 500, [[0, '#7de2d4'], [0.4, '#a2ece2'], [1, '#c8f6ee']]));
    fill(rrect(0, 0, W, H, 0), lin(0, 1024, 0, 0, [[0, 'rgba(160,236,226,0.6)'], [0.5, 'rgba(160,236,226,0)']]));
    // soft cast shadow of the spike on the sky
    blurred(18, () => fill(poly([[30, 490], [300, 560], [330, 640], [200, 620]]), 'rgba(40,120,110,0.35)'));

    // procedural textures
    const crumple = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = vec2(p.x * .8 + p.y * .6, -p.x * .6 + p.y * .8);
      float n = fbm(q * vec2(.05, .012)), m = fbm(p * .03 + 5.), r = fbm(q * vec2(.12, .03) + 9.);
      float ridge = pow(1. - abs(2. * r - 1.), 6.);
      vec3 c = mix(vec3(.03, .035, .045), vec3(.13, .14, .16), n);
      c += ridge * vec3(.42, .44, .42) * smoothstep(.35, .75, m) + pow(ridge, 3.) * .25;
      return c; }`));
    const prism = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = vec2(.707, -.707); float t = dot(p, vec2(.707, .707));   // across the bar
      float a = dot(p, d);
      float f = fbm(vec2(t * .03, a * .006)), g = fbm(p * .012 + 4.);
      vec3 c = mix(vec3(.10, .76, .58), vec3(.55, .86, .22), smoothstep(.35, .7, g));
      float st = fract(t * .022 + .4 * f);
      c = mix(c, vec3(1., .62, .12), smoothstep(.80, .84, st) * (1. - smoothstep(.9, .94, st)));
      c = mix(c, vec3(.95, .35, .75), smoothstep(.90, .93, st));
      c = mix(c, vec3(.12, .2, .22), .35 * step(.55, fract(t * .06 + .3 * g)));
      c *= .85 + .3 * f;
      return c; }`));
    const mosaic = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 g = floor(p / 9. + vec2(fbm(p * .03) * 3.)); float h = hash(g), k = hash(g + 3.3);
      vec3 c = h < .45 ? vec3(.12, .78, .62) : h < .6 ? vec3(.98, .55, .08) : h < .7 ? vec3(.6, .15, .7) : h < .85 ? vec3(.18, .2, .26) : vec3(.45, .9, .8);
      return c * (.7 + .4 * k); }`));

    // ── khaki block + the long dagger spike (left) ──
    fill(poly([[200, 415], [330, 408], [360, 470], [330, 520], [215, 500]]), lin(200, 410, 330, 520, [[0, KH], [1, KHD]]));
    fill(poly([[212, 418], [250, 412], [236, 440]]), '#67d8c6');
    const spikeTop = poly([[14, 470], [230, 440], [330, 470], [340, 520]]);
    const spikeBot = poly([[14, 470], [340, 520], [340, 610], [250, 580]]);
    fill(spikeTop, lin(14, 470, 330, 470, [[0, '#4a4b62'], [1, '#3a3b50']]));
    fill(spikeBot, lin(14, 470, 300, 600, [[0, '#2a2c3a'], [1, '#1c1e28']]));
    fill(poly([[250, 580], [340, 560], [360, 620], [300, 620]]), '#8a88b0');

    // ── draped slate cloth ──
    const cloth = P([[296, 112], [318, 156], [408, 192], [476, 210], [536, 198], [600, 176], [640, 240], [560, 320], [480, 380], [420, 430], [360, 450], [330, 400], [300, 320], [279, 272], [272, 230], [276, 196], [290, 150]]);
    fill(cloth, lin(280, 120, 560, 380, [[0, '#4a4a5e'], [0.3, '#3a3a50'], [0.55, '#55546a'], [1, '#2e2f40']]));
    clipped(cloth, () => blurred(14, () => {
      fill(ellipseP(360, 230, 40, 26, 0.3), '#1e1f2c'); fill(ellipseP(430, 260, 60, 20, 0.5), '#262838');
      fill(ellipseP(320, 180, 30, 50, 0.2), '#6a6878'); fill(ellipseP(470, 300, 60, 16, -0.2), '#6e6a6a');
      fill(ellipseP(300, 300, 30, 16, 0.6), '#7a7468'); fill(ellipseP(520, 250, 40, 20, 0), '#8a8468');
    }));

    // ── leaning poles and columns (behind the crystals) ──
    const pole = (x0, y0, x1, y1, w0, w1, c) => {
      const dx = x1 - x0, dy = y1 - y0, L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
      const pth = poly([[x0 - nx * w0 / 2, y0 - ny * w0 / 2], [x1 - nx * w1 / 2, y1 - ny * w1 / 2], [x1 + nx * w1 / 2, y1 + ny * w1 / 2], [x0 + nx * w0 / 2, y0 + ny * w0 / 2]]);
      fill(pth, c); return pth;
    };
    // dark backing of the lower wreck
    fill(P([[340, 560], [470, 470], [560, 420], [640, 600], [760, 720], [860, 800], [1024, 700], [1024, 1030], [330, 1030]], true, false), lin(340, 500, 1024, 1024, [[0, '#35374a'], [0.5, '#4a4a52'], [1, '#6a6858']]));
    // big khaki column
    const colA = poly([[330, 1030], [450, 1030], [560, 330], [470, 320]]);
    fill(colA, lin(330, 1000, 560, 330, [[0, '#56574c'], [0.5, '#7a7660'], [1, '#8a8468']]));
    fill(poly([[430, 1030], [450, 1030], [560, 330], [540, 328]]), '#2a2c32');
    pole(250, 1030, 400, 540, 26, 20, '#1a1c24');
    pole(214, 1030, 362, 510, 8, 6, '#121418');
    pole(292, 1030, 420, 560, 6, 5, 'rgba(160,150,120,0.8)');
    pole(300, 1030, 470, 470, 40, 34, '#2c2e38');

    // ── crumpled black mass (right) ──
    const mass = P(ragged([[560, 330], [640, 290], [720, 270], [810, 250], [860, 262], [900, 300], [960, 340], [1024, 380], [1024, 700], [960, 740], [900, 780], [860, 800], [800, 760], [720, 700], [640, 640], [580, 560], [560, 460]], 0, 17, 9, 8, 26), true, false);
    fill(mass, crumple);
    clipped(mass, () => blurred(20, () => { fill(ellipseP(640, 400, 70, 60, 0), 'rgba(90,90,110,0.5)'); fill(ellipseP(940, 560, 60, 90, 0), 'rgba(10,12,14,0.6)'); }));
    // white cloud puffs
    for (const [x, y, r, sd] of [[842, 347, 20, 1], [752, 490, 30, 2], [775, 520, 16, 3], [895, 555, 42, 4], [906, 612, 34, 5], [872, 522, 18, 6]]) {
      fill(P(blob(x, y, r * 1.05, r, sd, 11, 0.22)), '#f4f6fc'); fill(P(blob(x + r * 0.3, y + r * 0.3, r * 0.55, r * 0.5, sd + 9, 9, 0.2)), '#cfd0ee');
    }
    blurred(4, () => { for (const [x, y, r] of [[842, 347, 18], [752, 487, 28], [895, 560, 38]]) fill(circleP(x - r * 0.2, y - r * 0.2, r * 0.6), 'rgba(255,255,255,0.8)'); });

    // ── the black spike (top right) ──
    pole(710, 66, 862, 266, 22, 10, '#1a1c22');
    stroke(P([[705, 60], [856, 262]], false), 'rgba(120,200,170,0.5)', 1.5);

    // ── rainbow crystals ──
    const topC = poly([[606, 150], [628, 102], [660, 82], [700, 60], [726, 46], [740, 70], [736, 110], [760, 170], [700, 230], [640, 200]]);
    fill(topC, mosaic);
    fill(poly([[700, 60], [726, 46], [740, 70], [716, 80]]), '#f8a020');
    // long prism bar: two faces
    const barTop = poly([[322, 452], [610, 172], [680, 176], [398, 468]]);
    const barSide = poly([[398, 468], [680, 176], [748, 238], [456, 536]]);
    fill(barSide, prism);
    fill(barTop, lin(322, 452, 680, 176, [[0, '#28c89e'], [0.4, '#58d890'], [0.7, '#2ad0a0'], [1, '#2cc8a8']]));
    clipped(barTop, () => { for (let i = 0; i < 14; i++) stroke(P([[330 + i * 6, 450 + i * 2], [620 + i * 5, 172 + i * 1]], false), i % 3 ? 'rgba(160,250,190,0.5)' : 'rgba(20,90,70,0.5)', 2); });
    // magenta/orange end cap
    const cap = poly([[610, 172], [680, 176], [774, 262], [760, 298], [690, 230], [620, 200]]);
    fill(cap, lin(620, 180, 770, 290, [[0, '#6a1a8a'], [0.25, '#e04ad0'], [0.45, '#ffa010'], [0.6, '#f04ab0'], [0.8, '#8a2ab0'], [1, '#3a1a5a']]));
    clipped(cap, () => { for (let i = 0; i < 8; i++) stroke(P([[600 + i * 10, 176 + i * 4], [700 + i * 10, 260 + i * 4]], false), i % 2 ? '#fcb030' : '#5a1a7a', 3); });
    // lower bar with yellow/pink bands
    const lowBar = poly([[330, 470], [420, 420], [470, 520], [400, 590], [360, 560]]);
    fill(lowBar, lin(330, 470, 470, 560, [[0, '#9ad040'], [0.3, '#f0c040'], [0.5, '#f090a0'], [0.7, '#b0d060'], [1, '#30c0a0']]));
    fill(poly([[318, 420], [350, 400], [360, 450], [330, 480]]), mosaic);
    stroke(P([[330, 440], [350, 520]], false), '#ffb020', 4);
    // dark facets across the join

    // ── lower wreck: planes and a wireframe leaf ──
    fill(poly([[470, 640], [560, 600], [680, 640], [720, 760], [640, 820], [520, 780]]), lin(470, 600, 720, 820, [[0, '#2c2e3a'], [1, '#3e404c']]));
    const leaf = poly([[548, 616], [600, 650], [650, 700], [660, 760], [620, 740], [570, 690]]);
    fill(leaf, '#202630');
    clipped(leaf, () => { for (let i = 0; i < 9; i++) stroke(P([[548 + i * 12, 616 + i * 14], [560 + i * 10, 690 + i * 8]], false), 'rgba(200,210,200,0.6)', 1); });
    stroke(P([[530, 540], [640, 585]], false), '#8a3ad0', 4);
    fill(poly([[560, 800], [720, 780], [800, 860], [760, 1030], [520, 1030]]), lin(560, 800, 760, 1030, [[0, '#3a3c48'], [1, '#2a2c36']]));
    fill(poly([[480, 900], [560, 880], [600, 1030], [480, 1030]]), lin(480, 900, 600, 1030, [[0, KH], [1, '#8a8264']]));
    fill(poly([[440, 760], [500, 720], [560, 800], [520, 880], [470, 860]]), '#454652');
    // right: khaki and slate planes
    fill(poly([[720, 700], [860, 800], [1024, 700], [1024, 1030], [760, 1030], [790, 880]]), lin(760, 700, 1024, 1030, [[0, '#4a4c56'], [0.5, '#6a6a64'], [1, '#8a8468']]));
    fill(poly([[860, 820], [1024, 740], [1024, 1030], [900, 1030]]), lin(860, 820, 1024, 1030, [[0, '#8a8466'], [1, '#a2926e']]));
    fill(poly([[930, 720], [1024, 680], [1024, 760], [960, 800]]), '#2a2e38');
    fill(poly([[800, 880], [880, 850], [900, 1030], [820, 1030]]), '#6a6e60');
    stroke(P([[940, 740], [1020, 820]], false), 'rgba(180,180,160,0.7)', 1.5);
    // the vertical dark pole (front)
    const pl = pole(650, 1030, 725, 650, 40, 30, '#2a2c34');
    fill(poly([[665, 1030], [675, 1030], [740, 650], [730, 650]]), 'rgba(140,140,150,0.6)');

    // painterly softening + grain
    E.draw(E.blur(E.snapshot(), 0.8), 0.6);
    E.grain(0.035, 26);
  }
});
