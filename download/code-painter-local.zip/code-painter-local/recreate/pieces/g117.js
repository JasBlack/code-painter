'use strict';
// g117 — "Silver zebra-faced idol": a lumpy satin-silver head on a pink ground, an iridescent blue crest and eye,
// a zebra-striped face with rainbow goggles, spiral discs, engraved "O"s and a black gaping mouth, on a chrome plinth.
REC.register('g117', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const area = pts => pts.reduce((s, p, i) => { const q = pts[(i + 1) % pts.length]; return s + p[0] * q[1] - q[0] * p[1]; }, 0);
    const holeOf = (outer, pts) => Math.sign(area(outer)) === Math.sign(area(pts)) ? pts.slice().reverse() : pts;
    const ell = (cx, cy, rx, ry, rot, n = 40) => { const pts = []; for (let i = 0; i < n; i++) { const t = i / n * 6.2832; const x = Math.cos(t) * rx, y = Math.sin(t) * ry; pts.push([cx + x * Math.cos(rot) - y * Math.sin(rot), cy + x * Math.sin(rot) + y * Math.cos(rot)]); } return pts; };

    // ── textures ──
    const pink = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.91, .74, .76), vec3(.98, .78, .81), smoothstep(0., 700., p.x));
      c += (fbm(p * 0.006) - .5) * vec3(.05, .04, .04);
      return c; }`));
    const faceZ = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = (p - vec2(428.1, 295.6)) / 100.; float u = q.x, v = q.y;
      float ph = 4.76313*v + 0.06310*v*v + 0.47625*v*v*v + -0.28300*u + 0.78977*u*v + 0.01773*u*v*v + -0.38322*u*u + -0.15208*u*u*v + 0.25569*u*u*u + 0.2411;
      float s = cos(6.2832 * ph);
      return mix(vec3(.04, .04, .05), vec3(.93, .93, .92), smoothstep(-0.15, 0.15, s)); }`));
    const spiral = (cx, cy, per, k, off, sy) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)}); d.y /= ${sy.toFixed(3)};
      d += 7. * vec2(vnoise(p * 0.02) - .5, vnoise(p * 0.03 + 7.) - .5);
      float ph = length(d) / ${per.toFixed(2)} + ${k.toFixed(1)} * atan(d.y, d.x) / 6.2832 + ${off.toFixed(3)};
      float s = cos(6.2832 * ph);
      return mix(vec3(.03, .03, .04), vec3(.93, .93, .92), smoothstep(-0.2, 0.2, s)); }`));
    const rainbow = (cx, cy, r) => { const g = a.createRadialGradient(cx + r * 0.2, cy + r * 0.25, 2, cx, cy, r);
      g.addColorStop(0, '#f8a838'); g.addColorStop(0.35, '#f8d030'); g.addColorStop(0.6, '#a8f060'); g.addColorStop(0.8, '#50e8c8'); g.addColorStop(0.92, '#7080f0'); g.addColorStop(1, '#c060e0'); return g; };

    // ── pink ground ──
    R.flat(rrect(-10, -10, 746, 1044, 0), pink, 0, 0);

    // ── plinth below the head ──
    const PL = P([[60, 1034], [66, 965], [120, 940], [380, 930], [640, 940], [692, 968], [700, 1034]]);
    const pg = a.createLinearGradient(60, 0, 700, 0);
    for (const [t, c] of [[0, '#3a6a8a'], [0.12, '#60b8b8'], [0.22, '#e8f4f8'], [0.37, '#c8c0ec'], [0.6, '#606aa0'], [0.8, '#6070d8'], [0.93, '#6a98ac'], [1, '#504060']]) pg.addColorStop(t, c);
    R.dome(PL, pg, 0.1, 0.16, 40, 4);
    clipA(PL, () => soft(x => { x.fillStyle = '#7a7a84'; x.fill(ellipseP(380, 950, 300, 40, 0)); }, 14, 0.8));
    R.dome(ellipseP(378, 948, 228, 42, 0), '#9a9c9c', 0.3, 0.05, 8, 3);
    R.dome(ellipseP(378, 952, 212, 32, 0), '#484a5e', 0.31, 0.03, 6, 3);
    { const wr = rng(17); for (let k = 0; k < 5; k++) { const pts = []; for (let x = 180; x <= 580; x += 8) pts.push([x, 948 + k * 3 + Math.sin(x * 0.07 + k * 1.7) * 4 + (wr() - 0.5) * 2]);
      a.lineWidth = 1.6; a.strokeStyle = ['#d8e8f0', '#b8a8f0', '#90d8c8', '#e8e0f8', '#a0b0e8'][k]; a.stroke(P(pts, false, true)); } }
    R.pipe(P(ell(378, 948, 222, 38, 0, 60), true, true), 5, '#c8ccd0', 0.36, 0.03, 3);
    R.dome(P([[-10, 920], [30, 905], [80, 912], [108, 945], [100, 1000], [80, 1034], [-10, 1034]]), '#3048b0', 0.12, 0.2, 30, 4);
    clipA(P([[-10, 920], [30, 905], [80, 912], [108, 945], [100, 1000], [80, 1034], [-10, 1034]]), () => soft(x => { x.fillStyle = '#60e8f0'; x.fill(ellipseP(20, 985, 25, 40, 0)); }, 10, 0.9));
    R.dome(P([[736, 930], [700, 940], [682, 975], [686, 1034], [736, 1034]]), '#1c3a44', 0.12, 0.2, 24, 4);

    // ── the head ──
    const HEAD = [[760, 80], [736, 86], [700, 98], [623, 144], [575, 157], [514, 154], [404, 128], [344, 131], [291, 147], [251, 171], [221, 200], [164, 289], [137, 305], [108, 340], [41, 378], [-10, 418],
      [-10, 819], [64, 881], [140, 912], [260, 920], [400, 922], [520, 918], [606, 917], [676, 892], [736, 854], [760, 700], [760, 300]];
    const FACE = [[330, 245], [390, 237], [450, 237], [500, 251], [520, 280], [525, 340], [532, 380], [545, 420], [541, 460], [512, 478], [500, 502], [495, 540], [480, 575], [445, 596], [400, 596], [368, 580], [350, 545],
      [344, 510], [320, 490], [298, 458], [292, 410], [297, 350], [304, 300], [314, 264]];
    const MOUTH = [[441, 658], [425, 656], [409, 662], [386, 692], [379, 718], [384, 770], [378, 805], [357, 834], [318, 853], [308, 867], [309, 874], [332, 899], [348, 897], [372, 878], [386, 873], [416, 873], [432, 885],
      [444, 888], [451, 874], [469, 860], [467, 843], [451, 815], [448, 781], [453, 761], [473, 744], [481, 711], [456, 669]];
    const SP1 = ell(655, 278, 76, 92, 0.1), SP2 = ell(118, 802, 92, 82, 0.15);
    const head = P(HEAD, true, true);
    for (const h of [FACE, MOUTH, SP1, SP2]) head.addPath(P(holeOf(HEAD, h), true, true));
    const hg = a.createLinearGradient(0, 120, 0, 920);
    hg.addColorStop(0, '#b8bcc8'); hg.addColorStop(0.35, '#c8cad4'); hg.addColorStop(0.6, '#e0e2e8'); hg.addColorStop(0.8, '#c4c4c4'); hg.addColorStop(1, '#9a9c9c');
    R.dome(head, hg, 0.1, 0.26, 110, 1);
    // engraved grey letters and grooves (sunk a little)
    const OB = [[598, 656], [565, 671], [538, 709], [525, 762], [525, 809], [535, 837], [561, 863], [582, 871], [634, 873], [673, 856], [695, 826], [706, 777], [706, 727], [695, 696], [669, 669], [653, 662], [631, 668], [619, 658]];
    const OBi = [[627, 697], [610, 704], [597, 719], [581, 774], [582, 820], [604, 842], [631, 827], [649, 776], [648, 720]];
    const OT = [[615, 433], [595, 443], [572, 475], [562, 523], [566, 565], [593, 604], [615, 614], [643, 612], [667, 619], [688, 609], [709, 579], [710, 502], [696, 469], [676, 446]];
    const OTi = [[644, 465], [624, 478], [613, 522], [615, 568], [634, 595], [645, 600], [664, 573], [671, 535], [667, 490], [659, 475]];
    for (const [out, inn] of [[OB, OBi], [OT, OTi]]) {
      const pth = P(out, true, true); pth.addPath(P(holeOf(out, inn), true, true));
      R.dome(pth, null, 0.36, -0.035, 10, 1);
      soft(x => { x.fillStyle = '#78787e'; x.fill(pth); }, 4);
      soft(x => { x.fillStyle = '#d4d6f4'; x.fill(P(inn, true, true)); }, 4);
    }
    const GR = [[[27, 758], [36, 813], [53, 839], [72, 848], [73, 859], [124, 880], [154, 876], [163, 884], [192, 873], [204, 860], [202, 786], [191, 786], [176, 765], [121, 724], [101, 720], [67, 728]],
      [[216, 673], [210, 681], [215, 701], [250, 722], [256, 770], [290, 764], [285, 742], [294, 723], [275, 702], [275, 669], [246, 665]],
      [[195, 457], [177, 471], [149, 546], [132, 560], [144, 584], [157, 584], [165, 575]],
      [[231, 517], [206, 521], [198, 534], [189, 577], [196, 598], [212, 597], [224, 584]],
      [[582, 383], [599, 396], [646, 397], [696, 414], [686, 398], [634, 380]]];
    for (const g of GR) { const p = P(g, true, true); R.dome(p, null, 0.36, -0.03, 10, 1); soft(x => { x.fillStyle = '#86868a'; x.fill(p); }, 6, 0.9); }
    soft(x => { x.fillStyle = '#8a8a8e'; x.fill(P([[205, 655], [330, 650], [335, 690], [210, 700]])); x.fill(ellipseP(150, 500, 22, 40, 0.3)); x.fill(ellipseP(60, 520, 18, 50, 0.2)); x.fill(ellipseP(60, 620, 14, 40, 0)); }, 10, 0.7);
    // grey soft mouth surround
    soft(x => { x.strokeStyle = '#707070'; x.lineWidth = 30; x.stroke(P(MOUTH, true, true)); }, 10, 0.8);
    soft(x => { x.strokeStyle = '#6a6a66'; x.lineWidth = 26; x.stroke(P([[40, 860], [140, 905], [300, 918], [450, 918], [606, 912], [690, 885]], false)); }, 14, 0.7);
    // bright horizontal sheen band
    soft(x => { x.fillStyle = '#ffffff'; x.fill(P([[0, 590], [300, 600], [560, 618], [736, 630], [736, 655], [500, 650], [250, 640], [0, 625]])); }, 14, 0.85);

    // ── iridescent crest ──
    const CREST = [[200, 300], [214, 250], [248, 196], [300, 155], [350, 132], [420, 132], [480, 148], [516, 165], [512, 204], [470, 212], [400, 212], [330, 214], [285, 228], [258, 262], [236, 300]];
    const cg = a.createLinearGradient(210, 300, 510, 150); cg.addColorStop(0, '#1898a0'); cg.addColorStop(0.3, '#2860a0'); cg.addColorStop(0.6, '#3434a0'); cg.addColorStop(1, '#4a3cb0');
    R.dome(P(CREST, true, true), cg, 0.3, 0.12, 30, 2);
    // the eye lobe
    const EYEL = ell(170, 342, 66, 50, -0.45);
    const eg = a.createLinearGradient(110, 380, 230, 300); eg.addColorStop(0, '#30d8e8'); eg.addColorStop(0.5, '#1890a8'); eg.addColorStop(1, '#3070c0');
    R.dome(P(EYEL, true, true), eg, 0.3, 0.14, 26, 2);
    R.dome(ellipseP(186, 343, 32, 27, -0.2), '#08080a', 0.4, 0.05, 6, 5);
    R.pipe(ellipseP(186, 343, 21, 18, -0.2), 5, '#f4f4f4', 0.45, 0.02, 5);
    R.flat(ellipseP(186, 343, 13, 11, -0.2), '#060608', 0.44, 5);
    // dark hollow
    R.flat(P(ell(78, 416, 62, 34, -0.35), true, true), '#2a2220', 0.06, 0);
    soft(x => { x.fillStyle = '#2a2220'; x.fill(ellipseP(78, 416, 60, 32, -0.35)); }, 3);

    // ── bumps ──
    for (const [x, y, r] of [[295, 545, 15], [251, 462, 10], [300, 694, 13], [280, 790, 16], [522, 196, 8], [682, 162, 7], [12, 640, 9], [250, 210, 6]]) R.bead(x, y, r, '#d8dae2', 0.32, 0.08, 1);
    R.flat(circleP(716, 162, 11), '#0a0a0a', 0.1, 0);

    // ── spiral discs ──
    R.dome(P(SP1, true, true), spiral(664, 276, 14.05, -2, 0.265, 1.0), 0.16, 0.06, 10, 7);
    R.dome(P(SP2, true, true), spiral(111, 819, 12.48, 1, -0.15, 0.98), 0.16, 0.06, 10, 7);

    // ── black mouth ──
    R.flat(P(MOUTH, true, true), '#020304', 0.02, 0);
    a.fillStyle = '#ffffff'; a.fill(circleP(410, 715, 3.5));

    // ── zebra face ──
    const faceP = P(FACE, true, true);
    R.dome(faceP, faceZ, 0.1, 0.06, 18, 2);
    // dark lower face
    soft(x => { x.fillStyle = '#060607'; x.fill(P([[352, 470], [392, 478], [420, 440], [460, 448], [500, 470], [500, 510], [492, 560], [470, 590], [400, 596], [362, 570], [345, 510]], true, true)); }, 3);
    // red-brown chin rim
    R.pipe(P([[346, 505], [355, 545], [372, 580], [400, 592], [445, 592], [478, 572], [492, 540], [498, 502], [510, 482]], false), 11, '#a85440', 0.2, 0.04, 2);
    R.pipe(P([[346, 505], [362, 518], [372, 540]], false), 8, '#a85440', 0.2, 0.03, 2);
    R.bead(368, 515, 6, '#f8f8f8', 0.24, 0.04, 2);
    // nose and lips
    R.dome(P([[424, 440], [440, 440], [446, 470], [462, 484], [470, 500], [456, 512], [440, 506], [430, 512], [416, 508], [402, 500], [408, 484], [420, 470]], true, true), '#a8a8ae', 0.2, 0.2, 16, 3);
    R.dome(P([[404, 528], [430, 524], [460, 528], [474, 540], [462, 552], [432, 556], [404, 552], [396, 540]], true, true), '#9a9aa2', 0.2, 0.14, 12, 3);
    R.groove(P([[402, 541], [432, 544], [470, 541]], false), 4, '#222', 0.34, 0.1, 3);
    // goggles with pink-brown swirl rims
    for (const [x, y, r] of [[378, 412, 42], [492, 412, 38]]) {
      R.pipe(circleP(x - 2, y - 2, r + 13), 5, '#9a6060', 0.22, 0.03, 2);
      for (let k = 0; k < 4; k++) { a.lineWidth = 1.4; a.strokeStyle = k % 2 ? '#e0a8b0' : '#a87070'; a.stroke(circleP(x - 3 + k, y - 3, r + 2 + k * 3)); }
      R.dome(circleP(x, y, r), rainbow(x, y, r), 0.24, 0.16, r * 0.8, 6);
      a.fillStyle = 'rgba(220,120,40,0.55)'; a.fill(P([[x - 16, y + 2], [x + 2, y - 4], [x + 18, y + 8], [x + 8, y + 26], [x - 10, y + 22]], true, true));
      a.fillStyle = '#7050d8'; a.fill(circleP(x - 6, y - 14, 5));
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.85, metal: 0.25, spec: 0.7, shin: 18, wrap: 0.5, ao: 0.5, rim: 0.25 }),    // 1 satin silver
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.3, ao: 0.4, coat: 0.15, iri: 0.25 }),       // 2 gloss / iridescent
        E.mat({ dif: 0.7, metal: 0.6, spec: 1.1, shin: 50, ao: 0.4 }),                           // 3 chrome
        E.mat({ dif: 1, spec: 0.8, shin: 30, wrap: 0.4, iri: 0.6, coat: 0.2 }),                  // 4 iridescent plinth
        E.mat({ dif: 1, spec: 1.0, shin: 80, coat: 0.2 }),                                       // 5 black gloss eye
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.6, emis: 0.25, coat: 0.3 }),                // 6 holo goggles
        E.mat({ dif: 0.8, spec: 0.3, shin: 30, wrap: 0.6, emis: 0.15 })                          // 7 spiral discs
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.55, 0.55, 0.58], amb: [0.5, 0.5, 0.52],
      envTop: [1, 0.98, 1.0], envHor: [0.8, 0.72, 0.78], envBot: [0.35, 0.33, 0.36], envK: [0.25, 0.8, 0.3, 0],
      rimC: [0.35, 0.3, 0.4], rimD: [0, 1, 0.3], r1: 3.2, r2: 10, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.45, 6]
    });
    E.bloom(0.1, 10);
    E.grain(0.025, 117);
  }
});
