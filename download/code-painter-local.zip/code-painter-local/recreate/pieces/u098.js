'use strict';
// u098 — "Stone mask in blue starlight": a pitted grey stone slab and a helmeted silver-faced mask float in
// a deep-blue glow lit by lens-flare stars; tan and blue droplets, a zebra-striped cylinder, chrome beads,
// a striped silver sheet and a red panel drift across a white-dotted black starfield.
REC.register('u098', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const img = (cv, ctx = a, alpha = 1, op = 'source-over') => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const pores = (path, n, seed, x0, y0, w, h, col = '#141210', rmax = 2.2) => clipA(path, () => { const r = rng(seed); for (let i = 0; i < n; i++) fill(circleP(x0 + r() * w, y0 + r() * h, 0.5 + r() * r() * rmax), col); });
    const STONE = 1, CHR = 2, GLOSS = 3, STRIPE = 4;

    // ── black starfield and the deep-blue glow ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#070708', 0, 0);
    soft(x => {
      fill(sm([[290, 290], [370, 250], [440, 200], [500, 220], [540, 290], [570, 420], [600, 560], [612, 700], [584, 800], [520, 860], [440, 860], [390, 800], [350, 700], [300, 580], [270, 440]]), rad(450, 500, 360, [[0, '#2c68d0'], [0.55, '#1c4cac'], [1, '#0c2260']], x), x);
    }, 18);
    // red panel
    R.flat(sm([[540, -10], [736, -10], [736, 140], [660, 156], [590, 186], [548, 226], [538, 120]]), lin(530, 0, 726, 200, [[0, '#f04a44'], [0.6, '#f43c38'], [1, '#e83432']]), 0.01, 0);
    // lavender drip
    R.pipe(line([[424, -10], [440, 30], [470, 60], [452, 100], [462, 150], [480, 190], [494, 226]]), 30, '#b4aaea', 0.04, 0.08, GLOSS);
    R.pipe(line([[470, 120], [486, 170], [500, 230]]), 10, '#e4e0ff', 0.06, 0.04, GLOSS);

    // ── the big pitted slab (right) ──
    const slab = sm([[532, 240], [560, 214], [610, 186], [670, 162], [736, 146], [736, 640], [700, 632], [640, 624], [596, 604], [572, 560], [560, 480], [548, 380], [538, 300]]);
    R.dome(slab, lin(540, 160, 726, 640, [[0, '#7e7670'], [0.5, '#78706a'], [1, '#6e6660']]), 0.06, 0.14, 26, STONE);
    pores(slab, 900, 3, 530, 140, 200, 500, '#1a1614', 2.4);
    R.groove(sm([[560, 250], [610, 214], [680, 190], [736, 178]]), 6, '#2a2624', 0.2, 0.05, STONE);
    R.groove(line([[556, 300], [566, 420], [580, 530], [604, 584], [660, 606], [736, 612]]), 10, '#24201e', 0.2, 0.06, STONE);
    const zb1 = sm([[620, 260], [690, 230], [736, 222], [736, 340], [700, 350], [650, 330], [626, 300]]);
    R.dome(zb1, '#d8d8d8', 0.16, 0.06, 8, STRIPE);
    clipA(zb1, () => { for (let i = -6; i < 16; i++) stroke(line([[600 + i * 16, 220], [660 + i * 16, 360]]), '#0e0e10', 8); });
    const zb2 = sm([[690, 470], [736, 460], [736, 560], [700, 556]]);
    R.dome(zb2, '#d8d8d8', 0.16, 0.05, 6, STRIPE);
    clipA(zb2, () => { for (let i = 0; i < 8; i++) stroke(line([[680, 470 + i * 14], [736, 480 + i * 14]]), '#0e0e10', 6); });
    R.bead(706, 424, 24, '#c8ccd4', 0.2, 0.2, CHR);
    R.flat(sm([[640, 380], [680, 372], [690, 400], [666, 420], [640, 410]]), '#141210', 0.2, 0);

    // ── grey shell arcing round the mask ──
    const shell = sm([[236, 330], [250, 290], [280, 262], [330, 248], [380, 230], [420, 206], [452, 184], [462, 196], [430, 226], [390, 254], [340, 276], [300, 300], [280, 340], [276, 420], [290, 480], [320, 540], [360, 590], [400, 612], [380, 626], [330, 610], [290, 570], [256, 500], [238, 420]]);
    R.dome(shell, '#5e5854', 0.08, 0.12, 12, STONE);
    pores(shell, 300, 5, 230, 180, 240, 450);
    R.pipe(line([[262, 300], [300, 280], [360, 262], [420, 238], [462, 214]]), 4, '#2a2828', 0.2, 0.03, STONE);
    // the helmeted mask
    const mask = sm([[346, 380], [366, 348], [410, 332], [460, 340], [490, 372], [500, 430], [498, 490], [484, 540], [452, 580], [404, 600], [370, 590], [350, 550], [342, 480]]);
    R.dome(mask, '#6a645e', 0.1, 0.16, 18, STONE);
    pores(mask, 360, 7, 340, 330, 170, 280);
    R.dome(sm([[350, 400], [372, 358], [420, 344], [470, 356], [486, 390], [470, 410], [420, 412], [376, 420]]), '#8a8480', 0.22, 0.08, 12, STONE);
    const face = sm([[356, 434], [400, 424], [446, 426], [456, 460], [440, 500], [410, 524], [376, 520], [358, 490]]);
    R.dome(face, '#d8dce4', 0.24, 0.1, 10, CHR);
    clipA(face, () => { for (const p of [[[366, 450], [390, 446], [410, 452]], [[414, 446], [440, 444]], [[380, 480], [400, 490], [424, 486]], [[372, 506], [400, 512], [430, 504]]]) stroke(line(p), '#14161c', 5); });
    // red outline wire
    R.pipe(line([[408, 318], [470, 330], [496, 370], [506, 440], [496, 510], [470, 556], [430, 596], [380, 614], [340, 600]]), 4, '#d02a20', 0.3, 0.03, GLOSS);
    R.pipe(line([[250, 330], [266, 300], [300, 286], [380, 262], [430, 236], [460, 206], [462, 190]]), 4, '#c82820', 0.3, 0.03, GLOSS);
    R.pipe(line([[256, 360], [262, 420], [276, 470]]), 4, '#c82820', 0.3, 0.03, GLOSS);

    // ── zebra cylinder, pill and chrome balls (left) ──
    const cyl = sm([[180, 360], [214, 344], [244, 356], [246, 540], [212, 556], [180, 540]]);
    R.dome(cyl, '#e4e4e4', 0.1, 0.16, 18, STRIPE);
    clipA(cyl, () => { for (let y = 350; y < 560; y += 15) stroke(line([[176, y], [212, y + 4], [250, y]]), '#101012', 7); });
    R.dome(ellipseP(146, 500, 16, 24, 0.3), '#e0e0e0', 0.1, 0.1, 10, STRIPE);
    clipA(ellipseP(146, 500, 16, 24, 0.3), () => { for (let y = 476; y < 526; y += 10) stroke(line([[126, y], [166, y + 6]]), '#101012', 5); });
    R.dome(rrect(200, 280, 44, 60, 22), '#b8ab98', 0.1, 0.18, 20, STONE);
    R.bead(287, 300, 25, '#a8b0c0', 0.12, 0.25, CHR);
    R.bead(327, 205, 20, '#b0b8c8', 0.12, 0.22, CHR);
    R.bead(498, 582, 15, '#a89a88', 0.2, 0.15, STONE);
    { const r = rng(9); for (let i = 0; i < 46; i++) { const x = 130 + r() * 290, y = 110 + r() * 470; if (x > 250 && y > 250) continue; R.bead(x, y, 2 + r() * 6, ['#b89a78', '#c8a888', '#8a6a4a', '#d0b8a0'][i % 4], 0.12, 0.08, STONE); } }
    R.bead(86, 532, 15, '#d08a30', 0.1, 0.15, GLOSS);
    R.bead(170, 905, 15, '#c87a30', 0.1, 0.15, GLOSS);
    R.bead(76, 851, 10, '#b8a088', 0.1, 0.1, STONE);
    R.bead(42, 640, 9, '#b8a088', 0.1, 0.1, STONE);

    // ── droplets ──
    const tan1 = sm([[118, 640], [124, 606], [150, 580], [200, 560], [262, 548], [272, 560], [250, 600], [210, 640], [160, 664], [126, 662]]);
    R.dome(tan1, lin(120, 560, 270, 660, [[0, '#8a7a66'], [0.5, '#a89680'], [1, '#76685a']]), 0.1, 0.26, 40, STONE);
    pores(tan1, 160, 11, 110, 540, 170, 130, '#4a4036', 1.4);
    const tan2 = sm([[408, 790], [418, 740], [448, 706], [500, 690], [546, 690], [530, 730], [506, 790], [476, 834], [436, 840], [412, 820]]);
    R.dome(tan2, lin(410, 690, 546, 840, [[0, '#968670'], [0.5, '#a89680'], [1, '#6e604e']]), 0.1, 0.26, 40, STONE);
    pores(tan2, 140, 13, 400, 680, 150, 170, '#4a4036', 1.4);
    const blue1 = sm([[70, 696], [92, 676], [140, 688], [190, 720], [230, 762], [226, 776], [190, 772], [130, 758], [84, 732]]);
    R.dome(blue1, '#2a6ed8', 0.1, 0.22, 26, GLOSS);
    R.dome(ellipseP(356, 1004, 84, 52, 0), '#1c5ac4', 0.1, 0.2, 30, GLOSS);
    R.bead(697, 812, 40, '#2a5aa8', 0.1, 0.3, GLOSS);
    R.bead(712, 636, 24, '#2a5aa8', 0.1, 0.2, GLOSS);
    // tan drips + blobs in the blue
    for (const pts of [[[380, 640], [400, 660], [410, 690]], [[440, 650], [460, 668], [470, 700]], [[560, 520], [570, 560], [566, 600]]]) R.pipe(line(pts), 16, '#8a7c6c', 0.12, 0.12, STONE);

    // ── zebra fabric and white lightning down the middle ──
    const zf = sm([[250, 560], [290, 552], [340, 570], [372, 600], [380, 660], [362, 720], [330, 760], [300, 740], [276, 690], [258, 620]]);
    R.flat(zf, '#101012', 0.06, 0);
    clipA(zf, () => { const r = rng(15); for (let i = -10; i < 22; i++) stroke(line([[230 + i * 12, 540], [270 + i * 12 + r() * 10, 640], [330 + i * 12, 760]]), i % 3 ? '#c8ccd4' : '#f0f2f6', 3 + r() * 2.5); });
    R.flat(poly([[372, 556], [380, 556], [350, 700], [330, 780], [310, 860], [292, 920], [284, 920], [300, 850], [322, 760], [346, 680]]), '#f4f6fa', 0.1, 0);
    R.flat(poly([[536, 420], [544, 420], [552, 560], [560, 700], [556, 820], [548, 820], [550, 700], [544, 560]]), '#eef2f8', 0.1, 0);

    const crum = sm([[300, 700], [340, 676], [392, 696], [404, 760], [392, 840], [352, 862], [318, 820], [306, 760]]);
    R.dome(crum, '#a8acb4', 0.08, 0.1, 10, STRIPE);
    clipA(crum, () => { const r = rng(17); for (let i = 0; i < 14; i++) stroke(line([[290 + r() * 30, 680 + i * 14], [340 + r() * 20, 700 + i * 13], [410, 690 + i * 14 + r() * 10]]), '#15161a', 2 + r() * 3); });
    R.flat(poly([[350, 680], [358, 680], [330, 790], [312, 880], [304, 880], [320, 790]]), '#f4f6fa', 0.2, 0);
    // ── striped silver sheet at the bottom ──
    const sheet = sm([[196, 1034], [230, 984], [290, 940], [370, 904], [470, 870], [560, 830], [610, 790], [630, 752], [640, 800], [632, 900], [616, 1034]]);
    R.dome(sheet, '#c8c8cc', 0.06, 0.14, 30, STRIPE);
    clipA(sheet, () => { for (let i = -30; i < 50; i++) { const x0 = 160 + i * 11; stroke(line([[x0, 760], [x0 + 60, 900], [x0 + 110, 1040]]), '#121214', 5.5); } });
    R.dome(ellipseP(356, 1004, 84, 52, 0), '#1c5ac4', 0.12, 0.2, 30, GLOSS);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.7, shin: 30, wrap: 0.25, ao: 0.5, grain: 0.15, rim: 0.15 }),          // 1 pitted stone
        E.mat({ dif: 0.2, spec: 1.4, shin: 80, metal: 1, ao: 0.3, tint: [1.05, 1.1, 1.2] }),                         // 2 chrome
        E.mat({ dif: 1, spec: 1.2, shin: 70, wrap: 0.2, coat: 0.3, ao: 0.3, rim: 0.4 }),                             // 3 gloss
        E.mat({ dif: 0.7, spec: 1.0, shin: 50, metal: 0.4, ao: 0.4, rim: 0.3 })                                     // 4 striped silver
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.95, 0.9, 0.85], amb: [0.34, 0.33, 0.34],
      envTop: [1.1, 1.1, 1.12], envHor: [0.5, 0.52, 0.62], envBot: [0.04, 0.05, 0.1], envK: [0.3, 0.8, 0.2, 0],
      rimC: [0.3, 0.5, 1.0], rimD: [0.4, 0.2, 0.5], l2: [0.6, -0.2, 0.5, 6], l2c: [0.15, 0.3, 0.7],
      r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-4, 5, 0.45, 6]
    });

    // ── stars, mint squiggles, lens flares ──
    { const r = rng(21); for (let i = 0; i < 900; i++) { const x = r() * 726, y = r() * 1024, big = r() < 0.06; const inside = x > 240 && x < 640 && y > 160 && y < 900; if (inside && r() < 0.85) continue; o.globalAlpha = 0.4 + r() * 0.6; fill(circleP(x, y, big ? 2.5 + r() * 6 : 0.4 + r() * 1.2), '#f4f4f4', o); } o.globalAlpha = 1; }
    for (const [x, y, rr] of [[100, 118, 13], [86, 300, 13], [222, 130, 8], [212, 104, 6], [6, 572, 10], [140, 852, 6], [140, 624, 6]]) fill(circleP(x, y, rr), '#f6f6f6', o);
    fill(P(blob(26, 202, 12, 9, 4, 9, 0.2)), '#e04a8a', o);
    { const sq = (x0, y0, y1, w) => { const pts = []; for (let y = y0; y < y1; y += 6) pts.push([x0 + Math.sin(y * 0.3) * w * 0.4 + (y % 18 < 9 ? 2 : -2), y]); stroke(line(pts), '#7ae0c8', w, o); }; sq(184, 84, 150, 5); sq(640, 812, 1000, 8); }
    const flare = (x, y, s) => {
      o.save(); o.globalCompositeOperation = 'screen';
      o.fillStyle = rad(x, y, s * 6, [[0, 'rgba(120,180,255,0.75)'], [0.4, 'rgba(60,120,255,0.3)'], [1, 'rgba(40,80,255,0)']], o); o.fillRect(x - s * 6, y - s * 6, s * 12, s * 12);
      o.fillStyle = rad(x, y, s * 1.6, [[0, 'rgba(255,255,255,1)'], [0.5, 'rgba(220,240,255,0.9)'], [1, 'rgba(200,230,255,0)']], o); o.fillRect(x - s * 2, y - s * 2, s * 4, s * 4);
      for (let i = 0; i < 8; i++) { const t = i / 8 * Math.PI + 0.2, L = s * (i % 2 ? 3 : 5.5); const g = o.createLinearGradient(x - Math.cos(t) * L, y - Math.sin(t) * L, x + Math.cos(t) * L, y + Math.sin(t) * L); g.addColorStop(0, 'rgba(160,210,255,0)'); g.addColorStop(0.5, 'rgba(230,245,255,0.9)'); g.addColorStop(1, 'rgba(160,210,255,0)'); o.strokeStyle = g; o.lineWidth = 1.6; o.beginPath(); o.moveTo(x - Math.cos(t) * L, y - Math.sin(t) * L); o.lineTo(x + Math.cos(t) * L, y + Math.sin(t) * L); o.stroke(); }
      o.restore();
    };
    flare(498, 272, 22); flare(536, 416, 20); flare(330, 505, 22); flare(562, 668, 23); flare(288, 914, 22); flare(270, 45, 6); flare(182, 172, 6);
    E.bloom(0.12, 10);
    E.grain(0.04, 98);
  }
});
