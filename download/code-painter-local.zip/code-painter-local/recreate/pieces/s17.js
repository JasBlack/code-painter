'use strict';
// s17 — "Clay console": a matte white-clay relief — a big round face with two tube-eyes,
// a slot plate and folded ridges, a zig-zag clay pipe edged by green neon — beside a pink
// padded panel with dome buttons and a black chrome speaker plate, a white box frame
// holding a dark mirror, and mottled grey-green concrete with stepped ridges.
REC.register('s17', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const line = (x, pts, w, col, smooth = true) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(P(pts, false, smooth)); };
    const clipDraw = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, 1024, 1024); a.restore(); };

    // ── mottled concrete / marble textures (GLSL) ──
    const concrete = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.012 + 3.1), m = fbm(px * 0.035 + 11.0), d = fbm(px * 0.006 + 7.7);
        vec3 c = mix(vec3(0.40, 0.43, 0.36), vec3(0.66, 0.68, 0.60), smoothstep(0.35, 0.7, n));
        c = mix(c, vec3(0.62, 0.66, 0.50), smoothstep(0.55, 0.8, m) * 0.5);
        c *= mix(0.45, 1.08, smoothstep(0.3, 0.55, d + 0.25 * (1.0 - uv.y) - 0.1 * uv.x));
        c += (hash(px) - 0.5) * 0.05;
        return c;
      }`);
    const marble = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.01 + vec2(fbm(px * 0.02) * 3.0, 0.0));
        float v = 0.5 + 0.5 * sin(n * 14.0);
        vec3 c = mix(vec3(0.22, 0.24, 0.2), vec3(0.62, 0.64, 0.58), v);
        c = mix(c, vec3(0.45, 0.46, 0.36), 0.3);
        return c;
      }`);

    // ground layers
    R.flat(rrect(-10, -10, 1044, 1044, 0), '#6a6e62', 0, 0);
    a.drawImage(concrete, 0, 0, 1024, 1024);
    clipDraw(P([[-10, -10], [520, -10], [420, 110], [300, 140], [150, 195], [-10, 235]], true, false), marble, 1);
    soft(x => { fillE(x, 90, 200, 110, 40, -0.2, '#b8bab6'); }, 20, 0.8);
    // darker lower-right corner
    soft(x => { fillE(x, 930, 900, 150, 160, 0, '#141c18'); fillE(x, 700, 1000, 90, 60, 0, '#2a302a'); fillE(x, 20, 380, 60, 60, 0, '#1a1a16'); }, 40, 0.8);

    // ── white pillows top-left ──
    R.dome(P([[70, -20], [285, -20], [282, 60], [240, 104], [150, 116], [90, 92], [66, 44]]), '#e2e2e0', 0.1, 0.25, 50, 1);
    R.dome(P([[296, -20], [470, -20], [460, 40], [410, 70], [330, 68], [296, 36]]), '#dededc', 0.1, 0.25, 40, 1);
    R.bead(57, 147, 22, '#e6e6e4', 0.1, 0.25, 1);
    R.flat(ellipseP(105, 128, 14, 24, 0.2), '#1a1c18', 0.02, 0);

    // ── pink padded panel ──
    const pink = [[-10, 232], [120, 204], [250, 152], [340, 124], [440, 104], [470, 140], [360, 420], [390, 600], [340, 640], [300, 710], [270, 790], [250, 860], [210, 940], [170, 1044], [-10, 1044]];
    const pg = a.createLinearGradient(0, 200, 300, 1000); pg.addColorStop(0, '#e8e0e6'); pg.addColorStop(0.45, '#d4c9d0'); pg.addColorStop(1, '#a8999f');
    R.dome(P(pink), pg, 0.18, 0.12, 40, 2);
    // lighter plane right of the scalloped ridge + scallops
    const plane = [[330, 640], [400, 600], [480, 640], [630, 640], [600, 1044], [150, 1044], [210, 940], [250, 860], [270, 790], [300, 710]];
    const plg = a.createLinearGradient(0, 640, 0, 1024); plg.addColorStop(0, '#d8d2d6'); plg.addColorStop(1, '#a8a0a6');
    R.dome(P(plane), plg, 0.2, 0.08, 30, 2);
    for (let i = 0; i <= 13; i++) { const t = i / 13, x = 330 - t * 180, y = 650 + t * 390; R.dome(circleP(x - 4, y, 17), '#d6ced4', 0.2, 0.1, 12, 2); }
    // dome buttons + dark holes on pink
    for (const [x, y, r] of [[125, 750, 20], [81, 876, 26], [175, 876, 26], [25, 902, 22], [131, 928, 28], [319, 925, 32], [256, 975, 32], [150, 1020, 26], [300, 1024, 24]]) R.bead(x, y, r, '#f2eef0', 0.28, 0.24, 2);
    for (const [x, y, r] of [[45, 750, 15], [0, 746, 12]]) R.flat(circleP(x, y, r), '#15131a', 0.1, 0);

    // ── black chrome speaker plate ──
    const plate = [[-10, 300], [140, 264], [160, 272], [160, 310], [148, 390], [128, 460], [100, 520], [62, 562], [-10, 590]];
    R.dome(P(plate), '#191c1a', 0.3, 0.12, 12, 4);
    for (const [x, y, r] of [[44, 390, 44], [40, 490, 38]]) {
      R.pipe(circleP(x, y, r), 14, '#b8bcb8', 0.4, 0.08, 4);
      R.dome(circleP(x, y, r * 0.55), '#0e100e', 0.38, 0.06, 10, 4);
      R.pipe(circleP(x, y, r * 0.35), 7, '#8a908c', 0.4, 0.05, 4);
    }
    R.pipe(circleP(98, 306, 12), 5, '#c8ccc8', 0.4, 0.05, 4);
    R.pipe(P(plate), 7, '#d8dcd8', 0.36, 0.06, 4);
    // keyhole piece with neon outline
    const key = new Path2D(); key.arc(76, 606, 44, 0, 6.283); key.rect(-10, 588, 60, 64);
    R.dome(key, '#101210', 0.3, 0.1, 10, 4);
    R.dome(circleP(64, 612, 18), '#2a2e2a', 0.36, 0.08, 10, 4);

    // ── the big clay face ──
    const faceCol = a.createLinearGradient(330, 0, 900, 600); faceCol.addColorStop(0, '#b8bebf'); faceCol.addColorStop(0.5, '#aeb6b9'); faceCol.addColorStop(1, '#b4bec2');
    const face = [[330, 620], [318, 460], [330, 330], [360, 210], [420, 110], [500, 30], [560, -20], [1044, -20], [1044, 210], [900, 245], [870, 300], [790, 470], [760, 505], [480, 528], [445, 560], [420, 640]];
    R.dome(P(face), faceCol, 0.22, 0.3, 110, 1);
    // folded ridges: brow fold and nose fold
    R.pipe(P([[850, -30], [780, 80], [700, 150], [600, 190], [500, 215], [430, 250], [370, 305], [330, 360]], false), 70, '#c4cacc', 0.44, 0.12, 1);
    R.pipe(P([[330, 390], [380, 345], [450, 318], [520, 305]], false), 44, '#c2c8ca', 0.44, 0.1, 1);
    R.bead(418, 400, 26, '#d8dddd', 0.46, 0.12, 1);
    R.flat(circleP(412, 395, 4), '#5a6060', 0.5, 1);
    // eye tubes
    for (const [x, y, rx, ry] of [[576, 136, 30, 34], [652, 88, 32, 32]]) {
      R.pipe(ellipseP(x, y, rx, ry, 0), 12, '#e2e6e6', 0.56, 0.08, 1);
      R.flat(ellipseP(x, y, rx - 6, ry - 6, 0), '#3e4442', 0.34, 3);
    }
    // slot plate
    { const sp = new Path2D(); const m = new DOMMatrix().translate(642, 285).rotate(-14);
      const rr = rrect(-86, -32, 172, 64, 16); sp.addPath(rr, m);
      R.dome(sp, '#c6cccc', 0.5, 0.06, 10, 1);
      const sl = new Path2D(); sl.addPath(rrect(-70, -18, 140, 30, 14), m); R.flat(sl, '#1e2624', 0.42, 3);
      const tab = new Path2D(); tab.addPath(rrect(-30, 4, 60, 24, 5), m); R.dome(tab, '#b8c0c0', 0.46, 0.05, 6, 1);
      for (const [sx, sy] of [[-72, 0], [72, 0]]) { const q = m.transformPoint(new DOMPoint(sx, sy)); R.bead(q.x, q.y, 8, '#2a2e2c', 0.5, 0.06, 4); } }
    // top-right white brackets
    R.pipe(P([[1044, 110], [985, 118], [966, 160], [986, 196], [1044, 204]], false), 40, '#e2e6e6', 0.4, 0.14, 1);
    R.pipe(P([[1000, -20], [998, 48], [1044, 60]], false), 32, '#e2e6e6', 0.4, 0.14, 1);

    // ── zig-zag clay pipe + green neon ──
    const zig = [[1044, 222], [905, 258], [872, 300], [792, 470], [760, 505], [482, 528], [448, 560], [420, 640]];
    R.pipe(P(zig, false, false), 62, '#dfe4e4', 0.4, 0.16, 1);
    R.pipe(P([[1044, 196], [890, 232], [850, 290], [772, 452], [746, 482], [480, 504]], false, false), 18, '#e8ecec', 0.52, 0.04, 1);
    const neon = [[1044, 302], [962, 312], [942, 332], [832, 540], [812, 556], [500, 580], [480, 592], [455, 645]];
    soft(x => line(x, neon, 30, '#80ff90', false), 10, 0.7);
    R.pipe(P(neon, false, false), 9, '#c8ffc0', 0.3, 0.05, 5);

    // ── concrete: stepped ridges, squiggle tube, black blob, triangle, balls ──
    for (const dy of [-70, 0, 70]) {
      const st = [[640 + dy * 0.3, 1044], [640 + dy * 0.3, 870 + dy], [700, 870 + dy], [740, 810 + dy], [840, 810 + dy], [880, 760 + dy], [960, 760 + dy], [1000, 720 + dy], [1044, 720 + dy]];
      R.pipe(P(st, false, false), 12, '#b4b8ac', 0.12, 0.06, 1);
    }
    R.pipe(P([[700, 560], [700, 660], [660, 700], [660, 780]], false, false), 12, '#b0b4a8', 0.12, 0.06, 1);
    R.pipe(P([[1000, 370], [1012, 420], [986, 470], [950, 512], [962, 560], [944, 600], [902, 616], [880, 642], [893, 668], [918, 660]], false), 42, '#e0e4e4', 0.2, 0.26, 1);
    R.flat(P(blob(822, 624, 26, 20, 7, 12, 0.35)), '#0c0e0c', 0.04, 3);
    R.dome(P([[728, 1044], [780, 940], [830, 1044]], true, false), '#e8ecec', 0.1, 0.2, 20, 1);
    R.bead(904, 992, 32, '#e4e6e6', 0.1, 0.26, 1); R.bead(970, 976, 32, '#e4e6e6', 0.1, 0.26, 1);

    // ── white box frame with dark mirror ──
    const outer = [[345, 640], [690, 640], [592, 930], [328, 880]], inner = [[370, 662], [650, 664], [566, 902], [352, 860]];
    const fr = new Path2D(P(outer, true, false)); fr.addPath(P(inner, true, false));
    const mirrorG = a.createLinearGradient(400, 660, 560, 900); mirrorG.addColorStop(0, '#a8b4b8'); mirrorG.addColorStop(0.45, '#8a989c'); mirrorG.addColorStop(0.58, '#4a5652'); mirrorG.addColorStop(1, '#2e3634');
    R.flat(P(inner, true, false), mirrorG, 0.18, 6);
    R.flat(P([[468, 764], [640, 740], [580, 900], [440, 880]], true, false), '#303a36', 0.2, 6);
    R.pipe(P([[476, 772], [626, 752], [572, 886], [452, 872]], true, false), 8, '#8a9690', 0.24, 0.04, 6);
    R.pipe(P([[400, 668], [362, 850]], false), 6, '#6a7470', 0.24, 0.04, 6);
    R.bead(470, 782, 22, '#dfe2e2', 0.2, 0.2, 1);
    { const hx = R.h; hx.save(); hx.fillStyle = hc(0.44, 1); hx.fill(fr, 'evenodd'); hx.restore(); a.save(); a.fillStyle = '#e4e6e6'; a.fill(fr, 'evenodd'); a.restore(); }
    R.dome(P([[328, 880], [345, 640], [320, 660], [300, 890], [580, 950], [592, 930]], true, false), '#c8cccc', 0.3, 0.12, 12, 1);
    R.pipe(P(outer, true, false), 10, '#eaecec', 0.44, 0.06, 1);
    // legs under the frame
    R.pipe(P([[380, 890], [360, 960], [390, 1000]], false), 22, '#e0e2e2', 0.3, 0.12, 1);
    R.pipe(P([[520, 910], [530, 980], [600, 1000]], false), 24, '#e0e2e2', 0.3, 0.12, 1);

    // soft ambient-occlusion shading painted into the albedo
    soft(x => {
      fillE(x, 420, 250, 70, 120, 0.3, '#8a9296'); fillE(x, 560, 420, 160, 60, 0, '#a2aaae'); fillE(x, 360, 560, 40, 60, 0, '#9aa0a2');
      fillE(x, 700, 380, 80, 110, 0.4, '#b0b8bc'); fillE(x, 520, 60, 60, 40, 0, '#a8b0b2'); fillE(x, 470, 960, 160, 70, 0, '#6a6468'); fillE(x, 660, 800, 50, 160, 0, '#6a6c64');
    }, 40, 0.5);
    soft(x => { x.strokeStyle = '#7a7076'; x.lineWidth = 30; x.stroke(P([[440, 118], [360, 210], [322, 330], [318, 460], [330, 620]], false)); }, 18, 0.5);
    soft(x => { fillE(x, 180, 560, 80, 200, 0.2, '#b8a8b2'); fillE(x, 60, 960, 90, 60, 0, '#a89aa2'); }, 40, 0.4);
    soft(x => { line(x, [[40, 330], [30, 360]], 6, '#90ff90'); line(x, [[100, 420], [96, 470]], 6, '#90ff90'); line(x, [[0, 560], [62, 548]], 8, '#90ff90');
      x.strokeStyle = '#80ff90'; x.lineWidth = 7; x.beginPath(); x.arc(76, 606, 46, -1.3, 4.0); x.stroke(); }, 2, 0.9);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 12, wrap: 0.45, ao: 1.0, rim: 0.2 }),                        // 1 white clay
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.5, ao: 0.8, rim: 0.15 }),                         // 2 pink clay
        E.mat({ dif: 1, spec: 0.1, shin: 10, ao: 0.6 }),                                               // 3 dark hole
        E.mat({ metal: 1, spec: 1.2, shin: 90, rim: 0.4, tint: [0.9, 1.0, 0.92], ao: 0.3 }),          // 4 black chrome
        E.mat({ dif: 0.5, emis: 0.7, spec: 0.3, shin: 20 }),                                           // 5 neon
        E.mat({ metal: 0.6, dif: 0.6, spec: 0.8, shin: 60, ao: 0.3 })                                  // 6 mirror
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.66, 0.66, 0.66], amb: [0.3, 0.31, 0.32],
      envTop: [1, 1, 1], envHor: [0.45, 0.5, 0.46], envBot: [0.05, 0.06, 0.05], envK: [0.6, 1.3, 0.4, 0],
      rimC: [0.4, 0.5, 0.42], rimD: [0.3, -0.4, 0.3], r1: 3, r2: 14, k: [0, 0.6, 0.4, 70], shadow: [10, -10, 0.55, 5]
    });
    E.grain(0.035, 17);
  }
});
