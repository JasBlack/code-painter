'use strict';
// s23 — "Resin skull disc": a slab of poured resin melt — orange, yellow, pink, violet,
// cobalt and turquoise, thick glossy puddles — with a teal skull medallion set in a
// crinkled-foil well, shot close with a shallow depth of field against grey.
REC.register('s23', {
  w: 819, h: 1024,
  draw(E) {
    const W = 819, H = 1024, S = E.S;
    const R = E.relief(), a = R.a, hx = R.h;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const fp = (x, pts, col) => { x.fillStyle = col; x.fill(P(pts)); };

    // ── grey studio backdrop ──
    const bg = a.createLinearGradient(0, 0, 520, 0);
    bg.addColorStop(0, '#8e8681'); bg.addColorStop(0.28, '#aca49d'); bg.addColorStop(0.5, '#958d87'); bg.addColorStop(0.68, '#5a5452'); bg.addColorStop(0.82, '#2a282a'); bg.addColorStop(1, '#1c1b1e');
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), bg, 0, 0);
    soft(x => { fe(x, 0, 620, 120, 300, 0, '#2e2c2c'); fe(x, 40, 420, 90, 160, 0, '#4a4545'); }, 60, 0.9);

    // ── the resin slab ──
    const slab = [[-20, 700], [0, 660], [30, 560], [70, 420], [104, 264], [300, 205], [430, 160], [520, 118], [570, 80], [610, 30], [630, -20], [W + 20, -20], [W + 20, H + 20], [-20, H + 20]];
    const slabP = P(slab, true, false);
    R.flat(slabP, '#e8a040', 0.05, 0);
    // blurred melt (out of focus): colour fields painted and blurred into the albedo
    a.save(); a.clip(slabP);
    soft(x => {
      x.fillStyle = '#f08a10'; x.fillRect(0, 0, W, H);
      // top right: cream-yellow with a dark smudge, lilac-pink band
      fp(x, [[400, 150], [620, 0], [W, 0], [W, 200], [600, 190], [460, 200]], '#f0cc7c');
      fe(x, 560, 170, 90, 30, -0.3, '#f8c040'); fe(x, 700, 90, 36, 60, 0.4, '#6e6068'); fe(x, 790, 150, 40, 60, 0, '#e8a090');
      fp(x, [[470, 210], [640, 190], [W, 210], [W, 380], [720, 330], [560, 260]], '#d6aacb');
      fe(x, 760, 300, 60, 40, 0, '#cf94b8'); fe(x, 790, 360, 40, 40, 0, '#c8729a');
      // right side: red / teal / cream bands
      fe(x, 800, 430, 40, 50, 0, '#b23e4d'); fe(x, 740, 440, 30, 50, 0, '#47a0a6'); fe(x, 800, 520, 30, 50, 0, '#1389a9');
      fe(x, 740, 500, 40, 40, 0, '#b6b982'); fe(x, 760, 590, 30, 40, 0, '#0d78af');
      fe(x, 750, 690, 40, 60, 0, '#eadbc7'); fe(x, 760, 780, 40, 50, 0, '#efd295'); fe(x, 800, 640, 30, 80, 0, '#ee7301');
      // orange field left of the disc
      fe(x, 330, 520, 110, 100, 0, '#f58a08'); fe(x, 380, 330, 40, 150, 0.1, '#f39318');
      // violet / pink / yellow / white below-left
      fe(x, 110, 560, 50, 40, 0, '#eef8f6'); fe(x, 175, 570, 45, 45, 0, '#f0cc10'); fe(x, 230, 560, 30, 40, 0, '#f07e00');
      fe(x, 250, 625, 60, 40, 0, '#d05878'); fe(x, 230, 680, 50, 35, 0, '#6a4a90'); fe(x, 300, 680, 40, 40, 0, '#c890b8');
      fe(x, 330, 615, 35, 60, 0, '#7b1b7b'); fe(x, 390, 600, 40, 70, 0, '#3040a8'); fe(x, 380, 680, 30, 30, 0, '#601b8a');
      fe(x, 100, 660, 60, 40, 0.2, '#2a1a90'); fe(x, 40, 600, 40, 60, 0, '#1a90b8');
      fe(x, 440, 610, 25, 30, 0, '#e08a10'); fe(x, 390, 500, 30, 20, 0, '#b8b8c6');
      // cobalt pool beneath the disc
      fp(x, [[440, 600], [520, 580], [640, 590], [700, 640], [710, 760], [670, 840], [560, 850], [500, 800], [470, 700]], '#0010a0');
      fe(x, 600, 700, 70, 90, 0, '#00008a'); fe(x, 520, 620, 60, 40, 0, '#0060c8'); fe(x, 670, 640, 40, 40, 0, '#2a1e98');
      fe(x, 690, 760, 30, 50, 0, '#36aeac'); fe(x, 670, 840, 40, 30, 0, '#88d0b0'); fe(x, 470, 700, 25, 50, 0, '#0058a8');
      fe(x, 450, 560, 60, 25, 0, '#2080b0');
      // bottom: dark orange column, white/cyan column, orange right
      fp(x, [[190, 720], [340, 710], [360, 760], [350, 1040], [190, 1040], [200, 800]], '#c04c02');
      fp(x, [[370, 790], [470, 800], [480, 900], [480, 1040], [360, 1040]], '#eaf6f2');
      fe(x, 375, 830, 20, 60, 0, '#f0e2b0'); fe(x, 500, 900, 25, 100, 0, '#e08e00');
      fe(x, 545, 900, 25, 80, 0, '#5a6070'); fe(x, 560, 990, 30, 50, 0, '#1040b0');
      fp(x, [[600, 880], [W, 740], [W, 1040], [600, 1040]], '#f07c00');
      fe(x, 780, 1000, 80, 60, 0, '#d84000'); fe(x, 640, 960, 40, 60, 0, '#f08800');
      // bottom-left: cyan, white, blue
      fp(x, [[0, 720], [110, 700], [160, 740], [170, 1040], [0, 1040]], '#eaf4f0');
      fe(x, 15, 900, 35, 140, 0, '#0070d8'); fe(x, 65, 960, 25, 70, 0, '#30c8dc'); fe(x, 120, 960, 30, 70, 0, '#6cdce8');
      fe(x, 175, 860, 25, 90, 0, '#b8b050'); fe(x, 20, 760, 30, 40, 0, '#5ccaca');
    }, 20);
    a.restore();

    // ── in-focus turquoise puddles (upper left), thick glossy resin ──
    const mint = [[123, 276], [177, 248], [238, 222], [323, 206], [385, 220], [402, 247], [364, 282], [326, 312], [306, 352], [286, 414], [254, 444], [200, 458], [140, 486], [100, 520], [80, 580], [60, 610], [40, 560], [70, 470], [96, 380], [108, 300]];
    // white resin skin along the inside of the rim
    R.dome(P([[108, 268], [200, 238], [140, 300], [110, 400], [90, 480], [60, 560], [30, 640], [0, 700], [-10, 690], [20, 600], [50, 500], [80, 400]]), '#e8eeee', 0.1, 0.06, 14, 1);
    const mintP = P(mint);
    R.dome(mintP, '#bfe6dc', 0.1, 0.04, 10, 2);
    a.save(); a.clip(mintP);
    soft(x => {
      fe(x, 180, 380, 70, 70, 0, '#18a0c4'); fe(x, 230, 330, 60, 40, 0, '#30b8d0'); fe(x, 90, 480, 40, 70, 0.2, '#28b0c8');
      fe(x, 300, 240, 80, 30, 0, '#c8ece2'); fe(x, 150, 290, 30, 40, 0, '#e8f8f6'); fe(x, 70, 560, 30, 50, 0, '#1a8ec0');
      fe(x, 280, 400, 30, 40, 0, '#78dce0');
    }, 12);
    a.restore();
    // holes in the puddle: white pocket with tan crescent; dark pocket with white + tan
    const hole1 = P([[228, 250], [262, 232], [310, 236], [328, 262], [312, 300], [284, 322], [256, 312], [240, 286]]);
    R.flat(hole1, '#f0ece6', 0.1, 1);
    a.save(); a.clip(hole1); fe(a, 300, 300, 36, 12, -0.4, '#e2c080'); fe(a, 260, 316, 30, 10, 0.2, '#2a2826'); a.restore();
    const hole2 = P([[142, 390], [168, 372], [200, 380], [218, 408], [206, 432], [178, 436], [156, 422]]);
    R.flat(hole2, '#141414', 0.1, 1);
    a.save(); a.clip(hole2); fe(a, 184, 404, 16, 14, 0, '#f4f2ee'); fe(a, 196, 424, 18, 8, 0, '#d8b870'); a.restore();
    // small green slip at the top rim
    R.dome(ellipseP(390, 182, 22, 8, -0.3), '#5bbf90', 0.1, 0.04, 6, 2);
    R.dome(P([[440, 190], [470, 170], [520, 160], [560, 150], [610, 140], [640, 150], [600, 170], [540, 185], [480, 210], [450, 216]]), '#f0d880', 0.1, 0.05, 10, 2);
    // glossy blobs of the left edge: yellow, violet
    R.dome(ellipseP(160, 566, 34, 42, 0.2), '#f2cc08', 0.1, 0.07, 16, 2);
    R.dome(P([[40, 640], [80, 620], [130, 640], [150, 680], [110, 700], [60, 700]]), '#5a40c0', 0.1, 0.05, 14, 2);
    R.dome(ellipseP(80, 755, 30, 16, 0), '#eef8f6', 0.1, 0.05, 10, 2);

    // glossy white ridges where the melt pools meet (slightly soft: just out of focus)
    for (const [pts, wd] of [
      [[[380, 540], [440, 520], [500, 560], [560, 580], [640, 590], [700, 620], [720, 700], [700, 800], [660, 860], [600, 880]], 12],
      [[[140, 700], [180, 690], [230, 700], [260, 720], [300, 715], [340, 720]], 10],
      [[[20, 650], [60, 690], [100, 710], [130, 740], [150, 780], [160, 840], [170, 900]], 12],
      [[[360, 740], [380, 790], [400, 830], [440, 840], [470, 860]], 10]])
      R.pipe(P(pts, false), wd, '#f2f4f2', 0.07, 0.03, 1);
    // ── slab rim: pale grey plastic edge ──
    const rim = P([[-10, 690], [10, 640], [36, 560], [74, 430], [104, 268], [300, 208], [420, 168]], false);
    R.pipe(rim, 22, '#d8d2ce', 0.08, 0.06, 1);
    soft(x => { x.lineWidth = 8; x.strokeStyle = '#ffffff'; x.stroke(P([[20, 610], [50, 520], [80, 420], [100, 330]], false)); }, 3, 0.7);

    // ── the skull medallion ──
    const cx = 565, cy = 405;
    // translucent outer ring (teal edge, silver lip)
    R.dome(ellipseP(cx, cy, 178, 172, -0.1), '#6e8e96', 0.1, 0.1, 20, 3);
    a.save(); a.clip(ellipseP(cx, cy, 178, 172, -0.1));
    soft(x => { x.lineWidth = 16; x.strokeStyle = '#30b0c0'; x.stroke(ellipseP(cx, cy + 6, 172, 168, -0.1)); fe(x, 420, 470, 30, 60, 0, '#d8e8e8'); fe(x, 700, 300, 30, 60, 0, '#d8d0d0'); }, 6, 0.8);
    a.restore();
    R.pipe(ellipseP(cx - 2, cy - 2, 162, 156, -0.1), 6, '#c8d0d0', 0.2, 0.03, 3);
    // crinkled foil well
    const foil = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(565., 405.); float a = atan(d.y, d.x), r = length(d);
      float n = fbm(vec2(a * 30., r * 0.06)) * .7 + fbm(p * 0.08) * .5;
      float s = pow(fbm(vec2(a * 60., r * 0.02) + 3.), 2.) * 1.2;
      vec3 c = mix(vec3(.06, .07, .08), vec3(.55, .54, .52), clamp(n * n * 1.0 + s * .35 - .08, 0., 1.));
      c = mix(c, vec3(.85, .78, .55), smoothstep(.55, .9, fbm(p * .02 + 7.)) * step(0., d.x + d.y * .3) * .8);
      return c; }`);
    const wellP = ellipseP(cx, cy - 2, 152, 140, -0.1);
    R.flat(wellP, null, 0.12, 4);
    a.save(); a.clip(wellP); a.drawImage(foil, 0, 0, W, H); a.restore();
    soft(x => { x.save(); x.clip(wellP); fe(x, 560, 470, 130, 60, 0, 'rgba(8,10,12,0.6)'); x.restore(); }, 10, 0.8);
    // teal skull disc
    const disc = ellipseP(548, 390, 118, 110, -0.08);
    R.dome(disc, '#3d6c7c', 0.13, 0.12, 30, 5);
    soft(x => { x.save(); x.clip(disc); fe(x, 520, 320, 90, 40, 0, '#5a8e98'); fe(x, 580, 470, 100, 50, 0, '#1e4658'); x.restore(); }, 14, 0.8);
    // eye holes + nose
    R.flat(ellipseP(515, 322, 24, 15, 0.05), '#0c1216', 0.12, 6);
    R.flat(ellipseP(582, 323, 28, 17, 0.02), '#0c1216', 0.12, 6);
    R.flat(P([[528, 342], [542, 342], [535, 328]], true, false), '#0c1216', 0.12, 6);
    // purple beads
    R.dome(ellipseP(530, 381, 60, 30, -0.1), '#4a2682', 0.25, 0.05, 14, 7);
    const beads = [[527, 402, 28], [460, 387, 10], [620, 357, 15], [474, 437, 18], [586, 432, 20], [542, 458, 16]];
    for (const [x, y, r] of beads) {
      R.dome(circleP(x, y + 3, r + 6), '#7aaebc', 0.25, 0.05, 6, 5);
      R.bead(x, y, r, '#3c1c70', 0.28, 0.12, 7);
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.7, emis: 0.35, spec: 0.9, shin: 60, wrap: 0.4, rim: 0.4 }),                    // 1 white resin / plastic
        E.mat({ dif: 0.6, emis: 0.3, spec: 1.3, shin: 90, wrap: 0.3, coat: 0.06, rim: 0.2 }),         // 2 glossy puddle
        E.mat({ dif: 0.6, emis: 0.3, spec: 1.0, shin: 70, coat: 0.35, rim: 0.6 }),                     // 3 clear ring
        E.mat({ dif: 0.55, emis: 0.2, metal: 0.15, spec: 0.9, shin: 40, grain: 0.7, ao: 0.4 }),        // 4 foil
        E.mat({ dif: 0.8, emis: 0.2, spec: 0.5, shin: 30, wrap: 0.3, ao: 0.6, grain: 0.08 }),         // 5 teal clay
        E.mat({ dif: 0.5, emis: 0.2, spec: 0.2, shin: 20 }),                                           // 6 holes
        E.mat({ dif: 0.8, emis: 0.2, spec: 1.2, shin: 70, coat: 0.15, rim: 0.3 })                     // 7 purple gloss
      ],
      light: [-0.5, 0.6, 0.62], lc: [1.0, 1.0, 1.0], amb: [0.35, 0.35, 0.38],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.58], envBot: [0.1, 0.1, 0.12], envK: [0.4, 1.2, 0.3, 0],
      rimC: [0.8, 0.85, 0.9], rimD: [-0.4, 0.5, 0.3], shadow: [-6, 6, 0.5, 8], r1: 2, r2: 8, k: [0, 0.6, 0.4, 70]
    });

    // depth of field: blur everything away from the focal band (upper left -> disc)
    const sharp = E.snapshot(), bl = E.blur(sharp, 9);
    const m = E.newCanvas(), mx = m.getContext('2d'); mx.setTransform(S, 0, 0, S, 0, 0);
    mx.fillStyle = '#fff'; mx.fillRect(0, 0, W, H);
    mx.globalCompositeOperation = 'destination-out'; mx.filter = `blur(${70 * S}px)`;
    mx.fillStyle = '#000'; mx.fill(P([[80, 180], [460, 110], [760, 190], [760, 600], [560, 620], [300, 520], [100, 560], [40, 400]]));
    const bm = E.newCanvas(), bx = bm.getContext('2d'); bx.drawImage(bl, 0, 0); bx.globalCompositeOperation = 'destination-in'; bx.drawImage(m, 0, 0);
    E.draw(bm, 1);
    E.bloom(0.12, 16);
    E.grain(0.03, 23);
  }
});
