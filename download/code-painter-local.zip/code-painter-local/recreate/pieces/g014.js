'use strict';
// g014 — "Gearhead in candy rock": a glossy blue blob with a dotted peach cap cracks open onto a black
// cavity and grey stone set with lilac gear-flowers and confetti; an orange coiled hose, a zebra-striped
// bulb, a spotted rock with a white tuft, cyan zigzags and purple on a pink and black ground.
REC.register('g014', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H]) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.4 + r() * 0.6; a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const dots = (path, n, seed, cols, r0, r1, h, m, box) => clipA(path, () => {
      const r = rng(seed);
      for (let i = 0; i < n; i++) { const x = box[0] + r() * (box[2] - box[0]), y = box[1] + r() * (box[3] - box[1]); R.dome(P(blob(x, y, r0 + r() * (r1 - r0), r0 + r() * (r1 - r0), seed * 100 + i, 8, 0.25)), cols[Math.floor(r() * cols.length)], h, 0.04, 4, m); }
    });
    // stone texture (grey pitted rock)
    const stoneTex = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float n = fbm(p * 0.045) + 0.5 * fbm(p * 0.12 + 3.);
      float pit = smoothstep(0.78, 0.86, n);
      vec3 c = mix(vec3(.56, .55, .6), vec3(.72, .71, .75), smoothstep(0.4, 0.9, fbm(p * 0.02 + 7.)));
      return mix(c, vec3(.1, .1, .13), pit * 0.9); }`);

    // ── grounds: black + pink ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#020204', 0, 0);
    const pink = P([[470, 150], [736, 120], [736, 1034], [270, 1034], [300, 900], [420, 860], [520, 600], [520, 300]], true, false);
    R.flat(pink, '#f89bd2', 0, 0);
    speck(pink, 2500, 4, '#ffc0e4', 0.9, [260, 120, 726, 1024]);

    // ── top right: purple, cyan zigzag fringe, peach arm ──
    R.flat(P([[600, -10], [736, -10], [736, 96], [650, 110], [596, 112]], true, false), '#8a66f2', 0.01, 0);
    speck(P([[600, -10], [736, -10], [736, 96], [596, 112]], true, false), 300, 5, '#b8a0ff', 0.8, [596, 0, 726, 112]);
    R.dome(P(blob(698, 62, 36, 34, 7, 14, 0.25)), '#2a2a34', 0.04, 0.08, 14, 3);
    speck(P(blob(698, 62, 36, 34, 7, 14, 0.25)), 300, 6, '#9a9aa6', 1.2, [660, 26, 736, 100]);
    const zig = (x0, y0, x1, y1, n, amp) => { const pts = []; for (let i = 0; i <= n; i++) { const t = i / n; pts.push([x0 + (x1 - x0) * t + (i % 2 ? amp * 0.4 : 0), y0 + (y1 - y0) * t + (i % 2 ? -amp : 0)]); } return pts; };
    const cyanP = P([...zig(488, 182, 736, 92, 26, 14), [736, 140], [736, 160], [620, 176], [540, 215], [490, 214]], true, false);
    R.flat(cyanP, '#56e2f0', 0.02, 0);
    clipA(cyanP, () => { a.strokeStyle = '#3cc0dc'; a.lineWidth = 1.2; for (let x = 480; x < 740; x += 5) { a.beginPath(); a.moveTo(x, 90); a.lineTo(x - 8, 220); a.stroke(); } });
    a.save(); a.strokeStyle = '#050508'; a.lineWidth = 5; a.lineJoin = 'miter'; a.stroke(P(zig(488, 182, 736, 92, 26, 14), false, false)); a.restore();
    const arm = P([[470, -10], [612, -10], [604, 96], [580, 100], [540, 132], [500, 170], [470, 196], [430, 168], [416, 120], [440, 60]], true, true);
    R.dome(arm, '#fab48e', 0.06, 0.06, 20, 1);
    speck(arm, 900, 8, '#ffd8c0', 0.8, [400, 0, 620, 200]);
    dots(arm, 14, 9, ['#f86ccc', '#f86ccc', '#f478c8'], 6, 10, 0.12, 2, [420, 0, 600, 180]);

    // ── glossy blue blob ──
    const blobO = [[20, 300], [40, 200], [90, 130], [160, 96], [250, 86], [320, 100], [390, 130], [450, 150], [520, 200], [570, 280], [600, 360], [590, 470], [520, 560], [420, 620], [300, 640], [160, 620], [70, 560], [24, 440]];
    const blobPth = P(blobO, true, true);
    R.dome(blobPth, lin(40, 120, 400, 500, [[0, '#3496cc'], [0.4, '#3088c4'], [1, '#2468a8']]), 0.08, 0.36, 90, 4);
    clipA(blobPth, () => soft(x => { fe(x, 160, 140, 40, 20, -0.3, '#30f0fa'); fe(x, 60, 300, 30, 90, 0.1, '#60b0e0'); fe(x, 120, 210, 50, 40, 0, '#3aa8d8'); fe(x, 60, 500, 40, 40, 0, '#88b0d8'); }, 16, 0.8));
    // white cracks
    a.save(); a.strokeStyle = '#f4f8ff'; a.lineCap = 'round';
    for (const [pts, wd] of [[[[30, 380], [50, 330], [90, 260], [160, 238], [230, 230], [300, 222], [340, 230], [370, 290], [400, 340], [430, 380], [460, 440], [490, 520]], 3], [[[230, 230], [250, 200]], 2], [[[60, 330], [40, 270], [70, 240]], 2], [[[100, 260], [80, 300], [90, 380], [110, 470]], 2]]) { a.lineWidth = wd; a.stroke(P(pts, false)); }
    a.restore();

    // ── dotted peach cap ──
    const cap = [[204, 150], [238, 116], [282, 108], [330, 120], [380, 138], [430, 150], [480, 186], [522, 230], [560, 268], [566, 300], [540, 296], [516, 270], [480, 252], [446, 246], [420, 236], [394, 222], [356, 218], [322, 208], [290, 198], [254, 194], [222, 186], [206, 170]];
    const capP = P(ragged(cap, 9, cap.length - 1, 8, 4, 10), true, false);
    R.dome(capP, '#fbb48c', 0.36, 0.05, 8, 1);
    speck(capP, 1200, 11, '#ffd0b0', 0.8, [200, 100, 570, 300]);
    dots(capP, 18, 12, ['#f86ccc', '#f45ac0'], 6, 10, 0.42, 2, [210, 110, 560, 290]);

    // ── black cavity ──
    const cav = [[96, 330], [120, 300], [150, 270], [200, 262], [240, 252], [300, 248], [340, 244], [380, 248], [404, 262], [410, 320], [384, 370], [300, 384], [200, 372], [120, 360]];
    const cavP = P(ragged(cav, 0, 9, 9, 6, 13), true, false);
    R.flat(cavP, '#08070e', 0.2, 0);
    clipA(cavP, () => { a.strokeStyle = 'rgba(40,40,60,0.6)'; a.lineWidth = 1; for (let y = 240; y < 390; y += 3) { a.beginPath(); a.moveTo(90, y); a.lineTo(420, y); a.stroke(); } });

    // ── grey stone mass ──
    const stone = [[96, 380], [120, 360], [200, 376], [300, 386], [384, 372], [410, 330], [430, 296], [480, 270], [540, 290], [580, 330], [610, 370], [600, 430], [560, 470], [530, 520], [510, 600], [500, 700], [470, 790], [400, 830], [330, 800], [300, 700], [200, 640], [130, 600], [100, 520]];
    const stoneP = P(ragged(stone, 0, stone.length, 10, 5, 14), true, false);
    R.dome(stoneP, null, 0.12, 0.1, 30, 3);
    clipA(stoneP, () => img(stoneTex));
    // gear flowers
    const gear = (x, y, rr) => {
      const pts = []; for (let i = 0; i < 48; i++) { const t = i / 48 * 6.283, k = (Math.floor(i / 2) % 2) ? 0.82 : 1; pts.push([x + Math.cos(t) * rr * k, y + Math.sin(t) * rr * k]); }
      R.dome(P(pts, true, true), '#dcb8f4', 0.3, 0.1, 8, 1);
      R.dome(circleP(x, y, rr * 0.48), '#3a3cb0', 0.32, 0.03, 4, 6);
      R.flat(circleP(x, y, rr * 0.36), '#05050c', 0.3, 0);
      clipA(circleP(x, y, rr * 0.36), () => { a.strokeStyle = '#5a40c8'; a.lineWidth = 2; for (let k = -3; k < 4; k++) { a.beginPath(); a.moveTo(x - rr, y + k * 6); a.lineTo(x + rr, y + k * 6 - 8); a.stroke(); } });
    };
    gear(100, 405, 48); gear(190, 446, 52); gear(325, 455, 40); gear(237, 525, 38); gear(482, 316, 50);
    // confetti
    const cr = rng(15), cols = ['#30c8f0', '#f0c020', '#f07a20', '#9a50e0', '#e02a40', '#30d8e8', '#e070e0', '#f4e030'];
    for (let i = 0; i < 46; i++) {
      const x = 110 + cr() * 480, y = 280 + cr() * 480;
      const inStone = a.isPointInPath(stoneP, x * S, y * S) || a.isPointInPath(cavP, x * S, y * S);
      if (!inStone) continue;
      R.dome(P(blob(x, y, 7 + cr() * 9, 5 + cr() * 7, 200 + i, 8, 0.3, cr() * 3)), cols[Math.floor(cr() * cols.length)], 0.34, 0.05, 4, 2);
    }
    R.dome(P(blob(170, 518, 18, 26, 31, 10, 0.15, 0.3)), '#f4e810', 0.32, 0.08, 8, 2);
    R.dome(circleP(408, 392, 14), '#e8e8f0', 0.34, 0.06, 6, 2);
    R.flat(circleP(463, 680, 13), '#08080c', 0.2, 0);

    // ── orange coiled hose ──
    const coilC = [440, 618];
    for (let k = 9; k >= 0; k--) {
      const rr = 70 + k * 17, pts = [];
      for (let i = 0; i <= 40; i++) { const t = -1.45 + i / 40 * 3.15; pts.push([coilC[0] + Math.cos(t) * rr * 1.0, coilC[1] + Math.sin(t) * rr * 1.1]); }
      R.pipe(P(pts, false), 24, k % 2 ? '#e44a14' : '#f05a1c', 0.1, 0.14, 5);
    }
    // fine ribs on the hose
    clipA(P([[440, 360], [736, 360], [736, 900], [360, 900], [380, 820], [520, 600], [540, 420]], true, false), () => {
      a.strokeStyle = 'rgba(120,20,8,0.55)'; a.lineWidth = 1;
      for (let i = 0; i < 260; i++) { const t = -1.45 + i / 260 * 3.0, c = Math.cos(t), s = Math.sin(t); a.beginPath(); a.moveTo(coilC[0] + c * 60, coilC[1] + s * 66); a.lineTo(coilC[0] + c * 232, coilC[1] + s * 255); a.stroke(); }
    });
    // re-draw stone edge over the hose
    const edge = [[556, 420], [544, 480], [526, 540], [512, 610], [502, 700], [472, 790], [410, 836], [380, 760], [440, 600], [460, 480], [480, 400], [520, 380]];
    R.dome(P(ragged(edge, 0, 6, 10, 5, 16), true, false), null, 0.12, 0.1, 20, 3);
    clipA(P(ragged(edge, 0, 6, 10, 5, 16), true, false), () => img(stoneTex));
    dots(stoneP, 10, 17, ['#7a50e0', '#30c0e0', '#f070d0'], 5, 9, 0.25, 2, [380, 560, 520, 800]);

    // ── zebra bulb ──
    const tube = [[380, 476], [396, 520], [410, 580], [416, 650], [404, 740], [370, 820], [330, 900], [304, 960], [296, 1034], [92, 1034], [96, 960], [76, 880], [62, 790], [64, 700], [84, 630], [130, 586], [200, 566], [270, 572], [320, 576], [356, 540]];
    const tubeP = P(tube, true, true);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 25. * vec2(fbm(p * 0.008), fbm(p * 0.008 + 4.));
      float ph = length(q - vec2(470., 860.)) / 46. + 0.3 * sin(q.y * 0.01 + q.x * 0.006) + 0.1 * sin(q.x * 0.03);
      float v = sin(6.2832 * ph);
      return vec3(smoothstep(-0.15, 0.15, v)) * vec3(.97, .96, .95) + .02; }`);
    R.dome(tubeP, '#ffffff', 0.12, 0.3, 70, 7);
    clipA(tubeP, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(zcv); a.restore(); });

    // ── left edge strips + grey rock ──
    R.flat(P([[-10, 470], [70, 466], [60, 520], [-10, 530]], true, false), '#f2a080', 0.02, 0);
    R.flat(P([...zig(-10, 540, 80, 520, 8, 10), [80, 570], [-10, 580]], true, false), '#3ad8e8', 0.02, 0);
    R.dome(P(blob(30, 498, 18, 14, 41, 8, 0.2)), '#7844f8', 0.06, 0.06, 6, 2);
    const lrock = P(ragged([[-10, 584], [60, 576], [96, 600], [104, 660], [86, 712], [30, 724], [-10, 720]], 0, 6, 10, 5, 18), true, false);
    R.dome(lrock, null, 0.06, 0.1, 18, 3);
    clipA(lrock, () => img(stoneTex));
    dots(lrock, 8, 19, ['#f070c8', '#f070c8', '#7a50e0'], 6, 9, 0.18, 2, [0, 590, 100, 710]);
    speck(P([[-10, 740], [60, 740], [60, 1034], [-10, 1034]], true, false), 120, 20, '#3a6ac0', 1.2, [0, 740, 60, 1024]);

    // ── bottom right: spotted rock, white tuft, dark blobs ──
    R.dome(P(blob(706, 820, 44, 70, 22, 14, 0.2)), '#202a44', 0.06, 0.12, 22, 3);
    speck(P(blob(706, 820, 44, 70, 22, 14, 0.2)), 500, 23, '#40b0d8', 1.2, [660, 740, 736, 900]);
    R.dome(P(blob(290, 1012, 46, 34, 24, 12, 0.2)), '#1a2034', 0.06, 0.1, 16, 3);
    speck(P(blob(290, 1012, 46, 34, 24, 12, 0.2)), 300, 25, '#4a90d0', 1.2, [240, 970, 340, 1034]);
    R.dome(P([[560, 930], [600, 900], [660, 900], [720, 920], [736, 960], [736, 990], [640, 960]], true, true), '#f0a070', 0.12, 0.1, 14, 1);
    const tr = rng(26);
    for (let i = 0; i < 220; i++) { const x = 566 + tr() * 170, y = 936 - tr() * 14, L = 26 + tr() * 60, an = -1.57 + (tr() - 0.5) * 1.8 + (x - 650) * 0.004; R.pipe(P([[x, y], [x + Math.cos(an) * L * 0.5 + (tr() - 0.5) * 6, y + Math.sin(an) * L * 0.5], [x + Math.cos(an) * L, y + Math.sin(an) * L]], false), 3.5, '#fbf8f4', 0.16, 0.04, 2); }
    const rock = P([[340, 1034], [350, 960], [390, 920], [470, 902], [560, 912], [640, 940], [700, 960], [736, 990], [736, 1034]], true, true);
    R.dome(rock, null, 0.1, 0.12, 30, 3);
    clipA(rock, () => {
      img(stoneTex);
      const br = rng(27); a.fillStyle = '#121218';
      for (let i = 0; i < 14; i++) a.fill(P(blob(360 + br() * 370, 930 + br() * 100, 10 + br() * 22, 14 + br() * 26, 400 + i, 10, 0.4)));
    });
    dots(rock, 16, 28, ['#f070c8', '#f070c8', '#9a60e8'], 6, 10, 0.24, 2, [350, 920, 726, 1024]);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.5, ao: 0.4, grain: 0.2 }),                          // 1 matte felt / clay
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.35, coat: 0.12, ao: 0.3 }),                          // 2 glossy candy
        E.mat({ dif: 1, spec: 0.2, shin: 14, wrap: 0.4, ao: 0.6, grain: 0.35 }),                           // 3 stone
        E.mat({ dif: 0.7, spec: 1.3, shin: 90, wrap: 0.3, coat: 0.45, ao: 0.4, rim: 0.4 }),               // 4 glossy blue blob
        E.mat({ dif: 1, spec: 0.6, shin: 30, wrap: 0.3, ao: 0.7, grain: 0.3 }),                            // 5 orange hose
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.2 }),                                      // 6 blue gear hub
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.45, ao: 0.4, coat: 0.08 })                           // 7 zebra satin
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.72], amb: [0.4, 0.4, 0.42],
      envTop: [1.2, 1.25, 1.3], envHor: [0.45, 0.5, 0.6], envBot: [0.05, 0.06, 0.1], envK: [0.3, 1.2, 0.3, 0],
      rimC: [0.4, 0.5, 0.7], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-6, 7, 0.6, 6]
    });
    E.grain(0.04, 14);
  }
});
