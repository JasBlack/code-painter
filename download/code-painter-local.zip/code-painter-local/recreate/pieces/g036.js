'use strict';
// g036 — "Chrome spirals and pearls": a tumble of grey-slate toy objects on black — chrome liquorice
// spirals, a cog, a pod of pearls, a ribbed bun, slate pills and a game pad over a mint zebra swirl.
REC.register('g036', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const W = 726, H = 1024;
    const rr = rng(36);
    const rot = (cx, cy, ang) => (u, v) => [cx + u * Math.cos(ang) - v * Math.sin(ang), cy + u * Math.sin(ang) + v * Math.cos(ang)];
    const rbox = (cx, cy, w, h, ang, rad) => {          // rounded rectangle, rotated
      const t = rot(cx, cy, ang), pts = [], n = 6;
      const r0 = Math.min(rad, w / 2, h / 2), hw = w / 2 - r0, hh = h / 2 - r0;
      const corners = [[hw, -hh, -Math.PI / 2], [hw, hh, 0], [-hw, hh, Math.PI / 2], [-hw, -hh, Math.PI]];
      for (const [x, y, a0] of corners) for (let i = 0; i <= n; i++) { const an = a0 + i / n * Math.PI / 2; pts.push(t(x + Math.cos(an) * r0, y + Math.sin(an) * r0)); }
      return P(pts, true, false);
    };
    const capsule = (x1, y1, x2, y2, r) => {
      const an = Math.atan2(y2 - y1, x2 - x1), p = new Path2D();
      p.arc(x2, y2, r, an - Math.PI / 2, an + Math.PI / 2); p.arc(x1, y1, r, an + Math.PI / 2, an + Math.PI * 1.5); p.closePath(); return p;
    };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const ol = (path, wd = 3, c = '#0a0a0a') => { a.save(); a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const spiralPts = (cx, cy, r0, r1, turns, sy = 1, ph = 0) => {
      const pts = [], n = Math.ceil(turns * 90);
      for (let i = 0; i <= n; i++) { const t = i / n, an = ph + t * turns * Math.PI * 2, r = r0 + (r1 - r0) * t; pts.push([cx + Math.cos(an) * r, cy + Math.sin(an) * r * sy]); }
      return pts;
    };
    // chrome liquorice spiral: black disc + chrome tube coiled on it
    const spiral = (cx, cy, r, turns, h0, sy = 1, ph = 0) => {
      R.dome(ellipseP(cx, cy, r + 4, (r + 4) * sy), '#0b0b0c', h0, 0.04, 6, 1);
      const pitch = r / turns;
      R.pipe(P(spiralPts(cx, cy, 2, r - pitch * 0.4, turns, sy, ph), false, false), pitch * 0.74, '#f0f0f0', h0 + 0.03, 0.06, 1);
      R.pipe(ellipseP(cx, cy, r - pitch * 0.2, (r - pitch * 0.2) * sy), pitch * 0.8, '#f2f2f2', h0 + 0.03, 0.07, 1);
    };

    // ── ground: black, with a pale mint zebra-swirl field in the upper left ──
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), '#060606', 0, 0);
    const bg = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 pale = mix(vec3(.95,.97,.94), vec3(.80,.87,.83), smoothstep(80., 420., length(p - vec2(170., 150.))));
      pale += 0.03 * (fbm(p * 0.01) - .5);
      float m = 1. - smoothstep(470., 520., p.y + 0.35 * max(p.x - 200., 0.));
      m *= 1. - smoothstep(430., 470., p.x);
      // zebra stripes: a curling fan of rays from under the slate pill
      vec2 q = p + 26. * vec2(fbm(p * 0.009), fbm(p * 0.009 + 7.)) - 13.;
      vec2 d = q - vec2(368., 162.);
      float th = atan(d.y, -d.x), r = length(d);
      float s = sin(th * 22. + r * 0.03 + 0.7 * sin(r * 0.02 + th * 2.));
      float zm = smoothstep(-8., 8., (p.y - 178.) - 0.25 * (330. - p.x)) * smoothstep(182., 200., p.x);
      vec3 z = mix(vec3(.03), vec3(.95,.96,.94), smoothstep(-0.2, 0.2, s));
      vec3 c = mix(pale, z, zm);
      return mix(vec3(.02), c, m); }`);
    a.drawImage(bg, 0, 0, W, H);
    // big black swirl bands
    soft(x => {
      x.fillStyle = '#060606';
      x.fill(P([[12, -10], [54, -10], [48, 22], [26, 52], [-10, 86]], true, false));
      x.fill(P([[98, -10], [172, -10], [168, 30], [150, 62], [138, 100], [128, 150], [122, 200], [128, 238], [150, 262], [188, 280], [200, 300], [160, 308], [118, 292], [90, 262], [83, 215], [90, 150], [99, 100], [101, 50]]));
      x.fill(P([[226, -10], [264, -10], [258, 16], [238, 30], [224, 14]]));
      x.fill(P([[292, 98], [328, 108], [334, 148], [302, 150], [282, 126]]));
      x.fill(P([[208, 172], [226, 160], [234, 166], [228, 186], [212, 192], [204, 184]]));
    }, 1.5);

    // ── left edge odds and ends ──
    R.dome(P([[-10, 285], [20, 290], [28, 340], [24, 400], [-10, 410]]), '#e6dccd', 0.05, 0.08, 10, 4);
    R.dome(P([[-10, 430], [22, 440], [34, 500], [28, 556], [-10, 560]]), '#5e564c', 0.05, 0.08, 10, 4);
    R.dome(circleP(62, 600, 36), '#7a8a80', 0.06, 0.12, 20, 2);
    R.dome(P([[-10, 640], [30, 650], [44, 700], [30, 745], [-10, 750]]), '#3d4234', 0.06, 0.1, 14, 4);
    // white cup
    R.dome(P([[-10, 735], [70, 742], [80, 768], [70, 830], [30, 838], [-10, 830]], true, false), '#e4e4e4', 0.1, 0.12, 12, 2);
    R.dome(ellipseP(52, 768, 26, 22, 0), '#9a9a9c', 0.2, 0.02, 8, 2);
    R.pipe(ellipseP(14, 872, 22, 26, 0), 13, '#c81e26', 0.12, 0.1, 6);

    // ── top: cup, slate pills, spiral ──
    R.dome(rbox(352, 22, 90, 90, 0.05, 30), '#a8a8a8', 0.08, 0.12, 14, 2);
    R.dome(ellipseP(352, 4, 42, 22, 0.05), '#e8e8e8', 0.2, 0.04, 8, 2);
    R.dome(rbox(612, 34, 210, 100, -0.13, 50), '#373f4a', 0.1, 0.12, 30, 2); ol(rbox(612, 34, 210, 100, -0.13, 50));
    R.dome(rbox(428, 86, 245, 96, -0.24, 48), '#5d6965', 0.14, 0.14, 30, 2); ol(rbox(428, 86, 245, 96, -0.24, 48));
    for (const [x, y, w, h] of [[372, 64, 40, 16], [447, 42, 30, 13], [508, 20, 22, 11]]) R.dome(rbox(x, y, w, h, -0.24, 2), '#62b6e6', 0.3, 0.02, 2, 6);
    spiral(706, 84, 80, 6, 0.2);
    R.dome(P([[690, 178], [740, 170], [740, 250], [700, 240], [686, 210]]), '#5a5c40', 0.1, 0.08, 10, 2);

    // ── ribbed bun ──
    const bun = ellipseP(487, 174, 142, 63, -0.2);
    R.dome(bun, '#b9b2a8', 0.2, 0.2, 40, 4); ol(bun, 3, '#2a2622');
    { const t = rot(487, 174, -0.2);
      for (let i = -6; i <= 6; i++) { const u = i * 20; const k = Math.sqrt(Math.max(0, 1 - (u / 141) ** 2)); R.groove(P([t(u * 0.98, -60 * k), t(u * 1.04, -10 * k), t(u, 58 * k)], false), 3, '#6c665e', 0.4, 0.04, 4); }
      R.groove(P([t(-130, 8), t(-60, 14), t(0, 14), t(60, 12), t(130, 4)], false), 5, '#5c564e', 0.42, 0.06, 4);
    }

    // ── game pad ──
    const pad = P([[468, 214], [560, 196], [660, 180], [740, 168], [740, 500], [620, 494], [520, 470], [462, 436], [440, 360], [440, 268]]);
    R.dome(pad, '#3b434e', 0.12, 0.16, 26, 2); ol(pad);
    for (const [x, y] of [[493, 258], [548, 238], [592, 222], [532, 333], [588, 316], [636, 298]]) R.dome(circleP(x, y, 15), '#6f747c', 0.28, 0.06, 10, 2);
    for (const [x, y] of [[517, 297], [573, 275], [619, 256], [671, 237]]) R.dome(rbox(x, y, 32, 30, -0.2, 4), '#6cc0ea', 0.28, 0.03, 4, 6);
    R.dome(P([[580, 362], [640, 338], [740, 330], [740, 470], [660, 472], [600, 460], [574, 420]]), '#30363f', 0.22, 0.1, 24, 2);

    // ── grey splatter with a cream fringe ──
    const gsDark = P([[30, 352], [80, 342], [132, 336], [160, 345], [172, 400], [182, 452], [160, 472], [118, 462], [80, 432], [42, 402], [30, 372]]);
    R.dome(gsDark, '#6b7571', 0.08, 0.05, 10, 4);
    const gsPts = [[152, 300], [138, 246], [150, 228], [168, 236], [174, 272], [214, 290], [262, 300], [306, 330], [350, 352], [330, 372], [300, 392], [254, 428], [224, 458], [196, 482], [166, 470], [150, 430], [136, 398], [148, 350]];
    const gs = P(gsPts);
    R.dome(gs, '#a7aeae', 0.1, 0.06, 10, 4); ol(gs, 2, '#4a5050');
    { const n = gsPts.length; for (let i = 0; i < n; i++) { const p = gsPts[i], q = gsPts[(i + 1) % n]; for (let k = 0; k < 9; k++) { const u = k / 9; R.bead(p[0] + (q[0] - p[0]) * u + (rr() - 0.5) * 6, p[1] + (q[1] - p[1]) * u + (rr() - 0.5) * 6, 2.5 + rr() * 2.5, '#ece4c8', 0.14, 0.04, 4); } } }
    for (const [x, y, rx, ry] of [[197, 316, 4, 9], [182, 382, 4, 9], [228, 352, 3, 7]]) R.paint(ellipseP(x, y, rx, ry, 0), '#101010');

    // ── steel-blue cylinder ──
    R.pipe(P([[96, 548], [452, 364]], false), 94, '#0c0c0c', 0.14, 0.1, 0);
    R.pipe(P([[96, 548], [452, 364]], false), 88, '#7a90a2', 0.16, 0.14, 6);
    R.dome(ellipseP(92, 552, 20, 44, -0.48), '#b8c4cc', 0.2, 0.06, 8, 6);
    for (const u of [0.33, 0.6]) { const x = 96 + (452 - 96) * u, y = 548 + (364 - 548) * u; R.pipe(P([[x - 20, y - 39], [x + 20, y + 39]], false), 7, '#f2f4f6', 0.3, 0.02, 6); }

    // ── cog with a spiral face ──
    { const cx = 425, cy = 485, n = 22, pts = [];
      for (let i = 0; i < n * 8; i++) { const an = i / (n * 8) * Math.PI * 2, c = Math.cos(an * n); pts.push([cx + Math.cos(an) * (110 + 12 * Math.max(-0.6, c)), cy + Math.sin(an) * (110 + 12 * Math.max(-0.6, c))]); }
      R.dome(P(pts, true, false), '#ece6de', 0.18, 0.1, 10, 1);
      R.dome(circleP(cx, cy, 100), '#d8d2ca', 0.2, 0.04, 6, 1);
      spiral(cx - 2, cy + 8, 92, 7, 0.24);
    }

    // ── taupe pebble ──
    const peb = P([[110, 555], [195, 528], [250, 535], [285, 568], [295, 625], [285, 690], [240, 745], [170, 785], [95, 795], [45, 775], [25, 730], [30, 670], [60, 605]]);
    R.dome(peb, '#928b7e', 0.18, 0.12, 40, 4); ol(peb, 4);
    for (const [x, y, r] of [[190, 546, 5], [70, 712, 4], [54, 690, 3]]) R.dome(ellipseP(x, y, r * 1.6, r, -0.6), '#e8b840', 0.32, 0.01, 2, 4);
    R.paint(P([[38, 640], [30, 700], [36, 760], [44, 700]]), '#c4a040');
    R.dome(P([[226, 540], [248, 548], [252, 562], [240, 566]]), '#101010', 0.32, 0.01, 2, 0);

    // ── bottom-left spiral ──
    spiral(198, 826, 122, 9, 0.2, 0.9);

    // ── pearl pod ──
    { const ang = -0.28, t = rot(300, 688, ang), L = 520;
      const end = t(L, 0);
      const pod = capsule(300, 688, end[0], end[1], 64);
      R.flat(pod, '#141416', 0.2, 1);
      // overflow pearls above the top band
      for (let u = 60; u < L; u += 54) { const [x, y] = t(u + 10, -84 + 4 * Math.sin(u)); R.bead(x, y, 28, '#efe7ea', 0.26, 0.12, 3); }
      for (const [u, v, r] of [[10, -78, 18], [-30, -60, 15]]) { const [x, y] = t(u, v); R.bead(x, y, r, '#efe7ea', 0.26, 0.1, 3); }
      R.pipe(pod, 22, '#f0f0f0', 0.3, 0.08, 1);
      for (const v of [-32, 6, 40]) for (let u = (v === 6 ? -10 : 18); u < L; u += 54) {
        const [x, y] = t(u + (rr() - 0.5) * 6, v + (rr() - 0.5) * 6); if (Math.hypot(...[u, v]) < 0 ) continue;
        if (u < 0 && Math.abs(v) > 30) continue;
        R.bead(x, y, 27 + rr() * 3, '#f0e8ec', 0.3, 0.14, 3);
      }
      const [sx, sy] = t(66, 50);
      R.dome(rbox(sx, sy, 22, 66, ang, 10), '#0a0a0a', 0.48, 0.03, 4, 1);
      R.pipe(rbox(sx, sy, 22, 66, ang, 10), 3, '#e8e8e8', 0.52, 0.01, 1);
    }

    // ── bottom: army box, pebbles, chrome bands, ring, discs ──
    R.dome(circleP(442, 770, 36), '#a2b2a6', 0.1, 0.1, 20, 2);
    R.dome(rbox(562, 727, 175, 62, -0.12, 8), '#585e48', 0.16, 0.06, 6, 4);
    R.dome(P([[700, 590], [740, 580], [740, 740], [668, 735], [668, 680]]), '#c4d2c6', 0.1, 0.1, 14, 2);
    R.dome(circleP(702, 702, 9), '#0a0a0a', 0.2, 0.02, 4, 2);
    const band = (pts, wd, h0) => { const pth = P(pts, false); R.pipe(pth, wd + 9, '#0c0c0c', h0, 0.1, 2); R.pipe(pth, wd, '#f2f2f2', h0 + 0.02, 0.12, 1); R.pipe(pth, 5, '#151515', h0 + 0.1, 0.01, 0); };
    band([[350, 880], [260, 902], [150, 920], [-20, 934]], 30, 0.18);
    band([[740, 758], [620, 774], [530, 794], [440, 818], [380, 840], [345, 872], [335, 912], [345, 952], [372, 992], [420, 1034]], 44, 0.2);
    band([[540, 842], [462, 852], [404, 880], [384, 920], [400, 966], [452, 1020]], 26, 0.26);
    R.dome(circleP(620, 970, 116), '#4f565f', 0.18, 0.08, 30, 2);
    R.dome(P([[640, 862], [700, 880], [730, 940], [730, 1040], [610, 1040], [600, 960], [620, 900]]), '#5c636c', 0.22, 0.03, 20, 2);
    R.pipe(P([[600, 878], [560, 900], [536, 950], [540, 1010], [566, 1050]], false), 26, '#cfd0d2', 0.26, 0.08, 1);
    R.pipe(circleP(620, 970, 172), 10, '#0c0c0c', 0.2, 0.06, 2);
    R.pipe(circleP(620, 970, 142), 56, '#efefef', 0.22, 0.14, 1);
    R.pipe(circleP(620, 970, 113), 8, '#0c0c0c', 0.3, 0.02, 2);
    R.dome(circleP(248, 1000, 100), '#d6d9ca', 0.2, 0.14, 50, 4);
    R.dome(circleP(56, 992, 72), '#4c5242', 0.2, 0.12, 40, 4);
    R.dome(circleP(56, 992, 40), '#3c4234', 0.3, 0.04, 20, 4);
    R.bead(46, 980, 8, '#e8c040', 0.34, 0.02, 4);

    // ── soap bubbles + white beads ──
    for (const [x, y, r] of [[52, 66, 30], [22, 135, 27], [14, 205, 23], [14, 620, 22]]) {
      R.bead(x, y, r, '#788084', 0.3, 0.3, 5);
    }
    for (const [x, y, r] of [[127, 129, 11], [104, 271, 11]]) R.bead(x, y, r, '#f4f4f4', 0.2, 0.15, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, metal: 0.3, spec: 1.1, shin: 50, rim: 0.25, ao: 0.6, coat: 0.08, wrap: 0.3 }), // 1 chrome
        E.mat({ dif: 1, spec: 0.25, shin: 18, wrap: 0.45, ao: 0.5, coat: 0.04 }),                       // 2 slate plastic
        E.mat({ dif: 0.8, metal: 0.35, spec: 1.1, shin: 45, ao: 0.6, coat: 0.15, iri: 0.04, tint: [1, 0.96, 1] }), // 3 pearl
        E.mat({ dif: 1, spec: 0.12, shin: 10, wrap: 0.5, ao: 0.5, grain: 0.12 }),                        // 4 clay / stone
        E.mat({ dif: 0.8, spec: 1.6, shin: 120, iri: 0.8, coat: 0.35, rim: 0.6 }),                       // 5 soap bubble
        E.mat({ dif: 1, spec: 0.6, shin: 40, wrap: 0.3, coat: 0.12, ao: 0.4 })                           // 6 glossy plastic
      ],
      light: [-0.5, 0.6, 0.65], lc: [0.85, 0.86, 0.86], amb: [0.32, 0.33, 0.33],
      envTop: [1.1, 1.1, 1.1], envHor: [0.72, 0.73, 0.73], envBot: [0.04, 0.04, 0.04], envK: [0.4, 1.2, 0.0, 0],
      rimC: [0.3, 0.32, 0.32], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 90], shadow: [-6, 7, 0.65, 6]
    });

    // depth-of-field: soften the bottom strip
    { const c = E.blur(E.snapshot(), 3.5), m = E.newCanvas(), x = m.getContext('2d');
      x.drawImage(c, 0, 0); x.globalCompositeOperation = 'destination-in';
      const g = x.createLinearGradient(0, 830 * S, 0, 930 * S); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,1)');
      x.fillStyle = g; x.fillRect(0, 0, m.width, m.height); E.draw(m); }
    E.bloom(0.12, 10);
    E.grain(0.03, 36);
  }
});
