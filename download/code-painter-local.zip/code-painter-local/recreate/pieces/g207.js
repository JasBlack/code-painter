'use strict';
// g207 — "Goggled noodle platter": a pale-blue clay platter with a red-lipped noodle cavity, spiral discs and
// goggle lenses, a mint alien head dripping pink noodles, glowing golden limbs and a fingerprint moon on black.
REC.register('g207', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const st = (x, path, col, w) => { x.strokeStyle = col; x.lineWidth = w; x.stroke(path); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const GOLD = '#e8cc58';

    // ── 1. black ground, stripe fans ──
    R.flat(rrect(-10, -10, 600, 1050, 0), '#0c0b10', 0, 0);
    const FAN = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = normalize(vec2(0.9, 0.44));
      float s = sin(6.2832 * (dot(p, d) / 36. + 0.04 * sin(p.y * 0.012)));
      float s2 = sin(6.2832 * (dot(p, normalize(vec2(0.92, 0.4))) / 31. + 0.3));
      vec3 wall = mix(vec3(0.80, 0.76, 0.81), vec3(0.24, 0.22, 0.28), smoothstep(0.35, 0.65, s));
      vec3 blk = mix(vec3(0.05, 0.045, 0.06), vec3(0.52, 0.50, 0.58), smoothstep(-0.25, 0.35, s2) * smoothstep(110., 200., p.y));
      return p.x < 250. ? wall : blk; }`);
    const wall = Q([-10, 215, 40, 222, 110, 262, 165, 300, 150, 420, 110, 560, 60, 640, -10, 650], true);
    R.flat(wall, '#c8bccb', 0.0, 0);
    clipA(wall, () => img(FAN));
    const fan2 = Q([300, 170, 380, 145, 470, 165, 500, 260, 470, 340, 320, 340, 290, 250], true);
    soft(x => { x.fillStyle = '#fff'; x.fill(fan2); }, 18, 1, 'destination-out');
    clipA(fan2, () => { a.save(); a.globalAlpha = 0.85; img(FAN); a.restore(); });
    soft(x => { x.fillStyle = '#0c0b10'; x.lineWidth = 30; x.strokeStyle = '#0c0b10'; x.stroke(fan2); }, 16, 0.6);
    // grey hair streaks on the right
    soft(x => { const r = rng(71); for (let i = 0; i < 13; i++) { const y = 240 + i * 5.5 + r() * 4; x.strokeStyle = 'rgba(180,185,210,0.8)'; x.lineWidth = 2.5 + r() * 3; x.beginPath(); x.moveTo(430 + r() * 40, y + 24); x.bezierCurveTo(480, y + 5, 520, y + 16, 590, y - 6); x.stroke(); } }, 1.5, 0.95);

    // ── 2. fingerprint moon (top right) ──
    const moon = circleP(546, 95, 116);
    R.dome(moon, lg(410, 0, 578, 200, [[0, '#8a9ac0'], [0.5, '#8e9ab2'], [1, '#848ea6']]), 0.05, 0.12, 30, 1);
    const RING = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(570., 111.); float r = length(d) + 2. * sin(atan(d.y, d.x) * 3. + length(d) * 0.02);
      float s = sin(6.2832 * r / 7.2);
      float k = smoothstep(135., 80., length(p - vec2(570., 111.)));
      return mix(vec3(1.0), vec3(0.08, 0.08, 0.1), smoothstep(0.45, 0.75, s) * k); }`);
    clipA(moon, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(RING); a.restore(); });

    // ── 3. pale glow sphere + snowflakes (top left) ──
    soft(x => { fe(x, 100, 172, 54, 58, 0, '#e4e8f4'); }, 8, 1);
    soft(x => {
      x.fillStyle = '#dceaf8';
      for (const [cx, cy, r] of [[54, 22, 18], [119, 14, 22], [61, 72, 19], [94, 61, 22], [108, 34, 18], [151, 14, 20], [150, 70, 20], [180, 40, 16], [80, 110, 16], [190, 8, 16], [130, 100, 18], [165, 110, 14], [30, 70, 15], [85, 2, 16], [22, 28, 12]])
        for (let k = 0; k < 6; k++) { const t = k / 6 * 6.283; x.beginPath(); x.arc(cx + Math.cos(t) * r * 0.55, cy + Math.sin(t) * r * 0.55, r * 0.42, 0, 6.283); x.fill(); }
    }, 1.5, 0.9);

    // ── 4. golden translucent arms ──
    const armL = Q([-10, 92, 8, 150, 50, 205, 110, 240, 180, 266, 235, 285], false, false);
    soft(x => { st(x, armL, GOLD, 58); }, 6, 0.9);
    soft(x => { st(x, armL, '#c8c0a8', 44); }, 2, 1);
    soft(x => { const r = rng(5); for (let i = 0; i < 14; i++) { const t = i / 13, px = 14 + t * 175, py = 175 + t * 85 - Math.sin(t * 3) * 12; x.save(); x.translate(px, py); x.rotate(0.5 + t * 0.3); x.fillStyle = '#e8eef6'; x.fillRect(-3, -9, 6 + r() * 3, 16); x.restore(); } }, 0.8, 0.9);
    const armR = Q([352, 28, 356, 64, 372, 96, 400, 96], false, false);
    soft(x => { st(x, armR, GOLD, 26); }, 5, 0.9);
    soft(x => { st(x, armR, '#b8b090', 14); }, 1.5, 1);
    const armR2 = Q([368, 108, 352, 160, 328, 210, 302, 258], false, false);
    soft(x => { st(x, armR2, GOLD, 56); }, 6, 0.9);
    soft(x => { st(x, armR2, '#c8c4a2', 42); }, 2, 1);
    soft(x => { for (let i = 0; i < 10; i++) { const t = i / 9, px = 368 - t * 62, py = 118 + t * 132; x.save(); x.translate(px, py); x.rotate(-0.9); x.fillStyle = '#e6f2fa'; x.fillRect(-3, -10, 7, 18); x.restore(); } }, 0.8, 0.85);
    R.bead(350, 28, 16, '#f2c030', 0.2, 0.12, 5);
    R.bead(405, 95, 15, '#f2c030', 0.2, 0.12, 5);
    R.bead(4, 98, 13, '#f2c030', 0.2, 0.12, 5);

    // ── 5. red throat glow behind the head ──
    soft(x => { x.fillStyle = '#c8a4ac'; x.fill(Q([125, 190, 200, 186, 300, 180, 306, 260, 300, 330, 130, 334, 118, 260])); }, 6, 1);
    soft(x => { fe(x, 240, 252, 48, 50, 0, '#f03040'); fe(x, 165, 250, 36, 34, 0, '#f6aca0'); }, 10, 0.95);

    // ── 6. bottom shadow ──
    soft(x => { fe(x, 300, 870, 250, 135, 0, '#4a4656'); fe(x, 290, 1000, 200, 40, 0, '#26232c'); }, 34, 1);

    // ── 7. the platter blob ──
    const blob_ = Q([100, 370, 130, 345, 180, 340, 240, 330, 260, 300, 300, 250, 370, 245, 410, 300, 470, 305, 530, 330, 548, 390, 540, 460, 548, 560, 550, 650, 540, 720, 520, 742, 490, 768, 450, 795, 400, 825, 340, 852, 300, 858, 250, 852, 170, 822, 100, 796, 40, 780, 18, 762, 8, 700, 6, 640, 22, 590, 38, 540, 42, 470, 60, 420]);
    R.dome(blob_, lg(0, 300, 0, 850, [[0, '#a4b8dc'], [0.5, '#b6c9e8'], [0.85, '#c6d6f0'], [1, '#8c9cbc']]), 0.08, 0.3, 40, 1);
    clipA(blob_, () => soft(x => {
      fe(x, 290, 785, 220, 40, 0, '#d4e2f8');                      // bright rim
      fe(x, 40, 660, 40, 80, 0, '#7a84a0');
    }, 14, 0.9));
    soft(x => { st(x, Q([548, 640, 530, 742, 490, 768, 450, 795, 400, 825, 340, 852, 300, 858, 250, 852, 170, 822, 100, 796, 40, 780, -10, 764], false, true), '#7a86a6', 18); }, 9, 0.8);
    // dark window on the right
    R.flat(Q([440, 445, 470, 440, 515, 448, 520, 480, 505, 500, 465, 505, 445, 485]), '#2e2a30', 0.1, 0);

    // ── 8. cavity: pink flesh, noodles, lips ──
    const cav = Q([160, 398, 220, 392, 300, 392, 360, 400, 410, 410, 440, 425, 452, 460, 450, 520, 440, 570, 420, 610, 395, 645, 360, 675, 300, 690, 250, 694, 215, 672, 170, 650, 130, 625, 100, 595, 80, 560, 72, 520, 80, 480, 110, 440, 140, 410]);
    R.dome(cav, rg(310, 520, 10, 290, 520, 190, [[0, '#fff8fc'], [0.45, '#fbe2ea'], [0.8, '#f4b0b8'], [1, '#f07a7c']]), 0.06, -0.04, 10, 1);
    clipA(cav, () => soft(x => { fe(x, 180, 440, 50, 40, 0, '#f45e60'); }, 16, 0.9));
    // blue-grey noodle masses
    const nL = Q([78, 545, 100, 530, 150, 528, 200, 532, 245, 545, 262, 600, 258, 650, 250, 690, 215, 668, 170, 645, 130, 622, 100, 595, 82, 568]);
    const nR = Q([330, 410, 400, 408, 440, 425, 452, 460, 450, 520, 440, 570, 420, 610, 398, 640, 385, 600, 368, 540, 345, 480, 330, 440]);
    const noodles = (path, seed, n) => {
      R.flat(path, '#46708a', 0.1, 0);
      clipA(path, () => {
        const r = rng(seed);
        for (let i = 0; i < n; i++) {
          let x = 90 + r() * 380, y = 400 + r() * 300; const pp = [[x, y]]; let ang = r() * 6.283;
          for (let k = 0; k < 6; k++) { ang += (r() - 0.5) * 2.6; x += Math.cos(ang) * 9; y += Math.sin(ang) * 9; pp.push([x, y]); }
          if (!a.isPointInPath(path, pp[0][0] * S, pp[0][1] * S)) continue;
          R.pipe(P(pp, false, true), 5.5, r() < 0.5 ? '#72a2c0' : '#6094b2', 0.16, 0.05, 2);
        }
      });
    };
    noodles(nL, 11, 900); noodles(nR, 12, 900);
    // pink noodle strands from the snout
    { const r = rng(21);
      for (let i = 0; i < 26; i++) {
        let x = 225 + r() * 40, y = 265 + r() * 20; const pp = [[x, y]];
        for (let k = 0; k < 12; k++) { x += (r() - 0.5) * 14 + (k > 6 ? (r() - 0.5) * 10 : 0); y += 20 + r() * 8; pp.push([x, y]); }
        R.pipe(P(pp, false, true), 2.6, r() < 0.5 ? '#f4c4c8' : '#eaa8b0', 0.2, 0.03, 2);
      } }
    // lips + teeth
    const lipU = Q([248, 630, 262, 618, 290, 606, 330, 598, 362, 594, 388, 602, 394, 612, 360, 606, 320, 610, 285, 620, 258, 634]);
    const lipL = Q([248, 634, 270, 626, 310, 622, 350, 618, 392, 614, 386, 640, 360, 662, 320, 674, 285, 670, 262, 656]);
    R.flat(Q([258, 634, 285, 616, 330, 604, 390, 606, 386, 622, 340, 626, 290, 632]), '#4a1018', 0.2, 0);
    for (let i = 0; i < 9; i++) { const t = i / 8, x = 270 + t * 112, y = 621 - t * 16; R.dome(rrect(x - 6, y - 8, 12, 15, 3), '#f4f0e8', 0.28, 0.05, 3, 5); }
    R.dome(lipU, '#f42028', 0.26, 0.08, 4, 7);
    R.dome(lipL, lg(260, 620, 380, 680, [[0, '#f4303a'], [1, '#f01020']]), 0.24, 0.16, 12, 7);

    // ── 9. spiral discs ──
    const SP = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(120., 662.)) / vec2(1.0, 0.76);
      float r = length(d), th = atan(d.y, d.x);
      float s = sin(6.2832 * (r / 15. + th / 6.2832));
      vec3 c = mix(vec3(0.86, 0.9, 0.97), vec3(0.04, 0.04, 0.06), smoothstep(0.2, 0.5, s));
      c = mix(vec3(0.55, 0.57, 0.67), c, smoothstep(14., 30., r));
      vec2 e = p - vec2(192., 326.); float r2 = length(e), t2 = atan(e.y, e.x);
      float s2 = r2 > 34. ? sin(6.2832 * (r2 / 12.)) : sin(6.2832 * (r2 / 4.5 + t2 / 6.2832));
      vec3 c2 = mix(vec3(0.95, 0.95, 0.97), vec3(0.05, 0.05, 0.07), smoothstep(-0.1, 0.25, s2));
      if (r2 < 34.) c2 = mix(vec3(0.82, 0.84, 0.88), vec3(0.42, 0.44, 0.5), smoothstep(-0.2, 0.4, s2));
      return p.y > 450. ? c : c2; }`);
    const sp1 = ellipseP(112, 665, 92, 72, 0);
    soft(x => { fe(x, 112, 665, 92, 72, 0, '#fff'); }, 4, 1, 'destination-out', blob_);
    clipA(sp1, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(SP); a.restore(); });
    const sp2 = new Path2D(); sp2.moveTo(192 + 55.4, 358); sp2.arc(192, 326, 64, 0.5236, 2.618, true); sp2.closePath();
    R.dome(sp2, '#f0f0f4', 0.2, 0.06, 6, 4);
    clipA(sp2, () => img(SP));
    R.bead(150, 312, 8, '#f6d020', 0.3, 0.06, 5);

    // cream bone bar on the left
    R.pipe(Q([30, 528, 100, 516, 182, 502], false, true), 30, '#cfcaa6', 0.3, 0.12, 1);
    R.pipe(Q([72, 540, 78, 574], false, true), 18, '#cfcaa6', 0.3, 0.1, 1);

    // ── 10. goggles plate + lenses ──
    const plate = Q([250, 300, 265, 262, 300, 245, 360, 248, 395, 280, 420, 300, 470, 302, 515, 315, 540, 345, 548, 390, 530, 420, 480, 425, 420, 418, 360, 400, 300, 385, 262, 360]);
    soft(x => { st(x, plate, GOLD, 10); }, 5, 0.8);
    R.dome(plate, lg(260, 250, 520, 420, [[0, '#a8bcdc'], [1, '#8ca2c8']]), 0.12, 0.08, 10, 1);
    for (const [cx, cy, r] of [[328, 293, 48], [441, 360, 56]]) {
      R.dome(circleP(cx, cy, r), '#0c0c12', 0.2, 0.16, 10, 2);
      R.pipe(circleP(cx, cy, r * 0.85), 5, '#b48a6a', 0.36, 0.04, 5);
      R.dome(circleP(cx, cy, r * 0.8), lg(cx, cy - r, cx, cy + r, [[0, '#e8f6fc'], [0.35, '#a8d0ea'], [0.6, '#6a8ab0'], [1, '#3a4a68']]), 0.38, 0.12, r * 0.6, 2);
    }
    // holes and yellow buttons on the plate
    for (const [x, y, r] of [[265, 364, 8], [302, 372, 4], [318, 390, 6], [270, 395, 3]]) R.flat(circleP(x, y, r), '#0a0a10', 0.16, 0);
    for (const [x, y, r] of [[360, 362, 8], [512, 346, 8]]) R.bead(x, y, r, '#f8d820', 0.18, 0.06, 5);

    // ── 11. alien head with eyes ──
    const head = Q([160, 32, 205, 12, 255, 15, 292, 38, 312, 80, 314, 122, 310, 160, 300, 190, 288, 215, 276, 240, 268, 270, 258, 305, 246, 332, 228, 332, 212, 300, 192, 268, 170, 250, 150, 240, 128, 222, 108, 195, 100, 165, 108, 130, 130, 98, 148, 62]);
    R.dome(head, lg(150, 20, 260, 320, [[0, '#a8d4ea'], [0.35, '#a8ccd8'], [0.6, '#b2c4c4'], [1, '#c4d0c8']]), 0.18, 0.3, 34, 1);
    clipA(head, () => soft(x => { fe(x, 220, 200, 26, 50, 0.3, '#d8e8f0'); fe(x, 175, 170, 40, 22, 0.3, '#98aeb4'); fe(x, 255, 60, 30, 26, 0, '#c8eaf8'); }, 10, 0.7));
    for (const d of [[200, 150, 188, 200, 186, 240, 196, 270], [232, 160, 236, 210, 240, 260, 240, 312], [262, 170, 262, 215, 258, 262], [160, 190, 165, 222, 160, 240]]) R.pipe(Q(d, true, false), 8, '#d4e8f0', 0.46, 0.06, 1);
    R.dome(circleP(275, 125, 31), '#e8d8a0', 0.4, 0.08, 6, 5);
    R.dome(circleP(276, 125, 25), '#f6f4ee', 0.44, 0.08, 8, 5);
    R.dome(circleP(283, 128, 13), '#3c1423', 0.5, 0.04, 4, 5);
    R.bead(287, 134, 3, '#ffffff', 0.55, 0.02, 5);
    R.dome(circleP(126, 166, 16), '#f2f2f6', 0.3, 0.08, 6, 5);
    R.dome(circleP(129, 170, 9), '#101014', 0.34, 0.04, 3, 5);

    // ── 12. black splats, orange blobs ──
    soft(x => {
      x.strokeStyle = '#050506';
      st(x, Q([140, 494, 200, 488, 242, 482, 272, 460], false, false), '#050506', 22);
      st(x, Q([222, 486, 252, 504, 278, 506], false, false), '#050506', 15);
      st(x, Q([180, 494, 168, 534], false, false), '#050506', 18);
      st(x, Q([330, 400, 380, 410, 418, 426], false, false), '#050506', 13);
      st(x, Q([372, 410, 362, 432], false, false), '#050506', 10);
    }, 1, 1);
    R.dome(Q([358, 716, 372, 702, 386, 704, 396, 690, 410, 696, 412, 712, 432, 708, 446, 720, 440, 740, 418, 742, 400, 732, 382, 744, 370, 738, 376, 724]), '#f8a010', 0.24, 0.05, 4, 5);
    R.dome(Q([290, 424, 302, 410, 318, 414, 330, 406, 344, 416, 334, 430, 314, 430, 300, 436]), '#f6a618', 0.26, 0.04, 3, 5);
    // dark lens on the platter
    R.dome(circleP(460, 655, 42), '#0c0c12', 0.14, 0.1, 8, 2);
    R.dome(circleP(460, 655, 30), rg(452, 645, 4, 460, 655, 30, [[0, '#c8c4cc'], [1, '#8a8690']]), 0.2, 0.06, 10, 1);
    // bubbles
    for (const [x, y, r] of [[318, 860, 9], [325, 885, 6], [325, 930, 10], [330, 965, 10], [222, 965, 4], [182, 748, 7], [238, 728, 10], [238, 790, 7], [348, 460, 4], [420, 545, 5], [470, 640, 3], [520, 750, 4], [30, 600, 4], [150, 380, 6], [75, 455, 5], [300, 240, 4], [430, 200, 4], [470, 145, 3], [536, 230, 4], [520, 330, 3], [440, 320, 5]])
      R.bead(x, y, r, '#eef2f8', 0.3, Math.min(0.2, r * 0.02), 5);

    // ── 13. translucent golden limb (right) ──
    const limb = Q([510, 380, 500, 450, 504, 530, 525, 600, 545, 660, 548, 720, 525, 775, 492, 825, 465, 885, 444, 945, 430, 1030], false, true);
    const limbB = Q([455, 900, 500, 950, 540, 1000, 560, 1040], false, true);
    const limbC = Q([500, 790, 540, 800, 590, 790], false, true);
    const limbD = Q([520, 958, 560, 990, 590, 1010], false, true);
    const limbE = Q([565, 425, 578, 480, 570, 560, 585, 640], false, true);
    const limbF = Q([-12, 690, 12, 740, -12, 800], false, true);
    soft(x => { for (const [pth, w] of [[limb, 42], [limbB, 30], [limbC, 40], [limbD, 26], [limbE, 60], [limbF, 22]]) st(x, pth, GOLD, w + 10); }, 5, 0.95);
    soft(x => { for (const [pth, w] of [[limb, 42], [limbB, 30], [limbC, 40], [limbD, 26], [limbE, 60], [limbF, 22]]) st(x, pth, '#fff', w - 4); }, 3, 1, 'destination-out');
    soft(x => { for (const [pth, w] of [[limb, 42], [limbB, 30], [limbC, 40], [limbD, 26], [limbE, 60], [limbF, 22]]) st(x, pth, '#a4a2ac', w - 4); }, 3, 0.6);
    soft(x => { const r = rng(31); x.fillStyle = '#d0e4f4'; for (let i = 0; i < 16; i++) { x.beginPath(); x.arc(556 + r() * 14, 420 + i * 16, 2 + r() * 2, 0, 6.283); x.fill(); } }, 1, 0.8);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.08, rim: 0.2 }),                 // 1 clay
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, ao: 0.3, coat: 0.3 }),                             // 2 glass / black gloss
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.4 }),
        E.mat({ dif: 0.5, spec: 0.3, shin: 40, wrap: 0.6, emis: 0.45 }),                                   // 4 spiral disc
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.2 }),                            // 5 beads / gloss
        E.mat({}),
        E.mat({ dif: 0.8, spec: 1.0, shin: 50, wrap: 0.4, emis: 0.25, coat: 0.1 })                         // 7 red lips
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.76], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.1, 0.12, 0.16], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.45, 6]
    });
  }
});
