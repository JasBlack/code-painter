'use strict';
// g200 — "Ice ghost, red roe": a frosted-glass ghost with two eyes and a chrome grin cradling red speckled pearls,
// zebra tentacles and a pale glass horn curling over a deep blue night, beside an orange neon rail with bead bugs.
REC.register('g200', {
  w: 1024, h: 726,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S, o = E.out;
    const img = (cv, al = 1) => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const clipB = (path, fn) => { a.save(); hx.save(); a.clip(path); hx.clip(path); fn(); hx.restore(); a.restore(); };
    const soft = (fn, blur, al = 1, op) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = al; if (op) a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const rad = (x, y, r0, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, r0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const CYAN = 'rgba(110,220,245,0.95)';
    const rim = (path, w = 4) => { soft(x => { x.strokeStyle = 'rgba(80,200,240,0.6)'; x.lineWidth = w * 3; x.stroke(path); }, w); a.lineWidth = w; a.strokeStyle = CYAN; a.stroke(path); };

    // ── 1. night ground: blue field (quadratic colour fit) + dark strip left of the neon rail ──
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 q = p / vec2(1024., 726.) - .5;
      vec3 c = vec3(0.205, 0.229, 0.511) + vec3(0.178, 0.178, 0.223) * q.x + vec3(-0.201, -0.180, -0.617) * q.y + vec3(-0.582, -0.608, -0.958) * q.x * q.x
        + vec3(0.048, -0.002, -0.002) * q.y * q.y + vec3(0.105, 0.061, -0.247) * q.x * q.y;
      float lx = 158. - 11. * p.y / 700.;
      vec3 l = mix(vec3(0.16, 0.17, 0.5), vec3(0.08, 0.075, 0.075), smoothstep(0., 520., p.y));
      c = mix(l, c, smoothstep(lx - 6., lx + 6., p.x));
      c += vec3(0.5, 0.12, 0.02) * exp(-abs(p.x - lx) / 16.) * 0.55;
      c += vec3(0.35, 0.08, 0.0) * exp(-abs(p.x - lx) / 4.5);
      return c + (hash(p * .71) - .5) * .05; }`));
    // stars / specks
    { const r = rng(200); for (let i = 0; i < 90; i++) { const x = r() * 1024, y = r() * 726, s = 0.6 + r() * 1.6;
      a.fillStyle = r() < 0.15 ? 'rgba(255,120,60,0.8)' : `rgba(150,220,250,${0.4 + r() * 0.5})`; a.fill(circleP(x, y, s)); } }
    // neon rail core
    soft(x => { x.strokeStyle = 'rgba(255,90,20,0.9)'; x.lineWidth = 22; x.beginPath(); x.moveTo(158, -10); x.lineTo(146, 740); x.stroke(); }, 6);
    soft(x => { x.strokeStyle = '#f8b066'; x.lineWidth = 12; x.beginPath(); x.moveTo(158, -10); x.lineTo(146, 740); x.stroke(); }, 1.5);

    // ── 2. bead column and two capsule bugs ──
    for (const y of [155, 200, 405, 446, 490, 622, 662, 702]) R.bead(196, y, 20, rad(190, y - 6, 2, 22, [[0, '#9aa2b0'], [0.6, '#56606e'], [1, '#2a3038']]), 0.05, 0.28, 3);
    const bug = (cx, cy, s, rot) => {
      a.save(); hx.save(); for (const c of [a, hx]) { c.translate(cx, cy); c.rotate(rot); c.scale(s, s); }
      const body = P([[-62, -8], [-40, -26], [10, -32], [40, -28], [62, -12], [66, 8], [56, 26], [20, 34], [-30, 30], [-50, 18], [-60, 10]], true, true);
      soft(x => { x.save(); x.translate(cx, cy); x.rotate(rot); x.scale(s, s); x.strokeStyle = 'rgba(90,210,245,0.8)'; x.lineWidth = 9; x.stroke(body); x.restore(); }, 2);
      R.dome(body, '#121014', 0.1, 0.2, 18, 3);
      R.dome(P([[-62, -8], [-82, -14], [-86, 0], [-82, 14], [-60, 10]], true, true), '#141216', 0.1, 0.1, 6, 3);
      for (const [x, y, r] of [[-8, -6, 6], [8, 4, 7], [22, -10, 5], [-24, 10, 4], [30, 10, 4], [-12, 14, 3]]) R.flat(circleP(x, y, r), '#e8302a', 0.25, 2);
      R.pipe(P([[-84, -8], [-96, -20]], false), 4, '#e83a2a', 0.15, 0.03, 2); R.pipe(P([[-84, 8], [-96, 22]], false), 4, '#e83a2a', 0.15, 0.03, 2);
      R.pipe(P([[64, -6], [80, -18]], false), 4, '#e83a2a', 0.15, 0.03, 2); R.pipe(P([[64, 4], [78, 12]], false), 4, '#e83a2a', 0.15, 0.03, 2);
      hx.restore(); a.restore();
    };
    bug(205, 64, 1, 0); bug(196, 296, 1.05, -0.06);

    // ── 3. zebra tentacles (fitted stripe phase fields) ──
    const T1 = P([[149,560],[161,549],[207,518],[238,488],[257,434],[268,372],[284,318],[315,265],[353,218],[384,195],[410,188],[440,205],[455,250],[461,334],[438,395],[384,472],[338,518],[315,541],[284,565],[222,584],[176,580]], true, true), T2 = P([[232,726],[262,690],[300,655],[350,615],[410,580],[470,550],[530,530],[600,525],[660,520],[710,490],[760,440],[800,405],[828,395],[835,430],[828,480],[808,540],[770,600],[720,650],[660,700],[620,726]], true, true);
    const ZA = E.fx(`const float ZAC[80] = float[80](-1.440,-1.080,-1.084,-1.732,-2.682,-3.960,-5.439,-6.719,-1.992,-1.506,-0.874,-0.739,-2.440,-4.349,-5.227,-6.087,-2.138,-1.990,-1.264,0.635,-2.351,-5.007,-4.421,-5.657,-1.590,-1.776,-2.152,-0.174,-2.138,-3.941,-3.427,-5.652,-0.619,-0.117,0.615,-0.340,-1.372,-2.486,-3.026,-4.844,0.707,1.005,1.120,0.188,-0.571,-1.348,-1.745,-3.363,2.092,1.763,1.508,0.852,0.284,-0.444,-0.564,-1.404,3.426,2.937,2.141,1.778,0.999,0.516,0.543,0.398,4.522,3.900,3.284,2.463,2.918,2.427,2.146,2.041,5.503,4.848,4.310,4.015,4.181,4.151,3.926,3.692);
float za(vec2 p){ vec2 u = clamp((p - vec2(140.0, 180.0)) / vec2(66.0000, 60.0000), vec2(0.), vec2(4.999, 6.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZAC[(i.y + b) * 8 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * za(p));
        return mix(vec3(0.05, 0.05, 0.06), vec3(0.78, 0.8, 0.8), smoothstep(-0.15, 0.15, c)); }`);
    const ZC = E.fx(`const float ZCC[80] = float[80](-4.460,-7.780,-10.755,-12.746,-13.172,-12.270,-10.492,-8.571,-7.026,-5.833,-1.589,-4.248,-6.855,-9.219,-10.297,-8.872,-6.779,-5.750,-5.735,-5.657,1.046,-0.928,-2.841,-4.846,-7.194,-5.196,-3.276,-3.485,-4.773,-5.139,3.238,1.883,0.581,1.068,-0.582,-1.059,-1.751,-2.794,-3.257,-4.000,4.772,4.135,2.831,1.497,0.749,-0.238,-1.040,-1.797,-1.957,-2.897,5.406,4.088,3.295,2.552,1.518,0.618,-0.142,-1.108,-1.822,-2.223,5.578,4.733,3.871,2.904,2.288,1.296,0.413,-0.287,-0.996,-1.582,5.391,4.222,3.423,3.988,1.169,1.175,1.546,0.946,0.046,-0.898);
float zc(vec2 p){ vec2 u = clamp((p - vec2(220.0, 380.0)) / vec2(90.0000, 69.2000), vec2(0.), vec2(6.999, 4.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZCC[(i.y + b) * 10 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ float c = cos(6.2832 * zc(p));
        return mix(vec3(0.05, 0.05, 0.06), vec3(0.8, 0.82, 0.8), smoothstep(-0.3, 0.0, c)); }`);
    for (const [T, Z] of [[T2, ZC], [T1, ZA]]) {
      soft(x => { x.fillStyle = 'rgba(5,6,20,0.6)'; x.translate(6, 10); x.fill(T); }, 10);
      clipB(T, () => { img(Z); R.dome(T, null, 0.05, 0.16, 26, 1); });
      a.lineWidth = 3; a.strokeStyle = 'rgba(140,215,240,0.7)'; a.stroke(T);
    }
    // hairline seams on the white stripes
    for (const T of [T1, T2]) clipA(T, () => { a.strokeStyle = 'rgba(120,160,200,0.35)'; a.lineWidth = 1; const r = rng(7);
      for (let i = 0; i < 26; i++) { const x = 160 + r() * 680, y = 190 + r() * 530; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 30, y + 22); a.stroke(); } });

    // ── 4. pale glass horn ──
    const HORN = P([[782, 170], [800, 145], [825, 145], [850, 170], [866, 230], [870, 300], [864, 370], [850, 430], [828, 485], [805, 530], [785, 555], [770, 540], [790, 500], [800, 460], [790, 420], [760, 400], [748, 350], [750, 280], [760, 220]], true, true);
    R.dome(HORN, lin(760, 150, 880, 460, [[0, '#b8d0dc'], [0.35, '#8eb2c6'], [0.7, '#5a8098'], [1, '#3a5a70']]), 0.08, 0.3, 40, 4);
    clipA(HORN, () => { a.strokeStyle = 'rgba(90,120,140,0.5)'; a.lineWidth = 1.5; for (let i = 0; i < 12; i++) { const y = 230 + i * 18; a.beginPath(); a.moveTo(768, y); a.quadraticCurveTo(820, y + 10, 875, y - 4); a.stroke(); } });
    rim(HORN, 2.5);
    R.dome(ellipseP(810, 160, 26, 14, 0.2), '#e2eef2', 0.3, 0.06, 8, 4);

    // ── 5. translucent glass body with arms ──
    const BODY = P([[455, 250], [470, 300], [500, 300], [560, 288], [640, 270], [690, 250], [740, 250], [765, 290], [762, 380], [745, 430], [730, 470], [690, 480], [640, 478], [600, 490], [560, 520], [500, 548], [440, 560], [380, 560], [345, 545], [372, 520], [420, 500], [470, 480], [490, 440], [470, 400], [460, 340]], true, true);
    soft(x => { x.fillStyle = 'rgba(60,120,160,0.3)'; x.fill(BODY); }, 3);
    clipA(BODY, () => { a.fillStyle = rad(640, 470, 10, 160, [[0, 'rgba(150,200,225,0.35)'], [1, 'rgba(60,110,150,0.0)']]); a.fill(BODY); });
    rim(BODY, 3);
    for (const pts of [[[470, 330], [430, 345], [400, 335]], [[480, 420], [440, 450], [400, 470]], [[350, 545], [330, 560], [318, 555]], [[700, 250], [710, 215], [722, 200]],
      [[730, 250], [760, 215], [775, 205]], [[745, 268], [780, 262], [800, 268]], [[740, 290], [770, 300], [790, 300]], [[460, 400], [440, 380], [438, 360]]]) {
      soft(x => { x.strokeStyle = 'rgba(170,220,240,0.6)'; x.lineWidth = 14; x.stroke(P(pts, false, true)); }, 1.5);
      a.lineWidth = 2.5; a.strokeStyle = CYAN; a.stroke(P(pts, false, true));
    }
    // inner small zebra tentacle
    const T3 = P([[512, 470], [540, 445], [575, 425], [610, 412], [622, 432], [600, 452], [560, 470], [530, 482]], true, true);
    clipA(T3, () => { a.fillStyle = '#e6eaee'; a.fill(T3); a.strokeStyle = '#0c0c10'; a.lineWidth = 11; for (let i = 0; i < 5; i++) { const x = 525 + i * 22; a.beginPath(); a.moveTo(x, 410); a.lineTo(x + 18, 490); a.stroke(); } });
    rim(T3, 2);

    // ── 6. ghost head with eyes and chrome grin ──
    const HEAD = P([[517, 113], [545, 138], [600, 150], [640, 158], [652, 172], [645, 215], [625, 245], [600, 262], [560, 268], [500, 266], [460, 255], [420, 240], [400, 215], [398, 180], [410, 158], [450, 150], [490, 138]], true, true);
    R.dome(HEAD, lin(420, 120, 640, 270, [[0, '#9ab6e6'], [0.5, '#88a6dc'], [1, '#7a96d0']]), 0.2, 0.08, 16, 4);
    rim(HEAD, 3);
    for (const x of [488, 542]) { R.dome(circleP(x, 186, 19), '#8ccce8', 0.3, 0.05, 5, 4); R.dome(circleP(x, 186, 13), '#06080c', 0.32, 0.02, 3, 3); }
    { const m = new Path2D(); m.moveTo(478, 232); m.quadraticCurveTo(540, 220, 604, 232); m.quadraticCurveTo(600, 290, 540, 290); m.quadraticCurveTo(482, 290, 478, 232); m.closePath();
      R.dome(m, '#c8ccd4', 0.3, 0.16, 22, 3); a.lineWidth = 3; a.strokeStyle = 'rgba(100,190,230,0.9)'; a.stroke(m); }
    for (const [x, y, r] of [[438, 222, 6], [455, 208, 3], [580, 165, 3], [560, 200, 2.5]]) R.bead(x, y, r, '#c4dcf0', 0.3, 0.06, 4);

    // ── 7. red speckled pearls + black pearl + black drop ──
    const PEARLS = [[530, 352, 37], [605, 316, 37], [598, 390, 36], [663, 366, 35]];
    for (const [x, y, r] of [...PEARLS, [697, 283, 46]]) { soft(c => { c.fillStyle = 'rgba(120,220,245,0.7)'; c.fill(circleP(x, y, r + 7)); }, 2); }
    for (const [x, y, r] of PEARLS) {
      R.bead(x, y, r, rad(x - r * 0.3, y - r * 0.35, 2, r * 1.2, [[0, '#ff5a32'], [0.6, '#d8381c'], [1, '#801c10']]), 0.3, 0.3, 3);
      const q = rng(x * 7 + y); clipA(circleP(x, y, r), () => { for (let i = 0; i < 18; i++) { a.fillStyle = q() < 0.8 ? 'rgba(25,8,6,0.85)' : 'rgba(240,210,160,0.9)'; a.fill(ellipseP(x + (q() - 0.5) * r * 1.6, y + (q() - 0.5) * r * 1.6, 2 + q() * 6, 1.5 + q() * 4, q() * 3)); } });
    }
    R.bead(697, 283, 46, rad(680, 266, 2, 55, [[0, '#3a3440'], [0.5, '#121016'], [1, '#050506']]), 0.3, 0.32, 3);
    R.dome(P([[700, 418], [722, 412], [740, 430], [748, 452], [730, 460], [706, 455], [690, 445]], true, true), '#08080a', 0.3, 0.1, 10, 3);
    // bubbles
    for (const [x, y, r] of [[695, 147, 7], [905, 655, 9], [385, 558, 7], [868, 497, 5], [948, 372, 5], [860, 130, 3], [300, 118, 3], [600, 510, 4], [757, 662, 5], [905, 620, 3], [522, 52, 3], [612, 538, 3]])
      { R.bead(x, y, r, '#4a7898', 0.1, 0.08, 4); a.lineWidth = 1.5; a.strokeStyle = 'rgba(150,220,245,0.9)'; a.stroke(circleP(x, y, r)); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.5, ao: 0.4, coat: 0.12 }),                         // 1 zebra
        E.mat({ dif: 1, spec: 0.3, shin: 30, wrap: 0.4 }),                                               // 2 fins / dots
        E.mat({ dif: 0.5, spec: 1.3, shin: 90, metal: 0.55, coat: 0.3, rim: 0.3 }),                      // 3 glossy pearls / chrome
        E.mat({ dif: 1, spec: 0.8, shin: 60, wrap: 0.55, coat: 0.25, rim: 0.6 })                         // 4 frosted glass
      ],
      light: [-0.35, 0.6, 0.72], lc: [0.72, 0.74, 0.8], amb: [0.36, 0.37, 0.42],
      envTop: [1.3, 1.35, 1.45], envHor: [0.45, 0.5, 0.75], envBot: [0.06, 0.06, 0.1], envK: [0.4, 1.6, 0.3, 0],
      rimC: [0.3, 0.7, 0.9], rimD: [0, 1, 0], r1: 2.2, r2: 9, k: [0, 0.6, 0.4, 70], shadow: [-5, 7, 0.45, 6]
    });
    E.bloom(0.12, 10);
    E.grain(0.06, 200);
  }
});
