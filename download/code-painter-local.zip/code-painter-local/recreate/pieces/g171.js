'use strict';
// g171 — "Porthole of rainbow chrome": a taupe sci-fi porthole ringed in red frames a white world of zebra swirls and
// black blots; an iridescent chrome tube loops over magenta and blue, a chrome dumbbell and a rainbow gear-disc below.
REC.register('g171', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a, x0 = x, y0 = y) => { const g = ctx.createRadialGradient(x0, y0, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const flat = arr => { const p = []; for (let i = 0; i < arr.length; i += 2) p.push([arr[i], arr[i + 1]]); return p; };
    const polys = list => { const p = new Path2D(); for (const f of list) p.addPath(poly(flat(f))); return p; };
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    const arcPts = (cx, cy, r, a0, a1, n = 40) => { const p = []; for (let i = 0; i <= n; i++) { const t = a0 + (a1 - a0) * i / n; p.push([cx + Math.cos(t) * r, cy + Math.sin(t) * r]); } return p; };
    const D = Math.PI / 180;

    // ── traced zebra / blot fields (measured from the reference) ──
    const HB = [[610,524,579,502,546,468,529,443,517,415,510,421,501,422,498,432,487,433,478,439,469,439,461,449,443,443,422,443,397,456,370,464,353,479,328,510,316,517,289,517,250,501,239,505,232,496,219,496,222,486,204,494,143,502,141,517,145,517,155,511,171,507,200,509,219,518,237,532,242,532,279,552,306,562,330,565,332,568,323,586,323,606,334,627,352,639,370,642,390,630,404,626,413,611,416,595,419,594,444,609,459,624,469,641,491,660,491,651,470,633,457,608,454,588,459,562,473,539,501,520,527,515,554,521,556,519,527,486,508,475,491,473,478,478,470,486,446,531,430,549,411,558,390,556,376,544,367,528,366,520,371,513,386,509,400,499,417,463,424,456,435,452,468,456,492,442,508,438,534,479,566,513,605,542,609,543],[525,352,528,387,543,426,574,468,605,493,601,471,577,448,557,421,540,382,537,359],[363,308,328,311,326,317,277,334,270,333,315,314,294,319,256,334,254,343,278,345,296,354,343,329,362,312],[498,337,493,361,494,382,499,411,514,410,508,375,510,342],[504,657,514,690,519,679,525,674,536,673,546,680,555,667,555,662,539,663],[503,684,498,727,525,705,512,700],[193,682,195,688,213,684,223,698,222,675],[257,585,259,597,256,600,256,608,265,609,264,589,262,585],[563,396,575,418,589,433],[594,558,601,581,605,564]];
    const HN = [[369,313,368,328,358,348,358,355,351,364,351,372,358,379,358,401,370,409,381,426,419,426,430,444,444,443,456,446,467,438,479,438,489,432,498,431,501,421,511,420,515,416,513,411,501,413,485,431,463,428,441,431,430,411,394,407,384,386,373,383,365,375,365,367,369,362,372,348,368,335,377,311,372,310],[297,445,283,453,267,457,261,467,244,480,236,480,230,476,231,482,224,485,219,495,231,495,238,504,246,502,260,488,281,479,284,473,283,463,294,453],[348,396,344,395,330,409,321,412,319,417,347,412],[279,743,301,754,291,743]];
    const Z1 = [[536,138,520,130,488,123,415,124,378,132,347,149,301,190,277,224,249,248,232,255,233,260,256,250,277,232,340,218,382,217,409,223,434,235,458,256,472,277,482,280,477,262,460,235,442,219,417,206,393,200,361,199,295,212,318,187,364,178,397,178,424,184,441,192,469,216,486,246,492,271,492,285,502,289,503,263,499,240,492,223,493,217,460,182,437,169,413,162,381,160,345,166,343,164,367,147,408,146,446,155,488,182,493,167,475,153,443,139,413,134,484,131,509,134,525,141],[252,258,256,260,269,255,296,251,362,250,407,256,454,271,444,260,416,244,390,236,357,232,304,238,265,250],[239,274,240,281,244,282,267,274,319,265,369,265,434,278,520,314,512,306,479,288,380,260,299,259,271,263],[525,240,516,241,517,273,513,297,520,302,523,301,531,256,531,241],[556,242,546,244,541,283,534,312,542,316,550,287],[475,134,503,154,512,148,496,135],[561,292,556,303,552,326,556,325,561,307],[574,232,569,233,568,254,574,242]];


    const Z3 = [[641,465,652,518,649,590,642,650,658,641,662,631,725,663,725,639,663,609,664,594,671,593,725,613,725,592,669,574,666,571,666,559,671,558,725,573,725,564,692,556,667,546,667,531,678,531,697,543,724,554,725,548,685,528,675,518,668,505,661,516,658,488,662,480,662,466],[725,744,725,722,720,719,718,697,712,692,720,685,703,677,696,688,708,695,702,706,692,702,690,697,679,703,662,706,647,697,637,686,635,700,650,720,656,721,660,718,675,722,701,738]];

    // ── background: magenta / violet / blue sky, red disc with a blue core, white floor ──
    R.flat(all, '#f4efed', 0, 0);
    a.fillStyle = lin(0, 0, 520, 0, [[0, '#fc0560'], [0.12, '#e8207a'], [0.24, '#b010b8'], [0.38, '#5a0ae0'], [0.48, '#320aee'], [0.6, '#560be0'], [0.7, '#9a0bc4'], [0.8, '#e2078e'], [0.9, '#fc0462'], [1, '#fc035e']]);
    a.fill(poly([[-10, -10], [560, -10], [560, 140], [240, 260], [-10, 250]]));
    // red disc (top right) with cream rim and a blue core
    const rimPts = [[548, -10], [566, 40], [592, 92], [626, 146], [664, 196], [700, 232], [736, 256]];
    a.fillStyle = '#f40c0c'; a.fill(poly([...rimPts, [736, -10]]));
    a.fillStyle = '#fc0461'; a.fill(poly([[600, 230], [736, 260], [736, 470], [620, 460]]));
    soft(x => { x.fillStyle = '#7a1488'; x.fill(poly([[596, 200], [650, 240], [660, 330], [640, 450], [600, 450]])); }, 18, 0.9);
    soft(x => { x.strokeStyle = '#5a2030'; x.lineWidth = 26; x.stroke(line([[640, 236], [690, 262], [736, 292]])); }, 8, 0.8);
    a.fillStyle = '#0a6cf4'; a.fill(circleP(742, 40, 106));
    soft(x => { x.strokeStyle = '#f0a020'; x.lineWidth = 16; x.stroke(line(rimPts)); }, 2, 1);
    a.strokeStyle = '#d8d0c8'; a.lineWidth = 9; a.stroke(line(rimPts.map(([x, y]) => [x - 4, y + 4])));
    // floor shading
    soft(x => {
      x.fillStyle = '#f6d4d2'; x.fill(poly([[-10, 470], [80, 470], [70, 700], [-10, 700]])); x.fillStyle = '#8a8080'; x.fill(poly([[-10, 380], [70, 400], [80, 440], [-10, 450]]));
      x.fillStyle = 'rgba(60,54,52,0.85)'; x.fill(poly([[-10, 300], [60, 300], [110, 340], [70, 370], [-10, 372]]));
    }, 24);

    // ── zebra fields outside the porthole ──
    R.flat(sm([[250, 150], [300, 135], [350, 110], [420, 92], [500, 95], [560, 120], [580, 170], [590, 260], [600, 320], [560, 300], [470, 266], [380, 258], [300, 268], [240, 290], [230, 250]]), '#f3f1ee', 0.02, 4);
    a.fillStyle = '#0b0a0b'; a.fill(polys(Z1));
    R.flat(poly([[636, 480], [736, 480], [736, 748], [690, 738], [645, 720], [630, 690], [645, 600], [650, 520]]), '#f3f1ee', 0.02, 4);
    a.fillStyle = '#0b0a0b'; a.fill(polys(Z3));

    // ── swirl discs ──
    const swirl = (cx, cy, r, turns, rot, hgt = 0.06) => {
      R.dome(circleP(cx, cy, r), '#f6f4f4', hgt, 0.08, r * 0.5, 4);
      const pts = []; const n = turns * 48;
      for (let i = 0; i <= n; i++) { const t = i / n, ang = rot + t * turns * 6.2832, rr = r * 0.94 * t; pts.push([cx + Math.cos(ang) * rr, cy + Math.sin(ang) * rr]); }
      a.save(); a.clip(circleP(cx, cy, r)); a.strokeStyle = '#0c0c14'; a.lineWidth = r * 0.94 / turns * 0.52; a.stroke(line(pts)); a.restore();
      a.strokeStyle = '#141c40'; a.lineWidth = 2.5; a.stroke(circleP(cx, cy, r - 1));
    };
    swirl(540, 190, 47, 6, 0.5);

    // ── camera lens (top left): light shell, ribbed rim, dark ribbed bore; knob on a light bracket ──
    R.dome(sm([[-10, 50], [10, 60], [40, 78], [66, 96], [90, 115], [104, 140], [108, 175], [100, 200], [80, 220], [62, 330], [-10, 344]]), lin(0, 60, 110, 220, [[0, '#d8d2ce'], [0.5, '#c4bcb8'], [1, '#9a9290']]), 0.1, 0.3, 12, 1);
    R.flat(poly([[-10, 42], [12, 54], [68, 92], [60, 110], [6, 84], [-10, 76]]), '#1e1a1a', 0.14, 1);
    for (let i = 0; i < 12; i++) { const t = i / 11; a.strokeStyle = '#8a8282'; a.lineWidth = 1.6; a.stroke(line([[-8 + t * 70, 48 + t * 38], [-14 + t * 70, 62 + t * 40]])); }
    const bore = sm([[-10, 220], [20, 192], [45, 150], [70, 128], [90, 152], [95, 200], [82, 258], [60, 306], [30, 334], [-10, 342]]);
    R.flat(bore, '#161212', 0.05, 0);
    clipA(bore, () => { for (let i = 0; i < 30; i++) { const t = (200 + i * 6) * D; a.strokeStyle = 'rgba(105,98,96,0.7)'; a.lineWidth = 2; a.stroke(line([[60 + Math.cos(t) * 40, 175 + Math.sin(t) * 30], [60 + Math.cos(t) * 160, 175 + Math.sin(t) * 140]])); }
      a.fillStyle = '#060404'; a.fill(ellipseP(66, 165, 26, 34, 0.3)); });
    // bracket: plate right of the knob, lug below-left, shadow under it
    R.dome(sm([[78, 196], [110, 172], [140, 162], [165, 178], [205, 212], [248, 240], [258, 262], [215, 276], [170, 282], [138, 290], [110, 296], [80, 270]]), lin(0, 165, 0, 300, [[0, '#c4beba'], [0.45, '#8a807c'], [1, '#56484a']]), 0.1, 0.16, 10, 1);
    R.dome(sm([[28, 296], [70, 280], [118, 288], [128, 312], [96, 332], [50, 336], [26, 322]]), '#bcb6b2', 0.12, 0.12, 8, 1);
    R.flat(sm([[-10, 340], [40, 338], [100, 334], [130, 318], [140, 340], [90, 365], [-10, 368]]), '#2a2424', 0.03, 0);
    soft(x => { x.fillStyle = 'rgba(90,70,68,0.7)'; x.fill(sm([[120, 290], [200, 272], [262, 262], [240, 300], [180, 320], [130, 330]])); }, 10);
    R.dome(ellipseP(100, 256, 50, 38, 0), '#2a2424', 0.2, 0.1, 6, 1);
    clipA(ellipseP(100, 254, 48, 36, 0), () => { for (let i = 0; i < 24; i++) { a.fillStyle = '#8a8280'; a.fillRect(54 + i * 4, 246, 1.8, 46); } });
    R.dome(ellipseP(94, 224, 40, 34, 0), '#a8a09c', 0.3, 0.06, 6, 1);
    R.dome(ellipseP(93, 222, 27, 24, 0), '#201c1c', 0.32, 0.04, 4, 1);
    R.dome(circleP(91, 218, 18), rad(91, 218, 20, [[0, '#ffffff'], [0.35, '#e0e0e8'], [0.7, '#707078'], [1, '#2a2a30']], a, 86, 210), 0.38, 0.18, 9, 5);

    // ── iridescent chrome tube (a thick horn from the spring, looping right and down) ──
    const TP = sm([[138, 150], [165, 140], [200, 130], [232, 118], [275, 98], [322, 74], [376, 57], [423, 50], [470, 48], [510, 54], [551, 67], [585, 91], [605, 118], [622, 162], [632, 205], [638, 250], [642, 300], [648, 350], [655, 400], [672, 438], [700, 452], [736, 458],
      [736, 535], [690, 518], [650, 492], [620, 452], [600, 400], [590, 350], [580, 300], [575, 250], [572, 200], [566, 160], [551, 118], [497, 96], [443, 93], [389, 103], [342, 123], [308, 150], [288, 184], [275, 216], [261, 238], [234, 251], [201, 251], [174, 238], [154, 204], [140, 170]]);
    const TC = [[150, 175], [200, 192], [250, 175], [295, 130], [345, 98], [400, 76], [460, 70], [515, 78], [560, 105], [592, 150], [604, 200], [607, 260], [612, 320], [622, 385], [648, 438], [690, 475], [745, 498]];
    const LN = [
      ['#8070e0', '#a8a8c8', '#a0a8c8', '#8060e8', '#6a50f0', '#9060e8', '#c060d8', '#c06090', '#b08090', '#b0b070', '#605860', '#605860', '#605a64', '#706870', '#e8f0a0', '#f0f0c0', '#f0f0d0'],
      ['#a8a0e0', '#c8c0d8', '#c0c0d8', '#b8c0d8', '#c8c8e0', '#d0d0e0', '#d0d0d8', '#b8b0a0', '#c0a080', '#c8d860', '#7020e0', '#7020e0', '#7828d8', '#8040c0', '#f0f0c0', '#f0f0d0', '#e8f0d8'],
      ['#9a80d8', '#b098d8', '#a8b0d8', '#a0d0b0', '#b0e080', '#d0e070', '#e0e090', '#c0c070', '#a0c070', '#90e070', '#2050f0', '#2050f0', '#4a50c8', '#6060c0', '#c0e0a0', '#b0e0a8', '#c0e0b0'],
      ['#8a70d0', '#c070c8', '#70a8d0', '#60b0c8', '#70c8c0', '#60c8c8', '#80c8c8', '#90b890', '#70c090', '#50d8a0', '#20d0d0', '#20c8d8', '#30c0d0', '#40b8d0', '#60d0d0', '#50c8d8', '#60c0d8'],
      ['#7a68c0', '#d060b8', '#e8e0b0', '#8090a0', '#80848c', '#8a8a80', '#909080', '#9a9a80', '#a0c080', '#b8f070', '#30e0a0', '#30e0a0', '#40e0a0', '#60d8a8', '#707a80', '#787a78', '#808078']];
    const TW = [110, 120, 100, 66, 52, 46, 46, 50, 56, 62, 66, 66, 66, 64, 70, 76, 76];
    R.dome(TP, '#8a8894', 0.28, 0.42, 34, 2);
    const tubePaint = x => {
      x.save(); x.clip(TP);
      for (const [lane, off, wd] of [[LN[0], -0.42, 0.26], [LN[4], 0.42, 0.26], [LN[1], -0.21, 0.24], [LN[3], 0.21, 0.24], [LN[2], 0, 0.24]]) {
        for (let i = 0; i < TC.length - 1; i++) {
          const p = TC[i], q = TC[i + 1], dx = q[0] - p[0], dy = q[1] - p[1], L = Math.hypot(dx, dy), nx = -dy / L, ny = dx / L;
          const w0 = TW[i], w1 = TW[i + 1], o0 = [p[0] + nx * off * w0, p[1] + ny * off * w0], o1 = [q[0] + nx * off * w1, q[1] + ny * off * w1];
          x.strokeStyle = lin(o0[0], o0[1], o1[0], o1[1], [[0, lane[i]], [1, lane[i + 1]]], x); x.lineWidth = (w0 + w1) / 2 * wd;
          x.beginPath(); x.moveTo(o0[0], o0[1]); x.lineTo(o1[0], o1[1]); x.stroke();
        }
      }
      // bulb: blue-violet left, pink belly, white-yellow hot spot
      x.fillStyle = '#6a58e8'; x.fill(ellipseP(160, 200, 26, 40, 0));
      x.fillStyle = '#e060c8'; x.fill(ellipseP(205, 222, 30, 16, 0.2));
      x.fillStyle = '#fff8d8'; x.fill(ellipseP(238, 228, 22, 14, -0.4));
      x.fillStyle = '#c8c4d4'; x.fill(ellipseP(215, 160, 40, 18, -0.4));
      x.restore();
    };
    soft(x => tubePaint(x), 3, 1);
    clipA(TP, () => soft(x => { x.strokeStyle = '#ffffff'; x.lineWidth = 10; x.stroke(line([[300, 100], [360, 76], [430, 64], [490, 64]])); }, 6, 0.5));
    // spring + rod
    R.pipe(line([[86, -10], [100, 50], [118, 110], [134, 160]]), 16, lin(80, 0, 130, 0, [[0, '#606070'], [0.5, '#e8e8f0'], [1, '#707080']]), 0.35, 0.2, 5);
    for (let i = 0; i < 7; i++) { const y = 102 + i * 8.5, x = 120 + i * 2.6; R.pipe(ellipseP(x, y, 15, 4, 0.3), 5, '#c0c0c8', 0.45, 0.1, 5); }

    // ── the porthole ring ──
    const cx = 344, cy = 565, rO = 300, hx = 375, hy = 535, rH = 238;
    const outer = [...arcPts(cx, cy, rO, 155 * D, 420 * D, 60), [470, 900], [455, 950], [420, 968], [360, 960], [290, 934], [205, 876], [140, 822], [100, 766], [72, 712]];
    const ringP = sm(outer);
    // red frame behind
    R.pipe(line([...arcPts(cx, cy, rO + 4, 150 * D, 425 * D, 60)]), 10, '#f01818', 0.12, 0.12, 3);
    R.pipe(line([[66, 706], [96, 768], [126, 800], [152, 820], [185, 842], [215, 860]]), 9, '#f01818', 0.12, 0.12, 3);
    R.pipe(line([[372, 955], [395, 962], [412, 975], [420, 992]]), 9, '#f01818', 0.12, 0.12, 3);
    R.dome(ringP, '#84685f', 0.08, 0.26, 22, 1);
    // inner lip
    R.dome(circleP(hx, hy, rH + 12), '#5e4a44', 0.2, 0.06, 8, 1);
    R.flat(circleP(hx, hy, rH), '#f6f4f2', 0.03, 4);
    // recessed panels and slots along the arc
    const arcPanel = (t0, t1, r, w) => sm([...arcPts(hx, hy, r + w / 2, t0 * D, t1 * D, 12), ...arcPts(hx, hy, r - w / 2, t1 * D, t0 * D, 12)]);
    const box = (t, r, w, h) => { const p = new Path2D(); p.addPath(rrect(-w / 2, -h / 2, w, h, 2), new DOMMatrix().translateSelf(hx + Math.cos(t * D) * r, hy + Math.sin(t * D) * r).rotateSelf(t + 90)); return p; };
    R.groove(arcPanel(160, 192, 268, 30), 4, '#3a2c28', 0.32, 0.12, 1);
    for (const t of [168, 176, 184]) R.groove(box(t, 268, 26, 2), 3, '#3a2c28', 0.32, 0.1, 1);
    for (let k = 0; k < 5; k++) R.groove(box(200 + k * 6, 262, 18, 22), 4, '#3a2c28', 0.32, 0.12, 1);
    for (let k = 0; k < 4; k++) R.groove(box(228 + k * 5.5, 260, 16, 20), 3.5, '#3a2c28', 0.32, 0.1, 1);
    R.groove(arcPanel(250, 284, 260, 20), 4, '#3a2c28', 0.32, 0.12, 1);
    for (const t of [276, 279, 282]) R.groove(box(t, 260, 3, 14), 2.5, '#3a2c28', 0.32, 0.1, 1);
    for (let k = 0; k < 4; k++) R.groove(box(22 + k * 8, 262, 18, 22), 3.5, '#3a2c28', 0.32, 0.1, 1);
    R.bead(463, 300, 5, '#3050a0', 0.35, 0.05, 5);
    // lower band: six recessed panels with chrome studs
    const studs = [[175, 776], [171, 797], [207, 799], [198, 819], [236, 819], [230, 838], [271, 834], [261, 858], [305, 852], [297, 873], [342, 867], [333, 888]];
    for (let k = 0; k < 6; k++) {
      const x = (studs[k * 2][0] + studs[k * 2 + 1][0]) / 2, y = (studs[k * 2][1] + studs[k * 2 + 1][1]) / 2;
      const p = new Path2D(); p.addPath(rrect(-16, -26, 32, 52, 3), new DOMMatrix().translateSelf(x, y).rotateSelf(25));
      R.flat(p, '#3a2c28', 0.16, 1);
    }
    R.groove(line([[150, 745], [230, 790], [330, 830], [420, 860]]), 4, '#3a2c28', 0.32, 0.1, 1);
    R.groove(line([[180, 840], [260, 885], [340, 915], [400, 930]]), 4, '#3a2c28', 0.32, 0.1, 1);
    for (const [x, y] of studs) R.bead(x, y, 9, rad(x - 2, y - 2, 11, [[0, '#ffffff'], [0.6, '#e8e8f0'], [1, '#808088']]), 0.3, 0.15, 7);
    // dark holes in the band
    R.flat(circleP(412, 795, 18), '#0c0a0a', 0.02, 0);
    R.flat(sm([[345, 880], [380, 860], [410, 880], [400, 930], [360, 935], [340, 910]]), '#0c0a0a', 0.02, 0);

    // ── inside the porthole ──
    const hole = circleP(hx, hy, rH);
    clipA(hole, () => {
      a.fillStyle = '#0b0a0b'; a.fill(polys(HB));
      a.fillStyle = '#0a1a50'; a.fill(polys(HN));
      a.fillStyle = rad(hx, hy, rH, [[0, 'rgba(0,0,0,0)'], [0.85, 'rgba(0,0,0,0)'], [1, 'rgba(60,50,50,0.25)']]); a.fill(hole);
    });
    swirl(437, 345, 58, 7, 1.0, 0.04);
    swirl(260, 400, 56, 7, 2.1, 0.06);
    swirl(190, 447, 48, 6, 0.3, 0.08);
    swirl(282, 685, 58, 7, 4.0, 0.06);
    // two lenses
    const lens = (ex, ey, rx, ry, brown) => {
      const e = ellipseP(ex, ey, rx, ry, 0);
      R.dome(e, '#f6f4f2', 0.05, 0.05, 10, 4);
      clipA(e, () => { a.fillStyle = '#9a8478'; a.fill(poly(brown)); });
      a.strokeStyle = '#18205a'; a.lineWidth = 3; a.stroke(e);
      a.strokeStyle = 'rgba(160,160,170,0.7)'; a.lineWidth = 2; a.stroke(ellipseP(ex, ey, rx + 4, ry + 4, 0));
    };
    lens(528, 592, 67, 70, [[490, 518], [560, 518], [600, 560], [600, 610], [582, 650], [578, 655]]);
    lens(424, 705, 74, 67, [[340, 630], [445, 630], [441, 644], [357, 742], [340, 760]]);

    // ── chrome dumbbell (lower left) ──
    const chromeAlb = (x0, y0, x1, y1) => lin(x0, y0, x1, y1, [[0, '#b0b0c8'], [0.3, '#e0e0ec'], [0.55, '#a8a8b0'], [0.8, '#707078'], [1, '#48484e']]);
    const bulbU = sm([[150, 705], [128, 676], [119, 635], [122, 585], [138, 545], [166, 520], [205, 512], [243, 526], [266, 560], [273, 604], [263, 646], [236, 672], [200, 690], [172, 708]]);
    const bulbL = sm([[-10, 702], [25, 698], [62, 705], [96, 718], [118, 740], [122, 775], [114, 812], [118, 852], [110, 892], [85, 918], [45, 928], [-10, 925]]);
    R.dome(bulbL, chromeAlb(0, 700, 150, 920), 0.25, 0.4, 50, 7);
    R.dome(sm([[108, 732], [132, 702], [156, 686], [172, 700], [152, 724], [128, 746]]), '#a8a8b4', 0.3, 0.3, 14, 7);
    R.dome(bulbU, chromeAlb(130, 520, 270, 700), 0.28, 0.42, 45, 7);
    for (let i = 0; i < 4; i++) R.pipe(ellipseP(153 - i * 7, 689 + i * 10, 25, 8, 0.6), 7, '#d8d8e4', 0.55, 0.1, 7);
    soft(x => {
      x.save(); x.clip(bulbU);
      x.fillStyle = '#5058f0'; x.fill(ellipseP(150, 545, 26, 26, 0.4));
      x.fillStyle = '#c050e8'; x.fill(ellipseP(178, 528, 24, 12, 0));
      x.fillStyle = '#40d8e0'; x.fill(ellipseP(205, 530, 16, 8, 0));
      x.fillStyle = '#fff4a0'; x.fill(ellipseP(160, 592, 22, 30, 0.2));
      x.fillStyle = '#ffffff'; x.fill(ellipseP(212, 550, 24, 18, 0));
      x.fillStyle = '#606068'; x.fill(ellipseP(255, 600, 22, 50, 0.1));
      x.fillStyle = '#e070d0'; x.fill(ellipseP(135, 620, 10, 22, 0));
      x.restore(); x.save(); x.clip(bulbL);
      x.fillStyle = '#fff8b0'; x.fill(ellipseP(40, 800, 46, 60, 0.2));
      x.fillStyle = '#ffffff'; x.fill(ellipseP(52, 772, 22, 24, 0));
      x.fillStyle = '#4048f0'; x.fill(ellipseP(10, 722, 26, 16, 0));
      x.fillStyle = '#b060e0'; x.fill(ellipseP(60, 712, 20, 8, 0));
      x.fillStyle = '#8a58d0'; x.fill(ellipseP(112, 800, 10, 34, 0));
      x.fillStyle = '#58585e'; x.fill(ellipseP(75, 905, 55, 26, 0));
      x.fillStyle = '#6a6a72'; x.fill(ellipseP(100, 860, 18, 40, 0));
      x.restore();
    }, 9, 0.9);
    // small swirl reflected in the bulb tip
    clipA(bulbU, () => { const pts = []; for (let i = 0; i <= 200; i++) { const t = i / 200, ang = t * 25, rr = 24 * t; pts.push([250 + Math.cos(ang) * rr, 632 + Math.sin(ang) * rr]); } a.fillStyle = '#e8e8f0'; a.fill(ellipseP(250, 632, 20, 26, 0.3)); a.strokeStyle = '#141420'; a.lineWidth = 2; a.stroke(line(pts)); });

    // ── chrome balls ──
    const ball = (x, y, r) => R.bead(x, y, r, rad(x + r * 0.1, y + r * 0.1, r * 1.1, [[0, '#ffffff'], [0.3, '#e0e0e8'], [0.65, '#9a9aa4'], [1, '#4a4a52']], a, x - r * 0.35, y - r * 0.35), 0.3, 0.35, 5);
    ball(36, 390, 31);
    ball(668, 672, 31);
    R.dome(rrect(690, 685, 40, 40, 12), '#3a3232', 0.2, 0.1, 8, 1);

    // ── rainbow gear disc (lower right) ──
    const gx = 598, gy = 915;
    R.flat(circleP(gx, gy, 192), '#1c1616', 0.05, 0);
    for (let k = 0; k < 40; k++) {
      const t = k / 40 * 6.2832 + 0.03; const p = new Path2D();
      p.addPath(rrect(-11, -19, 22, 38, 2), new DOMMatrix().translateSelf(gx + Math.cos(t) * 172, gy + Math.sin(t) * 172).rotateSelf(t / D + 90));
      R.dome(p, '#8a7066', 0.15, 0.12, 5, 1);
    }
    R.pipe(circleP(gx, gy, 189), 6, '#f02020', 0.2, 0.08, 3);
    R.dome(circleP(gx, gy, 160), '#7a6058', 0.12, 0.12, 8, 1);
    const cg = a.createConicGradient(-Math.PI, gx, gy);
    [[0, '#3a2c2c'], [0.1, '#3a2c30'], [0.14, '#5030c0'], [0.167, '#6a32e4'], [0.208, '#0d54f2'], [0.25, '#11c0c3'], [0.29, '#08e65d'], [0.33, '#3dee08'], [0.375, '#e8c90e'], [0.417, '#f92639'], [0.458, '#701be7'], [0.5, '#0a45f6'], [0.54, '#10b9c6'], [0.58, '#08de73'], [0.65, '#06e458'], [0.75, '#20a080'], [0.8, '#3a2c2c'], [1, '#3a2c2c']].forEach(([t, c]) => cg.addColorStop(t, c));
    R.flat(circleP(gx, gy, 155), cg, 0.2, 6);
        R.dome(circleP(gx - 12, gy, 96), '#2a2222', 0.18, 0.06, 6, 1);
    R.dome(circleP(gx - 12, gy, 90), '#6a5450', 0.22, 0.06, 6, 1);
    R.flat(circleP(gx - 12, gy, 81), '#1a1414', 0.2, 0);
    R.flat(circleP(gx - 12, gy, 77), lin(525, 880, 640, 950, [[0, '#f98916'], [0.2, '#f95020'], [0.42, '#f91c3d'], [0.55, '#f0109a'], [0.66, '#7019e4'], [0.8, '#2a2af6'], [1, '#1048f4']]), 0.22, 6);
    a.strokeStyle = '#a0e040'; a.lineWidth = 2.5; a.stroke(circleP(gx - 12, gy, 76));

    // ── bottom-left keys in the shadow ──
    soft(x => { x.fillStyle = 'rgba(70,64,62,0.85)'; x.fill(poly([[-10, 920], [110, 915], [170, 960], [230, 1034], [-10, 1034]])); x.fillStyle = 'rgba(90,84,80,0.5)'; x.fill(poly([[230, 940], [330, 960], [400, 1034], [260, 1034]])); }, 20);
    for (const [x, y, w, h] of [[-10, 945, 60, 90], [62, 962, 100, 80], [172, 992, 90, 50]]) { R.dome(rrect(x, y, w, h, 4), '#7a7674', 0.05, 0.06, 5, 1); a.strokeStyle = '#2a2626'; a.lineWidth = 2; a.stroke(rrect(x, y, w, h, 4)); }
    for (const [x, y, r] of [[25, 970, 7], [100, 990, 8], [150, 1012, 6]]) R.flat(circleP(x, y, r), '#2a2626', 0.06, 0);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 20, wrap: 0.4, ao: 0.6, grain: 0.18 }),                               // 1 taupe ring
        E.mat({ dif: 0.35, spec: 0.7, shin: 40, wrap: 1.0, ao: 0.3, coat: 0.04, emis: 0.66 }),                    // 2 iridescent chrome
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.4, ao: 0.2, emis: 0.15 }),                                 // 3 red frame
        E.mat({ dif: 0.6, spec: 0.2, shin: 20, wrap: 0.6, emis: 0.42 }),                                        // 4 white / zebra
        E.mat({ dif: 0.7, spec: 1.3, shin: 80, metal: 0.35, wrap: 0.3, ao: 0.3, coat: 0.2 }),                   // 5 chrome
        E.mat({ dif: 0.4, spec: 0.5, shin: 30, wrap: 0.6, emis: 0.62 }),                                        // 6 rainbow disc
        E.mat({ dif: 0.75, spec: 1.2, shin: 60, wrap: 0.4, ao: 0.3, coat: 0.12 })                               // 7 chrome bulbs
      ],
      light: [-0.45, 0.6, 0.66], lc: [1, 0.98, 0.96], amb: [0.42, 0.4, 0.42],
      envTop: [1.1, 1.05, 1.05], envHor: [0.6, 0.55, 0.6], envBot: [0.2, 0.18, 0.2], envK: [0.3, 1.0, 0.3, 0],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 60], shadow: [6, 8, 0.55, 10]
    });
    E.grain(0.05, 171);
  }
});
