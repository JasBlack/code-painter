'use strict';
// g165 — "Corn-snake playroom": a tiled white room with a coral boiler machine, a white blob creature and a zebra
// banner, where knitted green corn snakes slither over a zebra floor past a white tub, a lettered black belt and chrome balls.
REC.register('g165', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, st, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    const speck = (path, n, seed, col, rmax, box, al = 0.4) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.3 + r() * r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const homo = (q) => {
      const [[x0, y0], [x1, y1], [x2, y2], [x3, y3]] = q;
      const dx1 = x1 - x2, dx2 = x3 - x2, dy1 = y1 - y2, dy2 = y3 - y2, sx = x0 - x1 + x2 - x3, sy = y0 - y1 + y2 - y3;
      const den = dx1 * dy2 - dx2 * dy1, g = (sx * dy2 - dx2 * sy) / den, h = (dx1 * sy - sx * dy1) / den;
      const A = x1 - x0 + g * x1, B = x3 - x0 + h * x3, D = y1 - y0 + g * y1, Ee = y3 - y0 + h * y3;
      return (u, v) => { const w = g * u + h * v + 1; return [(A * u + B * v + x0) / w, (D * u + Ee * v + y0) / w]; };
    };
    const tileQuad = (M, u0, v0, u1, v1, k = 0.2) => {
      const du = (u1 - u0) * k, dv = (v1 - v0) * k;
      return [[u0 + du, v0], [u1 - du, v0], [u1, v0 + dv], [u1, v1 - dv], [u1 - du, v1], [u0 + du, v1], [u0, v1 - dv], [u0, v0 + dv]].map(([u, v]) => M(u, v));
    };
    const TILE = '#b4c4c2', GROUT = '#4c5a5a';
    // knitted corn snake along a polyline
    const snake = (pts, wd, seed) => {
      const pth = line(pts);
      R.pipe(pth, wd, '#c4cc94', 0.08, 0.3, 3);
      const r = rng(seed);
      // bumps: sample the path
      const seg = []; let L = 0;
      for (let i = 1; i < pts.length; i++) { const d = Math.hypot(pts[i][0] - pts[i - 1][0], pts[i][1] - pts[i - 1][1]); seg.push([L, d]); L += d; }
      for (let s = 0; s < L; s += 9) {
        let i = 0; while (i < seg.length - 1 && seg[i][0] + seg[i][1] < s) i++;
        const u = (s - seg[i][0]) / seg[i][1], p0 = pts[i], p1 = pts[i + 1], dx = (p1[0] - p0[0]) / seg[i][1], dy = (p1[1] - p0[1]) / seg[i][1];
        const cx = p0[0] + (p1[0] - p0[0]) * u, cy = p0[1] + (p1[1] - p0[1]) * u;
        for (let k = -3; k <= 3; k++) {
          const off = k / 3.4 * wd * 0.5, sc = Math.cos(k / 3.4 * 1.3);
          R.dome(ellipseP(cx - dy * off + dx * (k % 2) * 4, cy + dx * off + dy * (k % 2) * 4, 5.2, 5.2 * (0.55 + 0.45 * sc), Math.atan2(dy, dx) + 1.57), r() < 0.5 ? '#ccd4a0' : '#bcc68c', 0.22 + 0.16 * sc, 0.05, 4, 3);
        }
      }
    };

    // ── ceiling with a skylight strip and spot lights ──
    R.flat(all, lin(0, 0, 726, 0, [[0, '#7a7670'], [0.35, '#9c988e'], [0.7, '#828078'], [1, '#74726c']]), 0, 0);
    R.flat(poly([[-10, 60], [120, 70], [250, 150], [-10, 100]]), '#a8a49c', 0.01, 0);
    R.flat(poly([[112, 76], [330, -10], [400, -10], [170, 92]]), lin(112, 80, 400, 0, [[0, '#f4f0e0'], [1, '#fffff4']]), 0.02, 0);
    soft(x => { x.fillStyle = '#fffbe8'; x.fill(poly([[100, 80], [330, -10], [420, -10], [180, 100]])); }, 14, 0.3);
    R.pipe(line([[170, 108], [500, -6]]), 4, '#d8d4c8', 0.03, 0.02, 1);
    for (const [x, y, r] of [[84, 42, 12], [425, 8, 14], [520, 30, 14], [618, 25, 11], [272, 108, 14]]) { R.dome(ellipseP(x, y, r, r * 0.55, 0), '#e8e6e0', 0.02, 0.04, 4, 1); R.flat(ellipseP(x, y, r * 0.6, r * 0.32, 0), '#4a4844', 0.03, 1); }
    R.bead(293, 124, 11, '#f0f0ee', 0.1, 0.1, 1);
    // back wall top band
    R.flat(poly([[255, 152], [640, 92], [736, 80], [736, 120], [640, 128], [255, 172]]), '#c8c8c0', 0.03, 1);

    // ── left wall tiles ──
    const LW = homo([[-30, 92], [262, 152], [262, 560], [-30, 590]]);
    const lwall = poly([[-10, 96], [262, 152], [262, 560], [-10, 590]]);
    R.flat(lwall, GROUT, 0.02, 1);
    a.save(); a.clip(lwall); R.h.save(); R.h.clip(lwall);
    for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) {
      const u0 = i * 0.27, v0 = j * 0.26 + 0.02;
      R.dome(P(tileQuad(LW, u0 + 0.015, v0 + 0.01, u0 + 0.255, v0 + 0.245), true, true), TILE, 0.05, 0.3, 16 - i * 2.5, 2);
      R.dome(P(tileQuad(LW, u0 + 0.06, v0 + 0.05, u0 + 0.21, v0 + 0.2), true, true), '#c8d6d4', 0.25, 0.06, 6, 2);
    }
    a.restore(); R.h.restore();
    for (const [x0, y0, x1, y1, w] of [[0, 170, 70, 120, 10], [10, 165, 80, 175, 9], [0, 160, 40, 110, 8], [20, 170, 50, 230, 9], [0, 175, 20, 220, 8], [10, 160, 70, 145, 8]]) R.dome(sm([[x0, y0], [(x0 + x1) / 2 + (y1 - y0) * 0.12, (y0 + y1) / 2 - (x1 - x0) * 0.12 - w * 0.3], [x1, y1], [(x0 + x1) / 2 - (y1 - y0) * 0.12, (y0 + y1) / 2 + (x1 - x0) * 0.12 + w * 0.3]]), '#1e3a22', 0.2, 0.05, 4, 3);
    // vent grille
    R.flat(poly([[76, 114], [146, 126], [146, 142], [76, 130]]), '#d8d8d4', 0.1, 1);
    for (let k = 0; k < 9; k++) R.groove(line([[82 + k * 7, 118 + k * 1.2], [82 + k * 7, 130 + k * 1.2]]), 2, '#5a5a58', 0.1, 0.03, 1);
    // ── back wall tiles ──
    R.flat(poly([[255, 160], [736, 110], [736, 600], [255, 600]]), GROUT, 0.02, 1);
    { const cols = [256, 326, 412, 498, 584, 668, 752], rows = [140, 230, 330, 420, 510, 600];
      for (let c = 0; c < cols.length - 1; c++) for (let r = 0; r < rows.length - 1; r++) {
        const x0 = cols[c] + 4, x1 = cols[c + 1] - 4, y0 = rows[r] + 4 - c * 6, y1 = rows[r + 1] - 4 - c * 6;
        R.dome(rrect(x0, Math.max(y0, 170 - c * 12), x1 - x0, y1 - Math.max(y0, 170 - c * 12), 18), TILE, 0.05, 0.28, 16, 2);
        R.dome(rrect(x0 + 16, Math.max(y0, 170 - c * 12) + 16, x1 - x0 - 32, y1 - Math.max(y0, 170 - c * 12) - 32, 12), '#c8d6d4', 0.22, 0.06, 6, 2);
      } }
    // ── zebra banner ──
    const ban = sm([[293, 176], [350, 166], [410, 160], [440, 180], [480, 196], [530, 196], [580, 180], [620, 155], [660, 130], [700, 118], [736, 116], [736, 175], [700, 190], [660, 215], [620, 250], [590, 290], [560, 310], [530, 330], [510, 372], [480, 360], [462, 320], [440, 290], [400, 272], [340, 268], [296, 270]]);
    R.dome(ban, '#888', 0.08, 0.06, 10, 1);
    clipA(ban, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = 14. * sin(p.x * 0.022 + 1.0) + 8. * sin(p.x * 0.05);
      float sl = 0.1 + 0.55 * smoothstep(520., 700., p.x);
      float hph = (p.y - w + sl * (p.x - 400.)) / 15.;
      float vph = (p.x + 6. * sin(p.y * 0.05)) / 19.;
      float k = smoothstep(380., 450., p.x + 0.4 * (p.y - 200.));
      float v = k > .5 ? sin(6.2832 * hph) : sin(6.2832 * vph);
      return mix(vec3(.95,.95,.94), vec3(.05,.05,.06), smoothstep(-.2, .2, v)); }`)));

    // ── floor (grey-blue) with zebra areas ──
    const floor = poly([[-10, 600], [736, 590], [736, 1034], [-10, 1034]]);
    R.flat(floor, lin(0, 600, 0, 1024, [[0, '#5e6a6c'], [0.4, '#72807e'], [1, '#7a8686']]), 0.01, 0);
    const fz = poly([[385, 760], [660, 730], [600, 860], [560, 1034], [-10, 1034], [-10, 960], [140, 1000], [340, 975], [385, 940]]);
    R.flat(fz, '#888', 0.015, 0);
    clipA(fz, () => img(E.fx(`const vec2 ZC[38] = vec2[38](vec2(420., 763.), vec2(476., 763.), vec2(532., 763.), vec2(588., 763.), vec2(364., 819.), vec2(420., 819.), vec2(476., 819.), vec2(532., 819.), vec2(588., 819.), vec2(364., 875.), vec2(420., 875.), vec2(476., 875.), vec2(532., 875.), vec2(588., 875.), vec2(364., 931.), vec2(420., 931.), vec2(476., 931.), vec2(532., 931.), vec2(588., 931.), vec2(28., 987.), vec2(84., 987.), vec2(140., 987.), vec2(252., 987.), vec2(308., 987.), vec2(364., 987.), vec2(420., 987.), vec2(476., 987.), vec2(532., 987.), vec2(588., 987.), vec2(28., 1043.), vec2(84., 1043.), vec2(140., 1043.), vec2(252., 1043.), vec2(308., 1043.), vec2(364., 1043.), vec2(420., 1043.), vec2(476., 1043.), vec2(532., 1043.));
const float ZK[228] = float[228](5.1790, 2.1721, 2.6230, 0.9560, -0.3297, -2.3310, -4.5060, 1.9007, 3.0144, -1.2773, 2.5313, 3.9711, -4.4834, 0.8527, -1.9549, 0.0131, -0.5318, 3.9486, 5.1818, 0.2124, 1.3006, 1.2574, -0.6438, -1.8790, 1.1334, 0.5608, 2.0502, -0.4852, -4.1039, -0.3204, -4.2356, 0.1705, -0.8186, 0.3142, -1.6544, -1.0333, -4.3019, 0.8737, 6.5849, 2.3268, 0.6474, -0.4775, -1.6572, -0.2105, -1.3968, 0.4061, 3.5724, 0.3433, 1.3521, -0.5455, -1.1094, -0.8538, -1.1134, -1.1859, -6.1338, -3.5603, -0.3404, 7.2159, 3.1665, 1.5328, 3.5460, -0.9551, -0.4464, -1.2871, -3.5959, -0.4122, 0.3731, 0.6261, -0.1048, 0.8951, 0.0821, -0.3621, -0.1081, 0.3124, -0.5785, -1.7431, -2.0101, -0.1729, 0.2505, 5.4237, 5.8705, 5.0974, 7.5101, 1.0683, -5.7995, 4.6937, 3.7951, -4.6385, -8.1041, -1.1926, 21.9980, 2.5084, 1.5512, -2.3713, -2.5613, -0.2049, -1.4461, 0.1610, 0.7264, -1.0838, -0.1832, 0.5360, 1.4084, 3.1077, 3.0877, -2.0077, 1.2574, -1.5085, 4.7797, 0.7335, 2.9744, -1.8744, 2.6878, -0.7393, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, -0.8355, 0.4313, 0.5123, -0.8565, -3.0327, -3.2414, 0.6975, -0.6721, 1.8194, -1.9808, -0.0654, -0.8007, 0.9252, 1.7221, 5.2565, 1.6654, -0.0279, -5.0255, -0.5976, 3.1159, 4.2407, 0.6419, -1.1761, -3.1120, 1.5134, 0.7198, 0.8826, -0.5217, -0.7952, -0.5833, -4.2000, 0.6247, 0.7662, -0.2062, 0.3508, -0.2700, 4.9764, 3.1478, 2.9517, -0.5023, -1.4216, -0.3353, 9.6455, 3.0807, 2.0509, 0.0507, -1.5436, 0.3058, 6.5103, 3.9416, 1.7478, 1.1684, -0.2867, 0.4225, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.0000, 0.3505, -1.3197, -3.7853, -0.9744, -3.2339, -4.3281, 0.4652, -0.7087, 0.9224, -1.9808, -0.0652, -0.8012, -0.7046, 1.6842, -0.3709, 1.6593, -0.1311, -5.0679, 4.7627, 2.8531, 0.4040, 0.5098, 0.2385, -3.7194, 2.1777, -0.0166, 2.2630, -0.0837, -1.5909, 1.9323, -0.9836, 0.8691, -0.0137, 0.2933, 0.7733, -0.8594, -6.0119, 3.6703, 0.5995, 1.3075, 3.8875, -1.6191, 4.6700, 2.5650, 1.0087, 0.4121, -0.7597, -1.8072);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 38; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.1897);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){ return mix(vec3(.94,.94,.93), vec3(.05,.05,.06), smoothstep(-.14, .14, zv(p))); }`)));
    // checker strip by the belt
    clipA(poly([[120, 612], [300, 616], [330, 660], [130, 662]]), () => { for (let k = 0; k < 14; k++) { a.fillStyle = k % 2 ? '#f0f0ee' : '#0e0e10'; a.fill(poly([[120 + k * 15, 612], [135 + k * 15, 612], [150 + k * 15, 662], [135 + k * 15, 662]])); } });

    // ── white blob creature (left middle) ──
    R.dome(circleP(205, 340, 85), lin(140, 270, 260, 420, [[0, '#f0efea'], [1, '#bcbcb6']]), 0.05, 0.45, 60, 1);
    R.dome(sm([[82, 330], [96, 300], [130, 290], [160, 310], [200, 330], [230, 380], [220, 430], [190, 470], [150, 480], [120, 460], [100, 420], [80, 390]]), lin(90, 300, 200, 480, [[0, '#e4e3de'], [0.4, '#b0b0aa'], [1, '#6e6e6a']]), 0.1, 0.4, 40, 1);
    R.dome(sm([[78, 400], [100, 396], [112, 430], [104, 470], [86, 468]]), '#b8b8b2', 0.2, 0.3, 14, 1);
    R.dome(circleP(107, 340, 16), '#f0e050', 0.45, 0.08, 6, 2);
    R.dome(circleP(107, 340, 7), '#1a1a1a', 0.5, 0.04, 4, 2);
    // ── coral boiler machine ──
    R.pipe(line([[340, 262], [340, 312]]), 40, '#a85a48', 0.2, 0.15, 2);
    R.dome(ellipseP(340, 262, 22, 7, 0), '#8a4a3a', 0.32, 0.04, 4, 2);
    R.dome(poly([[258, 310], [445, 306], [445, 326], [258, 330]]), '#2a2a2a', 0.15, 0.06, 6, 4);
    const mach = poly([[210, 400], [262, 326], [450, 322], [456, 590], [262, 600], [212, 500]]);
    R.dome(mach, lin(210, 0, 456, 0, [[0, '#c87666'], [0.6, '#d48878'], [1, '#b06a5c']]), 0.1, 0.12, 14, 1);
    for (const [x, y, r] of [[362, 352, 6], [398, 345, 4], [420, 360, 5], [340, 372, 3], [285, 415, 4], [420, 420, 3], [440, 470, 5]]) R.dome(circleP(x, y, r), '#f0eeea', 0.25, 0.04, 3, 1);
    R.dome(circleP(318, 404, 33), '#f8f8f4', 0.25, 0.06, 6, 1);
    R.dome(circleP(318, 404, 28), '#f0d010', 0.28, 0.04, 6, 1);
    a.save(); a.fillStyle = '#141414'; a.font = 'bold 26px Arial Black, Arial, sans-serif'; a.textAlign = 'center'; a.textBaseline = 'middle'; a.fillText('MM', 318, 400); a.restore();
    R.dome(rrect(258, 390, 26, 52, 4), '#f0f0ec', 0.2, 0.08, 6, 1);
    R.dome(rrect(230, 398, 20, 26, 2), '#242424', 0.2, 0.04, 3, 4);
    R.pipe(line([[250, 446], [400, 444]]), 12, '#3a3a3a', 0.25, 0.06, 4);
    R.dome(rrect(318, 464, 40, 136, 4), '#2c2c2e', 0.2, 0.05, 6, 4);
    speck(rrect(318, 464, 40, 136, 4), 220, 9, '#9a9a9a', 1.6, [318, 464, 358, 600]);
    R.dome(circleP(394, 536, 30), '#e4e4e0', 0.22, 0.12, 14, 4);
    R.dome(circleP(394, 536, 10), '#9a9a9a', 0.32, 0.05, 6, 4);
    R.dome(circleP(288, 484, 16), '#5a5a5a', 0.22, 0.08, 8, 4);
    R.pipe(line([[360, 490], [384, 486]]), 10, '#d8d8d8', 0.28, 0.05, 4);
    R.dome(ellipseP(455, 512, 14, 50, 0), '#7a2e26', 0.15, 0.1, 8, 3);
    // white chair
    R.dome(poly([[186, 478], [262, 472], [276, 560], [200, 568]]), '#ecebe6', 0.2, 0.18, 14, 1);
    R.dome(poly([[200, 560], [330, 552], [334, 590], [204, 600]]), '#e6e5e0', 0.25, 0.14, 12, 1);
    for (const [x, y] of [[206, 596], [306, 590]]) R.dome(rrect(x, y, 20, 34, 4), '#dcdbd6', 0.2, 0.12, 6, 1);
    R.dome(poly([[412, 566], [500, 562], [500, 600], [412, 604]]), '#ecece8', 0.15, 0.12, 8, 1);
    // ── right: table with laptop, eggs, pink table, robot arm, black ball ──
    R.flat(poly([[516, 452], [640, 448], [640, 466], [516, 470]]), '#f2f0ec', 0.15, 1);
    for (const x of [522, 628]) R.flat(rrect(x, 466, 8, 120, 2), '#e8e4dc', 0.15, 1);
    R.dome(poly([[556, 412], [640, 410], [636, 448], [552, 452]]), '#e6e6e2', 0.2, 0.06, 6, 1);
    R.flat(poly([[566, 418], [630, 416], [626, 440], [562, 442]]), '#cfd2d4', 0.25, 1);
    for (const [x, y, r] of [[650, 500, 22], [682, 512, 20], [618, 504, 14]]) R.dome(ellipseP(x, y, r, r * 0.85, 0), '#f0efec', 0.2, 0.25, r, 1);
    R.flat(poly([[606, 528], [736, 520], [736, 548], [606, 552]]), '#e8b4a8', 0.15, 1);
    R.flat(rrect(616, 548, 12, 110, 2), '#e8d8d0', 0.15, 1);
    R.pipe(line([[630, 180], [672, 260], [700, 330], [690, 420], [660, 470]]), 10, '#c8ccd0', 0.4, 0.1, 4);
    R.pipe(line([[700, 330], [726, 300]]), 16, '#d8d8d8', 0.4, 0.1, 1);
    R.pipe(line([[650, 268], [700, 300]]), 22, '#e4e4e0', 0.45, 0.15, 1);
    R.bead(712, 376, 18, '#e0702a', 0.45, 0.15, 2);
    R.bead(718, 312, 14, '#efefec', 0.45, 0.15, 1);
    R.pipe(line([[630, 150], [680, 200], [736, 240]]), 30, '#1a1a1c', 0.45, 0.12, 4);
    for (const [x, y, c] of [[660, 186, '#f04040'], [690, 214, '#40c0f0'], [712, 230, '#f0e040'], [640, 168, '#e8e8e8']]) R.flat(circleP(x, y, 5), c, 0.58, 4);
    R.bead(700, 112, 62, '#141416', 0.3, 0.35, 4);
    // corn cob on the wall
    snake([[474, 170], [520, 168], [568, 182]], 64, 3);
    R.dome(P([[568, 176], [590, 186], [568, 196]], true, false), '#e8e8e4', 0.35, 0.05, 4, 1);

    // ── black wheeled toaster, belt with letters ──
    R.dome(circleP(46, 660, 66), '#2a2a2c', 0.08, 0.2, 16, 4);
    R.dome(circleP(46, 660, 48), '#8a4632', 0.2, 0.08, 10, 3);
    for (let k = 0; k < 12; k++) { const t = k / 12 * 6.283; R.pipe(line([[46 + Math.cos(t) * 12, 660 + Math.sin(t) * 12], [46 + Math.cos(t) * 44, 660 + Math.sin(t) * 44]]), 4, '#c88060', 0.3, 0.04, 3); }
    R.dome(circleP(46, 660, 13), '#3a3a3a', 0.32, 0.05, 6, 4);
    const toast = sm([[104, 560], [140, 532], [210, 530], [226, 560], [228, 670], [104, 668]]);
    R.dome(toast, lin(104, 0, 228, 0, [[0, '#18181a'], [1, '#4a4a4e']]), 0.1, 0.2, 14, 4);
    clipA(toast, () => { a.strokeStyle = '#6a6a6a'; a.lineWidth = 1.2; for (let k = 0; k < 8; k++) { a.beginPath(); a.moveTo(112 + k * 15, 532); a.lineTo(112 + k * 15, 670); a.stroke(); } for (let k = 0; k < 6; k++) { a.beginPath(); a.moveTo(104, 545 + k * 22); a.lineTo(228, 545 + k * 22); a.stroke(); } });
    R.flat(rrect(110, 600, 74, 10, 2), '#d8c070', 0.32, 4);
    R.pipe(line([[160, 680], [160, 752]]), 6, '#1a1a1a', 0.1, 0.04, 4);
    snake([[236, 718], [300, 690], [360, 668], [430, 646], [500, 622], [560, 600], [612, 590], [660, 600], [690, 630], [672, 662], [630, 664], [600, 650]], 72, 5);
    const belt = P([[86, 652], [200, 662], [330, 672], [513, 686], [620, 692], [736, 660], [736, 700], [620, 732], [513, 728], [330, 714], [200, 702], [86, 690]], true, true);
    R.dome(belt, '#141414', 0.35, 0.05, 6, 4);
    clipA(belt, () => {
      a.save(); a.fillStyle = '#f4f4f2'; a.font = 'bold 30px Arial Narrow, Arial, sans-serif'; a.textBaseline = 'middle'; a.translate(104, 668); a.rotate(0.06); a.fillText('Gane nito /soo intals', 0, 6); a.restore();
      const r = rng(17); for (let k = 0; k < 18; k++) { const x = 420 + r() * 310, y = 688 + r() * 24; a.fillStyle = r() < 0.6 ? '#c8d850' : '#e87a6a'; a.fill(sm(blob(x, y, 8 + r() * 10, 5 + r() * 5, k, 8, 0.3))); }
    });
    soft(x => { x.fillStyle = '#1a1e20'; x.fill(P([[90, 700], [330, 720], [620, 735], [736, 700], [736, 760], [620, 780], [330, 770], [90, 750]], true, true)); }, 16, 0.5);
    // ── corn snakes ──
    R.dome(ellipseP(420, 664, 34, 20, 0), '#efeeea', 0.45, 0.15, 12, 1);
    R.dome(ellipseP(580, 708, 70, 22, 0), '#e8e8e4', 0.3, 0.08, 10, 1);
    R.dome(ellipseP(656, 636, 16, 16, 0), '#f0efec', 0.45, 0.15, 8, 1);
    // white box with zebra top
    R.dome(poly([[340, 760], [380, 714], [540, 720], [540, 770], [520, 812], [340, 806]]), '#a8a8a6', 0.15, 0.12, 8, 1);
    clipA(poly([[340, 760], [380, 714], [540, 720], [540, 770]]), () => { a.fillStyle = '#121212'; for (let k = 0; k < 6; k++) a.fill(poly([[340, 744 + k * 9], [540, 718 + k * 9], [540, 723 + k * 9], [340, 749 + k * 9]])); });
    // pink ramp with chrome balls
    const ramp = poly([[560, 1034], [640, 820], [690, 720], [736, 700], [736, 1034]]);
    R.dome(ramp, lin(600, 760, 736, 1024, [[0, '#d88474'], [0.6, '#b86a5c'], [1, '#3a2428']]), 0.06, 0.08, 12, 1);
    { const r = rng(21); for (let k = 0; k < 14; k++) R.flat(sm(blob(600 + r() * 140, 760 + r() * 260, 6 + r() * 10, 4 + r() * 6, k, 8, 0.3)), r() < 0.5 ? '#60a8d0' : '#f07040', 0.07, 1); }
    snake([[650, 742], [632, 800], [600, 846], [540, 876], [470, 900], [420, 940], [370, 980], [320, 1010], [290, 1040]], 70, 7);
    for (const [x, y] of [[706, 793], [689, 862]]) { R.bead(x, y, 26, '#d8dce0', 0.15, 0.3, 5); }
    R.dome(ellipseP(620, 915, 62, 52, 0), lin(570, 870, 680, 970, [[0, '#dcdad8'], [1, '#8a8686']]), 0.08, 0.4, 40, 1);
    // ── white tub with water ──
    const tub = sm([[38, 792], [80, 772], [300, 780], [348, 792], [388, 842], [384, 942], [344, 976], [140, 1002], [38, 992]]);
    R.dome(tub, lin(0, 780, 0, 1000, [[0, '#f0f0ec'], [0.7, '#d8d8d4'], [1, '#8a8a88']]), 0.06, 0.28, 24, 1);
    const water = sm([[40, 816], [92, 800], [292, 810], [332, 822], [356, 852], [352, 930], [322, 958], [132, 976], [40, 962]]);
    R.flat(water, lin(0, 800, 0, 970, [[0, '#a8c4c2'], [1, '#c8dedc']]), 0.12, 6);
    soft(x => { x.fillStyle = '#90b0ae'; x.fill(sm([[220, 870], [270, 860], [330, 880], [300, 900], [240, 896]])); x.fill(sm([[160, 930], [220, 920], [260, 940], [200, 950]])); }, 6, 0.6);
    // white creature arm on the left
    R.dome(sm([[-10, 700], [40, 712], [60, 750], [40, 800], [80, 860], [140, 880], [190, 900], [200, 930], [170, 944], [120, 930], [80, 940], [56, 990], [-10, 1000]]), lin(0, 700, 60, 1000, [[0, '#e6e5e0'], [0.5, '#c8c8c2'], [1, '#6a6866']]), 0.1, 0.5, 50, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 36, wrap: 0.5, ao: 0.5, coat: 0.06 }),                              // 1 white plastic
        E.mat({ dif: 0.9, spec: 1.1, shin: 70, wrap: 0.4, ao: 0.5, coat: 0.25, rim: 0.15 }),                  // 2 glossy tiles
        E.mat({ dif: 1, spec: 0.12, shin: 14, wrap: 0.5, ao: 0.6, grain: 0.15 }),                             // 3 knit / matte
        E.mat({ dif: 0.6, metal: 0.5, spec: 1.2, shin: 60, ao: 0.4, coat: 0.2 }),                             // 4 black / metal
        E.mat({ dif: 0.4, metal: 0.9, spec: 1.6, shin: 90, ao: 0.3, coat: 0.3 }),                             // 5 chrome
        E.mat({ dif: 0.8, spec: 0.8, shin: 60, wrap: 0.5, coat: 0.2, emis: 0.1 })                             // 6 water
      ],
      light: [-0.5, 0.5, 0.7], lc: [0.72, 0.72, 0.7], amb: [0.45, 0.46, 0.46],
      envTop: [1.15, 1.14, 1.12], envHor: [0.6, 0.64, 0.64], envBot: [0.3, 0.33, 0.33], envK: [0.15, 0.7, 0.3, 0],
      rimC: [0.1, 0.1, 0.1], rimD: [0, 1, 0], r1: 1.6, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-4, 7, 0.5, 10]
    });
    E.grain(0.025, 165);
  }
});
