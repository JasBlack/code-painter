'use strict';
// g077 — "Zebra clam in the desert": a giant zebra-striped creature with a tan leather shell for a mouth sits
// in a blue pool under two moons; mesas, saguaros, a nebula sky and gold chrome pins crowd the sand.
REC.register('g077', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    keep();
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, st, x1, y1) => { const g = a.createRadialGradient(x, y, 0, x1 ?? x, y1 ?? y, r); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.stroke(path); };

    // ── textures ──
    const sky = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.13,.30,.76), vec3(.20,.52,.85), smoothstep(40., 330., p.y));
      // nebula star
      vec2 d = p - vec2(548., 148.); float an = atan(d.y, d.x), r = length(d);
      float arm = pow(abs(cos(an * 2.5 + 0.3 + 0.4 * (fbm(p * 0.02) - .5))), 3.) * smoothstep(105., 15., r) + smoothstep(45., 0., r) * 0.5;
      arm *= 0.5 + 0.8 * fbm(p * 0.035);
      c = mix(c, vec3(.55,.85,.95), clamp(arm, 0., 1.) * 0.85);
      float cl = smoothstep(150., 0., length((p - vec2(530., 150.)) * vec2(0.8, 1.2)));
      float st = step(0.985 - 0.03 * cl, hash(floor(p / 2.5))) * smoothstep(0., 1., cl * 1.4 + 0.08);
      c = mix(c, vec3(1.,.97,.95), st);
      c = mix(c, vec3(.85,.7,.8), cl * cl * 0.25 * step(0.6, hash(floor(p / 1.5) + 3.)));
      return c; }`));
    const moonTex = (cx, cy, r) => pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(${cx.toFixed(1)}, ${cy.toFixed(1)})) / ${r.toFixed(1)};
      float n = fbm(d * 3.2 + 5.) ; float m = smoothstep(0.52, 0.6, n);
      vec3 c = mix(vec3(.97,.92,.66), vec3(.86,.73,.33), m);
      c *= 1. - 0.12 * smoothstep(0.6, 1., length(d));
      return c; }`));
    // zebra creature stripes: contours around the spiral eye
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 c = vec2(183., 390.);
      vec2 q = p + 3. * vec2(fbm(p * 0.02) - .5, fbm(p * 0.02 + 5.) - .5);
      vec2 d = q - c; float an = atan(d.y, d.x);
      vec3 W = vec3(.97,.96,.94), B = vec3(.02,.02,.025);
      if (length(d) < 37.) { float f = fract(length(d) / 4.8 + an * 0.16); return mix(B, W, smoothstep(0.35, 0.5, f) * smoothstep(0.95, 0.8, f)); }
      vec2 e = vec2((q.x - 170.8) * 1.021, q.y - 401.7);
      float dyp = e.y > 0. ? e.y / (1.99 + 0.0016 * e.y) : e.y / 0.963;
      float r = e.x < 0. ? length(vec2(e.x, dyp)) : abs(dyp);
      float n = (-22.23 + sqrt(max(494.2 + 7.264 * (r - 48.), 0.))) / 3.632;
      float f = fract(n + 0.641);
      float w = smoothstep(0.385, 0.43, f) * (1. - smoothstep(0.975, 1., f));
      return mix(B, W, clamp(w, 0., 1.)); }`));
    const zDisc = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = (p - vec2(400., 895.)) * vec2(1.0, 1.8); float r = length(d) + 5. * sin(p.x * 0.012);
      float f = fract((r * r - 2116.) / 24000.);
      return mix(vec3(.04,.03,.03), vec3(.98,.88,.70), smoothstep(0.5, 0.53, f) * smoothstep(1.0, 0.97, f)); }`));
    const zGround = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float s = dot(p, vec2(0.48, 0.88)) / 48.;
      float f = fract(s - 0.79);
      return mix(vec3(.04,.03,.03), vec3(.98,.86,.62), smoothstep(0.45, 0.49, f) * smoothstep(1.0, 0.97, f)); }`));
    const water = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.14,.36,.62), vec3(.18,.44,.70), smoothstep(640., 900., p.y));
      c += 0.06 * (fbm(vec2(p.x * 0.01, p.y * 0.08)) - .5);
      return c; }`));
    const sand = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.96,.85,.63), vec3(.96,.81,.49), smoothstep(540., 720., p.y));
      c = mix(c, vec3(.965,.80,.43), smoothstep(720., 1000., p.y));
      c *= 0.96 + 0.06 * fbm(p * 0.02);
      return c; }`));
    const desert = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = mix(vec3(.93,.83,.70), vec3(.97,.90,.80), smoothstep(400., 510., p.y));
      float t = step(0.9, hash(vec2(floor(p.x / 5.), floor(p.y / 14.)))) * step(fract(p.y / 14.), 0.5) * smoothstep(420., 500., p.y);
      c = mix(c, vec3(.55,.42,.22), t * 0.7);
      return c; }`));

    // ── sky, black wave, moon ──
    R.flat(rrect(-10, -10, 746, 560, 0), sky, 0, 0);
    const WAVE = P([[-10, -10], [600, -10], [588, 6], [560, 20], [513, 20], [463, 20], [425, 28], [395, 50], [363, 70], [325, 75], [275, 80], [230, 90],
      [205, 112], [180, 140], [150, 160], [100, 180], [55, 175], [25, 182], [0, 205], [-10, 210]]);
    F(WAVE, '#020203');
    K(P([[600, -10], [588, 6], [560, 20], [513, 20], [463, 20], [425, 28], [395, 50], [363, 70], [325, 75], [275, 80], [230, 90], [205, 112], [180, 140], [150, 160], [100, 180], [55, 175], [25, 182], [0, 205]], false), '#3a3a50', 3);
    R.dome(circleP(80, 106, 51), moonTex(80, 106, 51), 0.02, 0.04, 10, 0);
    // glass pane on the right
    const GL = P([[668, -10], [736, -10], [736, 300], [700, 282], [680, 270], [672, 250]], true, false);
    F(GL, lin(668, 0, 726, 300, [[0, '#a8c4e4'], [0.5, '#78a4d8'], [1, '#9cc0e6']]));
    soft(x => { x.fillStyle = 'rgba(230,240,255,0.7)'; x.fill(ellipseP(700, 60, 12, 40, 0)); x.fill(ellipseP(706, 180, 10, 50, 0)); }, 6, 1);
    K(P([[672, -10], [672, 250], [680, 270], [700, 282], [736, 300]], false), '#e0a850', 4);
    K(P([[668, -10], [668, 250]], false), '#f8f0e0', 1.5);

    // ── mesas ──
    const MESA = P([[330, 186], [336, 183], [450, 196], [452, 220], [462, 260], [478, 290], [492, 308], [540, 312], [610, 300], [614, 282], [690, 288], [690, 320],
      [705, 360], [726, 380], [726, 430], [450, 430], [330, 420]], true, false);
    F(MESA, lin(330, 190, 600, 420, [[0, '#f0c88a'], [0.4, '#ecbf78'], [0.7, '#eab460'], [1, '#e4ac5a']]));
    F(P([[330, 186], [336, 183], [450, 196], [450, 206], [336, 194]], true, false), '#c99a58');
    F(P([[614, 282], [690, 288], [690, 296], [614, 291]], true, false), '#c99a58');
    F(P([[606, 296], [614, 284], [614, 330], [600, 330]], true, false), '#d8a648');
    F(P([[452, 206], [462, 260], [478, 290], [492, 308], [470, 310], [452, 300]], true, false), '#f0d49c');
    for (const pts of [[[466, 312], [478, 352], [488, 380]], [[490, 370], [510, 360], [524, 380], [536, 365], [560, 390], [585, 410]], [[600, 330], [598, 380], [612, 404], [640, 420]]])
      K(P(pts, false), '#a06a30', 1.2);
    F(P([[690, 315], [700, 305], [726, 300], [726, 400], [700, 380]], true, false), '#f6efe2');
    F(P([[704, 360], [726, 352], [726, 395], [710, 392]], true, false), '#b48270');
    R.dome(circleP(600, 363, 12), '#c4c8f0', 0.03, 0.04, 8, 2);
    // desert floor with far cacti
    F(rrect(300, 405, 440, 130, 0), desert);
    { const q = rng(77); for (let i = 0; i < 22; i++) { const x = 420 + q() * 300, y = 425 + q() * 60, h = 6 + q() * 12;
      K(P([[x, y], [x, y - h]], false), '#7a5a2a', 2); K(P([[x - 4, y - h * 0.4], [x - 4, y - h * 0.7]], false), '#7a5a2a', 1.4); } }
    // icy strip
    R.pipe(P([[300, 528], [420, 522], [560, 526], [726, 518]], false), 18, '#cfe6ee', 0.03, 0.04, 3);
    keep();

    // ── sand ground, pond, blue pool ──
    R.flat(P([[290, 536], [726, 528], [736, 1034], [-10, 1034], [-10, 640], [290, 640]], true, false), sand, 0.02, 0);
    const POND = P([[302, 578], [325, 566], [450, 562], [560, 566], [640, 560], [662, 572], [646, 590], [570, 598], [500, 616], [420, 628], [330, 630], [306, 612]]);
    R.flat(POND, lin(0, 562, 0, 630, [[0, '#2a1a10'], [0.5, '#5a3a24'], [1, '#3a2416']]), 0.01, 0);
    F(P([[302, 578], [325, 566], [450, 562], [560, 566], [640, 560], [662, 572], [640, 578], [450, 572], [320, 582]]), '#8a5a34');
    const POOL = P([[-10, 640], [60, 650], [150, 690], [260, 694], [400, 684], [470, 690], [460, 730], [380, 760], [300, 780], [200, 800], [150, 820], [60, 880], [-10, 920]]);
    R.flat(POOL, water, 0.01, 0);
    soft(x => { x.fillStyle = 'rgba(200,220,240,0.45)'; x.fill(ellipseP(200, 760, 140, 14, -0.1)); x.fill(ellipseP(380, 720, 70, 10, 0)); }, 10, 1);
    keep();

    // ── far cacti ──
    const cactus = (x, y0, h, w, arms) => {
      const col = lin(x - w, 0, x + w, 0, [[0, '#6a4a1c'], [0.4, '#c09848'], [1, '#5a3c16']]);
      R.dome(rrect(x - w / 2, y0 - h, w, h, w / 2), col, 0.04, 0.06, w * 0.4, 3);
      for (const [side, ay, ah] of arms) {
        const ax = x + side * w * 1.1;
        R.pipe(P([[x, ay], [ax, ay], [ax, ay - ah]], false), w * 0.7, '#a07a34', 0.04, 0.05, 3);
      }
    };
    cactus(490, 568, 150, 16, [[-1, 500, 40], [1, 470, 40]]);
    cactus(580, 540, 100, 12, [[-1, 490, 26], [1, 480, 30]]);
    cactus(405, 560, 90, 11, [[-1, 515, 24], [1, 500, 24]]);
    cactus(367, 555, 60, 9, [[1, 520, 18]]);
    cactus(625, 520, 60, 9, [[1, 490, 16]]);
    cactus(698, 556, 90, 11, [[-1, 510, 24], [1, 500, 22]]);
    cactus(677, 524, 74, 9, [[1, 488, 16]]);
    cactus(14, 520, 70, 9, [[1, 490, 20]]);
    keep();

    // ── the zebra creature ──
    const BODY = P([[10, 620], [3, 560], [2, 480], [8, 400], [30, 345], [70, 298], [98, 272], [140, 262], [200, 290], [255, 320], [262, 380], [272, 450], [298, 520], [306, 600],
      [300, 650], [292, 700], [240, 716], [150, 716], [80, 700], [40, 670]]);
    soft(x => { x.fillStyle = 'rgba(10,20,40,0.7)'; x.fill(ellipseP(170, 715, 150, 22, 0)); }, 10, 1);
    R.dome(BODY, zeb, 0.08, 0.2, 60, 2);
    soft(x => { x.fillStyle = 'rgba(255,255,255,0.75)'; x.fill(ellipseP(80, 350, 10, 40, 0.5)); x.fill(ellipseP(65, 430, 6, 30, 0.3)); }, 9, 1);
    clipA(BODY, () => soft(x => { x.fillStyle = 'rgba(160,150,160,0.8)'; x.fill(ellipseP(160, 640, 40, 25, 0.3)); }, 3, 0.8));
    // mottled base
    R.dome(P([[150, 700], [200, 712], [260, 704], [300, 695], [310, 718], [290, 735], [240, 740], [180, 732], [140, 718]]), '#e8d6c0', 0.06, 0.06, 10, 2);
    R.dome(P([[228, 708], [262, 700], [300, 696], [310, 716], [290, 734], [250, 736], [230, 724]]), '#6a5658', 0.08, 0.05, 8, 2);
    R.dome(P([[150, 703], [175, 700], [180, 718], [160, 726], [143, 716]]), '#7a6466', 0.08, 0.04, 6, 2);
    // leather shell (upper lip)
    const leather = lin(100, 200, 400, 360, [[0, '#f2d098'], [0.5, '#eec890'], [1, '#e0ae72']]);
    const UP = P([[94, 270], [130, 238], [200, 210], [270, 200], [350, 204], [410, 224], [446, 262], [460, 310], [456, 350], [420, 354], [350, 360], [300, 368],
      [240, 386], [200, 345], [150, 302]], true);
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.9)'; x.fill(P([[240, 370], [300, 356], [450, 345], [458, 375], [300, 380], [245, 398]])); }, 3, 1);
    const LO = P([[236, 392], [300, 372], [350, 364], [420, 360], [456, 372], [460, 420], [446, 468], [410, 505], [350, 526], [300, 526], [282, 480], [258, 430]]);
    R.dome(LO, lin(240, 360, 460, 520, [[0, '#d8a060'], [0.6, '#c88a48'], [1, '#b07038']]), 0.1, 0.26, 55, 1);
    R.groove(P([[350, 362], [345, 420], [340, 470], [334, 524]], false), 6, '#a0703c', 0.24, 0.08, 1);
    R.groove(P([[288, 420], [320, 410], [346, 420]], false), 5, '#a0703c', 0.22, 0.06, 1);
    R.dome(UP, leather, 0.1, 0.3, 70, 1);
    R.groove(P([[205, 212], [250, 224], [285, 250], [312, 288], [326, 330], [336, 360]], false), 6, '#9c6c38', 0.26, 0.1, 1);
    R.groove(P([[150, 255], [200, 250], [240, 270]], false), 4, '#c09060', 0.25, 0.04, 1);
    K(P([[96, 272], [150, 302], [200, 345], [238, 386]], false), '#b08848', 2.5);
    R.dome(ellipseP(195, 295, 23, 21, 0), lin(175, 275, 215, 315, [[0, '#dce0fa'], [1, '#b4bce8']]), 0.3, 0.03, 10, 2);
    R.dome(ellipseP(425, 272, 15, 21, 0.2), lin(410, 252, 440, 292, [[0, '#dce0fa'], [1, '#aab4e6']]), 0.3, 0.03, 8, 2);
    R.dome(circleP(47, 468, 27), lin(20, 440, 74, 496, [[0, '#e8ecfc'], [1, '#c0c6ec']]), 0.2, 0.08, 14, 2);
    keep();

    // ── pedestal with cap, moon two, chrome balls on the pool ──
    R.dome(P([[110, 590], [126, 590], [128, 650], [134, 700], [140, 735], [100, 735], [106, 700], [110, 650]]), lin(100, 0, 140, 0, [[0, '#c8a888'], [0.5, '#f4e0c8'], [1, '#b89878']]), 0.12, 0.1, 10, 1);
    R.dome(ellipseP(118, 573, 35, 22, 0), lin(0, 552, 0, 596, [[0, '#ece0d8'], [0.45, '#d8c8c0'], [0.55, '#5a4446'], [1, '#3a2a2c']]), 0.24, 0.1, 14, 6);
    R.dome(circleP(102, 780, 48), moonTex(102, 780, 48), 0.06, 0.1, 22, 0);
    const chrome = (x, y, r) => {
      R.dome(circleP(x, y, r), rad(x - r * 0.3, y - r * 0.35, r * 1.2, [[0, '#ffffff'], [0.2, '#d8d0d4'], [0.45, '#6a5050'], [0.7, '#2a1c1c'], [0.85, '#b89080'], [1, '#504040']]), 0.08, Math.min(0.3, r * 0.008 + 0.05), r, 5);
    };
    chrome(27, 722, 26); chrome(168, 752, 14); chrome(660, 540, 8);

    // ── pale blue tubes ──
    const TUBE = '#c6e2ee';
    const tube = (pts, wd) => R.pipe(P(pts, false), wd, TUBE, 0.06, 0.22, 3);
    tube([[-20, 960], [40, 940], [120, 900], [150, 860], [180, 830], [230, 800], [300, 790]], 46);
    tube([[0, 610], [20, 650], [40, 690], [70, 700]], 30);
    tube([[300, 650], [360, 648], [420, 648], [480, 650], [520, 660], [525, 700], [500, 730], [420, 760], [320, 790], [250, 806]], 30);
    tube([[520, 748], [580, 748], [640, 740], [700, 712], [740, 700]], 34);
    tube([[580, 712], [600, 700], [640, 690], [680, 680]], 26);
    tube([[0, 1010], [100, 1000], [200, 1012]], 40);
    tube([[290, 985], [360, 985], [420, 1000]], 40);
    tube([[540, 970], [600, 975], [640, 995]], 30);
    keep();

    // ── striped ground (front-left) and the big zebra disc ──
    const ZG = P([[-10, 920], [60, 890], [160, 900], [330, 940], [420, 960], [420, 1034], [-10, 1034]], true, false);
    R.flat(ZG, zGround, 0.04, 2);
    tube([[-20, 960], [30, 948], [90, 935]], 46);
    const DISC = P([[165, 860], [180, 810], [240, 780], [330, 765], [430, 762], [520, 772], [570, 790], [580, 830], [560, 900], [520, 950], [440, 965], [330, 960], [240, 940], [185, 905]]);
    soft(x => { x.fillStyle = 'rgba(30,10,0,0.6)'; x.fill(ellipseP(400, 960, 220, 20, 0)); }, 10, 1);
    R.dome(DISC, zDisc, 0.06, 0.14, 40, 2);
    tube([[0, 1010], [100, 1000], [200, 1012]], 40);
    tube([[290, 985], [360, 985], [420, 1000]], 40);
    keep();

    // ── gold chrome pins ──
    const goldG = (x0, x1) => lin(x0, 0, x1, 0, [[0, '#2a1204'], [0.12, '#7a3a0c'], [0.24, '#f0b050'], [0.32, '#fff0b0'], [0.42, '#c06a18'], [0.55, '#3a1a06'], [0.7, '#9a5418'], [0.84, '#f0b050'], [0.92, '#ffe0a0'], [1, '#4a2208']]);
    const pin = (x, prof, top, capF) => {
      const L = [], Rr = [];
      for (const [y, w] of prof) { L.push([x - w, y]); Rr.push([x + w, y]); }
      const path = P([...L, ...Rr.reverse()]);
      const mx = Math.max(...prof.map(p => p[1]));
      soft(z => { z.fillStyle = 'rgba(120,60,10,0.55)'; z.fill(ellipseP(x + mx * 1.2, prof[prof.length - 1][0], mx * 1.6, 16, 0)); }, 8, 1);
      R.dome(path, null, 0.12, 0.16, mx * 0.5, 4);
      clipA(path, () => { for (let k = 0; k < prof.length - 1; k++) { const [y0, w0] = prof[k], [y1, w1] = prof[k + 1];
        for (let y = y0; y < y1; y += 2) { const w = w0 + (w1 - w0) * (y - y0) / (y1 - y0) + 1; a.fillStyle = goldG(x - w, x + w); a.fillRect(x - w - 1, y, 2 * w + 2, 2.6); } } });
      capF();
    };
    pin(608, [[590, 10], [640, 12], [700, 14], [760, 19], [800, 26], [830, 34], [852, 40], [858, 30]], 0, () =>
      R.dome(P([[592, 600], [592, 568], [600, 555], [616, 555], [624, 568], [624, 600]]), lin(592, 0, 624, 0, [[0, '#3a2a30'], [0.4, '#7a6a72'], [1, '#2a1c22']]), 0.3, 0.08, 10, 6));
    pin(543, [[620, 10], [680, 12], [740, 15], [790, 21], [840, 33], [880, 50], [892, 40]], 0, () =>
      R.dome(P([[527, 630], [527, 596], [535, 584], [551, 584], [559, 596], [559, 630]]), lin(527, 0, 559, 0, [[0, '#3a2a30'], [0.4, '#7a6a72'], [1, '#2a1c22']]), 0.3, 0.08, 10, 6));
    pin(450, [[690, 12], [740, 13], [800, 16], [850, 22], [900, 32], [935, 44], [955, 40]], 0, () => {
      R.dome(ellipseP(450, 672, 45, 33, 0), lin(0, 640, 0, 705, [[0, '#f0e2d0'], [0.4, '#e6d4c0'], [0.5, '#4a3438'], [1, '#2a1a1e']]), 0.3, 0.1, 18, 6);
      R.dome(ellipseP(450, 650, 22, 8, 0), '#4a3438', 0.4, 0.02, 4, 6);
    });
    keep();

    // ── gold eggs, spiky ball, white eggs, chrome balls (right) ──
    const goldR = (x, y, rx, ry) => R.dome(ellipseP(x, y, rx, ry, 0), rad(x - rx * 0.3, y - ry * 0.4, Math.max(rx, ry) * 1.2, [[0, '#fff4c0'], [0.2, '#ffc850'], [0.5, '#c87a18'], [0.8, '#f0a030'], [1, '#6a3408']]), 0.1, 0.2, Math.min(rx, ry) * 0.9, 4);
    const white = (x, y, rx, ry) => { soft(z => { z.fillStyle = 'rgba(140,70,20,0.5)'; z.fill(ellipseP(x + rx * 0.4, y + ry * 0.8, rx, ry * 0.35, 0)); }, 8, 1);
      R.dome(ellipseP(x, y, rx, ry, 0), rad(x - rx * 0.2, y - ry * 0.4, Math.max(rx, ry) * 1.3, [[0, '#ffffff'], [0.6, '#f0ecec'], [1, '#c8b8b0']]), 0.1, 0.22, Math.min(rx, ry) * 0.9, 2); };
    white(668, 632, 28, 20); white(712, 630, 22, 18); white(605, 628, 30, 22);
    goldR(690, 650, 38, 28); goldR(705, 610, 20, 16);
    R.dome(circleP(650, 700, 32), '#5a3a2c', 0.1, 0.14, 20, 3);
    { const q = rng(9); for (let i = 0; i < 60; i++) { const an = q() * 6.283, rr = q() * 30; F(circleP(650 + Math.cos(an) * rr, 700 + Math.sin(an) * rr, 1.6), '#2a1810'); } }
    goldR(625, 708, 42, 26);
    chrome(720, 800, 28); chrome(367, 907, 38);
    white(660, 855, 62, 48);
    goldR(692, 905, 50, 52);
    white(555, 930, 54, 46);
    // 8-ball egg in front
    R.dome(ellipseP(476, 990, 74, 52, 0), lin(0, 940, 0, 1040, [[0, '#ece0d4'], [0.35, '#e0d0c4'], [0.5, '#3a2a2c'], [1, '#1a1012']]), 0.12, 0.2, 40, 6);
    R.dome(ellipseP(470, 956, 30, 10, 0), '#2a1c1e', 0.3, 0.02, 4, 6);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.9, spec: 0.5, shin: 25, wrap: 0.5, ao: 0.5, grain: 0.15, emis: 0.18 }),                    // 1 leather / satin
        E.mat({ dif: 0.85, spec: 1.2, shin: 80, wrap: 0.5, ao: 0.4, coat: 0.15, emis: 0.18 }),                    // 2 glossy enamel
        E.mat({ dif: 0.85, spec: 0.9, shin: 60, wrap: 0.6, ao: 0.4, coat: 0.15, emis: 0.2 }),                     // 3 pale plastic tubes / cacti
        E.mat({ dif: 0.35, metal: 0.1, spec: 1.6, shin: 90, wrap: 0.3, ao: 0.2, emis: 0.72 }),                     // 4 gold chrome
        E.mat({ dif: 0.5, metal: 0.2, spec: 1.8, shin: 120, wrap: 0.3, ao: 0.3, emis: 0.35 }),                    // 5 chrome balls
        E.mat({ dif: 0.85, spec: 1.4, shin: 90, wrap: 0.4, ao: 0.4, coat: 0.2, emis: 0.12 })                      // 6 glossy caps
      ],
      light: [-0.5, 0.55, 0.68], lc: [1.0, 0.96, 0.9], amb: [0.36, 0.36, 0.4],
      envTop: [0.5, 0.7, 1.0], envHor: [0.95, 0.8, 0.6], envBot: [0.3, 0.2, 0.12], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.1, 0.12, 0.16], rimD: [0, 1, 0], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [6, 5, 0.4, 7]
    });
    E.bloom(0.06, 8);
    E.grain(0.03, 77);
  }
});
