'use strict';
// g124 — "Coral capsule still life": a yellow-framed card — wavy zebra field, a grey paint tin with a brush,
// a gold-flecked white capsule, white coral round a glowing red bar and a black-yellow feather, a pointing hand on graph paper.
REC.register('g124', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024;
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const speck = (path, n, seed, col, rmax = 1.4, box = [0, 0, W, H], al = 0.5) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = al + r() * (1 - al); a.beginPath(); a.arc(box[0] + r() * (box[2] - box[0]), box[1] + r() * (box[3] - box[1]), 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });
    const poly = pts => P(pts, true, false);
    const all = rrect(-10, -10, W + 20, H + 20, 0);
    const T = (cx, cy, rot) => pts => pts.map(([u, v]) => [cx + u * Math.cos(rot) - v * Math.sin(rot), cy + u * Math.sin(rot) + v * Math.cos(rot)]);

    // ── white card with tinted corners ──
    R.flat(all, '#ffffff', 0, 0);
    soft(x => { x.fillStyle = '#ead888'; x.fill(circleP(0, 0, 70)); x.fillStyle = '#98a8bc'; x.fill(circleP(726, 0, 90)); }, 40, 0.9);
    // card interior (scalloped corners)
    const X0 = 45, Y0 = 52, X1 = 680, Y1 = 972, CR = 30;
    const card = new Path2D();
    card.moveTo(X0 + CR, Y0); card.lineTo(X1 - CR, Y0); card.arc(X1, Y0, CR, Math.PI, Math.PI / 2, true); card.lineTo(X1, Y1 - CR);
    card.arc(X1, Y1, CR, -Math.PI / 2, Math.PI, true); card.lineTo(X0 + CR, Y1); card.arc(X0, Y1, CR, 0, -Math.PI / 2, true); card.lineTo(X0, Y0 + CR);
    card.arc(X0, Y0, CR, Math.PI / 2, 0, true); card.closePath();
    R.flat(card, lin(560, 100, 640, 900, [[0, '#f6f7f8'], [0.5, '#d8d8dc'], [1, '#b8b8c0']]), 0.01, 0);

    // ── wavy zebra field (top-left) ──
    const zone = poly([[X0, Y0], [420, Y0], [420, 200], [380, 240], [330, 330], [300, 480], [180, 520], [150, 760], [X0, 760]]);
    const zeb = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float ang = mix(0.42, 1.05, smoothstep(120., 400., p.x - 0.4 * (300. - p.y)));
      vec2 n = vec2(-sin(ang), cos(ang)), t = vec2(cos(ang), sin(ang));
      float ph = dot(p, n) / 21. + 0.32 * sin(dot(p, t) / 26. + p.y * 0.01) + 0.6 * sin(p.x * 0.006 + p.y * 0.012);
      float s = fract(ph);
      float b = smoothstep(0.46, 0.52, s) * (1. - smoothstep(0.95, 1.0, s));
      return mix(vec3(.99), vec3(.02), b); }`);
    R.flat(zone, '#ffffff', 0.02, 0);
    clipA(zone, () => img(zeb));
    // black starry strip
    const strip = poly([[200, Y0], [300, Y0], [300, 205], [200, 205]]);
    R.flat(strip, '#030305', 0.03, 0);
    { const r = rng(4); for (let i = 0; i < 26; i++) R.flat(circleP(204 + r() * 92, Y0 + r() * 150, 1 + r() * r() * 9), r() < 0.25 ? '#2040e8' : '#f8f8f8', 0.035, 0); }
    R.flat(circleP(220, 80, 9), '#2040e8', 0.04, 0); R.flat(circleP(270, 98, 9), '#ffffff', 0.04, 0); R.flat(circleP(246, 186, 11), '#ffffff', 0.04, 0);

    // ── graph paper + hand (top-right) ──
    const paper = P([[440, 120], [470, 60], [520, 52], [600, 70], [670, 90], [668, 200], [672, 300], [640, 350], [590, 356], [540, 340], [480, 360], [430, 340], [410, 280], [420, 200]], true, true);
    R.flat(paper, '#a8a4aa', 0.03, 0);
    const grid = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float g1 = max(smoothstep(0.42, 0.48, abs(fract(p.x / 9.) - .5)), smoothstep(0.42, 0.48, abs(fract(p.y / 9.) - .5)));
      float g2 = max(smoothstep(0.45, 0.49, abs(fract(p.x / 27.) - .5)), smoothstep(0.45, 0.49, abs(fract(p.y / 27.) - .5)));
      vec3 c = vec3(.70,.68,.71) * (0.9 + 0.14 * fbm(p * 0.03));
      c = mix(c, vec3(.42,.40,.44), g1 * 0.6); c = mix(c, vec3(.2,.2,.22), g2 * 0.6);
      float ink = smoothstep(0.66, 0.7, fbm(p * 0.06 + 4.)) * step(0.6, vnoise(p * 0.35));
      return mix(c, vec3(.02), ink); }`);
    clipA(paper, () => img(grid));
    R.dome(circleP(578, 275, 14), '#f0f0f2', 0.05, 0.02, 4, 1);
    const hand = P([[680, 82], [640, 76], [600, 86], [560, 96], [520, 104], [492, 116], [470, 140], [452, 168], [446, 200], [448, 240], [462, 242], [470, 205], [484, 182],
      [500, 196], [522, 196], [552, 170], [584, 160], [622, 150], [660, 148], [680, 152]], true, true);
    R.dome(hand, lin(460, 100, 660, 200, [[0, '#e8e8ea'], [1, '#f8f8fa']]), 0.06, 0.08, 18, 1);
    R.flat(poly([[640, 116], [680, 112], [680, 240], [660, 236]]), '#9a9aa0', 0.05, 0);

    // ── orange-red card ──
    R.flat(poly([[478, 410], [640, 418], [636, 730], [468, 692]]), '#fd5204', 0.06, 1);
    R.dome(circleP(551, 461, 8), '#ffffff', 0.07, 0.02, 3, 1);
    a.save(); a.fillStyle = '#f8f8f8'; a.font = '14px serif'; a.fillText('R', 585, 525); a.fillText('B', 566, 448); a.restore();

    // ── dark floor gradient + glowing corner (bottom-right), red-magenta floor ──
    R.flat(poly([[300, 700], [680, 640], [680, 972], [300, 972]]), lin(420, 760, 680, 972, [[0, '#1c1618'], [0.45, '#4a4652'], [0.75, '#8a88a8'], [1, '#f0f0f8']]), 0.02, 0);
    soft(x => { x.fillStyle = '#fafaff'; x.fill(P([[690, 980], [600, 900], [640, 880], [690, 900]])); }, 18, 0.9);
    R.flat(poly([[X0, 862], [300, 862], [470, 900], [480, 972], [X0, 972]]), lin(X0, 0, 480, 0, [[0, '#fc3418'], [0.4, '#fc3060'], [0.65, '#d030b0'], [0.85, '#9040c0'], [1, '#6040a0']]), 0.02, 0);
    soft(x => { x.fillStyle = '#060406'; x.fill(P([[160, 760], [300, 740], [460, 760], [600, 820], [560, 900], [420, 930], [300, 920], [190, 900]], true, true)); }, 22, 0.95);
    // blue striped square + black zigzag
    const bsq = poly([[X0, 760], [158, 760], [158, 930], [X0, 930]]);
    R.flat(bsq, '#0e10a0', 0.03, 0);
    clipA(bsq, () => { const r = rng(6); a.strokeStyle = '#2838e0'; a.lineWidth = 1.6; for (let y = 784; y < 930; y += 5) { a.beginPath(); a.moveTo(X0, y + r() * 2); a.lineTo(160, y + r() * 3); a.stroke(); } });
    { const z = [[X0, 752]]; for (let i = 0; i <= 8; i++) z.push([X0 + i * 14, 768 + (i % 2 ? -12 : 6)]); z.push([158, 758], [158, 786], [X0, 786]);
      R.flat(poly(z), '#060608', 0.035, 0); }

    // ── white coral: a branching network of thin tubes ──
    const coral = (pts, wd) => R.pipe(P(pts, false), wd, '#eef0f0', 0.2, 0.1, 2);
    { const r = rng(12);
      const grow = (x, y, ang, len, wd, depth) => {
        const pts = [[x, y]]; let cx = x, cy = y, a0 = ang;
        for (let i = 0; i < 5; i++) { a0 += (r() - 0.5) * 0.8; cx += Math.cos(a0) * len / 5; cy += Math.sin(a0) * len / 5; pts.push([cx, cy]); }
        coral(pts, wd);
        if (depth > 0) for (let k = 0; k < 2; k++) { const j = 1 + Math.floor(r() * 4); grow(pts[j][0], pts[j][1], a0 + (k ? -1 : 1) * (0.7 + r() * 0.5), len * 0.72, Math.max(5, wd * 0.9), depth - 1); }
      };
      for (const [x, y, ang, len] of [[450, 330, -2.0, 120], [450, 330, -1.0, 110], [420, 300, -2.6, 100], [470, 300, -0.5, 110], [480, 380, 0.1, 100], [500, 450, 0.3, 90],
        [480, 520, 0.2, 90], [470, 600, 0.5, 90], [460, 660, 0.9, 80], [350, 330, -2.2, 90], [340, 400, 2.9, 70], [380, 260, -1.6, 90], [300, 300, -2.8, 60],
        [140, 620, 2.9, 80], [150, 660, 2.4, 80], [170, 820, 2.3, 70], [200, 860, 1.9, 60], [450, 440, 1.6, 70], [540, 380, -0.8, 80]])
        grow(x, y, ang, len, 8, 3);
    }
    // ── glowing red bar wrapped in coral chain ──
    { const f = T(358, 655, -0.29);
      const bar = P(f([[-38, -200], [38, -200], [38, 200], [-38, 200]]), true, false);
      R.dome(bar, lin(...f([[-38, 0]])[0], ...f([[38, 0]])[0], [[0, '#d82010'], [0.5, '#fa4a20'], [1, '#c81808']]), 0.24, 0.12, 20, 6);
      const r = rng(13);
      for (let i = 0; i < 150; i++) { const u = (r() < 0.5 ? -1 : 1) * (30 + r() * 26), v = -200 + r() * 400; const [[x, y]] = f([[u, v]]);
        R.pipe(ellipseP(x, y, 7, 4.5, r() * 3), 3.6, '#f2dcd8', 0.32, 0.04, 2); }
      for (const [x, y, rr] of [[338, 557, 13], [355, 590, 14], [394, 682, 15], [410, 710, 10], [384, 604, 6]]) R.bead(x, y, rr, '#fff8a0', 0.36, 0.06, 7);
    }
    // ── feather ──
    const fcl = [[398, 352], [404, 420], [410, 500], [418, 580], [428, 660], [442, 750]];
    const fth = P(lock(fcl, 96, 6, 0.45));
    R.dome(fth, '#ecece8', 0.3, 0.06, 14, 1);
    clipA(fth, () => {
      a.fillStyle = '#b0b0ae'; a.fill(poly([[420, 470], [470, 450], [480, 760], [434, 760]]));
      const yl = [[350, 450]]; for (let i = 0; i <= 13; i++) yl.push([354 + (i % 2) * 20 + i * 2.2, 460 + i * 13]); yl.push([416, 640], [408, 450]);
      a.fillStyle = '#f6e800'; a.fill(poly(yl));
      a.strokeStyle = '#666'; a.lineWidth = 1.2; a.stroke(P(fcl, false));
    });
    { const tuft = []; const r = rng(17); for (let i = 0; i < 40; i++) { const t = i / 40 * 6.283, rr = (i % 2 ? 44 : 50) + r() * 6; tuft.push([398 + Math.cos(t) * rr * 0.8, 418 + Math.sin(t) * rr * 1.25 * (Math.sin(t) > 0 ? 0.8 : 1)]); }
      R.dome(P(tuft, true, true), '#080808', 0.32, 0.06, 12, 1); }
    // ── grey paint tin with a brush ──
    R.pipe(P([[96, 104], [130, 150], [168, 198]], false), 22, '#f4f4f4', 0.2, 0.1, 1);
    R.pipe(P([[150, 196], [176, 232]], false), 8, '#d0a868', 0.3, 0.04, 1);
    { const body = P([[108, 232], [302, 232], [302, 432], [290, 452], [250, 466], [205, 470], [160, 466], [120, 452], [108, 432]], true, true);
      R.dome(body, lin(108, 0, 302, 0, [[0, '#5a5e62'], [0.3, '#8a8e92'], [0.6, '#70747a'], [1, '#4a4e52']]), 0.22, 0.14, 50, 3);
      clipA(body, () => {
        a.fillStyle = '#fd5004'; a.fill(poly([[100, 382], [310, 352], [310, 418], [100, 446]]));
        a.fillStyle = '#ffffff'; a.fill(poly([[100, 446], [310, 418], [310, 424], [100, 452]]));
        a.fillStyle = '#f8f8f8'; a.fill(poly([[162, 250], [184, 250], [184, 470], [162, 470]]));
        const r = rng(14); for (let i = 0; i < 26; i++) a.fill(circleP(112 + r() * 186, 260 + r() * 190, 2 + r() * 3.5));
        a.fillStyle = '#111'; a.font = 'bold 12px sans-serif'; a.fillText('ENTRP BOW', 192, 395); a.fillText('INT CASING', 118, 384);
        a.fillStyle = '#fef0e0'; a.font = '12px sans-serif'; a.fillText('buse fools faxin', 190, 430);
      });
      R.dome(ellipseP(205, 232, 98, 34, 0), '#7a7e82', 0.36, 0.06, 10, 3);
      R.dome(ellipseP(205, 234, 84, 26, 0), '#f6f6f6', 0.34, 0.04, 12, 1);
    }

    // ── gold-flecked capsule ──
    { const f = T(260, 692, -0.26);
      const capP = P(f([[-88, -120], [-78, -170], [-44, -194], [20, -198], [70, -190], [88, -160], [88, 160], [74, 190], [30, 198], [-40, 196], [-80, 180], [-88, 130]]), true, true);
      R.dome(capP, lin(...f([[-88, 0]])[0], ...f([[88, 0]])[0], [[0, '#c4c8c8'], [0.3, '#f0f2f0'], [0.7, '#e4e8e6'], [1, '#b8bcbc']]), 0.26, 0.26, 70, 4);
      clipA(capP, () => {
        a.fillStyle = '#fa4a10'; a.fill(poly(f([[-130, 158], [130, 140], [130, 260], [-130, 260]])));
        const r = rng(15); a.fillStyle = '#9c7428';
        for (let i = 0; i < 70; i++) { const [[x, y]] = f([[-80 + r() * 160, -180 + r() * 330]]); a.fill(ellipseP(x, y, 4 + r() * 5, 2.4 + r() * 2.5, -0.26 + (r() - 0.5) * 0.8)); }
      });
    }
    // ── grey speckled plate (edge-on) ──
    { R.flat(P([[400, 760], [500, 690], [580, 630], [640, 590], [630, 650], [560, 720], [480, 780]], true, true), '#c02010', 0.3, 1);
      const back = P([[318, 896], [380, 850], [460, 790], [540, 724], [604, 660], [636, 612], [640, 640], [610, 700], [540, 770], [460, 830], [380, 880]], true, true);
      R.dome(back, '#f4f4f2', 0.34, 0.06, 12, 1);
      const plate = P([[300, 882], [340, 830], [420, 760], [500, 694], [570, 634], [618, 586], [632, 570], [630, 600], [604, 650], [544, 716], [470, 778], [396, 836], [336, 874]], true, true);
      R.dome(plate, lin(400, 740, 460, 830, [[0, '#ececea'], [1, '#b0b0ae']]), 0.4, 0.08, 18, 1);
      speck(plate, 1100, 16, '#4a4a4a', 0.7, [300, 560, 640, 890]);
    }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.3, shin: 24, wrap: 0.6, ao: 0.3 }),                                      // 1 matte white
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.5, ao: 0.6, coat: 0.1 }),                           // 2 coral
        E.mat({ dif: 1, spec: 0.8, shin: 40, wrap: 0.3, coat: 0.15, ao: 0.4 }),                          // 3 painted tin
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.4, coat: 0.25, ao: 0.3 }),                          // 4 capsule
        E.mat({}),
        E.mat({ dif: 0.8, spec: 1.0, shin: 50, wrap: 0.3, emis: 0.35, coat: 0.2 }),                      // 6 glowing red
        E.mat({ dif: 0.2, emis: 1.0, spec: 0.5, shin: 30 })                                               // 7 lamps
      ],
      light: [-0.4, 0.55, 0.73], lc: [0.6, 0.6, 0.6], amb: [0.55, 0.55, 0.56],
      envTop: [1.2, 1.2, 1.2], envHor: [0.6, 0.6, 0.62], envBot: [0.15, 0.15, 0.17], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.2, 0.2, 0.25], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 100], shadow: [-6, 9, 0.6, 7]
    });
    // glow of the lamps + yellow frame line
    const o = E.out;
    for (const [x, y, r] of [[338, 557, 34], [355, 590, 34], [394, 682, 36], [410, 710, 26]]) {
      const g = o.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, 'rgba(255,250,170,0.9)'); g.addColorStop(0.4, 'rgba(255,200,60,0.5)'); g.addColorStop(1, 'rgba(255,80,20,0)');
      o.fillStyle = g; o.fillRect(x - r, y - r, 2 * r, 2 * r);
    }
    o.save(); o.lineWidth = 3.5; o.strokeStyle = '#f0f040'; o.stroke(card); o.restore();
    E.grain(0.03, 124);
  }
});
