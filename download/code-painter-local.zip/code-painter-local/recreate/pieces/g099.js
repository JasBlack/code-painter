'use strict';
// g099 — "Figure-eight alley": an ink-lined cartoon back alley — a cream figure-eight pipe sculpture with a smiling
// ball on a screw and a dripping urn, a zebra-striped drape, dark green brick, a tunnel, vintage cars and a bone on the dash.
REC.register('g099', {
  w: 726, h: 1024,
  draw(E) {
    const o = E.out, S = E.S;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.strokeStyle = c; o.lineWidth = wd; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const ink = (path, c, wd = 3) => { fill(path, c); stroke(path, '#0a0a0a', wd); };
    const clip = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const poly = pts => P(pts, true, false);
    const sm = pts => P(pts, true, true);
    const open = pts => P(pts, false, true);
    const K = '#0a0a0a', CR = '#f6f2de', GR = '#c4beb8';
    const r = rng(99);

    // ── walls ──
    fill(rrect(-10, -10, 746, 1044, 0), '#303c30');
    // dark green brick mottling
    clip(poly([[250, -10], [680, -10], [680, 720], [250, 720]]), () => {
      for (let y = 0; y < 720; y += 26) for (let x = 250 + (y / 26 % 2) * 30; x < 690; x += 60) {
        if (r() < 0.75) fill(sm(blob(x + r() * 20, y + r() * 8, 22 + r() * 16, 8 + r() * 4, Math.floor(r() * 1e4), 10, 0.3)), '#1c281c');
      }
    });
    // grey stone wall + dark brick lines
    const stone = poly([[30, -10], [250, -10], [250, 560], [30, 560]]);
    fill(stone, '#8c8c80');
    clip(stone, () => {
      for (let y = 20; y < 560; y += 42) { stroke(open([[30, y], [90, y + 2], [160, y - 1], [250, y + 1]]), '#5a5a50', 3 + r() * 3); }
      fill(poly([[186, -10], [238, -10], [238, 560], [186, 560]]), '#6a6660');
      for (let y = 10; y < 560; y += 42) fill(rrect(196, y, 34, 30, 3), '#5a5752');
      for (const [x, y, rx, ry] of [[204, 100, 8, 10], [190, 128, 7, 9], [186, 182, 6, 10], [206, 190, 6, 9], [212, 352, 8, 10], [196, 404, 6, 9], [212, 410, 6, 8]]) ink(ellipseP(x, y, rx, ry, 0), '#7c7a72', 2);
    });
    fill(poly([[238, -10], [264, -10], [264, 460], [238, 460]]), K);
    for (let y = 30; y < 460; y += 60) ink(rrect(240, y, 18, 22, 2), '#8a8a84', 2);
    // left black speckled strip
    fill(poly([[-10, -10], [36, -10], [40, 560], [-10, 560]]), '#060607');
    for (let i = 0; i < 260; i++) { const y = r() * 560, x = r() * 40 * (0.4 + 0.6 * r()); fill(circleP(x, y, 0.6 + r() * 2.2), '#e8e6dc'); }
    for (const pts of [[[0, 160], [16, 150], [30, 186], [22, 224], [28, 250], [6, 262], [0, 250]], [[0, 336], [18, 330], [30, 360], [22, 400], [28, 430], [10, 446], [0, 440]], [[22, 470], [32, 460], [36, 500], [26, 520]]])
      fill(sm(pts), '#ece8d8');
    // beige brick wall (right)
    const brick = poly([[676, -10], [736, -10], [736, 720], [676, 720]]);
    fill(brick, '#dfc7af');
    clip(brick, () => {
      for (let y = 0, i = 0; y < 720; y += 33, i++) {
        stroke(open([[676, y], [736, y]]), '#4a4038', 3);
        for (let x = 676 + (i % 2) * 22; x < 736; x += 44) stroke(open([[x, y], [x, y + 33]]), '#4a4038', 3);
      }
    });
    stroke(open([[676, -10], [676, 720]]), K, 4);

    // ── pipe, rope, lamps, sign ──
    ink(rrect(262, 84, 414, 16, 6), '#8a8a86', 3);
    for (const x of [276, 466, 582]) ink(rrect(x - 8, 78, 16, 28, 3), '#9a9a94', 2.5);
    o.setLineDash([6, 4]);
    stroke(open([[470, 96], [462, 150], [458, 220], [460, 280], [462, 324]]), '#2a2a2a', 7);
    stroke(open([[480, 120], [540, 126], [600, 110], [650, 84], [676, 64]]), '#2a2a2a', 7);
    o.setLineDash([]);
    stroke(open([[466, 96], [480, 120]]), '#2a2a2a', 6);
    for (const x of [312, 522]) {
      ink(rrect(x - 26, 14, 52, 38, 6), '#8a8a84', 3);
      for (let k = 0; k < 3; k++) stroke(open([[x - 26, 22 + k * 10], [x + 26, 22 + k * 10]]), '#4a4a46', 2);
      ink(rrect(x - 10, -10, 20, 24, 2), '#6a6a66', 2);
    }
    ink(rrect(514, 156, 164, 72, 2), '#5a5a58', 3);
    fill(rrect(524, 164, 146, 56, 1), '#fdc808');
    for (const [x, y] of [[422, 48], [366, 128], [360, 250], [322, 382], [594, 350], [594, 528]]) fill(circleP(x, y, 3), '#e8e8e0');

    // ── tunnel arch ──
    ink(sm([[484, 560], [488, 470], [520, 410], [590, 384], [650, 396], [680, 420], [680, 560]]), '#8a8a80', 3);
    fill(sm([[500, 570], [504, 480], [530, 432], [592, 410], [652, 420], [680, 440], [680, 570]]), '#020204');
    for (let k = 0; k < 9; k++) { const t = 0.15 + k * 0.1, ang = Math.PI * (1 + t); stroke(open([[590 + Math.cos(ang) * 92, 488 + Math.sin(ang) * 80], [590 + Math.cos(ang) * 104, 488 + Math.sin(ang) * 100]]), K, 2); }

    // ── grey speaker box ──
    ink(poly([[190, 438], [300, 420], [342, 440], [340, 560], [196, 560]]), '#8a8484', 3);
    ink(ellipseP(242, 476, 26, 24, 0), '#6a6464', 3);
    ink(ellipseP(242, 476, 14, 13, 0), '#3a3434', 2);

    // ── zebra drape (left) ──
    const drape = sm([[34, -10], [78, -10], [96, 100], [120, 200], [150, 300], [180, 400], [222, 490], [252, 560], [244, 650], [200, 640], [120, 600], [50, 560], [40, 400], [30, 200]]);
    const zeb = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = clamp((p.x - 120.) / 100., -0.9, 1.4), q = clamp((p.y - 300.) / 250., -1.25, 1.4);
      float ph = 3.3157 + 3.6847 * u - 0.4068 * q - 0.1841 * u * u + 0.3399 * u * q - 1.0978 * q * q + 0.9754 * u * u * q - 1.1982 * u * q * q + 0.2462 * u * u * u;
      ph += 0.12 * sin(p.y * 0.035 + p.x * 0.01);
      float v = sin(ph * 6.2832);
      return mix(vec3(.03), vec3(.97, .95, .87), smoothstep(.1, .3, v)); }`));
    fill(drape, zeb);
    stroke(drape, K, 3);
    fill(sm([[200, 560], [240, 540], [256, 600], [240, 650], [210, 640]]), 'rgba(196,190,184,0.85)');

    // ── grey tyre behind the sculpture ──
    ink(ellipseP(300, 650, 42, 60, 0), '#3a3838', 3);
    ink(ellipseP(306, 650, 26, 40, 0), '#7a7676', 2);
    ink(ellipseP(308, 650, 10, 16, 0), '#2a2828', 2);

    // ── vintage white car (right, behind) ──
    ink(sm([[470, 640], [520, 610], [560, 586], [620, 578], [670, 590], [680, 640], [676, 720], [640, 740], [480, 740], [462, 700]]), '#ece8dc', 3);
    for (let k = 0; k < 6; k++) ink(rrect(540 + k * 22, 576 - k * 2, 14, 30, 3), '#f4f2ea', 2);
    ink(rrect(478, 650, 70, 70, 6), '#d8d4c8', 3);
    for (let k = 0; k < 6; k++) stroke(open([[482, 662 + k * 10], [544, 662 + k * 10]]), K, 2);
    ink(ellipseP(640, 716, 30, 40, 0), '#161616', 3);
    ink(ellipseP(640, 716, 14, 20, 0), '#8a8a8a', 2);
    // teal car (right edge)
    ink(sm([[656, 760], [680, 700], [736, 690], [736, 840], [660, 830]]), '#40c0b0', 3);
    ink(sm([[690, 744], [712, 730], [726, 740], [726, 790], [694, 792]]), '#e8f0e0', 2);
    ink(sm([[700, 752], [716, 746], [722, 784], [698, 786]]), '#f4060b', 2);
    fill(circleP(709, 744, 8), '#2a1a10');

    // ── floor ──
    fill(poly([[300, 690], [480, 700], [736, 700], [736, 1034], [560, 1034], [300, 780]]), '#0a0a0a');
    fill(poly([[430, 740], [736, 700], [736, 1034], [560, 1034], [400, 860], [380, 800]]), '#6a6262');
    fill(sm([[400, 740], [520, 760], [600, 820], [620, 870], [560, 900], [480, 880], [420, 820]]), '#030305');
    fill(sm([[560, 740], [640, 750], [700, 800], [736, 840], [736, 880], [660, 860], [600, 800]]), '#1a1616');
    for (let i = 0; i < 26; i++) { const x = 520 + r() * 220, y = 760 + r() * 260; fill(sm(blob(x, y, 6 + r() * 16, 3 + r() * 6, i * 7, 10, 0.4)), '#f4f2ea'); }
    // lollipop post
    stroke(open([[610, 920], [612, 970]]), K, 7); stroke(open([[610, 920], [612, 970]]), '#e8e4dc', 3);
    ink(circleP(610, 912, 14), '#f4f2ea', 3);

    // ── figure-eight tube ──
    const loop = [[405, 478], [470, 450], [515, 390], [526, 320], [506, 240], [452, 192], [390, 176], [326, 190], [276, 240], [254, 320], [270, 400], [320, 455], [405, 478],
      [480, 520], [545, 580], [578, 650], [570, 730], [530, 790], [460, 828], [390, 834], [320, 806], [262, 744], [238, 672], [255, 600], [300, 548], [350, 512], [405, 478]];
    const tube = (pts, closed) => {
      const path = P(pts, closed, true);
      stroke(path, K, 54);
      stroke(path, GR, 47);
      o.save(); o.translate(-6, -5); stroke(path, CR, 32); o.restore();
      return path;
    };
    tube(loop, true);
    // front crossing segment
    tube([[262, 352], [272, 410], [320, 458], [405, 482], [482, 522], [546, 584], [576, 640]], false);
    // segment rings
    const seg = (x, y, ang) => { const dx = Math.cos(ang) * 26, dy = Math.sin(ang) * 26; for (const s of [-5, 5]) stroke(open([[x - dx + s * Math.sin(ang), y - dy - s * Math.cos(ang)], [x + dx + s * Math.sin(ang), y + dy - s * Math.cos(ang)]]), K, 2.5); };
    for (const [x, y, an] of [[452, 192, 1.0], [326, 190, 2.2], [262, 350, 0.1], [520, 360, 3.1], [500, 252, 0.6], [440, 500, 2.6], [520, 562, 2.4], [574, 690, 0.0], [520, 798, 1.0], [390, 834, 1.57], [262, 744, 2.4], [252, 610, 0.3], [338, 466, 2.0]]) seg(x, y, an);

    // ── smiling ball on a screw ──
    ink(sm([[446, 284], [466, 276], [482, 290], [474, 306], [456, 304]]), CR, 3);
    ink(circleP(398, 300, 44), CR, 3);
    fill(ellipseP(386, 292, 4, 7, 0), K); fill(ellipseP(412, 292, 4, 7, 0), K);
    stroke(P([[384, 318], [398, 326], [414, 316]], false, true), K, 3);
    ink(ellipseP(398, 354, 42, 10, 0), CR, 3);
    for (let k = 0; k < 9; k++) ink(ellipseP(398, 372 + k * 11, 21, 7, 0.12), k % 2 ? '#dedad0' : CR, 2.5);
    ink(rrect(386, 470, 24, 90, 4), CR, 3);
    // urn
    ink(ellipseP(398, 568, 40, 9, 0), CR, 3);
    ink(ellipseP(398, 586, 34, 8, 0), CR, 3);
    const urn = sm([[352, 610], [398, 590], [446, 610], [472, 660], [466, 712], [436, 748], [360, 748], [330, 712], [326, 660]]);
    ink(urn, '#c8c2c4', 3);
    clip(urn, () => {
      const drip = [[320, 590]]; for (let x = 326; x <= 476; x += 10) drip.push([x, 660 + (x / 10 % 2 ? 20 + r() * 14 : 0)]);
      drip.push([480, 590]);
      fill(poly(drip), CR); stroke(open(drip.slice(1, -1)), K, 2);
    });
    ink(ellipseP(398, 752, 56, 12, 0), CR, 3);
    ink(ellipseP(398, 770, 52, 11, 0), '#dedad0', 3);
    stroke(open([[398, 782], [398, 830]]), K, 18); stroke(open([[398, 782], [398, 830]]), '#dedad0', 12);
    ink(ellipseP(378, 838, 18, 12, 0.4), CR, 3);

    // ── big cream car (foreground) ──
    const car = sm([[-10, 540], [60, 552], [130, 578], [190, 616], [240, 664], [290, 720], [330, 770], [380, 832], [440, 896], [510, 956], [580, 1000], [650, 1034], [-10, 1034]]);
    ink(car, CR, 3);
    fill(poly([[-10, 706], [120, 700], [244, 688], [258, 698], [120, 718], [-10, 742]]), K);
    // windshield frame + glass + dash
    ink(sm([[-10, 756], [150, 734], [272, 726], [318, 752], [344, 850], [334, 890], [200, 904], [-10, 916]]), CR, 3);
    const glass = sm([[-10, 772], [150, 756], [262, 744], [300, 768], [326, 850], [316, 878], [200, 890], [-10, 902]]);
    fill(glass, '#9c9890');
    clip(glass, () => {
      fill(poly([[-10, 740], [240, 740], [180, 810], [-10, 830]]), '#433c44');
      fill(poly([[-10, 836], [310, 820], [330, 890], [-10, 910]]), '#b07850');
      stroke(open([[160, 820], [262, 750]]), '#2a2a2a', 3);
    });
    stroke(glass, K, 3);
    // bone
    const bone = sm([[86, 818], [100, 806], [118, 814], [170, 812], [192, 802], [212, 814], [204, 836], [214, 852], [196, 866], [176, 852], [118, 856], [100, 870], [80, 860], [86, 840], [72, 828]]);
    ink(bone, '#f8f4e2', 3);
    // wiper + body lines
    stroke(open([[10, 900], [90, 890], [160, 884]]), K, 3);
    stroke(open([[-10, 920], [120, 900], [260, 890], [380, 900], [460, 940], [520, 1000], [540, 1034]]), K, 3);
    stroke(open([[-10, 560], [80, 572], [150, 600], [200, 640]]), K, 2);

    E.grain(0.035, 99);
  }
});
