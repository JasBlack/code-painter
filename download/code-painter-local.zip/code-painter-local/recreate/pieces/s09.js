'use strict';
// s09 — "Sticker medallion in the sun": a bronze medallion with a glossy orange
// tube-creature, on a zig-zag purple sticker and a black sticker full of lilac
// worms, lying on a teal leaf with yellow petals in hard sunlight.
REC.register('s09', {
  w: 1024, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h;
    const both = f => { a.save(); hx.save(); f(a); f(hx); };
    const restore = () => { a.restore(); hx.restore(); };
    // resample a closed smooth outline and wave it along its normal (sun-ray zig-zag)
    const wave = (pts, period, amp, phase = 0) => {
      const n = pts.length, dense = [];
      for (let i = 0; i < n; i++) {
        const p0 = pts[(i - 1 + n) % n], p1 = pts[i], p2 = pts[(i + 1) % n], p3 = pts[(i + 2) % n];
        for (let t = 0; t < 1; t += 0.05) {
          const t2 = t * t, t3 = t2 * t;
          const f = (a0, a1, a2, a3) => 0.5 * (2 * a1 + (-a0 + a2) * t + (2 * a0 - 5 * a1 + 4 * a2 - a3) * t2 + (-a0 + 3 * a1 - 3 * a2 + a3) * t3);
          dense.push([f(p0[0], p1[0], p2[0], p3[0]), f(p0[1], p1[1], p2[1], p3[1])]);
        }
      }
      const out = []; let s = 0;
      for (let i = 0; i < dense.length; i++) {
        const p = dense[i], q = dense[(i + 1) % dense.length], o = dense[(i - 1 + dense.length) % dense.length];
        const dx = q[0] - o[0], dy = q[1] - o[1], L = Math.hypot(dx, dy) || 1;
        const k = amp * Math.sin(s / period * Math.PI * 2 + phase);
        out.push([p[0] + dy / L * k, p[1] - dx / L * k]);
        s += Math.hypot(q[0] - p[0], q[1] - p[1]);
      }
      return out;
    };

    // ── background: dark corner, orange rim, yellow petal, teal leaf ──
    const bgc = E.fx(`

      vec3 fx(vec2 uv, vec2 px){
        vec2 q = vec2(px.x * 0.8 + px.y * 0.6, -px.x * 0.6 + px.y * 0.8);
        float n = fbm(q * vec2(0.006, 0.03) + vec2(3.1, 1.7)), m = fbm(px * 0.08), g = hash(px);
        vec3 teal = mix(vec3(0.22, 0.36, 0.30), vec3(0.32, 0.47, 0.39), smoothstep(0.3, 0.75, n));
        teal *= 0.85 + 0.15 * smoothstep(60.0, 260.0, px.y);
        // lighter mint toward the yellow petal and near the sticker top
        float lt = smoothstep(420.0, 80.0, px.x + 0.35 * px.y - 60.0);
        teal = mix(teal, vec3(0.46, 0.62, 0.52), 0.55 * lt);
        teal = mix(teal, vec3(0.52, 0.72, 0.60), 0.7 * smoothstep(170.0, 40.0, length(px - vec2(540.0, 170.0))));
        teal *= 0.9 + 0.18 * m + 0.14 * (g - 0.5);
        teal = mix(teal, vec3(0.56, 0.64, 0.46), 0.5 * smoothstep(200.0, 40.0, length(px - vec2(100.0, 700.0))));
        teal = mix(teal, vec3(0.55, 0.78, 0.66), 0.7 * smoothstep(160.0, 20.0, length(px - vec2(260.0, 1024.0))));
        return teal;
      }`);
    a.drawImage(bgc, 0, 0, 1024, 1024);
    hx.fillStyle = hc(0.0, 0); hx.fillRect(0, 0, 1024, 1024);
    // dark top-left corner fading to brown and orange down the left edge
    const cg = a.createLinearGradient(0, 0, 0, 1024);
    cg.addColorStop(0, '#0e0b0b'); cg.addColorStop(0.22, '#120d0a'); cg.addColorStop(0.35, '#3a2610'); cg.addColorStop(0.5, '#8a5a1c'); cg.addColorStop(0.75, '#e8a040'); cg.addColorStop(1, '#f5a443');
    R.flat(P([[-20, -20], [200, -20], [140, 60], [95, 150], [60, 250], [35, 360], [18, 480], [8, 600], [6, 760], [10, 900], [16, 1044], [-20, 1044]]), cg, 0.0, 0);
    // yellow petal band
    const yb = [[176, -20], [146, 50], [112, 100], [82, 150], [60, 200], [50, 250], [42, 300], [35, 350], [28, 400], [24, 450], [20, 500], [12, 560], [4, 640], [8, 760], [16, 870], [22, 1044], [240, 1044], [190, 994], [134, 960], [92, 910], [62, 850], [40, 810], [66, 750], [80, 690], [64, 630], [58, 560], [68, 500], [76, 450], [85, 400], [95, 350], [105, 300], [118, 250], [135, 200], [150, 150], [182, 100], [214, 50], [250, -20]];
    const ybg = a.createLinearGradient(0, 0, 200, 900);
    ybg.addColorStop(0, '#9a8c38'); ybg.addColorStop(0.3, '#c8b848'); ybg.addColorStop(1, '#f6e058');
    R.dome(P(yb), ybg, 0.01, 0.05, 20, 1);
    a.save(); a.clip(P(yb)); a.strokeStyle = 'rgba(70,56,14,0.75)'; a.lineWidth = 50; a.filter = 'blur(10px)'; a.stroke(P([[156, -20], [112, 80], [66, 180], [42, 280], [26, 380], [16, 470]], false)); a.restore();
    a.save(); a.clip(P(yb)); a.fillStyle = 'rgba(236,160,60,0.7)'; a.filter = 'blur(12px)'; a.fill(P([[-20, 480], [30, 520], [34, 1044], [-20, 1044]])); a.restore();
    // bottom-right yellow petals
    R.dome(P([[1044, 700], [940, 716], [880, 740], [864, 790], [882, 812], [900, 842], [884, 872], [904, 900], [944, 930], [938, 962], [960, 990], [980, 1044], [1044, 1044]]), '#e8d256', 0.01, 0.06, 30, 1);
    R.groove(P([[900, 858], [960, 870], [1030, 880]], false), 22, '#8a7a2a', 0.07, 0.04, 1, 0.8);
    a.save(); a.filter = 'blur(24px)'; a.fillStyle = 'rgba(196,222,168,0.85)'; a.fill(P([[820, 1060], [860, 950], [930, 940], [990, 1060]])); a.fill(P([[160, 1060], [200, 990], [300, 1000], [320, 1060]])); a.restore();
    a.save(); a.filter = 'blur(24px)'; a.fillStyle = 'rgba(30,45,35,0.5)'; a.fill(P([[660, 800], [860, 760], [850, 900], [700, 900]])); a.restore();

    // ── purple zig-zag sticker ──
    const stBase = [[610, 170], [540, 222], [480, 258], [420, 288], [350, 310], [280, 322], [215, 348], [170, 400], [148, 470], [133, 550], [116, 640], [95, 720], [72, 790], [72, 860],
      [96, 896], [140, 930], [206, 952], [266, 972], [330, 990], [420, 986], [510, 962], [590, 928], [650, 884], [670, 830], [690, 780], [740, 740], [760, 600], [760, 300], [700, 180]];
    const stW = wave(stBase, 46, 17);
    const stP = P(stW);
    // pale translucent border + blue line
    a.save(); a.lineJoin = 'round'; a.strokeStyle = 'rgba(214,222,214,0.8)'; a.lineWidth = 34; a.stroke(stP); a.restore();
    hx.save(); hx.lineJoin = 'round'; hx.strokeStyle = hc(0.05, 2); hx.lineWidth = 34; hx.stroke(stP); hx.restore();
    R.flat(stP, '#9c4c84', 0.08, 2);
    a.save(); a.lineJoin = 'round'; a.strokeStyle = '#2f4fd0'; a.lineWidth = 10; a.stroke(stP); a.strokeStyle = '#6a58c8'; a.lineWidth = 3; a.stroke(stP); a.restore();
    // purple interior shading + scribbles
    a.save(); a.clip(stP);
    const pg = a.createLinearGradient(200, 300, 500, 1000); pg.addColorStop(0, '#c898b0'); pg.addColorStop(0.25, '#a9709a'); pg.addColorStop(0.55, '#a4508c'); pg.addColorStop(1, '#8e3e7c');
    a.fillStyle = pg; a.globalAlpha = 1; a.fillRect(0, 150, 800, 874); a.globalAlpha = 1;
    const sr = rng(9); a.strokeStyle = 'rgba(60,10,40,0.55)'; a.lineWidth = 1.6;
    for (let i = 0; i < 260; i++) {
      let x = 60 + sr() * 700, y = 180 + sr() * 840; a.beginPath(); a.moveTo(x, y);
      for (let k = 0; k < 4; k++) { x += (sr() - 0.5) * 22; y += (sr() - 0.5) * 22; a.lineTo(x, y); }
      a.stroke();
    }
    a.restore();

    // ── black worm sticker ──
    const ws = [[555, -30], [560, 40], [572, 100], [596, 150], [632, 184], [700, 196], [760, 300], [760, 520], [700, 580], [656, 630], [660, 700], [690, 760], [730, 792], [776, 790], [820, 772], [870, 752], [950, 732], [1054, 716], [1054, -30]];
    const wsP = P(ws);
    a.save(); a.lineJoin = 'round'; a.strokeStyle = 'rgba(190,178,190,0.9)'; a.lineWidth = 30; a.stroke(wsP); a.restore();
    hx.save(); hx.lineJoin = 'round'; hx.strokeStyle = hc(0.12, 3); hx.lineWidth = 34; hx.stroke(wsP); hx.restore();
    R.flat(wsP, '#4a3092', 0.13, 3);
    const wsIn = P([[600, -30], [606, 40], [620, 96], [648, 140], [700, 160], [800, 184], [880, 214], [920, 270], [918, 400], [870, 500], [810, 580], [760, 650], [720, 730], [750, 770], [800, 758], [860, 734], [930, 712], [1054, 696], [1054, -30]]);
    a.save(); a.clip(wsP); a.fillStyle = '#12141f'; a.fill(wsIn); a.restore();
    // lilac worms
    const worms = [
      [[626, 128], [618, 88], [636, 50], [668, 30], [704, 34], [728, 58]], [[690, 118], [698, 86], [722, 72], [740, 86], [734, 112]],
      [[760, 10], [778, 40], [776, 80], [792, 120]], [[806, 168], [812, 120], [826, 80], [846, 44], [848, 10]], [[880, -10], [892, 36], [880, 90], [872, 136], [886, 176], [872, 214]],
      [[914, 76], [940, 52], [964, 20]], [[926, 126], [956, 106], [980, 86], [1010, 92]], [[1016, 120], [994, 160], [984, 200], [960, 232], [930, 250]],
      [[928, 296], [962, 290], [996, 306], [1010, 340], [990, 372], [950, 372]], [[870, 364], [900, 344], [930, 336]],
      [[896, 420], [930, 432], [964, 414], [1000, 428], [1030, 420]], [[880, 480], [914, 462], [950, 482], [990, 472], [1030, 486]],
      [[860, 540], [900, 530], [930, 560], [912, 600], [880, 612], [870, 650], [892, 684], [930, 672], [950, 640]],
      [[944, 556], [966, 598], [996, 616], [1012, 656], [986, 700], [950, 692]], [[1000, 520], [1024, 540]],
      [[664, 700], [668, 666], [700, 650], [732, 662], [740, 692], [718, 712], [696, 700]], [[740, 646], [772, 624], [804, 634], [834, 604]],
      [[756, 706], [798, 694], [830, 664], [862, 692], [842, 724], [800, 740], [760, 760], [730, 790]]];
    for (const w of worms) {
      const p = P(w, false);
      R.pipe(p, 34, '#443e74', 0.14, 0.08, 3);
      a.save(); a.lineWidth = 20; a.strokeStyle = '#b494a6'; a.translate(-3, -3); a.stroke(p); a.restore();
    }

    // ── bronze medallion ──
    const lobeL = P([[370, 350], [300, 356], [248, 380], [212, 424], [196, 480], [188, 540], [190, 600], [200, 650], [178, 700], [156, 740], [146, 780], [150, 820], [168, 856], [200, 900], [248, 934], [300, 950], [360, 956], [420, 946], [490, 916], [550, 866], [586, 780], [588, 650], [570, 560], [520, 440], [460, 384]]);
    const lobeU = circleP(616, 392, 150);
    const med = new Path2D(); med.addPath(lobeL); med.addPath(lobeU);
    const bro = E.fx(`

      vec3 fx(vec2 uv, vec2 px){
        float s = hash(floor(px * 0.7)), n = fbm(px * 0.03);
        vec3 c = mix(vec3(0.50, 0.38, 0.16), vec3(0.74, 0.60, 0.26), n);
        c *= 0.65 + 0.6 * step(0.55, s) * s;
        return c;
      }`);
    a.save(); a.clip(med); a.drawImage(bro, 0, 0, 1024, 1024); a.restore();
    R.flat(med, null, 0.18, 4);
    // dark channel inside the gold rim
    both(x => x.clip(med));
    a.lineWidth = 96; a.strokeStyle = '#0d0c09'; a.stroke(lobeL); a.stroke(lobeU);
    hx.lineWidth = 96; hx.strokeStyle = hc(0.14, 4); hx.stroke(lobeL); hx.stroke(lobeU);
    restore();
    // gold rim: pipes along each lobe outline, clipped away from the other lobe
    const notL = new Path2D(); notL.rect(-50, -50, 1124, 1124); notL.addPath(lobeU);
    const notU = new Path2D(); notU.rect(-50, -50, 1124, 1124); notU.addPath(lobeL);
    both(x => x.clip(notL, 'evenodd')); R.pipe(lobeL, 34, '#d8aa48', 0.18, 0.08, 4); restore();
    both(x => x.clip(notU, 'evenodd')); R.pipe(lobeU, 34, '#d8aa48', 0.18, 0.08, 4); restore();
    // inner raised bronze plate
    const plate = P([[300, 410], [258, 446], [240, 520], [236, 620], [240, 720], [248, 790], [270, 850], [316, 896], [380, 912], [460, 900], [530, 850], [556, 700], [560, 560], [640, 530], [690, 480], [706, 400], [676, 318], [600, 296], [524, 326], [476, 404], [400, 392]]);
    a.save(); a.clip(plate); a.drawImage(bro, 0, 0, 1024, 1024); a.restore();
    R.dome(plate, null, 0.19, 0.04, 14, 4);
    // tail S and eye grooves
    const tail = P([[330, 790], [290, 770], [252, 780], [240, 822], [226, 858], [204, 852], [206, 806]], false);
    a.save(); a.lineCap = a.lineJoin = 'round'; a.lineWidth = 44; a.strokeStyle = '#0d0c09'; a.stroke(tail); a.restore();
    R.pipe(tail, 26, '#b08a3a', 0.22, 0.06, 4);
    R.groove(P([[266, 690], [280, 700], [276, 716]], false), 12, '#0d0c09', 0.23, 0.04, 4, 1);
    R.groove(P([[292, 640], [326, 652]], false), 6, '#0d0c09', 0.23, 0.03, 4, 1);
    R.groove(P([[290, 660], [324, 672]], false), 6, '#0d0c09', 0.23, 0.03, 4, 1);
    for (let i = 0; i < 4; i++) R.groove(P([[640 + i * 4, 440 + i * 12], [690, 430 + i * 12], [724, 440 + i * 10]], false), 5, '#0d0c09', 0.23, 0.03, 4, 1);
    // pearl in its socket
    R.dome(circleP(628, 380, 80), '#b08840', 0.2, 0.03, 10, 4);
    R.flat(circleP(628, 380, 70), '#0e0f12', 0.18, 4);
    R.bead(628, 378, 58, '#a8b0a4', 0.2, 0.22, 6);

    // yellow wavy hair + pink mouth block (inside black outlines)
    const hairs = [[[330, 404], [300, 420], [276, 450], [262, 490], [270, 520], [256, 556], [266, 596], [260, 630], [276, 656]],
      [[300, 436], [292, 470], [300, 500], [290, 540], [298, 580], [290, 620]], [[330, 410], [360, 400], [392, 414], [380, 436], [352, 440]],
      [[480, 410], [510, 400], [540, 410], [550, 432], [530, 440], [522, 466]]];
    for (const hp of hairs) { a.save(); a.lineCap = a.lineJoin = 'round'; a.lineWidth = 42; a.strokeStyle = '#0d0c09'; a.stroke(P(hp, false)); a.restore(); }
    for (const hp of hairs) R.pipe(P(hp, false), 24, '#ecd83c', 0.21, 0.06, 7);
    const pink = P([[336, 500], [440, 482], [470, 500], [470, 640], [350, 652], [334, 600]], true, false);
    a.save(); a.lineJoin = 'round'; a.lineWidth = 20; a.strokeStyle = '#0d0c09'; a.stroke(pink); a.restore();
    R.flat(pink, '#f25c78', 0.21, 7);
    R.groove(P([[350, 632], [370, 624], [390, 634], [410, 622], [430, 630], [450, 620]], false), 5, '#401018', 0.21, 0.02, 7, 1);

    // ── glossy orange tube creature: masses with holes + tubes ──
    const OR = '#e2860e', HOLE = '#140c10';
    const tube = (pts, w = 38, h0 = 0.26, dh = 0.12) => R.pipe(P(pts, false), w, OR, h0, dh, 5);
    const hole = (path, col = HOLE) => R.flat(path, col, 0.2, 5);
    const rr = (x, y, w, h) => rrect(x, y, w, h, Math.min(w, h) * 0.4);
    // frame / raised arm: violet interior, thick tube border, inner S-strokes
    const frameIn = P([[620, 222], [700, 196], [800, 200], [880, 228], [908, 268], [900, 330], [872, 394], [826, 450], [766, 500], [700, 544], [720, 480], [716, 420], [690, 350], [650, 290]]);
    R.flat(frameIn, '#46288e', 0.2, 3);
    a.save(); a.clip(frameIn); a.fillStyle = 'rgba(15,8,30,0.5)'; a.fill(P([[700, 330], [820, 300], [880, 330], [800, 460], [720, 500]])); a.restore();
    tube([[612, 226], [660, 200], [720, 190], [800, 196], [870, 222], [908, 262], [906, 322], [880, 388], [834, 446], [774, 498], [708, 544], [650, 580], [608, 600]], 50);
    tube([[616, 232], [644, 286], [684, 336], [712, 396], [724, 456], [718, 516], [700, 548]], 44);
    tube([[676, 212], [692, 256], [730, 290], [790, 300], [850, 298], [898, 286]], 32);
    tube([[744, 360], [780, 384], [830, 372], [874, 336]], 30);
    tube([[716, 262], [740, 312], [746, 350]], 24);
    R.pipe(circleP(664, 250, 20), 18, OR, 0.26, 0.08, 5);
    // ring
    R.pipe(circleP(596, 515, 26), 30, OR, 0.26, 0.12, 5);
    hole(circleP(596, 515, 11));
    // crown tubes + spikes
    tube([[310, 540], [334, 552], [370, 546], [406, 538], [440, 532]], 30);
    for (const sp of [[[352, 520], [350, 484]], [[400, 530], [396, 492]], [[446, 520], [444, 478]], [[520, 500], [518, 470]]]) tube(sp, 24);
    tube([[330, 592], [390, 590], [450, 594]], 22);
    // body mass
    const bodyM = P([[306, 690], [320, 668], [350, 654], [400, 650], [445, 640], [452, 600], [450, 556], [462, 510], [490, 486], [530, 482], [556, 500], [566, 540], [574, 600], [582, 650],
      [592, 700], [600, 760], [602, 820], [596, 860], [578, 896], [548, 916], [500, 926], [466, 934], [446, 956], [420, 962], [398, 950], [380, 935], [368, 935], [356, 962],
      [344, 988], [322, 990], [318, 960], [330, 920], [334, 880], [320, 850], [310, 810], [305, 760]]);
    R.dome(bodyM, OR, 0.25, 0.12, 20, 5);
    for (const [x, y, w, h] of [[345, 678, 22, 20], [385, 668, 12, 20], [330, 712, 26, 18], [380, 712, 26, 18], [424, 700, 16, 40], [458, 706, 50, 20], [336, 752, 26, 22],
      [386, 752, 54, 18], [466, 746, 34, 42], [520, 740, 20, 60], [440, 800, 32, 28], [482, 566, 18, 22]]) hole(rr(x, y, w, h));
    for (const sl of [[[412, 688], [460, 668], [500, 652]], [[470, 618], [504, 606]], [[466, 640], [512, 626]], [[546, 650], [550, 700], [548, 760], [552, 830]]])
      { a.save(); a.lineCap = 'round'; a.lineWidth = 14; a.strokeStyle = HOLE; a.stroke(P(sl, false)); a.restore(); hx.save(); hx.lineCap = 'round'; hx.lineWidth = 14; hx.strokeStyle = hc(0.2, 5); hx.stroke(P(sl, false)); hx.restore(); }
    hole(P([[368, 832], [404, 818], [440, 836], [432, 878], [400, 900], [372, 882]]));
    hole(P([[482, 832], [538, 816], [564, 848], [540, 880], [502, 872]]));
    hole(P([[400, 910], [430, 900], [440, 940], [410, 950]]));

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.8, emis: 0.35, spec: 0.1, shin: 10, wrap: 0.3 }),                       // petals
        E.mat({ dif: 0.85, emis: 0.3, spec: 0.35, shin: 30, wrap: 0.2 }),                      // purple vinyl sticker
        E.mat({ dif: 0.85, emis: 0.3, spec: 0.2, shin: 14, grain: 0.25, wrap: 0.2 }),           // black sticker + worms
        E.mat({ dif: 0.5, metal: 0.55, spec: 0.8, shin: 40, grain: 0.35, emis: 0.2, tint: [1.1, 0.9, 0.6], ao: 0.6 }), // bronze
        E.mat({ dif: 0.9, emis: 0.25, spec: 1.0, shin: 50, wrap: 0.15, coat: 0.12, ao: 0.6 }),  // glossy orange
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.7, shin: 30, wrap: 0.1 }),                         // pearl
        E.mat({ dif: 0.8, emis: 0.3, spec: 0.5, shin: 30, wrap: 0.2 })                          // yellow / pink
      ],
      light: [-0.55, 0.6, 0.58], lc: [1.05, 1.0, 0.92], amb: [0.28, 0.3, 0.34],
      envTop: [1, 0.95, 0.85], envHor: [0.5, 0.42, 0.3], envBot: [0.08, 0.06, 0.04], envK: [0.4, 1.0, 0.4, 0],
      shadow: [-10, 10, 0.6, 12], r1: 2, r2: 8, k: [0, 0.6, 0.4, 90]
    });
    E.grain(0.04, 5);
  }
});
