'use strict';
// s35 — "Pink wax slab": a glossy magenta slab punched with holes over a brown
// ground, a salmon clay blob with ringed teal eyes, red light on the right.
REC.register('s35', {
  w: 819, h: 1024,
  draw(E) {
    const W = 819, H = 1024, S = E.S;
    const R = E.relief(), a = R.a, hx = R.h;
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const area = pts => { let s = 0; for (let i = 0; i < pts.length; i++) { const p = pts[i], q = pts[(i + 1) % pts.length]; s += p[0] * q[1] - q[0] * p[1]; } return s; };
    const ccw = pts => area(pts) > 0 ? pts.slice().reverse() : pts;   // hole winding
    const soft = (ctx, px, fn) => { ctx.save(); ctx.filter = `blur(${px * S}px)`; fn(ctx); ctx.restore(); };
    // dome with a smoothstep profile (no crease at the foot) for melted, merging lumps
    const mound = (path, alb, h0, dh, wd, m) => {
      if (alb) { a.fillStyle = alb; a.fill(path); }
      const steps = Math.min(90, Math.max(2, Math.ceil(wd * S / 0.9)));
      hx.save(); hx.clip(path); hx.fillStyle = hc(h0 + dh, m); hx.fill(path);
      for (let k = steps - 1; k >= 1; k--) { const u = k / steps, t = (k - 0.5) / steps; hx.lineWidth = 2 * wd * u; hx.strokeStyle = hc(h0 + dh * t * t * (3 - 2 * t), m); hx.stroke(path); }
      hx.restore();
    };

    // slab colour field: lilac centre-left, deep magenta at the bottom, red right and left edges
    const field = pat(E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 lil = vec3(226.,132.,249.)/255., mag = vec3(214.,60.,205.)/255., deep = vec3(206.,30.,196.)/255.;
        vec3 red = vec3(199.,52.,43.)/255., redT = vec3(186.,44.,32.)/255.;
        float t = exp(-(pow((p.x-180.)/260.,2.) + pow((p.y-330.)/300.,2.)));
        vec3 c = mix(mag, lil, t);
        c = mix(c, deep, smoothstep(760.,1000.,p.y)*0.8);
        float r = smoothstep(525.,640.,p.x - 0.1*p.y + 40.*(fbm(p*0.004)-.5));
        c = mix(c, mix(redT, red, smoothstep(0.,300.,p.y)), r);
        vec3 edge = mix(vec3(190.,59.,49.)/255., vec3(196.,61.,151.)/255., smoothstep(60.,300.,p.y));
        edge = mix(edge, vec3(191.,42.,81.)/255., smoothstep(350.,600.,p.y));
        edge = mix(edge, vec3(160.,20.,28.)/255., smoothstep(650.,1000.,p.y));
        c = mix(c, edge, smoothstep(50.,0.,p.x));
        c = mix(c, vec3(197.,70.,136.)/255., smoothstep(130.,20.,p.x)*smoothstep(160.,20.,p.y)*0.6);
        c = mix(c, vec3(185.,24.,120.)/255., smoothstep(130.,20.,p.x)*smoothstep(520.,900.,p.y)*0.7);
        return c;
      }`));
    const fieldDeep = pat(E.fx(`
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = mix(vec3(214.,70.,225.)/255., vec3(205.,26.,190.)/255., smoothstep(850.,1010.,p.y));
        c = mix(c, vec3(222.,110.,236.)/255., exp(-pow((p.x-170.)/110.,2.)-pow((p.y-960.)/60.,2.))*0.7);
        c = mix(c, vec3(170.,14.,100.)/255., smoothstep(110.,10.,p.x));
        return c;
      }`));

    // ── ground (brown / olive, seen through holes and gaps)
    const gg = a.createLinearGradient(300, 700, 800, 1024);
    gg.addColorStop(0, '#3a0603'); gg.addColorStop(0.55, '#4a0c02'); gg.addColorStop(0.85, '#541200'); gg.addColorStop(1, '#7a3602');
    R.flat(rrect(-10, -10, W + 20, H + 20, 0), gg, 0.0, 1);

    // holes: [x, y, rx, ry, rot, interior]
    const holes = [
      [207, 12, 48, 28, 0, '#8a4406'], [72, 62, 10, 11, 0, '#7a4a12'], [131, 33, 8, 9, 0, '#7a4a12'], [157, 96, 6, 7, 0, '#8e6c22'],
      [163, 133, 6, 8, 0, '#8e6c22'], [165, 166, 5, 8, 0, '#6a3a10'], [99, 194, 5, 6, 0, '#7a5012'], [220, 206, 7, 12, -0.5, '#6a3a10'],
      [10, 126, 5, 4, 0, '#301008'], [383, 53, 7, 8, 0, '#50280a'], [438, 34, 7, 9, 0, '#6a4010'], [492, 65, 34, 30, 0, '#8a3a04'],
      [411, 196, 8, 9, 0, '#200805'], [68, 285, 30, 66, 0, '#9a4a02'], [213, 302, 15, 13, 0, '#040202'], [279, 281, 13, 12, 0, '#8e5c26'],
      [348, 258, 13, 12, 0, '#8a4406'], [142, 325, 7, 8, 0, '#6a4010'], [210, 353, 9, 8, 0, '#060303'], [137, 400, 15, 13, 0, '#040202'],
      [52, 484, 21, 26, 0, '#6e1e02'], [118, 484, 7, 9, 0, '#5a2a05'], [619, 235, 8, 9, 0, '#100404'],
      [135, 660, 16, 14, 0, '#200a04'], [121, 770, 18, 20, 0, '#200a08'], [67, 760, 4, 4, 0, '#300a05'],
      [192, 527, 4, 16, 0.2, '#300a05'], [98, 606, 9, 4, 0.5, '#300a05'], [788, 470, 2, 2, 0, '#300a05']
    ];
    const polyHoles = [
      [[[490, 128], [515, 121], [540, 128], [558, 146], [564, 170], [548, 156], [525, 142], [500, 137]], '#6a2a06'],
      [[[586, 76], [598, 78], [613, 102], [612, 116], [600, 102]], '#4a1a06'],
      // cave between slab and blob
      [[[299, 455], [317, 424], [349, 399], [392, 367], [417, 336], [436, 299], [449, 274], [462, 262], [466, 300], [452, 350], [438, 392], [400, 434], [368, 454], [348, 478], [342, 510], [305, 510], [296, 482]], '#5e1c0c'],
      // gap under the blob (bottom left) + the crack under it
      [[[112, 915], [140, 880], [200, 878], [262, 850], [292, 815], [340, 840], [350, 900], [380, 928], [460, 928], [470, 990], [330, 990], [112, 960]], '#4a0604'],
      // gap right of the blob, running down to the bottom
      [[[596, 470], [630, 448], [655, 436], [666, 442], [660, 470], [640, 490], [615, 510], [598, 515]], '#200402'],
      [[[636, 612], [662, 608], [684, 640], [694, 700], [700, 790], [712, 840], [750, 870], [780, 905], [795, 950], [808, 1000], [815, 1030], [530, 1030], [530, 880], [600, 860], [636, 700]], null]
    ];
    for (const [x, y, rx, ry, rot, c] of holes) R.paint(ellipseP(x, y, rx, ry, rot), c);
    for (const [pts, c] of polyHoles) if (c) R.paint(P(pts), c);
    // gel in the cave
    const gel = [[330, 500], [338, 472], [356, 450], [388, 428], [424, 390], [438, 356], [450, 306], [452, 272]];
    a.save(); a.lineCap = 'round'; a.lineJoin = 'round';
    a.strokeStyle = 'rgba(150,100,120,0.8)'; a.lineWidth = 34; a.stroke(P(gel, false));
    a.strokeStyle = 'rgba(200,170,190,0.7)'; a.lineWidth = 5; a.stroke(P(gel.map(([x, y]) => [x - 10, y - 4]), false));
    a.restore();

    // ── magenta slab with its holes (nonzero winding: holes run the other way)
    const slab = new Path2D();
    slab.rect(-20, -20, W + 40, H + 40);
    for (const [x, y, rx, ry, rot] of holes) { slab.moveTo(x + rx * Math.cos(rot), y + rx * Math.sin(rot)); slab.ellipse(x, y, rx, ry, rot, 0, Math.PI * 2, true); }
    for (const [pts] of polyHoles) slab.addPath(P(ccw(pts)));
    R.dome(slab, field, 0.06, 0.07, 9, 2);
    // gold glitter on the slab lip at the cave
    const gr = rng(35);
    for (let i = 0; i < 70; i++) {
      const u = gr(), x = 300 + u * 95 + (gr() - 0.5) * 8, y = 455 - u * 88 + (gr() - 0.5) * 8;
      a.fillStyle = gr() > 0.5 ? '#e8c890' : '#b08050'; a.fillRect(x, y, 1.6, 1.6);
    }

    // ── salmon blob
    const blobPts = [[452, 262], [470, 254], [510, 270], [560, 292], [600, 322], [620, 370], [615, 425], [630, 450],
      [620, 480], [640, 520], [680, 556], [700, 588], [684, 612], [648, 618], [656, 660], [662, 700], [658, 740], [640, 780], [650, 812], [680, 848], [700, 875],
      [712, 920], [690, 932], [640, 915], [600, 900], [560, 880], [520, 870], [470, 880], [455, 905], [440, 938], [400, 944], [365, 932], [345, 905], [335, 880],
      [325, 850], [300, 828], [282, 838], [247, 868], [193, 893], [150, 896], [140, 870], [148, 840], [160, 815], [168, 795], [160, 775], [143, 748], [136, 718],
      [148, 692], [170, 665], [185, 620], [198, 560], [196, 505], [240, 500], [300, 506], [336, 505], [342, 474], [361, 449], [392, 430], [430, 386], [442, 355],
      [455, 305], [452, 280]];
    const bg = a.createLinearGradient(230, 560, 620, 660);
    bg.addColorStop(0, '#dc84cc'); bg.addColorStop(0.3, '#e06c9e'); bg.addColorStop(0.62, '#da5a68'); bg.addColorStop(1, '#d24a4c');
    R.dome(P(blobPts), bg, 0.12, 0.2, 32, 3);
    // soft top-right: the blob melts into the red slab
    const topSoft = [[466, 240], [540, 242], [600, 266], [640, 300], [650, 380], [640, 440], [600, 452], [520, 400], [470, 320]];
    soft(a, 16, c => { c.fillStyle = '#d4505a'; c.fill(P(topSoft)); });
    mound(P(topSoft), null, 0.13, 0.19, 60, 3);
    // melted lumps on the upper blob
    for (const [x, y, rx, ry, dh] of [[530, 450, 50, 40, 0.03], [250, 820, 60, 40, 0.05], [640, 870, 50, 40, 0.05]])
      mound(ellipseP(x, y, rx, ry), null, 0.32, dh, Math.min(rx, ry), 3);
    // soft creases between the lumps (shallow smooth troughs)
    for (const [x, y, rx, ry, rot] of [[574, 380, 30, 8, 0.6], [606, 452, 22, 7, 0.1]])
      mound(ellipseP(x, y, rx, ry, rot), null, 0.32, -0.04, Math.min(rx, ry), 3);
    // holes at the blob's top edge
    R.dome(ellipseP(488, 236, 13, 11), '#0c0303', 0.3, -0.26, 7, 1);
    R.dome(ellipseP(541, 262, 11, 10), '#1c0505', 0.33, -0.26, 6, 1);
    R.dome(ellipseP(560, 337, 3, 3), '#300808', 0.32, -0.05, 2, 1);
    // dark hole right of the finger
    R.dome(ellipseP(334, 855, 17, 23, 0.2), '#2a0302', 0.3, -0.26, 9, 1);

    // rings: [x, y, rx, ry, ix, iy, irx, iry, bottom colour]
    const rings = [[407, 531, 65, 51, 412, 522, 31, 24, '#22b0b4'], [311, 654, 46, 42, 306, 654, 19, 18, '#22b4be'], [424, 649, 47, 42, 425, 646, 22, 19, '#1c2a08'],
      [529, 675, 46, 43, 531, 672, 19, 17, '#22a0a0'], [492, 467, 26, 24, 491, 468, 9, 8, '#200808']];
    for (const [x, y, rx, ry, ix, iy, irx, iry, c] of rings) {
      const o = ellipseP(x, y, rx, ry), th = Math.min(rx - irx, ry - iry);
      R.dome(o, '#e2708c', 0.3, 0.15, th * 0.75, 3);
      R.dome(ellipseP(ix, iy, irx, iry), '#b83848', 0.45, -0.3, Math.min(irx, iry) * 0.75, 4);
      R.paint(ellipseP(ix + irx * 0.22, iy + iry * 0.3, irx * 0.72, iry * 0.62), c);
    }

    // mint paint streaks on the left of the blob
    const streaks = [[[245, 534], [238, 548], [232, 568], [224, 588], [212, 610], [200, 626], [194, 618], [204, 596], [212, 574], [222, 552], [232, 538]],
      [[150, 702], [158, 686], [172, 670], [192, 654], [216, 644], [212, 656], [194, 670], [176, 686], [160, 704]],
      [[204, 774], [208, 752], [220, 730], [236, 712], [252, 704], [250, 716], [236, 736], [222, 756], [212, 774]]];
    for (const s of streaks) R.paint(P(ragged(s, 0, s.length, 4, 2.5, 7), true, false), '#b8dce6');

    // squiggle scratches on the blob
    R.groove(P([[392, 728], [398, 758], [408, 786], [424, 804], [452, 808], [480, 800], [496, 786], [506, 768]], false), 4, '#a0343a', 0.32, 0.02, 3, 0.6);
    R.groove(P([[480, 790], [494, 776], [504, 766]], false), 3, '#a0343a', 0.32, 0.02, 3, 0.6);

    // ── magenta front layer over the blob's bottom
    const front = [[96, 1030], [104, 980], [127, 930], [165, 915], [207, 905], [247, 888], [262, 878], [282, 848], [292, 818], [305, 801], [322, 806],
      [333, 830], [330, 860], [338, 888], [350, 915], [345, 945], [325, 962], [335, 975], [370, 985], [410, 985], [450, 975], [458, 940], [455, 905], [462, 860],
      [478, 832], [505, 825], [530, 828], [544, 850], [542, 895], [525, 945], [515, 990], [515, 1030]];
    R.dome(P(front), fieldDeep, 0.2, 0.16, 26, 4);
    R.dome(ellipseP(650, 976, 62, 58, 0), fieldDeep, 0.22, 0.16, 36, 4);
    R.dome(ellipseP(700, 1014, 12, 10, 0), '#300808', 0.4, -0.3, 8, 1);
    // magenta rolls on the red slab's edge along the right gap
    R.dome(P([[604, 534], [618, 502], [644, 480], [670, 480], [684, 508], [674, 544], [644, 564], [612, 560]]), '#e070e0', 0.14, 0.16, 26, 4);
    R.dome(P([[688, 650], [712, 656], [736, 688], [736, 740], [722, 786], [700, 800], [676, 790], [690, 750], [694, 700]]), '#dc62d8', 0.14, 0.14, 22, 4);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 30, coat: 0.15, wrap: 0.1, ao: 0.4 }),                          // 1 brown ground, wet
        E.mat({ dif: 1, spec: 0.7, shin: 70, coat: 0.3, wrap: 0.05, rim: 0.4, ao: 0.3 }),                // 2 magenta slab
        E.mat({ dif: 1, spec: 0.25, shin: 30, coat: 0.45, wrap: 0.25, rim: 0.6, ao: 0.4, grain: 0.01 }), // 3 salmon clay
        E.mat({ dif: 1, spec: 0.7, shin: 50, coat: 0.45, wrap: 0.1, rim: 0.5, ao: 0.3 })                 // 4 front lobes / ring holes
      ],
      light: [-0.55, 0.6, 0.58], lc: [0.78, 0.76, 0.78], amb: [0.5, 0.48, 0.52],
      envTop: [0.75, 0.55, 0.95], envHor: [0.45, 0.25, 0.45], envBot: [0.08, 0.02, 0.05], envK: [0.15, 0.5, 0.6, 0],
      rimC: [0.3, 0.18, 0.45], rimD: [-1, 1, 0.9], l2: [1, -0.3, -0.1, 1.5], l2c: [0.35, 0.08, 0.04],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-10, 10, 0.65, 7]
    });
    E.grain(0.03, 5);
  }
});
