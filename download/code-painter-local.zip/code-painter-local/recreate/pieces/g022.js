'use strict';
// g022 — "Cassette badge collage": a sunlit glossy plastic badge — cream and teal rims round a black
// record, a taupe tape machine with chrome reels, an orange four-button box, zebra flag and purple maze.
REC.register('g022', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const strokeA = (path, col, wd) => { a.lineWidth = wd; a.strokeStyle = col; a.stroke(path); };
    const PUR = '#4a2d9e';
    // purple-outlined glossy island
    const isle = (path, alb, h0, dh, wd, m, ow = 12) => { R.pipe(path, ow, PUR, h0 - 0.02, 0.05, 1); R.pipe(path, ow * 0.45, '#120a18', h0, 0.03, 1); R.dome(path, alb, h0, dh, wd, m); };
    const rot = (cx, cy, ang, pts) => pts.map(([x, y]) => [cx + x * Math.cos(ang) - y * Math.sin(ang), cy + x * Math.sin(ang) + y * Math.cos(ang)]);
    const rrPts = (hw, hh, r, n = 6) => { const o = []; const cs = [[hw - r, hh - r, 0], [-hw + r, hh - r, 1], [-hw + r, -hh + r, 2], [hw - r, -hh + r, 3]]; for (const [cx, cy, q] of cs) for (let i = 0; i <= n; i++) { const t = (q + i / n) * Math.PI / 2; o.push([cx + Math.cos(t) * r, cy + Math.sin(t) * r]); } return o; };
    const speck = (path, n, seed, col, rmax = 1.2) => clipA(path, () => { const r = rng(seed); a.fillStyle = col; for (let i = 0; i < n; i++) { a.globalAlpha = 0.3 + r() * 0.6; a.beginPath(); a.arc(r() * 726, r() * 1024, 0.3 + r() * rmax, 0, 6.283); a.fill(); } a.globalAlpha = 1; });

    // ── background rims ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#2c140e', 0, 0);
    R.dome(circleP(430, 430, 508), '#fbef98', 0.02, 0.06, 16, 2);
    R.dome(circleP(430, 430, 472), '#9ccdc9', 0.04, 0.03, 10, 2);
    speck(circleP(430, 430, 472), 1500, 3, '#e8fffc', 0.8);
    // the black record (grooved rings + dashed white track)
    const rec = P([[-10, 300], [12, 290], [26, 232], [48, 175], [88, 135], [150, 90], [210, 50], [280, -10], [430, -10], [450, 80], [320, 300], [320, 700], [300, 850], [60, 850], [-10, 850]], true, true);
    R.dome(rec, '#1a1a1e', 0.06, 0.04, 12, 6);
    clipA(rec, () => {
      for (let r = 520; r > 150; r -= 7) strokeA(circleP(400, 520, r), r % 3 ? 'rgba(90,88,92,0.35)' : 'rgba(10,10,12,0.5)', 2);
      a.fillStyle = 'rgba(95,90,94,0.6)'; a.fill(P([...Array(40)].map((_, i) => { const t = Math.PI * (0.55 + i / 39 * 0.9); return [400 + Math.cos(t) * 480, 520 + Math.sin(t) * 480]; }).concat([...Array(40)].map((_, i) => { const t = Math.PI * (1.45 - i / 39 * 0.9); return [400 + Math.cos(t) * 428, 520 + Math.sin(t) * 428]; })), true, false));
      for (let r = 430; r < 480; r += 6) strokeA(circleP(400, 520, r), 'rgba(60,58,62,0.4)', 1.5);
    });
    for (let i = 0; i < 7; i++) { const t = Math.PI * (1.15 + i * 0.03), x = 400 + Math.cos(t) * 405, y = 520 + Math.sin(t) * 405; R.dome(P(rot(x, y, t + Math.PI / 2, rrPts(14, 12, 2, 2))), '#f4f2ee', 0.1, 0.04, 3, 1); }

    // bottom: teal pool, cream, orange corner
    R.dome(P([[300, 860], [420, 880], [560, 900], [736, 880], [736, 1034], [300, 1034]], true, true), '#fbe88a', 0.02, 0.05, 20, 2);
    R.dome(P([[60, 830], [250, 820], [400, 880], [430, 960], [400, 1034], [60, 1034]], true, true), '#a6d6d2', 0.04, 0.05, 20, 2);
    R.dome(P([[-10, 836], [40, 850], [56, 940], [50, 1034], [-10, 1034]], true, true), '#f99644', 0.04, 0.06, 14, 2);
    // ── gold rope ──
    R.pipe(P([[40, -10], [60, 60], [110, 130], [200, 150], [240, 140]], false), 7, '#b4a078', 0.12, 0.08, 5);
    R.pipe(P([[330, -10], [312, 40], [290, 80]], false), 6, '#b4a078', 0.12, 0.08, 5);

    // ── taupe tape machine ──
    const mach = P([[300, 76], [420, 50], [520, 60], [606, 80], [628, 112], [626, 250], [604, 296], [540, 306], [420, 316], [392, 366], [252, 374], [236, 330], [276, 290], [276, 240], [256, 200], [290, 184]], true, true);
    isle(mach, '#ece4e2', 0.1, 0.08, 6, 1, 14);
    R.dome(P([[312, 92], [420, 66], [516, 76], [596, 96], [612, 120], [610, 246], [592, 280], [540, 292], [410, 302], [380, 352], [262, 360], [252, 332], [290, 296], [290, 236], [272, 206], [302, 196]], true, true), '#a08c8a', 0.14, 0.03, 6, 2);
    clipA(mach, () => {
      a.fillStyle = 'rgba(120,100,100,0.5)'; a.fill(circleP(420, 140, 78));
      speck(mach, 700, 11, '#f0e8e8', 0.6);
    });
    R.dome(P(rot(376, 143, -0.05, rrPts(26, 17, 2, 2))), '#f6f4f0', 0.18, 0.03, 3, 1);
    R.dome(P(rot(520, 150, 0.08, rrPts(34, 46, 3, 2))), '#f4f2ee', 0.18, 0.03, 3, 1);
    clipA(P(rot(520, 150, 0.08, rrPts(30, 42, 2, 2))), () => { for (let k = 0; k < 9; k++) strokeA(P(rot(520, 150, 0.08, [[-26, -38 + k * 9.5], [26, -38 + k * 9.5]]), false), '#141014', 2.5); strokeA(P(rot(520, 150, 0.08, [[0, -42], [0, 42]]), false), '#141014', 2); });
    R.flat(P(rot(548, 192, 0.08, rrPts(17, 17, 2, 2))), '#120c10', 0.15, 6);
    R.flat(P(rot(366, 226, 0.05, rrPts(32, 16, 2, 2))), '#120c10', 0.15, 6);
    R.flat(circleP(432, 262, 10), '#120c10', 0.12, 6);
    R.bead(334, 242, 13, '#f2f0ec', 0.16, 0.08, 1);
    R.bead(410, 298, 8, '#f2f0ec', 0.16, 0.06, 1);
    R.dome(circleP(496, 292, 40), '#0c0a0e', 0.16, 0.06, 8, 6);
    R.dome(circleP(496, 292, 22), '#3a3438', 0.18, 0.04, 6, 6);
    R.dome(P(rot(588, 236, 0.1, rrPts(22, 24, 3, 2))), '#f2eee8', 0.16, 0.04, 4, 1);
    // chrome reels
    for (const [x, y] of [[240, 118], [462, 52]]) {
      R.pipe(circleP(x, y, 50), 12, PUR, 0.16, 0.06, 1);
      R.dome(circleP(x, y, 48), '#c0c8d4', 0.18, 0.12, 14, 3);
      R.dome(circleP(x, y, 14), '#d8dce4', 0.32, 0.06, 6, 3);
      for (let k = 0; k < 4; k++) { const t = k * Math.PI / 2 + 0.3; R.flat(P(rot(x + Math.cos(t) * 28, y + Math.sin(t) * 28, t, rrPts(8, 8, 1, 1))), '#0c0c10', 0.2, 6); }
    }

    // ── mauve sponge field ──
    const spPts = [[40, 380], [100, 352], [180, 340], [260, 336], [330, 322], [420, 304], [520, 306], [600, 300], [624, 330], [610, 470], [600, 600], [590, 700], [520, 712], [440, 700], [380, 760], [360, 830], [260, 850], [180, 820], [70, 810], [10, 740], [16, 600], [24, 480]];
    const scal = []; for (let i = 0; i < spPts.length; i++) { const p0 = spPts[i], p1 = spPts[(i + 1) % spPts.length]; const L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), k = Math.max(1, Math.round(L / 16)); for (let j = 0; j < k; j++) { const u = j / k, bump = (j % 2 ? 7 : 0); scal.push([p0[0] + (p1[0] - p0[0]) * u + (p1[1] - p0[1]) / L * bump, p0[1] + (p1[1] - p0[1]) * u - (p1[0] - p0[0]) / L * bump]); } }
    const sponge = P(scal, true, true);
    isle(sponge, '#765671', 0.1, 0.05, 10, 4, 12);
    const spCv = E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 q = p * 0.11; vec2 i = floor(q), f = fract(q); float m = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 o = vec2(hash(i + g), hash(i + g + 7.7)); m = min(m, length(g + o - f)); }
      float v = smoothstep(0.15, 0.6, m); return vec3(1.0 - 0.45 * v); }`);
    clipA(sponge, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(spCv); a.restore(); });

    // ── zebra fan + pink tile + lipstick ──
    const fan = P([[128, 312], [140, 272], [180, 240], [230, 222], [278, 220], [300, 250], [290, 300], [250, 330], [200, 352], [150, 346]], true, true);
    isle(fan, '#f2f0ec', 0.12, 0.06, 8, 1);
    const fanCv = E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 d = p - vec2(164.6, 459.9); float ph = (length(d) - 22.9) / 36.92 + 0.182 * sin(atan(d.y, d.x) * 1.359); float s = sin(6.2832 * ph); return vec3(smoothstep(-0.15, 0.15, s)) * 0.93 + 0.02; }`);
    clipA(fan, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(fanCv); a.restore(); });
    isle(P([[236, 318], [318, 296], [336, 362], [256, 390]], true, false), '#e66fa4', 0.18, 0.04, 5, 1, 8);
    R.pipe(P([[382, 300], [352, 340]], false), 28, '#0c0a0e', 0.18, 0.12, 6);
    R.pipe(P([[352, 340], [334, 364]], false), 30, '#ece8e4', 0.2, 0.12, 3);
    R.pipe(P([[334, 364], [314, 390]], false), 30, '#0c0a0e', 0.18, 0.12, 6);

    // ── purple maze ──
    const maze = P([[600, 160], [640, 140], [700, 130], [736, 140], [736, 740], [650, 730], [596, 700], [590, 500], [596, 300]], true, true);
    isle(maze, '#5b3cb6', 0.1, 0.04, 10, 1, 12);
    const vor = `vec2 vo(vec2 p){ vec2 q = p / 46. + 0.18 * vec2(vnoise(p * 0.03), vnoise(p * 0.03 + 9.)); vec2 i = floor(q), f = fract(q); float m1 = 9., m2 = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(x, y); vec2 o = vec2(hash(i + g), hash(i + g + 3.1)) * 0.8 + 0.1; float d = length(g + o - f); if (d < m1) { m2 = m1; m1 = d; } else if (d < m2) m2 = d; }
      return vec2(m1, m2); }
      float wall(vec2 p){ vec2 v = vo(p); return clamp(1. - (v.y - v.x) * 46. / 13., 0., 1.); }`;
    const mzCv = E.fx(vor + `vec3 fx(vec2 uv, vec2 p){ float w = smoothstep(0.0, 0.25, wall(p)); return mix(vec3(0.36, 0.24, 0.71), vec3(0.92, 0.86, 0.92), w); }`);
    clipA(maze, () => img(mzCv));
    const mzH = E.fx(vor + `vec3 fx(vec2 uv, vec2 p){ float w = wall(p); float h = 0.12 + 0.16 * sqrt(max(0., 1. - (1. - w) * (1. - w))) * step(0.01, w); float v = h * 255.; return vec3(floor(v) / 255., 32. / 255., fract(v)); }`);
    R.h.save(); R.h.clip(maze); R.h.setTransform(1, 0, 0, 1, 0, 0); R.h.drawImage(mzH, 0, 0); R.h.restore();
    R.dome(P([[680, 150], [736, 136], [736, 200], [700, 206]], true, true), '#f6a050', 0.12, 0.06, 8, 1);
    R.dome(P([[630, 150], [660, 130], [690, 150], [672, 176], [640, 172]], true, true), '#ece2d4', 0.12, 0.06, 6, 1);

    // ── character in a black hole ──
    R.dome(circleP(178, 482, 98), '#0a0808', 0.06, 0.03, 6, 6);
    R.pipe(circleP(178, 482, 98), 8, '#6a5a50', 0.1, 0.03, 5);
    R.dome(P([[128, 450], [140, 412], [180, 398], [228, 404], [252, 440], [254, 490], [150, 500]], true, true), '#a49478', 0.12, 0.12, 20, 5);
    { const hp = []; for (let i = 0; i <= 16; i++) { const t = Math.PI * (1.05 + i / 16 * 0.75), r = i % 2 ? 62 : 86; hp.push([182 + Math.cos(t) * r, 470 + Math.sin(t) * r * 0.9]); } hp.push([200, 420], [150, 440], [120, 470]); R.dome(P(hp, true, false), '#f2de3a', 0.2, 0.06, 5, 1); }
    R.dome(P([[150, 470], [252, 466], [262, 540], [246, 566], [160, 566]], true, true), '#e26aa0', 0.13, 0.05, 6, 1);
    clipA(P([[150, 470], [252, 466], [262, 540], [246, 566], [160, 566]], true, true), () => { for (let y = 500; y < 570; y += 12) { strokeA(P([[140, y], [270, y]], false), '#b84478', 2); for (let x = 150 + (y % 24 ? 12 : 0); x < 270; x += 24) strokeA(P([[x, y], [x, y + 12]], false), '#b84478', 2); } });
    const teeth = []; for (let i = 0; i <= 12; i++) teeth.push([152 + i * 8.4, i % 2 ? 470 : 486]);
    R.dome(P([...teeth, [252, 500], [152, 500]], true, false), '#f4f0ea', 0.18, 0.04, 3, 1);
    R.dome(P([[118, 470], [146, 476], [160, 530], [150, 570], [124, 556], [112, 510]], true, true), '#ee8a2a', 0.15, 0.06, 6, 1);
    for (const [x, y] of [[170, 440], [212, 438]]) R.bead(x, y, 8, '#3a2a1a', 0.2, 0.04, 6);

    // ── orange four-button box ──
    const BC = [430, 480], BA = -0.38;
    R.dome(P([[468, 330], [636, 306], [612, 440], [560, 470]], true, true), '#f49428', 0.14, 0.12, 10, 1);
    const box = P(rot(BC[0], BC[1], BA, rrPts(138, 136, 26)), true, false);
    isle(box, '#f49428', 0.14, 0.14, 12, 1, 12);
    const inner = P(rot(BC[0], BC[1], BA, rrPts(110, 108, 16)), true, false);
    R.dome(inner, '#b09670', 0.2, 0.03, 5, 4);
    speck(inner, 400, 21, '#2a2018', 1.4);
    R.dome(P(rot(548, 410, -0.38, rrPts(26, 66, 4, 2))), '#0c0a0e', 0.26, 0.04, 4, 6);
    for (const [dx, dy] of [[0, -30], [0, 14], [0, 50]]) { const q = rot(548, 410, -0.38, [[dx, dy]])[0]; R.dome(P(rot(q[0], q[1], -0.38, rrPts(16, 13, 2, 2))), '#f6f4f0', 0.3, 0.03, 3, 1); }
    for (const [x, y] of [[345, 465], [442, 408], [495, 512], [398, 565]]) {
      R.dome(circleP(x, y, 47), '#9a8460', 0.22, 0.05, 6, 4);
      R.dome(circleP(x, y, 40), '#0e0c0e', 0.2, 0.03, 8, 6);
      if (!(x === 442)) { strokeA(P(rot(x, y, 0.5, [[-12, 0], [12, 0]]), false), '#a89070', 4); strokeA(P(rot(x, y, 0.5, [[0, -12], [0, 12]]), false), '#a89070', 4); }
    }
    R.bead(442, 408, 20, '#ecebe8', 0.26, 0.18, 1);
    // orange gecko
    R.pipe(P([[440, 640], [470, 646], [510, 640], [540, 624], [548, 600], [540, 580], [524, 584]], false), 16, '#f49428', 0.2, 0.1, 1);
    for (const l of [[[470, 646], [452, 668]], [[470, 646], [446, 628]], [[530, 630], [560, 656], [576, 664]], [[540, 612], [570, 600]]]) R.pipe(P(l, false), 9, '#f49428', 0.2, 0.08, 1);
    R.bead(490, 620, 12, '#f0eeec', 0.2, 0.1, 1);

    // ── glossy black device with a white ring ──
    const dev = P([[-10, 570], [60, 552], [180, 550], [260, 566], [300, 600], [310, 670], [280, 740], [200, 770], [80, 770], [-10, 760]], true, true);
    isle(dev, '#0c0a0e', 0.14, 0.16, 26, 6, 12);
    R.dome(P(rot(50, 612, 0.1, rrPts(30, 24, 3, 2))), '#f4f2ee', 0.3, 0.03, 3, 1);
    R.dome(circleP(148, 688, 62), '#f2f0ec', 0.3, 0.1, 12, 1);
    R.dome(circleP(150, 688, 22), '#a49498', 0.36, -0.06, 6, 1);
    R.dome(P(rot(276, 622, 0.0, rrPts(14, 28, 3, 2))), '#ece8e4', 0.3, 0.05, 4, 1);
    // gold hammer
    R.pipe(P([[300, 650], [320, 680], [324, 720], [330, 750]], false), 12, '#a08850', 0.3, 0.08, 5);
    R.dome(P([[300, 630], [334, 640], [328, 668], [292, 660]], true, true), '#a08850', 0.32, 0.08, 6, 5);
    // little rings and beads
    for (const [x, y, r, col] of [[95, 345, 26, '#f4f0ec'], [52, 410, 28, '#f4f0ec'], [110, 842, 24, '#f4f0ec'], [225, 762, 18, '#c8b088'], [287, 800, 16, '#f4f0ec'], [20, 805, 12, '#f4f0ec']]) {
      R.dome(circleP(x, y, r), col, 0.16, 0.08, r * 0.5, 1);
      R.flat(circleP(x, y, r * 0.42), '#6a5a60', 0.17, 1);
    }
    for (const [x, y, r] of [[50, 516, 10], [160, 360, 7], [270, 762, 6], [16, 690, 6]]) R.bead(x, y, r, '#f4f0ec', 0.18, 0.06, 1);

    // ── zebra flag and taupe wedge ──
    const wedge = P([[592, 704], [660, 720], [736, 724], [736, 846], [650, 884], [606, 936], [566, 992], [530, 990], [548, 930], [556, 860], [574, 780]], true, true);
    isle(wedge, '#bca6a8', 0.1, 0.06, 8, 1);
    clipA(wedge, () => { for (let k = 0; k < 6; k++) strokeA(P([[650 + k * 14, 750], [640 + k * 14, 830]], false), 'rgba(120,96,100,0.6)', 3); });
    R.pipe(P([[630, 730], [604, 760], [600, 800], [612, 820]], false), 12, '#a8888c', 0.16, 0.06, 1);
    R.pipe(P([[590, 840], [570, 880], [566, 900]], false), 10, '#8a7074', 0.16, 0.06, 1);
    const flag = P([[327, 646], [460, 674], [598, 710], [574, 780], [556, 860], [548, 930], [536, 978], [470, 1000], [430, 992], [404, 967], [349, 911], [304, 867], [284, 800], [294, 733], [306, 667]], true, true);
    isle(flag, '#f4f2ee', 0.12, 0.08, 10, 6, 12);
    const zCv = E.fx(`vec3 fx(vec2 uv, vec2 p){ float ph = (p.y - 0.834 * (p.x - 400.) - 0.0008 * (p.x - 400.) * (p.y - 800.) - 84.5) / 75.9 + 0.14 * sin(p.x * 0.032 + p.y * 0.0102 + 0.93); float s = sin(6.2832 * ph); return vec3(smoothstep(-0.1, 0.1, s)) * 0.94 + 0.02; }`);
    clipA(flag, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(zCv); a.restore(); });
    // finger at the bottom
    R.dome(P([[96, 1040], [100, 960], [112, 938], [140, 934], [158, 956], [164, 1040]], true, true), '#e8a890', 0.2, 0.2, 24, 7);
    R.dome(P([[106, 974], [110, 946], [130, 940], [150, 950], [152, 976], [130, 980]], true, true), '#f8d2c8', 0.36, 0.04, 6, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.3, ao: 0.4, coat: 0.18 }),                    // 1 glossy plastic
        E.mat({ dif: 1, spec: 0.35, shin: 20, wrap: 0.5, ao: 0.3, grain: 0.06, emis: 0.05 }),      // 2 enamel rims
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.3, shin: 70, rim: 0.3, coat: 0.2 }),                  // 3 chrome
        E.mat({ dif: 1, spec: 0.4, shin: 20, wrap: 0.4, ao: 0.5, grain: 0.15 }),                    // 4 sponge
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.9, shin: 30, grain: 0.2 }),                           // 5 bronze / gold
        E.mat({ dif: 1, spec: 1.4, shin: 90, wrap: 0.2, ao: 0.3, coat: 0.35 }),                     // 6 black gloss
        E.mat({ dif: 1, spec: 0.3, shin: 16, wrap: 0.6, ao: 0.3 })                                  // 7 skin
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.9, 0.86, 0.8], amb: [0.36, 0.36, 0.4],
      envTop: [1, 0.98, 0.95], envHor: [0.55, 0.5, 0.55], envBot: [0.12, 0.08, 0.12], envK: [0.25, 1.1, 0.3, 0],
      r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 120], shadow: [-6, 7, 0.6, 7]
    });
    E.grain(0.04, 22);
  }
});
