'use strict';
// g132 — "Pipe ring sprite": a smiling white clay head on a looping pipe banded with chrome rings, over a
// big white gourd, against a green camouflage tile wall, a beige wall and a black-and-white chevron floor.
REC.register('g132', {
  w: 726, h: 1024,
  draw(E) {
    const W = 726, H = 1024, S = E.S;
    const R = E.relief(), a = R.a;
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const radg = (x, y, r0, r1, st, x1 = x, y1 = y) => { const g = a.createRadialGradient(x, y, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const img = (cv, path) => { a.save(); if (path) a.clip(path); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clip) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clip) a.clip(clip); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const poly = pts => P(pts, true, false);
    const all = rrect(-10, -10, W + 20, H + 20, 0);

    // ── sky, camouflage tile wall, beige wall ──
    R.flat(all, lin(0, 0, 0, 120, [[0, '#3a3a52'], [1, '#46465e']]), 0, 0);
    const wallTop = x => 120 - 0.18 * x, wallBot = x => 705 + 0.133 * (x - 100);
    const wall = poly([[0, wallTop(0)], [637, wallTop(637)], [637, wallBot(637)], [0, wallBot(0)]]);
    const camo = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float top = 120. - 0.18 * p.x, bot = 705. + 0.133 * (p.x - 100.);
      float v = (p.y - top) / (bot - top);              // 0..1 up the wall
      float u = p.x / (bot - top) * 600.;
      vec2 q = vec2(u, v * 600.);
      float n = fbm(q * 0.012 + 3.1) + 0.35 * fbm(q * 0.05);
      vec3 c = mix(vec3(.10,.16,.13), vec3(.26,.34,.26), smoothstep(.66, .70, n));
      c = mix(c, vec3(.17,.25,.19), smoothstep(.55, .58, n) * (1. - smoothstep(.66, .70, n)) * .7);
      // tile seams
      float sy = abs(fract(v * 15.) - .5), sx = abs(fract(u / 52.) - .5);
      c *= 1. - .45 * smoothstep(.47, .5, sy) - .35 * smoothstep(.47, .5, sx);
      c *= .9 + .2 * vnoise(p * .3);
      return c; }`);
    img(camo, wall);
    // beige wall with panel seams, doorway
    const beige = poly([[636, -10], [736, -10], [736, 800], [636, 790]]);
    R.flat(beige, lin(636, 0, 726, 0, [[0, '#b8a68e'], [0.5, '#c2ae94'], [1, '#b49c80']]), 0, 0);
    for (let k = 0; k < 12; k++) { const y = 18 + k * 66; R.paint(rrect(636, y, 92, 2.5, 0), 'rgba(120,100,80,0.6)'); R.paint(rrect(636, y + 2.5, 92, 1.5, 0), 'rgba(240,230,215,0.6)'); }
    R.paint(rrect(636, 0, 4, 790, 0), '#6a6050');
    R.flat(poly([[684, 470], [736, 466], [736, 780], [684, 772]]), '#040404', 0, 0);
    R.paint(rrect(680, 466, 5, 306, 0), '#d8ccbc');
    for (const [x, y] of [[606, 66], [592, 342], [598, 400], [704, 402]]) R.bead(x, y, 5, '#e8e8e8', 0.1, 0.05, 1);

    // ── chevron floor (perspective) ──
    const floorP = poly([[0, wallBot(0)], [736, wallBot(736)], [736, 1034], [0, 1034]]);
    // stripe field fitted offline: lines radiating from a vanishing point, mirrored about a chevron axis
    const floor = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 v0 = vec2(112.34, 796.47), t = vec2(cos(1.785), sin(1.785)), n = vec2(-t.y, t.x);
      vec2 A = vec2(-387.7, -97.88), d = A - v0, B = v0 + 2. * dot(d, t) * t - d;
      float side = dot(p - v0, n), sA = sign(dot(d, n));
      float ph = side * sA < 0. ? atan(p.y - A.y, p.x - A.x) - atan(v0.y - A.y, v0.x - A.x)
                                : -(atan(p.y - B.y, p.x - B.x) - atan(v0.y - B.y, v0.x - B.x));
      float g = ph + 1.843 * ph * abs(ph) + .026;
      float s = cos(6.2832 * g / .096);
      float e = fwidth(s) + .02;
      vec3 wht = vec3(.86, .86, .85) * (.92 + .1 * vnoise(p * .08));
      wht *= 1. - .1 * smoothstep(.46, .5, abs(fract(p.x / 34. + p.y / 90.) - .5));
      return mix(vec3(.05), wht, smoothstep(-e, e, -s)); }`);
    img(floor, floorP);

    // ── ceiling pipes ──
    for (const [x, y1] of [[130, 100], [293, 70], [500, 32]]) {
      R.pipe(P([[x, -10], [x, y1]], false), 10, '#6a5e58', 0.1, 0.08, 2);
      R.dome(rrect(x - 12, y1 - 6, 24, 22, 4), '#5a4e48', 0.12, 0.06, 5, 2);
      R.dome(rrect(x - 8, y1 + 14, 16, 8, 2), '#3a322e', 0.12, 0.04, 3, 2);
    }
    R.pipe(P([[118, 10], [180, 4], [215, 0]], false), 12, '#6a5e58', 0.1, 0.08, 2);

    // ── left: pink blob, black hose, lavender cloth ──
    R.dome(P([[20, 30], [42, 50], [54, 100], [52, 160], [44, 205], [26, 222], [16, 200]]), radg(30, 110, 5, 110, [[0, '#d09088'], [1, '#a06860']]), 0.1, 0.25, 30, 4);
    R.pipe(P([[28, 215], [48, 238], [60, 268], [66, 300]], false), 28, '#1a1614', 0.1, 0.2, 5);
    const cloth = P([[18, 262], [60, 276], [100, 305], [140, 345], [180, 392], [215, 430], [250, 470], [290, 520], [340, 548], [390, 560], [380, 600], [300, 650], [270, 720], [220, 745], [140, 760], [60, 780], [18, 780]]);
    R.dome(cloth, lin(20, 300, 200, 700, [[0, '#ece2f0'], [0.5, '#d8cee6'], [1, '#8a84b0']]), 0.05, 0.12, 60, 3);
    soft(x => { x.fillStyle = '#6e68a0'; x.fill(ellipseP(60, 650, 60, 90, 0.3)); x.fill(ellipseP(150, 710, 70, 30, 0)); x.fillStyle = '#f8f0fa'; x.fill(ellipseP(100, 340, 50, 25, 0.5)); }, 25, 0.8, 'source-over', cloth);

    // ── the gourd: elongated lobe + big bulb ──
    const lobe = P([[30, 480], [40, 445], [70, 422], [120, 412], [170, 414], [215, 432], [245, 468], [266, 515], [298, 556], [360, 572], [330, 690], [275, 745], [220, 715], [160, 680], [100, 640], [55, 595], [34, 540]]);
    R.dome(lobe, lin(60, 420, 160, 700, [[0, '#d8d8d0'], [0.5, '#cacac4'], [1, '#9a9ba8']]), 0.12, 0.34, 120, 1);
    const bulb = ellipseP(418, 730, 152, 166, 0);
    R.dome(bulb, radg(420, 640, 20, 200, [[0, '#e6e3da'], [0.6, '#cfccc4'], [1, '#9a98a0']]), 0.14, 0.5, 150, 1);
    // scratch marks on the bulb
    { const r = rng(132); let pts = [];
      for (let i = 0; i <= 30; i++) { const x = 340 + i * 5.3, y = 800 - (i % 2 ? 10 + r() * 32 : r() * 6); pts.push([x, y]); }
      R.groove(P(pts, false, false), 2, '#4a4848', 0.6, 0.05, 1, 0.9);
      for (let i = 0; i < 40; i++) { const x = 345 + r() * 150, y = 790 + r() * 50; a.save(); a.strokeStyle = 'rgba(70,70,70,0.4)'; a.lineWidth = 0.8; a.beginPath(); a.moveTo(x, y); a.lineTo(x + 2, y + 8 + r() * 14); a.stroke(); a.restore(); } }
    R.dome(ellipseP(445, 554, 58, 16, 0), '#ebe9e2', 0.62, 0.06, 8, 1);

    // ── the looping pipe ──
    const tubeA = P([[640, 135], [580, 128], [520, 126], [460, 128], [410, 135], [370, 155], [335, 190], [305, 230], [285, 270], [275, 310], [280, 350], [290, 385], [312, 420], [345, 452], [390, 478], [440, 490], [500, 505], [548, 530], [590, 565], [622, 615], [645, 670], [656, 720], [656, 765], [648, 805], [628, 838], [598, 862]], false);
    R.pipe(tubeA, 70, '#ece9e2', 0.35, 0.3, 1);
    // elbow sleeve (top right)
    R.dome(P([[556, 92], [620, 84], [690, 86], [722, 108], [726, 180], [720, 240], [690, 290], [652, 316], [622, 300], [600, 250], [590, 190], [565, 160], [552, 125]]), lin(560, 90, 720, 300, [[0, '#f2f0ea'], [1, '#c8c4c0']]), 0.4, 0.22, 40, 1);
    for (const pts of [[[600, 100], [640, 170], [690, 230]], [[640, 92], [690, 150], [715, 200]], [[575, 170], [620, 230], [650, 290]]]) R.groove(P(pts, false), 6, '#b8b4b0', 0.62, 0.05, 1, 0.6);
    // neck + collar + head
    R.pipe(P([[480, 330], [476, 400], [470, 470]], false), 62, '#ece9e2', 0.4, 0.28, 1);
    R.dome(ellipseP(476, 382, 56, 21, 0), '#f0eee8', 0.6, 0.1, 10, 1);
    R.dome(rrect(422, 368, 108, 18, 6), '#e8e6e0', 0.62, 0.06, 6, 1);
    R.dome(P([[420, 205], [400, 214], [384, 228], [400, 244], [420, 246]]), '#efede6', 0.42, 0.18, 14, 1);
    R.dome(P([[572, 244], [596, 240], [612, 258], [608, 282], [592, 292], [574, 286]]), '#efede6', 0.42, 0.18, 16, 1);
    R.dome(P([[494, 167], [530, 172], [552, 195], [566, 222], [574, 255], [573, 285], [566, 310], [552, 330], [520, 340], [470, 340], [438, 330], [422, 310], [413, 280], [414, 245], [424, 210], [445, 185], [468, 172]]), radg(470, 220, 10, 110, [[0, '#f6f4ee'], [1, '#dcdad4']]), 0.42, 0.5, 80, 1);
    R.dome(ellipseP(466, 229, 4.5, 7, 0), '#0a0a0a', 0.9, 0.02, 2, 4);
    R.dome(ellipseP(516, 238, 4.5, 7, 0), '#0a0a0a', 0.9, 0.02, 2, 4);
    R.groove(P([[478, 258], [488, 266], [499, 260]], false), 3.2, '#101010', 0.92, 0.03, 4, 1);

    // chrome bands across the tube
    const band = (x, y, ang, len, wd) => {
      const c = Math.cos(ang), s = Math.sin(ang), hx = -s * wd / 2, hy = c * wd / 2, lx = c * len / 2, ly = s * len / 2;
      const pth = poly([[x - lx - hx, y - ly - hy], [x + lx - hx, y + ly - hy], [x + lx + hx, y + ly + hy], [x - lx + hx, y - ly + hy]]);
      R.dome(pth, lin(x - lx, y - ly, x + lx, y + ly, [[0, '#4a4644'], [0.2, '#e8e4e0'], [0.45, '#9a9490'], [0.7, '#f4f0ec'], [1, '#5a5450']]), 0.62, 0.1, wd * 0.3, 4);
      a.save(); a.strokeStyle = 'rgba(30,26,24,0.9)'; a.lineWidth = 1.6; a.stroke(pth); a.restore();
    };
    for (const [x, y, ang, len, wd] of [[338, 188, 0.8, 84, 16], [287, 262, 0.25, 80, 16], [283, 368, -0.2, 80, 16], [362, 458, -0.95, 82, 18], [408, 132, 1.4, 80, 14], [470, 126, 1.55, 78, 14], [527, 126, 1.62, 78, 14], [580, 560, -0.75, 84, 18], [643, 656, -0.3, 82, 16], [642, 822, 0.25, 84, 17]])
      band(x, y, ang, len, wd);

    // ── torn paper strip on the left ──
    const strip = P(ragged([[-10, -10], [20, -10], [22, 200], [18, 420], [24, 640], [20, 1034], [-10, 1034]], 1, 5, 7, 4, 7), true, false);
    R.flat(strip, '#8a8682', 0.02, 0);
    { const r = rng(77); a.save(); a.clip(strip); for (let i = 0; i < 900; i++) { a.fillStyle = r() < 0.5 ? '#2a2826' : '#d0ccc8'; a.fillRect(r() * 26 - 2, r() * 1024, 1 + r() * 3, 1 + r() * 3); } a.restore(); }

    // ── pirate badge ──
    R.dome(ellipseP(70, 935, 44, 64, 0), '#3a4448', 0.1, 0.12, 8, 2);
    R.flat(ellipseP(70, 935, 34, 54, 0), '#38c0c0', 0.2, 0);
    R.flat(P([[40, 980], [44, 950], [60, 940], [80, 940], [96, 950], [100, 980]]), '#d81818', 0.21, 0);
    R.flat(ellipseP(70, 925, 13, 15, 0), '#f0c0a0', 0.22, 0);
    R.flat(P([[58, 930], [82, 930], [80, 950], [70, 958], [60, 950]]), '#141414', 0.23, 0);
    R.flat(P([[46, 914], [58, 900], [70, 896], [84, 900], [94, 914], [70, 910]]), '#1e6a4a', 0.23, 0);
    R.paint(rrect(62, 960, 16, 8, 2), '#f0d040');

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.28, shin: 18, wrap: 0.55, ao: 0.5, grain: 0.06 }),                 // 1 white clay
        E.mat({ dif: 0.55, metal: 0.65, spec: 1.3, shin: 60, ao: 0.4, rim: 0.2 }),                  // 2 chrome / copper pipes
        E.mat({ dif: 1, spec: 0.1, shin: 10, wrap: 0.6, ao: 0.4 }),                                 // 3 cloth
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.3, ao: 0.3 }),                                 // 4 gloss
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.3, ao: 0.3 })                                  // 5 rubber
      ],
      light: [-0.45, 0.55, 0.7], lc: [0.62, 0.61, 0.58], amb: [0.5, 0.51, 0.56],
      envTop: [1.0, 1.0, 1.0], envHor: [0.45, 0.5, 0.45], envBot: [0.12, 0.14, 0.12], envK: [0.3, 1.0, 0.3, 0],
      rimC: [0.1, 0.1, 0.15], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 8, k: [0, 0.6, 0.4, 90], shadow: [-10, 10, 0.55, 5]
    });

    // ── overlays: white crack lines ──
    const o = E.out;
    o.lineCap = o.lineJoin = 'round'; o.strokeStyle = '#f4f4f4'; o.lineWidth = 2.2;
    for (const pts of [[[18, 455], [38, 460], [55, 478], [72, 500], [92, 522], [102, 505]], [[92, 522], [90, 552]], [[18, 760], [55, 770], [62, 800], [80, 828], [108, 858], [132, 880], [158, 930], [176, 968]], [[62, 800], [72, 850], [88, 868]]]) o.stroke(P(pts, false, false));
    E.grain(0.035, 132);
  }
});
