'use strict';
// g024 — "Chrome bear's night arch": a glossy red arch on red holds a starry black night — red liquid
// splashes round a chrome ring, a zebra-capped chrome mushroom, a zebra slope, a blue hill and a chrome bear.
REC.register('g024', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };

    // ── red wall + pale floor ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#f6080a', 0, 0);
    R.flat(rrect(-10, 856, 746, 180, 0), lin(0, 0, 726, 0, [[0, '#f0fcfa'], [0.5, '#dfeefa'], [1, '#9cbaf8']]), 0, 0);
    soft(x => { x.fillStyle = 'rgba(230,140,120,0.7)'; x.fill(rrect(-10, 860, 60, 70, 0)); x.fill(rrect(690, 860, 60, 40, 0)); }, 14, 1);

    // ── the arch: glossy rim, black night inside ──
    const outer = P([[30, 966], [14, 900], [12, 700], [14, 480], [24, 360], [50, 260], [100, 170], [170, 95], [260, 42], [360, 16], [460, 14], [560, 34], [640, 84], [690, 160], [716, 270], [724, 420], [726, 700], [724, 930], [704, 972], [600, 990], [400, 996], [200, 990], [80, 980]], true, true);
    R.dome(outer, lin(0, 0, 726, 300, [[0, '#f02a10'], [0.45, '#e81808'], [0.75, '#f040a0'], [1, '#d060f0']]), 0.05, 0.3, 26, 1);
    clipA(outer, () => soft(x => {
      x.fillStyle = '#7a60ff'; x.fill(P([[690, 200], [724, 260], [728, 560], [700, 560], [688, 300]], true, true));
      x.fillStyle = '#f8c020'; x.fill(P([[694, 380], [708, 380], [708, 470], [696, 470]], true, true));
      x.fillStyle = '#ff70e0'; x.fill(P([[520, 20], [620, 50], [690, 140], [700, 220], [670, 180], [600, 80]], true, true));
      x.fillStyle = '#ffd000'; x.fill(P([[20, 520], [40, 300], [70, 240], [36, 330], [28, 520]], true, true));
    }, 8, 0.85));
    const night = P([[30, 960], [28, 700], [30, 480], [40, 380], [66, 290], [110, 200], [170, 130], [250, 75], [340, 45], [440, 40], [530, 55], [610, 100], [655, 170], [675, 260], [682, 400], [684, 560], [690, 960]], true, true);
    R.flat(night, '#030306', 0.12, 0);
    const stars = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 g = floor(p / 46.); float h = hash(g); vec2 o = vec2(hash(g + 3.1), hash(g + 5.7)) * 30. + 8.;
      float r = length(p - g * 46. - o), on = step(0.45, h), sz = 3. + 4. * hash(g + 9.);
      float core = smoothstep(sz, sz - 1.5, r) * on, halo = exp(-r * r / (sz * sz * 4.)) * on;
      return vec3(0.01, 0.01, 0.025) + vec3(1.) * core + vec3(0.2, 0.75, 1.) * halo * 0.6; }`);
    clipA(night, () => img(stars));
    // dark speckled disc, top right
    R.flat(ellipseP(510, 128, 150, 80, 0.1), '#060814', 0.13, 0);
    clipA(ellipseP(510, 128, 150, 80, 0.1), () => { const r = rng(4); for (let i = 0; i < 900; i++) { a.fillStyle = `rgba(${120 + r() * 100},${120 + r() * 100},255,${0.2 + r() * 0.4})`; a.fillRect(360 + r() * 300, 48 + r() * 160, 1, 1); } });

    // ── blue hill (bottom right) ──
    const blue = P([[700, 556], [690, 600], [650, 650], [580, 730], [520, 800], [500, 860], [470, 900], [432, 940], [420, 996], [600, 990], [704, 972], [724, 930], [726, 600]], true, true);
    R.dome(blue, lin(420, 600, 726, 1000, [[0, '#0a44ff'], [0.6, '#063cfc'], [1, '#2a5cff']]), 0.12, 0.12, 30, 6);
    R.dome(P([[512, 922], [540, 896], [600, 884], [636, 896], [628, 924], [580, 936], [520, 946]], true, true), '#ff74f4', 0.2, 0.03, 8, 6);
    for (const [x, y, r] of [[632, 775, 11], [616, 828, 6], [688, 768, 6], [602, 995, 6], [560, 700, 4]]) R.dome(circleP(x, y, r), '#f4fbff', 0.2, 0.03, r * 0.6, 0);

    // ── zebra slope ──
    const path = P([[22, 900], [60, 880], [120, 860], [200, 800], [260, 740], [330, 680], [420, 630], [520, 598], [620, 578], [690, 566], [690, 600], [650, 650], [580, 730], [520, 800], [500, 860], [470, 900], [432, 940], [420, 996], [200, 990], [80, 980], [30, 960]], true, true);
    const zp = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float k = (1.4097 - 0.5804) / 360., th = 0.5804 + k * (980. - p.y);
      float xr = 293.5 + (log(sin(th)) - log(sin(0.5804))) / k;
      float P = 41.1 + (29.04 - 41.1) * (980. - p.y) / 360.;
      float ph = (p.x - xr) * sin(th) / P - 0.0339 * pow((p.x - 400.) / 100., 2.);
      float s = sin(6.2832 * ph);
      return mix(vec3(0.02, 0.02, 0.04), vec3(0.97, 0.97, 0.99), smoothstep(-0.12, 0.12, s)); }`);
    R.dome(path, null, 0.14, 0.14, 30, 6);
    clipA(path, () => img(zp));

    // ── red splash (glossy liquid) ──
    const RED = '#e01608';
    const splash = [
      P([[230, 330], [160, 300], [90, 280], [50, 290], [60, 330], [40, 360], [110, 360], [190, 352], [240, 350]], true, true),
      P([[230, 360], [150, 390], [80, 400], [30, 420], [22, 450], [60, 470], [110, 452], [180, 430], [240, 400]], true, true),
      P([[250, 300], [210, 260], [170, 220], [140, 170], [110, 160], [100, 200], [140, 240], [200, 290], [230, 320]], true, true),
      P([[300, 330], [340, 380], [360, 420], [330, 440], [280, 430], [240, 410], [230, 360], [260, 330]], true, true),
      P([[230, 470], [280, 456], [320, 470], [300, 510], [250, 530], [210, 560], [170, 580], [150, 560], [190, 530], [200, 500]], true, true),
      P([[236, 66], [262, 60], [272, 80], [262, 100], [244, 96]], true, true)
    ];
    for (const p of splash) R.dome(p, RED, 0.2, 0.2, 18, 1);
    R.dome(P([[96, 170], [130, 160], [160, 200], [150, 236], [110, 240], [86, 210]], true, true), '#ffe010', 0.3, 0.12, 12, 1);
    for (const [x, y, r] of [[268, 152, 9], [248, 240, 6], [292, 290, 6], [372, 470, 10], [280, 280, 4]]) R.bead(x, y, r, RED, 0.25, 0.1, 1);
    // dark red eye orb
    R.dome(circleP(332, 226, 76), '#c01008', 0.25, 0.3, 50, 1);
    R.dome(ellipseP(334, 240, 50, 48, 0), '#100204', 0.4, 0.1, 30, 2);
    R.dome(circleP(334, 248, 18), '#b8f4ff', 0.5, 0.04, 8, 0);
    // rainbow tail
    const tail = P([[250, 470], [290, 452], [340, 470], [380, 500], [430, 504], [462, 500], [430, 520], [370, 530], [320, 520], [280, 500]], true, true);
    R.dome(tail, lin(260, 470, 460, 510, [[0, '#ff3010'], [0.25, '#f8e020'], [0.45, '#40f060'], [0.7, '#60c0ff'], [1, '#e0c0ff']]), 0.3, 0.12, 14, 1);
    R.dome(circleP(382, 440, 22), '#60f060', 0.32, 0.14, 14, 1);

    // ── chrome: ring, ball, bead arc, mushroom stem ──
    const CHR = '#d8dce8';
    R.dome(circleP(266, 322, 40), CHR, 0.35, 0.25, 22, 3);
    R.dome(circleP(266, 322, 16), '#0a0408', 0.4, -0.1, 6, 2);
    R.bead(406, 376, 28, CHR, 0.4, 0.3, 3);
    for (const [x, y] of [[318, 152], [324, 126], [338, 102], [358, 82], [386, 68], [416, 60], [448, 56], [480, 56], [512, 60]]) R.bead(x, y, 13, CHR, 0.4, 0.15, 3);
    const stem = P([[426, 392], [470, 380], [480, 420], [474, 500], [476, 600], [470, 620], [432, 616], [430, 500]], true, true);
    R.dome(stem, CHR, 0.25, 0.35, 40, 3);
    R.pipe(P([[490, 384], [530, 400], [540, 440], [520, 520], [506, 600]], false), 36, CHR, 0.25, 0.3, 3);
    for (const y of [385, 410, 470, 545, 570]) R.bead(448, y, 7, '#080808', 0.55, 0.02, 2);
    // zebra mushroom cap
    const cap = P([[412, 214], [480, 202], [560, 208], [640, 202], [664, 220], [670, 300], [674, 440], [620, 438], [560, 404], [500, 386], [440, 342], [408, 280]], true, true);
    R.dome(cap, null, 0.28, 0.2, 26, 6);
    const zc = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float u = max(p.x - 520., 0.01), v = max(470. - p.y, 0.01), n = 4.;
      float d = pow(pow(u, n) + pow(v, n), 1. / n), wv = pow(v, n) / (pow(u, n) + pow(v, n));
      float ph = d / 22. + wv * 0.35 * sin(0.075 * p.x + 1.) * smoothstep(660., 420., p.x) + (1. - wv) * 0.15 * sin(0.04 * p.y);
      float s = sin(6.2832 * ph);
      return mix(vec3(0.02, 0.02, 0.05), vec3(0.97, 0.96, 0.98), smoothstep(-0.12, 0.12, s)); }`);
    clipA(cap, () => img(zc));
    // small red splash on the slope
    R.dome(P([[544, 590], [570, 560], [610, 548], [650, 566], [656, 590], [610, 606], [570, 606]], true, true), RED, 0.3, 0.1, 10, 1);
    R.bead(598, 586, 12, '#e8f8ff', 0.4, 0.1, 3);

    // ── chrome bear ──
    R.dome(ellipseP(128, 790, 76, 100, 0.1), CHR, 0.25, 0.45, 70, 3);
    R.pipe(P([[150, 830], [220, 806], [292, 790]], false), 52, CHR, 0.4, 0.3, 3);
    R.dome(ellipseP(300, 786, 24, 30, 0), CHR, 0.5, 0.25, 22, 3);
    R.pipe(P([[72, 880], [140, 890], [210, 872]], false), 34, CHR, 0.35, 0.2, 3);
    R.pipe(P([[140, 706], [190, 712], [220, 700]], false), 30, CHR, 0.55, 0.2, 3);
    R.dome(P([[92, 610], [84, 586], [92, 570], [116, 584], [124, 604]], true, true), CHR, 0.45, 0.2, 12, 3);
    R.dome(P([[126, 592], [130, 570], [146, 572], [154, 594]], true, true), CHR, 0.45, 0.2, 10, 3);
    R.dome(ellipseP(166, 642, 76, 56, -0.1), CHR, 0.4, 0.45, 56, 3);
    R.dome(ellipseP(232, 636, 22, 20, 0), CHR, 0.6, 0.2, 18, 3);
    R.bead(190, 632, 9, '#0a0a10', 0.75, 0.04, 2);
    R.bead(222, 702, 18, '#f01810', 0.6, 0.2, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 1.3, shin: 70, wrap: 0.2, ao: 0.3, coat: 0.3 }),                    // 1 glossy liquid / rim
        E.mat({ dif: 1, spec: 1.2, shin: 80, coat: 0.3 }),                                         // 2 black gloss
        E.mat({ dif: 0.1, metal: 1.0, spec: 1.8, shin: 120, rim: 1.0, tint: [1.05, 1.05, 1.1] }),   // 3 chrome
        E.mat({}), E.mat({}),
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.2, coat: 0.2 })                              // 6 glossy enamel
      ],
      light: [-0.4, 0.6, 0.7], lc: [1, 0.98, 0.96], amb: [0.42, 0.4, 0.42],
      envTop: [1.2, 1.2, 1.25], envHor: [0.15, 0.14, 0.25], envBot: [0.06, 0.12, 0.5], envK: [1.6, 2.0, 0.3, 0],
      rimC: [0.2, 0.3, 0.9], rimD: [0.6, 0.2, 0.6], l2: [-1, 0.2, 0.25, 3], l2c: [1.0, 0.35, 0.18], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 120], shadow: [-5, 6, 0.5, 6]
    });
    E.bloom(0.12, 8);
    E.grain(0.03, 24);
  }
});
