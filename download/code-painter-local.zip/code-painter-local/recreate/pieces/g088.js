'use strict';
// g088 — "Night watchman's window": a capped guard reads his phone in a dark room under an ornate lavender
// ceiling lamp; a giant zebra-striped arm reaches into a blue window with two black bear silhouettes and a light beam.
REC.register('g088', {
  w: 726, h: 1024,
  draw(E) {
    const S = E.S, o = E.out;
    const pat = cv => { const p = o.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const fill = (path, c) => { o.fillStyle = c; o.fill(path); };
    const stroke = (path, c, wd) => { o.lineWidth = wd; o.strokeStyle = c; o.lineCap = o.lineJoin = 'round'; o.stroke(path); };
    const ink = (path, c, wd = 2.5, ic = '#060608') => { fill(path, c); stroke(path, ic, wd); };
    const clipped = (path, fn) => { o.save(); o.clip(path); fn(); o.restore(); };
    const blurred = (px, fn) => { o.save(); o.filter = `blur(${px * S}px)`; fn(); o.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = o.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, x1 = x, y1 = y, r0 = 0) => { const g = o.createRadialGradient(x1, y1, r0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const poly = pts => P(pts, true, false);
    const hatch = (path, n, seed, col, ang0, angJ, l0, l1, wd = 1.4) => clipped(path, () => {
      const r = rng(seed);
      for (let i = 0; i < n; i++) {
        const x = r() * 726, y = r() * 1024, a = ang0 + (r() - 0.5) * angJ + Math.sin(y * 0.01 + x * 0.004) * 0.35, L = l0 + r() * (l1 - l0);
        stroke(P([[x, y], [x + Math.cos(a) * L * 0.5, y + Math.sin(a) * L * 0.5 + 2], [x + Math.cos(a) * L, y + Math.sin(a) * L]], false), col, wd * (0.6 + r() * 0.8));
      }
    });

    // ── room: ceiling glow, dark walls ──
    fill(rrect(0, 0, 726, 1024, 0), '#090a0f');
    fill(rrect(0, 0, 726, 98, 0), lin(0, 0, 726, 0, [[0, '#0e1018'], [0.3, '#2c2633'], [0.5, '#3a3040'], [0.7, '#2c2633'], [1, '#0e111a']]));
    blurred(30, () => fill(ellipseP(385, 50, 230, 70, 0), 'rgba(80,66,90,0.6)'));
    stroke(P([[0, 98], [726, 98]], false), '#1e1c26', 3);
    // faint decor shapes on the dark wall
    { const r = rng(88); for (let i = 0; i < 9; i++) { const x = 560 + r() * 160, y = 120 + r() * 300; fill(P(star(x, y, 14, 6, 5, r() * 3)), 'rgba(30,32,44,0.8)'); } }
    for (const [x, y] of [[48, 70], [128, 18], [162, 20], [680, 38]]) fill(circleP(x, y, 1.5), '#d8d8e0');

    // ── ornate lamp ──
    const lamp = poly([[232, 22], [540, 20], [522, 156], [250, 156]]);
    ink(lamp, lin(232, 20, 540, 156, [[0, '#b8b0d0'], [0.5, '#c8c0e0'], [1, '#a8a0c4']]), 3);
    for (const [x0, y0, x1, y1] of [[255, 38, 350, 90], [420, 38, 516, 90], [266, 110, 350, 150], [420, 110, 508, 150]]) {
      const q = rrect(x0, y0, x1 - x0, y1 - y0, 2);
      ink(q, '#120e16', 2); stroke(rrect(x0 + 4, y0 + 4, x1 - x0 - 8, y1 - y0 - 8, 2), '#d8b8a0', 1.5);
      const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2;
      stroke(P([[x0 + 8, y0 + 8], [cx, cy], [x1 - 8, cy - 4]], false), '#e8c8b8', 2);
      stroke(P([[cx - 14, cy + 6], [cx - 4, cy - 8], [cx + 10, cy - 4], [cx + 6, cy + 10], [cx - 6, cy + 4]], true), '#e8c8b8', 2);
      stroke(P([[x1 - 30, y0 + 10], [x1 - 14, y0 + 16], [x1 - 22, y0 + 30]], false), '#e8d0c0', 2);
    }
    const dome = ellipseP(385, 106, 64, 40, 0);
    ink(dome, '#1a1420', 3);
    fill(ellipseP(385, 112, 54, 32, 0), rad(385, 128, 48, [[0, '#f0dcd8'], [0.3, '#8a7484'], [1, '#2a2030']]));
    fill(ellipseP(352, 92, 12, 4, -0.5), 'rgba(255,255,255,0.8)');
    for (const [x, y] of [[385, 34], [385, 156], [258, 102], [512, 102]]) ink(ellipseP(x, y, 8, 6, 0), '#c8c0e0', 2);

    // ── window ──
    ink(rrect(234, 178, 438, 300, 0), '#050608', 2, '#b8b0d0');
    fill(rrect(252, 210, 390, 280, 0), '#f2dcc8');
    stroke(P([[640, 212], [626, 232]], false), '#060608', 3);
    const sky = poly([[194, 232], [632, 232], [632, 480], [700, 470], [700, 600], [194, 600]]);
    fill(sky, lin(0, 225, 0, 560, [[0, '#4a9ad6'], [0.06, '#409bf6'], [1, '#3e9bf8']]));
    clipped(sky, () => { const r = rng(5); for (let i = 0; i < 1500; i++) { o.fillStyle = r() < 0.5 ? 'rgba(20,60,140,0.25)' : 'rgba(200,230,255,0.2)'; o.fillRect(194 + r() * 440, 232 + r() * 360, 1.2, 1.2); } });
    blurred(8, () => fill(rrect(392, 232, 26, 340, 6), 'rgba(250,150,210,0.9)'));
    fill(rrect(399, 232, 12, 340, 4), '#fff4fa');
    // bears
    fill(P([[232, 352], [250, 318], [274, 302], [282, 288], [292, 290], [300, 312], [330, 327], [372, 340], [389, 352], [362, 368], [322, 378], [272, 382], [236, 374]], true, true), '#030303');
    fill(P([[424, 350], [468, 330], [504, 316], [522, 296], [532, 289], [541, 296], [549, 316], [566, 332], [576, 356], [582, 386], [580, 410], [568, 424], [544, 427], [524, 424], [514, 410], [498, 400], [474, 396], [458, 386], [444, 370]], true, true), '#030303');
    // grey teardrop with a spiral
    const tear = P([[462, 452], [478, 432], [504, 420], [532, 414], [546, 422], [540, 448], [524, 478], [500, 500], [478, 504], [464, 492], [460, 472]], true, true);
    ink(tear, '#4c5666', 2.5, '#f0d4c0'); stroke(tear, '#060608', 1);
    stroke(P([[476, 480], [482, 476], [486, 482], [480, 488], [472, 482], [476, 472]], false), '#e8d4c4', 1.5);
    // coins + dashes
    for (const [x, y, r] of [[282, 535, 12], [322, 519, 10], [343, 547, 10], [369, 507, 8], [376, 541, 7], [429, 526, 6], [436, 494, 6], [551, 486, 6], [248, 550, 5], [395, 506, 4], [460, 498, 4]]) {
      ink(circleP(x, y, r), rad(x, y, r, [[0, '#a8acb4'], [1, '#5a5e68']], x - r * 0.3, y - r * 0.3), 2);
      stroke(P([[x - r * 0.4, y - r * 0.2], [x, y + r * 0.3], [x + r * 0.4, y - r * 0.1]], false), '#2a2a30', 1.2);
    }
    { const r = rng(8); for (let i = 0; i < 26; i++) { const x = 250 + i * 12 + r() * 6, y = 494 - Math.sin(i * 0.18) * 14 + r() * 8; fill(rrect(x, y, 5 + r() * 6, 3, 1.5), '#f0c8b4'); } }
    for (const [x, y] of [[440, 395], [462, 382], [480, 378], [348, 462], [360, 470], [520, 466]]) fill(ellipseP(x, y, 4, 2, 0), '#f0d0bc');

    // ── grey hatched mass ──
    const mass = P([[88, 640], [150, 600], [196, 560], [250, 566], [310, 572], [380, 572], [430, 556], [462, 528], [520, 502], [566, 488], [604, 478], [646, 470], [690, 458], [722, 450], [722, 640], [705, 700], [700, 980], [640, 984], [520, 978], [430, 976], [430, 1030], [88, 1030]], true, true);
    fill(mass, '#647585');
    clipped(mass, () => { const r = rng(9); for (let i = 0; i < 9000; i++) { o.fillStyle = r() < 0.5 ? 'rgba(40,50,62,0.35)' : 'rgba(170,185,200,0.3)'; o.fillRect(r() * 726, 450 + r() * 580, 1.3, 1.3); } });
    hatch(mass, 700, 12, 'rgba(26,34,46,0.85)', 0.5, 0.5, 14, 34, 1.3);
    hatch(poly([[560, 470], [726, 440], [726, 640], [560, 640]]), 160, 13, 'rgba(26,34,46,0.95)', 0.1, 0.3, 24, 50, 1.8);
    stroke(P([[196, 560], [250, 566], [310, 572], [380, 572], [430, 556], [462, 528], [520, 502], [566, 488], [604, 478], [646, 470], [690, 458], [722, 450]], false), '#f2cdb8', 3.5);
    stroke(P([[196, 556], [250, 562], [310, 568], [380, 568], [430, 552], [462, 524], [520, 498], [566, 484], [604, 474], [646, 466], [690, 454], [722, 446]], false), '#14181e', 1.5);
    { const r = rng(14); for (let i = 0; i < 16; i++) { const t = r(), x = 210 + t * 480, y = 575 - t * 110 + 6 + r() * 6; fill(rrect(x, y, 6 + r() * 10, 3, 1.5), '#f0c8b4'); } }
    fill(circleP(527, 512, 4), '#f2e8e0');

    // ── zebra sleeve + arm ──
    const zeb = P([[-10, -10], [34, -10], [48, 80], [62, 150], [100, 200], [140, 250], [190, 300], [220, 330], [262, 360], [310, 372], [342, 378], [338, 456], [300, 460], [262, 470], [232, 492], [212, 528], [198, 560], [170, 590], [140, 616], [110, 640], [60, 648], [-10, 648]], true, true);
    // stripe fields fitted to the reference: sleeve body, forearm, upper sleeve
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float v1 = cos(6.2832 * (dot(p, vec2(.7431, -.6691)) / 42. - .178));
      float v2 = cos(6.2832 * (dot(p, vec2(.8290, -.5592)) / 35. - .493));
      float v3 = cos(6.2832 * (dot(p, vec2(.7934, -.6088)) / 30.25 - .470));
      float w2 = smoothstep(208., 222., p.x) * smoothstep(318., 330., p.y);
      float w3 = 1. - smoothstep(288., 312., p.y);
      float v = mix(mix(v1, v3, w3), v2, w2);
      return mix(vec3(.02), vec3(.98, .95, .91), smoothstep(-.12, .12, v)); }`);
    clipped(zeb, () => { o.fillStyle = pat(zcv); o.fillRect(0, 0, 360, 660); });
    stroke(zeb, '#060606', 2.5);
    // wrist bracelets + hand
    const wrist = P([[328, 376], [356, 372], [374, 384], [374, 420], [366, 446], [344, 456], [328, 450]], true, true);
    ink(wrist, '#f0d4c4', 2);
    for (const [dx, c] of [[0, '#d83a5a'], [8, '#f2c8c0'], [14, '#c82848'], [24, '#e8c8b8']]) stroke(P([[332 + dx, 380], [338 + dx, 414], [334 + dx, 450]], false), c, 4);
    { for (let i = 0; i < 9; i++) fill(circleP(366, 384 + i * 7, 2), '#f8e0d0'); }

    // ── grey blob creature ──
    const blobP = P([[62, 182], [98, 168], [110, 150], [121, 136], [132, 148], [152, 152], [200, 166], [236, 192], [252, 226], [246, 256], [226, 282], [200, 302], [176, 312], [148, 306], [122, 292], [112, 262], [106, 228], [90, 202]], true, true);
    ink(blobP, '#706d8c', 3);
    clipped(blobP, () => blurred(10, () => fill(ellipseP(168, 258, 44, 36, 0), '#f4d4c8')));
    stroke(P([[100, 175], [118, 172], [116, 200], [114, 240], [116, 280], [130, 300]], false), '#f0d8c8', 2);
    for (const [x, y, rx, ry] of [[152, 212, 15, 12], [226, 207, 10, 9], [200, 185, 6, 5], [212, 262, 5, 5], [213, 224, 4, 4]]) ink(ellipseP(x, y, rx, ry, 0), '#f6efe6', 1.5);

    // ── chrome ball, plant, dresser ──
    ink(circleP(128, 685, 31), rad(128, 685, 31, [[0, '#ffffff'], [0.35, '#d8d8e0'], [0.75, '#7a7a88'], [1, '#2a2a34']], 132, 680), 2);
    fill(rrect(0, 640, 96, 140, 0), '#16141e');
    { const r = rng(15); for (let i = 0; i < 26; i++) { const x = 30 + r() * 80, y = 650 + r() * 125; stroke(P([[x, y], [x + 6 + r() * 6, y - 14 - r() * 10]], false), '#4a4c9c', 2); } }
    for (const x of [10, 22]) stroke(P([[x, 648], [x, 780]], false), '#6a3040', 3);
    const dres = rrect(-4, 784, 104, 214, 4);
    ink(dres, lin(0, 784, 100, 1000, [[0, '#94aadc'], [1, '#8098cc']]), 3);
    stroke(P([[0, 784], [100, 784]], false), '#e8d8d0', 3);
    stroke(rrect(4, 792, 88, 196, 3), '#3a4870', 1.5);
    ink(rrect(30, 826, 52, 7, 3), '#e8ecf4', 1.5);
    ink(ellipseP(26, 905, 5, 7, 0), '#e8ecf4', 1.5); fill(circleP(26, 905, 2), '#060608');

    // ── mirror on legs ──
    stroke(P([[652, 960], [636, 1000]], false), '#c8c8d8', 3); stroke(P([[700, 960], [714, 1000]], false), '#c8c8d8', 3);
    ink(ellipseP(676, 785, 46, 202, 0), '#f0d4c4', 2.5);
    fill(ellipseP(676, 785, 40, 196, 0), lin(640, 600, 716, 980, [[0, '#8c9ecc'], [0.5, '#a4aac8'], [1, '#b8b2c8']]));
    blurred(10, () => fill(ellipseP(690, 820, 16, 140, 0), 'rgba(240,220,230,0.5)'));
    ink(rrect(652, 930, 46, 6, 2), '#d8d8e8', 1.2);
    fill(rrect(712, 410, 14, 50, 2), '#a8a8c8');

    // floor strip
    fill(poly([[430, 980], [726, 984], [726, 1024], [430, 1024]]), '#566474');
    hatch(poly([[430, 984], [726, 984], [726, 1024], [430, 1024]]), 80, 16, 'rgba(26,34,46,0.8)', 0.1, 0.4, 14, 30, 1.2);
    fill(ellipseP(560, 978, 30, 6, 0), '#c8b8b0');

    // ── the guard ──
    const guard = P([[205, 606], [240, 597], [300, 601], [345, 619], [348, 631], [320, 642], [312, 660], [318, 680], [331, 694], [318, 698], [302, 690], [296, 706], [285, 726], [268, 742], [256, 752], [262, 780], [285, 830], [300, 862], [330, 882], [352, 880], [372, 892], [386, 930], [410, 940], [426, 956], [434, 1030], [78, 1030], [80, 900], [88, 820], [100, 762], [126, 726], [170, 702], [195, 690], [200, 662], [208, 640]], true, false);
    fill(guard, '#030304');
    clipped(guard, () => {
      blurred(1, () => { const r = rng(17);
        for (let i = 0; i < 22; i++) { const x = 190 + r() * 120, y = 760 + r() * 190, a = 1.2 + r() * 0.9, L = 20 + r() * 50; stroke(P([[x, y], [x + Math.cos(a) * L * 0.5 + 4, y + Math.sin(a) * L * 0.5], [x + Math.cos(a) * L, y + Math.sin(a) * L]], false), '#3a3a8c', 2 + r() * 3); } });
      fill(ellipseP(244, 640, 3, 4, 0), '#b8b8c0'); fill(ellipseP(200, 731, 3, 3, 0), '#d8d8e0');
    });
    // hands + phone
    fill(P([[318, 896], [340, 884], [360, 880], [372, 888], [362, 898], [370, 906], [380, 914], [376, 924], [350, 928], [326, 922]], true, true), '#f2b4a4');
    stroke(P([[338, 902], [360, 900]], false), '#a86a62', 1.2);
    const phone = poly([[352, 914], [414, 870], [430, 888], [368, 932]]);
    ink(phone, '#f6f6f8', 3, '#050505');
    fill(P([[368, 912], [382, 914], [392, 924], [376, 934], [362, 930]], true, true), '#f2b4a4');

    E.grain(0.04, 88);
  }
});
