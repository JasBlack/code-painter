'use strict';
// g091 — "Neon seed pillow": a white clay pillow scrawled with glowing neon loops and gold seeds, a one-eyed
// spiky head and a porous coral cage behind it, a red light bar, zebra drapery, inside a notched cream frame.
REC.register('g091', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };

    // ── outer gradient border ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#e0c890', 0, 0);
    a.fillStyle = lin(0, 0, 726, 0, [[0, '#f9f4ce'], [0.25, '#f3ecb5'], [0.5, '#e0dfcd'], [0.75, '#b5babd'], [1, '#8db3b4']]); a.fillRect(0, 0, 726, 70);
    a.fillStyle = lin(0, 0, 726, 0, [[0, '#f75b4c'], [0.25, '#f84048'], [0.5, '#fa3874'], [0.75, '#fa35cd'], [1, '#d845f6']]); a.fillRect(0, 955, 726, 69);
    a.fillStyle = lin(0, 60, 0, 964, [[0, '#f6f0b8'], [0.27, '#efdd61'], [0.48, '#eeb84b'], [0.71, '#e4883d'], [0.93, '#dd6238'], [1, '#f05c48']]); a.fillRect(0, 60, 18, 904);
    a.fillStyle = lin(0, 60, 0, 964, [[0, '#8fb0b0'], [0.27, '#778b8a'], [0.48, '#6e7da4'], [0.71, '#7873b3'], [0.93, '#9c64bf'], [1, '#c050e8']]); a.fillRect(708, 60, 18, 904);

    // content area with notched corners
    const X0 = 16, Y0 = 69, X1 = 709, Y1 = 958, NR = 32;
    const notched = (x0, y0, x1, y1, r) => {
      const p = new Path2D();
      p.moveTo(x0 + r, y0); p.lineTo(x1 - r, y0); p.arc(x1 + 2, y0 - 2, r + 2, Math.PI, Math.PI / 2, true);
      p.lineTo(x1, y1 - r); p.arc(x1 + 2, y1 + 2, r + 2, -Math.PI / 2, Math.PI, true);
      p.lineTo(x0 + r, y1); p.arc(x0 - 2, y1 + 2, r + 2, 0, -Math.PI / 2, true);
      p.lineTo(x0, y0 + r); p.arc(x0 - 2, y0 - 2, r + 2, Math.PI / 2, 0, true);
      p.closePath(); return p;
    };
    const content = notched(X0, Y0, X1, Y1, NR);
    const frameOut = notched(X0 - 8, Y0 - 8, X1 + 8, Y1 + 8, NR - 8);

    // ── interior: dark wall + lavender floor ──
    R.flat(content, '#36333a', 0, 0);
    clipA(content, () => {
      a.fillStyle = lin(0, 70, 0, 400, [[0, '#3a373e'], [1, '#2a272e']]); a.fillRect(0, 60, 726, 420);
      const floor = P([[300, 520], [709, 352], [740, 352], [740, 980], [0, 980], [0, 700]], true, false);
      a.fillStyle = lin(560, 380, 600, 960, [[0, '#55525b'], [0.3, '#8a8ca8'], [0.55, '#8486a8'], [1, '#56535c']]); a.fill(floor);
      soft(x => { x.fillStyle = '#9aa0c4'; x.fill(ellipseP(660, 610, 70, 120, 0)); }, 40, 0.7);
      soft(x => { x.fillStyle = '#26232e'; x.fill(ellipseP(380, 905, 200, 55, -0.2)); x.fill(ellipseP(520, 800, 90, 60, -0.4)); }, 30, 0.9);
    });

    // ── zebra drapery (top-left and bottom-left) ──
    // stripe flow fitted per 75-px tile (quadratic phase each), blended
    const zeb = E.fx(`const vec2 ZC[14] = vec2[14](vec2(54., 106.), vec2(128., 106.), vec2(204., 106.), vec2(278., 106.), vec2(354., 106.), vec2(54., 182.), vec2(128., 182.), vec2(204., 182.), vec2(278., 182.), vec2(354., 182.), vec2(54., 256.), vec2(128., 256.), vec2(204., 256.), vec2(278., 256.));
const float ZK[84] = float[84](-7.3046, 1.3859, -2.2384, -0.8249, 0.2870, 0.9351, 6.6020, -0.7988, 1.7968, 0.0364, -0.6198, -0.7842, -1.0822, -1.1823, 1.6082, -0.3485, 0.3566, -0.6461, -0.1336, -1.5443, 2.3894, -0.1166, 1.3046, -0.9513, 3.5672, -2.3461, 3.4668, -0.9473, 1.2920, -1.2072, -0.3728, -1.0492, 1.4372, 0.3630, 0.8677, -0.3245, 1.3800, -0.9280, 0.6409, 0.1856, 0.2360, -0.2513, 4.8670, -0.5459, 1.0704, 0.0122, 1.0491, -0.3647, 1.2921, -0.9709, 1.8440, -0.0036, 0.3773, 0.0676, 0.2847, -1.7817, 0.8519, -1.1488, 0.4353, -1.7854, 1.6259, 0.8432, -0.1072, -0.0038, 0.4703, 1.1873, -1.2675, -0.8422, -0.1116, -0.0091, -0.1639, -1.1367, 0.1288, -1.3984, 0.3476, -0.7361, 0.0045, -0.6150, 0.5232, 1.4443, -0.1529, 2.1208, 2.6129, -2.7263);
float zv(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 14; i++) { vec2 q = (p - ZC[i]) / 100.; float w = exp(-dot(q, q) / 0.3403);
    float ph = ZK[i*6] + ZK[i*6+1] * q.x + ZK[i*6+2] * q.y + ZK[i*6+3] * q.x * q.x + ZK[i*6+4] * q.x * q.y + ZK[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
const vec2 ZD[7] = vec2[7](vec2(54., 712.), vec2(54., 788.), vec2(128., 788.), vec2(54., 862.), vec2(128., 862.), vec2(54., 938.), vec2(128., 938.));
const float ZL[42] = float[42](2.6085, -0.6007, 1.0937, -0.3061, -1.5797, -0.8954, 1.0431, -2.9420, 1.9028, -1.8146, 1.8685, 0.0065, -4.3647, -20.6808, 0.3783, -18.3896, 3.9889, -0.2691, 6.3803, -1.9475, 1.5384, -1.3327, 0.8896, -0.3299, -1.9799, -4.2337, 2.7175, -1.3331, 1.8783, -0.3277, -5.3256, 1.1473, -0.9954, 1.2496, -1.2951, 0.3369, -1.1083, -2.4252, 2.0556, -0.6321, 1.6014, -0.4258);
float zw(vec2 p){ float s = 0., ws = 1e-4;
  for (int i = 0; i < 7; i++) { vec2 q = (p - ZD[i]) / 100.; float w = exp(-dot(q, q) / 0.3403);
    float ph = ZL[i*6] + ZL[i*6+1] * q.x + ZL[i*6+2] * q.y + ZL[i*6+3] * q.x * q.x + ZL[i*6+4] * q.x * q.y + ZL[i*6+5] * q.y * q.y;
    s += w * cos(6.2832 * ph); ws += w; }
  return s / ws; }
      vec3 fx(vec2 uv, vec2 p){
        float v = p.y < 520. ? zv(p) : zw(p);
        float sh = 0.88 + 0.12 * sin(p.y * 0.04 - p.x * 0.02);
        return mix(vec3(.93, .92, .9) * sh, vec3(.03), smoothstep(-.16, .16, v)); }`);
    const zebTL = P([[X0, Y0 + NR], [X0 + NR, Y0], [330, Y0], [370, 100], [405, 135], [420, 160], [400, 300], [X0, 600]], true, false);
    const zebBL = P([[X0, 560], [160, 600], [190, 958], [X0, Y1 - NR]], true, false);
    clipA(content, () => { clipA(zebTL, () => img(zeb)); clipA(zebBL, () => img(zeb)); });
    // drape shading
    clipA(zebTL, () => soft(x => { x.fillStyle = '#000'; x.fill(ellipseP(360, 150, 60, 140, 0.5)); }, 30, 0.35));

    // white fringe tubes along the pillow's lower-left edge, with little spikes
    const fr = rng(91);
    for (const [off, w] of [[12, 8], [30, 7], [50, 6]]) {
      const cl = [[16 - off * 0.2, 600 + off], [36 - off * 0.3, 690 + off * 0.4], [58 - off * 0.5, 770 + off * 0.3], [80 - off * 0.6, 850 + off * 0.2], [110 - off * 0.7, 915 + off * 0.2], [150 - off * 0.6, 965]];
      R.pipe(P(cl, false), w, '#dcdce2', 0.12, 0.07, 1);
    }
    for (let i = 0; i < 14; i++) {
      const t = i / 13, y = 630 + t * 310, x = 24 + t * t * 110 + fr() * 8;
      R.pipe(P([[x, y], [x - 16 - fr() * 10, y + 4 - fr() * 10]], false), 6, '#e0e0e6', 0.14, 0.06, 1);
    }

    const pil = [[27, 302], [55, 275], [136, 252], [227, 238], [273, 234], [309, 247], [345, 320], [382, 447], [436, 584], [473, 693], [482, 784], [464, 856], [400, 911], [309, 938], [227, 947], [150, 935], [118, 897], [94, 845], [74, 775], [52, 695], [28, 615], [18, 420]];
    // ── the spiky head behind (one eye) ──
    const head = P([[236, 240], [258, 205], [300, 175], [360, 152], [430, 145], [488, 150], [530, 172], [556, 215], [572, 270], [580, 330], [470, 340], [330, 320], [250, 300]], true, true);
    for (const [pts, w] of [[[[290, 188], [268, 184]], 12], [[[478, 146], [490, 120]], 10], [[[526, 182], [548, 162]], 8], [[[540, 196], [566, 186]], 8], [[[548, 214], [578, 218]], 8], [[[420, 146], [414, 130]], 7]])
      R.pipe(P(pts, false), w, '#e2e2e8', 0.14, 0.1, 1);
    R.dome(head, lin(300, 150, 520, 330, [[0, '#dcdce2'], [1, '#d0d0d8']]), 0.1, 0.3, 45, 1);
    clipA(head, () => soft(x => { x.lineWidth = 40; x.strokeStyle = '#7a7a84'; x.stroke(head); x.lineWidth = 60; x.strokeStyle = '#4a4a54'; x.stroke(P(pil, true, true)); }, 18, 0.6));
    // eye
    R.flat(circleP(386, 210, 38), '#0c0b0e', 0.36, 0);
    R.flat(circleP(386, 210, 33), '#f2f2f2', 0.36, 0);
    R.flat(circleP(386, 210, 28), '#101012', 0.36, 0);
    R.dome(circleP(386, 212, 21), '#0a0a0c', 0.36, 0.06, 12, 4);

    // ── the porous coral cage ──
    const coral = P([[402, 330], [440, 300], [490, 268], [530, 250], [566, 262], [592, 290], [604, 330], [622, 380], [645, 430], [660, 490], [668, 560], [676, 620], [660, 680], [630, 720], [590, 752], [545, 770], [505, 768], [480, 740], [462, 700], [470, 640], [480, 560], [462, 470], [430, 400]], true, true);
    R.dome(coral, '#e4e2e8', 0.08, 0.14, 26, 1);
    const holes = [[548, 378, 26, 42, 0.3], [512, 450, 34, 50, 0.2], [600, 515, 32, 56, 0.1], [560, 592, 22, 34, 0.1], [470, 400, 16, 30, 0.4], [520, 660, 28, 22, 0.2], [600, 640, 26, 30, 0.5],
      [640, 580, 12, 22, 0], [575, 700, 26, 18, 0.3], [510, 720, 20, 14, 0], [628, 690, 16, 14, 0], [600, 330, 12, 22, 0], [470, 560, 14, 24, 0], [636, 460, 10, 18, 0], [500, 330, 14, 12, 0],
      [540, 735, 14, 10, 0], [655, 640, 9, 14, 0], [492, 610, 10, 16, 0], [560, 285, 9, 7, 0], [452, 345, 10, 8, 0], [612, 418, 8, 14, 0]];
    const holeP = new Path2D();
    const hp = holes.map(([x, y, rx, ry, rot], i) => P(blob(x, y, rx * 1.12, ry * 1.12, 300 + i, 10, 0.16, rot)));
    for (const q of hp) holeP.addPath(q);
    // cavities: pink-lilac lattice with dark cells, shadowed at the top rim
    clipA(holeP, () => {
      a.fillStyle = lin(440, 300, 660, 760, [[0, '#d8a4b0'], [0.5, '#c6a6ba'], [1, '#b49ab0']]); a.fillRect(400, 240, 300, 560);
      a.fillStyle = '#2c2028';
      for (let y = 250; y < 790; y += 15) for (let x = 400 + (y % 30 ? 7 : 0); x < 700; x += 15) a.fill(ellipseP(x, y, 5, 4.2, 0.4));
      for (const [x, y, rx, ry, rot] of holes) { a.fillStyle = rad(x - rx * 0.3, y - ry * 0.5, Math.max(rx, ry) * 1.2, [[0, 'rgba(40,24,36,0.75)'], [1, 'rgba(40,24,36,0)']]); a.fill(ellipseP(x, y, rx, ry, rot)); }
    });
    R.h.save(); R.h.fillStyle = hc(0.05, 1); R.h.fill(holeP); R.h.restore();
    for (const q of hp) R.pipe(q, 9, '#ecebef', 0.16, 0.12, 1);
    clipA(coral, () => soft(x => { x.fillStyle = '#5a5060'; x.fill(ellipseP(640, 640, 70, 160, 0.2)); x.fill(ellipseP(560, 780, 120, 40, 0)); }, 30, 0.5));
    const cr = rng(17);
    for (let i = 0; i < 30; i++) {
      const t = cr(), y = 270 + t * 480, x = 596 + Math.sin(t * 3) * 40 + 46 * t;
      R.pipe(P([[x, y], [x + 18 + cr() * 14, y - 6 + cr() * 12]], false), 6, '#e0e0e6', 0.14, 0.08, 1);
    }

    // ── red light bar ──
    const bar = P([[372, 378], [402, 364], [496, 628], [470, 642]], true, false);
    R.flat(P([[360, 360], [412, 342], [512, 640], [470, 660]], true, false), '#f0b0b0', 0.08, 0);
    R.flat(bar, '#ec2c1c', 0.1, 0);

    // ── the big pillow ──
    const pillow = P(pil, true, true);
    R.dome(pillow, lin(150, 250, 330, 940, [[0, '#d4d4d8'], [0.5, '#cacad0'], [1, '#b4b4bc']]), 0.1, 0.5, 55, 1);
    clipA(pillow, () => soft(x => { x.lineWidth = 50; x.strokeStyle = '#6a6a74'; x.stroke(pillow); }, 22, 0.55));
    // seeds
    const seeds = [[209, 270], [277, 288], [45, 325], [109, 325], [238, 352], [341, 402], [36, 425], [173, 415], [245, 434], [277, 461], [123, 515], [218, 525], [309, 506],
      [373, 570], [77, 588], [327, 620], [123, 725], [236, 702], [382, 743], [436, 784], [245, 829], [123, 829], [355, 856], [209, 879], [364, 688], [300, 360], [60, 470], [410, 640]];
    const sr = rng(33);
    for (const [x, y] of seeds) {
      const rot = sr() * 3.14;
      R.flat(ellipseP(x, y, 9, 4.4, rot), '#c09a48', 0.5, 0);
      R.flat(ellipseP(x + Math.cos(rot) * 0.5, y + Math.sin(rot) * 0.5, 6.5, 2.2, rot), '#1a120c', 0.5, 0);
    }

    // ── frame band ──
    R.flat(frameOut, null, 0.0, 0);
    a.save(); a.lineWidth = 8; a.strokeStyle = '#f2df60'; a.stroke(notched(X0 - 4, Y0 - 4, X1 + 4, Y1 + 4, NR - 4)); a.lineWidth = 4.5; a.strokeStyle = '#fffff2'; a.stroke(notched(X0 - 4, Y0 - 4, X1 + 4, Y1 + 4, NR - 4)); a.restore();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.22, shin: 16, wrap: 0.3, ao: 0.6, rim: 0.2, grain: 0.05 }),     // 1 white clay
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4 }),
        E.mat({ dif: 0.7, spec: 0.8, shin: 40, metal: 0.3 }),
        E.mat({ dif: 1, spec: 1.2, shin: 80, coat: 0.3 })                                          // 4 gloss black
      ],
      light: [-0.35, 0.55, 0.75], lc: [0.72, 0.72, 0.76], amb: [0.4, 0.4, 0.44],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.6], envBot: [0.15, 0.14, 0.18], envK: [0.2, 0.8, 0.3, 0],
      rimC: [0.3, 0.3, 0.4], rimD: [0, 1, 0], r1: 1.5, r2: 10, k: [0, 0.6, 0.4, 150], shadow: [-6, 8, 0.5, 6]
    });

    // ── glows ──
    // red bar halo
    soft(x => { x.fillStyle = '#ff3a40'; x.fill(P([[352, 360], [414, 330], [520, 640], [466, 676]], true, false)); }, 26, 0.55, 'screen', o);
    soft(x => { x.fillStyle = '#ff9aa0'; x.fill(ellipseP(450, 330, 60, 40, 0)); x.fill(ellipseP(500, 690, 40, 50, 0)); }, 30, 0.45, 'screen', o);
    o.save(); o.clip(bar); o.fillStyle = lin(372, 378, 470, 642, [[0, '#f43020'], [1, '#ee2a1a']], o); o.fill(bar); o.restore();
    for (const [x, y, r] of [[405, 410, 9], [394, 393, 7], [464, 593, 9]]) {
      o.fillStyle = rad(x, y, r * 2.4, [[0, '#ffffd0'], [0.35, '#ffe040'], [0.7, 'rgba(255,180,40,0.5)'], [1, 'rgba(255,120,40,0)']], o); o.fill(circleP(x, y, r * 2.4));
    }
    // neon lines
    const neon = new Path2D();
    { const p = new Path2D(); p.arc(100, 432, 37, -0.4, 0.55, true); neon.addPath(p); }
    neon.addPath(P([[177, 333], [209, 316], [241, 330], [252, 376], [275, 404], [296, 440], [291, 482], [264, 497], [223, 493], [186, 478], [177, 430], [182, 385]], true, true));
    neon.addPath(P([[55, 668], [92, 650], [150, 622], [210, 600], [273, 584], [330, 562], [366, 541], [402, 522], [440, 510]], false, true));
    neon.addPath(P([[180, 586], [182, 650], [190, 720], [208, 778], [242, 797], [272, 777], [276, 730], [263, 668], [256, 614], [262, 588]], false, true));
    neon.addPath(ellipseP(378, 722, 40, 72, -0.12));
    neon.addPath(circleP(319, 821, 12));
    neon.addPath(P([[84, 632], [86, 670], [90, 712]], false, true));
    const knob = P([[160, 560], [178, 558], [190, 568], [186, 582], [168, 586], [156, 576]], true, true);
    soft(x => { x.lineWidth = 46; x.strokeStyle = '#9aa2ff'; x.stroke(neon); x.fillStyle = '#9aa2ff'; x.fill(knob); }, 20, 0.8, 'screen', o);
    soft(x => { x.lineWidth = 22; x.strokeStyle = '#e4e8ff'; x.stroke(neon); x.fill(knob); }, 7, 1, 'screen', o);
    o.save(); o.lineCap = o.lineJoin = 'round'; o.lineWidth = 9; o.strokeStyle = '#ffffff'; o.stroke(neon); o.fillStyle = '#fff'; o.fill(knob); o.restore();
    soft(x => { x.fillStyle = '#ff8090'; x.fill(ellipseP(470, 470, 50, 190, -0.35)); }, 40, 0.35, 'screen', o);
    // beam across the coral
    soft(x => { x.lineWidth = 30; x.strokeStyle = '#ffffff'; x.stroke(P([[430, 512], [520, 478], [600, 448], [650, 430]], false)); }, 12, 0.75, 'screen', o);
    // small lights
    for (const [x, y, r] of [[491, 226, 14], [282, 922, 16], [577, 304, 8]]) {
      o.fillStyle = rad(x, y, r, [[0, x === 577 ? 'rgba(255,90,120,0.9)' : 'rgba(255,255,255,1)'], [0.5, 'rgba(230,235,255,0.6)'], [1, 'rgba(200,210,255,0)']], o); o.fill(circleP(x, y, r));
    }
    // frame glow
    soft(x => { x.lineWidth = 10; x.strokeStyle = '#fff4a0'; x.stroke(notched(X0 - 4, Y0 - 4, X1 + 4, Y1 + 4, NR - 4)); }, 6, 0.6, 'screen', o);
    E.grain(0.04, 91);
  }
});
