'use strict';
// s05 — "Rubber totem cave": a chunky pink-and-orange rubber creature with a dark-blue oval eye,
// orange coiled tubing and a blue base with yellow zig-zags, wedged among lavender rock, a
// speckled navy wall, op-art stripes, a grey cave mouth and an orange polka-dot slab.
REC.register('s05', {
  w: 1024, h: 559,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const W = 1024, H = 559;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fillE = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const texIn = (path, cv, alpha = 1) => { a.save(); a.clip(path); a.globalAlpha = alpha; a.drawImage(cv, 0, 0, W, H); a.restore(); };
    const tube = (pts, w, col, h0 = 0.3, dh = 0.1, m = 4, closed = false) => R.pipe(P(pts, closed), w, col, h0, dh, m);

    // speckle textures
    const navyTex = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.05), g = hash(floor(px * 0.5)), s = step(0.985, hash(floor(px / 3.0)));
        vec3 c = mix(vec3(0.10, 0.11, 0.18), vec3(0.20, 0.22, 0.32), n);
        c *= 0.75 + 0.5 * g; c = mix(c, vec3(0.8, 0.85, 0.9), s * 0.6);
        return c;
      }`);
    const lavTex = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.02), g = hash(floor(px * 0.7));
        vec3 c = mix(vec3(0.50, 0.42, 0.70), vec3(0.62, 0.54, 0.80), n);
        return c * (0.88 + 0.22 * g);
      }`);
    const rockTex = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.03), g = hash(floor(px * 0.8)), m = fbm(px * 0.15);
        vec3 c = mix(vec3(0.30, 0.28, 0.30), vec3(0.62, 0.58, 0.62), n * 0.7 + m * 0.4);
        return c * (0.8 + 0.35 * g);
      }`);
    const caveTex = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float n = fbm(px * 0.025), g = hash(floor(px * 0.8));
        vec3 c = mix(vec3(0.12, 0.11, 0.12), vec3(0.42, 0.40, 0.42), n);
        c *= 0.8 + 0.3 * g;
        c = mix(c, vec3(0.03), smoothstep(90.0, 20.0, length(px - vec2(700.0, 470.0)) ) * 0.7);
        return c;
      }`);

    // ── base: lavender rock everywhere ──
    const full = rrect(-10, -10, W + 20, H + 20, 0);
    R.flat(full, '#9a88c4', 0.05, 1); texIn(full, lavTex);

    // ── orange backdrop behind the creature's head + diagonal orange stripe ──
    const orBack = P([[240, -10], [800, -10], [900, -10], [860, 30], [790, 80], [740, 130], [690, 180], [660, 230], [630, 290], [600, 300], [560, 300], [520, 280], [300, 200], [250, 80]]);
    R.flat(orBack, '#f06a18', 0.08, 2);
    // speckled navy wall (left block + diagonal band)
    const navyL = P([[160, -10], [330, -10], [300, 60], [270, 120], [250, 200], [240, 290], [200, 300], [170, 250], [150, 150]]);
    const navyR = P([[600, 40], [660, 20], [700, -10], [800, -10], [770, 40], [710, 100], [650, 150], [605, 172], [575, 140], [572, 80]]);
    for (const n of [navyL, navyR]) { R.dome(n, '#1e2030', 0.1, 0.03, 12, 3); texIn(n, navyTex); }
    // orange drips / pink spirals / green blobs on top
    tube([[560, -10], [555, 60], [560, 110]], 26, '#f2a038', 0.14, 0.06, 2);
    tube([[515, 0], [520, 50], [512, 90]], 12, '#c8c0f0', 0.14, 0.04, 2);
    R.dome(P([[575, 30], [600, 25], [612, 70], [606, 125], [585, 130], [575, 90]]), '#2ec040', 0.12, 0.06, 12, 2);
    R.dome(P([[340, 0], [382, 0], [385, 40], [370, 70], [345, 60]]), '#22b040', 0.12, 0.06, 12, 2);
    R.dome(P([[420, 10], [445, 10], [452, 50], [440, 60], [425, 50]]), '#26c048', 0.14, 0.05, 10, 2);
    for (const [x, y, r] of [[275, 45, 30], [470, 30, 32], [600, 170, 20]]) {
      R.dome(circleP(x, y, r), '#d86ac0', 0.12, 0.05, 10, 2);
      a.lineWidth = 5; a.strokeStyle = '#6a2a90'; a.beginPath(); for (let t = 0; t < 14; t += 0.2) { const rr = r * t / 14 * 0.95; a.lineTo(x + Math.cos(t) * rr, y + Math.sin(t) * rr); } a.stroke();
    }
    R.dome(P([[210, 0], [250, 0], [260, 30], [240, 40], [215, 25]]), '#f07030', 0.12, 0.05, 8, 2);
    tube([[560, 240], [620, 245], [650, 250], [640, 262], [600, 262]], 26, '#26b040', 0.14, 0.05, 2);
    tube([[560, 212], [610, 215]], 22, '#26b040', 0.14, 0.05, 2);
    R.dome(circleP(668, 142, 22), '#1ec0d0', 0.14, 0.04, 8, 2); R.flat(circleP(668, 142, 11), '#1e2030', 0.18, 2);
    R.dome(ellipseP(598, 180, 18, 16, 0), '#8a50b0', 0.14, 0.04, 8, 2);
    tube([[740, 0], [720, 30]], 10, '#20c0d0', 0.14, 0.04, 2);
    for (const [x, y] of [[248, 90], [240, 118], [720, 125], [735, 100], [200, 190], [188, 205]]) R.dome(ellipseP(x, y, 7, 10, 0.4), '#e8ecee', 0.14, 0.04, 4, 2);

    // ── purple rock with blue fingerprint arcs ──
    const lav = P([[612, 300], [660, 240], [730, 180], [800, 120], [880, 50], [950, -10], [960, -10], [900, 200], [860, 300], [870, 380], [850, 569], [615, 569], [608, 400]]);
    R.dome(lav, '#8a76bc', 0.1, 0.05, 30, 1); texIn(lav, lavTex);
    for (let i = 0; i < 12; i++) {
      const pts = []; for (let t = 0; t <= 1.001; t += 0.1) { const ang = -2.5 + t * 1.5, rr = 70 + i * 10; pts.push([850 + Math.cos(ang) * rr, 290 + Math.sin(ang) * rr * 0.8]); }
      R.groove(P(pts, false), 7, '#2228a8', 0.15, 0.02, 1, 1);
    }
    for (const d of [[[720, 300], [728, 330], [740, 350]], [[740, 290], [750, 320]], [[690, 305], [700, 320]]]) R.groove(P(d, false), 6, '#2a30b0', 0.15, 0.02, 1, 1);
    // grey cave
    const cave = P([[640, 360], [700, 345], [770, 350], [820, 380], [840, 440], [820, 540], [800, 559], [625, 559], [612, 470], [620, 400]]);
    R.flat(cave, '#303034', 0.02, 5); texIn(cave, caveTex);
    // ── orange polka-dot slab ──
    const orS = P([[900, 30], [990, 0], [1034, -10], [1034, 569], [840, 569], [860, 480], [820, 420], [800, 360], [820, 320], [880, 300], [890, 200], [880, 80]], true, false);
    R.dome(orS, '#f8740e', 0.2, 0.08, 16, 6);
    for (const [x, y, r, c] of [[995, 125, 25, '#3a40d0'], [912, 145, 22, '#3a40d0'], [915, 235, 38, '#2ec8d0'], [990, 370, 52, '#3a3cd0'], [910, 455, 20, '#6a50c0'],
      [965, 515, 22, '#6a50c0'], [900, 525, 20, '#3a40d0'], [1015, 250, 14, '#3a40d0']]) {
      R.dome(circleP(x, y, r + 5), '#b08ad0', 0.24, 0.02, 4, 6);
      R.dome(circleP(x, y, r), c, 0.24, 0.03, r * 0.5, 6);
    }

    // ── left: pink panel with squiggles, yellow rim, purple strip ──
    const pinkP = P([[-10, -10], [100, -10], [98, 205], [-10, 215]], true, false);
    R.dome(pinkP, '#e690c8', 0.2, 0.04, 10, 6);
    { const r = rng(5); a.save(); a.clip(pinkP); a.strokeStyle = '#1e2a40'; a.lineWidth = 4; a.lineCap = a.lineJoin = 'round';
      for (let i = 0; i < 40; i++) { let x = r() * 90, y = r() * 200; a.beginPath(); a.moveTo(x, y); for (let k = 0; k < 5; k++) { x += (r() - 0.5) * 24; y += (r() - 0.3) * 18; a.lineTo(x, y); } a.stroke(); } a.restore(); }
    R.pipe(P([[100, -10], [98, 205], [-10, 215]], false), 16, '#f4e030', 0.22, 0.05, 6);
    const pstrip = P([[108, -10], [165, -10], [165, 240], [150, 300], [120, 310], [108, 240]]);
    R.dome(pstrip, '#8c6cc8', 0.16, 0.04, 10, 1);
    R.dome(rrect(118, 20, 36, 205, 10), '#5a60d8', 0.2, 0.03, 8, 1);
    a.fillStyle = '#1a1a50'; for (let i = 0; i < 10; i++) a.fillRect(128, 40 + i * 18, 16, 3);
    tube([[112, -10], [110, 80], [115, 180], [120, 300]], 10, '#f07028', 0.24, 0.03, 2);
    // op-art stripes bottom-left
    const opP = P([[-10, 220], [60, 215], [80, 300], [70, 420], [60, 569], [-10, 569]], true, false);
    const op = E.fx(`
      vec3 fx(vec2 uv, vec2 px){
        float w = px.x + 14.0 * sin(px.y * 0.045) + 8.0 * sin(px.y * 0.11 + 1.0);
        float s = fract(w / 12.0);
        vec3 c = mix(vec3(0.20, 0.28, 0.78), vec3(0.70, 0.66, 0.92), smoothstep(0.35, 0.45, s) - smoothstep(0.8, 0.9, s));
        c = mix(c, vec3(0.25, 0.75, 0.85), step(0.93, s));
        return c;
      }`);
    R.flat(opP, '#5058c0', 0.18, 7); texIn(opP, op);
    R.dome(P([[-10, 290], [30, 290], [50, 320], [40, 355], [10, 360], [-10, 350]]), '#f0dc40', 0.2, 0.05, 12, 6);
    R.flat(ellipseP(20, 318, 10, 12, 0), '#e8a0c0', 0.25, 6);
    // grey rock with black scribbles
    const rock = P([[60, 230], [120, 250], [160, 280], [180, 330], [175, 420], [150, 480], [130, 569], [55, 569], [65, 450], [75, 320]]);
    R.dome(rock, '#7a7078', 0.1, 0.1, 30, 5); texIn(rock, rockTex, 0.9);
    { const r = rng(12); for (let i = 0; i < 9; i++) { const x = 85 + r() * 70, y = 340 + r() * 200; R.groove(P([[x, y], [x + 10, y - 8], [x + 18, y + 4], [x + 26, y - 6]], false), 5, '#101010', 0.18, 0.02, 5, 1); } }
    tube([[150, 290], [170, 360], [175, 440], [160, 520], [150, 569]], 20, '#a080d0', 0.16, 0.06, 1);

    // ── the creature ──
    const slab = P([[245, 140], [268, 95], [320, 74], [420, 70], [500, 78], [548, 100], [575, 140], [590, 290], [612, 300], [612, 569], [148, 569], [158, 420], [240, 405], [235, 300]]);
    R.dome(slab, '#9a80d8', 0.2, 0.08, 20, 1);
    const body = P([[265, 140], [285, 90], [330, 72], [420, 68], [500, 76], [540, 100], [558, 150], [560, 280], [560, 470], [520, 480], [300, 472], [262, 430], [258, 300]]);
    R.dome(body, '#f4a0c8', 0.28, 0.06, 20, 6);
    // blue base with yellow zig-zags
    const base = P([[185, 432], [260, 428], [300, 462], [540, 470], [548, 300], [596, 305], [598, 569], [192, 569]]);
    R.dome(base, '#2830b8', 0.28, 0.05, 14, 6);
    { const r = rng(7); a.save(); a.clip(base); for (let i = 0; i < 90; i++) { a.fillStyle = 'rgba(240,240,255,0.8)'; a.fill(circleP(180 + r() * 420, 440 + r() * 130, 1 + r() * 1.5)); } a.restore(); }
    for (const zz of [[[190, 470], [210, 455], [225, 480], [245, 460]], [[185, 520], [210, 510], [225, 530], [255, 515], [270, 540]], [[255, 480], [275, 465], [290, 485]],
      [[350, 470], [370, 490], [390, 475], [410, 500]], [[430, 470], [445, 500], [470, 485], [500, 510], [520, 490]], [[410, 530], [430, 550], [460, 535], [490, 560]],
      [[550, 300], [560, 340], [548, 380], [565, 420], [575, 470], [560, 520]], [[520, 540], [545, 520], [570, 545]]]) tube(zz, 16, '#e8e04c', 0.36, 0.05, 6);
    // camera-like white knob
    R.dome(rrect(265, 500, 85, 70, 18), '#1a1a1a', 0.34, 0.05, 10, 6);
    R.dome(rrect(275, 510, 65, 60, 14), '#e8e8e0', 0.36, 0.06, 12, 6);
    R.bead(308, 540, 18, '#f0e070', 0.4, 0.06, 6);
    R.dome(P([[560, 520], [610, 510], [640, 540], [630, 569], [555, 569]]), '#f47a18', 0.3, 0.08, 16, 4);

    // orange tubing: outline, coils, antennas, eye rings
    const OR = '#f47418';
    tube([[272, 420], [266, 300], [268, 180], [284, 120], [320, 90], [420, 82], [505, 90], [535, 130], [540, 250], [538, 440], [500, 462], [310, 458]], 20, OR, 0.34, 0.1, 4, true);
    for (let i = 0; i < 4; i++) { const y = 125 + i * 28; tube([[320, y + 8], [330, y - 6], [420, y - 10], [500, y - 4], [520, y + 12], [480, y + 20], [340, y + 18]], 16, OR, 0.36, 0.08, 4, true); }
    tube([[330, 80], [320, 50], [300, 20], [285, -10]], 16, OR, 0.34, 0.08, 4);
    tube([[490, 85], [498, 50], [515, 10], [520, -10]], 16, OR, 0.34, 0.08, 4);
    tube([[340, 240], [360, 225], [420, 222], [480, 236], [510, 260], [520, 300]], 14, OR, 0.36, 0.06, 4);
    tube([[272, 260], [300, 250], [335, 270], [340, 300], [325, 330], [300, 335]], 14, OR, 0.36, 0.06, 4);
    for (const [x, y, r] of [[300, 305, 26], [350, 385, 24], [500, 268, 20]]) {
      R.dome(circleP(x, y, r), '#2a3ac8', 0.34, 0.04, r * 0.4, 6);
      R.pipe(circleP(x, y, r + 10), 14, OR, 0.36, 0.06, 4);
    }
    R.pipe(ellipseP(445, 335, 72, 104, 0), 12, OR, 0.36, 0.06, 4);
    const eye = ellipseP(445, 335, 60, 92, 0.05);
    R.dome(eye, '#2632c0', 0.34, 0.05, 20, 7);
    { const r = rng(3); a.save(); a.clip(eye); for (let i = 0; i < 60; i++) { a.fillStyle = 'rgba(220,230,255,0.7)'; a.fill(circleP(390 + r() * 100, 250 + r() * 170, 0.8 + r())); } a.restore(); }
    R.bead(485, 322, 22, '#6adcb8', 0.4, 0.08, 6);
    R.bead(378, 248, 12, '#2a3ac8', 0.36, 0.04, 6);

    // ── soft light & shade painted into albedo ──
    soft(x => { fillE(x, 700, 470, 90, 70, 0, '#000'); fillE(x, 230, 300, 20, 150, 0, '#201830'); fillE(x, 600, 330, 20, 150, 0, '#302040'); }, 25, 0.5);
    soft(x => { fillE(x, 420, 130, 120, 50, 0, '#ffd0e8'); }, 30, 0.35);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 0.95, emis: 0.2, spec: 0.12, shin: 12, wrap: 0.3, grain: 0.3 }),              // lavender rock
        E.mat({ dif: 0.9, emis: 0.25, spec: 0.25, shin: 20, wrap: 0.3 }),                          // backdrop bits
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.3, shin: 20, grain: 0.5 }),                           // navy speckle
        E.mat({ dif: 0.9, emis: 0.25, spec: 0.35, shin: 30, wrap: 0.3 }),                          // orange tubing
        E.mat({ dif: 0.85, emis: 0.3, spec: 0.1, shin: 10, grain: 0.5 }),                          // rock / cave
        E.mat({ dif: 0.9, emis: 0.25, spec: 0.2, shin: 16, wrap: 0.35 }),                          // rubber
        E.mat({ dif: 0.9, emis: 0.2, spec: 0.4, shin: 30, wrap: 0.2 })                             // eye / stripes
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.8, 0.78, 0.76], amb: [0.26, 0.25, 0.28],
      envTop: [1, 0.98, 0.95], envHor: [0.5, 0.45, 0.5], envBot: [0.1, 0.08, 0.1], envK: [0.3, 0.8, 0.4, 0],
      shadow: [-6, 6, 0.55, 8], r1: 2, r2: 8, k: [0, 0.6, 0.4, 70]
    });
    E.grain(0.035, 5);
  }
});
