'use strict';
// g210 — "Porthole frog with zebra hat": a pale-blue clay creature with gold-ringed chrome eyes and a zebra cone hat,
// a red maw holding a white eyeball and green sponge, an orange porthole, golden frog hands and chrome bubbles.
REC.register('g210', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const lg = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, stops) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const lumps = (cx, cy, cl) => {
      const pts = [];
      for (let i = 0; i < 120; i++) {
        const t = i / 120 * 6.283, ux = Math.cos(t), uy = Math.sin(t); let best = 4;
        for (const [x, y, r] of cl) { const dx = x - cx, dy = y - cy, ud = ux * dx + uy * dy, d = ud * ud - dx * dx - dy * dy + r * r; if (d > 0) best = Math.max(best, ud + Math.sqrt(d)); }
        pts.push([cx + ux * best, cy + uy * best]);
      }
      return P(pts, true, false);
    };
    const chrome = (x, y, r) => R.dome(circleP(x, y, r), rg(x - r * 0.3, y - r * 0.4, 1, x, y, r, [[0, '#ffffff'], [0.35, '#d0d4de'], [0.65, '#5a6070'], [0.85, '#b0b8c8'], [1, '#e8ecf4']]), 0.3, Math.min(0.3, r * 0.006 + 0.06), r * 0.9, 3);

    // ── 1. slate ground, starry specks, glass coil ──
    R.flat(rrect(-10, -10, 600, 1050, 0), lg(578, 0, 200, 600, [[0, '#3e4e6c'], [0.5, '#5e6e88'], [1, '#6c7c96']]), 0, 0);
    soft(x => { fe(x, 420, 420, 160, 200, 0, '#6a82a4'); fe(x, 330, 230, 90, 120, 0, '#74849c'); }, 40, 0.8);
    { const r = rng(5); for (let i = 0; i < 90; i++) R.paint(circleP(300 + r() * 270, 80 + r() * 520, 0.6 + r() * 1.4), 'rgba(250,236,160,0.8)'); }
    R.flat(rrect(-10, -10, 600, 20, 0), '#040404', 0, 0);
    { const pts = []; for (let i = 0; i <= 60; i++) { const x = 70 + i * 8.6; pts.push(x, 28 + Math.sin(i * 1.2) * 14 + Math.max(0, x - 500) * 0.6); } R.pipe(Q(pts, true, false), 9, '#c8d4e0', 0.3, 0.1, 3); }

    // ── 2. blue sphere, pale body ──
    const sph = circleP(590, 1100, 290);
    R.dome(sph, rg(470, 920, 20, 590, 1100, 290, [[0, '#6aa4d6'], [0.6, '#5292d0'], [1, '#4a88c8']]), 0.06, 0.2, 60, 1);
    const body = Q([-10, 560, 60, 590, 120, 600, 200, 612, 260, 650, 350, 700, 430, 740, 500, 790, 530, 810, 420, 840, 340, 900, 300, 960, 280, 1040, -10, 1040], true);
    R.dome(body, rg(260, 900, 20, 230, 820, 330, [[0, '#f0f6fc'], [0.5, '#d4e4f2'], [0.8, '#b4cce4'], [1, '#98b6d6']]), 0.08, 0.3, 60, 1);

    soft(x => { fe(x, 220, 1010, 70, 26, 0, '#5c78a8'); }, 12, 0.9, 'source-over', body);

    // ── 3. creature head ──
    const head = Q([-10, 120, 60, 95, 140, 75, 170, 50, 215, 35, 250, 55, 258, 110, 242, 160, 252, 205, 290, 245, 330, 285, 350, 335, 342, 392, 300, 425, 262, 432, 220, 420, 150, 400, 100, 335, 60, 322, -10, 330]);
    R.dome(head, lg(0, 60, 300, 400, [[0, '#dce8f6'], [0.4, '#c4d6ec'], [0.8, '#a8bcd8'], [1, '#8ca2c4']]), 0.1, 0.3, 40, 1);
    soft(x => { fe(x, 240, 330, 45, 60, 0.2, '#f45868'); fe(x, 220, 300, 30, 30, 0, '#f06878'); }, 18, 0.95, 'source-over', head);
    // white cloud
    const cl = [[30, 75, 18], [60, 62, 18], [80, 55, 20], [110, 48, 18], [135, 62, 16], [40, 90, 20], [75, 95, 22], [110, 92, 18], [15, 120, 18], [45, 135, 16], [85, 130, 14], [10, 170, 14], [150, 40, 12]];
    R.dome(lumps(65, 95, cl), '#eef4fc', 0.3, 0.12, 12, 1);
    for (const [x, y, r] of cl) R.dome(circleP(x, y, r * 0.75), null, 0.38, 0.05, r * 0.7, 1);
    // gold brow bar
    R.pipe(Q([60, 205, 150, 135], true, false), 46, '#d8c88a', 0.36, 0.14, 5);
    R.dome(ellipseP(60, 205, 12, 16, -0.6), '#8a7a40', 0.5, 0.02, 4, 5);
    // grill cylinder + grey-blue tube + chrome drop
    R.pipe(Q([118, 290, 182, 252], true, false), 62, '#4a4c58', 0.32, 0.12, 3);
    { const r = rng(9); for (let i = 0; i < 40; i++) R.bead(110 + r() * 75, 240 + r() * 55, 1.6, '#8a8c98', 0.46, 0.02, 3); }
    R.pipe(Q([178, 300, 180, 330, 190, 360, 205, 380], true, false), 26, '#b0c0d8', 0.4, 0.12, 1);
    chrome(212, 390, 18);
    // eyes
    for (const [x, y, r] of [[205, 88, 50], [12, 236, 50]]) {
      R.dome(circleP(x, y, r), '#ece4c4', 0.36, 0.12, 10, 5);
      R.dome(circleP(x + 2, y + 6, r * 0.76), '#e0a820', 0.42, 0.06, 6, 5);
      for (let k = 0; k < 28; k++) { const t = 0.2 + k / 28 * 2.8; R.groove(Q([x + 2 + Math.cos(t) * r * 0.45, y + 6 + Math.sin(t) * r * 0.45, x + 2 + Math.cos(t) * r * 0.72, y + 6 + Math.sin(t) * r * 0.72], true, false), 1.6, '#1a1408', 0.48, 0.02, 5); }
      chrome(x - 2, y - 6, r * 0.6);
    }

    // ── 4. zebra cone hat ──
    const zeb = Q([-10, 332, 60, 312, 110, 322, 160, 342, 210, 366, 262, 400, 304, 440, 332, 466, 304, 520, 262, 570, 222, 604, 196, 616, 150, 570, 100, 525, 60, 492, -10, 470]);
    const ZB = E.fx(`
      // <zph>
      const float ZPHC[72] = float[72](-8.298,-7.913,-7.883,-7.927,-7.420,-5.977,-3.954,-1.790,0.552,-7.036,-6.189,-6.334,-6.561,-5.081,-3.423,-2.178,0.104,2.708,-5.419,-5.080,-4.271,-3.036,-1.758,-0.793,-0.882,2.215,4.675,-3.675,-4.055,-2.408,-1.225,-0.129,1.054,1.624,4.363,5.940,-2.906,-2.638,-1.359,-0.044,1.372,2.514,4.256,4.938,6.612,-2.317,-1.214,-0.042,0.371,1.790,4.442,6.410,6.910,7.838,-1.864,-0.436,0.817,2.120,4.893,7.197,8.377,9.087,9.675,-1.569,0.215,2.171,4.595,7.291,9.339,10.525,11.256,11.753);
      float zph(vec2 p){ vec2 u = clamp((p - vec2(0.0, 300.0)) / vec2(56.6667, 66.0000), vec2(0.), vec2(5.999, 4.999));
        ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
        vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
        vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
        float f = 0.;
        for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZPHC[(i.y + b) * 9 + i.x + a] * bx[a] * by[b];
        return f; }
      // </zph>
      vec3 fx(vec2 uv, vec2 p){
        float s = cos(6.2832 * zph(p));
        return mix(vec3(0.03, 0.03, 0.05), vec3(0.96, 0.97, 0.98), smoothstep(-0.15, 0.15, s)); }`);
    R.dome(zeb, '#ffffff', 0.14, 0.12, 22, 4);
    clipA(zeb, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(ZB); a.restore(); });

    // ── 5. red maw, teeth, eyeball, sponge, porthole ──
    const maw = Q([196, 620, 232, 572, 280, 520, 330, 470, 380, 470, 425, 520, 445, 600, 440, 690, 420, 750, 380, 790, 330, 795, 300, 760, 250, 700]);
    R.dome(maw, rg(330, 640, 10, 330, 640, 180, [[0, '#8a0c1e'], [0.7, '#6a0818'], [1, '#c01828']]), 0.1, 0.04, 8, 1);
    for (let i = 0; i < 13; i++) { const t = i / 12, x = 334 - t * 136, y = 478 + t * 140; R.dome(ellipseP(x + 6, y + 6, 9, 6, -0.9), '#f4ece4', 0.22, 0.05, 3, 5); }
    const sponge = Q([350, 500, 400, 498, 440, 540, 455, 600, 440, 660, 410, 690, 380, 670]);
    R.dome(sponge, '#c8dca8', 0.2, 0.06, 8, 1);
    { const r = rng(13); for (let i = 0; i < 120; i++) { const x = 350 + r() * 105, y = 500 + r() * 190; if (!a.isPointInPath(sponge, x * S, y * S)) continue; R.bead(x, y, 2.5 + r() * 2, '#d4e6b2', 0.28, 0.04, 1); } }
    const eyeb = ellipseP(338, 620, 66, 102, -0.25);
    R.dome(eyeb, rg(320, 590, 10, 338, 620, 100, [[0, '#ffffff'], [0.7, '#eef2f6'], [1, '#c8d4e0']]), 0.24, 0.16, 30, 1);
    R.pipe(Q([330, 606, 345, 660, 360, 720, 368, 760], true, false), 1.8, '#c01818', 0.42, 0.01, 1);
    R.pipe(Q([330, 606, 320, 560, 296, 520], true, false), 1.6, '#c01818', 0.42, 0.01, 1);
    R.dome(circleP(330, 606, 8), '#c01020', 0.42, 0.03, 3, 5);
    R.flat(circleP(330, 606, 3), '#100404', 0.45, 0);
    R.pipe(Q([350, 788, 390, 772, 438, 736], true, false), 18, '#d8d0f0', 0.3, 0.1, 1);
    // porthole
    const ring = ellipseP(223, 766, 128, 138, 0);
    R.dome(ring, '#d0a828', 0.2, 0.16, 8, 3);
    R.dome(ellipseP(225, 764, 118, 128, 0), '#08080c', 0.28, 0.06, 6, 2);
    R.dome(circleP(234, 752, 100), '#a8b8d8', 0.3, 0.04, 6, 1);
    R.dome(circleP(234, 750, 88), rg(220, 720, 10, 234, 750, 90, [[0, '#ff7018'], [0.8, '#fa5808'], [1, '#e84808']]), 0.32, 0.06, 20, 2);
    soft(x => { fe(x, 220, 860, 90, 26, 0, '#1a3a6c'); }, 6, 0.85, 'source-over', ellipseP(225, 764, 118, 128, 0));
    R.paint(Q([150, 690, 180, 672, 196, 700, 168, 718]), '#fffce0');
    R.paint(Q([200, 650, 238, 646, 236, 676, 204, 678]), '#fffce0');

    // ── 6. lavender feather ──
    const feather = Q([-10, 905, 80, 902, 150, 910, 220, 916, 258, 924, 240, 942, 200, 962, 150, 988, 100, 1012, 60, 1040, -10, 1040]);
    R.dome(feather, lg(0, 900, 0, 1024, [[0, '#a8a0e4'], [1, '#8a84d4']]), 0.12, 0.12, 14, 1);
    { const r = rng(17); for (let i = 0; i < 14; i++) { const x = r() * 200, y = 925 + r() * 80; R.pipe(Q([x, y, x + 20 + r() * 20, y - 4 - r() * 6], true, false), 2, '#e8e4fc', 0.3, 0.02, 1); } }
    chrome(255, 924, 8);

    // ── 7. golden frog hands ──
    const GH = '#d8c070';
    const hand = (px, py, pr, fingers, arm) => {
      const cl = [[px, py, pr]];
      for (const [fx, fy, w, br] of fingers) { const L = Math.hypot(fx - px, fy - py), n = Math.ceil(L / (w * 0.35)); for (let k = 1; k < n; k++) { const t = k / n; cl.push([px + (fx - px) * t, py + (fy - py) * t, w / 2 * (1 - 0.25 * t)]); } cl.push([fx, fy, br]); }
      if (arm) { const [x2, y2, w2] = arm; const n = 10; for (let k = 1; k <= n; k++) { const t = k / n; cl.push([px + (x2 - px) * t, py + (y2 - py) * t, w2 / 2]); } }
      R.dome(lumps(px, py, cl), rg(px - pr * 0.4, py - pr * 0.4, 2, px, py, pr * 3, [[0, '#f0dc88'], [0.5, '#dcc470'], [1, '#c8b064']]), 0.22, 0.2, 16, 1);
      for (const [fx, fy, w, br] of fingers) R.bead(fx - br * 0.2, fy - br * 0.25, br * 0.55, null, 0.3, 0.08, 1);
    };
    hand(500, 172, 34, [[455, 84, 24, 19], [438, 194, 22, 17], [452, 252, 20, 15], [530, 258, 20, 16]], [600, 120, 46]);
    hand(-8, 540, 48, [[77, 432, 26, 22], [104, 540, 22, 18], [62, 612, 22, 18]], null);
    hand(-6, 800, 38, [[34, 763, 26, 24], [128, 842, 22, 19], [70, 868, 18, 15]], null);
    soft(x => { fe(x, 22, 700, 26, 64, 0.3, '#6a6a58'); }, 6, 0.8);
    // long golden leg on the right
    const leg = Q([590, 228, 566, 260, 552, 330, 546, 420, 544, 520, 532, 600, 524, 680, 532, 740, 556, 776, 590, 790], true, false);
    R.pipe(leg, 58, '#cdbd78', 0.2, 0.16, 1);
    soft(x => { x.strokeStyle = '#a8a888'; x.lineWidth = 20; x.stroke(leg); }, 8, 0.5);
    R.bead(548, 372, 18, '#e0c870', 0.3, 0.14, 1);

    // ── 8. cream tentacles, doodles, orange flames, bubbles ──
    for (const [pts, w] of [[[282, 388, 350, 370, 420, 330, 480, 300, 545, 282], 15], [[300, 398, 380, 386, 450, 362, 520, 332], 10], [[440, 405, 500, 386, 548, 362], 10], [[360, 404, 430, 395], 7]]) {
      R.pipe(Q(pts, true, false), w + 4, '#3a4660', 0.18, 0.04, 1);
      R.pipe(Q(pts, true, false), w, '#ece4b8', 0.24, 0.1, 5);
    }
    soft(x => { x.strokeStyle = '#14141c'; x.lineWidth = 1.6; const r = rng(23); for (let i = 0; i < 9; i++) { const cx = 340 + r() * 40, cy = 425 + r() * 55; x.beginPath(); x.arc(cx, cy, 4 + r() * 4, r() * 6, r() * 6 + 4.5); x.stroke(); } }, 0.3, 1);
    for (const f of [[470, 520, 490, 500, 502, 515, 520, 498, 528, 520, 512, 540, 520, 560, 498, 556, 480, 546, 466, 548], [402, 760, 420, 748, 432, 728, 450, 736, 470, 722, 484, 742, 470, 760, 482, 784, 462, 790, 446, 808, 430, 794, 410, 800]])
      R.dome(Q(f, true), '#f46a10', 0.3, 0.04, 4, 5);
    for (const [x, y, r] of [[405, 77, 14], [344, 119, 10], [292, 161, 11], [379, 177, 26], [421, 132, 5], [360, 308, 16], [308, 344, 9], [414, 459, 32], [504, 443, 18], [262, 535, 9], [450, 570, 6], [540, 470, 6]]) chrome(x, y, r);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.45, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.08, rim: 0.2 }),                 // 1 clay
        E.mat({ dif: 1, spec: 1.2, shin: 80, wrap: 0.3, ao: 0.3, coat: 0.3 }),                             // 2 gloss
        E.mat({ dif: 0.8, metal: 0.3, spec: 1.3, shin: 70, wrap: 0.4, ao: 0.2, coat: 0.25, emis: 0.15 }), // 3 chrome
        E.mat({ dif: 0.6, spec: 0.5, shin: 40, wrap: 0.6, emis: 0.42, coat: 0.1 }),                        // 4 zebra
        E.mat({ dif: 1, spec: 1.0, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.2 }),                            // 5 beads / gloss
        E.mat({}), E.mat({})
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.72, 0.72, 0.76], amb: [0.42, 0.42, 0.46],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.1, 0.12, 0.16], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 70], shadow: [-5, 6, 0.45, 6]
    });
  }
});
