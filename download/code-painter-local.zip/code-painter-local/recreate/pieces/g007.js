'use strict';
// g007 — "Zebra chopper postcard": a custom motorcycle tank striped like a zebra, a painted landscape
// screen, an orange eye with a chrome pearl, purple glitter and lilac coral, a studded grey fender over a yellow tyre.
REC.register('g007', {
  w: 701, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, hx = R.h, S = E.S;
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const clipBoth = (path, fn) => { a.save(); hx.save(); a.clip(path); hx.clip(path); fn(); a.restore(); hx.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const sparkle = (path, n, seed, cols, rmax = 1.2) => clipA(path, () => { const r = rng(seed);
      for (let i = 0; i < n; i++) { a.fillStyle = cols[i % cols.length]; a.globalAlpha = 0.3 + r() * 0.7; a.beginPath(); a.arc(r() * 701, r() * 1024, 0.4 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1; });
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };

    // ── out-of-focus background ──
    R.flat(rrect(-10, -10, 721, 1044, 0), '#2a2624', 0, 0);
    soft(x => {
      x.fillStyle = '#f0e29a'; x.fill(P([[-10, -10], [160, -10], [170, 30], [120, 50], [60, 44], [-10, 50]]));
      x.fillStyle = '#a8d0cc'; x.fill(P([[-10, 50], [80, 40], [170, 60], [210, 90], [130, 130], [70, 200], [40, 280], [20, 360], [-10, 380]]));
      fe(x, 300, 20, 120, 40, 0, '#3a3634'); fe(x, 390, 24, 30, 24, 0, '#a8a4a0'); fe(x, 430, 60, 40, 20, 0, '#1a1818');
      x.fillStyle = '#5e8a3c'; x.fill(P([[560, -10], [711, -10], [711, 40], [620, 56], [590, 30]]));
      x.fillStyle = '#b89c18'; x.fill(P([[610, 70], [650, 46], [711, 40], [711, 120], [640, 118], [612, 100]]));
      fe(x, 650, 82, 14, 10, 0, '#151414'); fe(x, 690, 74, 10, 10, 0, '#151414'); fe(x, 640, 108, 10, 6, 0, '#151414');
      x.fillStyle = '#d0f0ec'; x.fill(P([[640, 120], [711, 110], [711, 200], [660, 180]]));
      x.fillStyle = '#121010'; x.fill(P([[-10, 600], [130, 610], [150, 1034], [-10, 1034]]));
    }, 5);
    // ribbed black/white tubes, top right
    for (const [x0, y0, x1, y1] of [[520, -10, 560, 100], [565, -10, 610, 100]]) {
      R.pipe(P([[x0, y0], [x1, y1]], false), 34, '#141414', 0.1, 0.12, 4);
      for (let t = 0.1; t < 1; t += 0.22) R.pipe(P([[x0 + (x1 - x0) * t, y0 + (y1 - y0) * t], [x0 + (x1 - x0) * (t + 0.08), y0 + (y1 - y0) * (t + 0.08)]], false), 34, '#e8e8e8', 0.1, 0.12, 4);
    }

    // ── mint panel and purple glitter field (right) ──
    R.dome(P([[420, 70], [560, 80], [711, 110], [711, 200], [620, 160], [480, 150], [430, 140]]), '#c4eae6', 0.06, 0.06, 20, 1);
    const purR = P([[470, 140], [560, 130], [640, 150], [711, 190], [711, 620], [640, 590], [560, 540], [490, 470], [460, 420], [480, 330], [470, 230]]);
    R.flat(purR, '#7050b0', 0.05, 6);
    sparkle(purR, 6000, 3, ['#b090f0', '#4a2a90', '#d8c8ff'], 1.2);
    const purL = P([[60, 420], [130, 400], [200, 420], [210, 600], [200, 700], [150, 720], [100, 690], [70, 620], [60, 520]]);
    R.flat(purL, '#7050b0', 0.05, 6);
    sparkle(purL, 2500, 4, ['#b090f0', '#4a2a90', '#d8c8ff'], 1.2);
    // lilac coral lattice: a lilac slab with inset Voronoi-cell holes
    { const cr = rng(17), seeds = [];
      for (let t = 0; t < 900 && seeds.length < 90; t++) { const q = [470 + cr() * 250, 130 + cr() * 400]; if (seeds.every(n => Math.hypot(n[0] - q[0], n[1] - q[1]) > 41)) seeds.push(q); }
      const clipPoly = (poly, nx, ny, c) => { const out = [];
        for (let i = 0; i < poly.length; i++) { const A = poly[i], B = poly[(i + 1) % poly.length], da = nx * A[0] + ny * A[1] - c, db = nx * B[0] + ny * B[1] - c;
          if (da <= 0) out.push(A); if ((da <= 0) !== (db <= 0)) { const t = da / (da - db); out.push([A[0] + (B[0] - A[0]) * t, A[1] + (B[1] - A[1]) * t]); } }
        return out; };
      const cmask = P([[516, 172], [570, 160], [640, 168], [711, 182], [711, 504], [640, 496], [606, 470], [588, 430], [572, 384], [548, 340], [526, 300], [512, 240]]);
      R.dome(cmask, '#ece4fa', 0.1, 0.1, 7, 2);
      const holes = new Path2D();
      for (const s0 of seeds) { let poly = [[s0[0] - 90, s0[1] - 90], [s0[0] + 90, s0[1] - 90], [s0[0] + 90, s0[1] + 90], [s0[0] - 90, s0[1] + 90]];
        for (const s1 of seeds) { if (s1 === s0) continue; const dx = s1[0] - s0[0], dy = s1[1] - s0[1], d = Math.hypot(dx, dy); if (d > 170) continue;
          const nx = dx / d, ny = dy / d; poly = clipPoly(poly, nx, ny, nx * (s0[0] + s1[0]) / 2 + ny * (s0[1] + s1[1]) / 2 - 7); if (poly.length < 3) break; }
        if (poly.length >= 3) holes.addPath(P(poly, true, true)); }
      clipBoth(cmask, () => { R.flat(holes, '#7050b0', 0.05, 6); });
      a.save(); a.clip(cmask); sparkle(holes, 1500, 8, ['#b090f0', '#4a2a90', '#d8c8ff'], 1.2); a.restore(); }

    // ── zebra tank: white dome with hand-traced black ribbons ──
    const tank = P([[10, 600], [4, 520], [6, 440], [16, 370], [28, 310], [45, 255], [75, 200], [110, 150], [150, 115], [200, 85], [260, 68], [330, 62], [400, 64], [450, 74], [480, 100], [470, 180], [420, 260], [350, 360], [250, 420], [170, 440], [110, 470], [70, 560], [40, 600]]);
    R.dome(tank, '#eceff4', 0.06, 0.24, 60, 2);
    const ribbon = (pts, ws) => { const L = [], Rr = [], n = pts.length;
      for (let i = 0; i < n; i++) { const p0 = pts[Math.max(0, i - 1)], p1 = pts[Math.min(n - 1, i + 1)]; let dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
        L.push([pts[i][0] - dy * ws[i] / 2, pts[i][1] + dx * ws[i] / 2]); Rr.push([pts[i][0] + dy * ws[i] / 2, pts[i][1] - dx * ws[i] / 2]); }
      return P([...L, ...Rr.reverse()], true, true); };
    clipA(tank, () => {
      a.fillStyle = '#0e1320';
      for (const [pts, ws] of [
        [[[80, 225], [62, 262], [50, 300], [44, 345], [42, 370], [45, 420], [57, 445], [62, 470], [65, 495], [54, 520], [60, 545], [58, 580], [50, 620]], [6, 14, 16, 20, 26, 36, 50, 50, 44, 22, 32, 24, 30]],
        [[[200, 100], [185, 120], [165, 145], [152, 170], [140, 195], [128, 220], [112, 245], [105, 270], [97, 295], [97, 320], [102, 345], [112, 370], [130, 400], [155, 430], [162, 445], [148, 470], [138, 495], [132, 520], [135, 545], [130, 580]], [10, 22, 40, 45, 50, 55, 45, 40, 25, 15, 15, 35, 45, 50, 35, 35, 35, 25, 40, 30]],
        [[[196, 74], [240, 70], [276, 84], [285, 98], [262, 120], [257, 145], [247, 170], [230, 195], [207, 220]], [10, 18, 34, 46, 50, 55, 55, 40, 25]],
        [[[316, 66], [356, 78], [380, 96], [348, 120], [340, 145], [335, 168]], [18, 34, 44, 40, 40, 40]],
        [[[420, 70], [408, 98], [400, 120], [395, 145], [392, 168]], [16, 20, 20, 20, 20]],
        [[[456, 78], [442, 110], [431, 145], [428, 168]], [18, 15, 12, 10]]
      ]) a.fill(ribbon(pts, ws));
    });

    // ── cream knob ──
    const knob = P([[118, 250], [160, 222], [220, 220], [270, 250], [300, 300], [300, 360], [260, 392], [190, 394], [140, 370], [112, 320]]);
    R.dome(knob, '#e4dccb', 0.14, 0.3, 50, 2);

    // ── painted landscape screen ──
    const scr = P([[204, 196], [230, 172], [320, 162], [440, 162], [488, 178], [508, 220], [500, 252], [440, 292], [330, 348], [282, 346], [252, 310], [214, 240]]);
    R.dome(scr, '#0c0e14', 0.18, 0.08, 10, 2);
    const pic = P([[222, 202], [244, 184], [320, 176], [440, 176], [480, 188], [494, 222], [488, 244], [436, 278], [330, 330], [290, 330], [262, 300], [232, 244]]);
    R.flat(pic, lin(0, 176, 0, 240, [[0, '#2f6ee0'], [0.6, '#6aa0ee'], [1, '#a0c4f4']]), 0.26, 1);
    clipA(pic, () => {
      const f = (c, pts) => { a.fillStyle = c; a.fill(P(pts, true, false)); };
      f('#2c5a2c', [[230, 236], [500, 222], [500, 262], [230, 280]]);
      f('#46536a', [[240, 258], [500, 246], [500, 340], [240, 340]]);
      const tr = rng(5); a.fillStyle = '#1c3a20';
      for (let i = 0; i < 30; i++) { const x = 380 + i * 4.2, h = 14 + tr() * 12; a.beginPath(); a.moveTo(x - 4, 226); a.lineTo(x, 226 - h); a.lineTo(x + 4, 226); a.fill(); }
      f('#d8b048', [[288, 244], [288, 206], [300, 200], [306, 186], [312, 200], [330, 206], [336, 244]]);
      f('#a07028', [[300, 214], [326, 214], [326, 222], [300, 222]]);
      a.fillStyle = '#226622'; a.fill(ellipseP(292, 214, 10, 14, 0));
      f('#eceef0', [[334, 236], [336, 224], [372, 220], [394, 228], [394, 246], [336, 250]]);
      f('#30343c', [[338, 238], [390, 236], [390, 242], [338, 244]]);
      f('#d82828', [[402, 238], [410, 228], [440, 226], [452, 234], [450, 242], [404, 244]]);
      a.fillStyle = '#f2f2f2'; a.fill(P(blob(338, 278, 52, 22, 9, 16, 0.3)));
      a.fillStyle = '#d02020'; a.fill(ellipseP(342, 272, 8, 6, 0)); a.fill(ellipseP(325, 284, 4, 3, 0));
      a.fillStyle = '#c0b0a0'; a.fill(ellipseP(410, 262, 12, 10, 0));
    });

    // ── bronze bracket, chrome disc, wheel ──
    // chrome pyramid
    R.dome(P([[300, 386], [440, 378], [454, 470], [400, 486], [330, 520], [262, 560], [250, 470]], true, false), lin(330, 380, 450, 500, [[0, '#a8b8d8'], [0.4, '#e8eef8'], [0.7, '#b0bcd4'], [1, '#8a94b0']]), 0.12, 0.2, 40, 7);
    const BR = '#8a6c48';
    R.pipe(P([[156, 720], [142, 640], [146, 540], [180, 470], [236, 428], [300, 410]], false), 44, BR, 0.1, 0.12, 5);
    R.pipe(P([[200, 610], [236, 540], [300, 500], [380, 484], [444, 494], [482, 524], [490, 566], [470, 600]], false), 30, BR, 0.12, 0.1, 5);
    for (const t of [3.6, 4.1, 4.6, 5.1, 5.6]) R.pipe(P([[355 + Math.cos(t) * 100, 660 + Math.sin(t) * 100], [355 + Math.cos(t) * 170, 660 + Math.sin(t) * 170]], false), 14, BR, 0.12, 0.08, 5);
    R.dome(circleP(232, 528, 78), '#8a96ac', 0.14, 0.14, 30, 7);
    for (const [x, y] of [[176, 528], [190, 504], [214, 494], [178, 556], [196, 586]]) R.bead(x, y, 8, '#d8dce4', 0.28, 0.06, 3);
    const wheel = circleP(355, 652, 102);
    R.dome(wheel, '#16141a', 0.12, 0.06, 6, 2);
    for (let i = 0; i < 12; i++) { const t = i / 12 * 6.2832; R.pipe(P([[355 + Math.cos(t) * 16, 676 + Math.sin(t) * 16], [355 + Math.cos(t + 0.3) * 92, 652 + Math.sin(t + 0.3) * 92]], false), 4, '#5a5a62', 0.2, 0.04, 3); }
    R.pipe(circleP(355, 652, 92), 6, '#4a4a52', 0.18, 0.05, 3);
    R.bead(352, 676, 16, '#808088', 0.2, 0.1, 3);

    // ── orange fan grid ──
    const OR = '#f88c1c';
    { const C = [305, 690], r0 = 96, r1 = 152, t0 = 2.62, t1 = 5.25, pts = [];
      for (let i = 0; i <= 30; i++) { const t = t0 + (t1 - t0) * i / 30; pts.push([C[0] + Math.cos(t) * r1, C[1] + Math.sin(t) * r1 * 0.95]); }
      for (let i = 30; i >= 0; i--) { const t = t0 + (t1 - t0) * i / 30; pts.push([C[0] + Math.cos(t) * r0, C[1] + Math.sin(t) * r0 * 0.95]); }
      const fan = P(pts, true, true);
      R.dome(fan, OR, 0.18, 0.1, 8, 2);
      for (let i = 1; i < 14; i++) { const t = t0 + (t1 - t0) * i / 14; R.groove(P([[C[0] + Math.cos(t) * (r0 + 10), C[1] + Math.sin(t) * (r0 + 10) * 0.95], [C[0] + Math.cos(t) * (r1 - 10), C[1] + Math.sin(t) * (r1 - 10) * 0.95]], false), 7, '#3a1808', 0.28, 0.12, 2); }
      clipBoth(fan, () => { const q = []; for (let i = 0; i <= 30; i++) { const t = t0 + (t1 - t0) * i / 30; q.push([C[0] + Math.cos(t) * 123, C[1] + Math.sin(t) * 123 * 0.95]); } R.pipe(P(q, false), 8, OR, 0.26, 0.06, 2); }); }
    // orange clamp + hook
    R.dome(P([[110, 576], [140, 556], [176, 560], [172, 584], [146, 590], [140, 610], [150, 630], [126, 636], [106, 610]]), OR, 0.14, 0.12, 10, 2);
    R.dome(P([[178, 744], [200, 734], [234, 740], [230, 762], [206, 760], [196, 784], [176, 780], [170, 760]]), OR, 0.14, 0.1, 8, 2);
    // yellow squiggle, pink coral
    { const pts = [[190, 444], [160, 444]]; for (let i = 0; i <= 16; i++) pts.push([128 - i * 1.2 + Math.sin(i * 1.6) * 9, 452 + i * 5.6]); R.pipe(P(pts, false), 8, '#d8d840', 0.2, 0.06, 2); }
    { const pr = rng(9); for (let i = 0; i < 40; i++) { const t = pr() * 6.28, rr = pr(); R.bead(224 + Math.cos(t) * rr * 34, 512 + Math.sin(t) * rr * 22, 4 + pr() * 4, '#e85898', 0.22, 0.04, 2); } }

    // ── orange eye with chrome pearl ──
    const eye = P([[356, 352], [380, 330], [430, 316], [490, 312], [540, 322], [572, 348], [580, 384], [570, 412], [552, 420], [548, 398], [560, 380], [548, 360], [520, 350], [540, 400], [510, 430], [460, 440], [416, 430], [384, 400], [366, 376]]);
    R.dome(eye, OR, 0.18, 0.14, 14, 2);
    R.bead(465, 374, 46, '#1c1a1e', 0.22, 0.06, 2);
    R.bead(465, 374, 30, '#dce4f0', 0.26, 0.22, 3);

    // ── grey studded fender plate ──
    const plate = P([[482, 446], [520, 480], [570, 528], [640, 576], [711, 610], [711, 790], [600, 794], [500, 812], [420, 852], [350, 920], [312, 980], [290, 960], [290, 780], [340, 750], [410, 712], [446, 660], [462, 560], [470, 480]]);
    R.dome(plate, '#bcbab6', 0.12, 0.06, 10, 4);
    soft(x => { fe(x, 450, 710, 50, 70, 0.3, '#d8c0a4'); fe(x, 660, 520, 50, 20, 0, '#d4bea6'); fe(x, 620, 668, 30, 26, 0, '#9070d0'); }, 4, 0.9);
    for (const [x, y, r] of [[502, 486, 13], [548, 497, 11], [516, 531, 13], [588, 545, 11], [551, 565, 13], [511, 596, 13], [582, 608, 14], [638, 617, 16], [542, 633, 16], [588, 676, 22], [437, 718, 13], [555, 717, 13], [627, 744, 18], [689, 750, 13], [507, 745, 14], [571, 769, 14], [526, 792, 11], [460, 798, 14], [414, 768, 15], [370, 780, 14], [319, 785, 13], [322, 828, 12], [345, 875, 14], [405, 850, 16]])
      R.bead(x, y, r, '#eef2f8', 0.2, 0.14, 7);

    // ── bottom-left motorcycle bits ──
    R.dome(P([[-10, 640], [60, 650], [120, 700], [150, 800], [150, 1044], [-10, 1044]]), '#0e0e10', 0.06, 0.1, 30, 2);
    clipBoth(P([[-10, 640], [60, 650], [120, 700], [150, 800], [150, 1044], [-10, 1044]]), () => {
      R.pipe(circleP(-30, 860, 160), 34, '#b8bcc4', 0.12, 0.08, 3);
      R.pipe(circleP(-30, 860, 118), 10, '#6a6e78', 0.12, 0.04, 3);
      R.pipe(P([[-10, 700], [40, 680], [90, 696], [130, 750]], false), 18, '#d8d4d4', 0.16, 0.06, 3); });
    R.dome(rrect(-10, 770, 90, 60, 10), '#e83a2c', 0.14, 0.08, 8, 2);
    R.pipe(P([[-10, 852], [80, 846], [176, 820]], false), 22, '#18181c', 0.2, 0.1, 2);
    R.dome(rrect(30, 832, 30, 56, 6), '#c8ccd4', 0.24, 0.08, 6, 7);
    R.pipe(P([[60, 640], [10, 760], [-10, 800]], false), 8, '#202024', 0.2, 0.06, 2);

    // ── lower zebra ──
    const lz = P([[80, 1044], [100, 930], [130, 810], [175, 760], [240, 748], [292, 770], [296, 900], [310, 1044]]);
    R.dome(lz, '#eceef2', 0.06, 0.14, 30, 2);
    const lzv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float f = p.x + 0.22 * (p.y - 1010.) * (1. - smoothstep(150., 250., p.x)) + 3. * sin(p.y * 0.05);
      float c = cos(6.2832 * (f - 112.) / 34.5);
      return vec3(1. - smoothstep(0.25, 0.45, c)); }`);
    clipA(lz, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(lzv); a.restore(); });

    // ── wheel rim, yellow tyre, chrome hub ──
    const WC = [672, 1190];
    R.dome(circleP(WC[0], WC[1], 395), '#0e0e10', 0.1, 0.12, 20, 2);
    R.dome(circleP(WC[0], WC[1], 350), '#f2e470', 0.1, 0.14, 34, 1);
    R.dome(circleP(WC[0], WC[1], 280), '#b8c4d0', 0.1, 0.12, 12, 3);
    clipBoth(circleP(WC[0], WC[1], 277), () => {
      R.dome(circleP(WC[0], WC[1], 255), '#2a2c34', 0.14, 0.02, 4, 3);
      for (let i = 0; i < 10; i++) { const t = -2.5 + i * 0.16; R.pipe(P([[WC[0] + Math.cos(t) * 100, WC[1] + Math.sin(t) * 100], [WC[0] + Math.cos(t + 0.25) * 262, WC[1] + Math.sin(t + 0.25) * 262]], false), 10, '#d8e0ea', 0.2, 0.06, 3); }
    });

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.25, shin: 20, wrap: 0.4, ao: 0.5 }),                                       // 1 matte paint
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.25, ao: 0.4, coat: 0.15, rim: 0.2 }),                   // 2 gloss enamel
        E.mat({ dif: 0.45, metal: 0.65, spec: 1.3, shin: 70, ao: 0.4, rim: 0.3 }),                           // 3 chrome
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.4, ao: 0.4, grain: 0.15 }),                             // 4 grey fender (satin)
        E.mat({ dif: 0.8, metal: 0.35, spec: 0.7, shin: 30, ao: 0.5, grain: 0.2, tint: [1.1, 0.9, 0.7] }),   // 5 bronze
        E.mat({ dif: 1, spec: 0.3, shin: 16, wrap: 0.5, grain: 0.5, ao: 0.4 }),                              // 6 glitter
        E.mat({ dif: 0.9, metal: 0.2, spec: 1.8, shin: 90, ao: 0.3, rim: 0.4, coat: 0.3 })                            // 7 bright chrome
      ],
      light: [0.2, 0.7, 0.68], lc: [0.85, 0.84, 0.82], amb: [0.36, 0.36, 0.38],
      envTop: [1.1, 1.08, 1.05], envHor: [0.6, 0.58, 0.6], envBot: [0.1, 0.1, 0.12], envK: [0.4, 1.0, 0.3, 0],
      rimC: [0.2, 0.2, 0.22], rimD: [0, 1, 0], r1: 1.4, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [2, 8, 0.6, 7]
    });
    E.bloom(0.12, 10);
    E.grain(0.025, 9);
  }
});
