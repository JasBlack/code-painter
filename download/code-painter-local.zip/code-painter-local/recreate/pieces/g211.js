'use strict';
// g211 — "Frowning mint spore": a frowning mint-jelly creature with a periwinkle porthole shell, zebra ring-eyes and a
// black-and-white spiral card, trailing grey ribbon tentacles over a violet-to-gold glitter backdrop.
REC.register('g211', {
  w: 578, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const Q = (f, sm = true, cl = true) => { const q = []; for (let i = 0; i < f.length; i += 2) q.push([f[i], f[i + 1]]); return P(q, cl, sm); };
    const L = f => Q(f, true, false);
    const img = (cv, alpha = 1, op = 'source-over') => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lg = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rg = (x0, y0, r0, x1, y1, r1, st) => { const g = a.createRadialGradient(x0, y0, r0, x1, y1, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (blur, fn, alpha = 1, clipP = null) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); if (clipP) a.clip(clipP); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    // ribbon polygon around a centre line (flat array), width w0 -> w1
    const ribbon = (f, w0, w1 = w0) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const n = c.length, l = [], r = [];
      for (let i = 0; i < n; i++) {
        const p0 = c[Math.max(0, i - 1)], p1 = c[Math.min(n - 1, i + 1)];
        let dx = p1[0] - p0[0], dy = p1[1] - p0[1]; const d = Math.hypot(dx, dy) || 1; dx /= d; dy /= d;
        const w = (w0 + (w1 - w0) * i / (n - 1)) / 2;
        l.push([c[i][0] - dy * w, c[i][1] + dx * w]); r.push([c[i][0] + dy * w, c[i][1] - dx * w]);
      }
      return P(l.concat(r.reverse()), true, true);
    };
    // wavy line along a centre line, offset sideways by off
    const wavy = (f, off, amp, wl, ph) => {
      const c = []; for (let i = 0; i < f.length; i += 2) c.push([f[i], f[i + 1]]);
      const out = []; let s = 0;
      for (let i = 0; i < c.length - 1; i++) {
        const [x0, y0] = c[i], [x1, y1] = c[i + 1], d = Math.hypot(x1 - x0, y1 - y0), nx = -(y1 - y0) / d, ny = (x1 - x0) / d;
        for (let t = 0; t < d; t += 2.5) { const u = (s + t) / wl * 6.283 + ph, k = off + amp * (Math.sin(u + 0.6 * Math.sin(u * 0.37)) * (0.8 + 0.3 * Math.sin(u * 0.21))); out.push([x0 + (x1 - x0) * t / d + nx * k, y0 + (y1 - y0) * t / d + ny * k]); }
        s += d;
      }
      return P(out, false, false);
    };

    // ── 1. background: fitted violet / black / gold field with glitter ──
    R.flat(rrect(-10, -10, 600, 1050, 0), null, 0, 0);
    img(E.fx(`
      const vec3 BGC[96] = vec3[96](vec3(1.056,0.906,0.403),vec3(0.613,0.508,0.121),vec3(0.196,0.141,-0.117),vec3(-0.114,-0.116,-0.217),vec3(-0.218,-0.186,-0.158),vec3(0.035,0.021,0.011),vec3(0.674,0.510,0.269),vec3(1.414,1.071,0.550),vec3(0.979,0.883,0.521),vec3(0.623,0.563,0.405),vec3(0.273,0.245,0.227),vec3(0.035,0.026,0.005),vec3(-0.089,-0.070,-0.033),vec3(0.156,0.114,0.069),vec3(0.754,0.552,0.252),vec3(1.223,0.897,0.409),vec3(0.880,0.831,0.596),vec3(0.594,0.576,0.629),vec3(0.328,0.328,0.585),vec3(0.175,0.179,0.264),vec3(0.114,0.106,0.100),vec3(0.332,0.243,0.125),vec3(0.670,0.474,0.198),vec3(0.935,0.654,0.244),vec3(0.758,0.735,0.644),vec3(0.531,0.525,0.698),vec3(0.352,0.360,0.696),vec3(0.281,0.298,0.426),vec3(0.252,0.239,0.219),vec3(0.315,0.242,0.131),vec3(0.441,0.298,0.096),vec3(0.623,0.396,0.069),vec3(0.641,0.627,0.694),vec3(0.474,0.473,0.720),vec3(0.361,0.378,0.688),vec3(0.331,0.352,0.477),vec3(0.299,0.288,0.267),vec3(0.296,0.235,0.117),vec3(0.333,0.211,0.012),vec3(0.413,0.220,-0.073),vec3(0.564,0.553,0.735),vec3(0.433,0.437,0.738),vec3(0.358,0.374,0.648),vec3(0.322,0.335,0.432),vec3(0.287,0.274,0.244),vec3(0.276,0.217,0.087),vec3(0.298,0.178,-0.041),vec3(0.344,0.156,-0.153),vec3(0.567,0.556,0.741),vec3(0.433,0.438,0.732),vec3(0.348,0.362,0.628),vec3(0.275,0.285,0.388),vec3(0.240,0.225,0.200),vec3(0.257,0.192,0.059),vec3(0.320,0.188,-0.056),vec3(0.409,0.201,-0.159),vec3(0.666,0.650,0.713),vec3(0.457,0.462,0.711),vec3(0.312,0.330,0.642),vec3(0.223,0.237,0.381),vec3(0.197,0.182,0.187),vec3(0.254,0.179,0.060),vec3(0.398,0.242,-0.026),vec3(0.576,0.335,-0.097),vec3(0.838,0.819,0.697),vec3(0.543,0.541,0.685),vec3(0.296,0.311,0.666),vec3(0.208,0.224,0.446),vec3(0.204,0.185,0.249),vec3(0.297,0.208,0.111),vec3(0.536,0.352,0.053),vec3(0.790,0.520,0.018),vec3(1.016,1.002,0.748),vec3(0.719,0.712,0.692),vec3(0.398,0.405,0.673),vec3(0.272,0.282,0.574),vec3(0.300,0.269,0.381),vec3(0.442,0.336,0.232),vec3(0.709,0.513,0.180),vec3(0.962,0.690,0.158),vec3(1.142,1.145,0.857),vec3(0.901,0.898,0.773),vec3(0.654,0.647,0.676),vec3(0.492,0.476,0.603),vec3(0.492,0.440,0.497),vec3(0.618,0.509,0.401),vec3(0.825,0.650,0.348),vec3(1.048,0.804,0.309),vec3(1.249,1.271,0.970),vec3(1.070,1.073,0.845),vec3(0.906,0.887,0.723),vec3(0.772,0.728,0.643),vec3(0.731,0.657,0.598),vec3(0.796,0.685,0.559),vec3(0.932,0.775,0.515),vec3(1.101,0.892,0.466));
vec3 bg(vec2 p){ vec2 u = clamp(p / vec2(115.6000, 113.7778), vec2(0.), vec2(4.999, 8.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  vec3 f = vec3(0.);
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += BGC[(i.y + b) * 8 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){
        vec3 c = bg(p);
        float gold = smoothstep(380., 520., p.x + 0.25 * p.y - 0.05 * max(0., p.y - 600.));
        float sp = hash(floor(p * 1.1));
        c *= mix(1., 0.75 + 0.5 * sp, gold);
        float dk = smoothstep(0.55, 0.0, length((p - vec2(530., 250.)) / vec2(70., 120.)));
        c = mix(c, c * (0.35 + 1.6 * step(0.93, sp)), dk * 0.6);
        c += (hash(p * 1.7) - 0.5) * 0.03;
        return c; }`));

    // ── 2. right-hand grey pipes and the ribbed band ──
    R.pipe(L([546, -6, 552, 36, 565, 70, 580, 100, 592, 118]), 9, '#8c9098', 0.2, 0.12, 4);
    R.pipe(L([596, 140, 572, 172, 545, 220, 520, 272]), 8, '#9a9ea8', 0.2, 0.1, 4);
    const rib = Q([540, 375, 560, 362, 590, 356, 590, 570, 540, 562, 512, 552, 528, 520, 540, 470, 544, 410]);
    R.dome(rib, lg(520, 330, 578, 560, [[0, '#8d9198'], [1, '#6c6f78']]), 0.1, 0.12, 12, 4);
    for (let i = 0; i < 7; i++) { const y = 392 + i * 12; R.groove(L([548, y, 574, y - 6]), 5, '#2a2a30', 0.2, 0.08, 4); }
    for (let i = 0; i < 6; i++) { const x = 530 + i * 9; R.groove(L([x, 500, x + 6, 545]), 5, '#2a2a30', 0.2, 0.08, 4); }

    // ── 3. lavender backing behind the head ──
    const lav = Q([250, 340, 244, 260, 250, 200, 272, 150, 305, 112, 335, 116, 360, 150, 420, 212, 470, 236, 510, 248, 526, 280, 522, 316, 470, 322, 380, 340, 290, 356]);
    R.dome(lav, lg(240, 120, 520, 330, [[0, '#9d9be0'], [0.5, '#a6a4e6'], [1, '#9896dc']]), 0.04, 0.03, 6, 6);

    // ── 4. fan shadow and grey ribbon tentacles ──
    a.save(); a.fillStyle = lg(0, 580, 0, 1024, [[0, 'rgba(10,9,14,0.95)'], [0.55, 'rgba(14,13,22,0.85)'], [0.8, 'rgba(40,40,80,0.45)'], [1, 'rgba(80,80,120,0.0)']]);
    a.filter = `blur(${6 * S}px)`; a.fill(Q([252, 650, 300, 580, 470, 580, 472, 800, 500, 880, 540, 960, 590, 1010, 590, 1040, 150, 1040, 190, 940, 230, 860, 252, 780], false)); a.restore();
    const strips = [
      [[338, 590, 316, 650, 300, 700, 262, 800, 227, 880, 194, 950, 158, 1035], 30],
      [[350, 590, 340, 650, 333, 700, 323, 800, 314, 880, 302, 950, 294, 1035], 36],
      [[386, 580, 382, 650, 378, 700, 371, 800, 374, 880, 380, 950, 388, 1035], 38],
      [[420, 575, 414, 650, 412, 700, 416, 800, 436, 880, 446, 950, 463, 1035], 30],
      [[452, 570, 458, 650, 462, 720, 474, 810, 486, 880, 512, 950, 560, 1035], 40]
    ];
    strips.forEach(([f, w], k) => {
      R.dome(ribbon(f, w * 0.85, w), lg(0, 580, 0, 1024, [[0, '#a8b6b8'], [0.25, '#949ca2'], [0.6, '#8c9098'], [1, '#a8aaa8']]), 0.06, 0.08, w * 0.4, 4);
      for (const s of [-1, 1]) R.pipe(wavy(f, s * w * 0.22, 4.6, 30 + k * 3, k * 1.7 + (s > 0 ? 2 : 0)), 4.2, '#d4d8c4', 0.15, 0.04, 5);
    });

    // ── 5. tendrils on the left ──
    const TM = '#d2e2cc';
    R.pipe(L([232, 398, 205, 360, 180, 330, 160, 310, 133, 300, 108, 304, 92, 322, 88, 348, 97, 368, 113, 377, 124, 368]), 12, TM, 0.15, 0.12, 5);
    R.bead(122, 368, 8, TM, 0.18, 0.1, 5);
    R.pipe(L([215, 440, 180, 448, 150, 462, 120, 492, 98, 530, 82, 570, 70, 610, 66, 642, 76, 664, 90, 666, 96, 656]), 10, TM, 0.15, 0.1, 5);
    R.bead(95, 655, 7, TM, 0.18, 0.08, 5);

    // ── 6. spiral card ──
    const rquad = (pts, r) => { const p = new Path2D(), n = pts.length; const m0 = [(pts[0][0] + pts[n - 1][0]) / 2, (pts[0][1] + pts[n - 1][1]) / 2]; p.moveTo(m0[0], m0[1]);
      for (let i = 0; i < n; i++) { const c = pts[i], nx = pts[(i + 1) % n]; p.arcTo(c[0], c[1], nx[0], nx[1], r); } p.closePath(); return p; };
    const cardO = rquad([[437, 562], [574, 540], [568, 812], [402, 782]], 24);
    const card = rquad([[441, 566], [569, 546], [561, 803], [407, 776]], 20);
    R.dome(cardO, '#9a9ca2', 0.1, 0.06, 6, 4);
    R.flat(card, '#f2f2f0', 0.14, 6);
    clipA(card, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(487.8, 667.2); d.y *= 0.838;
      float f = length(d) / 24.2 + 0.0726 * atan(d.y, d.x) / 6.2832 - 0.1857;
      float v = cos(6.2832 * f);
      vec3 bl = vec3(0.04, 0.035, 0.04) + step(0.985, hash(floor(p * 1.5))) * 0.35;
      return mix(bl, vec3(0.96, 0.955, 0.95), smoothstep(-0.12, 0.12, v)); }`)));

    // ── 7. white disc ──
    R.dome(ellipseP(186, 726, 59, 64, 0), '#9ea6b8', 0.02, 0.04, 6, 2);
    R.dome(ellipseP(185, 723, 54, 59, 0), rg(170, 700, 5, 185, 723, 60, [[0, '#e4eceb'], [0.7, '#cfd8d9'], [1, '#b6c0c4']]), 0.06, 0.2, 30, 2);

    // ── 8. the mint body ──
    const mintA = lg(0, 330, 0, 640, [[0, '#a8cfd0'], [0.3, '#bcdcd0'], [1, '#c8e0c4']]);
    // left lobe (zebra eye + grey disc)
    const lobe = Q([272, 300, 300, 328, 345, 335, 352, 380, 342, 430, 336, 480, 342, 525, 362, 548, 335, 566, 300, 560, 288, 584, 276, 608, 260, 630, 236, 636, 210, 626, 191, 604, 183, 574, 192, 542, 197, 508, 190, 470, 197, 428, 216, 402, 246, 390, 262, 368, 268, 338]);
    R.dome(lobe, mintA, 0.1, 0.22, 26, 1);
    soft(10, x => { fe(x, 300, 470, 10, 60, 0, '#d8e4a8'); fe(x, 250, 545, 40, 14, 0, '#d4e0a8'); fe(x, 196, 470, 8, 50, 0, '#d0e0b0'); }, 0.6, lobe);
    // knob on a neck
    R.dome(Q([362, 186, 368, 165, 374, 146, 386, 138, 400, 140, 404, 156, 410, 172, 414, 190]), '#cce0b8', 0.12, 0.12, 10, 1);
    R.dome(circleP(394, 104, 46), rg(380, 80, 5, 394, 104, 48, [[0, '#e8ece8'], [0.55, '#ccd2c8'], [0.85, '#d6cc88'], [1, '#d0c068']]), 0.16, 0.22, 30, 3);
    { const r = rng(211); for (let i = 0; i < 140; i++) { const t = r() * 6.283, rr = Math.sqrt(r()) * 40; R.bead(394 + Math.cos(t) * rr, 104 + Math.sin(t) * rr * 0.95, 1.6 + r() * 1.6, null, 0.36, 0.03, 3); } }
    // ear bump
    R.dome(circleP(425, 186, 27), rg(418, 176, 3, 425, 186, 28, [[0, '#a8c8dc'], [1, '#88aec4']]), 0.12, 0.16, 18, 1);
    // shell rim + shell
    const shellO = Q([334, 388, 356, 350, 388, 330, 419, 320, 450, 314, 481, 311, 512, 320, 533, 350, 545, 390, 545, 440, 535, 492, 514, 525, 488, 545, 450, 554, 406, 554, 368, 549, 342, 528, 330, 490, 326, 445]);
    R.dome(shellO, lg(330, 300, 545, 560, [[0, '#d6e2b4'], [0.5, '#e0e0a0'], [1, '#d8d890']]), 0.12, 0.18, 14, 1);
    const shell = Q([346, 392, 364, 362, 392, 344, 421, 334, 450, 329, 479, 327, 506, 335, 524, 360, 533, 394, 533, 440, 524, 486, 505, 514, 482, 532, 448, 540, 408, 540, 375, 535, 354, 518, 343, 486, 340, 445]);
    R.dome(shell, lg(340, 330, 530, 540, [[0, '#8ea6cc'], [0.5, '#7890c2'], [1, '#6c84b8']]), 0.2, 0.06, 10, 2);
    // head
    const hp = []; for (let i = 0; i < 28; i++) { const t = i / 28 * 6.283, w = 1 + 0.04 * Math.sin(3 * t + 1) + 0.03 * Math.cos(5 * t); hp.push([355 + Math.cos(t) * 90 * w, 256 + Math.sin(t) * 79 * w]); }
    const head = P(hp, true, true);
    R.dome(head, rg(330, 225, 10, 355, 255, 100, [[0, '#b0d4e0'], [0.6, '#9cc4cc'], [1, '#88b4b8']]), 0.14, 0.26, 40, 1);
    soft(14, x => { fe(x, 410, 310, 40, 20, -0.3, '#d8dc9a'); fe(x, 290, 300, 18, 30, 0, '#c8dcb8'); }, 0.7, head);
    // spine
    const spine = [322, 340, 321, 400, 320, 460, 321, 530, 322, 600, 321, 680, 320, 760, 322, 830, 323, 855];
    { const r = rng(5); for (const sd of [-1, 1]) { const pts = []; for (let y = 345; y < 852; y += 5) { const x0 = 321 + sd * 9; pts.push([x0, y]); pts.push([x0 + sd * (3 + r() * 9), y + 2.5 + (r() - 0.5) * 3]); } pts.push([321, 852]); pts.push([321, 345]);
      R.dome(P(pts, true, false), '#dde2b0', 0.2, 0.04, 2, 1); } }
    R.dome(ribbon(spine, 22, 18), lg(0, 340, 0, 860, [[0, '#c8e0cc'], [1, '#cddcb8']]), 0.2, 0.08, 9, 1);
    // arms / legs
    R.pipe(L([350, 548, 390, 548, 430, 548, 458, 556, 470, 575, 470, 605, 462, 632, 466, 652, 478, 662]), 18, '#c8e0c4', 0.2, 0.12, 1);
    R.pipe(L([352, 560, 354, 600, 350, 640, 352, 676]), 14, '#c4dcc0', 0.2, 0.1, 1);
    R.pipe(L([366, 600, 372, 650, 388, 710, 406, 760, 420, 798]), 12, '#c6dcc0', 0.2, 0.1, 1);

    // ── 9. face ──
    for (const [x, y] of [[300, 268], [387, 270]]) {
      R.dome(ellipseP(x, y, 10, 11, 0), '#c0bce0', 0.36, 0.04, 4, 5);
      R.dome(circleP(x + 1, y + 1, 6.5), '#1c1830', 0.4, 0.03, 3, 5);
      R.paint(circleP(x - 1.5, y - 2, 2), '#f0f0ff');
    }
    R.pipe(L([284, 252, 298, 248, 314, 254]), 4, '#2a2830', 0.38, 0.02, 0);
    R.pipe(L([371, 255, 388, 250, 404, 256]), 4, '#2a2830', 0.38, 0.02, 0);
    R.pipe(L([302, 304, 316, 297, 330, 298, 346, 302, 360, 310]), 5, '#1c1820', 0.38, 0.02, 0);
    R.pipe(L([306, 311, 330, 306, 356, 316]), 3, '#e0e4c0', 0.4, 0.02, 1);
    { const r = rng(9); for (let i = 0; i < 26; i++) { const t = r() * 6.283, rr = Math.sqrt(r()) * 75, x = 355 + Math.cos(t) * rr, y = 250 + Math.sin(t) * rr * 0.8; if (Math.hypot(x - 300, y - 268) < 18 || Math.hypot(x - 387, y - 270) < 18 || (y > 290 && y < 318 && x > 295 && x < 365)) continue; R.dome(ellipseP(x, y, 2.2, 3.5, r()), '#e8ecb0', 0.42, 0.03, 2, 5); } }

    // ── 10. shell details ──
    for (const [x, y, r] of [[469, 331, 14], [494, 346, 7], [453, 365, 11], [481, 374, 9], [505, 359, 9], [503, 402, 15], [406, 362, 11]]) {
      R.dome(circleP(x, y, r + 3), '#e4e09c', 0.26, 0.04, 3, 1);
      R.flat(circleP(x, y, r), '#1e2030', 0.18, 2);
    }
    for (const [x, y, r] of [[366, 393, 20], [344, 431, 15], [375, 449, 10], [497, 456, 12], [490, 487, 11], [459, 509, 14], [419, 518, 14], [396, 482, 7], [470, 470, 5], [420, 490, 5]])
      R.bead(x, y, r, '#9ab2d8', 0.22, r * 0.012, 7);
    R.dome(circleP(436, 425, 42), rg(425, 410, 10, 436, 425, 44, [[0, '#f0f2f6'], [0.55, '#b4b8c4'], [0.8, '#e4e8ee'], [1, '#8c909c']]), 0.24, 0.12, 16, 3);
    R.flat(circleP(437, 424, 24), '#060506', 0.2, 0);
    R.flat(Q([350, 495, 362, 488, 372, 494, 386, 492, 390, 506, 382, 520, 386, 532, 370, 534, 358, 528, 346, 520, 348, 506]), '#050405', 0.2, 0);

    // ── 11. zebra ring-eye and grey disc on the lobe ──
    const zo = ellipseP(241, 473, 45, 61, 0.08);
    R.dome(ellipseP(241, 473, 49, 65, 0.08), '#e8ece4', 0.3, 0.04, 4, 6);
    R.flat(zo, '#ffffff', 0.32, 6);
    clipA(zo, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(240., 472.); d.y *= 0.76;
      float f = length(d) / 7.4 + 0.5 * fbm(p * 0.05) + 0.1 * atan(d.y, d.x);
      float v = cos(6.2832 * f);
      return mix(vec3(0.04), vec3(0.95, 0.95, 0.93), smoothstep(-0.2, 0.2, v)); }`)));
    R.dome(circleP(232, 577, 28), '#b8bcbc', 0.28, 0.06, 6, 6);
    clipA(circleP(232, 577, 26), () => { a.lineWidth = 1.1; a.strokeStyle = 'rgba(70,70,75,0.55)'; for (let r = 3; r < 27; r += 3.4) { a.beginPath(); a.ellipse(231, 576, r, r * 0.95, 0, 0, 6.283); a.stroke(); } });
    // bristles
    { const r = rng(17);
      const fringe = (cx, cy, rad, t0, t1, n, len) => { for (let i = 0; i < n; i++) { const t = t0 + (t1 - t0) * r(), l = len * (0.6 + r() * 0.6); R.pipe(L([cx + Math.cos(t) * rad, cy + Math.sin(t) * rad, cx + Math.cos(t) * (rad + l), cy + Math.sin(t) * (rad + l)]), 1.6, '#e8e4a0', 0.2, 0.02, 5); } };
      fringe(232, 585, 48, 1.6, 3.4, 70, 12); fringe(352, 255, 90, 3.6, 4.2, 40, 12); fringe(440, 248, 12, -0.6, 0.6, 10, 10); }

    // ── 12. droplets ──
    for (const [x, y, r] of [[153, 228, 8], [243, 237, 5], [30, 463, 9], [128, 404, 6], [162, 268, 4], [196, 405, 4], [47, 330, 2.5], [92, 446, 3], [113, 433, 3], [92, 620, 3], [89, 698, 4], [106, 743, 4], [120, 773, 5], [128, 744, 2.5], [210, 307, 3], [262, 157, 4]])
      R.bead(x, y, r, '#d4d8e8', 0.2, Math.min(0.2, r * 0.03), 7);
    R.dome(Q([150, 212, 158, 226, 160, 236, 152, 242, 144, 236, 146, 224]), '#d4d8e8', 0.2, 0.12, 6, 7);
    R.dome(Q([254, 148, 266, 158, 268, 172, 260, 176, 252, 166]), '#a8b0e0', 0.1, 0.05, 4, 6);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 50, wrap: 0.5, ao: 0.3, coat: 0.2, rim: 0.2 }),                  // 1 mint jelly
        E.mat({ dif: 1, spec: 0.7, shin: 40, wrap: 0.4, ao: 0.4, coat: 0.1 }),                             // 2 blue shell / disc
        E.mat({ dif: 0.8, spec: 1.4, shin: 60, wrap: 0.3, metal: 0.5, coat: 0.2 }),                         // 3 chrome / knob
        E.mat({ dif: 1, spec: 0.6, shin: 30, wrap: 0.4, ao: 0.4 }),                                        // 4 grey ribbons
        E.mat({ dif: 0.8, spec: 0.6, shin: 40, wrap: 0.5, emis: 0.2 }),                                    // 5 cream piping
        E.mat({ dif: 0.6, spec: 0.4, shin: 40, wrap: 0.6, emis: 0.4 }),                                    // 6 card / zebra
        E.mat({ dif: 1, spec: 1.3, shin: 80, wrap: 0.3, coat: 0.3 })                                       // 7 droplets / bubbles
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.75, 0.75, 0.78], amb: [0.45, 0.45, 0.48],
      envTop: [1.05, 1.02, 1.0], envHor: [0.55, 0.6, 0.66], envBot: [0.15, 0.18, 0.24], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.2, 0.3, 0.4], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 80], shadow: [-5, 6, 0.5, 6]
    });
  }
});
