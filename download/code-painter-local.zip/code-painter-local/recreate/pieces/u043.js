'use strict';
// u043 — "Crackle island lounge": a black crackle-glazed island with a grey T-shaped console and a rainbow
// river, floating on a blue star carpet in a grey room under a fire horizon, beside a zebra wall and a rainbow sun.
REC.register('u043', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const clipA = (path, fn, ctx = a) => { ctx.save(); ctx.clip(path); fn(); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a, x1 = x, y1 = y) => { const g = ctx.createRadialGradient(x1, y1, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), line = pts => P(pts, false, true);
    const fill = (path, c, ctx = a) => { ctx.fillStyle = c; ctx.fill(path); };
    const stroke = (path, c, wd, ctx = a) => { ctx.lineWidth = wd; ctx.strokeStyle = c; ctx.lineCap = ctx.lineJoin = 'round'; ctx.stroke(path); };
    const ALL = poly([[-10, -10], [736, -10], [736, 1034], [-10, 1034]]);
    const burst = (x, y, r, n, seed, col = 'rgba(235,235,255,0.95)', ctx = o) => { const q = rng(seed); ctx.strokeStyle = col; ctx.lineCap = 'round';
      for (let i = 0; i < n; i++) { const t = q() * 6.283, L = r * (0.4 + q() * 0.6); ctx.lineWidth = 0.8 + q() * 1.4; ctx.beginPath(); ctx.moveTo(x, y); ctx.lineTo(x + Math.cos(t) * L, y + Math.sin(t) * L); ctx.stroke(); }
      const g = ctx.createRadialGradient(x, y, 0, x, y, r * 0.35); g.addColorStop(0, 'rgba(255,255,255,1)'); g.addColorStop(1, 'rgba(160,170,255,0)'); ctx.fillStyle = g; ctx.fill(circleP(x, y, r * 0.35)); };
    const star4 = (x, y, r, c, ctx = a) => fill(poly([[x - r, y], [x - r * 0.16, y - r * 0.16], [x, y - r], [x + r * 0.16, y - r * 0.16], [x + r, y], [x + r * 0.16, y + r * 0.16], [x, y + r], [x - r * 0.16, y + r * 0.16]]), c, ctx);

    // ── space, rainbow sun and fire horizon ──
    R.flat(ALL, null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.015, .01, .012);
      vec2 g = floor(p / 4.), f = fract(p / 4.) - .5;
      c += step(.93, hash(g)) * smoothstep(.35, .1, length(f)) * (.4 + .6 * hash(g + 3.));
      float r = length(p - vec2(860., 260.));
      vec3 sun = mix(vec3(.46, .52, .96), vec3(.70, .52, .92), smoothstep(120., 230., r));
      sun = mix(sun, vec3(.95, .62, .84), smoothstep(230., 286., r));
      sun = mix(sun, vec3(1., .74, .40), smoothstep(286., 302., r));
      c = mix(sun, c, smoothstep(300., 318., r));
      c += vec3(1., .3, .1) * .5 * smoothstep(330., 306., r) * smoothstep(290., 306., r);
      return c; }`));
    // the far fire line and tree band
    soft(x => { fill(poly([[-10, 94], [600, 92], [600, 108], [-10, 110]]), '#e83a10', x); }, 3, 1);
    soft(x => { fill(poly([[-10, 98], [600, 96], [600, 103], [-10, 105]]), '#ffd030', x); }, 1.5, 0.9);
    fill(poly([[-10, 104], [600, 102], [600, 120], [-10, 120]]), '#16301e');
    { const r = rng(4); for (let x = -10; x < 600; x += 7) fill(poly([[x, 112], [x + 3.5, 100 - r() * 8], [x + 7, 112]]), '#16301e'); }
    fill(poly([[-10, 116], [600, 116], [600, 122], [-10, 122]]), '#e8c040');

    // ── grey room wall ──
    const WALL = poly([[-10, 122], [600, 122], [600, 360], [-10, 360]]);
    fill(WALL, '#86848a');
    clipA(WALL, () => { for (let y = 126; y < 360; y += 9) stroke(line([[0, y], [600, y + 2]]), 'rgba(40,38,44,0.55)', 2); });
    const ZP = poly([[100, 135], [222, 135], [222, 330], [100, 330]]);
    fill(ZP, '#f0f0f0'); clipA(ZP, () => { for (let y = 128.6; y < 330; y += 9.75) fill(rrect(100, y, 122, 5.2, 0), '#121014'); });   // measured: period 9.75 px
    fill(rrect(116, 170, 66, 82, 2), '#0c0a0c');
    fill(sm([[132, 182], [140, 200], [150, 186], [158, 200], [166, 182], [164, 214], [156, 236], [148, 244], [140, 236], [134, 214]]), '#d02818');
    // window, bookcase, milk splash
    fill(rrect(-4, 146, 64, 70, 2), '#c8e4f0'); stroke(line([[0, 150], [56, 212]]), '#f8f8f8', 4); stroke(line([[56, 150], [0, 212]]), '#f8f8f8', 4);
    R.flat(rrect(-4, 220, 80, 150, 0), '#8a3a20', 0.1, 4);
    for (const [y, c] of [[230, '#d8c8b0'], [276, '#c8b8a0'], [322, '#e0d4c0']]) { fill(rrect(4, y, 64, 38, 0), '#2a1a14'); for (let k = 0; k < 7; k++) fill(rrect(6 + k * 9, y + 4, 7, 34, 1), mixHex(c, '#a09080', (k % 3) * 0.3)); }
    R.dome(sm([[66, 120], [92, 100], [120, 92], [134, 104], [110, 130], [100, 170], [96, 214], [80, 216], [74, 180], [70, 150]]), '#f4f4f4', 0.2, 0.1, 10, 1);
    // lime machine with the moon panel, barber pole
    R.flat(rrect(470, 86, 30, 214, 2), '#d0dc90', 0.2, 4);
    R.flat(rrect(486, 160, 70, 140, 2), '#d4e090', 0.2, 4);
    R.flat(rrect(492, 170, 56, 126, 1), '#080608', 0.22, 0);
    { const p = new Path2D(); p.arc(520, 226, 22, 0, 6.283); p.arc(528, 220, 18, 0, 6.283, true); fill(p, '#f2d040'); }
    R.pipe(line([[517, 86], [517, 124]]), 14, '#f0f0f0', 0.25, 0.08, 4);
    clipA(rrect(510, 86, 14, 38, 3), () => { for (let k = 0; k < 6; k++) stroke(line([[508, 84 + k * 8], [526, 92 + k * 8]]), k % 2 ? '#2040c0' : '#d02020', 3); });
    for (const [x, y, r] of [[462, 132, 10], [478, 140, 9], [448, 160, 8], [420, 192, 9], [458, 202, 9], [140, 122, 8]]) R.bead(x, y, r, '#8a8a92', 0.3, 0.08, 5);
    R.flat(rrect(384, 128, 70, 46, 1), '#1a1418', 0.1, 0);
    for (let k = 0; k < 7; k++) fill(rrect(388 + k * 9, 146, 7, 26, 1), ['#3a50a0', '#2a3a70', '#5060b0'][k % 3]);
    R.bead(390, 242, 22, '#141016', 0.3, 0.1, 5);
    // grey gravel path, left
    const PATH = sm([[80, 330], [180, 330], [150, 380], [140, 430], [130, 480], [104, 530], [100, 600], [88, 640], [92, 690], [90, 720], [40, 730], [0, 725], [-10, 700], [15, 640], [50, 600], [50, 540], [55, 480], [95, 440], [100, 400], [78, 360]]);

    // ── blue star carpet ──
    // dark floor on the left with the table and a reaching arm
    fill(poly([[-10, 360], [150, 360], [130, 480], [100, 560], [90, 720], [-10, 730]]), '#141014');
    { const r = rng(17); for (let i = 0; i < 90; i++) fill(circleP(r() * 120, 360 + r() * 360, 0.6 + r() * 1.4), r() < 0.7 ? '#e8e8f0' : '#6a6a70'); }
    R.flat(poly([[-10, 362], [96, 366], [100, 388], [-10, 386]]), '#d8b48a', 0.2, 4);
    for (const x of [8, 80]) R.flat(rrect(x, 386, 9, 170, 1), '#8a3a20', 0.18, 4);
    R.flat(rrect(-10, 386, 96, 10, 0), '#a04a28', 0.18, 4);
    R.dome(ellipseP(40, 380, 26, 7, 0), '#f0f0f0', 0.24, 0.04, 4, 1);
    fill(sm([[-10, 480], [20, 488], [44, 500], [64, 520], [70, 540], [56, 548], [30, 530], [-10, 560]]), '#d8a080');
    fill(sm([[-10, 500], [16, 506], [24, 540], [16, 580], [-10, 590]]), '#2a6a3a');
    const CARPET = sm([[150, 368], [210, 372], [300, 420], [330, 520], [200, 540], [170, 600], [150, 700], [180, 790], [260, 860], [380, 880], [520, 860], [620, 800], [690, 740], [736, 720], [736, 1034], [-10, 1034], [-10, 730], [20, 722], [70, 722], [90, 640], [100, 560], [112, 500], [130, 450], [140, 400]]);
    R.flat(CARPET, null, 0.02, 0);
    clipA(CARPET, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.11, .21, .66) * (.92 + .12 * vnoise(p * .05));
      vec2 g = floor(p / 30.), f = fract(p / 30.) - .5; vec2 o = (vec2(hash(g + 1.), hash(g + 2.)) - .5) * .4;
      vec2 q = abs(f - o); float sz = .5 + .5 * hash(g + 9.);
      float st = step(.25, hash(g + 5.)) * smoothstep(.035, .0, min(q.x, q.y) * (1. + 9. * max(q.x, q.y) / sz)) * smoothstep(.3 * sz, .05, max(q.x, q.y));
      c = mix(c, vec3(.95, .95, 1.), st);
      c += step(.96, hash(floor(p / 3.))) * .5;
      return c; }`)));
    clipA(CARPET, () => { const r = rng(23); for (let y = 380; y < 1030; y += 34) for (let x = (y / 34 % 2) * 17; x < 736; x += 34) { if (r() < 0.25) continue; const rr = 4 + r() * 6; star4(x + (r() - 0.5) * 18, y + (r() - 0.5) * 18, rr, '#f4f4ff'); } });
    R.flat(PATH, '#7a7a80', 0.06, 4);
    clipA(PATH, () => { const r = rng(5); for (let i = 0; i < 700; i++) fill(circleP(r() * 190, 330 + r() * 400, 1 + r() * 3.5), r() < 0.45 ? '#2a2a30' : '#c0c0c6'); });
    stroke(line([[100, 350], [118, 400], [110, 450], [126, 500], [96, 560], [70, 620]]), '#f0f0ff', 2);
    // black slab with yellow edge, yellow star
    R.dome(poly([[170, 452], [252, 452], [238, 490], [154, 490]]), '#0a0a0e', 0.1, 0.04, 3, 5);
    stroke(poly([[170, 452], [252, 452], [238, 490], [154, 490]]), '#e0c040', 2);

    // ── the crackle island ──
    const ISL = sm([[300, 515], [260, 518], [218, 522], [186, 575], [168, 630], [152, 690], [160, 760], [200, 815], [260, 856], [357, 872], [463, 866], [540, 836], [600, 800], [650, 762], [690, 728], [706, 690], [700, 640], [680, 590], [660, 530], [648, 470], [636, 420], [615, 370], [590, 330], [560, 300], [500, 290], [440, 292], [400, 310], [390, 330]]);
    stroke(ISL, '#f0d840', 8);
    R.flat(ISL, null, 0.06, 0);
    clipA(ISL, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p / 6.5, i = floor(q), f = fract(q); float d1 = 9., d2 = 9.;
      for (int y = -1; y <= 1; y++) for (int x = -1; x <= 1; x++) { vec2 g = vec2(float(x), float(y)); vec2 o = vec2(hash(i + g), hash(i + g + 17.)) * .9 + .05;
        float d = length(g + o - f); if (d < d1) { d2 = d1; d1 = d; } else if (d < d2) d2 = d; }
      float e = smoothstep(.2, .08, d2 - d1);
      float hole = smoothstep(.62, .7, fbm(p * .03 + 3.));
      vec3 c = mix(vec3(.02, .015, .02), vec3(.70, .56, .42), e * (1. - hole));
      return c; }`)));
    star4(186, 632, 34, '#f8e860');
    // white crackle tree, lower left
    { const r = rng(21); const br = (x, y, an, len, wd, d) => { if (d > 6 || len < 5) return; const x2 = x + Math.cos(an) * len, y2 = y + Math.sin(an) * len;
        stroke(line([[x, y], [(x + x2) / 2 + (r() - 0.5) * 6, (y + y2) / 2 + (r() - 0.5) * 6], [x2, y2]]), '#eeeeee', wd); for (let k = 0; k < 2; k++) br(x2, y2, an + (r() - 0.5) * 1.3, len * 0.72, wd * 0.72, d + 1); };
      br(230, 800, -1.45, 60, 4, 0); br(270, 770, -1.0, 50, 3.5, 0); br(330, 650, -2.3, 50, 3, 1); br(300, 560, -0.6, 40, 2.5, 2); }
    // mint pool and blue blobs
    R.dome(ellipseP(502, 340, 38, 25, 0), '#1ee8a8', 0.12, 0.06, 10, 3);
    { const r = rng(14); for (let i = 0; i < 26; i++) { const x = 420 + r() * 230, y = 360 + r() * 400; R.dome(sm(blob(x, y, 5 + r() * 12, 4 + r() * 8, i, 8, 0.25)), r() < 0.8 ? '#3050c8' : '#38c8c0', 0.1, 0.04, 4, 3); } }
    R.dome(sm(blob(610, 680, 26, 16, 3, 10, 0.2, 0.4)), '#3050c8', 0.1, 0.05, 6, 3);
    // rainbow river
    const RIB = [[495, 452], [515, 447], [532, 450], [546, 462], [560, 485], [580, 510], [605, 535], [620, 565], [630, 600], [650, 620], [670, 635], [685, 655], [695, 680], [690, 710], [670, 735], [640, 750], [600, 765]];
    for (const [w, c] of [[24, '#2ec8e8'], [20, '#f2e448']]) stroke(line(RIB.slice(0, 9)), c, w);
    stroke(line(RIB.slice(7, 15)), '#f2e448', 24); stroke(line(RIB.slice(7, 15)), '#fdfbe8', 14); stroke(line(RIB.slice(14)), '#f2e448', 9); stroke(line(RIB.slice(14)), '#fdfbe8', 4);
    const RIV = [[455, 470], [465, 453], [480, 447], [493, 455], [488, 480], [486, 510], [496, 540], [515, 570], [530, 600], [535, 632], [528, 670], [518, 700], [508, 730], [503, 755], [516, 768], [540, 758], [565, 742]];
    for (const [w, c] of [[28, '#2ec8e8'], [23, '#f0e040'], [11, '#f0a030'], [4, '#e84820']]) stroke(line(RIV), c, w);
    // white L-shaped block
    const LB = poly([[222, 326], [410, 322], [410, 350], [398, 358], [392, 372], [390, 396], [388, 440], [378, 494], [298, 494], [310, 440], [318, 396], [312, 384], [300, 376], [270, 368], [230, 362], [220, 350]]);
    R.dome(LB, '#e4e4e4', 0.2, 0.08, 6, 1);
    clipA(LB, () => { for (let y = 326; y < 522; y += 6) stroke(line([[200, y], [400, y]]), y > 380 ? 'rgba(70,70,78,0.55)' : 'rgba(120,120,128,0.5)', y > 380 ? 1.4 : 1.2); });
    R.flat(poly([[298, 494], [378, 494], [376, 520], [296, 520]]), '#0c0c10', 0.1, 0);
    R.flat(poly([[190, 364], [230, 362], [270, 368], [300, 376], [318, 396], [312, 430], [240, 410], [190, 400]]), '#1a1a20', 0.1, 0);
    fill(rrect(362, 322, 34, 24, 1), '#f2d040');
    // the grey T console
    const TB = poly([[330, 690], [440, 690], [442, 798], [326, 798]]);
    R.flat(poly([[326, 798], [442, 798], [444, 828], [324, 828]]), '#0c0c10', 0.1, 0);
    R.dome(TB, '#55555c', 0.15, 0.06, 6, 4);
    R.dome(poly([[396, 404], [422, 404], [422, 700], [396, 700]]), '#4a4a50', 0.15, 0.05, 4, 4);
    R.dome(poly([[290, 522], [480, 522], [480, 556], [290, 556]]), '#4c4c54', 0.16, 0.05, 4, 4);
    R.dome(poly([[346, 556], [374, 556], [374, 690], [346, 690]]), '#3e3e46', 0.18, 0.04, 3, 4);
    for (const P_ of [TB]) stroke(P_, '#0a0a0c', 3);
    R.bead(382, 744, 14, '#9ab0c8', 0.24, 0.06, 3); fill(circleP(382, 744, 5), '#0a0a10');
    fill(rrect(430, 560, 40, 30, 4), '#2840a0');
    // printer on the wall ledge
    R.flat(poly([[222, 270], [360, 270], [372, 300], [210, 300]]), '#d8b040', 0.2, 4);
    clipA(poly([[222, 270], [360, 270], [372, 300], [210, 300]]), () => { for (let x = 222; x < 372; x += 6) stroke(line([[x, 270], [x, 300]]), '#5a4010', 1.5); });
    R.flat(poly([[204, 300], [378, 300], [372, 330], [210, 336]]), '#1a1a20', 0.18, 5);
    // grey balls on the island
    R.bead(281, 795, 26, '#5a5a62', 0.2, 0.12, 5);
    R.bead(450, 405, 13, '#5a5a62', 0.2, 0.08, 5);
    // palette and pink card
    R.flat(rrect(310, 838, 80, 24, 2), '#f0f0f0', 0.1, 4);
    { const cs = ['#e03030', '#f0a030', '#3050d0', '#40c060', '#e040a0', '#3030a0', '#f0e040', '#40c0e0']; cs.forEach((c, i) => fill(circleP(320 + (i % 4) * 18, 845 + Math.floor(i / 4) * 10, 4), c)); }
    R.flat(poly([[516, 860], [566, 826], [606, 852], [552, 892]]), '#f2f2f2', 0.1, 4);
    fill(poly([[530, 858], [566, 834], [592, 852], [556, 878]]), '#f0a8d0');

    // ── zebra wall on the right ──
    const ZW = sm([[736, 60], [690, 70], [660, 90], [650, 140], [648, 200], [655, 300], [660, 380], [655, 440], [660, 500], [675, 550], [700, 630], [720, 680], [736, 700]]);
    R.flat(ZW, null, 0.1, 0);
    clipA(ZW, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ float ph = (p.x + 5. * sin(p.y * .05 + p.x * .02) + 2.5 * sin(p.y * .12)) / 7.1;
      return mix(vec3(.94, .93, .92), vec3(.05, .04, .05), step(.5, fract(ph))); }`)));
    clipA(ZW, () => soft(x => fill(poly([[620, 470], [700, 450], [736, 700], [650, 640]]), 'rgba(150,148,152,0.6)', x), 16, 1));
    // white burst under the sun
    soft(x => { fill(sm([[560, 180], [610, 170], [650, 200], [656, 260], [646, 320], [630, 370], [600, 390], [574, 350], [556, 290], [552, 230]]), '#ffffff', x); }, 10, 1);
    // ── bottom-left: rope, red claw, white ball, rubble; bottom-right: pot and slab ──
    stroke(line([[-10, 742], [40, 736], [100, 734], [130, 760], [140, 820], [160, 870], [190, 910], [200, 960], [196, 1000]]), '#f2f2f2', 8);
    stroke(line([[120, 740], [126, 800], [150, 860], [180, 900], [190, 960]]), '#a07060', 4);
    stroke(line([[60, 700], [60, 760], [50, 800]]), '#d8c0b0', 6);
    fill(sm([[0, 780], [40, 776], [80, 790], [96, 812], [60, 830], [30, 860], [0, 850]]), '#a02818');
    R.bead(32, 962, 36, '#f0f0f2', 0.2, 0.2, 1);
    fill(sm([[40, 990], [90, 940], [130, 920], [160, 960], [150, 1034], [40, 1034]]), '#5a5a62');
    R.dome(poly([[380, 1034], [560, 930], [580, 950], [420, 1034]]), '#f0f0f0', 0.1, 0.08, 6, 1);
    // ceramic pot
    const POT = sm([[580, 900], [640, 950], [700, 970], [736, 960], [736, 1034], [600, 1034], [590, 960]]);
    R.flat(sm([[640, 860], [700, 860], [736, 870], [736, 960], [690, 950], [640, 920]]), '#141218', 0.2, 5);
    R.dome(POT, lin(570, 0, 736, 0, [[0, '#8a4a30'], [0.4, '#b06a48'], [1, '#6a3020']]), 0.1, 0.2, 40, 2);
    R.dome(ellipseP(688, 822, 54, 58, 0), '#c06a40', 0.3, 0.1, 20, 2);
    R.dome(sm([[548, 838], [600, 834], [640, 852], [680, 872], [700, 900], [726, 945], [726, 975], [690, 978], [650, 965], [610, 935], [580, 900], [552, 872]]), lin(560, 0, 736, 0, [[0, '#f0f0f2'], [0.7, '#e8e8ec'], [1, '#c0c0c8']]), 0.3, 0.08, 10, 1);
    for (const d of [0, 20]) stroke(line([[566, 856 + d], [620, 888 + d], [670, 916 + d], [710, 944 + d]]), '#1a1a20', 4);
    R.bead(720, 692, 16, '#f0f0f0', 0.3, 0.1, 1);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.5, shin: 30, wrap: 0.4, ao: 0.4, coat: 0.08 }),                            // 1 white glaze
        E.mat({ dif: 0.9, metal: 0.25, spec: 0.8, shin: 40, wrap: 0.3, ao: 0.4 }),                        // 2 copper pot
        E.mat({ dif: 1, spec: 0.8, shin: 60, coat: 0.2, ao: 0.3 }),                                       // 3 glossy blobs
        E.mat({ dif: 1, spec: 0.2, shin: 16, wrap: 0.4, ao: 0.3 }),                                       // 4 matte
        E.mat({ dif: 1, spec: 0.9, shin: 50, coat: 0.2, ao: 0.3 }),                                       // 5 black gloss
      ],
      light: [-0.4, 0.6, 0.7], lc: [0.6, 0.6, 0.62], amb: [0.5, 0.5, 0.52],
      envTop: [1, 1, 1], envHor: [0.55, 0.55, 0.6], envBot: [0.15, 0.14, 0.16], envK: [0.2, 0.8, 0.2, 0],
      r1: 2, r2: 8, k: [0, 0.6, 0.4, 80], shadow: [-4, 6, 0.3, 8]
    });
    // sparkle bursts and highlights after light
    for (const [x, y, r, sd] of [[325, 332, 34, 1], [440, 300, 30, 2], [262, 428, 30, 3], [216, 520, 40, 4], [566, 330, 26, 5], [600, 410, 40, 6]]) burst(x, y, r, 40, sd);
    { const q = rng(8); for (let i = 0; i < 70; i++) { const t = q() * 6.283, L = 60 + q() * 60; o.strokeStyle = 'rgba(255,255,255,0.7)'; o.lineWidth = 1; o.beginPath(); o.moveTo(610 + Math.cos(t) * 30, 300 + Math.sin(t) * 30); o.lineTo(610 + Math.cos(t) * L, 300 + Math.sin(t) * L); o.stroke(); } }
    for (const [x, y, w] of [[152, 60, 12], [476, 48, 10], [528, 22, 5]]) fill(ellipseP(x, y, w, w * 0.45, 0), '#f0f0f0', o);
    E.grain(0.035, 9);
  }
});
