'use strict';
// g083 — "Jellyfish television": a glossy plastic TV-creature on slate grey — a pink-and-blue screen in a cream
// and gold frame, a zebra vortex and a starry purple lobe behind, a ribbed cream cap with eyes, a translucent frill below.
REC.register('g083', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S, o = E.out;
    const keep = () => { R.a.getImageData(0, 0, 1, 1); R.h.getImageData(0, 0, 1, 1); };
    const pat = cv => { const p = a.createPattern(cv, 'no-repeat'); p.setTransform(new DOMMatrix().scale(1 / S)); return p; };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops) => { const g = a.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const BG = '#6f7687';

    // ── pattern fields ──
    const zVort = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(226., 318.);
      float r = length(d), an = atan(d.y, d.x);
      float ph = 30. * an / 6.2832 + 0.16 * abs(fract(r / 70.) - .5) * 4. + 0.25 * sin(r * 0.03 + an * 2.) + 0.3 * (fbm(p * 0.012) - .5);
      float v = sin(6.2832 * ph);
      return mix(vec3(.03), vec3(.96, .96, .94), smoothstep(-.18, .18, v)); }`));
    const zVert = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float v = cos(6.2832 * (p.x - 303.5) / 26.6);
      return mix(vec3(.96, .96, .94), vec3(.03), smoothstep(.2, .45, v)); }`));
    const zDiag = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      float v = cos(6.2832 * (dot(p, vec2(.894, .447)) - 773.) / 28.);
      return mix(vec3(.96, .96, .94), vec3(.03), smoothstep(.0, .3, v)); }`));
    const stars = pat(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.01, .01, .03);
      vec2 g = floor(p / 7.); float h = hash(g);
      vec2 q = fract(p / 7.) - .5 - (vec2(hash(g + 3.1), hash(g + 7.7)) - .5) * .6;
      float s = smoothstep(.16, .0, length(q)) * step(.82, h);
      c += s * mix(vec3(.4, .7, 1.), vec3(1.), hash(g + 1.3));
      return c; }`));

    // ── background ──
    R.flat(rrect(-10, -10, 746, 1044, 0), BG, 0, 0);

    // ── right lobe: blue rim, purple, starry black, red-orange ──
    const lobe = P([[470, 178], [520, 182], [600, 190], [652, 204], [682, 236], [692, 300], [694, 400], [688, 480], [674, 550], [652, 596], [600, 612], [556, 600], [540, 560], [536, 300]], true, true);
    R.dome(lobe, '#2a4ef0', 0.08, 0.12, 22, 1);
    const lobe2 = P([[486, 196], [540, 196], [600, 204], [646, 218], [668, 246], [676, 300], [678, 400], [672, 480], [660, 540], [640, 582], [600, 596], [560, 588], [546, 300]], true, true);
    clipA(lobe2, () => { a.fillStyle = '#7a3ce8'; a.fill(lobe2); });
    const space = P([[492, 222], [560, 222], [620, 232], [648, 260], [656, 320], [656, 420], [650, 500], [630, 560], [596, 580], [560, 572], [548, 300]], true, true);
    clipA(space, () => {
      a.fillStyle = stars; a.fill(space);
      soft(x => { x.fillStyle = '#f03a1c'; x.fill(P([[600, 460], [660, 470], [680, 560], [640, 610], [570, 600], [560, 520]], true, true)); }, 14, 0.95);
      soft(x => { x.fillStyle = '#5a2ab8'; x.fill(ellipseP(600, 225, 90, 22, 0)); }, 10, 0.8);
    });
    // gold ring with blue lens
    R.dome(ellipseP(641, 466, 17, 37, 0), '#d8b860', 0.2, 0.08, 6, 1);
    R.dome(ellipseP(641, 466, 11, 29, 0), '#2a9cf0', 0.24, 0.06, 10, 1);
    keep();

    // ── left body: blue-cyan lobe, gold rim, zebra vortex ──
    const blueL = P([[34, 340], [70, 360], [100, 450], [150, 530], [190, 580], [212, 660], [210, 760], [184, 806], [130, 806], [80, 770], [40, 700], [22, 600], [20, 460]], true, true);
    R.dome(blueL, lin(0, 400, 0, 800, [[0, '#28b0f0'], [0.45, '#1ac0f4'], [0.8, '#2a7ae8'], [1, '#2050d8']]), 0.08, 0.14, 26, 1);
    clipA(blueL, () => {
      soft(x => { x.fillStyle = '#e8a0b0'; x.fill(ellipseP(98, 520, 56, 50, 0)); x.fillStyle = '#d8c070'; x.fill(ellipseP(80, 470, 30, 26, 0)); }, 12, 0.9);
      soft(x => { x.fillStyle = '#050508'; x.fill(P(blob(90, 508, 34, 26, 4, 12, 0.3))); }, 3, 1);
    });
    const gold = P([[38, 280], [44, 232], [72, 208], [124, 204], [112, 220], [84, 244], [76, 320], [82, 400], [96, 470], [64, 476], [48, 420], [38, 340]], true, true);
    R.dome(gold, lin(30, 200, 110, 480, [[0, '#c89a3c'], [0.5, '#d0a040'], [1, '#b89040']]), 0.1, 0.16, 18, 1);
    const zl = P([[80, 236], [126, 210], [170, 190], [236, 170], [300, 158], [350, 166], [320, 290], [230, 330], [196, 450], [184, 566], [150, 566], [112, 500], [90, 440], [78, 340]], true, true);
    R.dome(zl, zVort, 0.1, 0.1, 18, 3);
    R.pipe(P([[84, 214], [118, 206], [170, 188], [236, 168], [300, 157], [350, 163]], false, true), 16, '#34b4f0', 0.16, 0.06, 1);
    keep();

    // ── screen block: zebra surround, gold drips, cream frame, pink screen ──
    const surround = rrect(176, 280, 406, 300, 40);
    R.dome(surround, zVert, 0.16, 0.1, 16, 3);
    const gd = [[200, 312, 22, 18], [262, 318, 30, 14], [290, 312, 14, 12], [488, 318, 26, 14], [520, 322, 16, 12], [178, 360, 14, 40], [172, 430, 12, 40], [176, 500, 16, 40], [184, 560, 26, 22], [236, 596, 40, 16], [270, 592, 18, 14], [552, 528, 18, 32], [556, 340, 12, 14], [562, 356, 10, 10]];
    R.dome(P(ragged([[178, 600], [176, 520], [180, 420], [182, 340], [192, 310], [230, 304], [300, 306], [300, 336], [210, 340], [200, 420], [200, 560], [250, 584], [290, 590], [290, 612], [230, 612]], 0, 4, 22, 9, 31), true, true), '#c8a042', 0.24, 0.08, 10, 1);
    for (const [x, y, rx, ry] of gd) R.dome(P(blob(x, y, rx, ry, x + y, 12, 0.3)), '#c8a042', 0.24, 0.08, 8, 1);
    const frame = rrect(194, 330, 368, 248, 34);
    R.dome(frame, '#efe6c8', 0.26, 0.14, 16, 2);
    const scr = rrect(214, 348, 328, 214, 22);
    R.flat(scr, '#f04030', 0.28, 1);
    R.flat(rrect(226, 352, 314, 206, 24), '#2a5af0', 0.28, 1);
    R.flat(rrect(240, 358, 296, 196, 26), '#4a7cf8', 0.28, 1);
    R.flat(P([[252, 400], [300, 368], [400, 362], [480, 360], [526, 380], [530, 460], [520, 520], [490, 546], [400, 552], [300, 550], [256, 520], [250, 460]], true, true), '#f468d2', 0.28, 1);
    R.dome(P([[324, 398], [360, 382], [430, 380], [466, 400], [464, 426], [430, 446], [380, 450], [340, 436]], true, true), '#1414f0', 0.28, 0.02, 10, 1);
    R.dome(P([[472, 378], [498, 366], [514, 376], [508, 398], [486, 400]], true, true), '#1414f0', 0.28, 0.02, 6, 1);
    R.dome(ellipseP(440, 500, 52, 38, 0), '#a2e83a', 0.28, 0.03, 12, 1);
    R.dome(ellipseP(274, 514, 14, 10, 0), '#1a3af0', 0.28, 0.02, 6, 1);
    soft(x => { x.fillStyle = '#f8a8e0'; x.fill(ellipseP(390, 540, 110, 14, 0)); }, 8, 0.8);
    for (const [x, y, r] of [[514, 396, 12], [526, 512, 9], [432, 384, 4], [300, 400, 3], [508, 434, 3], [466, 446, 3]]) R.bead(x, y, r, r > 6 ? '#c89aa8' : '#d8e0f8', 0.3, 0.06, 5);
    R.dome(rrect(540, 508, 30, 54, 14), '#d8b860', 0.3, 0.06, 6, 1);
    R.dome(ellipseP(555, 535, 10, 18, 0), '#58d04a', 0.34, 0.04, 6, 1);
    for (const [x, y, r] of [[562, 340, 9], [570, 358, 8]]) R.bead(x, y, r, '#a8d8f0', 0.3, 0.08, 5);
    R.dome(P([[476, 282], [500, 276], [528, 290], [520, 306], [490, 302]], true, true), '#e8508a', 0.26, 0.04, 6, 1);
    keep();

    // ── ribbed cream cap with eyes + comb fringe ──
    const comb = rrect(246, 248, 246, 40, 6);
    R.dome(comb, '#ece4cc', 0.26, 0.08, 6, 2);
    for (let x = 252; x < 490; x += 7) R.groove(P([[x, 254], [x, 286]], false, false), 3, '#b8b0a0', 0.34, 0.06, 2, 0.6);
    const cap = P([[150, 262], [196, 244], [252, 222], [292, 192], [330, 164], [372, 154], [418, 160], [452, 182], [492, 202], [536, 216], [542, 232], [500, 242], [420, 246], [320, 250], [240, 256]], true, true);
    R.dome(cap, '#ecd894', 0.28, 0.16, 26, 2);
    for (let i = 0; i < 9; i++) {
      const t = i / 8, y = 172 + i * 8.5;
      R.groove(P([[300 - t * 110, y + 30 + t * 30], [350, y + 6], [400, y + 2], [470, y + 16 + t * 20], [530 - t * 10, y + 42 + t * 6]], false, true), 3, '#c8b070', 0.4, 0.05, 2, 0.5);
    }
    for (let x = 160; x < 540; x += 6) R.groove(P([[x, 248 - Math.max(0, (x - 160) * 0.02)], [x, 256]], false, false), 2.5, '#c8b890', 0.34, 0.04, 2, 0.5);
    for (const [x, y] of [[341, 196], [399, 189]]) { R.bead(x, y, 13, '#30b8e8', 0.42, 0.06, 1); R.bead(x, y, 8.5, '#f2d020', 0.46, 0.04, 1); R.bead(x, y, 4.5, '#b01818', 0.5, 0.03, 1); }
    R.groove(P([[360, 196], [368, 190], [376, 196]], false, true), 2.5, '#6a5a30', 0.44, 0.04, 2, 0.8);
    R.groove(P([[350, 212], [372, 216], [392, 210]], false, true), 2.5, '#6a5a30', 0.44, 0.04, 2, 0.8);
    keep();

    // ── translucent frill skirt ──
    const clipBoth = (path, fn) => { R.a.save(); R.h.save(); R.a.clip(path); R.h.clip(path); fn(); R.a.restore(); R.h.restore(); };
    const skirtPts = [[96, 630], [150, 600], [210, 576], [300, 570], [400, 570], [500, 572], [566, 588], [624, 616], [676, 650], [704, 676], [692, 698], [660, 708], [628, 724], [600, 748], [574, 772], [548, 792], [512, 806], [480, 812],
      [456, 820], [430, 806], [410, 828], [386, 812], [360, 848], [336, 820], [314, 836], [292, 812], [270, 826], [248, 806], [222, 812], [196, 806], [168, 796], [140, 780], [112, 760], [86, 732], [66, 704], [56, 686], [70, 662]];
    const skirt = P(skirtPts, true, true);
    R.dome(skirt, lin(0, 570, 0, 840, [[0, '#f2ecd6'], [0.15, '#e6e8f0'], [0.55, '#d6dcec'], [1, '#aab4d0']]), 0.1, 0.06, 24, 4);
    clipA(skirt, () => {
      soft(x => { x.fillStyle = '#9aaee6'; for (const [cx, cy, rx] of [[150, 730, 50], [620, 690, 40], [300, 790, 50], [420, 790, 40]]) x.fill(ellipseP(cx, cy, rx, 30, 0)); }, 18, 0.55);
    });
    // diagonal zebra panel lower right
    const zr = P([[440, 640], [540, 620], [596, 650], [612, 720], [596, 800], [520, 812], [452, 800], [436, 720]], true, true);
    R.dome(zr, zDiag, 0.14, 0.06, 12, 3);
    // fanned pleats
    clipBoth(skirt, () => {
      for (let i = 0; i < 46; i++) {
        const t = i / 45, x0 = 120 + t * 520, an = (t - 0.5) * 1.5;
        const x1 = x0 + Math.sin(an) * 160, y1 = 600 + Math.cos(an) * 260;
        if (x0 > 450 && x0 < 590 && i % 3) continue;
        R.pipe(P([[x0 + (x0 - 380) * -0.1, 590], [x1, y1]], false, false), 9, i % 2 ? '#eef0f6' : '#d8dcea', 0.12, 0.07, 4);
      }
    });
    // ruffled hems
    const hem = (pts, amp) => { const out = []; for (let i = 0; i < pts.length - 1; i++) { const [x0, y0] = pts[i], [x1, y1] = pts[i + 1]; for (let k = 0; k < 4; k++) { const t = k / 4; out.push([x0 + (x1 - x0) * t, y0 + (y1 - y0) * t + (k % 2 ? amp : -amp)]); } } out.push(pts[pts.length - 1]); return out; };
    R.pipe(P(hem([[70, 662], [56, 686], [66, 704], [86, 732], [112, 760], [140, 780], [168, 796], [196, 806], [222, 812], [248, 806]], 3), false, true), 9, '#f2eee2', 0.16, 0.06, 2);
    R.pipe(P(hem([[628, 724], [660, 708], [692, 698], [704, 676], [690, 660]], 3), false, true), 9, '#f2eee2', 0.16, 0.06, 2);
    // hanging ribs
    const rr = rng(83);
    for (let x = 226; x < 470; x += 18 + rr() * 10) {
      const len = 120 + rr() * 110, x2 = x + (rr() - 0.5) * 24;
      R.pipe(P([[x, 610], [x + (x2 - x) * 0.5, 610 + len * 0.6], [x2, 610 + len]], false, true), 9 + rr() * 5, '#f0f2f8', 0.16, 0.08, 4);
    }
    // blue drips
    for (const [x, y0, y1, w] of [[338, 700, 842, 18], [352, 690, 862, 14], [366, 720, 840, 12], [312, 760, 826, 10], [392, 760, 850, 10], [300, 780, 840, 8]]) R.pipe(P([[x, y0], [x + 2, (y0 + y1) / 2], [x, y1]], false, true), w, '#2448f0', 0.18, 0.1, 1);
    for (let y = 760; y < 860; y += 8) R.groove(P([[340, y], [362, y]], false, false), 3, '#1430b0', 0.3, 0.05, 1, 0.5);
    keep();
    // cream tube
    const tube = P([[104, 632], [140, 652], [190, 640], [232, 668], [282, 698], [332, 714], [382, 712], [432, 704], [470, 700], [510, 690], [540, 668], [566, 650], [604, 652], [640, 622]], false, true);
    R.pipe(tube, 18, '#f2e6be', 0.24, 0.12, 2);
    R.pipe(P([[640, 622], [660, 640]], false, true), 16, '#f2e6be', 0.24, 0.1, 2);
    // flower + stem
    R.pipe(P([[476, 690], [472, 740], [468, 790], [470, 822]], false, true), 12, '#f2e6be', 0.24, 0.1, 2);
    for (let y = 700; y < 820; y += 6) R.groove(P([[466, y], [478, y]], false, false), 2, '#c8b890', 0.3, 0.03, 2, 0.6);
    for (let i = 0; i < 12; i++) { const an = i / 12 * Math.PI * 2; R.pipe(P([[476, 680], [476 + Math.cos(an) * 22, 680 + Math.sin(an) * 18]], false, false), 6, '#f4ecc8', 0.3, 0.06, 2); }
    R.bead(476, 680, 7, '#f0c840', 0.34, 0.05, 2);
    // cylinder end with lime lens
    R.dome(ellipseP(590, 768, 40, 30, -0.45), '#e8dcb8', 0.22, 0.1, 10, 2);
    R.dome(ellipseP(592, 766, 26, 17, -0.45), '#9ae82c', 0.3, 0.04, 8, 1);
    // pink creature
    R.dome(P([[452, 836], [462, 812], [480, 806], [496, 818], [506, 840], [490, 852], [470, 852]], true, true), '#f0607a', 0.18, 0.1, 10, 1);
    R.bead(444, 830, 8, '#f0607a', 0.18, 0.08, 1); R.bead(506, 830, 7, '#f0607a', 0.18, 0.08, 1);
    // small bubbles on the left
    for (const [x, y, r] of [[76, 462, 6], [84, 470, 4], [52, 600, 5], [70, 590, 3], [150, 690, 4]]) R.bead(x, y, r, '#d8c890', 0.24, 0.05, 1);
    keep();

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.9, shin: 70, wrap: 0.5, ao: 0.4, coat: 0.18, rim: 0.15 }),     // 1 glossy plastic
        E.mat({ dif: 1, spec: 0.8, shin: 50, wrap: 0.5, ao: 0.6, coat: 0.15, rim: 0.1 }),      // 2 cream ribbed
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.5, ao: 0.4, coat: 0.12 }),                // 3 zebra
        E.mat({ dif: 0.9, spec: 0.8, shin: 40, wrap: 0.6, ao: 0.5, coat: 0.15, emis: 0.12 })   // 4 translucent frill
      ],
      light: [-0.45, 0.6, 0.66], lc: [0.6, 0.6, 0.6], amb: [0.5, 0.5, 0.52],
      envTop: [1, 1, 1], envHor: [0.55, 0.57, 0.62], envBot: [0.2, 0.21, 0.25], envK: [0.2, 1.0, 0.3, 0],
      r1: 1.4, r2: 6, k: [0, 0.6, 0.4, 110], shadow: [-4, 6, 0.5, 7]
    });
    E.grain(0.025, 83);
  }
});
