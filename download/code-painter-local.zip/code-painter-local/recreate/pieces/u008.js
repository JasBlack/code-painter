'use strict';
// u008 — "Cosmic clay sultan": a giant white clay face in a slate drum hat, almond-seed eyes and black zebra
// contours, target-ring cheeks, glittering red lips over a fluffy white beard, adrift in a streaked starfield.
REC.register('u008', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const img = (cv, ctx = a) => { ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.drawImage(cv, 0, 0); ctx.restore(); };
    const soft = (fn, blur, alpha = 1, op = 'source-over', ctx = a) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); x.lineCap = x.lineJoin = 'round'; fn(x);
      ctx.save(); ctx.setTransform(1, 0, 0, 1, 0, 0); ctx.globalAlpha = alpha; ctx.globalCompositeOperation = op; ctx.filter = `blur(${blur * S}px)`; ctx.drawImage(c, 0, 0); ctx.restore();
    };
    const lin = (x0, y0, x1, y1, stops, ctx = a) => { const g = ctx.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r, stops, ctx = a) => { const g = ctx.createRadialGradient(x, y, 0, x, y, r); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const sm = pts => P(pts, true, true), poly = pts => P(pts, true, false), open = pts => P(pts, false, true);
    const clipAH = (path, fn) => { a.save(); R.h.save(); a.clip(path); R.h.clip(path); fn(); a.restore(); R.h.restore(); };
    const WH = '#e2e5ec', INK = '#08080a';
    const ink = (path, hv = 0.1) => R.flat(path, INK, hv, 2);

    // ── streaked starfield ──
    R.flat(rrect(-10, -10, 746, 1044, 0), null, 0, 0);
    img(E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec3 c = vec3(.02, .02, .025);
      vec2 g = floor(p / 3.), f = fract(p / 3.) - .5;
      c += step(.975, hash(g)) * smoothstep(.5, .1, length(f)) * (.4 + .6 * hash(g + 1.3));
      float ang = mix(.42, -.12, smoothstep(150., 900., p.y)) + .1 * sin(p.x * .004);
      vec2 d = vec2(cos(ang), sin(ang)), n = vec2(-d.y, d.x);
      float u = dot(p, d), v = dot(p, n), row = floor(v / 9.);
      float on = step(.8, hash(vec2(row, floor(u / 110. + hash(vec2(row, 3.)) * 5.))));
      float dash = smoothstep(.3, .9, vnoise(vec2(u * .12, row * 7.)));
      float line = smoothstep(1.2, .2, abs(fract(v / 9.) * 9. - 4.5));
      c += on * dash * line * vec3(.62, .62, .64) * smoothstep(.2, .6, vnoise(vec2(u * .01, row * .3)));
      return c; }`));
    for (const [x, y, r] of [[40, 78, 12], [490, 20, 8], [512, 145, 10], [660, 207, 9], [683, 333, 15], [707, 400, 5], [627, 432, 7], [677, 495, 11], [690, 678, 16], [85, 883, 10], [365, 935, 13], [180, 990, 14], [440, 955, 5], [130, 630, 5], [712, 830, 6], [500, 820, 5]]) {
      soft(x2 => { x2.fillStyle = 'rgba(255,248,236,0.55)'; x2.fill(circleP(x, y, r * 1.35)); }, r * 0.4);
      soft(x2 => { x2.strokeStyle = 'rgba(255,255,255,0.6)'; x2.lineWidth = 1; for (let k = 0; k < 16; k++) { const t = k / 16 * 6.283; x2.beginPath(); x2.moveTo(x + Math.cos(t) * r, y + Math.sin(t) * r); x2.lineTo(x + Math.cos(t) * r * 1.9, y + Math.sin(t) * r * 1.9); x2.stroke(); } }, 0.5);
      a.fillStyle = rad(x, y, r, [[0, '#ffffff'], [0.7, '#fffaf2'], [1, '#f0e6da']]); a.fill(circleP(x, y, r));
    }

    soft(x => { x.fillStyle = rad(0, 150, 120, [[0, 'rgba(190,170,150,0.9)'], [1, 'rgba(120,100,90,0)']], x); x.fill(circleP(0, 150, 120)); }, 10);
    // ── ring discs (top right, bottom right) ──
    // elliptic rings with a low-order wobble (centre, y-stretch, period, phase, wobble fitted offline)
    const disc = (path, prm) => { const [X, Y, ex, per, ph, w1, w2, w3, w4] = prm.map(v => v.toFixed(4));
      R.dome(path, WH, 0.05, 0.12, 22, 1);
      clipAH(path, () => img(E.fx(`vec3 fx(vec2 uv, vec2 p){ vec2 q = vec2(p.x - ${X}, (p.y - ${Y}) / ${ex}); float an = atan(q.y, q.x);
          float r = length(q) + ${w1} * cos(an) + ${w2} * sin(an) + ${w3} * cos(2. * an) + ${w4} * sin(2. * an);
          float v = cos(6.2832 * (r / ${per} + ${ph})); return mix(vec3(.03), vec3(.886, .898, .925), smoothstep(-.15, .15, v)); }`)));
      clipAH(path, () => { a.strokeStyle = '#e4e7ee'; a.lineWidth = 16; a.stroke(path); });
    };
    disc(sm([[593, 0], [570, 29], [557, 59], [562, 143], [586, 164], [627, 179], [672, 173], [694, 164], [726, 136], [726, 40], [685, 0]]), [638.062, 70.573, 0.95, 11.913, 0.94, -4.596, -6.0, 2.929, 0.761]);
    disc(sm([[634, 792], [611, 788], [571, 796], [540, 820], [510, 840], [496, 894], [503, 931], [521, 974], [554, 1030], [657, 1030], [669, 1010], [698, 961], [703, 917], [692, 857], [663, 811]]), [601.116, 881.703, 1.065, 18.202, 0.216, -6.0, -6.0, 1.497, -0.034]);

    // ── white ball and black sphere, top left ──
    R.dome(sm([[0, 162], [40, 170], [50, 126], [75, 98], [110, 90], [150, 100], [172, 130], [160, 165], [130, 180], [100, 182], [70, 200], [50, 240], [0, 250]]), WH, 0.1, 0.25, 40, 1);
    // chain bit at the left edge

    // ── the face ──
    const FACE = sm([[0, 250], [60, 230], [120, 205], [184, 195], [283, 153], [305, 160], [379, 150], [470, 183], [494, 182], [534, 224], [552, 255], [563, 345], [580, 405], [610, 440], [630, 480], [644, 520], [644, 570], [640, 634], [620, 686], [583, 729], [520, 760], [473, 786], [453, 815], [425, 859], [373, 898], [310, 909], [262, 890], [215, 830], [213, 791], [223, 713], [202, 696], [183, 707], [164, 733], [163, 751], [119, 799], [77, 810], [36, 804], [0, 790]]);
    R.dome(FACE, lin(0, 200, 600, 800, [[0, '#dfe3ec'], [0.5, '#e6e9ef'], [1, '#d6dae4']]), 0.12, 0.2, 60, 1);
    // inner bulges for the clay look
    for (const [pts, hh] of [
      [[[0, 300], [60, 260], [120, 250], [150, 300], [140, 380], [90, 450], [30, 500], [0, 520]], 0.06],
      [[[30, 610], [80, 560], [150, 540], [210, 560], [240, 620], [200, 700], [140, 780], [60, 800], [10, 760]], 0.06],
      [[[380, 560], [460, 560], [520, 620], [520, 690], [460, 720], [380, 700], [350, 640]], 0.05]]) R.dome(sm(pts), null, 0.3, hh, 50, 1);

    // left flowing black bands (measured outlines)
    const BANDS = [
      [[329, 152], [274, 158], [232, 166], [251, 166], [274, 164], [264, 193], [249, 213], [173, 255], [145, 281], [134, 309], [143, 363], [141, 378], [118, 409], [35, 475], [0, 512], [0, 586], [42, 516], [85, 476], [145, 434], [166, 411], [174, 383], [170, 317], [182, 290], [204, 270], [248, 245], [271, 225], [286, 202], [302, 158]],
      [[297, 459], [229, 468], [169, 492], [155, 492], [93, 540], [45, 641], [8, 696], [16, 752], [33, 778], [53, 788], [76, 790], [90, 786], [102, 776], [76, 787], [48, 783], [28, 768], [16, 735], [16, 713], [22, 692], [34, 674], [57, 636], [79, 571], [94, 548], [114, 530], [205, 485], [228, 478], [251, 484]],
      [[329, 421], [187, 446], [170, 471], [217, 449], [329, 431]],
      [[237, 500], [217, 505], [156, 538], [120, 546], [107, 558], [96, 578], [139, 548], [183, 537], [225, 515]],
      [[329, 389], [215, 397], [249, 406], [280, 406], [329, 398]],
      [[194, 615], [182, 618], [173, 669], [188, 665], [202, 651], [212, 656], [214, 667], [196, 690], [235, 683], [248, 688], [264, 685], [252, 659], [267, 620], [238, 634], [223, 637]]];
    clipAH(FACE, () => { for (const b of BANDS) ink(sm(b)); });
    // right side contour stripes (fitted stripe phases), dark lines thinner than the white
    const SR = sm([[460, 250], [520, 260], [555, 300], [565, 345], [600, 428], [640, 500], [645, 600], [640, 690], [560, 700], [480, 668], [470, 610], [400, 560], [365, 500], [300, 462], [215, 470], [200, 440], [230, 400], [340, 366], [430, 345], [470, 320], [470, 280]]);
    const zcv = E.fx(`const float ZRC[168] = float[168](-7.452,-6.750,-6.016,-5.256,-5.023,-5.338,-6.424,-7.794,-9.102,-8.697,-6.225,-5.968,-7.629,-9.978,-6.877,-5.621,-4.868,-4.541,-4.670,-5.142,-5.901,-7.629,-9.110,-7.913,-5.743,-7.972,-9.555,-10.473,-6.358,-4.487,-3.188,-4.260,-3.811,-5.122,-4.509,-8.023,-7.745,-3.891,-10.180,-10.840,-10.793,-10.069,-5.469,-3.954,-0.363,-4.979,-1.782,-4.276,-2.663,-6.960,-0.214,-7.004,-3.197,-11.114,-9.942,-8.408,-3.242,-3.421,-1.421,-1.628,-1.145,-1.959,-3.656,-0.485,-3.546,-3.262,-3.639,-3.880,-4.986,-5.770,-0.775,-0.065,-0.181,-0.466,0.565,-2.613,1.148,-1.175,-1.344,-1.874,-1.815,-2.208,-2.126,-2.817,0.163,-0.196,0.693,1.745,0.387,3.457,0.206,0.581,-0.090,0.118,-0.189,-0.302,-0.980,-0.578,1.058,1.415,2.307,2.885,1.834,0.783,2.712,1.627,1.857,1.635,1.590,1.320,0.982,0.738,2.386,3.246,4.162,5.043,6.063,7.256,3.300,3.782,3.191,3.194,3.132,2.909,2.491,2.158,4.087,5.158,6.235,7.382,8.434,8.347,5.983,5.052,5.588,5.086,4.936,4.642,4.202,3.984,6.040,7.158,8.246,9.214,9.735,9.330,8.213,7.248,7.053,6.934,6.735,6.437,5.924,5.721,8.110,9.184,10.127,10.735,10.858,10.579,10.088,9.271,8.364,7.792,7.855,7.806,7.591,7.429);
float zr(vec2 p){ vec2 u = clamp((p - vec2(200.0, 250.0)) / vec2(40.9091, 48.8889), vec2(0.), vec2(10.999, 8.999));
  ivec2 i = ivec2(floor(u)); vec2 t = u - vec2(i);
  vec4 bx = vec4((1.-t.x)*(1.-t.x)*(1.-t.x), 3.*t.x*t.x*t.x - 6.*t.x*t.x + 4., -3.*t.x*t.x*t.x + 3.*t.x*t.x + 3.*t.x + 1., t.x*t.x*t.x) / 6.;
  vec4 by = vec4((1.-t.y)*(1.-t.y)*(1.-t.y), 3.*t.y*t.y*t.y - 6.*t.y*t.y + 4., -3.*t.y*t.y*t.y + 3.*t.y*t.y + 3.*t.y + 1., t.y*t.y*t.y) / 6.;
  float f = 0.;
  for (int b = 0; b < 4; b++) for (int a = 0; a < 4; a++) f += ZRC[(i.y + b) * 14 + i.x + a] * bx[a] * by[b];
  return f; }
      vec3 fx(vec2 uv, vec2 p){ float v = cos(6.2832 * zr(p)); return mix(vec3(.03), vec3(.886, .898, .925), smoothstep(-.4, -.2, v)); }`);
    clipAH(FACE, () => clipAH(SR, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(zcv); a.restore(); }));
    // target rings: cheek and lower left lobe
    const rings = (cx, cy, rx, ry, list, rot = 0) => { for (const [r, w] of list) { a.lineWidth = w; a.strokeStyle = INK; a.stroke(ellipseP(cx, cy, rx * r, ry * r, rot)); } };
    a.fillStyle = WH; a.fill(ellipseP(292, 541, 70, 66, 0));
    rings(292, 541, 1, 1, [[62, 7], [46, 7], [31, 6]]); ink(ellipseP(292, 545, 16, 16, 0));
    a.fillStyle = WH; a.fill(ellipseP(72, 722, 64, 70, 0));
    rings(72, 724, 0.86, 1, [[64, 8], [46, 7], [30, 6]]); ink(ellipseP(70, 723, 13, 25, 0));

    // seed eyes, nose and the four hash marks
    const seed = (x, y, rx, ry, rot = 0) => { R.dome(ellipseP(x, y, rx, ry, rot), lin(x, y - ry, x, y + ry, [[0, '#b8bcc4'], [0.6, '#9a9ea8'], [1, '#c4c8d0']]), 0.32, 0.06, ry, 4);
      a.fillStyle = 'rgba(70,70,80,0.5)'; for (let k = -3; k <= 3; k++) a.fillRect(x - rx * 0.7, y + k * ry * 0.18, rx * 1.4, 0.6); };
    for (const s of [[337, 229, 33, 12], [317, 273, 41, 12], [311, 322, 51, 15], [443, 240, 29, 13], [460, 290, 22, 11]]) seed(...s);
    for (const [x, y, rx, ry] of [[343, 187, 32, 7], [427, 203, 36, 8]]) { R.dome(ellipseP(x, y, rx, ry, 0), '#a8acb4', 0.32, 0.04, ry, 4); R.groove(open([[x - rx * 0.8, y], [x, y + 2], [x + rx * 0.8, y]]), 3, INK, 0.36, 0.03, 4, 1); }
    R.pipe(open([[388, 205], [392, 240], [396, 268]]), 12, '#e8ebf0', 0.32, 0.08, 1);
    R.dome(ellipseP(398, 283, 14, 12, 0), '#0c0c10', 0.36, 0.08, 10, 3);
    for (let i = 0; i < 4; i++) R.groove(open([[222 + i * 10, 308], [228 + i * 10, 282]]), 4, INK, 0.3, 0.03, 2, 1);
    R.dome(circleP(386, 641, 15), '#0c0c10', 0.3, 0.1, 12, 3);
    // little moustache tuft
    { const fr = rng(13); for (let i = 0; i < 50; i++) { const x = 370 + fr() * 60, y = 330 + fr() * 20; R.pipe(open([[x, y], [x + (fr() - 0.5) * 8, y + 10 + fr() * 14]]), 1.6, '#f4f6fa', 0.34, 0.02, 1); } }

    R.dome(circleP(110, 200, 38), '#141418', 0.3, 0.2, 30, 3);
    R.flat(sm([[0, 250], [40, 236], [70, 240], [40, 300], [10, 340], [0, 350]]), '#0a0a0c', 0.3, 2);
    { const cr = rng(81); for (let i = 0; i < 70; i++) { const t = cr(); R.bead(4 + t * 60 + cr() * 10, 290 - t * 50 + cr() * 14, 1.6 + cr() * 2.5, '#b8b8be', 0.32, 0.05, 3); } }

    // ── slate drum hat ──
    const HAT = sm([[160, 80], [205, 45], [270, 24], [340, 16], [420, 16], [480, 26], [480, 120], [482, 172], [470, 182], [420, 162], [360, 150], [300, 152], [240, 166], [190, 186], [165, 192], [176, 150]]);
    soft(x => { x.fillStyle = 'rgba(0,0,0,0.8)'; x.fill(HAT); }, 6);
    R.dome(HAT, lin(160, 0, 480, 0, [[0, '#22222a'], [0.5, '#2c2c34'], [1, '#1e1e26']]), 0.3, 0.18, 26, 5);
    R.pipe(open([[163, 190], [200, 175], [250, 158], [300, 149], [360, 148], [420, 157], [460, 170], [482, 178]]), 12, '#4c4e58', 0.42, 0.06, 5);
    R.flat(poly([[367, 14], [386, 12], [388, 152], [370, 150]]), lin(367, 0, 388, 0, [[0, '#2a2c34'], [0.4, '#c8ccd8'], [0.6, '#6c707c'], [1, '#2a2c34']]), 0.5, 3);
    clipAH(HAT, () => { const hr = rng(4); for (let i = 0; i < 60; i++) a.fillRect(170 + hr() * 300, 20 + hr() * 140, 1.2, 1.2); });

    // ── fluffy white beard ──
    const BEARD = sm([[222, 742], [262, 752], [320, 760], [380, 758], [440, 750], [478, 762], [470, 806], [440, 846], [420, 870], [380, 892], [340, 905], [300, 906], [262, 888], [232, 856], [214, 810], [212, 772]]);
    R.dome(BEARD, '#f0f2f6', 0.3, 0.14, 40, 6);
    { const fr = rng(31); for (let i = 0; i < 900; i++) { const t = fr() * 6.283, rr = Math.sqrt(fr()), x = 345 + Math.cos(t) * 128 * rr, y = 822 + Math.sin(t) * 78 * rr;
      const L = 8 + fr() * 14, an = Math.atan2(y - 760, x - 345) + (fr() - 0.5) * 0.8;
      a.strokeStyle = fr() < 0.85 ? 'rgba(252,252,255,0.9)' : 'rgba(150,154,166,0.5)'; a.lineWidth = 0.9; a.beginPath(); a.moveTo(x, y); a.lineTo(x + Math.cos(an) * L, y + Math.sin(an) * L); a.stroke(); } }

    // ── glittering red lips with a glowing rim ──
    const LIPS = sm([[250, 702], [290, 692], [360, 690], [430, 694], [480, 702], [496, 724], [486, 748], [440, 756], [370, 758], [300, 756], [256, 748], [244, 726]]);
    soft(x => { x.strokeStyle = 'rgba(255,190,150,0.95)'; x.lineWidth = 18; x.stroke(LIPS); }, 9);
    R.dome(LIPS, '#b03c40', 0.34, 0.14, 26, 7);
    { const gr = rng(55); for (let i = 0; i < 160; i++) { const x = 260 + gr() * 230, y = 700 + gr() * 52; a.fillStyle = gr() < 0.6 ? '#f8d070' : '#ffe8b0'; a.fill(circleP(x, y, 0.8 + gr() * 2)); } }
    for (let i = 0; i < 26; i++) { const t = i / 26 * 6.283, x = 370 + Math.cos(t) * 126, y = 724 + Math.sin(t) * 34; soft(x2 => { x2.fillStyle = '#fff4e0'; x2.fill(circleP(x, y, 4)); }, 1.5); }
    for (let i = 0; i < 18; i++) { const x = 300 + i * 9; R.pipe(open([[x, 752], [x + 1, 768 + (i % 3) * 5]]), 2, '#6a1c20', 0.36, 0.02, 7); }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 26, wrap: 0.55, ao: 0.5, coat: 0.08 }),            // 1 white clay
        E.mat({ dif: 1, spec: 0.5, shin: 40, wrap: 0.4, ao: 0.3, coat: 0.15 }),              // 2 black paint
        E.mat({ dif: 0.6, spec: 1.1, shin: 80, metal: 0.6, ao: 0.2, coat: 0.4 }),            // 3 black gloss / chrome
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.5, ao: 0.4, coat: 0.1 }),               // 4 seed eyes
        E.mat({ dif: 1, spec: 0.7, shin: 50, wrap: 0.4, ao: 0.4, coat: 0.25 }),              // 5 slate hat
        E.mat({ dif: 1, spec: 0.1, shin: 12, wrap: 0.8, ao: 0.2, emis: 0.15 }),              // 6 fur
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.5, ao: 0.2, coat: 0.3, emis: 0.15 }),   // 7 red lips
      ],
      light: [-0.35, 0.65, 0.68], lc: [0.6, 0.6, 0.62], amb: [0.5, 0.5, 0.52],
      envTop: [0.96, 0.97, 1], envHor: [0.55, 0.56, 0.6], envBot: [0.06, 0.06, 0.08], envK: [0.4, 0.9, 0, 0],
      r1: 3, r2: 10, k: [0, 0.6, 0.4, 90], shadow: [-4, 7, 0.5, 8]
    });
    E.grain(0.03, 8);
  }
});
