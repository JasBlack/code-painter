'use strict';
// s40 — "Gold relics in the milk": a lavender-white porcelain wave with a zebra-striped
// curl and cow spots, a yellow-green dish holding gold face/brain/heart plaques, a silver
// shield, black/white rods with a chrome elbow, a glowing red bar, purple + cream frame behind.
REC.register('s40', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const soft = (fn, blur, alpha = 1, op = 'source-over') => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.globalCompositeOperation = op; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const fe = (x, cx, cy, rx, ry, rot, col) => { x.fillStyle = col; x.fill(ellipseP(cx, cy, rx, ry, rot)); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const sparkle = (path, n, seed, col, rmax = 0.9) => clipA(path, () => {
      const r = rng(seed); a.fillStyle = col;
      for (let i = 0; i < n; i++) { a.globalAlpha = 0.3 + r() * 0.6; a.beginPath(); a.arc(r() * 726, r() * 1024, 0.3 + r() * rmax, 0, 6.283); a.fill(); }
      a.globalAlpha = 1;
    });

    // ── background: green-grey felt (top-left), black, purple board, dark brown right ──
    R.flat(rrect(-10, -10, 746, 1044, 0), '#070304', 0, 0);
    const green = P([[-10, -10], [330, -10], [330, 75], [250, 75], [250, 290], [200, 300], [150, 292], [120, 300], [80, 288], [40, 296], [-10, 290]], true, false);
    R.flat(green, '#50706b', 0.0, 0);
    sparkle(green, 2500, 3, '#2c3c3a', 0.8);
    soft(x => {
      fe(x, 70, 30, 45, 16, 0, '#5d3a4a'); fe(x, 200, 42, 44, 16, 0, '#5d3a4a'); fe(x, 70, 232, 34, 26, 0, '#5d3a4a');
      fe(x, 0, 200, 22, 70, 0, '#5d3a4a'); fe(x, 110, 296, 150, 14, 0, '#5d3a4a'); fe(x, 240, 150, 20, 60, 0, '#5d3a4a');
    }, 9, 0.9);
    R.flat(P([[-10, 292], [250, 292], [250, 440], [-10, 440]], true, false), '#030203', 0.0, 0);
    // dark brown right column
    R.flat(P([[600, -10], [736, -10], [736, 780], [600, 780]], true, false), '#2c1016', 0.0, 0);
    soft(x => { fe(x, 690, 120, 30, 80, 0, '#1a0a0c'); fe(x, 640, 400, 22, 120, 0, '#150808'); }, 18, 0.8);
    // purple board
    const purple = P([[330, -10], [665, -10], [665, 215], [612, 215], [612, 548], [248, 548], [248, 75], [330, 75]], true, false);
    const pg = a.createLinearGradient(250, 0, 660, 540); pg.addColorStop(0, '#6a10cc'); pg.addColorStop(0.5, '#7612d6'); pg.addColorStop(1, '#7a10d8');
    R.flat(purple, pg, 0.02, 6);
    sparkle(purple, 1800, 5, '#d8c0ff', 0.6);
    // grey square + gold star
    R.dome(rrect(408, -20, 200, 170, 3), '#aaa4b0', 0.05, 0.05, 4, 4);
    const starPts = [];
    for (let i = 0; i < 16; i++) { const ang = -1.5 + i / 16 * 6.283, r = i % 2 ? 24 : 58, w = i % 2 ? 0 : 0.16; starPts.push([500 + Math.cos(ang + w) * r, 62 + Math.sin(ang + w) * r * 0.95]); }
    R.dome(P(starPts, true, true), '#e8c56a', 0.1, 0.1, 6, 2);
    // cream frame (L with an upturn)
    const frame = new Path2D();
    frame.addPath(P([[312, -20], [352, -20], [352, 150], [362, 166], [540, 166], [540, 148], [586, 148], [586, 188], [576, 198], [350, 198], [322, 186], [312, 160]], true, false));
    R.dome(frame, '#fbf8c4', 0.08, 0.1, 7, 4);

    // ── the porcelain milk: whole lower field + wave + horn ──
    const wave = [[236, 100], [244, 70], [234, 34], [210, 14], [180, 12], [158, 26], [146, 52], [138, 90], [134, 111], [124, 205], [109, 280], [96, 342], [78, 392], [46, 405],
      [20, 386], [-20, 366], [-20, 1044], [746, 1044], [746, 660], [612, 610], [612, 548], [470, 548], [462, 520], [461, 443], [450, 379], [428, 321], [386, 271], [336, 236],
      [271, 214], [207, 186], [170, 150], [163, 118], [168, 82], [182, 52], [205, 46], [222, 62], [226, 96]];
    const waveP = P(wave, true, true);
    const wg = a.createLinearGradient(100, 100, 600, 1000);
    wg.addColorStop(0, '#e0e8fa'); wg.addColorStop(0.4, '#d0d8f4'); wg.addColorStop(0.75, '#bec6ea'); wg.addColorStop(1, '#b0b8e2');
    R.dome(waveP, wg, 0.1, 0.18, 26, 1);
    // lime / violet stains on the wave
    clipA(waveP, () => soft(x => {
      fe(x, 262, 250, 34, 26, 0.5, '#eef4b8'); fe(x, 318, 322, 22, 44, 0.2, '#eaf2b4'); fe(x, 300, 440, 30, 36, 0, '#e6f0b0'); fe(x, 390, 330, 18, 30, 0, '#e8f0c4');
      fe(x, 190, 480, 70, 14, 0.1, '#e4eeb4'); fe(x, 60, 430, 40, 20, 0.3, '#e8f0c0');
      fe(x, 200, 190, 18, 14, 0.5, '#9c78c4'); fe(x, 300, 285, 14, 22, 0, '#a07ac8'); fe(x, 330, 400, 12, 26, 0, '#9e7ac6'); fe(x, 260, 470, 30, 12, 0, '#a47cc8');
      fe(x, 140, 470, 40, 10, 0.3, '#a888cc'); fe(x, 440, 350, 14, 50, 0.1, '#4a2230'); fe(x, 452, 440, 8, 30, 0, '#6a3848');
    }, 10, 0.9));
    // zebra curl
    const zeb = P([[134, 111], [152, 149], [184, 199], [227, 236], [277, 267], [315, 317], [320, 380], [304, 430], [268, 468], [202, 482], [134, 462], [78, 432], [42, 406],
      [78, 392], [96, 342], [109, 280], [124, 205]], true, true);
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 F = vec2(150., -90.);
      vec2 d = p - F;
      float th = atan(d.x, d.y);
      // curl: near the bottom-left the stripes wrap round towards the left edge
      float bl = smoothstep(330., 480., p.y) * smoothstep(260., 60., p.x);
      float ph = th * 30. + 0.012 * (p.y - 100.) * (1. - smoothstep(120., 300., p.x)) + bl * (p.y - 380.) * 0.09;
      // fold seam
      float side = step(0., (p.x - 200.) * 0.92 - (p.y - 300.) * 0.45);
      ph += side * 0.5 * step(300., p.y);
      float s = sin(6.2832 * ph);
      return vec3(smoothstep(-0.12, 0.12, s)) * 0.9 + 0.05; }`);
    clipA(zeb, () => { a.save(); a.globalCompositeOperation = 'multiply'; img(zcv); a.restore(); });
    soft(x => { x.strokeStyle = '#8060b0'; x.lineWidth = 10; x.stroke(P([[315, 317], [320, 380], [304, 430], [268, 468], [202, 482], [134, 462]], false)); }, 6, 0.5);

    // ── cow spots on the milk (speckled dark brown with pink halos) ──
    const spots = [[90, 785, 47, 64, 0.1, 1], [70, 1000, 92, 56, 0, 2], [200, 895, 30, 40, 0.3, 3], [272, 857, 25, 25, 0, 4], [352, 902, 32, 34, 0, 5], [690, 880, 62, 135, 0, 6],
      [148, 905, 8, 8, 0, 7], [642, 578, 30, 24, 0.3, 8], [700, 610, 28, 50, 0, 9], [20, 640, 16, 26, 0, 10], [410, 990, 26, 14, 0, 11]];
    soft(x => { x.fillStyle = '#c490c8'; for (const [cx, cy, rx, ry, rot, sd] of spots) x.fill(P(blob(cx, cy, rx * 1.25, ry * 1.2, sd, 12, 0.18, rot))); }, 14, 0.85);
    const spotPath = new Path2D();
    for (const [cx, cy, rx, ry, rot, sd] of spots) spotPath.addPath(P(blob(cx, cy, rx, ry, sd, 12, 0.18, rot)));
    soft(x => { x.fillStyle = '#2b1016'; x.fill(spotPath); }, 3, 1);
    sparkle(spotPath, 3000, 9, '#f0d8e8', 0.6);

    // right cloud with spots
    // scalloped outline: resample the base outline and push bumps outward
    const scallop = (pts, len, amp) => {
      const out = [], n = pts.length; let acc = 0;
      for (let i = 0; i < n; i++) {
        const p0 = pts[i], p1 = pts[(i + 1) % n], L = Math.hypot(p1[0] - p0[0], p1[1] - p0[1]), k = Math.max(1, Math.round(L / 3));
        const nx = (p1[1] - p0[1]) / L, ny = -(p1[0] - p0[0]) / L;
        for (let j = 0; j < k; j++) { const u = j / k, d = amp * Math.pow(Math.abs(Math.sin(Math.PI * (acc + L * u) / len)), 0.6); out.push([p0[0] + (p1[0] - p0[0]) * u - nx * d, p0[1] + (p1[1] - p0[1]) * u - ny * d]); }
        acc += L;
      }
      return out;
    };
    const cloudB = [[736, 214], [712, 222], [684, 244], [656, 270], [632, 304], [618, 350], [616, 400], [614, 470], [618, 540], [624, 600], [630, 660], [646, 720], [664, 780]];
    const cp = P([...scallop(cloudB, 62, 20), [736, 800]], true, false);
    R.dome(cp, '#cfd8f6', 0.12, 0.22, 34, 1);
    const cspot = new Path2D();
    const CS = [[697, 292, 30, 30, 21], [652, 357, 24, 30, 22], [714, 362, 16, 32, 23], [684, 482, 46, 44, 24], [690, 640, 44, 58, 25], [650, 560, 12, 12, 26]];
    soft(x => { x.fillStyle = '#c890b8'; for (const [cx, cy, rx, ry, sd] of CS) x.fill(P(blob(cx, cy, rx * 1.2, ry * 1.2, sd, 11, 0.3))); }, 8, 0.8);
    for (const [cx, cy, rx, ry, sd] of CS)
      cspot.addPath(P(blob(cx, cy, rx, ry, sd, 11, 0.3)));
    clipA(cp, () => soft(x => { x.fillStyle = '#3a1418'; x.fill(cspot); }, 2, 1));
    sparkle(cspot, 1200, 11, '#f0d8e8', 0.6);

    // ── the dish: yellow rim, green band, black dashes ──
    const DC = [408, 745], DRX = 233, DRY = 255;
    const ringPts = (k, amp, seed) => { const r = rng(seed), pts = []; for (let i = 0; i < 64; i++) { const t = i / 64 * 6.283, j = 1 + (r() - 0.5) * amp; pts.push([DC[0] + Math.cos(t) * DRX * k * j, DC[1] + Math.sin(t) * DRY * k * j]); } return pts; };
    const outer = P(ringPts(1.03, 0.02, 1)), inner = P(ringPts(0.85, 0.015, 2));
    R.dome(outer, '#e6d65e', 0.14, 0.08, 8, 4);
    clipA(outer, () => {
      a.lineWidth = 16; a.strokeStyle = '#58b834'; a.stroke(P(ringPts(0.875, 0.01, 3)));
      const dr = rng(7); a.fillStyle = '#141008';
      for (let i = 0; i < 26; i++) { const t = i / 26 * 6.283 + dr() * 0.1, k = 0.92 + dr() * 0.04; a.save(); a.translate(DC[0] + Math.cos(t) * DRX * k, DC[1] + Math.sin(t) * DRY * k); a.rotate(t + 1.57); a.fill(ellipseP(0, 0, 10 + dr() * 10, 3 + dr() * 2)); a.restore(); }
    });
    const bowl = a.createRadialGradient(360, 700, 20, 408, 745, 240); bowl.addColorStop(0, '#e2e6f8'); bowl.addColorStop(1, '#c6cce8');
    R.dome(inner, bowl, 0.12, 0.04, 14, 1);
    // black pool + zebra wedge inside the dish
    const pool = P([[420, 548], [520, 530], [600, 545], [626, 590], [618, 650], [596, 700], [560, 724], [510, 722], [466, 700], [438, 660], [420, 600]]);
    clipA(inner, () => { a.fillStyle = '#0a0506'; a.fill(pool); });
    const wedge = P([[604, 618], [622, 680], [612, 760], [582, 830], [530, 892], [470, 932], [402, 946], [372, 906], [402, 860], [452, 802], [502, 760], [552, 722], [586, 672]]);
    const wcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 d = p - vec2(614., 483.); float th = atan(d.x, d.y);
      float s = sin(th * 92. + length(d) * 0.012);
      return vec3(smoothstep(-0.15, 0.15, s)) * 0.92 + 0.04; }`);
    clipA(inner, () => clipA(wedge, () => img(wcv)));
    soft(x => { x.fillStyle = '#e8ecf8'; x.fill(P([[560, 560], [600, 580], [612, 640], [596, 690], [580, 650], [570, 600]])); }, 4, 0.9);
    soft(x => { fe(x, 300, 700, 90, 70, 0, '#f4f4c0'); fe(x, 250, 620, 40, 60, 0, '#58b838'); }, 20, 0.55);

    // ── silver shield ──
    const shield = P([[310, 452], [360, 432], [410, 440], [412, 490], [396, 520], [364, 536], [330, 526], [310, 494]]);
    R.dome(shield, '#d0d0da', 0.2, 0.08, 6, 3);
    const sr = rng(17);
    for (let i = 0; i < 16; i++) { const t0 = sr() * 6.28; R.pipe(P([[358 + Math.cos(t0) * 8, 484 + Math.sin(t0) * 8], [358 + Math.cos(t0 + 0.3) * 28, 484 + Math.sin(t0 + 0.3) * 26], [358 + Math.cos(t0 + 0.5) * 42, 484 + Math.sin(t0 + 0.4) * 38]], false), 4, '#d4d4dc', 0.26, 0.05, 3); }
    R.dome(ellipseP(362, 490, 16, 20, 0), '#c8c8d0', 0.26, 0.08, 8, 3);

    // ── rods and chrome elbow ──
    R.pipe(P([[522, 262], [449, 468]], false), 17, '#1c1a1e', 0.3, 0.14, 5);
    R.pipe(P([[522, 256], [530, 300]], false), 22, '#9a9aa2', 0.35, 0.12, 3);
    R.dome(rrect(532, 272, 18, 26, 3), '#90d020', 0.4, 0.08, 4, 5);
    R.pipe(P([[430, 480], [395, 668]], false), 21, '#f2f2f4', 0.36, 0.14, 5);
    R.pipe(P([[398, 652], [394, 672]], false), 24, '#8a8a92', 0.4, 0.1, 3);
    R.pipe(P([[438, 472], [500, 490], [530, 506], [538, 530], [536, 562]], false), 30, '#9c9ca6', 0.4, 0.18, 3);
    R.pipe(P([[430, 468], [450, 474]], false), 36, '#a4a4ae', 0.42, 0.14, 3);
    R.groove(P([[510, 480], [504, 504]], false), 3, '#303036', 0.58, 0.05, 3);

    // ── gold plaques ──
    const GOLD = '#e6c65a';
    const plate = (cx, cy, sz, rot) => { const c = Math.cos(rot), s = Math.sin(rot), pts = [[-1, -1], [1, -1], [1, 1], [-1, 1]].map(([u, v]) => [cx + (u * c - v * s) * sz / 2, cy + (u * s + v * c) * sz / 2]); return P(pts, true, false); };
    const T = (cx, cy, rot) => (u, v) => [cx + u * Math.cos(rot) - v * Math.sin(rot), cy + u * Math.sin(rot) + v * Math.cos(rot)];
    // filigree
    const fil = (pts) => R.pipe(P(pts, false), 7, GOLD, 0.34, 0.08, 2);
    fil([[282, 540], [300, 532], [330, 540], [352, 560], [370, 575]]); fil([[292, 548], [320, 556], [345, 572]]);
    fil([[196, 650], [206, 668], [230, 678], [256, 672]]); fil([[200, 668], [218, 686], [250, 690]]);
    fil([[300, 782], [290, 800], [310, 820], [330, 818], [346, 830]]); fil([[285, 772], [298, 790], [316, 800]]);
    fil([[392, 806], [385, 826], [398, 840], [420, 836], [436, 824]]); fil([[440, 720], [454, 740], [446, 760], [456, 780]]); fil([[432, 700], [448, 716]]);
    // brain square
    R.dome(plate(290, 625, 124, 0.3), GOLD, 0.26, 0.08, 5, 2);
    R.dome(rrect(222, 548, 22, 34, 3), GOLD, 0.26, 0.06, 4, 2);
    { const t = T(290, 625, 0.3); for (const [cl, w] of [[[[-34, -20], [-20, -34], [0, -30], [18, -36], [34, -22], [36, 0]], 12], [[[-36, 4], [-24, 14], [-8, 8], [6, 20], [24, 14], [34, 26]], 12],
      [[[-26, -6], [-10, -16], [8, -12], [20, -2]], 9], [[[-30, 26], [-12, 34], [8, 30], [20, 38]], 10]]) R.pipe(P(cl.map(q => t(...q)), false), w, '#dcb850', 0.32, 0.12, 2); }
    // face square
    R.dome(plate(372, 736, 124, 0.12), GOLD, 0.26, 0.08, 5, 2);
    R.dome(rrect(296, 712, 18, 18, 3), '#808088', 0.3, 0.04, 3, 3);
    { const t = T(372, 736, 0.12);
      R.dome(ellipseP(...t(0, 2), 40, 48, 0.12), '#dcb850', 0.32, 0.1, 18, 2);
      R.dome(P([[-6, -14], [6, -14], [8, 16], [0, 20], [-8, 16]].map(q => t(...q))), '#e0bc54', 0.4, 0.08, 5, 2);
      for (const sx of [-1, 1]) R.groove(P([[sx * 10, -6], [sx * 20, -8], [sx * 30, -5]].map(q => t(...q)), false), 3, '#8a6a20', 0.44, 0.05, 2);
      R.pipe(P([[-22, 28], [-10, 22], [0, 26], [10, 22], [22, 28]].map(q => t(...q)), false), 8, '#dcb850', 0.42, 0.06, 2);
      R.groove(P([[-10, 34], [0, 36], [10, 34]].map(q => t(...q)), false), 3, '#8a6a20', 0.44, 0.04, 2);
      for (const u of [-18, -9, 0, 9, 18]) R.pipe(P([[u * 0.6, -28], [u, -44]].map(q => t(...q)), false), 4, '#dcb850', 0.4, 0.05, 2); }
    // heart
    const heart = P([[514, 692], [470, 650], [456, 612], [466, 578], [492, 566], [514, 578], [536, 564], [562, 574], [574, 606], [562, 648]]);
    R.dome(heart, GOLD, 0.24, 0.14, 16, 2);
    { const hr = rng(8); for (let i = 0; i < 12; i++) { const y0 = 580 + i * 8; R.pipe(P([[476 + hr() * 10, y0 + 6], [500, y0 + hr() * 6], [530, y0 + 4], [556 - hr() * 8, y0 - 4]], false), 4, '#dcb850', 0.36, 0.04, 2); }
      R.dome(ellipseP(516, 616, 16, 22, 0), '#dcb850', 0.38, 0.06, 8, 2); }

    // ── glowing red bar + balls ──
    R.pipe(P([[80, 594], [224, 640]], false), 40, '#f8b0a4', 0.2, 0.1, 7);
    R.bead(162, 626, 16, '#e82010', 0.3, 0.16, 5);
    for (const [x, y, r, c] of [[278, 700, 5, '#e83010'], [274, 737, 5, '#e83010'], [245, 805, 10, '#e82010'], [219, 517, 7, '#98c830'], [198, 541, 7, '#98c830']]) R.bead(x, y, r, c, 0.3, 0.1, 5);

    // ── top-left beads ──
    R.bead(76, 12, 14, '#c8c8cc', 0.1, 0.2, 3);
    R.bead(80, 100, 22, '#8a9294', 0.1, 0.2, 3);

    // ── bottom: green strips, cable, flashlight ──
    R.flat(rrect(-10, 1004, 205, 30, 0), '#12a020', 0.02, 0);
    R.flat(rrect(390, 1004, 346, 30, 0), '#12a020', 0.02, 0);
    R.pipe(P([[222, 930], [232, 962], [262, 976], [292, 972], [300, 960]], false), 10, '#141214', 0.2, 0.1, 5);
    R.pipe(P([[452, 972], [470, 996], [476, 1030]], false), 10, '#141214', 0.2, 0.1, 5);
    R.pipe(P([[478, 1022], [632, 986]], false), 40, '#8e8e98', 0.2, 0.2, 3);
    R.pipe(P([[630, 986], [664, 978]], false), 48, '#d02820', 0.22, 0.2, 5);
    R.bead(606, 994, 12, '#6a6a72', 0.4, 0.1, 3);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 24, wrap: 0.5, ao: 0.6, coat: 0.06, rim: 0.5 }),                   // 1 porcelain milk
        E.mat({ dif: 0.75, metal: 0.45, spec: 0.8, shin: 22, rim: 0.3, ao: 0.6, tint: [1.1, 1.0, 0.6], grain: 0.15, emis: 0.1 }),     // 2 gold
        E.mat({ dif: 0.6, metal: 0.5, spec: 1.0, shin: 50, rim: 0.3, ao: 0.4, emis: 0.1 }),                     // 3 chrome / silver
        E.mat({ dif: 1, spec: 0.3, shin: 20, wrap: 0.4, ao: 0.4 }),                                         // 4 plastic (frame, dish, square)
        E.mat({ dif: 1, spec: 1.1, shin: 70, wrap: 0.2, coat: 0.2, ao: 0.3 }),                              // 5 gloss rods / balls
        E.mat({ dif: 1, spec: 0.05, shin: 10, wrap: 0.6, grain: 0.1 }),                                     // 6 purple board
        E.mat({ dif: 0.6, emis: 0.55, spec: 0.6, shin: 30, wrap: 0.4 })                                     // 7 glowing bar
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.75, 0.74, 0.8], amb: [0.42, 0.42, 0.48],
      envTop: [1.05, 1.02, 1.0], envHor: [0.6, 0.55, 0.6], envBot: [0.18, 0.12, 0.16], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.5, 0.45, 0.7], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-6, 7, 0.55, 6]
    });

    // ── red glow ──
    const o = E.out;
    for (const [x, y, r, al] of [[150, 615, 130, 0.55], [250, 660, 110, 0.5], [300, 760, 110, 0.5], [270, 800, 70, 0.4], [70, 594, 50, 0.4]]) {
      const g = o.createRadialGradient(x, y, 0, x, y, r); g.addColorStop(0, `rgba(255,30,30,${al})`); g.addColorStop(0.5, `rgba(255,40,50,${al * 0.5})`); g.addColorStop(1, 'rgba(255,0,0,0)'); o.fillStyle = g; o.fillRect(x - r, y - r, 2 * r, 2 * r);
    }
    { const g = o.createLinearGradient(80, 594, 224, 640); g.addColorStop(0, 'rgba(255,190,180,0.8)'); g.addColorStop(1, 'rgba(255,120,110,0.6)'); o.lineCap = 'round'; o.lineWidth = 30; o.strokeStyle = g; o.beginPath(); o.moveTo(84, 595); o.lineTo(210, 636); o.stroke(); }
    { const g = o.createRadialGradient(162, 626, 2, 162, 626, 16); g.addColorStop(0, '#ff9070'); g.addColorStop(0.4, '#f02010'); g.addColorStop(1, '#a00800'); o.fillStyle = g; o.fill(circleP(162, 626, 16)); }
    { const g = o.createLinearGradient(0, 820, 0, 1024); g.addColorStop(0, 'rgba(40,30,50,0)'); g.addColorStop(1, 'rgba(40,30,50,0.35)'); o.fillStyle = g; o.fillRect(0, 820, 726, 204); }
    E.bloom(0.18, 10);
    E.grain(0.04, 40);
  }
});
