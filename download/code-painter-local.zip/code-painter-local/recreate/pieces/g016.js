'use strict';
// g016 — "Desert night lizard": a sticker collage — deep-blue starry night with two moons, a sandstone
// mesa and saguaro desert, a grinning bronze face disc, an orange waffle lizard with a pearl eye,
// purple serrated borders, a lilac worm maze, zebra fields and white / gold pebbles.
REC.register('g016', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    // flush the height buffer after every relief call (a canvas-recording glitch can otherwise drop height strokes)
    for (const k of ['dome', 'flat', 'pipe', 'groove']) { const f0 = R[k]; R[k] = (...args) => { f0(...args); R.h.getImageData(0, 0, 1, 1); }; }
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const F = (path, c) => { a.fillStyle = c; a.fill(path); };
    const K = (path, c, wd) => { a.lineWidth = wd; a.strokeStyle = c; a.lineCap = a.lineJoin = 'round'; a.stroke(path); };
    const lin = (x0, y0, x1, y1, st) => { const g = a.createLinearGradient(x0, y0, x1, y1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const rad = (x, y, r0, r1, st) => { const g = a.createRadialGradient(x, y, r0, x, y, r1); st.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    // sawtooth teeth along an open polyline (side = +1 / -1 picks the normal)
    const saw = (pts, step, len, side) => {
      const p = new Path2D();
      for (let i = 0; i < pts.length - 1; i++) {
        const [x0, y0] = pts[i], [x1, y1] = pts[i + 1], L = Math.hypot(x1 - x0, y1 - y0), k = Math.max(1, Math.round(L / step));
        const nx = side * (y1 - y0) / L, ny = -side * (x1 - x0) / L;
        for (let j = 0; j < k; j++) {
          const u0 = j / k, u1 = (j + 1) / k, um = (u0 + u1) / 2;
          p.moveTo(x0 + (x1 - x0) * u0, y0 + (y1 - y0) * u0);
          p.lineTo(x0 + (x1 - x0) * um + nx * len, y0 + (y1 - y0) * um + ny * len);
          p.lineTo(x0 + (x1 - x0) * u1, y0 + (y1 - y0) * u1); p.closePath();
        }
      }
      return p;
    };
    const DARK = '#2a1810';

    // ── night sky ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 0, 300, 1024, [[0, '#1e44b4'], [0.5, '#1a40b0'], [1, '#2048b8']]), 0, 0);
    soft(x => { x.fillStyle = '#4aaeee'; x.fill(ellipseP(610, 130, 55, 75, 0.3)); x.fillStyle = '#58bcf2'; x.fill(ellipseP(690, 60, 60, 35, 0)); }, 22, 0.95);
    { const r = rng(161); a.fillStyle = '#ffffff';
      for (let i = 0; i < 520; i++) { const u = r(), v = r(), x = 395 + (u + r() - 0.5) * 170, y = 30 + (v + r() - 0.5) * 140; if (y < 15 || y > 190) continue; a.globalAlpha = 0.5 + r() * 0.5; a.beginPath(); a.arc(x, y, 0.5 + r() * r() * 1.8, 0, 6.283); a.fill(); }
      for (const [x, y] of [[48, 380], [295, 160], [235, 760], [295, 742], [312, 755], [18, 690], [16, 160]]) { a.globalAlpha = 0.9; a.beginPath(); a.arc(x, y, 2, 0, 6.283); a.fill(); }
      a.globalAlpha = 1; }

    // ── black night cap (top) ──
    const blackP = P([[92, -10], [385, -10], [372, 18], [350, 52], [322, 90], [292, 108], [255, 108], [220, 98], [182, 94], [152, 110], [130, 140], [126, 170], [128, 188], [118, 202], [98, 214], [92, 150], [100, 70]]);
    R.dome(blackP, '#060404', 0.04, 0.03, 4, 1);
    K(P([[385, -10], [372, 18], [350, 52], [322, 90], [292, 108], [255, 108], [220, 98], [182, 94], [152, 110], [130, 140], [126, 170], [128, 188], [118, 202], [98, 214]], false), '#8a6a50', 2.5);
    const blackR = P([[540, -10], [736, -10], [736, 18], [690, 25], [660, 35], [650, 50], [640, 72], [600, 77], [562, 66], [546, 40]]);
    R.dome(blackR, '#060404', 0.04, 0.03, 4, 1); K(blackR, '#8a6a50', 2);
    const blackT = P([[380, -10], [560, -10], [556, 8], [470, 14], [400, 12]]);
    R.flat(blackT, '#060404', 0.04, 1);

    // ── top-left corner: orange disc, yellow band, teal stucco ──
    R.flat(P([[-10, -10], [200, -10], [178, 0], [130, 22], [85, 50], [45, 78], [15, 108], [-10, 140]], true, false), '#f6e48e', 0.05, 1);
    R.flat(P([[-10, 21], [20, 19], [56, 16], [42, 34], [22, 54], [-10, 82]], true, false), '#f07a28', 0.06, 1);
    R.flat(P([[-10, -10], [62, -10], [56, 16], [20, 19], [-10, 21]], true, false), '#060404', 0.04, 1);
    const tealP = P([[-10, 140], [10, 112], [40, 80], [80, 52], [125, 26], [168, 4], [178, 0], [140, 28], [112, 55], [98, 88], [92, 128], [94, 160], [99, 185], [92, 207], [80, 232], [62, 260], [36, 282], [10, 295], [-10, 305]]);
    R.dome(tealP, '#a8dccf', 0.05, 0.04, 6, 1);
    clipA(tealP, () => { const r = rng(7); for (let i = 0; i < 900; i++) { a.fillStyle = r() < 0.5 ? 'rgba(110,170,160,0.45)' : 'rgba(230,250,245,0.5)'; a.beginPath(); a.ellipse(r() * 180, r() * 310, 1.5 + r() * 4, 0.8 + r() * 1.2, 0.4, 0, 6.283); a.fill(); } });
    K(P([[178, 0], [140, 28], [112, 55], [98, 88], [92, 128], [94, 160], [99, 185], [92, 207], [80, 232], [62, 260], [36, 282], [10, 295], [-10, 305]], false), '#5a3420', 3);
    K(P([[178, 0], [140, 28], [112, 55], [98, 88], [92, 128], [94, 160], [99, 185], [92, 207], [80, 232], [62, 260], [36, 282], [10, 295], [-10, 305]], false), 'rgba(240,210,180,0.7)', 1);

    // ── moons ──
    const moon = (cx, cy, r, seed) => {
      R.dome(circleP(cx, cy, r), rad(cx - r * 0.3, cy - r * 0.3, 2, r * 1.1, [[0, '#f4ecc0'], [0.7, '#e2d498'], [1, '#c8b47a']]), 0.1, 0.06, r * 0.4, 4);
      const q = rng(seed);
      soft(x => { for (let i = 0; i < 14; i++) { x.fillStyle = q() < 0.5 ? 'rgba(150,140,100,0.55)' : 'rgba(190,180,130,0.6)'; const an = q() * 6.283, d = q() * r * 0.75; x.fill(ellipseP(cx + Math.cos(an) * d, cy + Math.sin(an) * d, r * (0.08 + q() * 0.2), r * (0.06 + q() * 0.14), q() * 3)); } }, 2, 1);
      K(circleP(cx, cy, r), '#5a4020', 2);
    };
    moon(193, 150, 45, 3); moon(55, 590, 62, 5);

    // ── purple lilac worm maze (right) ──
    const mazeP = P([[468, 246], [520, 228], [562, 214], [600, 168], [650, 112], [695, 72], [736, 56], [736, 700], [690, 690], [670, 640], [660, 560], [652, 470], [645, 410], [610, 395], [570, 385], [548, 350], [500, 300]]);
    const mz = E.fx(`vec3 fx(vec2 uv, vec2 p){
      vec2 q = p + 25. * vec2(vnoise(p * 0.01), vnoise(p * 0.01 + 5.2));
      float v = (q.x * 0.35 + q.y * 0.94) / 27. + 5. * vnoise(q * 0.014) + 2.2 * vnoise(q * 0.03 + 7.);
      float b = abs(fract(v) - 0.5), on = smoothstep(590., 620., p.x);
      float w = smoothstep(0.29, 0.25, b) * on;
      float ed = smoothstep(0.22, 0.26, b) * smoothstep(0.32, 0.27, b) * on;
      vec3 pur = vec3(0.50, 0.30, 0.68) * (0.92 + 0.16 * vnoise(p * 0.4));
      vec3 lil = mix(vec3(0.98, 0.92, 0.93), vec3(0.86, 0.74, 0.86), smoothstep(0.05, 0.19, b));
      vec3 c = mix(pur, lil, w);
      return mix(c, vec3(0.42, 0.26, 0.30), ed * 0.7); }`);
    R.dome(mazeP, '#7e4cac', 0.08, 0.05, 6, 1);
    clipA(mazeP, () => img(mz));
    a.fillStyle = '#8a5ad0'; a.fill(saw([[468, 246], [520, 228], [562, 214], [600, 168]], 12, 14, 1)); K(mazeP, '#e0d0f4', 3); K(mazeP, DARK, 1.5);

    // ── mesa ──
    const mesa = P([[318, 205], [330, 196], [380, 192], [420, 190], [462, 196], [470, 215], [472, 250], [500, 280], [540, 300], [570, 330], [300, 380], [250, 385], [262, 350], [290, 310], [318, 270]], true, false);
    R.flat(mesa, lin(300, 190, 520, 380, [[0, '#e4b074'], [0.4, '#e0aa70'], [0.6, '#f0cc90'], [1, '#f4d898']]), 0.06, 1);
    clipA(mesa, () => soft(x => {
      x.fillStyle = '#c89660'; x.fill(P([[380, 200], [420, 196], [425, 275], [400, 300], [372, 270]])); x.fill(P([[456, 200], [470, 210], [472, 255], [455, 260]]));
      x.fillStyle = '#f6dca0'; x.fill(P([[300, 340], [360, 300], [420, 310], [480, 300], [560, 330], [480, 360], [380, 370]]));
      x.fillStyle = '#d4a46c'; x.fill(P([[330, 210], [345, 205], [348, 270], [330, 280]]));
    }, 5, 0.85));
    K(P([[330, 200], [332, 270]], false), '#b07c48', 1.5); K(P([[380, 194], [382, 280]], false), '#b07c48', 1.5); K(P([[420, 192], [422, 285]], false), '#b07c48', 1.5);

    // ── desert floor ──
    const desert = P([[240, 360], [300, 352], [380, 345], [470, 340], [560, 330], [620, 350], [650, 420], [660, 520], [665, 620], [640, 660], [560, 660], [470, 640], [380, 630], [300, 615], [240, 600], [230, 480]]);
    R.flat(desert, lin(240, 340, 600, 660, [[0, '#ecc898'], [0.5, '#e2b484'], [1, '#d8a070']]), 0.06, 1);
    clipA(desert, () => soft(x => {
      x.fillStyle = '#c08050'; for (const [cx, cy, rx, ry] of [[430, 400, 140, 12], [560, 380, 80, 10], [330, 440, 60, 10], [600, 500, 60, 14], [520, 600, 120, 16], [360, 590, 120, 14]]) x.fill(ellipseP(cx, cy, rx, ry, 0.05));
      x.fillStyle = '#f6e6cc'; for (const [cx, cy, rx, ry] of [[400, 470, 120, 30], [560, 440, 60, 20], [330, 520, 70, 26], [470, 540, 60, 18]]) x.fill(ellipseP(cx, cy, rx, ry, 0));
      x.fillStyle = '#86a8d4'; x.fill(P([[360, 585], [420, 570], [480, 568], [500, 580], [470, 598], [400, 600]]));
    }, 3, 0.9));
    // cacti
    const cactus = (x, y0, y1, w, arms) => {
      const col = '#9a8a5c';
      R.pipe(P([[x, y1], [x, y0]], false), w, col, 0.1, 0.06, 1);
      for (const [side, ya, yb, dx] of arms) R.pipe(P([[x, ya], [x + side * dx, ya], [x + side * dx, yb]], false, false), w * 0.7, col, 0.1, 0.05, 1);
      K(P([[x + w * 0.3, y1], [x + w * 0.3, y0 + w * 0.3]], false), 'rgba(60,50,30,0.6)', w * 0.25);
      a.save(); a.globalAlpha = 0.45; K(P([[x + 2, y1], [x + w * 2.5, y1 + 4]], false), '#8a5a38', w * 0.5); a.restore();
    };
    cactus(425, 372, 545, 18, [[-1, 440, 405, 22], [1, 425, 395, 22]]);
    cactus(507, 465, 578, 12, [[-1, 510, 482, 14], [1, 500, 476, 14]]);
    cactus(458, 525, 612, 11, [[-1, 560, 540, 12], [1, 548, 530, 12]]);
    cactus(400, 505, 585, 10, [[1, 540, 520, 11]]);
    cactus(548, 475, 560, 10, [[-1, 515, 495, 11]]);
    cactus(630, 480, 560, 10, [[-1, 520, 500, 11], [1, 512, 494, 10]]);
    cactus(355, 402, 455, 7, [[-1, 425, 412, 8]]); cactus(492, 420, 470, 6, [[1, 440, 430, 7]]); cactus(590, 420, 460, 6, []); cactus(380, 420, 445, 5, []);

    // ── cream drift (lower left) with a blue sky window ──
    const drift = P([[110, 590], [180, 585], [240, 600], [310, 620], [400, 640], [480, 650], [560, 662], [575, 760], [540, 800], [470, 785], [400, 775], [330, 782], [260, 792], [190, 810], [130, 850], [100, 860], [98, 700]]);
    R.dome(drift, lin(100, 600, 500, 800, [[0, '#e8d6c0'], [0.5, '#f0e2d0'], [1, '#d8b898']]), 0.08, 0.06, 10, 1);
    clipA(drift, () => soft(x => {
      x.fillStyle = '#b07850'; x.fill(P([[100, 700], [150, 690], [190, 740], [170, 800], [120, 830], [100, 800]])); x.fill(P([[200, 640], [260, 640], [240, 680], [200, 670]]));
      x.fillStyle = '#d6aa80'; x.fill(P([[420, 650], [520, 660], [540, 720], [480, 700]]));
    }, 8, 0.85));
    const hole = P([[195, 705], [240, 678], [300, 670], [360, 672], [400, 690], [395, 740], [370, 780], [300, 785], [240, 790], [200, 770], [190, 740]]);
    R.flat(hole, lin(190, 670, 400, 790, [[0, '#1c40b0'], [1, '#2246b8']]), 0.04, 0);
    K(hole, '#e8d4bc', 4); K(hole, DARK, 1.5);
    a.fillStyle = '#fff'; for (const [x, y] of [[235, 762], [292, 742], [312, 756]]) { a.beginPath(); a.arc(x, y, 2.2, 0, 6.283); a.fill(); }

    // ── zebra fields ──
    // stripe flow: low-order phase fields (constants fitted offline to the reference's stripe flow)
    const zcv = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float ph;
      if (p.y < 600.) {
        float u = (p.x - 200.) / 100., v = (p.y - 350.) / 100.;
        ph = 0.15784 - 2.6847 * v - 0.68184 * v * v - 4.3887 * u + 0.16415 * u * v - 0.34459 * u * u;
      } else {
        float u = (p.x - 320.) / 100., v = (p.y - 900.) / 100.;
        ph = 0.37847 - 2.1665 * v + 0.068791 * v * v + 0.1269 * v * v * v - 2.7039 * u - 0.25802 * u * v + 0.21547 * u * v * v
          + 0.22502 * u * u + 0.090653 * u * u * v + 0.059015 * u * u * u;
      }
      float s = cos(6.2832 * ph) - 0.1;
      vec3 wh = vec3(0.95, 0.90, 0.84), bk = vec3(0.04, 0.035, 0.04);
      return mix(wh, bk, smoothstep(-0.12, 0.12, s)); }`);
    const hood = P([[150, 282], [190, 268], [250, 262], [300, 266], [306, 285], [290, 315], [266, 350], [250, 400], [236, 440], [200, 480], [176, 540], [150, 562], [126, 560], [112, 500], [108, 420], [112, 350], [126, 305]]);
    const zebB = P([[96, 870], [140, 845], [200, 810], [280, 790], [360, 778], [440, 776], [500, 784], [548, 800], [560, 860], [556, 940], [550, 1034], [60, 1034], [70, 960], [92, 930]]);
    const zebL = P([[-10, 862], [20, 880], [40, 910], [36, 960], [50, 1034], [-10, 1034]]);
    // purple serrated rim around the hood / drift
    const rimL = [[318, 262], [300, 258], [250, 252], [190, 258], [150, 270], [120, 300], [104, 350], [98, 420], [96, 500], [92, 600], [86, 700], [84, 790], [96, 850], [118, 870]];
    a.fillStyle = '#8a5ad0'; a.fill(saw(rimL, 16, 22, 1));
    K(P(rimL, false), '#8a5ad0', 16);
    R.h.save(); R.h.lineWidth = 16; R.h.strokeStyle = 'rgb(20,32,0)'; R.h.stroke(P(rimL, false)); R.h.restore();
    R.dome(hood, '#ffffff', 0.08, 0.05, 8, 1); clipA(hood, () => img(zcv)); K(hood, DARK, 2.5);
    for (const z of [zebB, zebL]) { R.dome(z, '#ffffff', 0.08, 0.05, 8, 1); clipA(z, () => img(zcv)); K(z, DARK, 2.5); }

    // ── bottom-right cream with purple-rimmed pebbles ──
    const creamR = P([[560, 640], [680, 640], [736, 660], [736, 1034], [545, 1034], [556, 920], [560, 820], [575, 760]]);
    R.flat(creamR, lin(560, 640, 736, 1024, [[0, '#f2d8a0'], [0.5, '#f4dc98'], [1, '#f0d088']]), 0.06, 1);
    clipA(creamR, () => soft(x => { x.fillStyle = '#d8a870'; x.fill(ellipseP(600, 700, 50, 40, 0)); x.fill(ellipseP(700, 1000, 60, 40, 0)); }, 12, 0.6));
    const pebP = new Path2D();
    for (const [cx, cy, rx, ry] of [[655, 762, 37, 33], [610, 832, 44, 38], [642, 945, 56, 54], [698, 862, 40, 41], [718, 735, 26, 30], [600, 737, 28, 26]]) pebP.addPath(ellipseP(cx, cy, rx, ry, 0));
    R.flat(pebP, '#7a4cc4', 0.08, 1);
    for (const [cx, cy, rx, ry, rot] of [[655, 762, 30, 26, 0.2], [610, 832, 36, 30, -0.2], [642, 945, 48, 46, 0.4]]) R.dome(P(blob(cx, cy, rx, ry, cx, 12, 0.08, rot)), rad(cx - rx * 0.3, cy - ry * 0.4, 2, rx * 1.2, [[0, '#ffffff'], [0.6, '#f0ece8'], [1, '#d4c8c0']]), 0.12, 0.2, rx * 0.6, 5);
    for (const [cx, cy, r] of [[698, 862, 32], [718, 735, 20], [600, 737, 22], [503, 608, 15], [612, 657, 12], [390, 620, 10], [255, 628, 8]]) R.dome(P(blob(cx, cy, r, r * 0.9, cy, 10, 0.15)), '#f0b030', 0.14, 0.18, r * 0.7, 4);
    R.bead(490, 642, 9, '#9aa4c0', 0.14, 0.1, 3);

    // ── bronze face disc ──
    const disc = ellipseP(262, 497, 106, 89, -0.05);
    R.dome(disc, '#7c604c', 0.12, 0.08, 12, 6);
    clipA(disc, () => { const r = rng(11); for (let i = 0; i < 1600; i++) { a.fillStyle = r() < 0.5 ? 'rgba(60,40,30,0.5)' : 'rgba(170,140,120,0.45)'; a.beginPath(); a.arc(150 + r() * 225, 405 + r() * 185, 0.7 + r() * 1.1, 0, 6.283); a.fill(); } });
    K(disc, '#3a2418', 3);
    R.dome(ellipseP(170, 522, 14, 20, 0), '#7c604c', 0.15, 0.04, 6, 6);
    const hair = []; for (let i = 0; i <= 60; i++) { const t = i / 60, x = 160 + t * 194; hair.push([x, 466 - Math.sin(t * Math.PI) * 34 + Math.sin(t * 38) * 6]); }
    R.pipe(P(hair, false), 9, '#f2d830', 0.22, 0.05, 2);
    R.pipe(P(hair.map(([x, y]) => [x + 4, y + 8]), false), 6, '#e8c820', 0.22, 0.04, 2);
    for (const [x, y] of [[258, 468], [310, 470]]) { R.groove(circleP(x, y, 6), 10, '#140c08', 0.2, 0.12, 6, 1); F(circleP(x, y, 8), '#120a06'); }
    const mouth = []; for (let i = 0; i <= 14; i++) mouth.push([208 + i * 9.5, 505 + (i % 2 ? 12 : 0)]);
    for (let i = 14; i >= 0; i--) mouth.push([208 + i * 9.5, 548 - (i % 2 ? 12 : 0)]);
    R.dome(P(mouth, true, false), '#f272b6', 0.2, 0.05, 4, 2);
    K(P(mouth, true, false), '#3a1418', 2);

    // ── bronze blobs ──
    R.dome(P([[165, 585], [190, 568], [215, 575], [225, 600], [215, 625], [195, 640], [175, 632], [162, 610]]), '#6a4c3c', 0.16, 0.16, 16, 3);
    R.pipe(P([[178, 630], [160, 650], [140, 660], [135, 675]], false), 9, '#5a4030', 0.16, 0.08, 3);
    R.dome(P([[318, 700], [338, 688], [350, 700], [355, 730], [380, 750], [372, 770], [335, 765], [314, 740]]), '#6a4c3c', 0.16, 0.16, 16, 3);

    // ── orange waffle lizard ──
    const OR = '#f88a18';
    const head = P([[462, 260], [490, 246], [535, 240], [585, 252], [622, 280], [632, 320], [615, 348], [585, 356], [550, 344], [515, 318], [478, 290]]);
    R.dome(head, OR, 0.2, 0.08, 6, 2);
    for (const [x, y, r] of [[546, 262, 9], [507, 280, 5], [492, 268, 4], [517, 298, 4], [500, 300, 3], [530, 258, 4]]) F(circleP(x, y, r), '#3a1c08');
    R.bead(585, 310, 34, '#6a4a3a', 0.24, 0.06, 3);
    R.bead(585, 310, 25, '#c0c8d4', 0.28, 0.2, 3);
    R.pipe(P([[612, 345], [622, 375], [612, 402], [590, 410], [575, 430], [585, 455], [610, 460], [625, 440], [618, 412], [595, 400], [578, 395]], false), 14, OR, 0.2, 0.08, 2);
    R.pipe(P([[610, 460], [600, 520], [585, 590], [578, 640]], false), 16, OR, 0.2, 0.08, 2);
    const limb = (pts, w = 26) => R.pipe(P(pts, false), w, OR, 0.2, 0.08, 2);
    limb([[460, 670], [432, 655], [440, 632], [462, 640]]); limb([[440, 650], [428, 668]]);
    limb([[445, 725], [410, 728], [385, 740], [395, 760]]); limb([[410, 728], [395, 718]]);
    limb([[560, 670], [588, 680], [600, 710]]); limb([[560, 740], [590, 760], [598, 790]]);
    limb([[505, 765], [495, 820], [478, 860], [462, 890]]);
    limb([[462, 890], [430, 900], [420, 912]], 14); limb([[462, 890], [445, 922]], 14); limb([[462, 890], [472, 915]], 14); limb([[462, 890], [480, 868]], 14);
    const shell = ellipseP(505, 705, 76, 66, -0.1);
    R.dome(shell, OR, 0.2, 0.1, 10, 2);
    clipA(ellipseP(505, 705, 66, 56, -0.1), () => {
      a.fillStyle = '#7a3a08';
      for (let gx = 0; gx < 7; gx++) for (let gy = 0; gy < 6; gy++) { const x = 448 + gx * 19 - gy * 3, y = 654 + gy * 18 + gx * 2; a.fill(rrect(x, y, 12, 11, 3)); }
    });
    for (let gx = 0; gx < 7; gx++) for (let gy = 0; gy < 6; gy++) { const x = 448 + gx * 19 - gy * 3, y = 654 + gy * 18 + gx * 2; if (Math.hypot((x + 6 - 505) / 66, (y + 5 - 705) / 56) < 1) { R.h.fillStyle = 'rgb(40,64,0)'; R.h.fill(rrect(x, y, 12, 11, 3)); } }

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.12, shin: 20, wrap: 0.5, ao: 0.4, rim: 0.2 }),                         // 1 paper / sticker layers
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.3, coat: 0.12, ao: 0.4, rim: 0.3 }),            // 2 orange gloss plastic
        E.mat({ dif: 0.5, metal: 0.6, spec: 1.0, shin: 50, rim: 0.3, ao: 0.3, emis: 0.1 }),          // 3 chrome / bronze
        E.mat({ dif: 0.8, metal: 0.4, spec: 0.8, shin: 30, ao: 0.4, tint: [1.1, 1.0, 0.7], emis: 0.1 }),  // 4 gold / moon
        E.mat({ dif: 1, spec: 1.0, shin: 70, wrap: 0.3, coat: 0.15, ao: 0.3 }),                       // 5 white stones
        E.mat({ dif: 0.9, spec: 0.5, shin: 30, metal: 0.2, grain: 0.15, ao: 0.4 })                     // 6 bronze disc
      ],
      light: [-0.5, 0.6, 0.62], lc: [0.8, 0.78, 0.74], amb: [0.42, 0.42, 0.45],
      envTop: [1.05, 1.02, 1.0], envHor: [0.6, 0.55, 0.55], envBot: [0.2, 0.14, 0.12], envK: [0.25, 0.9, 0.3, 0],
      rimC: [0.4, 0.4, 0.5], rimD: [0.3, 0.6, 0.3], r1: 1.5, r2: 6, k: [0, 0.6, 0.4, 110], shadow: [-5, 6, 0.55, 6]
    });
    E.bloom(0.1, 8);
    E.grain(0.035, 16);
  }
});
