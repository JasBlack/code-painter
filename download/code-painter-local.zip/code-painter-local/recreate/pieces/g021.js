'use strict';
// g021 — "Nimbus robot on green": a low-angle white-and-black clay robot with a black cone hat,
// a ringed telescope arm and cream panel frames, a clay hand and a glitter ball on chroma green.
REC.register('g021', {
  w: 726, h: 1024,
  draw(E) {
    const R = E.relief(), a = R.a, S = E.S;
    const clipA = (path, fn) => { a.save(); a.clip(path); fn(); a.restore(); };
    const img = cv => { a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.drawImage(cv, 0, 0); a.restore(); };
    const soft = (fn, blur, alpha = 1) => {
      const c = E.newCanvas(), x = c.getContext('2d'); x.setTransform(S, 0, 0, S, 0, 0); fn(x);
      a.save(); a.setTransform(1, 0, 0, 1, 0, 0); a.globalAlpha = alpha; a.filter = `blur(${blur * S}px)`; a.drawImage(c, 0, 0); a.restore();
    };
    const lin = (x0, y0, x1, y1, stops) => { const g = a.createLinearGradient(x0, y0, x1, y1); stops.forEach(([t, c]) => g.addColorStop(t, c)); return g; };
    const strokeA = (path, col, wd) => { a.lineWidth = wd; a.strokeStyle = col; a.stroke(path); };
    const WH = '#e4e0dc', BK = '#0b0b0d', CY = '#bdeeea';

    // ── background: grey floor, dark fabric, grey band, chroma green ──
    R.flat(rrect(-10, -10, 746, 1044, 0), lin(0, 500, 0, 1024, [[0, '#b2aeab'], [1, '#aeaaa7']]), 0, 0);
    const fabric = P([[-10, -10], [208, -10], [182, 90], [150, 190], [118, 280], [96, 340], [60, 300], [-10, 292]], true, false);
    const fab = E.fx(`vec3 fx(vec2 uv, vec2 p){
      float w = fbm(p * vec2(0.012, 0.03) + 3.);
      float rip = sin(p.y * 0.55 + w * 9. + p.x * 0.05) * .5 + .5;
      float fold = fbm(p * vec2(0.006, 0.012)) ;
      float v = 0.12 + 0.09 * rip + 0.16 * fold + 0.04 * hash(p);
      return vec3(v * 0.98, v * 0.95, v); }`);
    clipA(fabric, () => img(fab));
    // pale lightning streaks on the fabric
    for (const [x0, y0, x1, y1] of [[150, 70, 210, 45], [60, 140, 140, 110], [0, 170, 50, 150], [20, 300, 90, 270], [70, 290, 130, 275]]) {
      const r = rng(x0 + y0), pts = []; for (let i = 0; i <= 10; i++) { const u = i / 10; pts.push([x0 + (x1 - x0) * u + (r() - 0.5) * 6, y0 + (y1 - y0) * u + (r() - 0.5) * 8]); }
      clipA(fabric, () => { strokeA(P(pts, false, false), 'rgba(200,196,194,0.8)', 3); });
    }
    R.flat(P([[-10, 320], [40, 300], [76, 330], [80, 400], [64, 500], [-10, 520]], true, true), '#060607', 0, 0);
    strokeA(P([[8, 330], [26, 345], [30, 380], [12, 400]], false), '#8a8a8e', 3);
    // grey band between fabric and green
    const band = P([[208, -10], [282, -10], [270, 150], [282, 196], [200, 280], [170, 360], [150, 470], [138, 560], [120, 760], [60, 760], [70, 520], [96, 340], [150, 190]], true, false);
    R.flat(band, lin(200, 0, 120, 600, [[0, '#a7a3a2'], [0.5, '#9d9998'], [1, '#aaa6a3']]), 0, 0);
    a.fillStyle = 'rgba(255,255,255,0.12)'; a.fill(P([[250, -10], [282, -10], [270, 150], [240, 175]], true, false));
    // left grey panel below
    R.flat(P([[-10, 520], [72, 515], [130, 560], [120, 1034], [-10, 1034]], true, false), '#b6b2ae', 0, 0);
    // chroma green
    const green = P([[282, -10], [736, -10], [736, 210], [600, 320], [460, 400], [360, 520], [300, 720], [240, 800], [146, 790], [140, 560], [150, 470], [170, 360], [200, 280], [282, 196], [270, 150]], true, false);
    R.flat(green, '#08f010', 0, 0);
    soft(x => { x.fillStyle = 'rgba(0,90,20,0.35)'; x.fill(ellipseP(640, 120, 120, 90, 0)); }, 30, 1);
    // scan lines on the grey floor
    clipA(P([[120, 780], [400, 780], [400, 1034], [120, 1034]], true, false), () => { const r = rng(5); for (let i = 0; i < 70; i++) { const x = 120 + r() * 280; strokeA(P([[x, 780], [x + 4, 1034]], false), `rgba(${r() < 0.5 ? '255,255,255' : '90,90,90'},0.08)`, 1); } });

    // ── cables over the green ──
    const cable = (pts, wd, col, h = 0.12) => R.pipe(P(pts, false), wd, col, 0.04, h, 1);
    cable([[372, -10], [378, 50], [400, 120], [436, 180], [480, 212], [520, 222]], 5, '#5a6a62');
    cable([[340, 150], [380, 110], [420, 60], [470, 20], [500, -10]], 5, '#6a7470');
    cable([[436, 180], [470, 140], [480, 90], [470, 40], [450, -10]], 4, '#5a6a62');
    cable([[436, 170], [420, 210], [430, 250], [460, 270]], 4, '#5a6a62');
    cable([[640, -10], [672, 40], [690, 100], [685, 170]], 5, '#2a3a30');
    cable([[268, 200], [330, 170], [400, 130], [470, 80], [560, 20], [600, -10]], 7, '#a8acac');
    cable([[0, 655], [100, 648], [200, 630], [300, 590], [370, 560]], 6, '#b8b8b6');
    cable([[150, 485], [230, 478], [310, 455], [370, 425]], 6, '#a8aca8');
    cable([[92, 380], [96, 300], [118, 220], [160, 160], [214, 118], [268, 92]], 5, '#c4c2c0');
    cable([[20, 1034], [36, 960], [70, 900]], 5, '#2a2a2e');
    cable([[140, 760], [146, 830], [150, 940]], 5, '#d8d6d2');
    R.bead(150, 940, 9, WH, 0.15, 0.12, 1);
    R.bead(142, 790, 8, WH, 0.15, 0.12, 1);
    // white worm squiggle
    R.pipe(P([[296, 80], [312, 64], [328, 72], [338, 96], [352, 116], [372, 126]], false), 22, WH, 0.2, 0.25, 1);
    // grey disc + eye at the top
    R.dome(circleP(530, 20, 50), '#aeaaa8', 0.1, 0.1, 10, 1);
    R.dome(circleP(700, 42, 58), '#ece8e2', 0.12, 0.14, 14, 1);
    R.dome(circleP(714, 32, 32), '#08080a', 0.2, 0.06, 6, 2);

    // ── clay hand + glitter ball ──
    const palm = P([[84, 340], [130, 300], [170, 262], [200, 232], [240, 220], [276, 230], [272, 262], [240, 286], [214, 304], [218, 352], [204, 386], [176, 404], [170, 440], [176, 478], [156, 506], [112, 516], [68, 500], [44, 466], [70, 424], [80, 380]]);
    R.dome(palm, '#dcd8d4', 0.12, 0.3, 30, 1);
    for (const [pts, wd] of [
      [[[232, 256], [290, 266], [330, 280], [364, 294]], 34], [[[226, 286], [262, 304], [292, 324]], 32], [[[208, 246], [244, 230], [272, 240]], 30],
      [[[118, 470], [86, 492], [58, 490]], 32], [[[140, 482], [118, 508], [92, 522]], 30], [[[160, 470], [150, 506], [132, 528]], 28], [[[192, 356], [198, 420], [190, 446]], 26]]) R.pipe(P(pts, false), wd, '#dedad6', 0.2, 0.3, 1);
    R.pipe(P([[68, 395], [80, 410]], false), 8, '#d8d4d0', 0.2, 0.1, 1); R.bead(68, 388, 13, '#dedad6', 0.2, 0.25, 1);
    R.pipe(P([[140, 410], [150, 424]], false), 8, '#d8d4d0', 0.2, 0.1, 1); R.bead(140, 405, 12, '#dedad6', 0.2, 0.25, 1);
    R.bead(251, 408, 42, '#7a7672', 0.2, 0.3, 3);
    clipA(circleP(251, 408, 42), () => { const r = rng(9); for (let i = 0; i < 260; i++) { a.fillStyle = r() < 0.5 ? `rgba(255,255,250,${0.4 + r() * 0.6})` : `rgba(40,36,34,${0.5 + r() * 0.4})`; a.fill(circleP(209 + r() * 84, 366 + r() * 84, 0.6 + r() * 2.2)); } });

    // ── robot body: black torso and side slab ──
    const torso = P([[400, 380], [500, 300], [620, 290], [736, 260], [736, 1034], [390, 1034], [380, 700], [370, 560]], true, false);
    R.dome(torso, BK, 0.05, 0.08, 20, 2);
    R.dome(P([[344, 620], [420, 600], [410, 960], [338, 950]], true, false), CY, 0.1, 0.06, 6, 4);
    // right column blobs and a knob
    R.dome(ellipseP(722, 596, 24, 50, 0.2), '#b8b4b0', 0.14, 0.2, 18, 1);
    R.pipe(P([[676, 690], [736, 646]], false), 44, '#b8b4b0', 0.14, 0.2, 1);
    R.pipe(P([[668, 752], [736, 746]], false), 20, '#c0bcb8', 0.2, 0.12, 1);
    R.bead(668, 752, 22, '#d0ccc8', 0.2, 0.25, 1);
    R.bead(708, 398, 18, WH, 0.2, 0.2, 1);
    // ribs
    R.dome(P([[392, 880], [440, 870], [450, 1034], [392, 1034]], true, true), '#b4b0ac', 0.1, 0.1, 14, 1);
    for (const [pts, wd] of [[[[392, 910], [470, 866], [560, 838], [640, 834], [690, 852]], 68], [[[392, 992], [470, 952], [550, 934], [610, 942], [630, 966]], 58],
      [[[400, 1062], [490, 1020], [610, 1008], [700, 1012], [740, 1018]], 60]]) R.pipe(P(pts, false), wd, '#b4b0ac', 0.12, 0.34, 1);
    R.dome(ellipseP(732, 884, 30, 46, 0), '#bcb8b4', 0.12, 0.2, 18, 1);
    // panel frames (cream ring, cyan lip, black screen with a white dot)
    const frame = (pts, dot, dr) => {
      const c = pts.reduce((s, p) => [s[0] + p[0] / 4, s[1] + p[1] / 4], [0, 0]);
      const sc = (k) => pts.map(p => [c[0] + (p[0] - c[0]) * k, c[1] + (p[1] - c[1]) * k]);
      const rr = (q, r) => { const p = new Path2D(); const n = q.length; for (let i = 0; i < n; i++) { const p0 = q[(i + n - 1) % n], p1 = q[i], p2 = q[(i + 1) % n]; const u = (A, B) => { const L = Math.hypot(B[0] - A[0], B[1] - A[1]); return [(B[0] - A[0]) / L, (B[1] - A[1]) / L]; }; const d0 = u(p1, p0), d1 = u(p1, p2); const s = [p1[0] + d0[0] * r, p1[1] + d0[1] * r], e = [p1[0] + d1[0] * r, p1[1] + d1[1] * r]; if (i === 0) p.moveTo(s[0], s[1]); else p.lineTo(s[0], s[1]); p.quadraticCurveTo(p1[0], p1[1], e[0], e[1]); } p.closePath(); return p; };
      const outer = rr(pts, 22), mid = rr(sc(0.84), 16), inner = rr(sc(0.72).map(p => [p[0] + 6, p[1] + 5]), 12);
      R.dome(outer, '#efe8dc', 0.14, 0.12, 8, 4);
      R.dome(mid, CY, 0.12, 0.02, 3, 4);
      R.flat(inner, '#050506', 0.1, 2);
      R.dome(circleP(dot[0], dot[1], dr), '#dcd8d2', 0.11, 0.06, dr * 0.7, 1);
    };
    frame([[440, 470], [672, 384], [662, 548], [446, 664]], [566, 520], 18);
    frame([[424, 690], [608, 614], [600, 780], [404, 892]], [510, 742], 23);

    // ── head: black cone hat, black dome, white visor band ──
    R.dome(P([[548, 150], [596, 22], [640, 150]], true, true), '#0a0a0c', 0.3, 0.2, 18, 2);
    R.dome(P([[480, 250], [500, 190], [560, 150], [630, 140], [690, 165], [736, 200], [736, 260], [480, 280]], true, true), '#0c0c0e', 0.15, 0.2, 30, 2);
    clipA(P([[480, 250], [500, 190], [560, 150], [630, 140], [690, 165], [736, 200], [736, 260], [480, 280]], true, true), () => {
      for (let k = 0; k < 26; k++) strokeA(ellipseP(600, 260, 130 - k * 2.2, 118 - k * 2.2, 0), 'rgba(120,120,130,0.28)', 0.8);
    });
    const visor = P([[486, 250], [500, 214], [560, 200], [660, 194], [736, 188], [736, 246], [640, 262], [560, 282], [500, 300], [482, 286]], true, true);
    R.dome(visor, '#e8e6e2', 0.25, 0.2, 16, 1);
    clipA(visor, () => { a.fillStyle = 'rgba(190,240,236,0.8)'; a.fill(P([[490, 280], [560, 262], [736, 234], [736, 250], [560, 284], [496, 302]], true, false)); });
    strokeA(P([[560, 268], [650, 250], [720, 236]], false), '#222', 2);
    a.save(); a.fillStyle = '#2a2a2a'; a.font = 'bold 11px Arial'; a.translate(612, 246); a.rotate(-0.13); a.fillText('NIMBUS', 0, 0); a.restore();
    // cyan collar + white shoulder
    R.dome(P([[462, 300], [560, 288], [736, 252], [736, 274], [600, 310], [480, 336]], true, true), CY, 0.15, 0.06, 8, 4);
    R.dome(P([[360, 330], [380, 296], [430, 282], [480, 290], [490, 330], [470, 380], [420, 400], [376, 384]], true, true), WH, 0.2, 0.3, 34, 1);
    R.dome(ellipseP(500, 268, 18, 24, 0.3), WH, 0.3, 0.15, 10, 1);
    // eye + camera box
    R.dome(rrect(476, 340, 70, 60, 6), '#e2e0dc', 0.3, 0.1, 8, 1);
    R.dome(circleP(510, 370, 22), '#0c0c10', 0.38, 0.04, 4, 2);
    R.dome(circleP(510, 370, 16), '#1d8fe0', 0.4, 0.06, 6, 5);
    R.dome(circleP(510, 370, 6), '#06263e', 0.42, 0.02, 3, 2);
    R.dome(P([[540, 360], [620, 330], [640, 360], [640, 410], [560, 430], [540, 410]], true, false), '#dedad6', 0.32, 0.12, 8, 1);
    R.dome(rrect(612, 330, 30, 26, 4), '#151517', 0.4, 0.05, 4, 2);
    R.pipe(P([[640, 344], [668, 338]], false), 8, '#d0ccc8', 0.38, 0.06, 1);

    // ── mechanical clutter behind the arm ──
    R.dome(P([[330, 480], [400, 400], [470, 380], [470, 560], [440, 700], [372, 700], [340, 600]], true, true), '#3c4444', 0.08, 0.06, 10, 2);
    R.dome(P([[372, 600], [430, 570], [446, 690], [404, 700], [376, 700]], true, true), '#a8d8d4', 0.12, 0.06, 8, 4);
    for (const [x, y, r] of [[372, 420, 16], [404, 470, 14], [356, 500, 12], [450, 600, 14], [420, 640, 12]]) R.bead(x, y, r, '#d8d6d2', 0.14, 0.12, 1);
    R.pipe(P([[350, 460], [390, 440], [420, 420]], false), 10, '#e0dcd8', 0.14, 0.08, 1);
    // ── the ringed telescope arm (lens segments, black grooved bands) ──
    const A0 = [515, 430], A1 = [192, 714];
    const L = Math.hypot(A1[0] - A0[0], A1[1] - A0[1]), dx = (A1[0] - A0[0]) / L, dy = (A1[1] - A0[1]) / L, nx = dy, ny = -dx;
    const arcP = (t, r, b = 0.3, N = 18) => { const o = []; for (let i = 0; i <= N; i++) { const s2 = -1 + 2 * i / N; o.push([A0[0] + dx * L * t + nx * s2 * r + dx * b * r * (1 - s2 * s2), A0[1] + dy * L * t + ny * s2 * r + dy * b * r * (1 - s2 * s2)]); } return o; };
    const ring = (t0, t1, r0, r1, b0 = 0.3, b1 = 0.3) => P([...arcP(t0, r0, b0), ...arcP(t1, r1, b1).reverse()], true, false);
    // lumpy forearm blob under the arm end
    R.dome(P([[210, 770], [270, 744], [330, 704], [376, 712], [372, 762], [320, 792], [250, 808], [214, 800]], true, true), WH, 0.15, 0.25, 26, 1);
    const lenses = [[-0.04, 0.2, 54, 56], [0.17, 0.46, 64, 68], [0.43, 0.63, 72, 76], [0.6, 1.0, 86, 94]];
    const blacks = [[0.06, 0.17], [0.27, 0.42], [0.5, 0.6], [0.66, 0.71], [0.77, 0.81], [0.88, 0.92]];
    for (const [t0, t1, r0, r1] of lenses) {
      const lp = ring(t0, t1, r0, r1, 0.3, 0.32);
      R.dome(lp, '#e4e0dc', 0.3, 0.32, r0 * 0.9, 1);
      clipA(lp, () => {
        for (const [b0, b1] of blacks) if (b1 > t0 && b0 < t1) {
          const rr0 = r0 + (r1 - r0) * (b0 - t0) / (t1 - t0) + 4, rr1 = r0 + (r1 - r0) * (b1 - t0) / (t1 - t0) + 4;
          a.fillStyle = '#0a0a0c'; a.fill(ring(b0, b1, rr0, rr1));
          for (let j = 1; j < 9; j++) { const tt = b0 + (b1 - b0) * j / 9; strokeA(P(arcP(tt, rr0 + (rr1 - rr0) * j / 9), false, false), 'rgba(140,140,150,0.35)', 0.8); }
        }
      });
    }
    // end cap buckle
    R.dome(rrect(174, 700, 46, 34, 4), '#d8d4d0', 0.62, 0.06, 4, 1);
    strokeA(rrect(180, 706, 34, 22, 3), '#3a3a3c', 2);
    // knob where the arm meets the body
    R.bead(522, 440, 30, '#dedad6', 0.4, 0.25, 1);

    // ── bottom-left blue-eyed device ──
    R.dome(P([[-10, 724], [42, 730], [78, 790], [80, 900], [60, 990], [-10, 1010]], true, true), '#a8acae', 0.1, 0.15, 20, 1);
    R.dome(P([[-10, 990], [60, 984], [80, 1034], [-10, 1034]], true, true), '#8a8c8e', 0.1, 0.1, 10, 1);
    R.dome(rrect(30, 726, 50, 64, 6), '#0a0a0c', 0.18, 0.06, 6, 2);
    R.dome(circleP(28, 850, 54), '#16181c', 0.2, 0.1, 10, 2);
    R.dome(circleP(28, 850, 46), '#cfeaf0', 0.24, 0.06, 8, 4);
    R.dome(circleP(28, 850, 40), '#101418', 0.25, 0.04, 6, 2);
    R.dome(circleP(28, 850, 34), '#1aa6ec', 0.27, 0.06, 10, 5);
    // black pole
    R.pipe(P([[270, 800], [242, 1040]], false), 14, '#0a0a0a', 0.06, 0.08, 2);

    R.shade({
      mats: [
        E.mat({}),
        E.mat({ dif: 1, spec: 0.35, shin: 22, wrap: 0.45, ao: 0.6, coat: 0.05, rim: 0.3 }),          // 1 white clay
        E.mat({ dif: 1, spec: 0.9, shin: 60, wrap: 0.2, ao: 0.3, coat: 0.22 }),                      // 2 black gloss
        E.mat({ dif: 0.6, metal: 0.5, spec: 1.2, shin: 40, grain: 0.35, emis: 0.2 }),               // 3 glitter
        E.mat({ dif: 1, spec: 0.4, shin: 30, wrap: 0.5, ao: 0.4, emis: 0.1 }),                       // 4 cream / cyan plastic
        E.mat({ dif: 1, spec: 1.0, shin: 80, wrap: 0.3, coat: 0.2, emis: 0.25 })                     // 5 blue lens
      ],
      light: [-0.5, 0.62, 0.6], lc: [0.75, 0.75, 0.76], amb: [0.42, 0.43, 0.44],
      envTop: [1, 1, 1], envHor: [0.6, 0.62, 0.62], envBot: [0.1, 0.12, 0.1], envK: [0.3, 0.9, 0.3, 0],
      rimC: [0.3, 0.5, 0.3], rimD: [0, 1, 0], r1: 1.5, r2: 7, k: [0, 0.6, 0.4, 110], shadow: [-6, 7, 0.55, 6]
    });
    E.draw(E.blur(E.snapshot(), 1.6), 0.6);
    E.grain(0.05, 21);
  }
});
