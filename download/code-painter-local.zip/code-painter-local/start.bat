@echo off
rem Code Painter by JAS.BLACK - double-click to start (Windows).
rem Runs a small web server for THIS folder, on this computer only, and opens the studio in your browser.
rem Keep this window open while you use it; close it to stop.
cd /d "%~dp0"
where node >nul 2>&1 && (node serve.mjs & goto end)
where py >nul 2>&1 && (py -3 serve.py & goto end)
where python >nul 2>&1 && (python serve.py & goto end)
echo Code Painter needs Python 3 (or Node.js) to run here.
echo Install Python from https://www.python.org/downloads/ (tick "Add python.exe to PATH"),
echo then double-click start.bat again.
:end
pause
