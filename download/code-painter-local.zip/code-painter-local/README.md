# Code Painter by JAS.BLACK — local version

Version 4.25.3

Drop in any picture and watch it painted in code, stroke by stroke, with the program writing itself underneath.
Add a song and the painting follows its hits and sections; add stroke sounds and every stroke plays a note.
Record it as an MP4 (in real time, or rendered frame by frame), save the code, an SVG, 4K / 8K PNGs, stills and covers.
*window* (top of the out panel) opens the painting in a window of its own: drag it to a projector or a second screen
and double-click it for full screen.

Everything runs in the browser: pictures, songs and videos never leave the computer. No account, no server.
Best in Chrome, Edge or Brave on a desktop or laptop (Safari works too).

This is the whole studio run from your own computer: JAS.BLACK's artworks as examples, 383 hand-coded recreations of
them to *replay*, and the bridge to **Resolume** (or any VJ app): the painting and its code out as live sources, and any
Syphon / Spout source in as a live input.

## What's new in 4.25.3

- **More room for the painting**:
  - **ui** (top right) scales every control, buttons, text and panels together. *auto* makes them smaller on a smaller window (a 1440×810 window shows the painting at about twice the area), or pick 70% – 110%.
  - The panel button next to it (or the **H** key) hides the panels under the painting; press again to bring them back.
  - The music panel's "load or drop a song" line is slimmer.
- **Menus fit their text**: a menu whose label doesn't fit uses less padding and a slightly smaller font. A few long labels are shorter: lines first / lines last, pal+mood, and the layering menus first / same / crop.
- **Phones**: a phone gets the phone layout even when the browser asks for the "desktop site" or an app's own browser lays the page out wider. Its real screen size and touch screen are checked too. The scaling never applies on a phone.

## 4.25.2

- **Flicker in recordings fixed**: with the 3D styles (oil, acrylic, metals…), a busy moment could make strokes still being painted vanish for a single frame and come back. The lit relief draws only so many arriving strokes per frame; when a filled patch started its next row, it pushed one of the others out. Strokes already showing now keep their place.
- **reset** (preset row, press twice): every setting back to its default. Your presets A–D and the easy / console choice are kept.
- **Brush row**: the four keys (rnd, abst, lines, sound) are a 2×2 grid between the size and volume knobs, so the volume knob no longer runs off the panel. It now shows its value.
- **Layering by shape** (speed panel, under the replay menu): one frame for the whole layered show.
  - *frame*: the first piece's shape, or 5:7, 1:1, 4:5, 9:16, 16:9 or 7:5.
  - *same shape* (only the pieces of that shape) or *all shapes*.
  - *crop* (fill the frame) or *fit* (whole piece, black bars).
- **Saving during a replay with live strokes or layers** (PNG, 4K / 8K, stills, contact sheet) now saves the canvas as you see it, strokes and layers included. Before, it re-ran the piece's code alone.

## 4.25.1

- **Settings from a file**: drop a picture, video, SVG or code page saved from 4.25.0 on anywhere on the page, or use **load** in the preset row, and its settings come back. Hold **Alt (Option)** while dropping to paint the file itself instead. A file without settings now says so when you use **load**. (Files saved before 4.25.0 have no settings in them, so they open as a picture or video as before.)
- **Speed panel**: the replay menu and *layer* have their own row, with *+live* and *finish* below, so nothing runs past the panel's edge any more. On the website, where there are no replay pieces, those knobs are hidden.

## 4.25.0

- **Settings travel with what you make**: every PNG, MP4, SVG and ⬇ code page you save carries the settings it was made with (like ComfyUI's workflows). Drop one back onto the page and they come back: styles, motion, path, brush, music mode and amount, the beat extras, the recording size and the rest. The picture and the song are not stored; open them again. A demo song is picked again by itself.
- **10 demo songs** (music panel, *demo ♪*): house, boom bap, drum & bass, techno, trap, lo-fi, dubstep, synthwave, breakbeat and ambient, 18–28 s each. Each has a quiet part, a build and a drop, for trying out the music reactivity.
- **Glow is back** (music panel, next to splash and branch): on the beat, the tip of each brush being drawn lights up in its own shape and colour, then fades within half a second as the brush moves on. It is brighter in the brush's own colour, never a white blob, and only on the few biggest brushes in flight.
- **Oil, reworked**: wet paint with a soft domed body, the two colours blending into each other across the brush, and fine bristle marks a few pixels apart that wander along the stroke. Paint piles where the brush lifts, and it shines with a broad wet sheen. Before, it looked like stiff striped planks, with a glint on every ridge.
- **Fill**: *one stroke* is now the default (zigzag and cross are still in the menu).
- **No more camera punch-in on drops** (or push-in on builds). The optional *fx* beat punch is unchanged.

## 4.24.1

- **Lines are drawn, never flashed in**:
  - *sketch* on a line now traces it with a pencil first, then paints along it. Before, the colour flooded out from the middle in a circle, so lines seemed to just appear.
  - A wide stroke filled with zigzag or cross rows now gives each row time to be drawn. Before, all the rows were squeezed into one stroke's time (about 60 ms a row), so they flashed in.
- **Music in the paint: a hit, then stillness**:
  - On the 3D styles, each beat snaps the light to one side and drops it low, then it eases back within a third of a second and holds still until the next beat. Before, it swung like a pendulum and never settled, so the beat didn't read.
  - Each beat's stroke is now at least a real gesture, about a seventh of the canvas, however far the painting has got.
- **Hits mode no longer starts on an empty canvas**: before the song's first hit, the first washes go on gently.

## 4.24.0

- **Music in the paint** (music panel, *amount* knob): the song now changes the painting itself, not only its pace. The old *glow*, *pulse* and *colour* keys are gone.
  - **A big stroke on every beat**: on each beat the painter makes one bold stroke, two to four times the size it is painting at, and snaps it down on the beat. It is still a stroke that brings the picture closer. With *one line*, the line swells on the beat instead.
  - **Loud = broad brushes, quiet = fine ones**: the brush size follows the song's loudness as it plays. Loud and quiet are measured against the song itself, so any track gets the full range. The painter is kept only a short way ahead of the stage, so what it paints next is chosen at this loudness. It still prepares in the quiet parts for a busy drop coming up, using the song's hits, which are known in advance.
  - **The light swings on the beat** (3D styles: oil, acrylic, knife, metals, glass…): every beat swings the light round, one way then the other, and the bass drops it lower and more raking, so the whole surface catches it.
  - At 0 the music only sets the pace, as before. *splash* and *branch* are still there as extras.

## Earlier: 4.23.6

- **One line with a song stops when the song stops**: the painting ends with the music — the strokes still being drawn finish, the ones not yet started are left out (no brush painting on in silence, and nothing dropped in at once). The one line's stroke search is a little lighter, so live it keeps up better; a ⏺ render always completes the whole picture before the song ends.
- **One line + music no longer jumps to the end**: the pen now aims to finish a little before the song does, the render asks the painter for as many strokes as the pen will draw, a catch-up is spread over a few frames (never a jump), and if any strokes are left when the song ends they are drawn out quickly instead of appearing all at once.
- **One line + music now follows the song**: with a song playing (hits or flow), the pen's pace comes from the music — faster when it's loud, a surge on every beat (about twice as many strokes on the beats as between them), and it keeps up with where the song says the painting should be (it hurries when behind and holds back when ahead), finishing with the song. Before, the pen kept its own slow pace and fell far behind. A wide stroke with zigzag fill no longer slows the one line down.
- **Fill (zigzag / cross) works with paint and soft**: the plain *paint* style now fills wide strokes with overlapping brush rows, and *soft* (airbrush) zigzags like a spray can; before, the fill menu didn't change them. Changing the fill menu now says which of the ticked styles it changes (flat, geo and the 3D materials are drawn as one shape and don't use it).
- **On the beat** (music panel; tick any mix): *glow* — a spark rides the tip of each stroke landing on the beat and a thin rim of light runs along its edges (following the passes actually painted, never wider than the stroke) · *splash* — the brushes being drawn flick drops of their paint off the tip, and they stay in the painting · *pulse* — strokes on the beat are thicker, the harder the beat the bolder · *colour* — strokes on the beat are brighter and more saturated · *branch* — with one line, the line splits on the beat.
- **Pre-drawn cuts in live recordings**: while the next scene is being pre-drawn, the live recording holds (no pictures, no sound, and the song waits), so the video cuts straight from the old scene to the new one, already painted, with no pause. A ⏺ render never had the pause.
- A video whose first frame is one flat colour (a fade in from black) now starts at once, instead of the painter searching for something to paint.
- The GitHub examples now show foam and hylics (instead of oil and glass).
- **Replay: layer ⤮** (next to the replay menu): the premade pieces in a random order, each replayed on top of the last instead of on a fresh canvas. A piece's background is left out and its big washes go on as thin glazes, so the pieces below keep showing; the live strokes (+live, turned up to 35% if it is off) follow the new piece's marks. Press again for a new order; pick anything else to stop.
- **Easy mode**: *pencil sketch* is the first look, and *graffiti* replaces oil painting. A new **path** choice (free · one line · spiral out · top → bottom); each press of *▶ try a demo* shows the next path.
- **Phone**: the looks and the path are on the phone too, above the styles.
- **The guide**: docs/GUIDE.md on GitHub covers every feature and how to use it, with example pictures; the README has a gallery and a quick start.
- **riso** no longer sinks to black in a dense picture (only the second ink overprints), and **stained glass** pieces laid over each other keep their colour instead of darkening.

## Start

- **Mac**: double-click `start.command`. The first time, macOS may say it's from an unidentified developer:
  right-click `start.command` → **Open** → **Open**.
- **Windows**: double-click `start.bat`.

Your browser opens the studio. Keep the small window that opened with it while you use it; close it to stop.
It needs **Python 3** (or Node.js): on a Mac, macOS offers to install it the first time; on Windows get it from
https://www.python.org/downloads/ (tick "Add python.exe to PATH").

## Resolume (out and in)

Syphon on a Mac, Spout on Windows.

1. Double-click `send/send-to-resolume.command` (Mac; right-click → Open the first time) or
   `send/send-to-resolume.bat` (Windows). The first time it sets itself up (about a minute; it needs Python 3.9 – 3.12
   on a Mac, 3.9+ on Windows). Keep its window open.
2. **Out**: press *send* (top of the out panel): it blinks until it finds the bridge, then lights green. In Resolume:
   Sources → Syphon / Spout → *Code Painter*. With *code* on, the code goes out too as *Code Painter code* (text on
   black: layer it with Add or Screen).
3. **In**: switch on Resolume's Syphon / Spout output, then pick *live input → Syphon / Spout* in the studio.

**If Resolume shows *Code Painter* black (Windows):** Spout only works between apps on the same graphics chip, and most
laptops have two. When the bridge finds two it asks to run on the fast one, like Resolume: answer **Y**. (Or set it
yourself: Windows Settings → System → Display → Graphics → Python → High performance, then start the bridge again.)
The bridge window shows how it's going every 10 s (*out: … fps*).

**If it's slow or jerky:** keep at least a corner of the studio's browser window visible (or put it on another
screen). A window that's completely covered, by Resolume full screen say, gets slowed right down by the computer and
sends only a few frames. On a laptop, plug it in.

## What's in here

- `start.command` / `start.bat`: start it (`serve.py` / `serve.mjs`: the tiny local web server they run)
- `studio/`: the app (its code, the painter and the recorder; `viewer3d.js` + `vendor/three/`: the 3D input, three.js,
  MIT licence)
- `recreate/`: the drawing engine and the 383 hand-coded pieces used by *replay*
- `style-reel/`: the original artworks (examples + replay comparisons)
- `confucius-swirl/js/core.js`: shared maths / drawing helpers used by the engine
- `send/`: the bridge to Resolume / VJ apps (Syphon on a Mac, Spout on Windows; out and in)

The artworks and the recreations © 2026 JAS.BLACK. All rights reserved.
