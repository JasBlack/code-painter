# Code Painter by JAS.BLACK — local version

Version 4.29.0

Drop in any picture and watch it painted in code, stroke by stroke, with the program writing itself underneath.
Add a song and the painting follows its hits and sections; add stroke sounds and every stroke plays a note.
Record it as an MP4 (in real time, or rendered frame by frame), save the code, an SVG, 4K / 8K PNGs, stills and covers.
*window* (top of the out panel) opens the painting in a window of its own: drag it to a projector or a second screen
and double-click it for full screen.

Everything runs in the browser: pictures, songs and videos never leave the computer. No account, no server.
Best in Chrome, Edge or Brave on a desktop or laptop (Safari works too).

This is the whole studio run from your own computer: JAS.BLACK's artworks as examples, 383 hand-coded recreations of
them to *replay*, and the bridge to **Resolume** (or any VJ app): the painting and its code out as live sources, and any
Syphon / Spout source in as a live input.

## What's new in 4.29.0

- **Score, rebuilt like the producers' videos**:
  - **How it moves:** the spine is "now". The song's notes drift in from the right as small dots, fire as they reach it (rings flare on the lows, stems drop on the mids, sprigs and strands fly off on the highs), then scroll away to the left, glowing and smearing.
  - **Notes:** every onset counts, not just the big hits.
  - **Spine:** swells with the sound.
  - **Colours:** change with the song's sections.
- **Four looks**:
  - *clean*: like the videos.
  - *brush*: loose gestures, loops and dabs in your styles and brush, no clean shapes.
  - *organic*: liquid blobs that run together, drips, splats and a molten spine, with grain.
  - *motion only*: no score drawn.
  The over-the-painting look is gone. The score modes take the layout's frame (9:16 etc.).
- **Text bar, reel style**:
  - **Timing:** one line at a time. Each line in the box gets an equal share of the video (3 lines over 9 s: one every 3 s), and the last one stays to the end.
  - **Display:** the whole line comes up at once, with a quick pop. No more painted text.
  - **Styles:** classic, box, colour box, outline, neon, typewriter, shadow.
- **Score shape** (the *shape* button beside the score menu):
  - **path:** a line, a ring in the middle, or a loop round the whole frame.
  - **flows:** ← → ↑ ↓.
  - **sliders:** line position, width, wave, beads, plus spread, size, speed, glow and tilt.

## Start

- **Mac**: double-click `start.command`. The first time, macOS may say it's from an unidentified developer:
  right-click `start.command` → **Open** → **Open**.
- **Windows**: double-click `start.bat`.

Your browser opens the studio. Keep the small window that opened with it while you use it; close it to stop.
It needs **Python 3** (or Node.js): on a Mac, macOS offers to install it the first time; on Windows get it from
https://www.python.org/downloads/ (tick "Add python.exe to PATH").

## Resolume (out and in)

Syphon on a Mac, Spout on Windows.

1. Double-click `send/send-to-resolume.command` (Mac; right-click → Open the first time) or
   `send/send-to-resolume.bat` (Windows). The first time it sets itself up (about a minute; it needs Python 3.9 – 3.12
   on a Mac, 3.9+ on Windows). Keep its window open.
2. **Out**: press *send* (top of the out panel): it blinks until it finds the bridge, then lights green. In Resolume:
   Sources → Syphon / Spout → *Code Painter*. With *code* on, the code goes out too as *Code Painter code* (text on
   black: layer it with Add or Screen).
3. **In**: switch on Resolume's Syphon / Spout output, then pick *live input → Syphon / Spout* in the studio.

**If Resolume shows *Code Painter* black (Windows):** Spout only works between apps on the same graphics chip, and most
laptops have two. When the bridge finds two it asks to run on the fast one, like Resolume: answer **Y**. (Or set it
yourself: Windows Settings → System → Display → Graphics → Python → High performance, then start the bridge again.)
The bridge window shows how it's going every 10 s (*out: … fps*).

**If it's slow or jerky:** keep at least a corner of the studio's browser window visible (or put it on another
screen). A window that's completely covered, by Resolume full screen say, gets slowed right down by the computer and
sends only a few frames. On a laptop, plug it in.

## What's in here

- `start.command` / `start.bat`: start it (`serve.py` / `serve.mjs`: the tiny local web server they run)
- `studio/`: the app (its code, the painter and the recorder; `viewer3d.js` + `vendor/three/`: the 3D input, three.js,
  MIT licence)
- `recreate/`: the drawing engine and the 383 hand-coded pieces used by *replay*
- `style-reel/`: the original artworks (examples + replay comparisons)
- `confucius-swirl/js/core.js`: shared maths / drawing helpers used by the engine
- `send/`: the bridge to Resolume / VJ apps (Syphon on a Mac, Spout on Windows; out and in)

The artworks and the recreations © JAS.BLACK. All rights reserved.
