# Code Painter by JAS.BLACK — local version

Version 4.34.0

Drop in any picture and watch it painted in code, stroke by stroke, with the program writing itself underneath.
Add a song and the painting follows its hits and sections; add stroke sounds and every stroke plays a note.
Record it as an MP4 (in real time, or rendered frame by frame), save the code, an SVG, 4K / 8K PNGs, stills and covers.
*window* (top of the out panel) opens the painting in a window of its own: drag it to a projector or a second screen
and double-click it for full screen.

Everything runs in the browser: pictures, songs and videos never leave the computer. No account, no server.
Best in Chrome, Edge or Brave on a desktop or laptop (Safari works too).

This is the whole studio run from your own computer: JAS.BLACK's artworks as examples, 383 hand-coded recreations of
them to *replay*, and the bridge to **Resolume** (or any VJ app): the painting and its code out as live sources, and any
Syphon / Spout source in as a live input.

## What's new in 4.34.0

- **Right-click any slider** to put it back to its default.
- **Signal on / off:** a switch at the top of the signal panel. Off keeps every setting for later.
- **Score · vector:**
  - **Vector detail:** a slider for how many shapes make up the picture. Tiny specks now join their neighbours, so no parts are left empty.
  - **Fill:** flat, painted (each shape filled with brushwork in your ticked styles) or mixed (flat with brush accents).
  - **Build:** the shapes now come in steadily on the notes and are all in by about a third of the song.
  - **On the beat:** every note kicks a group of shapes (swell, flash, the small ones jump), and the whole picture breathes with the beat.

## Start

- **Mac**: double-click `start.command`. The first time, macOS may say it's from an unidentified developer:
  right-click `start.command` → **Open** → **Open**.
- **Windows**: double-click `start.bat`.

Your browser opens the studio. Keep the small window that opened with it while you use it; close it to stop.
It needs **Python 3** (or Node.js): on a Mac, macOS offers to install it the first time; on Windows get it from
https://www.python.org/downloads/ (tick "Add python.exe to PATH").

## Resolume (out and in)

Syphon on a Mac, Spout on Windows.

1. Double-click `send/send-to-resolume.command` (Mac; right-click → Open the first time) or
   `send/send-to-resolume.bat` (Windows). The first time it sets itself up (about a minute; it needs Python 3.9 – 3.12
   on a Mac, 3.9+ on Windows). Keep its window open.
2. **Out**: press *send* (top of the out panel): it blinks until it finds the bridge, then lights green. In Resolume:
   Sources → Syphon / Spout → *Code Painter*. With *code* on, the code goes out too as *Code Painter code* (text on
   black: layer it with Add or Screen).
3. **In**: switch on Resolume's Syphon / Spout output, then pick *live input → Syphon / Spout* in the studio.

**If Resolume shows *Code Painter* black (Windows):** Spout only works between apps on the same graphics chip, and most
laptops have two. When the bridge finds two it asks to run on the fast one, like Resolume: answer **Y**. (Or set it
yourself: Windows Settings → System → Display → Graphics → Python → High performance, then start the bridge again.)
The bridge window shows how it's going every 10 s (*out: … fps*).

**If it's slow or jerky:** keep at least a corner of the studio's browser window visible (or put it on another
screen). A window that's completely covered, by Resolume full screen say, gets slowed right down by the computer and
sends only a few frames. On a laptop, plug it in.

## What's in here

- `start.command` / `start.bat`: start it (`serve.py` / `serve.mjs`: the tiny local web server they run)
- `studio/`: the app (its code, the painter and the recorder; `viewer3d.js` + `vendor/three/`: the 3D input, three.js,
  MIT licence)
- `recreate/`: the drawing engine and the 383 hand-coded pieces used by *replay*
- `style-reel/`: the original artworks (examples + replay comparisons)
- `confucius-swirl/js/core.js`: shared maths / drawing helpers used by the engine
- `send/`: the bridge to Resolume / VJ apps (Syphon on a Mac, Spout on Windows; out and in)

The artworks and the recreations © JAS.BLACK. All rights reserved.
