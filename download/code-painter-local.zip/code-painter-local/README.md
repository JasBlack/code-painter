# Code Painter by JAS.BLACK — local version

Version 4.23.4

Drop in any picture and watch it painted in code, stroke by stroke, with the program writing itself underneath.
Add a song and the painting follows its hits and sections; add stroke sounds and every stroke plays a note.
Record it as an MP4 (in real time, or rendered frame by frame), save the code, an SVG, 4K / 8K PNGs, stills and covers.
*window* (top of the out panel) opens the painting in a window of its own: drag it to a projector or a second screen
and double-click it for full screen.

Everything runs in the browser: pictures, songs and videos never leave the computer. No account, no server.
Best in Chrome, Edge or Brave on a desktop or laptop (Safari works too).

This is the whole studio run from your own computer: JAS.BLACK's artworks as examples, 383 hand-coded recreations of
them to *replay*, and the bridge to **Resolume** (or any VJ app): the painting and its code out as live sources, and any
Syphon / Spout source in as a live input.

## What's new in 4.23.4

- **One line + music now follows the song**: with a song playing (hits or flow), the pen's pace comes from the music — faster when it's loud, a surge on every beat (about twice as many strokes on the beats as between them), and it keeps up with where the song says the painting should be (it hurries when behind and holds back when ahead), finishing with the song. Before, the pen kept its own slow pace and fell far behind. A wide stroke with zigzag fill no longer slows the one line down.
- **Fill (zigzag / cross) works with paint and soft**: the plain *paint* style now fills wide strokes with overlapping brush rows, and *soft* (airbrush) zigzags like a spray can; before, the fill menu didn't change them. Changing the fill menu now says which of the ticked styles it changes (flat, geo and the 3D materials are drawn as one shape and don't use it).
- **On the beat** (music panel; tick any mix): *glow* — a spark rides the tip of each stroke landing on the beat and a thin rim of light runs along its edges (following the passes actually painted, never wider than the stroke) · *splash* — the brushes being drawn flick drops of their paint off the tip, and they stay in the painting · *pulse* — strokes on the beat are thicker, the harder the beat the bolder · *colour* — strokes on the beat are brighter and more saturated · *branch* — with one line, the line splits on the beat.
- **Pre-drawn cuts in live recordings**: while the next scene is being pre-drawn, the live recording holds (no pictures, no sound, and the song waits), so the video cuts straight from the old scene to the new one, already painted, with no pause. A ⏺ render never had the pause.
- A video whose first frame is one flat colour (a fade in from black) now starts at once, instead of the painter searching for something to paint.
- The GitHub examples now show foam and hylics (instead of oil and glass).
- **Replay: layer ⤮** (next to the replay menu): the premade pieces in a random order, each replayed on top of the last instead of on a fresh canvas. A piece's background is left out and its big washes go on as thin glazes, so the pieces below keep showing; the live strokes (+live, turned up to 35% if it is off) follow the new piece's marks. Press again for a new order; pick anything else to stop.
- **Easy mode**: *pencil sketch* is the first look, and *graffiti* replaces oil painting. A new **path** choice (free · one line · spiral out · top → bottom); each press of *▶ try a demo* shows the next path.
- **Phone**: the looks and the path are on the phone too, above the styles.
- **The guide**: docs/GUIDE.md on GitHub covers every feature and how to use it, with example pictures; the README has a gallery and a quick start.
- **riso** no longer sinks to black in a dense picture (only the second ink overprints), and **stained glass** pieces laid over each other keep their colour instead of darkening.

## Start

- **Mac**: double-click `start.command`. The first time, macOS may say it's from an unidentified developer:
  right-click `start.command` → **Open** → **Open**.
- **Windows**: double-click `start.bat`.

Your browser opens the studio. Keep the small window that opened with it while you use it; close it to stop.
It needs **Python 3** (or Node.js): on a Mac, macOS offers to install it the first time; on Windows get it from
https://www.python.org/downloads/ (tick "Add python.exe to PATH").

## Resolume (out and in)

Syphon on a Mac, Spout on Windows.

1. Double-click `send/send-to-resolume.command` (Mac; right-click → Open the first time) or
   `send/send-to-resolume.bat` (Windows). The first time it sets itself up (about a minute; it needs Python 3.9 – 3.12
   on a Mac, 3.9+ on Windows). Keep its window open.
2. **Out**: press *send* (top of the out panel): it blinks until it finds the bridge, then lights green. In Resolume:
   Sources → Syphon / Spout → *Code Painter*. With *code* on, the code goes out too as *Code Painter code* (text on
   black: layer it with Add or Screen).
3. **In**: switch on Resolume's Syphon / Spout output, then pick *live input → Syphon / Spout* in the studio.

**If Resolume shows *Code Painter* black (Windows):** Spout only works between apps on the same graphics chip, and most
laptops have two. When the bridge finds two it asks to run on the fast one, like Resolume: answer **Y**. (Or set it
yourself: Windows Settings → System → Display → Graphics → Python → High performance, then start the bridge again.)
The bridge window shows how it's going every 10 s (*out: … fps*).

**If it's slow or jerky:** keep at least a corner of the studio's browser window visible (or put it on another
screen). A window that's completely covered, by Resolume full screen say, gets slowed right down by the computer and
sends only a few frames. On a laptop, plug it in.

## What's in here

- `start.command` / `start.bat`: start it (`serve.py` / `serve.mjs`: the tiny local web server they run)
- `studio/`: the app (its code, the painter and the recorder; `viewer3d.js` + `vendor/three/`: the 3D input, three.js,
  MIT licence)
- `recreate/`: the drawing engine and the 383 hand-coded pieces used by *replay*
- `style-reel/`: the original artworks (examples + replay comparisons)
- `confucius-swirl/js/core.js`: shared maths / drawing helpers used by the engine
- `send/`: the bridge to Resolume / VJ apps (Syphon on a Mac, Spout on Windows; out and in)

The artworks and the recreations © 2026 JAS.BLACK. All rights reserved.
