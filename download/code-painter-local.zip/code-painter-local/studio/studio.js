'use strict';
// ─────────────────────────────────────────────────────────────
//  Code Painter by JAS.BLACK — studio. Version 4.26.3 (see CHANGELOG.md in the release zip).
//  Auto-paint: any image -> painter-worker.js rebuilds it shape by shape;
//              every shape is a line of code (E/B/T/R/S calls on a tiny runtime).
//  Replay:     a hand-coded piece (recreate/pieces/sNN.js) re-run op by op in
//              replay.html, highlighting the source line that drew each op.
//  Music:      load a track, pick a part of it on the timeline, and the song
//              paints the picture: every detected hit drops its share of strokes
//              (louder hits drop more), or the strokes follow the
//              energy curve. Beat FX (punch zoom, flashing border) are optional.
//  The whole stage is one canvas, so ⏺ record captures exactly what you see
//  (plus the music) — in real time, or offline frame by frame (perfectly smooth).
// ─────────────────────────────────────────────────────────────
(() => {
const $ = id => document.getElementById(id);
const stage = $('stage'), STAGE_X = stage.getContext('2d');
let X = STAGE_X;      // (pointed at the send canvas while the painting is drawn there: see SEND)
const MONO = '"Cascadia Mono", Consolas, "SF Mono", Menlo, monospace';
// the stage colours (neon mono: green + purple on near-black; the toolbar uses the same colours via CSS)
const APP_VERSION = '4.26.3', FOOTER = `Code Painter by Jas Black - 2026`;
const THEMES = {
  neon: { bg: '#0b0b0c', panel: '#141517', panel2: '#0f1011', line: '#26272a', fg: '#ececf0', dim: '#6f6f7a', accent: '#39ff88', accent2: '#b36bff',
    fn: '#39ff88', num: '#b36bff', str: '#d8d8de', kw: '#b36bff', com: '#4d4d57', punct: '#8c8c96', ident: '#ececf0',
    hi: 'rgba(57,255,136,.11)', hi2: 'rgba(179,107,255,.14)', glow: false, grid: '' }
};
// stage layouts: 16:9 side by side, or 9:16 for reels / shorts / tiktok (painting top, original middle, code bottom)
const LAYOUTS = {
  landscape: { W: 1920, H: 1080, paint: { x: 980, y: 86, w: 900, h: 600 }, orig: { x: 40, y: 86, w: 900, h: 600 }, code: { x: 40, y: 704, w: 1840, h: 336 },
    title: { x: 40, y: 50, size: 30 }, sub: { y: 49, size: 18, maxW: 620, inline: true }, stats: { right: 1880, y: 44, size: 26 }, font: 19, lh: 25, rule: 0 },
  vertical: { W: 1080, H: 1920, paint: { x: 40, y: 158, w: 1000, h: 752 }, orig: { x: 40, y: 926, w: 1000, h: 500 }, code: { x: 40, y: 1442, w: 1000, h: 438 },
    title: { x: 40, y: 64, size: 44 }, sub: { x: 40, y: 116, size: 21, maxW: 440 }, stats: { right: 1040, y: 108, size: 26 }, font: 20, lh: 26, rule: 142 },
  // feed posts (no app buttons over them, so the whole frame is free)
  portrait: { W: 1080, H: 1350, feed: true, paint: { x: 40, y: 96, w: 1000, h: 736 }, orig: { x: 40, y: 848, w: 360, h: 462 }, code: { x: 416, y: 848, w: 624, h: 462 },
    stats: { right: 1040, y: 58, size: 24 }, font: 17, lh: 22, rule: 0 },
  square: { W: 1080, H: 1080, feed: true, paint: { x: 40, y: 96, w: 1000, h: 596 }, orig: { x: 40, y: 708, w: 330, h: 332 }, code: { x: 386, y: 708, w: 654, h: 332 },
    stats: { right: 1040, y: 58, size: 24 }, font: 16, lh: 21, rule: 0 }
};
// DISPLAY: studio (titles, stats, panes) · simple (reels: painting, original, code; no text) · painting (the painting only)
let COL = THEMES.neon, LY = LAYOUTS.landscape, SW = 1920, SH = 1080, gridCv = null, DISPLAY = 'studio';
const store = (k, v) => { try { if (v === undefined) return localStorage.getItem(k); localStorage.setItem(k, v); } catch (e) { return null; } };
// a first visit: nothing of ours stored yet (looked at before anything is, so the easy controls can greet a newcomer)
const FIRST_VISIT = (() => { try { return !Object.keys(localStorage).some(k => k.startsWith('cp-') && k !== 'cp-ui'); } catch (e) { return true; } })();
// the clock: real time, or during an offline render the video's own time (it moves on one frame at a time)
const OFF = { on: false, t: 0, t0: 0, frame: 0, fps: 30, aT: 0, aPlaying: false, aStarted: false, aStart: 0, aEnd: -1, timers: [], parked: 0, endAt: Infinity, vCur: null, vStart: 0, vOnce: false, pcm: null };
const clock = () => OFF.on ? OFF.t : performance.now();
// the reel: a set length (0 = free), and whether a finished painting loops back to empty
const reelLen = () => +$('reellen').value;
const loopOn = () => $('loop').value !== 'off';
const holdOpen = () => reelLen() > 0 || loopOn();     // (the run's clock keeps going after the painting is done)

function setLayout(name, keep = true) {
  if (!LAYOUTS[name]) name = 'landscape';
  LY = LAYOUTS[name];
  document.body.dataset.layout = name; $('layout').value = name; if (keep) store('cp-layout', name);
  applyStageSize(true);
}
function setDisplay(name, keep = true) {
  DISPLAY = ['simple', 'duo', 'painting', 'editor'].includes(name) ? name : 'studio';
  document.body.dataset.display = DISPLAY; if (keep) store('cp-display', DISPLAY);
  for (const b of document.querySelectorAll('#view [data-display]')) b.classList.toggle('on', b.dataset.display === DISPLAY);
  // the painting view takes the picture's own shape, so the frame choice (and the IG guides) don't apply there
  $('layout').disabled = $('igguides').disabled = DISPLAY === 'painting';
  applyStageSize(true);
}
// the stage canvas: the chosen frame, or in the painting view the picture's own shape at about
// 1920×1080's pixel count (even sizes, which video encoders need)
function stageSize() {
  if (DISPLAY !== 'painting') return [LY.W, LY.H];
  const src = S.out || S.orig, ar = src ? srcW(src) / srcH(src) : 1, A = 1920 * 1080;
  return [2 * Math.round(Math.sqrt(A * ar) / 2), 2 * Math.round(Math.sqrt(A / ar) / 2)];
}
// RS: the stage's pixels per layout pixel — 1 normally; a render at another size draws the same layout scaled
let RS = 1;
function applyStageSize(force) {
  const [w, h] = stageSize(), pw = Math.round(w * RS / 2) * 2, ph = Math.round(h * RS / 2) * 2;
  if (!force && stage.width === pw && stage.height === ph && SW === w && SH === h) return;
  SW = w; SH = h; if (stage.width !== pw || stage.height !== ph) { stage.width = pw; stage.height = ph; }
  gridCv = null; fitStage(); updateGuides();
}
// scale the stage to fit the window in either orientation (the canvas itself stays at full resolution)
function fitStage() {
  const m = stage.closest('main'), cs = getComputedStyle(m);
  const w = m.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight), h = m.clientHeight - parseFloat(cs.paddingTop) - parseFloat(cs.paddingBottom);
  const k = Math.max(0.05, Math.min(w / SW, h / SH));
  stage.style.width = Math.floor(SW * k) + 'px'; stage.style.height = Math.floor(SH * k) + 'px';
}
addEventListener('resize', fitStage);
new ResizeObserver(fitStage).observe(stage.closest('main'));
const PIECES = [['s01', 'Mercury bloom'], ['s02', 'Resin island'], ['s03', 'Resin night tile'], ['s04', 'Neon resin tile'], ['s05', 'Rubber totem cave'],
  ['s06', 'Chocolate grin'], ['s07', 'Alabaster idol'], ['s08', 'Maze-tattooed mask'], ['s09', 'Sticker medallion'], ['s10', 'Jelly pile'],
  ['s11', 'Violet clay'], ['s12', 'Melting crooner'], ['s13', 'Bubblegum op-art slope'], ['s14', 'Glass ring marble swirl'], ['s15', 'Pewter face medallion'],
  ['s16', 'Neon jelly deep field'], ['s17', 'Clay console'], ['s18', 'Molten gold grin'], ['s19', 'Cosmic octopus sheet'], ['s20', 'Debris room'],
  ['s21', 'Starry urchin'], ['s22', 'Pewter ape in orbit'], ['s23', 'Resin skull disc'], ['s24', 'Chrome zebra sheet'], ['s25', 'Holo-shard obsidian'],
  ['s26', 'Iridescent wreck on mint'], ['s27', 'Foil bouquet'], ['s28', 'Op-art paper planes'], ['s29', 'Medallion on blue relief'], ['s30', 'Gilded resin cells'],
  ['s31', 'Op-art transmission'], ['s32', 'Retro game den'], ['s33', 'Blue-pipe maw'], ['s34', 'Coral saint'], ['s35', 'Bubblegum wax'],
  ['s36', 'Neon silhouette sticker'], ['s37', 'Zebra dream collage'], ['s38', 'Gilded desert machine'], ['s39', 'Glowing idol tray'], ['s40', 'Gold relics in the milk'],
  ['s41', 'Jar in the void'], ['s42', 'Pearl tide'], ['s43', 'Zebra comet cosmos'], ['s44', 'Pipe buddy'], ['s45', 'Pearl & mercury relief'],
  ['s46', 'Hypno machine'], ['s47', 'Yellow-face totem'], ['s48', 'Grey heart machine'], ['s49', 'Hypno lounge'], ['s50', 'Brain clay close-up'],
  ['s51', 'Clay collage head'], ['s52', 'Leather sun head'], ['s53', 'Milk wax blister'], ['s54', 'Mushroom keeper'], ['s55', 'Night jungle otters'],
  ['s56', 'Badge sheet'], ['g001', 'Crayon starburst salamander'], ['g002', 'Clay nose in zebra cream'], ['g003', 'Goggle twins under zebra'], ['g004', 'Mercury hair'],
  ['g005', 'Plasticine fang mask'], ['g006', 'Enamel gadget board'], ['g007', 'Zebra chopper postcard'], ['g008', 'Grinning chrome maw'], ['g009', 'Zebra hose under neon'],
  ['g010', 'Leather sage in chrome'], ['g011', 'Chrome drip on zebra'], ['g012', 'Portal pit boss'], ['g013', 'Zebra spill machine'], ['g014', 'Gearhead in candy rock'],
  ['g015', 'Cat tile in resin'], ['g016', 'Desert night lizard'], ['g017', 'Plumber\'s figure eight'], ['g018', 'Granite helmet sitter'], ['g019', 'Crosshatch visor girl'],
  ['g020', 'Zebra-masked moustache man'], ['g021', 'Nimbus robot on green'], ['g022', 'Cassette badge collage'], ['g023', 'Porcelain squid vitrine'], ['g024', 'Chrome bear\'s night arch'],
  ['g025', 'Robot at the cassette deck'], ['g026', 'Goggled girl, zebra cosmos'], ['g027', 'Starfield hose relay'], ['g028', 'Glossy pill cosmos'], ['g029', 'Zebra beasts, green moonfield'],
  ['g030', 'Pearl spiral reactor'], ['g031', 'Spiral clay reef'], ['g032', 'Porcelain portal dreamer'], ['g033', 'Lilac serpent vase'], ['g034', 'Specimen in the bell jar'],
  ['g035', 'Zebra tea ceremony'], ['g036', 'Chrome spirals and pearls'], ['g037', 'Zebra-faced clay portrait'], ['g038', 'Purple cell, zebra tide'], ['g039', 'Porcelain cell in glass'],
  ['g040', 'Hooded pilgrims, ring wall'], ['g041', 'Zebra boy and octopus'], ['g042', 'Porcelain mask, zebra tongue'], ['g043', 'Chrome grub with skull'], ['g044', 'Gold-toothed time machine'],
  ['g045', 'Spiral-cheeked dreamer'], ['g046', 'Zebra porthole diver'], ['g047', 'Rainbow knob collage'], ['g048', 'Pink mask maze badges'], ['g049', 'Iridescent propeller card'],
  ['g050', 'Zebra garage'], ['g051', 'Zebra-bearded dreamer'], ['g052', 'Glass terrarium of zebra dunes'], ['g053', 'Cosmic zebra whirlpool'], ['g054', 'Orange gremlin\'s T-square'],
  ['g055', 'Zebra girl at dusk'], ['g056', 'Clay snail zebra dream'], ['g057', 'Neon glass berserker'], ['g058', 'Latex spiral-head diver'], ['g059', 'Warbler zebra collage'],
  ['g060', 'Gaping toy monster'], ['g061', 'Clay planet spiral board'], ['g062', 'Gold mask in zebra folds'], ['g063', 'Pink worms on teal'], ['g064', 'Grey camera spiral board'],
  ['g065', 'Zebra maze crawler'], ['g066', 'Koala keyboard rapture'], ['g067', 'Grinning porcelain zebra'], ['g068', 'Dreamer in the zebra quilt'], ['g069', 'Porcelain bubble menagerie'],
  ['g070', 'Kintsugi porcelain muse'], ['g071', 'Jellyfish in the pink gallery'], ['g072', 'Gold-slab grin in glass'], ['g073', 'Spiral-cheeked paper dreamer'], ['g074', 'Tube-bearded goggle beast'],
  ['g075', 'Coin avalanche at sea'], ['g076', 'Glowing spiral control panel'], ['g077', 'Zebra clam in the desert'], ['g078', 'Pink sea-monster tentacles'], ['g079', 'Orange coral totem'],
  ['g080', 'Tongue in the pink gallery'], ['g081', 'Zebra-winged studio visitor'], ['g082', 'Starry rug bedroom'], ['g083', 'Jellyfish television'], ['g084', 'Spiral dusk encounter'],
  ['g085', 'Zebra-gilled leaf creature'], ['g086', 'Clay cosmos control board'], ['g087', 'Glow ghosts and zebra suns'], ['g088', 'Night watchman\'s window'], ['g089', 'Cat in the pink splash'],
  ['g090', 'Rainbow chrome contraption'], ['g091', 'Neon seed pillow'], ['g092', 'Blue ghost in stockings'], ['g093', 'Porcelain hypnosis garden'], ['g094', 'Gilded profile, pearl S'],
  ['g095', 'Golden reel, green tablet'], ['g096', 'Hedgehog zebra helmet'], ['g097', 'Chrome puddle on coral'], ['g098', 'Ghosts in the pink gallery'], ['g099', 'Figure-eight alley'],
  ['g100', 'Bubble-helmet goggle girl'], ['g101', 'Seal of bubbles'], ['g102', 'Mint clay fingerprint'], ['g103', 'Sherbet board on zebra'], ['g104', 'Golden dial in orbit'],
  ['g105', 'Pearl caterpillar fringe'], ['g106', 'Lime blobs on zebra'], ['g107', 'Junkyard zebra flag'], ['g108', 'Spiral zebra porthole head'], ['g109', 'Zebra screen console'],
  ['g110', 'Hypnotic tea party'], ['g111', 'Mirrored clay reacher'], ['g112', 'Zebra sleepers\' still life'], ['g113', 'Glossy mustache panel'], ['g114', 'Felt collage with spirals'],
  ['g115', 'Coral branch and zebra flow'], ['g116', 'Zebra egg and coil'], ['g117', 'Silver zebra-faced idol'], ['g118', 'Smiley porthole plate'], ['g119', 'Four-panel zebra dream'],
  ['g120', 'Airbrushed grinning maw'], ['g121', 'Coral clay planet'], ['g122', 'Orange face collage'], ['g123', 'Fingerprint chrome dreamer'], ['g124', 'Coral capsule still life'],
  ['g125', 'Zebra-spined beast'], ['g126', 'Visor sage, zebra coat'], ['g127', 'Mallet, zebra and drip'], ['g128', 'Smoke-room zebra feast'], ['g129', 'Lavender spiral console'],
  ['g130', 'Chrome gnome in the stars'], ['g131', 'Cosmic zebra octopus'], ['g132', 'Pipe ring sprite'], ['g133', 'Mint paper collage'], ['g134', 'Gold baubles elephant'],
  ['g135', 'Golden zebra puffer'], ['g136', 'Crackled eye dish'], ['g137', 'Zebra-bearded hat robot'], ['g138', 'Hooded glitch profile'], ['g139', 'Zebra tunnel card'],
  ['g140', 'Moonstruck zebra singer'], ['g141', 'Starry glass cup'], ['g142', 'Fingerprint whorl ball'], ['g143', 'Golden seahorse dunes'], ['g144', 'Hypnotic machine collage'],
  ['g145', 'Yellow-headed pipe idol'], ['g146', 'Chrome cloud on red'], ['g147', 'Zebra poodle plaza'], ['g148', 'Pebbled zebra console'], ['g149', 'Golden scorpion pool'],
  ['g150', 'Airbrushed blue spool'], ['g151', 'Horned swoon'], ['g152', 'Spiral puddle machine'], ['g153', 'Octopus ring circus'], ['g154', 'Pill tray and zebra hose'],
  ['g155', 'Cracked spiral slab'], ['g156', 'Chrome dentures on zebra'], ['g157', 'Melted iron idol'], ['g158', 'Spiral-eyed lounge'], ['g159', 'Speaker relief board'],
  ['g160', 'Starry-faced clay lady'], ['g161', 'Pearl-ringed cosmic eye'], ['g162', 'Hose-headed concrete idol'], ['g163', 'Holographic crescent targets'], ['g164', 'Golden pouf and spirals'],
  ['g165', 'Corn-snake playroom'], ['g166', 'Meringue zebra machine'], ['g167', 'Mirror-visor noodle rider'], ['g168', 'Crayon starfield bouquet'], ['g169', 'Clay fish, gold kintsugi'],
  ['g170', 'Sun-faced idol wheel'], ['g171', 'Porthole of rainbow chrome'], ['g172', 'Clay robot sunburst'], ['g173', 'Pearl clay and gold coils'], ['g174', 'Sunburst dial machine'],
  ['g175', 'Glass pawn in zebra wind'], ['g176', 'Rear-view joyride'], ['g177', 'Feathered wave goodbye'], ['g178', 'Red-haloed octo mask'], ['g179', 'Bell-jar professor'],
  ['g180', 'Spiral sweet tin'], ['g181', 'Clay script over the vortex'], ['g182', 'Rabbit plaque on magenta'], ['g183', 'Porcelain zebra melt'], ['g184', 'Frosted clay reef'],
  ['g185', 'Puffball zebra drift'], ['g186', 'Afterparty in the zebra lounge'], ['g187', 'Still life with bee pod'], ['g188', 'Zebra-legged strongman'], ['g189', 'Moon mouth with zebra drapes'],
  ['g190', 'Nuns of the zebra spiral'], ['g191', 'Sunset puppet theatre'], ['g192', 'Starship lens console'], ['g193', 'Pearl goggles and the pup'], ['g194', 'Enamel spiral slab'],
  ['g195', 'Porthole in the goo'], ['g196', 'Zebra goo cyclops'], ['g197', 'Lavender gadget, chrome eyes'], ['g198', 'Zebra wave, ember eye'], ['g199', 'Horned zebra totem'],
  ['g200', 'Ice ghost, red roe'], ['g201', 'Lavender heart grin'], ['g202', 'Pearl spiral monster'], ['g203', 'Orange porthole machine'], ['g204', 'Starry skull smoker'],
  ['g205', 'Ringed shuttle dream'], ['g206', 'Zebra visor porthole face'], ['g207', 'Goggled noodle platter'], ['g208', 'Goldfish in the glass helmet'], ['g209', 'Shell platter with zebra crown'],
  ['g210', 'Porthole frog with zebra hat'], ['g211', 'Frowning mint spore'], ['g212', 'Cog-eye slate medallion'], ['g213', 'Lilac pyramid shrine'], ['g214', 'Moon-face eye pod'],
  ['g215', 'Lens-eyed flower sphere'], ['g216', 'Chrome fish on a zebra capsule'], ['g217', 'Pearl caterpillars in a robot sea'], ['g218', 'Zebra drum and cow-lattice eye'], ['g219', 'Anemone with a zebra spoon'],
  ['g220', 'Twin pods and green cells'], ['g221', 'Zebra porthole stew'], ['g222', 'Jellyfish dome summit'], ['g223', 'Op-art jaw at dusk'], ['g224', 'Zebra yeti space collage'],
  ['g225', 'Chrome fish with a sun eye'], ['g226', 'Tendrils over the vortex'], ['g227', 'Brain-coral patchwork'], ['u001', 'Zebra river, checker shores'], ['u002', 'Chrome horn, red star'],
  ['u003', 'Wine-sipping space diver'], ['u004', 'Clay ram-horn cyclops'], ['u005', 'Gilded night collage'], ['u006', 'Blue chain nightwalk'], ['u007', 'Zebra-beard grinner'],
  ['u008', 'Cosmic clay sultan'], ['u009', 'Leopard peak turntable'], ['u010', 'Pink clay jaw on zebra'], ['u011', 'Pale ghost and orange dome'], ['u012', 'Burnt postcard nebula'],
  ['u013', 'Wond speaker eye'], ['u014', 'Toothed saucer and film reel'], ['u015', 'Icy face, glowing pill'], ['u016', 'Gold pear reliquary'], ['u017', 'Orange peanut sentinel'],
  ['u018', 'Pink dome cosmos'], ['u019', 'Zebra cartridge relic'], ['u020', 'Chrome kid at the garage'], ['u021', 'Toothy gallery diorama'], ['u022', 'Zebra fish collage'],
  ['u023', 'Glass tray toy box'], ['u024', 'Cosmic vortex acrobats'], ['u025', 'Chrome saucer reverie'], ['u026', 'Studded gloss mask'], ['u027', 'Gold vase, zebra flesh'],
  ['u028', 'Mint moon atlas'], ['u029', 'Shark ghosts\' starry cave'], ['u030', 'Gold-suited moon dancer'], ['u031', 'Pink clay carnival'], ['u032', 'Zebra turntable cosmos'],
  ['u033', 'Horned chrome idol'], ['u034', 'Gold spill living room'], ['u035', 'Scorched enamel ghost'], ['u036', 'Frosted lavender clay parade'], ['u037', 'Cosmic pink gallery'],
  ['u038', 'Chrome zebra grin'], ['u039', 'Golden eggs on the racetrack'], ['u040', 'Paint-splash listener'], ['u041', 'Doorway on the star coast'], ['u042', 'Gold-clawed star anemone'],
  ['u043', 'Crackle island lounge'], ['u044', 'Gold dial under zebra sky'], ['u045', 'Window onto the cosmos'], ['u046', 'Tongue over the runway'], ['u047', 'Comic cosmos with paint'],
  ['u048', 'Gold slabs at dusk'], ['u049', 'Fluffy arch over Datth'], ['u050', 'Marbled moon plate'], ['u051', 'Gold oracle in zebra hood'], ['u052', 'Night window in sand'],
  ['u053', 'Radio night collage'], ['u054', 'Gold neck in cow pasture'], ['u055', 'Silver hand, golden knot'], ['u056', 'Pearl-laden bearded dreamer'], ['u057', 'Spiked star in a framed void'],
  ['u058', 'Gold crab in porcelain'], ['u059', 'Starburst totem'], ['u060', 'Skeleton feeds the birds'], ['u061', 'Coral eye collage'], ['u062', 'Plush parade'],
  ['u063', 'Cosmic French press'], ['u064', 'Gold dancer on the rubble'], ['u065', 'Moonbeam face and the egg'], ['u066', 'Comet-tailed sea anemone'], ['u067', 'Goggled pilot in chrome smoke'],
  ['u068', 'Telescope over the sponge cake'], ['u069', 'Ember holes, zebra tides'], ['u070', 'Marttaled control desk'], ['u071', 'Clay viking crooner'], ['u072', 'Arcade relief altar'],
  ['u073', 'Sparkle cyclops and gold'], ['u074', 'Coral reactor colossus'], ['u075', 'Zebra sage on the moon'], ['u076', 'Snowman under the glass moon'], ['u077', 'Zebra-crowned face board'],
  ['u078', 'Cow-print kart with gold spill'], ['u079', 'Caulk-gun madonna'], ['u080', 'Gold X medallion'], ['u081', 'Mercury puddle and comb'], ['u082', 'Thorn crown reverie'],
  ['u083', 'Zebra beast and coral eye'], ['u084', 'Circuit-board reef'], ['u085', 'Gilded bull in orbit'], ['u086', 'Holographic porcelain dancer'], ['u087', 'Plaster moon mask'],
  ['u088', 'Chrome cutlery storm'], ['u089', 'Cream-ridged star whale'], ['u090', 'Leopard bear, blue drum'], ['u091', 'Gold-beaked zebra dish'], ['u092', 'Olive glass melt'],
  ['u093', 'Chrome dreamer, gold moon'], ['u094', 'Chrome scrawl, skatepark disc'], ['u095', 'Neon-bound green sleeper'], ['u096', 'Crumpled night, blue scrawl'], ['u097', 'u097'],
  ['u098', 'Stone mask in blue starlight'], ['u099', 'Gilded zebra riot'], ['u100', 'Zebra meets the moai']];

const S = {
  mode: 'idle', name: '', orig: null, out: null, outX: null, running: false, done: false, t0: 0, pausedAt: 0, pausedTotal: 0,
  queue: [], acc: 0, workerDone: false, finalSim: null,
  count: 0, total: 0, sim: null, codeBytes: 0,
  // auto
  lines: [], items: [], drawn: [], bits: 0, fmt: 'packed', k: 1, bgHex: '#000000', recent: [], gen: 0,
  // replay
  src: [], opLines: [], opKinds: [], step: 0, frame: null, api: null, cur: null, sched: [], replayGen: 0,
  rec: null
};
// (a self-contained page — one that works opened straight from the disk — carries the painter's code with it)
const WORKER_URL = window.CP_WORKER_SRC ? URL.createObjectURL(new Blob([window.CP_WORKER_SRC], { type: 'text/javascript' })) : 'painter-worker.js?v=4.16.0', worker = new Worker(WORKER_URL);
// ── live modes (video, zoom, live inputs): several painters at once, each painting its own band of rows, so the
// painting keeps up with the speed slider (one painter alone manages ~150 strokes a second). More speed, more painters.
const POOL = { helpers: [], max: Math.max(1, Math.min(7, (navigator.hardwareConcurrency || 4) - 2)) };
function helper(i) {
  if (POOL.helpers[i]) return POOL.helpers[i];
  const h = POOL.helpers[i] = { w: new Worker(WORKER_URL), gen: -1, busy: false };
  h.w.onmessage = e => {
    const m = e.data; wake();
    if (m.gen !== S.gen || m.gen !== h.gen) return;
    if (m.type === 'shape') { if (S.mode === 'auto' && S.endless.on && m.L !== undefined && styleOkFor(m)) S.queue.push(m); }
    else if (m.type === 'need') h.busy = false;
  };
  return h;
}
const poolSize = () => { const f = speedFactor(); return f === Infinity ? POOL.max + 1 : Math.min(POOL.max + 1, Math.max(2, Math.round(1 + f / 2))); };
const helpersPost = msg => { for (const h of POOL.helpers) { h.w.postMessage(msg); if (msg.type === 'stop') { h.busy = false; h.gen = -1; } } };
// stroke size: ×0.25 … ×4 of the usual range (each stroke's size within it stays random)
const sizeK = () => { const v = +$('ssize').value; return Math.pow(2, v / (v < 0 ? 30 : 50)); };      // ×0.1 … ×1 … ×4
// auto stroke count: about what it takes to cover the canvas — more for small strokes, fewer for big ones, more for
// styles that draw thin lines (pencil, pen…); a style's own size counts too
const THIN = { pencil: 2.4, pen: 2.4, hatch: 2, charcoal: 1.5, pastel: 1.3, marker: 1.5, string: 1.5, points: 1.6, stitch: 1.3, thread: 1.3, calligraphy: 1.3, sumi: 1.2, ink: 1.2, neon: 1.4, beads: 1.2 };
function autoShapes() {
  const st = stylePick.values(), ks = st.map(v => Math.pow(styleSizeOf(v), -1.3) * (THIN[v] || 1)), sf = ks.reduce((a, b) => a + b, 0) / Math.max(1, ks.length);
  const k = sizeRand() ? 0.9 : Math.pow(sizeK(), -1.3);
  return Math.max(150, Math.min(20000, Math.round(1000 * k * sf / 50) * 50));
}
// a style's own stroke size (right-click its key): ×0.25 … ×4, on top of the size knob
const SSZ = (() => { try { return JSON.parse(store('cp-stysize') || '{}') || {}; } catch (e) { return {}; } })();
const styleSizeOf = v => SSZ[v] || 1;
const shapesWanted = () => $('shapes').value === 'auto' ? autoShapes() : +$('shapes').value || 1000;
function showAutoShapes() { const o = $('shapes').querySelector('option[value="auto"]'); if (o && typeof stylePick !== 'undefined') o.textContent = `auto (${autoShapes()})`; }
const sizeRand = () => $('ssizerand').checked;          // random: every stroke picks its own size, ×0.25 … ×4

// ── example + replay menus ───────────────────────────────────
// (the public web version — window.CP_PUBLIC — has no artworks and no replays: its examples are demo pictures drawn
// here in code)
const PUBLIC = !!window.CP_PUBLIC;
// the artworks come in sets (by the first letter of their id): shirt art s01…, flux glitch 15 g001…, flux glitch 1 u001…
const SETS = [['s', 'shirt art'], ['g', 'flux glitch 15'], ['u', 'flux glitch 1']];
const refOf = id => `../style-reel/${id[0] === 's' ? 'shirt_refs' : 'glitch_refs'}/${id}.webp`;
if (window.CP_DEMO_JAS) $('example').add(new Option('demo · JAS.BLACK', '__demo:jas'));
$('example').add(new Option('✎ your text…', '__text'));
if (!PUBLIC) {
  for (const [k, label] of SETS) {
    const list = PIECES.filter(([id]) => id[0] === k); if (!list.length) continue;
    const ge = document.createElement('optgroup'), gr = document.createElement('optgroup'); ge.label = gr.label = `${label} (${list.length})`;
    for (const [id, name] of list) { ge.appendChild(new Option(`${id} · ${name}`, refOf(id))); gr.appendChild(new Option(`${id} · ${name}`, id)); }
    $('example').appendChild(ge); $('replay').appendChild(gr);
  }
  const rs = document.createElement('optgroup'); rs.label = 'one after another';
  for (const [k, label] of SETS) { const n = PIECES.filter(([id]) => id[0] === k).length; if (n) rs.appendChild(new Option(`▶ all ${label} (${n})`, '__show:' + k)); }
  if (PIECES.length) { rs.appendChild(new Option(`▶ all of them (${PIECES.length})`, '__show:')); $('replay').appendChild(rs); }
  const og = document.createElement('optgroup'); og.label = 'more';
}
if (PUBLIC) {
  // (the public page can carry one picture of its own, first: window.CP_DEMO_JAS)
  const demos = [['orb', 'demo · chrome orb'], ['dusk', 'demo · dusk waves'], ['bloom', 'demo · bloom'], ['blocks', 'demo · colour blocks']];
  for (const [k, name] of demos) $('example').add(new Option(name, '__demo:' + k));
  $('replay').closest('.row').style.display = 'none'; $('mix').closest('.row').style.display = 'none'; $('layerrow').style.display = 'none';     // (replay and its knobs: the local version, which has the pieces)
}
// all of a set at once, as a playlist
{
  const og = document.createElement('optgroup'); og.label = 'all at once';
  const sets = PUBLIC ? [['', 'the demos']] : SETS.filter(([k]) => PIECES.some(([id]) => id[0] === k));
  for (const [k, label] of sets) og.appendChild(new Option(`▶ ${label}, as a playlist`, '__playlist:' + k));
  $('example').appendChild(og);
}

// ── helpers ──────────────────────────────────────────────────
// pixel size of an image, video or canvas
function srcW(el) { return el.videoWidth || el.naturalWidth || el.width || 1; }
function srcH(el) { return el.videoHeight || el.naturalHeight || el.height || 1; }
// draw el so it covers the rectangle (cropping what overflows), like CSS object-fit: cover
function drawCover(x, el, dx, dy, dw, dh) {
  const iw = srcW(el), ih = srcH(el), k = Math.max(dw / iw, dh / ih), sw = dw / k, sh = dh / k;
  x.drawImage(el, (iw - sw) / 2, (ih - sh) / 2, sw, sh, dx, dy, dw, dh);
}
// jump a video to time t and wait until that frame is ready
function seekTo(v, t) {
  return new Promise(ok => { const done = () => { v.removeEventListener('seeked', done); ok(); }; v.addEventListener('seeked', done); setTimeout(done, 1500); v.currentTime = t; });
}
const loadImg = src => new Promise((ok, bad) => {
  const i = new Image();
  if (/^https?:/.test(src) && new URL(src).origin !== location.origin) i.crossOrigin = 'anonymous';   // pictures dragged in from websites
  i.onload = () => ok(i); i.onerror = () => bad(new Error('the browser could not decode it')); i.src = src;
});
const sleep = ms => new Promise(r => setTimeout(r, ms));
const fmtTime = s => `${Math.floor(s / 60)}:${String(Math.floor(s % 60)).padStart(2, '0')}`;
const elapsed = () => S.t0 ? ((S.running || !S.pausedAt ? clock() : S.pausedAt) - S.t0 - S.pausedTotal) / 1000 : 0;
const clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v;
function fit(img, r) {
  const iw = srcW(img), ih = srcH(img), k = Math.min(r.w / iw, r.h / ih);
  const w = iw * k, h = ih * k; return { x: r.x + (r.w - w) / 2, y: r.y + (r.h - h) / 2, w, h, k };
}
function setButtons() {
  const active = S.mode !== 'idle';
  $('play').disabled = !active || (S.done && !audioActive()); $('restart').disabled = !active; $('rec').disabled = !active;
  // while zooming endlessly there is no finished program to save (⬇ png saves the current view)
  $('savecode').disabled = $('savesvg').disabled = S.mode !== 'auto' || !S.count || S.endless.on; $('savepng').disabled = !active;
  $('savestills').disabled = $('savesheet').disabled = !stillsOk(); $('savecover').disabled = !active;
  $('embedmusic').disabled = !AU.el;
  $('play').textContent = S.running ? '⏸ pause' : '▶ resume';
  $('audiox').disabled = !AU.el;
}
// similarity vs the original (mean absolute colour error at 128 px), the same measure as the recreation harness
const simCv = document.createElement('canvas'), simX = simCv.getContext('2d', { willReadFrequently: true });
let simRef = null;
function simPrepare(img) {
  const iw = srcW(img), ih = srcH(img), k = 128 / Math.max(iw, ih);
  simCv.width = Math.max(1, Math.round(iw * k)); simCv.height = Math.max(1, Math.round(ih * k));
  simX.drawImage(img, 0, 0, simCv.width, simCv.height); simRef = simX.getImageData(0, 0, simCv.width, simCv.height).data;
}
function simOf(cv) {
  simX.drawImage(cv, 0, 0, simCv.width, simCv.height);
  const d = simX.getImageData(0, 0, simCv.width, simCv.height).data; let e = 0;
  for (let i = 0; i < d.length; i += 4) e += Math.abs(d[i] - simRef[i]) + Math.abs(d[i + 1] - simRef[i + 1]) + Math.abs(d[i + 2] - simRef[i + 2]);
  return 100 * (1 - e / (d.length / 4 * 3) / 255);
}

// ═════════════════════════════════════════════════════════════
//  Music
// ═════════════════════════════════════════════════════════════
const AU = { ctx: null, el: null, srcNode: null, an: null, dest: null, file: null, name: '', dur: 0, hop: 0, fft: null,
  rms: null, on: null, cum: null, hits: [], bpm: 0, in: 0, out: 0, preview: false,
  bass: 0, mid: 0, high: 0, beat: 0, beats: 0, hi: 0, ended: false };
const FIT = 0.92;
function audioCtx() {
  if (!AU.ctx) { AU.ctx = new AudioContext(); AU.dest = AU.ctx.createMediaStreamDestination(); AU.mix = AU.ctx.createGain(); AU.mix.connect(AU.dest); }
  return AU.ctx;
}
// what a recording hears: the music / live sound and the stroke sounds (nothing at all: no sound track)
const recAudio = () => AU.ctx && AU.mix && (AU.live || AU.el || SND.on || VS.node) ? { ctx: AU.ctx, node: AU.mix } : null;                 // "follow energy" mode completes the painting at 92% of the selection
const lerp = (a, b, t) => a + (b - a) * t;
const audioActive = () => !!AU.el;
// where the song is (seconds) and whether it plays — during an offline render, on the render's own clock
const aTime = () => OFF.on ? OFF.aT : AU.el ? AU.el.currentTime : 0;
const aPaused = () => OFF.on ? !OFF.aPlaying : !AU.el || AU.el.paused;
// live sound (microphone, or a captured screen / tab) drives the painting too, with beats found as they happen
const musicMode = () => audioActive() || AU.live ? $('musicmode').value : 'none';   // hits | flow | free
const beatFx = () => $('beatfx').checked;
// media: an existing <video> whose own soundtrack becomes the music (otherwise a new <audio> for the song)
// ── a video's own sound: off (silent), keep (heard and recorded as it is, no beat analysis), music (drives the painting) ──
const VS = { node: null, el: null };
const MEDIA_SRC = new WeakMap();
function mediaSource(el) { let n = MEDIA_SRC.get(el); if (!n) { n = AU.ctx.createMediaElementSource(el); MEDIA_SRC.set(el, n); } return n; }
function vsoundShow() { const b = $('vsound'); if (!b) return; const v = S.video; b.hidden = !(v && !v.srcObject && S.vfile); b.textContent = `🎞 sound: ${S.vsound || 'off'}`; b.classList.toggle('on', (S.vsound || 'off') !== 'off'); }
function keepOff() { if (VS.node) { try { VS.node.disconnect(); } catch (e) {} } VS.node = null; if (VS.el) VS.el.muted = true; VS.el = null; }
async function setVideoSound(mode) {
  const v = S.video; if (!v || !S.vfile) return;
  keepOff();
  if (AU.el === v) removeAudio();
  S.vsound = mode;
  if (mode === 'keep') { audioCtx(); await AU.ctx.resume(); const n = mediaSource(v); n.connect(AU.ctx.destination); n.connect(AU.mix); VS.node = n; VS.el = v; v.muted = false; $('hint').textContent = "Video sound: kept — it plays and goes into the recording; the painting doesn't follow it."; }
  else if (mode === 'music') { if (await loadAudio(S.vfile, v)) { v.muted = false; $('hint').textContent = "Video sound: music — the painting follows its hits like a song."; } else S.vsound = 'off'; }
  else { v.muted = true; $('hint').textContent = 'Video sound: off.'; }
  vsoundShow(); setButtons();
}
async function loadAudio(file, media) {
  try {
    audioCtx(); await AU.ctx.resume();
    $('hint').textContent = `Analysing ${file.name}…`;
    const buf = await AU.ctx.decodeAudioData(await file.arrayBuffer());
    analyse(buf);
    releaseAudio();
    AU.el = media || new Audio(URL.createObjectURL(file)); AU.el.preload = 'auto'; AU.ownEl = !media;
    AU.srcNode = mediaSource(AU.el);
    if (!AU.an) { AU.an = AU.ctx.createAnalyser(); AU.an.fftSize = 2048; AU.an.smoothingTimeConstant = 0.55; AU.fft = new Uint8Array(AU.an.frequencyBinCount); AU.an.connect(AU.ctx.destination); AU.an.connect(AU.mix); }
    AU.srcNode.connect(AU.an);
    AU.name = file.name.replace(/\.[^.]+$/, ''); if ($('demosong') && $('demosong').value !== AU.name) $('demosong').value = '';     // (a song of your own: the demo menu goes back to its title)
    AU.dur = buf.duration; AU.ended = false; AU.file = file;
    AU.in = 0; AU.out = AU.dur;
    AU.el.onended = onAudioEnded;
    detectHits();
    AU.sections = findSections(); AU.key = songKey(buf);
    $('audioname').textContent = `♪ ${AU.name} · ${fmtTime(AU.dur)} · ${NOTE_NAMES[AU.key.root]}${AU.key.minor ? 'm' : ''}`;
    $('timeline').hidden = false; fitStage();
    $('hint').textContent = `Music ready (${AU.sections.length} sections: ${AU.sections.map(x => x.kind).join(' · ')}): drag on the timeline to choose the part to paint to. ${S.mode === 'idle' ? 'Then pick an image or a piece.' : 'Then press ⟲ restart.'}`;
    setButtons();
    return true;
  } catch (e) { if (!media) $('hint').textContent = 'Could not read that audio file: ' + e.message; return false; }
}
// let go of the current music; a video that was providing it carries on, silent and looping
function releaseAudio() {
  if (!AU.el) return;
  AU.srcNode.disconnect();
  if (AU.ownEl) { AU.el.pause(); URL.revokeObjectURL(AU.el.src); }
  else { AU.el.muted = true; AU.el.loop = true; AU.el.onended = null; }
  AU.el = null;
}
function removeAudio() {
  if (!AU.el) return;
  releaseAudio(); AU.cum = null; AU.file = null; AU.preview = false; AU.resumeAt = null; AU.grid = null; AU.sections = null; AU.key = null;
  $('audioname').textContent = $('tlsel').textContent = $('tlhits').textContent = ''; $('matchshapes').textContent = `= hits × ${$('perhit').value}`; $('timeline').hidden = true; fitStage(); setButtons();
}
// offline analysis of the whole track (~23 ms frames): loudness, onset strength (new energy, weighted to the bass),
// the cumulative energy curve used by "follow energy", and the tempo
function analyse(buf) {
  const sr = buf.sampleRate, n = buf.length, hop = 1024, frames = Math.max(2, Math.floor(n / hop));
  const chans = []; for (let c = 0; c < buf.numberOfChannels; c++) chans.push(buf.getChannelData(c));
  const rms = new Float32Array(frames), low = new Float32Array(frames), hi = new Float32Array(frames), a = 1 - Math.exp(-2 * Math.PI * 150 / sr), a2 = 1 - Math.exp(-2 * Math.PI * 2500 / sr);
  let lp = 0, lp2 = 0;
  for (let f = 0; f < frames; f++) {
    let s = 0, sl = 0, sh = 0;
    for (let i = f * hop; i < (f + 1) * hop; i++) {
      let x = 0; for (const ch of chans) x += ch[i] || 0; x /= chans.length;
      lp += a * (x - lp); lp2 += a2 * (x - lp2); s += x * x; sl += lp * lp; sh += (x - lp2) * (x - lp2);
    }
    rms[f] = Math.sqrt(s / hop); low[f] = Math.sqrt(sl / hop); hi[f] = Math.sqrt(sh / hop);
  }
  { let ml = 1e-9, mh = 1e-9; for (let f = 0; f < frames; f++) { ml = Math.max(ml, low[f]); mh = Math.max(mh, hi[f]); } for (let f = 0; f < frames; f++) { low[f] /= ml; hi[f] /= mh; } AU.low = low; AU.hi = hi; }
  let mr = 1e-9, mo = 1e-9; const on = new Float32Array(frames);
  for (let f = 1; f < frames; f++) on[f] = Math.max(0, low[f] - low[f - 1]) + 0.5 * Math.max(0, rms[f] - rms[f - 1]);
  for (let f = 0; f < frames; f++) { mr = Math.max(mr, rms[f]); mo = Math.max(mo, on[f]); }
  for (let f = 0; f < frames; f++) { rms[f] /= mr; on[f] /= mo; }
  const cum = new Float32Array(frames + 1);
  for (let f = 0; f < frames; f++) cum[f + 1] = cum[f] + 0.04 + Math.pow(rms[f], 1.3) + 1.5 * on[f];
  AU.rms = rms; AU.on = on; AU.cum = cum; AU.hop = hop / sr;
}
// hits: peaks of the onset curve that stand out from their ±0.4 s neighbourhood; sensitivity trades how many
function detectHits() {
  const on = AU.on, n = on.length, sens = +$('sens').value / 100;
  const k = lerp(2.2, 0.3, sens), gap = lerp(0.3, 0.085, sens), floor = lerp(0.22, 0.025, sens);
  const ps = new Float64Array(n + 1), ps2 = new Float64Array(n + 1);
  for (let f = 0; f < n; f++) { ps[f + 1] = ps[f] + on[f]; ps2[f + 1] = ps2[f] + on[f] * on[f]; }
  const win = Math.max(2, Math.round(0.4 / AU.hop)), hits = [];
  for (let f = 1; f < n - 1; f++) {
    if (on[f] < on[f - 1] || on[f] <= on[f + 1] || on[f] < floor) continue;
    const a0 = Math.max(0, f - win), a1 = Math.min(n, f + win + 1), m = a1 - a0;
    const mean = (ps[a1] - ps[a0]) / m, sd = Math.sqrt(Math.max(0, (ps2[a1] - ps2[a0]) / m - mean * mean));
    const t = f * AU.hop;
    if (on[f] > mean + k * sd) {
      if (hits.length && t - hits[hits.length - 1].t < gap) { if (on[f] > hits[hits.length - 1].s) hits[hits.length - 1] = { t, s: on[f] }; }
      else hits.push({ t, s: on[f] });
    }
  }
  const mx = hits.reduce((a, h) => Math.max(a, h.s), 1e-9); for (const h of hits) h.s = Math.min(1, h.s / mx * 1.25);
  AU.hits = hits; updateSelectionInfo();
}
const hitsInSel = () => AU.hits.filter(h => h.t >= AU.in - 0.06 && h.t <= AU.out);   // a hit right on the in point counts
// tempo of the selection: autocorrelation of the onset curve, lightly biased towards 90–150 BPM
function estimateBpm(a = AU.in, b = AU.out) {
  const f0 = Math.floor(a / AU.hop), f1 = Math.min(AU.on.length, Math.floor(b / AU.hop));
  if (f1 - f0 < 40) return 0;
  // smooth the onsets a little first: a beat period that falls between two frames would otherwise
  // split its correlation over both lags and lose to the (exact) half tempo
  const on = new Float32Array(AU.on.length), K = [1, 2, 3, 2, 1];
  for (let f = f0; f < f1; f++) { let s = 0; for (let j = -2; j <= 2; j++) s += (AU.on[f + j] || 0) * K[j + 2]; on[f] = s / 9; }
  const lo = Math.round(0.3 / AU.hop), hi = Math.round(1.0 / AU.hop), sc = new Float64Array(hi + 2);
  let bestLag = 0;
  for (let lag = lo - 1; lag <= hi + 1; lag++) {
    let s = 0; for (let f = f0; f + lag < f1; f++) s += on[f] * on[f + lag];
    const bpm = 60 / (lag * AU.hop), bias = Math.exp(-(Math.log2(bpm / 120) ** 2) / 0.5);
    sc[lag] = s / (f1 - f0 - lag) * (0.6 + 0.4 * bias);
    if (lag >= lo && lag <= hi && sc[lag] > (sc[bestLag] || 0)) bestLag = lag;
  }
  if (!bestLag) return 0;
  // parabolic fit around the peak for a sub-frame lag (frames are ~23 ms, too coarse for an exact tempo)
  const y0 = sc[bestLag - 1], y1 = sc[bestLag], y2 = sc[bestLag + 1], d = y0 - 2 * y1 + y2;
  return 60 / ((bestLag + (d < 0 ? 0.5 * (y0 - y2) / d : 0)) * AU.hop);
}
function updateSelectionInfo() {
  if (!AU.el && !AU.on) return;
  const len = AU.out - AU.in, H = hitsInSel(), per = +$('perhit').value;
  AU.bpm = estimateBpm(); AU.grid = beatGrid();
  $('tlsel').textContent = `${fmtTime(AU.in)} → ${fmtTime(AU.out)} (${len.toFixed(1)} s)`;
  $('tlhits').textContent = `${H.length} hits${AU.bpm ? ` · ~${Math.round(AU.bpm)} BPM (${Math.round(len * AU.bpm / 60)} beats)` : ''}`;
  $('matchshapes').textContent = `= ${H.length}×${per}`;
  drawTimeline();
}
// the song's bar grid: the beat period, and the first downbeat of the selection (the phase where the onsets line up
// best, then whichever of the four beats of a bar hits hardest — kicks usually land on the one)
function beatGrid(A = AU.in, Bt = AU.out, bpm = AU.bpm) {
  if (!bpm || !AU.on) return null;
  const p = 60 / bpm, hop = AU.hop, on = AU.on, at = t => { const f = Math.round(t / hop); return on[f] || 0; };
  let ph = 0, best = -1;
  for (let s = 0, n = Math.max(8, Math.round(p / hop)); s < n; s++) {
    const o = s / n * p; let sc = 0;
    for (let t = A + o; t < Bt; t += p) sc += at(t) + 0.5 * (at(t - hop) + at(t + hop));
    if (sc > best) { best = sc; ph = o; }
  }
  let one = 0; best = -1;
  for (let j = 0; j < 4; j++) { let sc = 0; for (let t = A + ph + j * p; t < Bt; t += 4 * p) sc += at(t); if (sc > best) { best = sc; one = j; } }
  return { p, t0: A + ph + one * p };
}
// beats since the first downbeat: on the song's clock, or a steady 120 BPM from the start of the run without one
function beatNow() {
  if (audioActive() && AU.grid && S.songOn) return (aTime() - AU.grid.t0) / AU.grid.p;
  return elapsed() * 2;
}
// "paint on hits": how many strokes land on each hit of the selection — stronger hits carry more, the total is the shape count
// (looping: only the hits of its first 72%, so the painting is finished in time to go back to empty)
function hitPlan(total) {
  const H = hitsInSel().filter(h => h.t <= AU.in + (AU.out - AU.in) * (loopOn() ? 0.72 : 1) + 0.01); if (!H.length || !total) return null;
  const sect = $('sections').checked && AU.sections, w = H.map(h => (Math.pow(h.s, 1.3) + 0.05) * (sect ? 0.4 + 1.2 * secAt(h.t).e : 1)), W = w.reduce((a, b) => a + b, 0);
  let acc = 0, prev = 0;
  const n = H.map((h, i) => { acc += w[i]; const c = Math.round(total * acc / W), k = c - prev; prev = c; return k; });
  return { t: H.map(h => h.t), s: H.map(h => h.s), n, i: 0 };
}
// "follow energy": fraction of the painting that should be visible at time t (within the selection)
function audioProgress(t) {
  const at = x => { const g = Math.min(AU.cum.length - 1, Math.max(0, x / AU.hop)), i = Math.floor(g), fr = g - i; return AU.cum[i] * (1 - fr) + AU.cum[Math.min(i + 1, AU.cum.length - 1)] * fr; };
  const end = AU.in + (AU.out - AU.in) * (loopOn() && S.mode !== 'idle' ? 0.72 : FIT), a = at(AU.in), b = at(end);
  return clamp01((at(Math.min(t, end)) - a) / Math.max(1e-9, b - a));
}
// live: band envelopes for the EQ / FX, hits fired as playback passes them, stop at the out point
function listen(now, dt) {
  const k = Math.exp(-dt / 120);
  AU.beat *= Math.exp(-dt / 140);
  if (AU.live) return liveListen(now, dt, k);
  if (!AU.el || aPaused()) { AU.bass *= k; AU.mid *= k; AU.high *= k; AU.moving = false; return; }
  if (aTime() >= AU.out - 0.01) {
    // a video whose own sound is the music goes round its part again (a recording still ends here)
    if (!OFF.on && AU.el === S.video && S.mode === 'auto' && S.endless.on && !S.rec) { AU.el.currentTime = AU.in; AU.hi = 0; while (AU.hi < AU.hits.length && AU.hits[AU.hi].t < AU.in) AU.hi++; return; }
    if (OFF.on) { OFF.aPlaying = false; OFF.aEnd = OFF.frame; } else AU.el.pause(); onAudioEnded(); return;
  }
  if (OFF.on) { AU.moving = true; offlineSpectrum(OFF.aT); }
  else {
    // after a seek the element reports "playing" before the sound (and its clock) actually starts
    AU.moving = AU.el.currentTime !== AU.prevT && !AU.el.seeking; AU.prevT = AU.el.currentTime;
    AU.an.getByteFrequencyData(AU.fft);
  }
  const band = (a, b) => { let s = 0; for (let i = a; i < b; i++) s += AU.fft[i]; return s / (b - a) / 255; };
  AU.bass = Math.max(band(1, 8), AU.bass * k); AU.mid = Math.max(band(8, 90), AU.mid * k); AU.high = Math.max(band(90, 400), AU.high * k);
  const t = aTime(), L = AU.hits;
  if (AU.hi > 0 && L[AU.hi - 1].t > t + 0.3) { AU.hi = 0; while (AU.hi < L.length && L[AU.hi].t < t) AU.hi++; }
  while (AU.hi < L.length && L[AU.hi].t <= t) {
    const h = L[AU.hi++];
    if (t - h.t < 0.25) { AU.beat = Math.max(AU.beat, 0.4 + 0.6 * h.s); AU.beats++; onBeat(h); }
  }
}
// live sound: bands from the analyser; a beat is a jump in low-end energy well above its recent level
function liveListen(now, dt, k) {
  const Lv = AU.live, fft = AU.fft;
  Lv.an.getByteFrequencyData(fft);
  const band = (a, b) => { let s = 0; for (let i = a; i < b; i++) s += fft[i]; return s / (b - a) / 255; };
  AU.bass = Math.max(band(1, 8), AU.bass * k); AU.mid = Math.max(band(8, 90), AU.mid * k); AU.high = Math.max(band(90, 400), AU.high * k);
  let flux = 0; for (let i = 1; i < 24; i++) { const d = fft[i] - Lv.prev[i]; if (d > 0) flux += d; Lv.prev[i] = fft[i]; }
  flux /= 23 * 255;
  const a = 1 - Math.exp(-dt / 900); Lv.mean += (flux - Lv.mean) * a; Lv.dev += (Math.abs(flux - Lv.mean) - Lv.dev) * a;
  const sens = +$('sens').value / 100, thr = Lv.mean + Lv.dev * (3.2 - 2.2 * sens) + 0.01;
  if (flux > thr && now - Lv.last > 140 && band(1, 12) > 0.15) {
    const st = clamp01((flux - thr) / (thr + 1e-3) * 1.5 + 0.35);
    Lv.last = now; AU.beat = Math.max(AU.beat, 0.4 + 0.6 * st); AU.beats++; onBeat({ t: 0, s: st });
  }
}
// offline render: the analyser's view of the song at time t, worked out from the decoded song with the same maths as
// the browser's AnalyserNode (Blackman window, 2048-point FFT, 0.55 smoothing, −100…−30 dB), so beats, bands and the EQ
// come out as they would live
const FFT = { re: null, im: null, win: null, mag: null, rev: null };
function offlineSpectrum(t) {
  const P = OFF.pcm, N = 2048; if (!P || !AU.fft) return;
  if (!FFT.re) {
    FFT.re = new Float64Array(N); FFT.im = new Float64Array(N); FFT.mag = new Float64Array(N / 2); FFT.win = new Float64Array(N); FFT.rev = new Uint32Array(N);
    for (let i = 0; i < N; i++) {
      const a = 2 * Math.PI * i / N; FFT.win[i] = 0.42 - 0.5 * Math.cos(a) + 0.08 * Math.cos(2 * a);
      let r = 0; for (let b = 0, x = i; b < 11; b++, x >>= 1) r = (r << 1) | (x & 1); FFT.rev[i] = r;
    }
  }
  const re = FFT.re, im = FFT.im, end = Math.round((t - P.t0) * P.rate);
  for (let i = 0; i < N; i++) { const j = end - N + i, v = j >= 0 && j < P.L.length ? (P.L[j] + P.R[j]) / 2 : 0, r = FFT.rev[i]; re[r] = v * FFT.win[i]; im[r] = 0; }
  for (let size = 2; size <= N; size <<= 1) {
    const h = size >> 1, st = -2 * Math.PI / size;
    for (let k = 0; k < h; k++) {
      const wr = Math.cos(st * k), wi = Math.sin(st * k);
      for (let i = k; i < N; i += size) { const q = i + h, tr = re[q] * wr - im[q] * wi, ti = re[q] * wi + im[q] * wr; re[q] = re[i] - tr; im[q] = im[i] - ti; re[i] += tr; im[i] += ti; }
    }
  }
  for (let k = 0; k < N / 2; k++) {
    FFT.mag[k] = 0.55 * FFT.mag[k] + 0.45 * Math.hypot(re[k], im[k]) / N;
    AU.fft[k] = Math.max(0, Math.min(255, Math.floor(255 / 70 * (20 * Math.log10(FFT.mag[k] || 1e-12) + 100))));
  }
}
function setLiveAudio(stream, label) {
  audioCtx(); AU.ctx.resume(); releaseLiveAudio();
  const src = AU.ctx.createMediaStreamSource(stream), gain = AU.ctx.createGain(), an = AU.ctx.createAnalyser();
  an.fftSize = 2048; an.smoothingTimeConstant = 0.5; src.connect(gain); gain.connect(an); gain.connect(AU.mix);     // (not to the speakers: no echo)
  AU.fft = AU.fft || new Uint8Array(an.frequencyBinCount);
  AU.live = { src, gain, an, stream, prev: new Uint8Array(32), mean: 0, dev: 0, last: 0, label };
  $('audioname').textContent = `♪ live: ${label}`; setButtons();
}
function releaseLiveAudio() {
  if (!AU.live) return;
  try { AU.live.src.disconnect(); AU.live.gain.disconnect(); } catch (e) { /* gone already */ }
  AU.live = null; if (!AU.el) $('audioname').textContent = '';
}
function onBeat(h) {
  // the music in the paint: every beat lands one big bold stroke, snapped down on the beat (the painter makes it the
  // moment the beat comes: the worker's 'accent'); with one line, the line swells instead; on the 3D styles the light swings
  const bt = beatsOn(), st = Math.min(1, 0.35 + h.s), amt = musicAmt();
  if (S.mode === 'auto' && amt > 0) {
    S.hit = { t: clock(), s: st }; lightKick(st * amt);
    if (S.running && !S.pen && !S.endless.on && !S.workerDone && !S.accWant && S.count < S.total - 2) { S.accWant = { t: clock(), s: st }; worker.postMessage({ type: 'accent', k: 1.8 + 2.6 * st * amt }); }
  }
  if (bt.has('splash') && S.mode === 'auto' && S.running) beatSplash(st);
  if (bt.has('glow') && S.mode === 'auto') S.tipGlow = { t: clock(), s: Math.min(1, 0.45 + 0.7 * h.s) };
  if (bt.has('branch') && S.mode === 'auto' && S.pen && S.running) worker.postMessage({ type: 'branch', n: h.s > 0.75 ? 2 : 1 });
  if (S.wantNext && S.endless && S.endless.on) advancePlaylist();       // playlist: change picture on the beat
  // "free" mode: a hit throws a burst of strokes onto the canvas
  if (S.mode === 'auto' && S.running && (musicMode() === 'free' || (AU.live && !S.endless.on))) S.acc += (4 + 0.004 * S.count) * (0.3 + h.s) * (0.4 + react());
  // endless zoom "on the hits": every hit keeps dropping its flurry of strokes
  if (S.mode === 'auto' && S.running && S.endless.on && musicMode() === 'hits') { S.debt += Math.max(1, Math.round(+$('perhit').value * (0.5 + h.s))); }
}
const react = () => +$('react').value / 100;
// how much the song changes the painting itself (0..1); and the extras on the beat: splash · branch · glow
const musicAmt = () => +$('musicamt').value / 100;
{ const v = store('cp-musicamt'); if (v != null) $('musicamt').value = v; $('musicamt').addEventListener('input', () => store('cp-musicamt', $('musicamt').value)); }
const beatsOn = () => new Set([...document.querySelectorAll('#beatrow input:checked')].map(i => i.value));
{ const v = store('cp-beats'), on = new Set(v == null ? ['splash'] : v.split(',').filter(Boolean));
  for (const i of document.querySelectorAll('#beatrow input')) { i.checked = on.has(i.value); i.onchange = () => store('cp-beats', [...beatsOn()].join(',')); } }
// splash: the brushes being drawn this moment flick drops of their paint off the tip — they stay in the painting
function beatSplash(st) {
  const now = clock(); let n = 0;
  for (const L of S.landing) {
    if (n >= 3 || L.q.t !== 'S' || now < L.t0 || now > L.t0 + L.dur) continue;
    const q = L.q, a = q.args, u = clamp01((now - L.t0) / L.dur), P = quadPts(a, Math.max(0.05, u), L.dir, 12), e = P[P.length - 1], b = P[Math.max(0, P.length - 3)];
    const dir = Math.atan2(e[1] - b[1], e[0] - b[0]), w = Math.max(2, a[6]), [c0] = colsOf(q), o = colsOf(q)[2], R = rngFor([e[0], e[1], now % 997, a[6], 3, 7]);
    const drops = Math.round(5 + 10 * st);
    for (let k = 0; k < drops; k++) {
      const an = dir + (R() - 0.5) * 1.9, d = w * (0.6 + R() * R() * 3.2) * (0.7 + st), r = Math.max(0.6, w * (0.05 + 0.22 * R()) * (1 - d / (w * 5))), x = e[0] + Math.cos(an) * d, y = e[1] + Math.sin(an) * d;
      const drop = R() < 0.25
        ? { t: 'S', st: 'flat', brush: null, args: [e[0] + Math.cos(an) * d * 0.5, e[1] + Math.sin(an) * d * 0.5, x - Math.cos(an) * d * 0.15, y - Math.sin(an) * d * 0.15, x, y, Math.max(0.6, r * 0.7), an, c0, c0, o] }     // a streak
        : { t: 'E', st: 'flat', brush: null, args: [x, y, r, r * (0.7 + R() * 0.5), an, 0, c0, c0, o] };
      putShape(drop); if (!S.endless.on) S.drawn.push(drop);
    }
    n++;
  }
}
function playAudioFromStart() {
  if (!AU.el) return;
  AU.preview = false; AU.resumeAt = null; setListen();
  AU.ended = false; AU.hi = 0; while (AU.hi < AU.hits.length && AU.hits[AU.hi].t < AU.in) AU.hi++;
  S.songOn = true;
  if (OFF.on) { OFF.aPlaying = OFF.aStarted = true; OFF.aT = AU.in; OFF.aStart = OFF.frame; return; }
  AU.el.currentTime = AU.in;
  AU.ctx.resume(); AU.el.play().catch(() => { $('hint').textContent = 'Click ▶ to start the music (the browser blocked autoplay).'; });
}
function onAudioEnded() {
  if (AU.preview) { AU.preview = false; setListen(); return; }
  AU.ended = true;
  if (S.done && S.running) { S.running = false; S.pausedAt = clock(); setButtons(); }
  if (S.rec) recStopSoon(loopOn() && finiteRun() ? 0 : 600);
}
// preview the selection without painting
function setListen() { $('listen').textContent = AU.preview ? '■ stop' : '▶ listen'; }
function toggleListen() {
  if (!AU.el || OFF.on) return;
  if (AU.preview) { AU.el.pause(); AU.preview = false; setListen(); return; }
  if (S.running) $('play').click();
  if (S.mode !== 'idle' && AU.resumeAt == null) AU.resumeAt = AU.ended ? AU.out : AU.el.currentTime;   // the painting picks up here again
  AU.preview = true; setListen();
  AU.el.currentTime = AU.in; AU.hi = 0; while (AU.hi < AU.hits.length && AU.hits[AU.hi].t < AU.in) AU.hi++;
  AU.ctx.resume(); AU.el.play();
}

// ── video timeline: the part of a video that plays (and is recorded) ──
// Drag across it to choose the part, drag the green handles to adjust, click to jump there, double-click for the whole
// video. The video goes round that part for ever (a recording plays it once). With the video's own sound as the
// music the part is the song's in / out, so both timelines move together.
const VT = $('vtlc'), VX = VT.getContext('2d'); let vtDrag = null;
const vidOn = () => S.mode === 'auto' && !!S.video && !S.video.srcObject && !LIVE.view3d && isFinite(S.video.duration) && S.video.duration > 0;
function vRange(v) {
  if (AU.el === v) return [AU.in, AU.out];
  const d = isFinite(v.duration) ? v.duration : 0;
  if (v._in == null) { v._in = 0; v._out = d; }
  return [Math.max(0, Math.min(v._in, d)), Math.max(0, Math.min(v._out || d, d))];
}
function setVRange(v, a, b) {
  const d = v.duration || 0;
  a = Math.max(0, Math.min(a, d - 0.2)); b = Math.max(a + 0.2, Math.min(b, d));
  if (AU.el === v) { AU.in = a; AU.out = b; updateSelectionInfo(); } else { v._in = a; v._out = b; }
  // playback stays inside the part
  if (v.currentTime < a - 0.01 || v.currentTime > b) jumpVideo(v, a);
}
function jumpVideo(v, t) {
  v.currentTime = t;
  if (AU.el === v) { AU.hi = 0; while (AU.hi < AU.hits.length && AU.hits[AU.hi].t < t) AU.hi++; if (AU.ended && S.endless.on) { AU.ended = false; if (S.running) AU.el.play().catch(() => {}); } }
}
// a video (not a live input, not its own music) goes round its part: back to the in point at the out point
function videoTick() {
  const v = S.video; if (!v || v.srcObject || S.mode !== 'auto' || !S.endless.on || OFF.on || AU.el === v || !(v.duration > 0)) return;
  const [a, b] = vRange(v);
  if (v.currentTime >= b - 0.03 || v.ended) {
    if (S.vOnce) { S.vOnce = false; recStopSoon(600); }
    v.currentTime = a; if (S.running && !S.cut) v.play().catch(() => {});
  }
}
// thumbnails along the timeline (made once per video, from a second copy so the playing one isn't disturbed)
const VTH = new WeakMap();
async function vThumbs(v) {
  const T = { cv: document.createElement('canvas'), n: 20, done: 0 }; VTH.set(v, T);
  const h = 60, w = Math.max(8, Math.round(h * srcW(v) / srcH(v))); T.w = w; T.cv.width = w * T.n; T.cv.height = h;
  const tv = document.createElement('video'); tv.muted = true; tv.preload = 'auto'; tv.src = v.currentSrc || v.src;
  try { await new Promise((ok, bad) => { tv.onloadeddata = ok; tv.onerror = bad; }); } catch (e) { return; }
  const x = T.cv.getContext('2d');
  for (let i = 0; i < T.n; i++) { await seekTo(tv, (i + 0.5) / T.n * tv.duration); drawCover(x, tv, i * w, 0, w, h); T.done = i + 1; }
  tv.removeAttribute('src'); tv.load();
}
const fmtT = s => `${Math.floor(s / 60)}:${(s % 60).toFixed(1).padStart(4, '0')}`;
function drawVT() {
  const on = vidOn(), box = $('vtl');
  if (box.hidden === on) { box.hidden = !on; fitStage(); }
  if (!on) return;
  const v = S.video, dpr = window.devicePixelRatio || 1, w = VT.clientWidth, h = VT.clientHeight;
  if (!w || !h) return;
  if (VT.width !== Math.round(w * dpr) || VT.height !== Math.round(h * dpr)) { VT.width = Math.round(w * dpr); VT.height = Math.round(h * dpr); }
  VX.setTransform(dpr, 0, 0, dpr, 0, 0); VX.clearRect(0, 0, w, h);
  const css = getComputedStyle(document.body), acc = css.getPropertyValue('--accent').trim();
  const d = v.duration, [a, b] = vRange(v), x = t => t / d * w;
  // the film strip: tiles at the video's own shape, each showing the moment under it
  let T = VTH.get(v); if (!T) vThumbs(v);
  T = VTH.get(v);
  if (T && T.done) {
    const tw = h * srcW(v) / srcH(v), n = Math.ceil(w / tw);
    for (let k = 0; k < n; k++) { const i = Math.min(T.n - 1, Math.floor((k + 0.5) * tw / w * T.n)); if (i < T.done) VX.drawImage(T.cv, i * T.w, 0, T.w, T.cv.height, k * tw, 0, tw, h); }
  }
  VX.fillStyle = 'rgba(0,0,0,.62)'; VX.fillRect(0, 0, x(a), h); VX.fillRect(x(b), 0, w - x(b), h);
  VX.strokeStyle = acc; VX.lineWidth = 1; VX.strokeRect(x(a) + 0.5, 0.5, Math.max(1, x(b) - x(a) - 1), h - 1);
  for (const hx of [x(a), x(b)]) { VX.fillStyle = acc; VX.fillRect(hx - 1, 0, 2, h); VX.fillRect(hx - 5, 0, 10, 7); VX.fillRect(hx - 5, h - 7, 10, 7); }
  const t = AU.el === v ? aTime() : v.currentTime;
  VX.fillStyle = '#fff'; VX.fillRect(x(t) - 0.75, 0, 1.5, h);
  const txt = `${fmtT(a)}–${fmtT(b)} · ${(b - a).toFixed(1)} s`;
  if ($('vtlsel').textContent !== txt) $('vtlsel').textContent = txt;
}
const vtTime = e => { const r = VT.getBoundingClientRect(); return clamp01((e.clientX - r.left) / r.width) * S.video.duration; };
VT.addEventListener('pointerdown', e => {
  if (!vidOn() || OFF.on) return;
  const v = S.video, r = VT.getBoundingClientRect(), px = e.clientX - r.left, [a, b] = vRange(v), xa = a / v.duration * r.width, xb = b / v.duration * r.width;
  vtDrag = Math.abs(px - xa) < 9 ? { k: 'in' } : Math.abs(px - xb) < 9 ? { k: 'out' } : { k: 'new', from: vtTime(e), moved: false };
  VT.setPointerCapture(e.pointerId);
});
VT.addEventListener('pointermove', e => {
  if (!vidOn()) return;
  const v = S.video;
  if (!vtDrag) { const r = VT.getBoundingClientRect(), px = e.clientX - r.left, [a, b] = vRange(v); VT.style.cursor = Math.abs(px - a / v.duration * r.width) < 9 || Math.abs(px - b / v.duration * r.width) < 9 ? 'ew-resize' : 'crosshair'; return; }
  const t = vtTime(e), [a, b] = vRange(v);
  if (vtDrag.k === 'in') setVRange(v, Math.min(t, b - 0.2), b);
  else if (vtDrag.k === 'out') setVRange(v, a, Math.max(t, a + 0.2));
  else if (Math.abs(t - vtDrag.from) > 0.15) { vtDrag.moved = true; setVRange(v, Math.min(t, vtDrag.from), Math.max(t, vtDrag.from)); }
});
VT.addEventListener('pointerup', e => {
  if (vtDrag && vtDrag.k === 'new' && !vtDrag.moved && vidOn()) { const [a, b] = vRange(S.video); jumpVideo(S.video, Math.min(b - 0.05, Math.max(a, vtTime(e)))); }
  vtDrag = null;
});
VT.addEventListener('dblclick', () => { if (vidOn()) setVRange(S.video, 0, S.video.duration); });
// ── song timeline: waveform, hits, in/out handles, playhead ──
const TL = $('tl'), TX = TL.getContext('2d'); let tlDrag = null;
function drawTimeline() {
  if (!AU.rms || $('timeline').hidden) return;
  const dpr = window.devicePixelRatio || 1, w = TL.clientWidth, h = TL.clientHeight;
  if (TL.width !== Math.round(w * dpr) || TL.height !== Math.round(h * dpr)) { TL.width = Math.round(w * dpr); TL.height = Math.round(h * dpr); }
  TX.setTransform(dpr, 0, 0, dpr, 0, 0); TX.clearRect(0, 0, w, h);
  const css = getComputedStyle(document.body), acc = css.getPropertyValue('--accent').trim(), acc2 = css.getPropertyValue('--accent2').trim(), dim = css.getPropertyValue('--dim').trim();
  const x = t => t / AU.dur * w, xi = x(AU.in), xo = x(AU.out), mid = h / 2;
  // loudness envelope
  const n = AU.rms.length;
  for (let px = 0; px < w; px++) {
    const f0 = Math.floor(px / w * n), f1 = Math.max(f0 + 1, Math.floor((px + 1) / w * n)); let m = 0;
    for (let f = f0; f < f1; f++) m = Math.max(m, AU.rms[f]);
    const inSel = px >= xi && px <= xo;
    TX.fillStyle = inSel ? acc : dim; TX.globalAlpha = inSel ? 0.75 : 0.35;
    const bh = Math.max(1, m * (h - 18) / 2); TX.fillRect(px, mid - bh, 1, bh * 2);
  }
  TX.globalAlpha = 1;
  // hits
  TX.fillStyle = acc2;
  for (const hh of AU.hits) { if (hh.t < AU.in || hh.t > AU.out) continue; const hx = x(hh.t); TX.fillRect(hx, h - 6 - hh.s * 10, 1.5, hh.s * 10 + 2); }
  // the song's sections
  if (AU.sections && $('sections').checked) {
    const SC = { intro: 'rgba(255,255,255,.3)', outro: 'rgba(255,255,255,.3)', verse: acc, build: acc2, drop: acc, break: acc2 };
    TX.font = `600 8px 'IBM Plex Mono', monospace`;
    for (const sc of AU.sections) {
      const a = x(sc.t0), b = x(sc.t1);
      TX.globalAlpha = sc.kind === 'drop' ? 1 : sc.kind === 'build' ? 0.85 : 0.45; TX.fillStyle = SC[sc.kind]; TX.fillRect(a + 1, 0, Math.max(1, b - a - 2), sc.kind === 'drop' ? 4 : 3);
      TX.globalAlpha = 1; TX.fillStyle = 'rgba(255,255,255,.22)'; TX.fillRect(a, 0, 1, h);
      if (b - a > 30) { TX.fillStyle = 'rgba(255,255,255,.6)'; TX.fillText(sc.kind, a + 3, 12); }
    }
  }
  // outside the selection is dimmed
  TX.fillStyle = 'rgba(0,0,0,.55)'; TX.fillRect(0, 0, xi, h); TX.fillRect(xo, 0, w - xo, h);
  // handles
  for (const hx of [xi, xo]) { TX.fillStyle = acc; TX.fillRect(hx - 1, 0, 2, h); TX.fillRect(hx - 5, 0, 10, 8); TX.fillRect(hx - 5, h - 8, 10, 8); }
  // playhead
  if (AU.el) { const px = x(aTime()); TX.fillStyle = '#fff'; TX.fillRect(px - 0.5, 0, 1.5, h); }
}
const tlTime = e => { const r = TL.getBoundingClientRect(); return clamp01((e.clientX - r.left) / r.width) * AU.dur; };
TL.addEventListener('pointerdown', e => {
  if (!AU.dur) return;
  const r = TL.getBoundingClientRect(), px = e.clientX - r.left, xi = AU.in / AU.dur * r.width, xo = AU.out / AU.dur * r.width;
  tlDrag = Math.abs(px - xi) < 9 ? 'in' : Math.abs(px - xo) < 9 ? 'out' : { from: tlTime(e) };
  TL.setPointerCapture(e.pointerId);
});
TL.addEventListener('pointermove', e => {
  if (!tlDrag) { if (AU.dur) { const r = TL.getBoundingClientRect(), px = e.clientX - r.left; TL.style.cursor = Math.abs(px - AU.in / AU.dur * r.width) < 9 || Math.abs(px - AU.out / AU.dur * r.width) < 9 ? 'ew-resize' : 'crosshair'; } return; }
  const t = tlTime(e);
  if (tlDrag === 'in') AU.in = Math.min(t, AU.out - 0.5);
  else if (tlDrag === 'out') AU.out = Math.max(t, AU.in + 0.5);
  else if (Math.abs(t - tlDrag.from) > 0.3) { AU.in = Math.min(t, tlDrag.from); AU.out = Math.max(t, tlDrag.from); }
  updateSelectionInfo();
});
TL.addEventListener('pointerup', () => { tlDrag = null; });
TL.addEventListener('dblclick', () => { AU.in = 0; AU.out = AU.dur; updateSelectionInfo(); });

// ═════════════════════════════════════════════════════════════
//  Auto-paint
// ═════════════════════════════════════════════════════════════
let loadToken = 0;
// src: a URL, or an already-loaded <img> / <video>. opts.list = playlist [{ el, name }], opts.video = the <video>
async function startAuto(src, name, fileName = '', opts = {}) {
  // open and read the new picture first: if it can't be used, whatever is running now carries on untouched
  const token = ++loadToken;
  $('hint').textContent = `Opening ${name}…`;
  if (!LOADING.on) loading('picture', 400);
  let img, data, ww, wh;
  try {
    if (src instanceof HTMLVideoElement) { img = src; if (!src.srcObject) { img.pause(); img.loop = false; await seekTo(img, AU.el === img ? AU.in : Math.min(Math.max(0.05, vRange(img)[0]), Math.max(0, (img.duration || 0) - 0.05))); } }
    else img = src instanceof HTMLImageElement ? src : await loadImg(src);
    const iw = srcW(img), ih = srcH(img), L = Math.max(iw, ih), work = workRes();
    if (!L) throw new Error('it has no size');
    ww = Math.max(8, Math.round(iw * work / L)); wh = Math.max(8, Math.round(ih * work / L));
    const c = document.createElement('canvas'); c.width = ww; c.height = wh;
    const cx = c.getContext('2d'); drawCover(cx, img, 0, 0, ww, wh);
    data = cx.getImageData(0, 0, ww, wh).data;      // (throws for a picture from a site that doesn't allow it)
  } catch (err) {
    if (token !== loadToken) return;
    loading(false);
    const heic = /\.hei[cf]$/i.test(fileName);
    $('hint').textContent = heic ? `This browser can't open HEIC photos. Export it as JPG / PNG first (or use Safari).`
      : typeof src === 'string' && /^https?:/.test(src) ? `That picture's website doesn't allow it to be used here. Save it first, then drop the file.`
      : `Couldn't open ${name}${err && err.message ? ` (${err.message})` : ''}. Try a JPG, PNG or WebP.`;
    return;
  }
  if (token !== loadToken) return;              // a newer picture was dropped while this one was loading
  stopAll(); applyReelLen(); newRun();
  S.list = opts.list || [{ el: img, name }]; S.li = opts.first || 0; S.fromSlots = !!opts.slots; S.video = opts.video || null;
  if (VS.el && VS.el !== S.video) { keepOff(); S.vsound = 'off'; } vsoundShow(); S.holdT = 0; S.wantNext = false;
  S.startArgs = [src, name, fileName, opts];
  S.mode = 'auto'; S.name = name; S.orig = img; S.done = false; S.lines = []; S.items = []; S.drawn = []; S.bits = 0; S.count = 0; S.sim = null; S.recent = [];
  S.queue = []; S.acc = 0; S.workerDone = false; const pk = !liveRun() || (!zoomWanted() && !S.video); S.line = pk ? lineSpec() : null; S.order = pk ? $('order').value : 'free'; S.picN = 0;     // (an order / one line: a still picture, or a playlist without zoom) S.lineSeed = 1 + Math.floor(Math.random() * 1e6); if (S.line) S.line.seed = S.lineSeed;
  S.pen = !!S.line && S.line.kind === 'pen'; S.fr = null; S.penCut = false; S.penEnd = 0; S.penEnds = {}; S.hit = null; S.tipGlow = null; S.accWant = null; S.held = false; S.until = null; S.wCount = 0; S.hurry = 1; S.wr = null; S.loud = 0; S.loudLo = S.loudHi = null; S.penLen = 0; S.fmt = $('export').value; S.codeBytes = 0; S.landing = []; S.big = null; S.debt = 0; S.brush = null;
  S.endless = newEndless();
  S.total = shapesWanted();
  // a video's own soundtrack only starts once the video does (after the first frame has emerged)
  const vidSound = S.video && AU.el === S.video;
  S.plan = musicMode() === 'hits' && !vidSound ? hitPlan(S.total) : null;
  S.k = outLong() / Math.max(ww, wh); S.ww = ww; S.wh = wh;
  S.out = document.createElement('canvas'); S.out.width = Math.round(ww * S.k); S.out.height = Math.round(wh * S.k);
  S.outX = S.out.getContext('2d');
  S.gen++; S.running = true; S.t0 = clock(); S.pausedTotal = 0; S.pausedAt = 0;
  // abstract: the painter chases a warped, more saturated version of the picture and wanders a little on its own
  S.absSeed = Math.random() * 6.28;
  if (abstractOn()) data = abstractWarp(data, ww, wh, 0, 0);
  if (monoRun()) greyData(data);
  if (moodOn()) data = moodShift(data);
  S.target = data.slice();
  // the canvas starts in the painter's background colour (the picture's average, or the nearest palette colour) right
  // away, so the very first frame is already what a loop comes back to
  const pal = palette();
  S.bgHex = SHP.hex(pal ? nearest(meanOf(data), pal) : meanOf(data)); S.loopBg = S.bgHex; S.bgSet = false;
  paintBg(S.outX); snapMaybe(0);
  if (S.line && S.line.kind === 'circles') { frStart(data, ww, wh); S.waitAudio = audioActive() && !vidSound; S.waitSince = clock(); setButtons(); return; }
  worker.postMessage({ type: 'start', gen: S.gen, w: ww, h: wh, data, shapes: S.total, styles: stylePick.values(), bgStyles: stylePick.bg(), smart: true, abstract: abstractOn(), lines: linesOn(), outline: pieceOn() ? 'last' : outlineMode(), hilite: pieceOn(), rfill: rfillMode(), stylesize: SSZ, seed: 1 + Math.floor(Math.random() * 1e6), size: sizeK(), sizeRand: sizeRand(), palette: pal, under: underOn(), order: S.order, line: S.line });
  const H = audioActive() ? hitsInSel().length : 0;
  $('hint').textContent = `Painting ${S.video ? 'the video ' : S.list.length > 1 ? `a playlist of ${S.list.length} (first: ` : ''}${name}${S.list.length > 1 && !S.video ? ')' : ''} — ${S.total} shapes${audioActive() ? ` to ♪ ${AU.name} (${fmtTime(AU.in)}–${fmtTime(AU.out)}${musicMode() === 'hits' ? `, ${H} hits` : ''})` : ''}.`;
  // the music waits until the painter has a head start, so the first hits have strokes ready to land
  S.waitAudio = audioActive() && !vidSound; S.waitSince = clock();
  setButtons();
}
// under: the picture (or the video, playing) shows under the painting wherever nothing has been painted yet, and the
// strokes cover it as they land. The painting's canvas then starts clear instead of in the background colour (the
// painters still work as if it were the background colour, so in the end everything gets covered).
// charcoal alone: the whole picture is drawn in greys (paper and all), not just its strokes
const monoRun = () => { const v = stylePick.values(), b = stylePick.bg(); return v.length > 0 && v.every(s => s === 'charcoal') && b.every(s => s === 'charcoal'); };
function greyData(d) { for (let i = 0; i < d.length; i += 4) d[i] = d[i + 1] = d[i + 2] = d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; return d; }
const underOn = () => $('under').checked && S.mode === 'auto' && !(S.endless && S.endless.travel);
function paintBg(x) {
  if (x === S.outX && RLF.on) reliefStop();
  if (underOn()) { x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, x.canvas.width, x.canvas.height); x.restore(); }
  else {
    SHP.lib(x).bg(S.bgHex);
    if (stylePick.values().includes('thread')) {      // embroidery: the cloth it is stitched on, a woven weave a little darker and lighter than the ground
      x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 0.16; x.fillStyle = patternFor('canvas', '#000'); x.fillRect(0, 0, x.canvas.width, x.canvas.height);
      x.globalAlpha = 0.07; x.fillStyle = patternFor('canvas', '#fff'); x.translate(2, 2); x.fillRect(-2, -2, x.canvas.width, x.canvas.height); x.restore();
    }
  }
}
// the source under the painting, in the painting's rectangle b (the current playlist picture / the live frame)
function drawUnder(b) {
  const src = S.list && S.list.length ? itemAt(0) : S.orig; if (!src || !srcW(src)) return;
  X.save(); X.beginPath(); X.rect(b.x, b.y, b.w, b.h); X.clip(); drawCover(X, src, b.x, b.y, b.w, b.h); X.restore();
}
// how much of the canvas is painted (0..1), looked at twice a second on a small copy
const UC = { cv: null, x: null, t: 0, v: 0 };
function underCover() {
  const now = clock(); if (Math.abs(now - UC.t) < 500 || !S.out) return UC.v;
  if (!UC.cv) { UC.cv = document.createElement('canvas'); UC.cv.width = UC.cv.height = 48; UC.x = UC.cv.getContext('2d', { willReadFrequently: true }); }
  UC.x.clearRect(0, 0, 48, 48); UC.x.drawImage(S.out, 0, 0, 48, 48);
  const d = UC.x.getImageData(0, 0, 48, 48).data; let a = 0; for (let i = 3; i < d.length; i += 4) a += d[i];
  UC.t = now; return (UC.v = a / (255 * 48 * 48));
}
// switched while painting: the background colour is lifted off the canvas (or put back under it)
function underSwitch() {
  if (S.mode !== 'auto' || !S.out) return;
  const x = S.outX, w = S.out.width, h = S.out.height;
  x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1;
  if (underOn()) {
    const id = x.getImageData(0, 0, w, h), d = id.data, [r, g, b] = hexRgb(S.bgHex);
    for (let i = 0; i < d.length; i += 4) if (Math.abs(d[i] - r) < 3 && Math.abs(d[i + 1] - g) < 3 && Math.abs(d[i + 2] - b) < 3) d[i + 3] = 0;
    x.putImageData(id, 0, 0);
  } else { x.globalCompositeOperation = 'destination-over'; x.fillStyle = S.bgHex; x.fillRect(0, 0, w, h); }
  x.restore(); S.big = null;
}
$('under').onchange = () => { underSwitch(); worker.postMessage({ type: 'under', on: underOn() }); helpersPost({ type: 'under', on: underOn() }); $('hint').textContent = $('under').checked ? 'Under: the picture / video shows under the painting until the strokes cover it.' : 'Under off: the painting starts on its background colour.'; };
// a change of style while painting: the painters take it from their next stroke. A still picture's painter works far
// ahead of what is shown, so it starts again from the canvas as it is now (with the shapes still arriving on it) and
// the strokes it had queued in the old style are dropped.
const styleOkFor = m => !S.styleOk || !m.s || !m.s.st || S.styleOk.has(m.s.st);     // (strokes still in flight from before a style change are dropped)
function restyle() {
  const styles = stylePick.values(), bg = stylePick.bg();
  worker.postMessage({ type: 'styles', styles, bg }); helpersPost({ type: 'styles', styles, bg });
  // strokes the painters made before the change (in the old styles) are dropped: the new style shows at once
  { const ok = S.styleOk = new Set([...styles, ...bg, 'flat']); if (S.queue && S.queue.length) S.queue = S.queue.filter(m => !m.s || !m.s.st || ok.has(m.s.st)); }
  if (S.mode !== 'auto' || S.endless.on || S.workerDone || !S.target || !S.out || OFF.on) return;
  const w = S.ww, h = S.wh, c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d', { willReadFrequently: true }), k = w / S.out.width;
  x.drawImage(S.out, 0, 0, w, h); x.setTransform(k, 0, 0, k, 0, 0); for (const L of S.landing) drawQ(x, L.q); x.setTransform(1, 0, 0, 1, 0, 0);
  const current = x.getImageData(0, 0, w, h).data;
  S.gen++; S.queue = []; S.workerDone = false;
  S.hurry = 1; S.until = null; S.wCount = S.count; worker.postMessage({ type: 'start', gen: S.gen, w, h, data: S.target.slice(), current, count0: S.count, shapes: S.total, styles, bgStyles: bg, smart: true, abstract: abstractOn(), lines: linesOn(), outline: pieceOn() ? 'last' : outlineMode(), hilite: pieceOn(), rfill: rfillMode(), stylesize: SSZ, seed: 1 + Math.floor(Math.random() * 1e6), size: sizeK() * (S.sizeMul || 1), sizeRand: sizeRand(), palette: palette(), under: underOn(), order: S.order, line: S.line });
}
// the worker computes as fast as it can; shapes are queued and revealed at a watchable pace (or on the music)
worker.onmessage = (e) => {
  const m = e.data;
  if (S.mix && S.mode === 'replay' && m.gen === S.gen) {
    wake();   // replay + live: only strokes made for the canvas as it is now
    if (m.type === 'shape' && m.L !== undefined) S.queue.push(m);
    else if (m.type === 'need') S.mix.busy = false;
    return;
  }
  if (m.gen !== S.gen || S.mode !== 'auto') return;
  wake();
  if (m.type === 'mask') { S.mask = m; S.maskCv = null; return; }
  if (m.type === 'bg') { S.bgHex = S.loopBg = SHP.hex(m.c); if (!S.count) { paintBg(S.outX); S.snaps = []; snapMaybe(0); } S.sim = m.sim; S.bgSet = true; }
  else if (m.type === 'shape' && m.acc) { S.accWant = null; S.wCount = m.count; if (S.running && styleOkFor(m)) S.accN = (S.accN || 0) + 1, reveal(m, { k: 1, max: 130 + 40 * (1 - musicAmt()) }); }   // the beat's stroke: down at once, snapped on in a flash
  else if (m.type === 'accent-none') S.accWant = null;
  else if (m.type === 'shape') { if (S.wr) S.wr.made++; S.wCount = m.count; if ((!S.endless.on || m.L !== undefined) && styleOkFor(m)) S.queue.push(m); }   // once endless, only shapes made for a view
  else if (m.type === 'done') { S.workerDone = true; S.finalSim = m.sim; }
  else if (m.type === 'need') { S.endless.busy = false; S.sim = m.sim; }
  else if (m.type === 'chains') frChains(m.chains);
};
// ── stroke motion: how a shape arrives on the stage before it is committed to the painting ──
//   draw:  brush strokes are drawn along their path, bars are swept out from one end, triangles fan open,
//          ellipses stretch open from a line, soft blobs spread like ink; a glowing tip marks the brush
//   glide: the same, and every shape also travels in from where the previous one was painted
//   pop:   shapes pop into place      off: shapes simply appear (the collage look)
// Only the stage shows the motion: the painting canvas (and the saved code) get the final shape, unchanged.
// one of the ticked motions, at random for every shape ('off' when none is ticked: shapes simply appear)
const motion = () => { const v = motionPick.values(); return v.length ? v[Math.floor(Math.random() * v.length)] : 'off'; };
// highlights: brush-tip points and outline flashes while shapes arrive; off = pure shapes. Colour is the viewer's pick.
const marks = () => $('marks').checked;
const markCol = () => $('markcol').value;
const easeOut = u => 1 - (1 - u) ** 3;
const easeOut2 = u => 1 - (1 - u) ** 2;
const easeInOut = u => (1 - Math.cos(Math.PI * u)) / 2;
const easeBack = u => { const v = u - 1; return 1 + 2.70158 * v * v * v + 1.70158 * v * v; };
const bounce = u => { const n = 7.5625, d = 2.75; if (u < 1 / d) return n * u * u; if (u < 2 / d) return n * (u -= 1.5 / d) * u + 0.75; if (u < 2.5 / d) return n * (u -= 2.25 / d) * u + 0.9375; return n * (u -= 2.625 / d) * u + 0.984375; };
// how much longer than a plain draw each kind of motion takes
const MOTION_TIME = { sketch: 1.45, fall: 1.25, spiral: 1.3, ink: 1.1, shatter: 1.25, pixel: 1.1 };
// first gradient colour of a shape's arguments (for the sketch outline)
const colourOf = (t, a) => a[t === 'T' ? 7 : t === 'S' ? 8 : 6];
// the point a fraction f of the way round a closed polygon
function alongPoly(p, f) {
  const n = p.length / 2, seg = []; let tot = 0;
  for (let i = 0; i < n; i++) { const j = (i + 1) % n, l = Math.hypot(p[j * 2] - p[i * 2], p[j * 2 + 1] - p[i * 2 + 1]); seg.push(l); tot += l; }
  let d = f * tot;
  for (let i = 0; i < n; i++) { if (d <= seg[i] || i === n - 1) { const j = (i + 1) % n, k = seg[i] ? Math.min(1, d / seg[i]) : 0; return [p[i * 2] + (p[j * 2] - p[i * 2]) * k, p[i * 2 + 1] + (p[j * 2 + 1] - p[i * 2 + 1]) * k, tot]; } d -= seg[i]; }
  return [p[0], p[1], tot];
}
const PIX = { cv: null, x: null };   // (pixel motion: the small canvas each shape is drawn into before it is blown up)
// radius around a shape's centre that covers all of it (ink / sketch floods grow to this)
function reachOf(L) {
  if (L.rad) return L.rad;
  const p = SHP.poly({ t: L.q.t, p: L.q.args }); let r = 1;
  for (let i = 0; i < p.length; i += 2) r = Math.max(r, Math.hypot(p[i] - L.c[0], p[i + 1] - L.c[1]));
  return (L.rad = r + 2);
}
function centreOf(q) {
  const a = q.args;
  if (q.t === 'T') return [(a[0] + a[2] + a[4]) / 3, (a[1] + a[3] + a[5]) / 3];
  if (q.t === 'S') return [0.25 * a[0] + 0.5 * a[2] + 0.25 * a[4], 0.25 * a[1] + 0.5 * a[3] + 0.25 * a[5]];
  return [a[0], a[1]];
}
function sizeOf(q) {
  const a = q.args, d = (i, j) => Math.hypot(a[j] - a[i], a[j + 1] - a[i + 1]);
  if (q.t === 'E' || q.t === 'B') return 2 * Math.sqrt(Math.abs(a[2] * a[3]));
  if (q.t === 'R') return Math.max(a[2], a[3]);
  if (q.t === 'T') return Math.max(d(0, 2), d(2, 4), d(4, 0));
  return d(0, 2) + d(2, 4);
}
// which way the brush goes: strokes and bars start at the end nearest the previous stroke, like a hand would
function directionOf(q, c, prev) {
  const a = q.args;
  if (prev && q.t === 'S') return Math.hypot(a[0] - prev[0], a[1] - prev[1]) <= Math.hypot(a[4] - prev[0], a[5] - prev[1]) ? 1 : -1;
  if (prev && q.t === 'R') { const r = a[4] + (a[2] >= a[3] ? 0 : Math.PI / 2); return (prev[0] - c[0]) * Math.cos(r) + (prev[1] - c[1]) * Math.sin(r) < 0 ? 1 : -1; }
  return Math.random() < 0.5 ? 1 : -1;
}
// reveal one shape: its line of code appears now; with `anim` ({delay, k, max}) it is animated onto the stage first
// one line with music: the pen's pace follows the song — faster when it is loud, a surge on every beat, and (hits /
// flow) catching up with how far the song says the painting should be by now, so it lands with the music
// where the one line should be by now with a song: the song's plan, run a little ahead so the last stroke lands before it ends
function penWant() {
  const m0 = musicMode(), t = AU.in + (aTime() - AU.in) / 0.9;
  if (m0 === 'flow') return S.total * audioProgress(Math.min(t, AU.out));
  if (m0 === 'hits' && S.plan) { if (t >= AU.out) return S.total; let w = 0; for (let j = 0; j < S.plan.t.length && S.plan.t[j] <= t; j++) w += S.plan.n[j]; return w; }
  return null;
}
function penMusicK() {
  if (!(S.mode === 'auto' && audioActive() && !AU.ended && !aPaused())) return 1;
  const energy = Math.min(1, 0.6 * AU.bass + 0.4 * AU.mid);
  let k = 0.35 + 2.2 * energy + 2.8 * Math.min(1, AU.beat);
  const want = penWant();
  if (want != null) k *= Math.min(6, Math.max(0.06, Math.exp((want - S.count) / Math.max(12, S.total * 0.02))));     // (ahead of the song: it slows right down; behind: it hurries)
  return Math.min(9, k);          // (never so fast that a burst of strokes lands in one frame)
}
function reveal(m, anim) {
  // every shape picks one of the ticked motions
  let mo = motion();
  if (S.pen && S.mode === 'auto' && mo !== 'off') mo = 'draw';
  else if (LAG.lite && !OFF.on && HEAVY.has(m.s.st) && mo !== 'off') mo = 'draw';     // (heavy strokes on a slow machine: still painted out, just plainly)
  if (!anim || mo === 'off') { anim = null; mo = 'off'; flushLandings(); }
  // endless zoom: the shape was made for the view at zoom m.L; move it onto the canvas as it is now
  const E = S.endless, f = Math.exp(E.Zb - (m.L || 0)), s = f === 1 ? m.s : scaleShape(m.s, f, S.ww / 2, S.wh / 2);
  const q = SHP.quant(s, S.k, E.on ? 'readable' : S.fmt);   // draw exactly what the chosen export format will reproduce
  q.st = s.st; q.brush = BRUSH.name !== 'default' ? BRUSH.name : null;
  if (!RLF.on && RELIEF[q.st] && S.out && reliefOk()) reliefStart();      // (so the very first relief stroke already arrives lit)
  // one line on the beat (see onBeat): the line swells — the strokes the pen draws right after the beat are bolder, the harder the beat the bolder
  if (S.pen && S.hit && clock() - S.hit.t < 300 && q.t === 'S') { const u = (clock() - S.hit.t) / 300; q.args[6] *= 1 + 1.6 * S.hit.s * musicAmt() * (1 - u * u); }
  const now = clock(), c = centreOf(q), prev = S.brush;
  let end = now;
  if (anim) {
    const dir = directionOf(q, c, prev), from = mo === 'glide' && prev ? prev : null;
    // long enough to actually watch: ~0.35 s for small shapes up to ~1.4 s for the big early ones
    let dur = mo === 'pop' ? 220 : Math.max(350, Math.min(1400, 260 + 2.2 * sizeOf(q))) * (anim.k || 1) * (MOTION_TIME[mo] || 1);
    if (from) dur += Math.min(500, Math.hypot(from[0] - c[0], from[1] - c[1]) * 0.6);
    dur = Math.min(dur, anim.max || 1200);
    const fp = fillParts(q); if (fp) dur = Math.min(6000, dur * Math.min(6, 0.6 + 0.3 * fp.length));   // a filled patch: the hand needs a while for all its passes (each row is drawn, never flashed in)
    const L = { q, c, dir, from, mode: mo, t0: now + (anim.delay || 0), dur, seed: Math.random() * 100 };
    if (S.pen && S.mode === 'auto') {      // one pen: each stroke starts when the last has finished, travelling at an even pace (the speed slider sets how fast)
      // the pen moves at one steady speed; it is set so that an average stroke takes as long as a stroke does at this speed in the normal painter
      // ((12 + 0.06 × strokes so far) × speed strokes a second), so the speed slider means the same here, short strokes or long
      const a = q.args, len = Math.hypot(a[4] - a[0], a[5] - a[1]) * 1.15 + 1;
      S.penLen = S.penLen ? S.penLen * 0.95 + len * 0.05 : len;
      const target = 1000 / ((12 + 0.06 * S.count) * Math.min(speedFactor(), 400)), v = Math.max(0.02, S.penLen / target) * penMusicK();
      const pid = m.pen || 0; S.penEnds = S.penEnds || {};      // (a branch keeps its own time, beside the main line)
      L.t0 = Math.max(now, pid ? S.penEnds[pid] || 0 : S.penEnd || 0); L.dur = dur = Math.max(1, len / v);
      if (pid) S.penEnds[pid] = L.t0 + dur; else S.penEnd = L.t0 + dur;
    }
    if (fp && mo !== 'off') {            // a filled patch: its passes land one after another, each drawn once it is down (no redrawing them all every frame)
      const lens = fp.map(p => Math.hypot(p.args[4] - p.args[0], p.args[5] - p.args[1]) + 1), tot = lens.reduce((a, b) => a + b, 0); let t = L.t0;
      fp.forEach((p, i) => { const d = Math.max(S.pen ? 0.5 : 16, L.dur * lens[i] / tot), P = { q: p, c: centreOf(p), dir: 1, from: null, mode: 'draw', t0: t, dur: d, seed: L.seed, more: i < fp.length - 1 }; S.landing.push(P); t += d; });
      end = t; if (S.pen && S.mode === 'auto') S.penEnd = t;
    } else { S.landing.push(L); end = L.t0 + dur; }
  } else commitShape(q);
  // the brush ends where a stroke ends, otherwise in the middle of the shape
  S.brush = q.t === 'S' ? (anim && S.landing[S.landing.length - 1].dir < 0 ? [q.args[0], q.args[1]] : [q.args[4], q.args[5]]) : c;
  const line = S.fmt === 'readable' || E.on ? SHP.code(s, S.k) : SHP.lineOf(q);
  S.lines.push(line); S.count++; S.sim = m.sim;
  if (E.on) { if (S.lines.length > 400) S.lines.splice(0, S.lines.length - 300); }   // endless: only the recent code is kept
  else {
    if (q.codes) { S.items.push(q); S.bits += q.bits; } else S.codeBytes += line.length + 2;
    S.drawn.push({ t: q.t, args: q.args, st: q.st, brush: q.brush });
  }
  S.recent.push({ s, t: end, beat: AU.beats, mode: mo });   // the outline flashes once the shape has arrived
  sndStroke(q, anim ? anim.delay || 0 : 0);
  if (S.recent.length > 40) S.recent.shift();
}
function commitLandings(now) { while (S.landing && S.landing.length && now >= S.landing[0].t0 + S.landing[0].dur) { const L = S.landing.shift(); if (L.more) putShape(L.q); else commitShape(L.q); } }
const pendingN = () => S.landing.reduce((n, L) => n + (L.more ? 0 : 1), 0);     // (shapes still arriving: a filled patch's passes count once)
function flushLandings() { commitLandings(Infinity); }
// the first u (0..1) of a quadratic brush stroke, coloured with the whole stroke's gradient (same maths as the runtime's S)
// glow (on the beat): the tip of each brush being drawn lights up in its own shape and colour — the brush's own marks
// around its tip, cut out with a soft round falloff the size of the brush, brightened, with a soft bloom — and fades
// as the brush moves on (a flash on the beat, gone within about half a second)
const TIPG = { cv: null, x: null, sm: null, sx: null };
function tipGlowNow() { const G = S.tipGlow; if (!G) return 0; const d = clock() - G.t; return d < 0 || d > 700 ? 0 : G.s * Math.exp(-d / 210); }
function glowTip(L, u, tip, g) {
  const q = L.q, t = q.t; if (L.mode !== 'draw' && L.mode !== 'sketch') return;      // (only the motions that are drawn along have a tip)
  const m = X.getTransform(), k = Math.hypot(m.a, m.b), w = t === 'S' ? q.args[6] : Math.max(4, sizeOf(q) * 0.25);
  const r = Math.max(5, Math.min(120, w * k * 0.7 + 3)), D = Math.ceil(2 * r) + 2;
  if (!TIPG.cv) { TIPG.cv = document.createElement('canvas'); TIPG.x = TIPG.cv.getContext('2d'); TIPG.sm = document.createElement('canvas'); TIPG.sx = TIPG.sm.getContext('2d'); }
  const c = TIPG.cv, x = TIPG.x; if (c.width < D || c.height < D) { c.width = c.height = Math.max(D, 64); }
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'source-over'; x.globalAlpha = 1; x.clearRect(0, 0, c.width, c.height);
  const ox = tip[0] - r, oy = tip[1] - r;
  x.setTransform(m.a, m.b, m.c, m.d, m.e - ox, m.f - oy);
  // the brush itself, drawn as far as it has got (the same marks as on the stage)
  const pos = L.mode === 'sketch' && t === 'S' ? easeInOut(clamp01((u - 0.25) / 0.75)) : t === 'S' ? (S.pen && S.mode === 'auto' ? u : easeInOut(u)) : u;
  if (t === 'S' || fillParts(q)) { if (pos > 0) strokeAt(x, q, pos, L.dir); } else drawQ(x, q);
  // only its tip: a soft round falloff the size of the brush
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalCompositeOperation = 'destination-in';
  const R = x.createRadialGradient(r, r, 0, r, r, r); R.addColorStop(0, 'rgba(0,0,0,1)'); R.addColorStop(0.3, 'rgba(0,0,0,0.8)'); R.addColorStop(0.7, 'rgba(0,0,0,0.25)'); R.addColorStop(1, 'rgba(0,0,0,0)');
  x.fillStyle = R; x.fillRect(0, 0, D, D);
  x.globalCompositeOperation = 'source-over';      // (added onto itself below: its own colour, brighter, its texture kept)
  X.save(); X.setTransform(1, 0, 0, 1, 0, 0); X.globalCompositeOperation = 'lighter';
  // bloom: the tip, small and back up again (soft in every browser), a little wider than the brush
  const sd = Math.max(4, Math.round(D / 6)); if (TIPG.sm.width < sd) TIPG.sm.width = TIPG.sm.height = Math.max(sd, 32);
  const sx = TIPG.sx; sx.setTransform(1, 0, 0, 1, 0, 0); sx.clearRect(0, 0, TIPG.sm.width, TIPG.sm.height); sx.imageSmoothingEnabled = true; sx.drawImage(c, 0, 0, D, D, 1, 1, sd - 2, sd - 2);     // (a clear pixel all round: no square edge when it is blown up)
  X.imageSmoothingEnabled = true; X.globalAlpha = Math.min(1, 0.4 * g);
  X.drawImage(TIPG.sm, 0, 0, sd, sd, ox - r * 0.25, oy - r * 0.25, D + r * 0.5, D + r * 0.5);
  X.globalCompositeOperation = 'screen'; X.globalAlpha = Math.min(1, g); X.drawImage(c, 0, 0, D, D, ox, oy, D, D); TIPG.last = [ox, oy, D];     // (screen: brighter in its own colour, never burnt white)
  X.restore();
}
// one shape part-way through its motion (X is already in painting coordinates); brush tips are collected in stage pixels
function drawMotion(L, u, lib, tips) {
  // brushes (strokes, bars, triangles) travel at an even, visible pace; ellipses and blobs open with a gentle ease-out
  const a = L.q.args, t = L.q.t, [cx, cy] = L.c, e = S.pen && S.mode === 'auto' ? u : t === 'S' || t === 'R' || t === 'T' ? easeInOut(u) : easeOut2(u);
  const tip = (x, y) => { const p = X.getTransform().transformPoint(new DOMPoint(x, y)); tips.push([p.x, p.y, u]); };
  X.save();
  if (L.from) { const k = 1 - easeInOut(Math.min(1, u * 1.15)); X.translate((L.from[0] - cx) * k, (L.from[1] - cy) * k); }
  if (L.mode === 'pop') {
    const sc = 0.25 + 0.75 * easeBack(u);
    X.translate(cx, cy); X.scale(sc, sc); X.translate(-cx, -cy); drawQ(X, L.q);
  } else if (L.mode === 'shatter') {    // flies in as spinning shards from all around and snaps together
    const n = 7, R = reachOf(L), e2 = easeOut(u), far = (1 - e2) * (R * 1.6 + 60);
    for (let k = 0; k < n; k++) {
      const a0 = L.seed + k / n * 6.2832, a1 = L.seed + (k + 1) / n * 6.2832, am = (a0 + a1) / 2, spin = (1 - e2) * 1.4 * (k % 2 ? 1 : -1) * (0.5 + ((k * 7 + L.seed) % 1));
      X.save();
      X.translate(Math.cos(am) * far, Math.sin(am) * far);
      X.translate(cx, cy); X.rotate(spin); X.translate(-cx, -cy);
      X.beginPath(); X.moveTo(cx, cy); X.lineTo(cx + Math.cos(a0) * R * 3, cy + Math.sin(a0) * R * 3); X.lineTo(cx + Math.cos(a1) * R * 3, cy + Math.sin(a1) * R * 3); X.closePath(); X.clip();
      X.globalAlpha *= Math.min(1, u * 4); drawQ(X, L.q);
      X.restore();
    }
  } else if (L.mode === 'pixel') {      // resolves from big pixel blocks to sharp, like a picture loading
    const blk = Math.round(32 * Math.pow(1 - u, 1.7));
    if (blk <= 1) drawQ(X, L.q);
    else {
      const r = reachOf(L), w = 2 * r, cells = Math.max(1, Math.ceil(w / blk));
      if (!PIX.cv) { PIX.cv = document.createElement('canvas'); PIX.x = PIX.cv.getContext('2d'); }
      if (PIX.cv.width < cells) PIX.cv.width = PIX.cv.height = Math.max(cells, 64);
      const px = PIX.x; px.setTransform(1, 0, 0, 1, 0, 0); px.clearRect(0, 0, cells, cells);
      px.setTransform(cells / w, 0, 0, cells / w, (r - cx) * cells / w, (r - cy) * cells / w); drawQ(px, L.q);
      X.imageSmoothingEnabled = false; X.drawImage(PIX.cv, 0, 0, cells, cells, cx - r, cy - r, w, w); X.imageSmoothingEnabled = true;
    }
  } else if (L.mode === 'fall') {       // drops in from above, tumbling slightly, and bounces to rest
    const d = (1 - bounce(u)) * (S.out.height * 0.45 + reachOf(L));
    X.translate(0, -d); X.translate(cx, cy); X.rotate((1 - u) * 0.6 * L.dir); X.translate(-cx, -cy); drawQ(X, L.q);
  } else if (L.mode === 'spiral') {     // swirls in around the middle of the canvas, growing as it arrives
    const ox = S.out.width / 2, oy = S.out.height / 2, e2 = easeOut(u), th = (1 - e2) * 2.4 * L.dir, sc = 1 + (1 - e2) * 0.9, s2 = 0.3 + 0.7 * e2;
    X.translate(ox, oy); X.rotate(th); X.scale(sc, sc); X.translate(-ox, -oy);
    X.translate(cx, cy); X.scale(s2, s2); X.translate(-cx, -cy); drawQ(X, L.q);
  } else if (L.mode === 'ink') {        // bleeds outward from its centre with a wobbly, organic edge
    const R = reachOf(L) * 1.55 * easeOut2(u), n = 36;
    X.beginPath();
    for (let i = 0; i <= n; i++) {
      const an = i / n * 2 * Math.PI, w = 1 + 0.22 * Math.sin(3 * an + L.seed) + 0.12 * Math.sin(7 * an + L.seed * 2.3);
      X[i ? 'lineTo' : 'moveTo'](cx + Math.cos(an) * R * w, cy + Math.sin(an) * R * w);
    }
    X.closePath(); X.clip(); drawQ(X, L.q);
  } else if (L.mode === 'sketch' && t === 'S') {     // a line: a pencil traces its path first, then the brush paints along it
    const pu = clamp01(u / 0.4), bu = clamp01((u - 0.25) / 0.75), m = X.getTransform(), px = 1 / Math.hypot(m.a, m.b);
    if (bu < 1) {
      const P = quadPts(a, Math.max(0.02, pu), L.dir, 28), j = Math.max(0.6, a[6] * 0.04);
      X.save(); X.globalAlpha = 0.8 * (1 - bu * bu); X.strokeStyle = colourOf(t, a); X.lineWidth = 1.5 * px; X.lineCap = X.lineJoin = 'round'; X.beginPath();
      P.forEach((p, i) => X[i ? 'lineTo' : 'moveTo'](p[0] + j * Math.sin(i * 1.7 + L.seed), p[1] + j * Math.cos(i * 2.3 + L.seed)));
      X.stroke(); X.restore();
      if (bu === 0) { const e2 = P[P.length - 1]; tip(e2[0], e2[1]); }
    }
    if (bu > 0) { const p = strokeAt(X, L.q, easeInOut(bu), L.dir); tip(p[0], p[1]); }
  } else if (L.mode === 'sketch') {     // a pencil outline goes round first, then the colour floods in from the middle
    const poly = SHP.poly({ t, p: a }), pu = clamp01(u / 0.55), fu = clamp01((u - 0.4) / 0.6);
    if (fu > 0) { X.save(); X.beginPath(); X.arc(cx, cy, reachOf(L) * easeOut2(fu), 0, 7); X.clip(); drawQ(X, L.q); X.restore(); }
    const [tx, ty, per] = alongPoly(poly, pu), m = X.getTransform();
    X.save();
    X.globalAlpha = 0.9 * (1 - fu * fu); X.strokeStyle = colourOf(t, a); X.lineWidth = 1.6 / Math.hypot(m.a, m.b); X.lineJoin = 'round';
    X.setLineDash([per * pu, per + 1]); X.beginPath();
    for (let i = 0; i < poly.length; i += 2) X[i ? 'lineTo' : 'moveTo'](poly[i], poly[i + 1]);
    X.closePath(); X.stroke(); X.restore();
    if (pu < 1) tip(tx, ty);
  } else if (t === 'S' || fillParts(L.q)) {
    const p = strokeAt(X, L.q, t === 'S' ? e : u, L.dir); tip(p[0], p[1]);
  } else if (t === 'R') {      // swept out along its long side, from one end
    const [x, y, w, h, r] = a, long = w >= h, len = long ? w : h, cut = len * e, s0 = L.dir > 0 ? -len / 2 : len / 2 - cut;
    X.save(); X.translate(x, y); X.rotate(r); X.beginPath();
    if (long) X.rect(s0, -h / 2 - 1, cut, h + 2); else X.rect(-w / 2 - 1, s0, w + 2, cut);
    const edge = L.dir > 0 ? -len / 2 + cut : len / 2 - cut; tip(long ? edge : 0, long ? 0 : edge);
    X.restore(); X.clip(); drawQ(X, L.q);
  } else if (t === 'T') {      // fans open around its first corner
    const [x0, y0, x1, y1, x2, y2] = a, s = easeOut2(Math.min(1, u * 1.6));
    const qx = x1 + (x2 - x1) * e, qy = y1 + (y2 - y1) * e, px = x0 + (qx - x0) * s, py = y0 + (qy - y0) * s;
    X.beginPath(); X.moveTo(x0, y0); X.lineTo(x0 + (x1 - x0) * s, y0 + (y1 - y0) * s); X.lineTo(px, py); X.closePath();
    tip(px, py); X.clip(); drawQ(X, L.q);
  } else {                     // ellipses stretch open from a line and twist into place; blobs spread like ink
    const [x, y, ra, rb, r] = a, major = ra >= rb, twist = (1 - e) * 0.6 * L.dir;
    const sMaj = t === 'E' ? Math.max(0.02, easeOut2(Math.min(1, u * 1.4))) : Math.max(0.02, 0.08 + 0.92 * e + 0.07 * Math.sin(Math.PI * u));
    const sMin = t === 'E' ? 0.06 + 0.94 * e ** 1.6 : sMaj;
    X.translate(x, y); X.rotate(r + twist); X.scale(major ? sMaj : sMin, major ? sMin : sMaj); X.rotate(-r); X.translate(-x, -y);
    drawQ(X, L.q);
    if (L.from && u < 0.8) tip(x, y);
  }
  X.restore();
}
// (shapes are always painted in the order the painter made them: each one was chosen for the canvas as it was
// then, so painting a big early shape late would cover the detail laid since)
// speed slider 1..100: 40 = normal (×1), up to about ×90 just before max (max = no waiting at all)
function speedFactor() { const v = +$('speed').value; return v >= 100 ? Infinity : Math.pow(2, (v - 40) / (v > 40 ? 59 / Math.log2(100) : 12)); }   // 40 = ×1, 99 = ×100
function showSpeed() { const f = speedFactor(); $('speedval').textContent = f === Infinity ? 'max' : '×' + (f < 1 ? f.toFixed(2) : f < 10 ? f.toFixed(1) : Math.round(f)); }
// enough strokes queued for the song to start (the music waits for the painter's head start)
const painterReady = () => (S.fr ? !!S.fr.ready : false) || S.queue.length >= Math.min(S.total, S.plan ? Math.max(40, 3 * Math.max(...S.plan.n.slice(0, 3))) : 40) || S.workerDone;
// a run that ends by itself (not a zoom, a video, a playlist or ∞, which paint on and on)
const liveRun = () => S.mode === 'auto' && (zoomWanted() || !!S.video || S.list.length > 1 || infinite());
const finiteRun = () => S.mode === 'replay' || (S.mode === 'auto' && !S.endless.on && !liveRun());
// timed to the reel's length (no song): the painting is finished at 88% of it (72% when it loops back afterwards)
const fitOn = () => reelLen() > 0 && !audioActive() && !AU.live && finiteRun();
const fitBuild = () => reelLen() * (loopOn() ? 0.72 : 0.88);
const fitCurve = u => u <= 0 ? 0 : u >= 1 ? 1 : (Math.exp(1.6 * u) - 1) / (Math.exp(1.6) - 1);   // a slow start for the big washes
function pace(dt) {
  commitLandings(clock());
  if (S.mode !== 'auto' || !S.running || S.dz > 0) return;     // (looping back to empty: nothing more lands)
  if (S.waitAudio) {
    if (!painterReady() && clock() - S.waitSince < 4000) return;
    S.waitAudio = false; playAudioFromStart(); if (S.fr && S.fr.ready) S.fr.t0 = clock();
  }
  if (S.fr && !S.fr.done) { frStep(); if (!S.fr.done) return; }      // (once the circles are done: the usual end of a run)
  if (S.endless.on) return paceEndless(dt);
  if (!OFF.on) musicHold(Math.max(0, demand(dt)));
  musicSize(dt);
  // (a video's own soundtrack hasn't started yet while its first frame emerges: plain speed pacing until then)
  // (live sound has no plan or energy curve: speed pacing with bursts on its beats)
  const m0 = (S.video && AU.el === S.video) ? 'none' : AU.live && !audioActive() ? 'free' : musicMode(), mode = m0 === 'hits' && !S.plan ? 'flow' : m0, playing = (audioActive() && !AU.ended && !aPaused()) || !!AU.live;
  if (S.pen && (mode === 'flow' || mode === 'hits') && AU.ended && !S.endless.on && !S.penCut) {
    // one line with a song: the painting ends with the song — the strokes still being drawn finish, the rest are left out
    S.penCut = true; S.queue = []; worker.postMessage({ type: 'stop' }); helpersPost({ type: 'stop' }); S.workerDone = true; S.total = S.count;
  }
  if (S.pen && (mode === 'flow' || mode === 'hits') && audioActive() && !AU.ended) {
    // one line with music: one stroke at a time, as the pen gets there; its pace follows the song (penMusicK)
    // (the hits the song has passed are used up here, so nothing else ever drops their strokes in at once)
    if (S.plan) { const t = aTime(); while (S.plan.i < S.plan.t.length && S.plan.t[S.plan.i] <= t) S.plan.i++; } S.debt = 0;
    for (let n = 0; n < 12 && S.queue.length && (S.penEnd || 0) - clock() < 120; n++) reveal(S.queue.shift(), { k: 1 });     // (at most a dozen a frame: a catch-up is spread out, never a jump)
  } else if (fitOn()) {
    // timed to the length: the strokes follow a curve that lands the last one on time
    const target = Math.floor(S.total * fitCurve(elapsed() / fitBuild())), rate = S.total / fitBuild();
    const anim = { k: Math.min(2, Math.max(0.1, Math.pow(rate / (12 + 0.06 * S.count), -0.6))), max: 900 };
    while (S.count < target && S.queue.length) reveal(S.queue.shift(), anim);
  } else if (mode === 'hits' && S.plan && !AU.ended) {
    // painted by the song: each hit that playback passes drops its share of strokes onto the canvas
    const P = S.plan, t = aTime();
    while (AU.moving && P.i < P.t.length && P.t[P.i] <= t) { S.debt += P.n[P.i]; P.i++; }
    // (before the song's first hit: the first washes go on gently, so the canvas never sits empty waiting for it)
    if (AU.moving && P.i === 0 && P.t.length && t < P.t[0] - 0.25) { S.acc = Math.min((S.acc || 0) + dt / 1000 * 5, 3); while (S.acc >= 1 && S.queue.length) { reveal(S.queue.shift(), { k: 1.3 }); S.acc--; } }
    // a hit's strokes start in a quick flurry and finish before the next beat
    const burst = S.debt, beatMs = AU.bpm ? 60000 / AU.bpm : 500, stagger = Math.min(12, 120 / burst); let j = 0;
    while (S.debt > 0 && S.queue.length) { const delay = j++ * stagger; reveal(S.queue.shift(), { delay, max: Math.max(120, beatMs * 0.85 - delay) }); S.debt--; }
  } else if (mode === 'flow' && !AU.ended) {
    const target = Math.floor(S.total * audioProgress(aTime()));
    while (S.count < target && S.queue.length) reveal(S.queue.shift(), { max: 650 });
  } else {
    const f = AU.ended ? Infinity : speedFactor();
    if (f === Infinity) { while (S.queue.length) reveal(S.queue.shift()); }
    else if (S.pen) { while (S.queue.length && (S.penEnd || 0) - clock() < 160) reveal(S.queue.shift(), { k: 1 }); }
    else {
      const drive = mode === 'free' && playing ? 0.25 + 2.4 * (0.6 * AU.bass + 0.4 * AU.mid) : 1;
      S.acc = Math.min(S.acc + dt / 1000 * f * drive * (12 + 0.06 * S.count), 2000);
      const anim = { k: Math.min(2, Math.max(0.1, Math.pow(f, -0.6))) };   // slower speed, slower brush
      while (S.acc >= 1 && S.queue.length) { reveal(S.queue.shift(), anim); S.acc -= 1; }
      if (!S.queue.length) S.acc = Math.min(S.acc, 1);
    }
  }
  // live modes (zoom, video, playlist): once enough of the first picture has emerged, things start moving and the
  // painting never ends
  // (a video with under on plays straight away: the strokes build up over it while it runs)
  const liveWanted = zoomWanted() || S.video || S.list.length > 1, from = S.video && underOn() ? 0 : liveWanted ? zoomStart() : 1;
  // (also when the first frame / picture is finished early — e.g. a live input that started on a black frame)
  const firstDone = liveWanted && S.workerDone && !S.queue.length && !S.landing.length;
  if ((liveWanted || infinite()) && (S.count >= Math.ceil(from * S.total) || firstDone)) { beginEndless(); return; }
  if (S.workerDone && !S.queue.length && !S.landing.length && !S.done) {
    S.done = true; S.sim = S.finalSim; reliefFlush(true);
    if ((!audioActive() || AU.ended) && !holdOpen()) { S.running = false; S.pausedAt = clock(); }
    setButtons();
    $('hint').textContent = `Done: ${S.count} shapes, ${S.sim.toFixed(1)}% match, ${(codeSize() / 1024).toFixed(1)} KB as ${S.fmt} code. ⬇ code saves it.`;
    if (S.rec && !audioActive() && !holdOpen()) recStopSoon(1500);
  }
}
// ═════════════════════════════════════════════════════════════
//  Endless zoom
//  The target becomes the picture nested inside itself (a copy 1/ZK the size sits in its centre, and so on),
//  so zooming in by ZK lands back on the full picture: the view can move in or out forever. The painted canvas
//  moves with the camera (re-baked every ~5% of zoom) and the painter keeps repainting the view it is shown:
//  big strokes where things are new or blown up, fine ones to sharpen.
// ═════════════════════════════════════════════════════════════
const ZK = 3, ZLAM = Math.log(ZK);
const newEndless = () => ({ on: false, Z: 0, Zb: 0, vel: 0, travel: 0, innerA: 0, busy: false, cv: null, cx: null, spare: null });
S.endless = newEndless();
const zoomWanted = () => +$('zoom').value !== 0;
const zoomStart = () => +$('zoomstart').value / 100;
// slider -100..100 -> log-zoom per second (in > 0, out < 0): up to ×1.35 per second, fine control near the middle
function zoomRate() { const v = +$('zoom').value / 100; return Math.sign(v) * v * v * 0.3; }
function showZoom() {
  const v = +$('zoom').value; $('zoomval').textContent = v === 0 ? 'off' : v > 0 ? `in ${v}` : `out ${-v}`;
  $('zoomstartval').textContent = `${$('zoomstart').value}%`;
}
// scale a shape's positions and sizes about (cx, cy); angles, colours and feather are unchanged
function scaleArgs(t, a, f, cx, cy) {
  const b = a.slice(), P = i => { b[i] = cx + (a[i] - cx) * f; b[i + 1] = cy + (a[i + 1] - cy) * f; };
  if (t === 'T') { P(0); P(2); P(4); }
  else if (t === 'S') { P(0); P(2); P(4); b[6] = a[6] * f; }
  else { P(0); b[2] = a[2] * f; b[3] = a[3] * f; }
  return b;
}
const scaleShape = (s, f, cx, cy) => ({ ...s, p: scaleArgs(s.t, s.p, f, cx, cy) });
function beginEndless() {
  const E = S.endless; if (E.on) return;
  E.on = true; E.busy = false;
  S.queue = []; S.plan = null; S.debt = 0; S.done = false; S.running = true; S.holdT = 0; S.wantNext = false; S.cutN = null;
  // a video starts playing now: with its own soundtrack as the music it starts from the chosen part of the song
  if (S.video) {
    if (!S.video.srcObject) S.video.playbackRate = +$('vspeed').value;
    if (AU.el === S.video) { S.waitAudio = false; playAudioFromStart(); }
    else {
      // recording a video with no sound at all: its part plays once and the recording ends with it (then it goes
      // round again); otherwise it goes round its part for ever (videoTick)
      const v = S.video; S.vOnce = !!S.rec && !AU.el && !v.srcObject;
      v.muted = S.vsound !== 'keep'; v.loop = false; v.onended = () => videoTick();
      if (!v.srcObject) { const [a, b] = vRange(v); if (v.currentTime < a || v.currentTime >= b - 0.05) v.currentTime = a; }
      if (!OFF.on) v.play().catch(() => {});     // (offline, the render moves the video on frame by frame)
    }
  }
  $('hint').textContent = S.video ? (LIVE.view3d ? 'Painting the 3D object live: drag on the picture to turn it, scroll / pinch to zoom.' : S.video.srcObject ? 'Painting the live input: the painter keeps repainting what it shows.' : 'Painting the video live: the painter keeps repainting the frame as it plays. Pause or ⟲ restart to stop.')
    : S.list.length > 1 && !zoomWanted() && $('slotmode').value === 'bars' ? `Playlist: a new picture every ${cutBars()} bar${cutBars() > 1 ? 's' : ''}, on the first beat${AU.grid ? '' : ' (120 BPM: no song)'}.`
    : S.fromSlots && !zoomWanted() ? ($('slotmode').value === 'cycle' ? `Slots: each picture holds for ${$('hold').value} s, then the next is painted over it.` : 'Slots: play 1 – 6 (click, key or drop) to paint that picture over this one.')
    : S.list.length > 1 && !zoomWanted() ? `Playlist: each picture holds for ${$('hold').value} s, then the next is painted over it.`
    : infinite() && !zoomWanted() ? '∞ Infinite: the picture is complete; the painter keeps painting over it.'
    : 'Endless zoom: the painter keeps repainting the view as it moves. Pause or ⟲ restart to stop.';
  setButtons();
}
// on the bars: true when the song (or live sound, or a steady 120 BPM) has crossed into the next block of n bars
const cutBars = () => [1, 2, 4, 8, 16][+$('cutbars').value] || 4;
function barCut() {
  const per = cutBars() * 4;
  const n = audioActive() && AU.grid && S.songOn && !aPaused() ? Math.floor(((aTime() - AU.grid.t0) / AU.grid.p) / per)
    : AU.live ? Math.floor(AU.beats / per) : Math.floor(elapsed() * 2 / per);
  if (S.cutN == null || n < S.cutN) { S.cutN = Math.max(0, n); return false; }       // (the first change: at the next block's first beat)
  if (n > S.cutN) { S.cutN = n; return true; }
  return false;
}
// the playlist steps on (without zoom): the painter paints the next picture over the current one
function advancePlaylist() {
  const prev = S.orig; startCut();
  S.li = (S.li + 1) % S.list.length; S.orig = S.list[S.li].el; S.holdT = 0; S.wantNext = false; S.picN = (S.picN || 0) + 1;
  if (S.fromSlots) { if (S.video === prev) S.video = null; slotVideo(prev, S.orig); }
  renderSlots();
  $('hint').textContent = `Playlist ${S.li + 1}/${S.list.length}: ${S.list[S.li].name}`;
}
// which picture sits at nesting level n: a playlist cycles through the levels (so zooming in flies from one
// picture into the next), a video is at every level, a single picture is nested in itself
function itemAt(n) { const L = S.list, N = L.length; return N > 1 ? L[(((S.li + n) % N) + N) % N].el : L[0].el; }
// soft edges: the picture cropped to the canvas shape with a wide feathered border (a rounded, superellipse fade
// over its outer ~40%), so each nested copy bleeds into the next instead of sitting in a hard rectangle.
// Cached per picture; a video's is refreshed with its frames.
const softCache = new WeakMap();
let softMask = null;
function softOf(el) {
  const vid = el instanceof HTMLVideoElement, hit = softCache.get(el);
  if (hit && (!vid || clock() - hit.t < 60)) return hit.cv;
  if (!softMask) {
    softMask = document.createElement('canvas'); softMask.width = softMask.height = 256;
    const mx = softMask.getContext('2d'), id = mx.createImageData(256, 256);
    for (let j = 0; j < 256; j++) for (let i = 0; i < 256; i++) {
      const u = Math.abs((i + 0.5) / 128 - 1), v = Math.abs((j + 0.5) / 128 - 1), r = Math.pow(u ** 4 + v ** 4, 0.25), t = clamp01((1 - r) / 0.42);
      id.data[(j * 256 + i) * 4 + 3] = Math.round(255 * t * t * (3 - 2 * t));
    }
    mx.putImageData(id, 0, 0);
  }
  const k = (vid ? 512 : 1024) / Math.max(S.out.width, S.out.height), w = Math.round(S.out.width * k), h = Math.round(S.out.height * k);
  const cv = hit ? hit.cv : document.createElement('canvas');
  if (cv.width !== w || cv.height !== h) { cv.width = w; cv.height = h; }
  const x = cv.getContext('2d');
  x.globalCompositeOperation = 'source-over'; x.clearRect(0, 0, w, h); drawCover(x, el, 0, 0, w, h);
  x.globalCompositeOperation = 'destination-in'; x.drawImage(softMask, 0, 0, w, h); x.globalCompositeOperation = 'source-over';
  softCache.set(el, { cv, t: clock() });
  return cv;
}
// what the painter aims at right now. Before the camera has moved: the current picture / video frame.
// Zooming: the pictures at every visible nesting level, biggest first. With soft edges each level is feathered and
// the next bigger one shows through its border; right after the zoom starts the sharp picture is still laid on top
// and fades away, so nothing jumps.
function targetInto(x, w, h) {
  const E = S.endless, soft = $('softedge').checked;
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.imageSmoothingQuality = 'high';
  x.fillStyle = S.bgHex; x.fillRect(0, 0, w, h);
  if (!E.travel) { drawCover(x, itemAt(0), 0, 0, w, h); return; }
  const n0 = Math.floor(E.Z / ZLAM);
  for (let n = soft ? n0 - 1 : n0; n < n0 + 12; n++) {
    const s = Math.exp(E.Z - n * ZLAM); if (s * Math.max(w, h) < 1.5) break;
    const a = n >= 1 ? E.innerA : 1; if (a <= 0) continue;     // inner copies fade in once the camera starts moving
    const el = itemAt(n), r = [(w - w * s) / 2, (h - h * s) / 2, w * s, h * s];
    x.globalAlpha = a;
    if (soft) x.drawImage(softOf(el), ...r); else drawCover(x, el, ...r);
    if (soft && n <= 0 && E.innerA < 1) { x.globalAlpha = 1 - E.innerA; drawCover(x, el, ...r); }
  }
  x.globalAlpha = 1;
}
// abstract mode: the target is the picture pushed around by a slow, smooth warp (and a little more saturated);
// while the camera moves the warp keeps flowing and swells with the bass
function abstractWarp(d, w, h, t, pump) {
  const out = new Uint8ClampedArray(d.length), A = (0.045 + 0.06 * pump) * Math.max(w, h), f1 = 2 * Math.PI / w * 1.3, f2 = 2 * Math.PI / h * 1.7, ph = S.absSeed || 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const dx = A * (Math.sin(y * f2 + t * 0.7 + ph) + 0.6 * Math.sin((x + y) * f1 * 0.7 - t * 0.5 + ph * 2));
    const dy = A * (Math.sin(x * f1 + t * 0.6 + ph * 3) + 0.6 * Math.sin((x - y) * f2 * 0.8 + t * 0.4 + 2.1));
    const sx = Math.min(w - 1, Math.max(0, Math.round(x + dx))), sy = Math.min(h - 1, Math.max(0, Math.round(y + dy))), i = (sy * w + sx) * 4, o = (y * w + x) * 4;
    const m = (d[i] + d[i + 1] + d[i + 2]) / 3;
    out[o] = m + (d[i] - m) * 1.3; out[o + 1] = m + (d[i + 1] - m) * 1.3; out[o + 2] = m + (d[i + 2] - m) * 1.3; out[o + 3] = 255;
  }
  return out;
}
const abstractOn = () => $('abstract').checked;
// hq detail: the painting's canvas is 2000 px on its long side instead of 1000 (finer strokes everywhere)
const hqOn = () => +$('detail').value >= 1024;
const workRes = () => +$('detail').value;
const outLong = () => hqOn() ? 2000 : 1000;
const fillMode = () => $('fillmode').value;
// (which of the ticked styles the fill changes: only the ones with a tool size of their own)
const fillNote = () => { if ($('fillmode').value === 'off') return ''; const v = stylePick.values().filter(st => TOOL[st]); return v.length ? ` For: ${v.join(', ')}.` : ' None of the ticked styles has a tool size of its own (flat, geo, the 3D materials… are drawn as one shape), so this changes nothing for them.'; };
{ let v = store('cp-fill'); if (v === 'zigzag' && !store('cp-fill2')) v = 'off'; store('cp-fill2', '1'); if (['zigzag', 'cross', 'off'].includes(v)) $('fillmode').value = v; }     // (one stroke is the default now: an old stored zigzag default is moved over once)
const linesOn = () => $('lines').checked;
{ const v = store('cp-lines'); if (v === '0') $('lines').checked = false; }
$('lines').onchange = () => {
  store('cp-lines', linesOn() ? '1' : '0'); worker.postMessage({ type: 'lines', on: linesOn() }); helpersPost({ type: 'lines', on: linesOn() });
  $('hint').textContent = linesOn() ? 'Lines: the styles draw with strokes from now on.' : 'Lines off: the styles use their own mix of strokes and shapes again.';
};
// send the painter the view as it is now: target + what is painted (the canvas under the camera, plus the
// shapes still arriving, as they will end up)
function sendFrame() {
  const E = S.endless, w = S.ww, h = S.wh, path = (S.line || S.order !== 'free') && !S.video && !zoomWanted() ? { order: S.order, line: S.line, pic: S.picN || 0, total: S.total } : null, n = path ? 1 : poolSize(), idle = [];     // (a path: one painter only, so the sweep / the line stay one)
  if (!E.busy) idle.push(0);
  for (let i = 1; i < n; i++) if (!helper(i - 1).busy) idle.push(i);
  if (!idle.length) return;
  if (!E.cv) { E.cv = document.createElement('canvas'); E.cx = E.cv.getContext('2d', { willReadFrequently: true }); }
  if (E.cv.width !== w || E.cv.height !== h) { E.cv.width = w; E.cv.height = h; }
  const x = E.cx;
  targetInto(x, w, h);
  let target = x.getImageData(0, 0, w, h).data;
  if (S.video && !E.travel) cutCheck(target, w, h);
  if (abstractOn()) target = abstractWarp(target, w, h, clock() / 1000 * 0.3, musicOn() ? AU.bass : 0);   // slow flow, so strokes can follow it
  if (monoRun()) greyData(target);
  const k = w / S.out.width, v = Math.exp(E.Z - E.Zb), tf = s => x.setTransform(k * s, 0, 0, k * s, w / 2 - k * s * S.out.width / 2, h / 2 - k * s * S.out.height / 2);
  x.setTransform(1, 0, 0, 1, 0, 0); x.fillStyle = S.bgHex; x.fillRect(0, 0, w, h);
  if (v < 1) { tf(1); x.drawImage(S.out, 0, 0); }
  tf(v); x.drawImage(S.out, 0, 0);
  for (const it of S.landing) drawQ(x, it.q);
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1;
  const current = x.getImageData(0, 0, w, h).data;
  // every idle painter gets the frame and its own band of rows (copies first: the buffers are handed over)
  const batch = S.cut ? 96 : speedFactor() > 8 ? 48 : 24, jobs = idle.map((i, j) => ({ i, t: j === idle.length - 1 ? target : target.slice(), c: j === idle.length - 1 ? current : current.slice() }));
  for (const { i, t, c } of jobs) {
    const msg = { type: 'frame', gen: S.gen, target: t, current: c, n: batch, L: E.Z, abstract: abstractOn(), outline: outlineMode(), rfill: rfillMode(), fresh: S.cut ? S.cut.got / S.cut.need : null, video: !!S.video, path, size: sizeK(), sizeRand: sizeRand(), under: underOn(), band: n > 1 ? [Math.floor(i * h / n), Math.floor((i + 1) * h / n)] : null };
    if (i === 0) { E.busy = true; worker.postMessage(msg, [t.buffer, c.buffer]); continue; }
    const hp = helper(i - 1);
    if (hp.gen !== S.gen) { hp.gen = S.gen; hp.w.postMessage({ type: 'start', gen: S.gen, w, h, data: t.slice(), shapes: 0, styles: stylePick.values(), bgStyles: stylePick.bg(), smart: true, abstract: abstractOn(), lines: linesOn(), outline: pieceOn() ? 'last' : outlineMode(), hilite: pieceOn(), rfill: rfillMode(), stylesize: SSZ, seed: 1 + Math.floor(Math.random() * 1e6), size: sizeK(), sizeRand: sizeRand(), palette: palette(), under: underOn() }); }
    hp.busy = true; hp.w.postMessage(msg, [t.buffer, c.buffer]);
  }
}
// ── cuts, pre-drawn: when the picture cuts to a new scene (a video's frames jump, or the playlist moves on), the new scene
// is painted before it is shown — the stage keeps the last frame meanwhile (and a video waits), then the painted scene
// appears at once. In an offline render no time passes while it is painted.
const cutsPre = () => $('cuts').value === 'pre' && S.mode === 'auto' && S.endless.on && !S.endless.travel;
function cutCheck(d, w, h) {
  const G = 12, sig = new Float32Array(G * G), n = new Float32Array(G * G);
  for (let y = 0; y < h; y += 2) for (let x = 0; x < w; x += 2) { const i = (y * w + x) * 4, k = Math.floor(y * G / h) * G + Math.floor(x * G / w); sig[k] += d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; n[k]++; }
  for (let k = 0; k < sig.length; k++) sig[k] /= n[k] || 1;
  const prev = S.cutSig; S.cutSig = sig;
  if (!prev || S.cut || !cutsPre()) return;
  let e = 0; for (let k = 0; k < sig.length; k++) e += Math.abs(sig[k] - prev[k]);
  e /= sig.length; if (e < 0.5) return;                       // (the same frame again)
  // a cut: a jump much bigger than the video's usual movement from frame to frame (so fast footage doesn't count),
  // and not straight after the last one
  const avg = S.cutAvg == null ? 0 : S.cutAvg, vt = S.video ? S.video.currentTime : 0;
  if (e > 30 && e > avg * 4 && !(S.cutAt != null && Math.abs(vt - S.cutAt) < 0.6)) { S.cutAt = vt; startCut(d); }
  else S.cutAvg = avg * 0.85 + e * 0.15;
}
function startCut(d) {
  if (S.cut || !cutsPre()) return;
  const f = document.createElement('canvas'); f.width = S.out.width; f.height = S.out.height; f.getContext('2d').drawImage(S.out, 0, 0);
  S.freeze = f; S.big = null;
  // a new scene starts on a fresh sheet in its own main colour (the old one doesn't show through thin strokes)
  if (!d) { const c = document.createElement('canvas'); c.width = c.height = 32; drawCover(c.getContext('2d'), itemAt(0), 0, 0, 32, 32); d = c.getContext('2d').getImageData(0, 0, 32, 32).data; }
  const pal = palette(), mean = meanOf(d); S.bgHex = SHP.hex(pal ? nearest(mean, pal) : mean);
  paintBg(S.outX);
  S.cut = { need: Math.round(Math.min(4000, Math.max(400, (S.total || 1000) * (OFF.on ? 1.5 : 0.8)))), got: 0, t: performance.now(), vid: null };
  const v = S.video; if (v && !OFF.on && AU.el !== v) { v.pause(); S.cut.vid = v; }      // (even one about to play again: it waits)
  // recording live: the pre-draw is left out of the recording (the song waits with it), so the video cuts straight
  // from the old scene to the new one already painted, with no pause
  if (S.rec && !OFF.on) {
    if (AU.el && !AU.el.paused && AU.el !== v) { AU.el.pause(); S.cut.song = AU.el; }
    if (S.rec.mp4) MP4REC.hold(true); else if (S.rec.pause && S.rec.state === 'recording') { S.rec.pause(); S.cut.mr = S.rec; }
  }
  flushLandings();
}
function endCut() {
  const c = S.cut; if (!c) return;
  S.cut = null; S.freeze = null; S.big = null; reliefFlush(true);
  if (c.vid && S.running && !OFF.on) c.vid.play().catch(() => {});
  if (c.song && S.running) c.song.play().catch(() => {});
  if (!OFF.on) { if (S.rec && S.rec.mp4) MP4REC.hold(false); if (c.mr && c.mr.state === 'paused') c.mr.resume(); }
}
// while a cut is being painted: every stroke lands at once; done after its share of strokes (live: or after 6 s)
function cutStep() {
  const c = S.cut;
  while (S.queue.length && c.got < c.need) { reveal(S.queue.shift()); c.got++; }
  if (c.got >= c.need || (!OFF.on && performance.now() - c.t > 6000)) endCut();
  else if (S.queue.length < 96 * poolSize()) sendFrame();
}
// bake the camera into the canvas (so it never drifts far from 1:1), moving shapes that are still arriving with it
function bake() {
  const E = S.endless, v = Math.exp(E.Z - E.Zb), W = S.out.width, H = S.out.height, cx = W / 2, cy = H / 2;
  if (!E.spare || E.spare.width !== W || E.spare.height !== H) { E.spare = document.createElement('canvas'); E.spare.width = W; E.spare.height = H; }
  const nc = E.spare, x = nc.getContext('2d');
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.imageSmoothingQuality = 'high'; x.clearRect(0, 0, W, H);
  if (v < 1) x.drawImage(S.out, 0, 0);     // zooming out: the old edge stays under the newly exposed ring until it is painted
  x.setTransform(v, 0, 0, v, cx - v * cx, cy - v * cy); x.drawImage(S.out, 0, 0); x.setTransform(1, 0, 0, 1, 0, 0);
  E.spare = S.out; S.out = nc; S.outX = x; S.big = null;
  if (RLF.on && RLF.st) { reliefZoom(RLF.st, v); RLF.st.out = S.out; }
  const sc = p => [cx + (p[0] - cx) * v, cy + (p[1] - cy) * v];
  for (const L of S.landing) { L.q = { ...L.q, args: scaleArgs(L.q.t, L.q.args, v, cx, cy) }; L.c = sc(L.c); if (L.from) L.from = sc(L.from); }
  if (S.brush) S.brush = sc(S.brush);
  E.Zb = E.Z;
}
function cameraStep(dt) {
  const E = S.endless;
  E.vel += (zoomRate() - E.vel) * (1 - Math.exp(-dt / 700));    // eases in when it starts, and on every slider change
  const dZ = E.vel * dt / 1000; E.Z += dZ; E.travel += Math.abs(dZ); E.innerA = clamp01(E.travel / 0.45);
  if (S.list.length > 1 && E.travel) S.orig = itemAt(Math.floor(E.Z / ZLAM));   // the original pane shows the picture filling the view
  if (Math.abs(E.Z - E.Zb) > 0.05) bake();
}
// the brush size follows the song: sections (bolder in the drops, finer in the breaks) and, with music in the paint,
// the loudness right now — loud parts paint with broad brushes, quiet parts with fine ones
function musicSize(dt) {
  const playing = S.mode === 'auto' && ((audioActive() && !AU.ended && !aPaused()) || !!AU.live), amt = playing ? musicAmt() : 0;
  const e = playing ? Math.min(1, 0.6 * AU.bass + 0.4 * AU.mid) : 0;
  S.loud = (S.loud || 0) + (e - (S.loud || 0)) * (1 - Math.exp(-dt / (e > (S.loud || 0) ? 300 : 1600)));     // (the passage, not each kick: the beat has its own stroke)
  let mul = sectOn() ? 0.6 + 0.9 * S.secE - (S.sec && S.sec.kind === 'break' ? 0.1 : 0) : 1;
  // (loud and quiet for this song: measured against its own quietest and loudest so far, so any track gets the full range)
  if (playing) { const L = S.loud, k = 1 - Math.exp(-dt / 20000); S.loudLo = S.loudLo == null ? L : L < S.loudLo ? L : S.loudLo + (L - S.loudLo) * k; S.loudHi = S.loudHi == null ? L : L > S.loudHi ? L : S.loudHi + (L - S.loudHi) * k; }
  const x = playing ? Math.min(1, Math.max(0, (S.loud - S.loudLo) / Math.max(0.15, S.loudHi - S.loudLo))) : 0.5;
  // (when the painter falls behind the song, no bigger than usual: big strokes take it longer to find)
  if (amt > 0) mul *= 1 + (0.45 + 1.15 * x - 1) * amt * (S.debt > 24 && x > 0.5 ? 0.3 : 1);
  mul = Math.min(2.2, Math.max(0.3, mul));
  if (Math.abs(mul - (S.sizeMul || 1)) > 0.07 * mul) { S.sizeMul = mul; const k = sizeK() * mul, rand = sizeRand(); worker.postMessage({ type: 'size', k, rand }); helpersPost({ type: 'size', k, rand }); }
}
function paceEndless(dt) {
  const E = S.endless;
  if (S.cut) { cutStep(); return; }
  cameraStep(dt);
  // a muted video (a separate song is the music) keeps looping on its own
  if (S.video && AU.el !== S.video && S.video.paused && !OFF.on) S.video.play().catch(() => {});
  // playlist without zoom: on the bars (a change on the first beat of every n bars), or hold each picture, then move
  // on (with music: on the next hit, so the change lands on the beat)
  const sm = $('slotmode').value;
  if (S.list.length > 1 && !E.travel && (!S.video || S.fromSlots) && sm === 'bars') { if (barCut()) advancePlaylist(); }
  else if (S.list.length > 1 && !E.travel && (!S.video || S.fromSlots) && (!S.fromSlots || sm === 'cycle')) {
    S.holdT += dt;
    if (S.holdT >= +$('hold').value * 1000) {
      if (musicOn() && AU.hits.length && S.holdT < +$('hold').value * 1000 + 4000) S.wantNext = true; else advancePlaylist();
    }
  }
  if (S.queue.length < 12 * poolSize()) sendFrame();
  const mode = musicMode(), playing = (audioActive() && !AU.ended && !aPaused()) || !!AU.live;
  // live modes keep painting all the time (a moving view or video can't wait for the beat);
  // on the hits, every hit also drops a flurry on top (see onBeat)
  const hitsLive = mode === 'hits' && playing && (AU.hits.length || AU.live);
  if (hitsLive && S.debt >= 1) {
    const burst = S.debt, beatMs = AU.bpm ? 60000 / AU.bpm : 500, stagger = Math.min(12, 120 / Math.max(1, burst)); let j = 0;
    while (S.debt >= 1 && S.queue.length) { const delay = j++ * stagger; reveal(S.queue.shift(), { delay, max: Math.max(120, beatMs * 0.85 - delay) }); S.debt--; }
  }
  const f = speedFactor();
  if (f === Infinity) { while (S.queue.length) reveal(S.queue.shift()); return; }
  const drive = (hitsLive ? 0.6 : mode !== 'hits' && playing ? 0.25 + 2.4 * (0.6 * AU.bass + 0.4 * AU.mid) : 1) * (sectOn() ? 0.5 + S.secE : 1);
  // (under: while the source still shows through, the strokes come slower, so it is covered over time)
  const slow = underOn() && underCover() < 0.97 ? 0.12 : 1;
  S.acc = Math.min(S.acc + dt / 1000 * f * drive * slow * Math.min(150, 12 + 0.06 * S.total) * (OFF.on && hqOn() ? 3 : 1), 180);
  // sections: bolder strokes in the loud parts, finer in the quiet ones
  musicSize(dt);
  const anim = { k: Math.min(2, Math.max(0.1, Math.pow(f, -0.6))) * (S.video ? 0.5 : 1) };   // (quicker strokes, so a video doesn't leave trails)
  while (S.acc >= 1 && S.queue.length) { reveal(S.queue.shift(), anim); S.acc -= 1; }
  if (!S.queue.length) S.acc = Math.min(S.acc, 1);
}
// the painting as it looks now (for ⬇ png while zooming)
function endlessView(scale) {
  flushLandings();
  const E = S.endless, v = Math.exp(E.Z - E.Zb), W = S.out.width, H = S.out.height, cv = document.createElement('canvas');
  cv.width = Math.round(W * scale); cv.height = Math.round(H * scale);
  const x = cv.getContext('2d'); x.imageSmoothingQuality = 'high'; x.scale(scale, scale);
  if (v < 1) x.drawImage(S.out, 0, 0);
  x.translate(W / 2, H / 2); x.scale(v, v); x.translate(-W / 2, -H / 2); x.drawImage(S.out, 0, 0);
  return cv;
}

// ── exported programs ────────────────────────────────────────
function wrapper(body) {
  return `<!doctype html>\n<title>${S.name} — Code Painter by JAS.BLACK</title>\n<style>html,body{margin:0;height:100%;background:#000;display:grid;place-items:center}canvas{max-width:100vw;max-height:100vh}</style>\n<canvas id="c" width="${S.out ? S.out.width : 0}" height="${S.out ? S.out.height : 0}"></canvas>\n<script>\nconst c = document.getElementById('c').getContext('2d');\n${SHP.RUNTIME}\n${body}\n</script>\n`;
}
// the list of draw calls, as code (readable text or packed)
function callList() {
  if (S.fmt === 'readable') return `const P=[\n${S.lines.map(l => '()=>' + l).join(',\n')}];`;
  return `${SHP.DECODER}\nconst P=D('${SHP.pack(S.items)}',[${SHP.MODES[S.fmt]}]).map(([f,a])=>()=>f(...a));`;
}
// self-painting player: strokes appear over DUR ms (slow start, speeding up — or following the song's energy curve,
// or landing on the song's hits: ST = [ms after IN, strokes painted by then, …]); click to replay.
// With music the first click starts playback (browsers block autoplay with sound); it plays IN..OUT seconds of the song.
function playerJS(o) {
  const A = !!o.audio;
  return `const BG='${S.bgHex}',N=P.length,DUR=${Math.round(o.dur)},CV=${o.curve ? '[' + o.curve.map(v => Math.round(v * 1000) / 1000).join(',') + ']' : 'null'},ST=${o.steps ? '[' + o.steps.join(',') + ']' : 'null'}${A ? `,IN=${o.tin.toFixed(3)},OUT=${o.tout.toFixed(3)}` : ''};
${A ? `const AU=new Audio('${o.audio}');` : ''}let i=0,t0=null,raf=0;
function prog(u){if(CV){const x=u*(CV.length-1),k=Math.floor(x),f=x-k;return CV[k]+(CV[Math.min(k+1,CV.length-1)]-CV[k])*f}return(Math.exp(3*u)-1)/(Math.exp(3)-1)}
function target(t){if(ST){let n=0;for(let j=0;j<ST.length&&ST[j]<=t;j+=2)n=ST[j+1];return n}return Math.floor(N*prog(Math.min(1,t/DUR)))}
function tick(ts){if(t0===null)t0=ts;const t=${A ? '(AU.currentTime-IN)*1000' : 'ts-t0'},n=target(t);while(i<n&&i<N)P[i++]();${A ? 'if(AU.ended||AU.currentTime>=OUT){AU.pause();while(i<N)P[i++]();return}raf=requestAnimationFrame(tick)' : 'if(i<N)raf=requestAnimationFrame(tick)'}}
function play(){cancelAnimationFrame(raf);bg(BG);i=0;t0=null;${A ? 'AU.currentTime=IN;AU.play();' : ''}raf=requestAnimationFrame(tick)}
c.canvas.style.cursor='pointer';c.canvas.onclick=play;
${A ? `bg(BG);c.globalAlpha=.9;c.fillStyle='#39ff88';c.font='700 '+Math.round(c.canvas.width/16)+'px monospace';c.textAlign='center';c.fillText('\\u25B6 click to play',c.canvas.width/2,c.canvas.height/2);` : 'play();'}`;
}
// ── saved programs in their styles: when the painting uses any of the drawn styles (or a brush), the program carries
// the studio's own shapes library and style renderers (the part between the ⟦style-runtime⟧ marks) and the strokes
// with their styles, and paints them exactly as the studio does (the relief materials lit with WebGL as well)
const usesStyles = () => S.drawn.some(d => d.brush || d.st === 'graffiti' || RELIEF[d.st] || STYLE_DRAW[d.st]);
async function sourceWith(needle, not) {
  for (const sc of document.scripts) {
    const t = sc.src ? await fetch(sc.src).then(r => r.text()).catch(() => '') : sc.textContent;
    if (t.includes(needle) && !(not && t.includes(not))) return t;
  }
  return '';
}
async function styledProgram(o) {
  const MK = '// ' + '\u27e6style-runtime\u27e7 ';     // (spelled in pieces, so this line isn't taken for the mark itself)
  const shp = await sourceWith('const SHP = (() =>', 'CP_WORKER_SRC'), main = await sourceWith(MK + 'begin');
  const a = main.indexOf(MK + 'begin'), b = main.indexOf(MK + 'end');
  if (!shp || a < 0 || b < a) return null;
  const W = S.out.width, H = S.out.height, ops = JSON.stringify(S.drawn.map(d => ({ t: d.t, args: d.args, st: d.st, brush: d.brush === 'custom' ? null : d.brush })));
  const prelude = `'use strict';
const c = document.getElementById('c').getContext('2d'), W = ${W}, H = ${H}, BGC = '${S.bgHex}', OPS = ${ops};
const $ = id => document.getElementById(id), store = () => null, clamp01 = v => v < 0 ? 0 : v > 1 ? 1 : v, easeInOut = u => (1 - Math.cos(Math.PI * u)) / 2, easeOut2 = u => 1 - (1 - u) ** 2;
const S = { mode: 'auto', endless: { on: false }, pen: false, landing: [], drawn: OPS, out: c.canvas, outX: c, bgHex: BGC, k: 1 }, OFF = { on: false }, clock = () => performance.now();
const fillMode = () => '${fillMode()}', outLong = () => ${outLong()};
let X = null;`;
  const after = `LIGHT.x = ${LIGHT.x}; LIGHT.y = ${LIGHT.y}; SPRAY.cap = '${SPRAY.cap}';
let R = null; const useRelief = OPS.some(q => RELIEF[q.st]) && !!reliefGL();
const B = document.createElement('canvas'); B.width = W; B.height = H; const bx = B.getContext('2d');
function bg() { LIVE = []; for (const x of [c, bx]) { x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.globalCompositeOperation = 'source-over'; x.fillStyle = BGC; x.fillRect(0, 0, W, H); }
  if (useRelief) { R = makeRelief(W, H, 1, Math.max(W, H) / 1000); R.ax.drawImage(c.canvas, 0, 0); } }
function SHOW() { if (R) { if (R.dirty) reliefRender(R, c); } else { c.setTransform(1, 0, 0, 1, 0, 0); c.globalAlpha = 1; c.drawImage(B, 0, 0); } }
const P = OPS.map(q => () => { if (R) reliefAdd(R, q); else drawQ(bx, q); });
// each stroke is painted out over a moment, as in the studio: the strokes landed so far sit on B (or in the relief),
// the ones still arriving are drawn part-way over them every frame
let LIVE = [];
function GO(i, t) {
  const q = OPS[i], a = q.args, fp = fillParts(q);
  let dur = Math.min(1100, 250 + 1.6 * (q.t === 'S' ? Math.hypot(a[4] - a[0], a[5] - a[1]) : Math.max(a[2] || 0, a[3] || 0)));
  if (fp) dur = Math.min(2800, dur * Math.min(2.6, 0.7 + 0.3 * Math.sqrt(fp.length)));
  LIVE.push({ i, q, t0: t, dur });
}
function DONE() { for (const L of LIVE) P[L.i](); LIVE = []; }
function FRAME(t) {
  while (LIVE.length > 40) P[LIVE.shift().i]();
  LIVE = LIVE.filter(L => { L.u = Math.min(1, Math.max(0, (t - L.t0) / L.dur)); if (L.u >= 1) { P[L.i](); return false; } return true; });
  const flat = [];
  if (R) {
    const list = [];
    for (const L of LIVE) {
      if (!RELIEF[L.q.st]) { flat.push(L); continue; }
      const fp = fillParts(L.q);
      if (fp) { const { done, cur, f } = fillUpTo(fp, L.u); for (const p of done) list.push({ q: p }); if (cur) list.push({ q: quadPart(cur, f, 1) }); }
      else list.push({ q: L.q.t === 'S' ? quadPart(L.q, easeInOut(L.u), 1) : L.q });
    }
    if (list.length) reliefRender(reliefScratch(R, list), c); else SHOW();
  } else { SHOW(); flat.push(...LIVE); }
  for (const L of flat) {
    c.save();
    if (L.q.t === 'S' || fillParts(L.q)) strokeAt(c, L.q, easeInOut(L.u), 1);
    else { const P0 = SHP.poly({ t: L.q.t, p: L.q.args }), b = boxOf(P0); c.beginPath(); c.arc(b.cx, b.cy, Math.hypot(b.w, b.h) / 2 * easeOut2(L.u) + 0.5, 0, 7); c.clip(); drawQ(c, L.q); }
    c.restore();
  }
}`;
  let player = o.animate ? playerJS(o.player) : 'bg();for(const f of P)f();SHOW();';
  player = player.replace('while(i<n&&i<N)P[i++]();', 'while(i<n&&i<N)GO(i++,t);FRAME(t);').replace('while(i<N)P[i++]();return', 'DONE();while(i<N)P[i++]();SHOW();return').replace('if(i<N)raf=', 'if(i<N||LIVE.length)raf=').replace(/\bbg\(BG\)/g, 'bg()');
  return `<!doctype html>\n<meta charset="utf-8">\n<title>${S.name} — Code Painter by JAS.BLACK</title>\n<style>html,body{margin:0;height:100%;background:#000;display:grid;place-items:center}canvas{max-width:100vw;max-height:100vh}</style>\n<canvas id="c" width="${W}" height="${H}"></canvas>\n<script>\n${shp}\n<\/script>\n<script>\n${prelude}\n${main.slice(a, b).replace(/<\/script/gi, '<\\/script')}\n${after}\n${player}\n<\/script>\n`;
}
let overhead = {};
function codeSize() {   // size of the static program the ⬇ code button would save
  if (S.mode !== 'auto') return S.codeBytes;
  if (S.fmt === 'readable') return (overhead.readable ??= wrapper(`bg('#000000');\n`).length) + S.codeBytes;
  return (overhead.packed ??= wrapper(`${SHP.DECODER}\nbg('#000000');for(const[f,a]of D('',[${SHP.MODES.packed}]))f(...a);`).length) + SHP.packedLen(S.bits);
}
async function autoProgram(opts = {}) {
  const styled = usesStyles() && !opts.plain;
  if (styled && !opts.animate) { const html = await styledProgram({ animate: false }); if (html) return html; }
  if (!opts.animate) {
    if (S.fmt === 'readable') return wrapper(`bg('${S.bgHex}');\n${S.lines.join(';\n')};`);
    return wrapper(`${SHP.DECODER}\nbg('${S.bgHex}');for(const[f,a]of D('${SHP.pack(S.items)}',[${SHP.MODES[S.fmt]}]))f(...a);`);
  }
  const o = { dur: Math.min(45, Math.max(8, S.count / 40)) * 1000 };
  if (opts.music && AU.file) {
    // same timing as in the studio: strokes land on the selection's hits, or follow its energy curve
    const len = AU.out - AU.in, plan = musicMode() === 'hits' ? hitPlan(S.count) : null;
    o.tin = AU.in; o.tout = AU.out; o.dur = len * FIT * 1000;
    if (plan) { let n = 0; o.steps = []; plan.t.forEach((t, j) => { n += plan.n[j]; if (plan.n[j]) o.steps.push(Math.round((t - AU.in) * 1000), n); }); }
    else o.curve = Array.from({ length: 256 }, (_, j) => audioProgress(AU.in + j / 255 * len * FIT));
    const bytes = new Uint8Array(await AU.file.arrayBuffer()); let bin = '';
    for (let i = 0; i < bytes.length; i += 8192) bin += String.fromCharCode.apply(null, bytes.subarray(i, i + 8192));
    o.audio = `data:${AU.file.type || 'audio/mpeg'};base64,${btoa(bin)}`;
  }
  if (styled) { const html = await styledProgram({ animate: true, player: o }); if (html) return html; }
  return wrapper(`${callList()}\n${playerJS(o)}`);
}
// render the finished picture big (auto: redraw the recorded calls at scale; replay: re-run the piece at scale)
async function renderBig(longSide) {
  if (S.mode === 'auto' && S.endless.on) return endlessView(longSide / Math.max(S.out.width, S.out.height));
  if (S.mode === 'auto' && RLF.on) { const cv = reliefBig(longSide / Math.max(S.out.width, S.out.height)); if (cv) return cv; }
  if (S.mode === 'auto') {
    const k = longSide / Math.max(S.out.width, S.out.height), cv = document.createElement('canvas');
    cv.width = Math.round(S.out.width * k); cv.height = Math.round(S.out.height * k);
    const x = cv.getContext('2d'); x.setTransform(k, 0, 0, k, 0, 0);
    const L = SHP.lib(x); L.bg(S.bgHex);
    for (const d of S.drawn) drawQ(x, d);
    if (SPRAY.wall !== 'none') { x.setTransform(1, 0, 0, 1, 0, 0); wallOver(x, 0, 0, cv.width, cv.height); }
    return cv;
  }
  if (S.mix || S.place) return canvasAsShown(longSide);        // (replay + live strokes, or layers: the canvas as it is — the code alone would leave them out)
  return S.api.render(S.total, longSide / Math.max(S.out.width, S.out.height));
}
// the painting as it is on the stage now (strokes still arriving included, as if landed), at a size
function canvasAsShown(longSide) {
  const k = longSide / Math.max(S.out.width, S.out.height), cv = document.createElement('canvas'); cv.width = Math.round(S.out.width * k); cv.height = Math.round(S.out.height * k);
  const x = cv.getContext('2d'); x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high'; x.drawImage(S.out, 0, 0, cv.width, cv.height);
  x.setTransform(k, 0, 0, k, 0, 0); for (const L of S.landing || []) if (clock() >= L.t0) drawQ(x, L.q);
  return cv;
}
const download = (blob, name) => { tagFile(blob, name).then(b => { const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = name; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 60000); }); };
// ── the settings travel with what you make (like ComfyUI's workflows): every PNG, MP4, SVG and code page saved carries
// the settings it was made with, and dropping one back onto the page brings them back (the picture stays as it is) ──
//   PNG: a tEXt chunk 'code-painter' · MP4: a top-level 'uuid' box at the end (players skip it) · SVG: <metadata> ·
//   HTML: a <script type="application/json" id="code-painter-settings">
const META_UUID = [0x63, 0x6f, 0x64, 0x65, 0x2d, 0x70, 0x61, 0x69, 0x6e, 0x74, 0x65, 0x72, 0x2d, 0x76, 0x31, 0x00];    // "code-painter-v1\0"
function settingsMeta() {
  return { app: 'code-painter', version: APP_VERSION, made: new Date().toISOString(), picture: S.name || null, song: audioActive() ? AU.name : null, settings: presetGet() };
}
const asciiJSON = o => JSON.stringify(o).replace(/[\u007f-￿]/g, c => '\\u' + c.charCodeAt(0).toString(16).padStart(4, '0'));
async function tagFile(blob, name) {
  try {
    const ext = (name.split('.').pop() || '').toLowerCase();
    if (!['png', 'mp4', 'svg', 'html'].includes(ext) || /presets\.json$/.test(name)) return blob;
    const json = asciiJSON(settingsMeta());
    if (ext === 'png') {
      const b = new Uint8Array(await blob.arrayBuffer());
      if (b.length < 33 || b[12] !== 0x49 || b[13] !== 0x48) return blob;          // (not a PNG with IHDR first)
      const body = new TextEncoder().encode('tEXtcode-painter\0' + json), n = body.length - 4, ch = new Uint8Array(body.length + 8), dv = new DataView(ch.buffer);
      dv.setUint32(0, n); ch.set(body, 4); dv.setUint32(4 + body.length, crc32(body));
      return new Blob([b.subarray(0, 33), ch, b.subarray(33)], { type: 'image/png' });
    }
    if (ext === 'mp4') {
      const body = new TextEncoder().encode(json), box = new Uint8Array(24 + body.length), dv = new DataView(box.buffer);
      dv.setUint32(0, box.length); box.set([0x75, 0x75, 0x69, 0x64], 4); box.set(META_UUID, 8); box.set(body, 24);
      return new Blob([blob, box], { type: blob.type || 'video/mp4' });
    }
    const t = await blob.text(), esc = json.replace(/</g, '\\u003c');
    if (ext === 'svg') return new Blob([t.replace(/(<svg\b[^>]*>)/, `$1<metadata id="code-painter">${esc}</metadata>`)], { type: 'image/svg+xml' });
    const tag = `<script type="application/json" id="code-painter-settings">${esc}<\/script>`;
    return new Blob([/<\/body>/.test(t) ? t.replace(/<\/body>(?![\s\S]*<\/body>)/, tag + '</body>') : t + '\n' + tag + '\n'], { type: 'text/html' });
  } catch (e) { return blob; }
}
// the settings a file carries (or null)
async function readMeta(f) {
  try {
    const name = (f.name || '').toLowerCase(), ok = o => o && o.app === 'code-painter' && o.settings ? o : null;
    if (/\.png$/.test(name) || f.type === 'image/png') {
      const b = new Uint8Array(await f.slice(0, Math.min(f.size, 8 << 20)).arrayBuffer()), dv = new DataView(b.buffer);
      for (let i = 8; i + 8 <= b.length;) {
        const n = dv.getUint32(i), ty = String.fromCharCode(b[i + 4], b[i + 5], b[i + 6], b[i + 7]);
        if (ty === 'tEXt') { const t = new TextDecoder('latin1').decode(b.subarray(i + 8, i + 8 + n)); if (t.startsWith('code-painter\0')) return ok(JSON.parse(t.slice(13))); }
        if (ty === 'IDAT' || ty === 'IEND') break;
        i += 12 + n;
      }
      return null;
    }
    if (/\.(mp4|m4v|mov)$/.test(name) || f.type === 'video/mp4') {
      for (let i = 0; i + 8 <= f.size;) {
        const h = new DataView(await f.slice(i, i + 24).arrayBuffer()); let n = h.getUint32(0);
        const ty = String.fromCharCode(h.getUint8(4), h.getUint8(5), h.getUint8(6), h.getUint8(7));
        if (n === 1) n = Number(h.getBigUint64(8)); else if (n === 0) n = f.size - i;
        if (n < 8) break;
        if (ty === 'uuid' && h.byteLength >= 24 && META_UUID.every((v, k) => h.getUint8(8 + k) === v)) return ok(JSON.parse(await f.slice(i + 24, i + n).text()));
        i += n;
      }
      return null;
    }
    if (/\.(svg|html?)$/.test(name)) {
      const t = await f.text(), m = t.match(/<metadata id="code-painter">([\s\S]*?)<\/metadata>/) || t.match(/<script type="application\/json" id="code-painter-settings">([\s\S]*?)<\/script>/);
      return m ? ok(JSON.parse(m[1])) : null;
    }
  } catch (e) { /* not ours */ }
  return null;
}
function applyMeta(m, file) {
  presetApply(m.settings);
  $('hint').textContent = `Loaded the settings ${file} was made with${m.version ? ` (version ${m.version})` : ''}${m.picture ? `, from the picture “${m.picture}”` : ''}${m.song ? ` and the song “${m.song}”` : ''}. Open a picture (and a song) to paint with them — or drop it again holding Alt (Option) to paint the file itself.`;
}
const safeName = () => S.name.replace(/[^\w-]+/g, '_');

// ═════════════════════════════════════════════════════════════
//  Replay a hand-coded piece
// ═════════════════════════════════════════════════════════════
async function startReplay(id, opts = {}) {
  loadToken++;   // a picture still loading must not take over from the replay
  const under = opts.layer && S.out ? S.out : null;      // layering: the new piece goes on top of what is there
  stopAll(); applyReelLen(); newRun();
  S.pen = false; S.line = null; S.order = 'free'; S.penEnd = 0;     // (a replay is never one pen: the mixed-in strokes land together)
  const gen = ++S.replayGen;
  S.mode = 'replay'; S.name = id; S.done = false; S.count = 0; S.sim = null; S.step = 0; S.cur = null; S.recent = [];
  $('hint').textContent = `Loading ${id}…`;
  const [img, text] = await Promise.all([loadImg(refOf(id)), fetch(`../recreate/pieces/${id}.js`).then(r => r.text())]);
  S.orig = img; S.src = text.split('\n'); S.codeBytes = text.length; simPrepare(img);
  if (S.frame) S.frame.remove();
  S.frame = document.createElement('iframe'); S.frame.style.cssText = 'position:absolute;width:1px;height:1px;opacity:0;pointer-events:none;border:0';
  S.frame.src = `replay.html?id=${id}`; document.body.appendChild(S.frame);
  await new Promise(r => { const t = setInterval(() => { const w = S.frame.contentWindow; if (w && w.READY) { clearInterval(t); r(); } }, 50); });
  if (gen !== S.replayGen) return;
  S.api = S.frame.contentWindow.REPLAY;
  const info = await S.api.count();
  S.opLines = info.lines; S.opKinds = info.kinds; S.total = info.n;
  // (layering: the show's frame; the piece is placed in it — cropped to fill it, or fitted inside with black bars)
  let W = info.w, H = info.h; S.place = null;
  if (opts.layer && RSHOW.frame) {
    const L = Math.max(info.w, info.h), A = RSHOW.frame.A; W = Math.round(A >= 1 ? L : L * A); H = Math.round(A >= 1 ? L / A : L);
    const sc = (RSHOW.frame.fit === 'fit' ? Math.min : Math.max)(W / info.w, H / info.h), dw = info.w * sc, dh = info.h * sc;
    if (W !== info.w || H !== info.h) S.place = { dx: (W - dw) / 2, dy: (H - dh) / 2, dw, dh, iw: info.w, ih: info.h };
  }
  S.out = document.createElement('canvas'); S.out.width = W; S.out.height = H; S.outX = S.out.getContext('2d');
  S.outX.fillStyle = '#000'; S.outX.fillRect(0, 0, W, H); S.loopBg = '#000000';
  if (under) drawCover(S.outX, under, 0, 0, W, H);
  S.mixSnaps = [];
  snapMaybe(0);
  // keep a replay to roughly half a minute of rendering: every op for small pieces, evenly sampled for big ones
  const maxSteps = Math.max(40, Math.min(360, Math.round(30000 / Math.max(info.ms, 12))));
  S.sched = info.n <= maxSteps ? Array.from({ length: info.n }, (_, i) => i + 1) : Array.from({ length: maxSteps }, (_, i) => Math.max(1, Math.round((i + 1) * info.n / maxSteps)));
  S.plan = audioActive() && musicMode() === 'hits' ? hitPlan(S.sched.length) : null; S.stepTarget = 0;
  if (mixAmount() > 0) startMix(info);
  if (under) {             // layering: the code lands only where it changes something, and its first op (the background) is left out
    if (!S.mix) S.mix = { busy: false, debt: 0, done: 0, strokeSteps: S.sched.length, per: 0, prev: null };
    const c0 = await S.api.render(1); if (gen !== S.replayGen) return;
    S.mix.prev = c0.getContext('2d').getImageData(0, 0, info.w, info.h).data; S.mix.bg = S.mix.prev.slice(); S.layered = true;
  } else S.layered = false;
  S.running = true; S.t0 = clock(); S.pausedTotal = 0; S.pausedAt = 0;
  $('hint').textContent = `${opts.layer ? `Layer ${RSHOW.i + 1} of ${RSHOW.ids ? RSHOW.ids.length : 1}${RSHOW.i === 0 && RSHOW.note ? ` (${RSHOW.note})` : ''}: ` : ''}Replaying ${id}: ${info.n} drawing ops from ${S.src.length} lines of code${S.mix ? ` + ${Math.round(S.mix.per * S.mix.strokeSteps)} live strokes${S.mix.strokeSteps < S.sched.length ? ', then the code finishes on its own' : ''}` : ''}${audioActive() ? ` to ♪ ${AU.name} (${fmtTime(AU.in)}–${fmtTime(AU.out)})` : ''}.`;
  playAudioFromStart();
  setButtons();
  replayLoop(gen);
}
// ── replay + live: the hand-coded piece builds up while the painter adds strokes (styles, motions, brush) ──
// Both land on one canvas in the order they happen: each code step puts down only the pixels it changed, on top of
// whatever strokes are there; the painter keeps looking at that canvas and the original, and paints what's missing.
const mixAmount = () => +$('mix').value / 100;
function startMix(info) {
  const FW = S.out.width, FH = S.out.height, work = workRes(), L = Math.max(FW, FH);        // (the frame: the piece's own size unless layering placed it)
  S.ww = Math.max(8, Math.round(FW * work / L)); S.wh = Math.max(8, Math.round(FH * work / L)); S.k = FW / S.ww;
  const steps = Math.max(1, Math.round(S.sched.length * (1 - +$('mixfin').value / 100)));   // strokes land in these steps; the rest is the code finishing
  S.mix = { busy: false, debt: 0, done: 0, strokeSteps: steps, per: shapesWanted() * mixAmount() / steps, prev: null, cv: document.createElement('canvas'), tmp: null };
  S.mix.cv.width = S.ww; S.mix.cv.height = S.wh; S.mix.cx = S.mix.cv.getContext('2d', { willReadFrequently: true });
  S.queue = []; S.landing = []; S.recent = []; S.lines = []; S.items = []; S.drawn = []; S.bits = 0; S.brush = null; S.endless = newEndless(); S.fmt = 'readable';
  const x = S.mix.cx; origInto(x, S.ww, S.wh);
  let data = x.getImageData(0, 0, S.ww, S.wh).data;
  if (abstractOn()) data = abstractWarp(data, S.ww, S.wh, 0, 0);
  worker.postMessage({ type: 'start', gen: S.gen, w: S.ww, h: S.wh, data, shapes: 0, styles: stylePick.values(), bgStyles: stylePick.bg(), smart: true, abstract: abstractOn(), lines: linesOn(), outline: pieceOn() ? 'last' : outlineMode(), hilite: pieceOn(), rfill: rfillMode(), stylesize: SSZ, seed: 1 + Math.floor(Math.random() * 1e6), size: sizeK(), sizeRand: sizeRand(), palette: palette(), under: underOn() });
}
function sendMixFrame() {
  const M = S.mix, w = S.ww, h = S.wh, x = M.cx;
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.imageSmoothingQuality = 'high';
  if (S.place) x.drawImage(S.out, 0, 0, w, h);        // (fitted with bars: outside the piece the target is the canvas itself)
  origInto(x, w, h);
  let target = x.getImageData(0, 0, w, h).data;
  if (abstractOn()) target = abstractWarp(target, w, h, clock() / 1000 * 0.3, musicOn() ? AU.bass : 0);
  x.drawImage(S.out, 0, 0, w, h);
  x.setTransform(w / S.out.width, 0, 0, w / S.out.width, 0, 0); for (const it of S.landing) drawQ(x, it.q);
  x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1;
  const current = x.getImageData(0, 0, w, h).data;
  // layering: the live strokes only go where the new piece's code has drawn so far (elsewhere the target is the canvas
  // itself, so there is nothing to fix): they follow its marks and leave the pieces below alone
  if (S.layered && M.bg && M.prev) {
    // (from the work canvas to the piece's own pixels, through where the piece sits in the frame)
    const P = S.place || { dx: 0, dy: 0, dw: S.out.width, dh: S.out.height, iw: S.out.width, ih: S.out.height }, FW = S.out.width, FH = S.out.height, bg = M.bg, pv = M.prev;
    for (let y = 0; y < h; y++) { const fy = (y + 0.5) * FH / h, ny = Math.floor((fy - P.dy) * P.ih / P.dh); for (let xx = 0; xx < w; xx++) {
      const fx = (xx + 0.5) * FW / w, nx = Math.floor((fx - P.dx) * P.iw / P.dw), i = (y * w + xx) * 4;
      if (nx < 0 || ny < 0 || nx >= P.iw || ny >= P.ih) { target[i] = current[i]; target[i + 1] = current[i + 1]; target[i + 2] = current[i + 2]; continue; }
      const j = (ny * P.iw + nx) * 4;
      if (Math.abs(pv[j] - bg[j]) + Math.abs(pv[j + 1] - bg[j + 1]) + Math.abs(pv[j + 2] - bg[j + 2]) < 30) { target[i] = current[i]; target[i + 1] = current[i + 1]; target[i + 2] = current[i + 2]; }
    } }
  }
  M.busy = true;
  worker.postMessage({ type: 'frame', gen: S.gen, target, current, n: 24, L: 0, abstract: abstractOn(), outline: outlineMode(), rfill: rfillMode(), fresh: S.layered ? 0.55 : null }, [target.buffer, current.buffer]);     // (layering: no big washes over the pieces below)
}
// the original picture onto a work canvas, placed where the piece sits in the frame (cropped or fitted when layering)
function origInto(x, w, h) {
  const P = S.place; if (!P) { drawCover(x, S.orig, 0, 0, w, h); return; }
  const k = w / S.out.width; x.save(); x.beginPath(); x.rect(P.dx * k, P.dy * k, P.dw * k, P.dh * k); x.clip(); drawCover(x, S.orig, P.dx * k, P.dy * k, P.dw * k, P.dh * k); x.restore();
}
// a few snapshots of a replay with live strokes as it goes (for stills and the contact sheet: re-running the piece's
// code alone would leave the strokes and the layers below out)
function mixSnap(frac) {
  const n = 12; if (!S.mixSnaps || S.mixSnaps.length > Math.floor(frac * n)) return;
  const k = Math.min(1, 2400 / Math.max(S.out.width, S.out.height)), c = document.createElement('canvas'); c.width = Math.round(S.out.width * k); c.height = Math.round(S.out.height * k);
  const x = c.getContext('2d'); x.drawImage(S.out, 0, 0, c.width, c.height); S.mixSnaps.push({ f: frac, c });
}
// a code step lands as the pixels it changed (so it goes on top of the strokes, and the strokes around it stay)
function codeInto(cv) {
  const M = S.mix, w = cv.width, h = cv.height, P = S.place;        // (the piece's own size; placed in the frame below)
  const nd = cv.getContext('2d').getImageData(0, 0, w, h), a = nd.data, p = M.prev;
  if (!M.tmp) { M.tmp = document.createElement('canvas'); M.tmp.width = w; M.tmp.height = h; M.tx = M.tmp.getContext('2d'); M.id = M.tx.createImageData(w, h); }
  const o = M.id.data;
  let changed = 0;
  for (let i = 0; i < a.length; i += 4) {
    const d = p ? Math.abs(a[i] - p[i]) + Math.abs(a[i + 1] - p[i + 1]) + Math.abs(a[i + 2] - p[i + 2]) : 255;
    o[i] = a[i]; o[i + 1] = a[i + 1]; o[i + 2] = a[i + 2]; o[i + 3] = d <= 12 ? 0 : d >= 40 ? 255 : (d - 12) * 9.1;
    if (o[i + 3] > 128) changed++;
  }
  // layering: a step that washes over most of the canvas (a piece's backgrounds and big washes) goes on as a thin glaze,
  // so the piece underneath still shows through it
  if (S.layered && changed > a.length / 4 * 0.5) for (let i = 3; i < o.length; i += 4) o[i] = o[i] * 0.12;
  M.tx.putImageData(M.id, 0, 0);
  if (RLF.on && RLF.st && RLF.st.out === S.out) {        // a relief: the code paints its colours (and is paint, not material, where it lands)
    const R = RLF.st; R.ax.setTransform(1, 0, 0, 1, 0, 0); if (P) R.ax.drawImage(M.tmp, P.dx * R.w / S.out.width, P.dy * R.h / S.out.height, P.dw * R.w / S.out.width, P.dh * R.h / S.out.height); else R.ax.drawImage(M.tmp, 0, 0); R.dirty = true;
    if (!P && R.w === w && R.h === h) for (let i = 3, j = 0; i < o.length; i += 4, j++) if (o[i] > 128) R.M[j] = 0;
  } else if (P) S.outX.drawImage(M.tmp, P.dx, P.dy, P.dw, P.dh); else S.outX.drawImage(M.tmp, 0, 0);
  M.prev = a;
}
// strokes: shapes × mix of them over the whole replay, spread over its steps (a jump of several steps brings several steps' worth)
function mixStrokes(steps = true) {
  const M = S.mix, f = speedFactor();
  if (steps) { const upto = Math.min(S.step + 1, M.strokeSteps); M.debt += M.per * Math.max(0, upto - M.done); M.done = Math.max(M.done, upto); }
  const anim = f === Infinity ? null : { k: Math.min(2, Math.max(0.1, Math.pow(f, -0.6))) };
  let j = 0;
  while (M.debt >= 1 && S.queue.length) {
    const keep = [S.count, S.codeBytes, S.sim];                 // (the replay keeps its own count, size and match)
    reveal(S.queue.shift(), anim && { ...anim, delay: j++ * 12 }); M.debt--; M.painted = (M.painted || 0) + 1;
    [S.count, S.codeBytes, S.sim] = keep;
  }
  if (M.per > 0 && !M.busy && S.queue.length < 48 && (M.done < M.strokeSteps || M.debt >= 1)) sendMixFrame();
}
// the code finish starts: every stroke still due lands first (so none land on top of the finishing layers);
// in step with a song there's no waiting, the strokes still arriving are simply put down
async function finishStrokes(gen, synced) {
  const M = S.mix;
  for (const t = clock(); !synced && gen === S.replayGen && M.debt >= 1 && clock() - t < 8000;) { if (S.running) mixStrokes(false); await wait(60); }
  M.debt = 0;
  for (const t = clock(); !synced && gen === S.replayGen && S.landing.length && clock() - t < 1600;) await wait(40);
  flushLandings(); M.finishing = true;
}
// (it runs on wait(): during an offline render that is the render's clock, so each step lands on its exact frame)
async function replayLoop(gen) {
  S.loops = (S.loops || 0) + 1;
  try { await replaySteps(gen); } finally { S.loops--; }
}
async function replaySteps(gen) {
  while (gen === S.replayGen && S.step < S.sched.length) {
    if (!S.running) { await wait(60); continue; }
    if (S.dz > 0) break;                // looping back to empty already
    const m0 = audioActive() ? musicMode() : 'none', mode = m0 === 'hits' && !S.plan ? 'flow' : m0, synced = (mode === 'hits' || mode === 'flow') && !AU.ended, fitted = !synced && fitOn();
    if (synced && mode === 'hits') {    // each hit advances the piece by its share of steps
      const P = S.plan, t = aTime();
      while (AU.moving && P.i < P.t.length && P.t[P.i] <= t) S.stepTarget += P.n[P.i++];
      if (S.stepTarget <= S.step) { await wait(15); continue; }
      S.step = Math.min(S.sched.length, S.stepTarget) - 1;
    } else if (synced) {                // follow the song: jump to wherever the energy curve says we should be
      const target = Math.ceil(S.sched.length * audioProgress(aTime()));
      if (target <= S.step) { await wait(25); continue; }
      S.step = target - 1;
    } else if (fitted) {                // timed to the reel's length
      const target = Math.ceil(S.sched.length * fitCurve(elapsed() / fitBuild()));
      if (target <= S.step) { await wait(20); continue; }
      S.step = target - 1;
    } else if (audioActive() && AU.ended) S.step = S.sched.length - 1;
    if (S.mix && !S.mix.finishing && S.step >= S.mix.strokeSteps) { await finishStrokes(gen, synced || fitted); if (gen !== S.replayGen) return; }
    const k = S.sched[S.step];
    const cv = await S.api.render(k);
    if (gen !== S.replayGen) return;
    if (S.mix) { codeInto(cv); mixStrokes(); }
    else { const P = S.place; S.outX.clearRect(0, 0, S.out.width, S.out.height); if (P) { S.outX.fillStyle = '#000'; S.outX.fillRect(0, 0, S.out.width, S.out.height); S.outX.drawImage(cv, P.dx, P.dy, P.dw, P.dh); } else S.outX.drawImage(cv, 0, 0); }
    if (S.mix) mixSnap(S.step / S.sched.length);
    S.count = k; S.cur = { line: S.opLines[k - 1], kind: S.opKinds[k - 1], t: clock() };
    if (S.step % 3 === 0 || S.step === S.sched.length - 1) S.sim = simOf(S.out);
    S.step++; snapMaybe(S.step / S.sched.length); if (!S.mix) sndStep();
    if (!synced && !fitted) { const f = speedFactor(); await wait(f === Infinity || AU.ended ? 0 : 80 / f); }
  }
  // (the code can finish before the painter has delivered all its strokes: let it catch up)
  for (const t = clock(); gen === S.replayGen && S.mix && S.mix.debt >= 1 && clock() - t < 8000 && !(S.dz > 0);) { if (S.running) mixStrokes(false); await wait(60); }
  if (gen !== S.replayGen) return;
  if (S.mix) { await wait(S.landing.length && !(S.dz > 0) ? 1500 : 0); if (gen !== S.replayGen) return; flushLandings(); S.sim = simOf(S.out); if (S.mixSnaps) { S.mixSnaps = S.mixSnaps.filter(s => s.f < 1); mixSnap(1); } }
  S.done = true; if ((!audioActive() || AU.ended) && !holdOpen()) { S.running = false; S.pausedAt = clock(); }
  setButtons();
  $('hint').textContent = `Replay done: ${S.total} ops${S.mix ? ` + ${S.mix.painted || 0} live strokes` : ''}, ${S.sim.toFixed(1)}% colour match with the original.`;
  if (RSHOW.ids) { $('hint').textContent += ` Next of ${RSHOW.ids.length} in ${$('hold').value} s.`; replayShowNext(gen); }
  else if (S.rec && !audioActive() && !holdOpen()) recStopSoon(1500);
}

function stopAll() {
  worker.postMessage({ type: 'stop' }); helpersPost({ type: 'stop' }); S.gen++; S.replayGen++; S.running = false; S.waitAudio = false; S.mix = null;
  if (S.frame) { S.frame.remove(); S.frame = null; }
  if (AU.el) AU.el.pause();
  if (S.video && S.video !== AU.el) S.video.pause();
  S.codeBytes = 0;
}
function restart() {
  if (S.mode === 'auto') return startAuto(...S.startArgs);
  if (S.mode === 'replay') return startReplay(S.name);
}

// ── recording (stage video + the music) ──────────────────────
// Preferred: MP4REC (recorder.js) — constant frame rate, H.264 + AAC, a plain MP4 that editors like DaVinci Resolve
// open without trouble. Browsers without WebCodecs fall back to MediaRecorder (WebM where possible).
// stop the recording in ms (offline: at that point of the video)
function recStopSoon(ms) {
  if (!S.rec || S.rec.now) return;           // (recording from now: it runs until ⏹)
  if (S.rec.offline) OFF.endAt = Math.min(OFF.endAt, OFF.t + ms);
  else setTimeout(stopRecording, ms);
}
const recMode = () => $('recmode').value;       // offline (render, hq) | stage (live) | full (interface) | now
// the record key: a dot and its word — the dot turns red while it records (or renders)
const recKey = (on, word) => { const k = $('rec'); k.classList.toggle('on', on); k.innerHTML = `<i class="dot"></i>${word}`; };
const recIdle = () => recKey(false, 'record');
const recName = ext => `code-painter-${S.name.replace(/[^\w-]+/g, '_')}-${S.rec && S.rec.screen || S.recScreen ? 'full-interface' : document.body.dataset.layout + (DISPLAY === 'studio' ? '' : '-' + DISPLAY)}.${ext}`;
// (sound is recorded only while a song, a video's soundtrack or a live sound is driving the painting; otherwise the
// video has no audio track at all)
// the browser's own recorder (when the MP4 recorder can't run): MP4 wherever the browser can make one (Chrome, Edge,
// Safari), WebM otherwise (Firefox)
const REC_TYPES = ['video/mp4;codecs=avc1.640028,mp4a.40.2', 'video/mp4;codecs=avc1,mp4a.40.2', 'video/mp4;codecs=avc1', 'video/mp4', 'video/webm;codecs=vp9,opus', 'video/webm'];
async function startRecording(fromNow = false) {
  const fps = +$('recfps').value || 30, go = () => { if (fromNow) $('hint').textContent = 'Recording from now: ⏹ stops it.'; else restart(); };
  recKey(true, 'stop'); S.lastRec = null; $('savevid').disabled = true;
  if (window.MP4REC && await MP4REC.supported(stage.width, stage.height, fps)) {
    try {
      await MP4REC.start(stage, { fps, bitrate: 16e6, audio: recAudio() });
      S.rec = { mp4: true, now: fromNow, hidden0: AWAKE.hiddenMs }; go(); return;
    } catch (e) { console.warn('MP4 recorder unavailable, using MediaRecorder', e); S.recNote = ` (the MP4 recorder couldn't start: ${e.message}, so the browser's own recorder was used)`; }
  } else S.recNote = ` (this browser has no video encoder for the studio's own MP4 recorder, so its built-in recorder was used: Chrome, Edge or Brave give the steadiest MP4s)`;
  const types = REC_TYPES;
  const mimeType = types.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
  if (!mimeType) { $('hint').textContent = 'This browser cannot record the canvas.'; recIdle(); return; }
  const tracks = [...stage.captureStream(fps).getVideoTracks()];
  if (recAudio()) tracks.push(...AU.dest.stream.getAudioTracks());
  const rec = new MediaRecorder(new MediaStream(tracks), { mimeType, videoBitsPerSecond: 16e6, audioBitsPerSecond: 256e3 });
  const chunks = [];
  rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  rec.onstop = () => { const blob = new Blob(chunks, { type: mimeType }), name = recName(mimeType.includes('mp4') ? 'mp4' : 'webm'); S.lastRec = { blob, name }; $('savevid').disabled = false; download(blob, name); $('hint').textContent = `Saved ${name} (${(blob.size / 1e6).toFixed(1)} MB)${S.recNote || ''}. No download? Click ⬇ video.`; S.recNote = ''; };
  rec.start(250); rec.now = fromNow; S.rec = rec;
  go();
}
// ⏺ with "full": the whole interface, every knob and key, as it looks (the browser asks to share this tab), with the
// music tapped straight from the player. Real time; the run starts over like any recording.
async function startScreenRecording() {
  const fps = +$('recfps').value || 30;
  if (!navigator.mediaDevices || !navigator.mediaDevices.getDisplayMedia) { $('hint').textContent = "This browser can't record its own tab: use stage or offline."; return; }
  let stream;
  $('hint').textContent = 'Full interface: choose this tab in the browser\'s share window.';
  try {
    stream = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: fps, displaySurface: 'browser' }, audio: false, preferCurrentTab: true, selfBrowserSurface: 'include', surfaceSwitching: 'exclude' });
  } catch (e) { $('hint').textContent = e.name === 'NotAllowedError' ? 'Full interface recording needs this tab to be shared (it was cancelled).' : `Couldn't record the tab (${e.message}).`; return; }
  const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.srcObject = stream;
  await v.play().catch(() => {});
  await new Promise(r => { if (v.videoWidth) r(); else { v.onloadedmetadata = r; setTimeout(r, 3000); } });
  // a fixed-size picture (the tab can change size while sharing: it is fitted in), at most 4K
  const k = Math.min(1, 3840 / (v.videoWidth || 1920), 2160 / (v.videoHeight || 1080)), cv = document.createElement('canvas');
  cv.width = 2 * Math.round((v.videoWidth || 1920) * k / 2); cv.height = 2 * Math.round((v.videoHeight || 1080) * k / 2);
  const cx = cv.getContext('2d');
  const draw = () => { if (!v.videoWidth) return; cx.fillStyle = '#000'; cx.fillRect(0, 0, cv.width, cv.height); const f = fit(v, { x: 0, y: 0, w: cv.width, h: cv.height }); cx.drawImage(v, f.x, f.y, f.w, f.h); };
  const end = () => { stream.getTracks().forEach(t => t.stop()); v.srcObject = null; };
  stream.getVideoTracks()[0].addEventListener('ended', () => { if (S.rec && S.rec.screen) stopRecording(); });   // (the browser's "stop sharing")
  recKey(true, 'stop'); S.lastRec = null; $('savevid').disabled = true;
  const audio = recAudio();
  if (window.MP4REC && await MP4REC.supported(cv.width, cv.height, fps)) {
    try { await MP4REC.start(cv, { fps, bitrate: 24e6, audio, draw }); S.rec = { mp4: true, screen: true, end }; S.recScreen = true; restart(); return; }
    catch (e) { S.recNote = ` (the MP4 recorder couldn't start: ${e.message}, so the browser's own recorder was used)`; }
  }
  const types = REC_TYPES, mimeType = types.find(t => window.MediaRecorder && MediaRecorder.isTypeSupported(t));
  if (!mimeType) { end(); recIdle(); $('hint').textContent = 'This browser cannot record the tab.'; return; }
  const tracks = [...stream.getVideoTracks()]; if (recAudio()) tracks.push(...AU.dest.stream.getAudioTracks());
  const rec = new MediaRecorder(new MediaStream(tracks), { mimeType, videoBitsPerSecond: 24e6, audioBitsPerSecond: 256e3 }), chunks = [];
  rec.ondataavailable = e => { if (e.data.size) chunks.push(e.data); };
  rec.onstop = () => { end(); const blob = new Blob(chunks, { type: mimeType }), name = recName(mimeType.includes('mp4') ? 'mp4' : 'webm'); S.lastRec = { blob, name }; $('savevid').disabled = false; download(blob, name); $('hint').textContent = `Saved ${name} (${(blob.size / 1e6).toFixed(1)} MB)${S.recNote || ''}. No download? Click ⬇ video.`; S.recNote = ''; S.recScreen = false; };
  rec.screen = true; S.recScreen = true; rec.start(250); S.rec = rec;
  restart();
}
function stopRecording() {
  if (!S.rec) return;
  if (S.rec.offline) { OFF.endAt = Math.min(OFF.endAt, OFF.t); return; }     // (the render finishes at this frame and saves)
  const r = S.rec; S.rec = null; recIdle();
  // a video whose own sound is the music goes round its part again once the recording is done
  if (S.mode === 'auto' && S.video && AU.el === S.video && S.endless.on) setTimeout(() => { if (!S.rec && AU.ended && S.video === AU.el) { S.running = true; playAudioFromStart(); setButtons(); } }, 700);
  if (!r.mp4) return r.stop();
  if (r.end) r.end();
  $('hint').textContent = 'Finishing the video…';
  MP4REC.stop(p => { $('hint').textContent = `Finishing the video… ${Math.round(p * 100)}%`; }).then(blob => {
    const name = recName('mp4'), st = MP4REC.stats;
    S.lastRec = { blob, name }; $('savevid').disabled = false; download(blob, name); S.recScreen = false;
    // if the page couldn't draw every frame in time, those frames repeat (sound stays in step): say so, and how much
    const hid = AWAKE.hiddenMs + (AWAKE.on ? performance.now() - AWAKE.since : 0) - (r.hidden0 || 0);
    const smooth = !st || st.repeated < 0.05 ? ' Smooth: every frame was drawn in time.'
      : ` The page drew about ${Math.round(st.drawnFps)} of ${st.fps} fps while recording, so ${Math.round(st.repeated * 100)}% of the frames repeat (longest hold ${st.longestHold.toFixed(2)} s)${st.fps > 30 ? '. 30 fps will look smoother' : ''}.`
        + (hid > 500 ? ` The window was behind another app for ${(hid / 1000).toFixed(1)} s, when the browser draws it less smoothly.` : '')
        + (st.encoderBehind > 0 ? ' The video encoder fell behind at times.' : '')
        + ' For a perfectly smooth video choose offline: it renders every frame (pictures, videos, playlists and replays).';
    // no hardware video encoder: encoding in software is slow and takes the processor away from the painting
    const hw = !st || st.hw ? '' : ' The browser is encoding the video in software (slow): turn on graphics acceleration (Settings → System → "Use graphics acceleration when available") and restart it.';
    $('hint').textContent = `Saved ${name} (${(blob.size / 1e6).toFixed(1)} MB, ${st ? st.fps : $('recfps').value} fps constant, H.264${!st || st.audio ? ' + AAC' : ', no sound'}).${smooth}${hw} No download? Click ⬇ video.`;
  })
    .catch(e => { S.recScreen = false; $('hint').textContent = 'Recording failed: ' + e.message; });
}

// ═════════════════════════════════════════════════════════════
//  Stage drawing
// ═════════════════════════════════════════════════════════════
function rr(x, y, w, h, r, fill, stroke, lw = 1.5) { X.beginPath(); X.roundRect(x, y, w, h, r); if (fill) { X.fillStyle = fill; X.fill(); } if (stroke) { X.strokeStyle = stroke; X.lineWidth = lw; X.stroke(); } }
// neon glow around whatever is drawn inside fn
function glow(color, blur, fn) { if (!COL.glow) return fn(); X.save(); X.shadowColor = color; X.shadowBlur = blur; fn(); X.restore(); }
function chip(x, y, text, color = COL.dim) {
  X.font = `600 16px ${MONO}`; const w = X.measureText(text).width + 22;
  rr(x, y, w, 28, 6, 'rgba(0,0,0,.72)', color === COL.dim ? COL.line : color, 1);
  X.fillStyle = color; X.fillText(text, x + 11, y + 19);
}
const musicOn = () => (AU.el && !aPaused()) || !!AU.live;
const fxOn = () => musicOn() && beatFx();    // the optional beat effects: punch zoom, flashing border / outlines, grid pulse, rule flare
const fxAmt = () => fxOn() ? react() * (sectOn() ? 0.45 + 1.1 * S.secE : 1) : 0;
function background() {
  X.fillStyle = COL.bg; X.fillRect(0, 0, SW, SH);
  if (!COL.grid || DISPLAY !== 'studio') return;
  if (!gridCv) {
    gridCv = document.createElement('canvas'); gridCv.width = SW; gridCv.height = SH; const g = gridCv.getContext('2d');
    g.strokeStyle = COL.grid; g.lineWidth = 1;
    for (let x = 0.5; x < SW; x += 40) { g.beginPath(); g.moveTo(x, 0); g.lineTo(x, SH); g.stroke(); }
    for (let y = 0.5; y < SH; y += 40) { g.beginPath(); g.moveTo(0, y); g.lineTo(SW, y); g.stroke(); }
  }
  X.drawImage(gridCv, 0, 0);
  if (fxOn()) { X.globalAlpha = clamp01(AU.bass * 1.6 * react()); X.drawImage(gridCv, 0, 0); X.drawImage(gridCv, 0, 0); X.globalAlpha = 1; }
}
// the studio display's top line: just the stats (no title)
function header() {
  const P = LY.stats;
  const stats = [];
  if (S.mode === 'auto') stats.push([Math.round(S.count * (1 - easeInOut(S.dz || 0))).toLocaleString() + (S.endless.on ? ' · ∞' : '/' + S.total.toLocaleString()), 'shapes', COL.fg]);
  if (S.mode === 'replay') stats.push([S.count.toLocaleString() + '/' + S.total.toLocaleString(), 'ops', COL.fg]);
  if (S.sim != null) stats.push([S.sim.toFixed(1) + '%', 'match', COL.accent]);
  if (S.mode !== 'idle') stats.push([(codeSize() / 1024).toFixed(1) + 'KB', S.mode === 'auto' ? S.fmt : 'code', COL.accent2],
    [AU.el ? fmtTime(aTime()) : fmtTime(elapsed()), 'time', COL.fg]);
  let x = P.right;
  for (let i = stats.length - 1; i >= 0; i--) {
    const [v, l, c] = stats[i]; X.font = `700 ${P.size}px ${MONO}`; const vw = X.measureText(v).width; X.font = `14px ${MONO}`; const lw = X.measureText(l).width;
    x -= Math.max(vw, lw);
    X.font = `700 ${P.size}px ${MONO}`; X.fillStyle = c;
    if (c !== COL.fg) glow(c, 12, () => X.fillText(v, x, P.y)); else X.fillText(v, x, P.y);
    X.fillStyle = COL.dim; X.font = `14px ${MONO}`; X.fillText(l, x, P.y + 20);
    x -= 30;
  }
  if (LY.rule) {   // neon rule under the header (vertical layout); flares on beats
    const g = X.createLinearGradient(40, 0, SW - 40, 0); g.addColorStop(0, COL.accent); g.addColorStop(1, COL.accent2);
    const f = AU.beat * fxAmt();
    glow(COL.accent, 10 + 30 * f, () => { X.fillStyle = g; X.fillRect(40, LY.rule, SW - 80, 2 + 2 * f); });
  }
}
function outline(s, b, k, color, alpha, width) {
  const p = SHP.poly(s);
  X.beginPath(); for (let i = 0; i < p.length; i += 2) X[i ? 'lineTo' : 'moveTo'](b.x + p[i] * k, b.y + p[i + 1] * k); X.closePath();
  X.globalAlpha = alpha; X.strokeStyle = color; X.lineWidth = width; X.stroke(); X.globalAlpha = 1;
}
function panes(now) {
  const O = LY.orig, Pn = LY.paint, active = S.running && !S.done, r = fxAmt();
  rr(O.x, O.y, O.w, O.h, 14, COL.panel, COL.line, 1);
  rr(Pn.x, Pn.y, Pn.w, Pn.h, 14, COL.panel);
  // a quiet hairline around the painting (it only flashes when beat FX are switched on)
  const beatCol = AU.beats % 2 ? COL.accent2 : COL.accent, flash = r && AU.beat > 0.3;
  if (flash) glow(beatCol, 10 + 40 * AU.bass * r, () => rr(Pn.x, Pn.y, Pn.w, Pn.h, 14, null, beatCol, 1.5 + 2 * AU.beat * r));
  else rr(Pn.x + 0.5, Pn.y + 0.5, Pn.w - 1, Pn.h - 1, 14, null, active && $('frame').value === 'rect' ? 'rgba(255,255,255,.14)' : COL.line, 1);
  if (!S.orig) {
    X.setLineDash([10, 10]); rr(O.x + 30, O.y + 30, O.w - 60, O.h - 60, 16, null, COL.line); X.setLineDash([]);
    X.fillStyle = COL.dim; X.font = `600 30px ${MONO}`; X.textAlign = 'center';
    X.fillText('drop any image here', O.x + O.w / 2, O.y + O.h / 2 - 8);
    X.font = `18px ${MONO}`; X.fillText(PUBLIC ? 'or pick a demo, or type a word (examples…)' : 'or pick an example / a piece to replay', O.x + O.w / 2, O.y + O.h / 2 + 28);
    X.fillStyle = COL.accent; X.fillText('the code-painted version appears here', Pn.x + Pn.w / 2, Pn.y + Pn.h / 2);
    X.textAlign = 'left';
    return;
  }
  const items = viewerItems();
  if (items.length >= 2) drawTiles(items, { x: O.x + 14, y: O.y + 14, w: O.w - 28, h: O.h - 28 }, 10, true);
  else {
    const a = fit(S.orig, { x: O.x + 14, y: O.y + 14, w: O.w - 28, h: O.h - 28 });
    X.drawImage(S.orig, a.x, a.y, a.w, a.h);
    chip(O.x + 14, O.y + 14, 'original');
  }
  if (S.out) {
    const b = fit(S.out, { x: Pn.x + 14, y: Pn.y + 14, w: Pn.w - 28, h: Pn.h - 28 });
    X.save(); X.beginPath(); X.roundRect(Pn.x + 2, Pn.y + 2, Pn.w - 4, Pn.h - 4, 12); X.clip();
    paintPanel(b, now, r);
    X.restore();
    if (S.mode === 'replay') chip(Pn.x + 14, Pn.y + 14, 'code, running', COL.accent);
  }
}
// ⟦style-runtime⟧ begin — from here to its end, the code also travels inside a saved program that uses the styles
// ═════════════════════════════════════════════════════════════
//  Drawing a shape: plain runtime call, or sprayed (graffiti); and its relief in the height map
// ═════════════════════════════════════════════════════════════
// ── fill gestures: a tool has a size (a spray can, a marker, a pencil can only be so wide). When the painter asks one
// for a stroke (or a patch) much wider than that, it is filled the way a hand would fill it: zigzag passes across it,
// or zigzags and then rows along it (cross). Each pass is a stroke of the style at the tool's own width; they are drawn
// one after another as the stroke arrives.
const TOOL = { painterly: 44, soft: 34, graffiti: 26, marker: 12, pencil: 5, pen: 3, charcoal: 14, pastel: 18, ink: 24, sumi: 30, calligraphy: 16, gouache: 40, watercolour: 50, oil: 56, acrylic: 56, knife: 64, neon: 10, hylics: 40, thread: 18 };
const FILLS = new WeakMap(), SWEEP = new Set(['painterly', 'gouache', 'watercolour', 'sumi', 'oil', 'acrylic', 'knife']);   // (brushes sweep across on a slant)
function fillParts(q) {
  if (q.sub || fillMode() === 'off') return null;
  const cap0 = TOOL[q.st]; if (!cap0 || (q.t !== 'S' && RELIEF[q.st] && RELIEF[q.st].bristle)) return null;    // (paint areas: bristleFill already lays them in brush strokes)
  const fm = fillMode(), hit = FILLS.get(q); if (hit && hit.m === fm) return hit.r;
  let cap = Math.max(cap0 * outLong() / 1000, q.t === 'S' ? q.args[6] / 10 : 0);     // (a fine tool on a huge band: still a sensible number of passes)
  const a = q.args, [c0, c1, o] = colsOf(q), R = rngFor(a), out = [], cross = fm === 'cross';
  const sub = (x0, y0, x1, y1, w, t, bend) => {
    const mx = (x0 + x1) / 2, my = (y0 + y1) / 2, dx = x1 - x0, dy = y1 - y0, l = Math.hypot(dx, dy) || 1;
    out.push({ t: 'S', st: q.st, brush: q.brush, sub: true, args: [x0, y0, mx - dy / l * bend, my + dx / l * bend, x1, y1, w, Math.atan2(dy, dx), mixHex(c0, c1, t), mixHex(c0, c1, Math.min(1, t + 0.08)), o], seed: [a[0] + out.length * 3.1, a[1] + out.length * 1.7, a[2], a[3], out.length, 7] });
  };
  if (q.t === 'S') {
    const W = a[6]; if (W <= cap * 1.3) { FILLS.set(q, { m: fm, r: null }); return null; }
    const P = quadPts(a, 1, 1, 48), cum = [0]; for (let i = 1; i < P.length; i++) cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
    const L = cum[cum.length - 1] || 1, at = d => { let j = 1; while (j < P.length - 1 && cum[j] < d) j++; const f = (d - cum[j - 1]) / ((cum[j] - cum[j - 1]) || 1), x = P[j - 1][0] + (P[j][0] - P[j - 1][0]) * f, y = P[j - 1][1] + (P[j][1] - P[j - 1][1]) * f, tx = P[j][0] - P[j - 1][0], ty = P[j][1] - P[j - 1][1], tl = Math.hypot(tx, ty) || 1; return [x, y, -ty / tl, tx / tl]; };
    const sweep = SWEEP.has(q.st), half = W / 2 - cap / 2, step = cap * 0.45;
    // rows along the band, each in overlapping runs (a brush narrower than the band); returns the parts it laid
    const rowsAlong = (k0, layer) => {
      const rows = Math.max(2, Math.round(W / (cap * 0.7))), runs = Math.max(1, Math.round(L / (cap * (sweep ? 5 : 4))));
      for (let k = 0; k < rows; k++) {
        const off = -half + (2 * half) * (k + layer * 0.5) / Math.max(1, rows - 1 + layer), back = (k + layer) % 2, sh = (R() - 0.5) * 0.6 / runs;
        for (let r = 0; r < runs; r++) {
          const rr = back ? runs - 1 - r : r, d0 = L * Math.max(0, rr / runs + (rr ? sh : 0) - 0.04), d1 = L * Math.min(1, (rr + 1) / runs + sh + 0.06), A = at(back ? d1 : d0), B = at(back ? d0 : d1), j = (R() - 0.5) * cap * 0.25;
          if (Math.abs(off) > half + 0.01) continue;
          sub(A[0] + A[2] * (off + j), A[1] + A[3] * (off + j), B[0] + B[2] * (off - j), B[1] + B[3] * (off - j), cap * (0.85 + R() * 0.3), (rr + 0.5) / runs, (R() - 0.5) * cap * 0.3);
        }
      }
    };
    if (sweep) { rowsAlong(0, 0); if (cross) rowsAlong(1, 1); FILLS.set(q, { m: fm, r: out }); return out; }
    // zigzag: across the band, edge to edge, moving along it
    let side = -1;          // (by hand: the steps uneven, the turns falling short or running over the edge, the line bowed)
    for (let d = 0, st = step; d < L; d += st) {
      st = step * (0.55 + R() * 1.0);
      const A = at(d), B = at(Math.min(L, d + st)), j = (R() - 0.5) * cap * 0.5, ra = half * (0.78 + R() * 0.3), rb = half * (0.78 + R() * 0.3);
      sub(A[0] + A[2] * ra * side + j, A[1] + A[3] * ra * side, B[0] - B[2] * rb * side, B[1] - B[3] * rb * side - j, cap * (0.7 + R() * 0.6), d / L, (R() - 0.5) * cap * 1.6);
      side = -side;
    }
    if (cross) rowsAlong(0, 0);    // then rows along it, over the zigzag (in short runs, so the colour still moves along it)
  } else {
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P); cap = Math.max(cap, Math.max(b.w, b.h) / 10); if (Math.max(b.w, b.h) <= cap * 1.8) { FILLS.set(q, { m: fm, r: null }); return null; }
    const an = q.st === 'marker' ? Math.PI / 4 : (q.t === 'E' || q.t === 'B' || q.t === 'R' ? a[4] : R() * Math.PI) + Math.PI / 2;   // (a chisel marker is widest moving at 45°)
    const pass = (ang, k0) => {
      const dx = Math.cos(ang), dy = Math.sin(ang), nx = -dy, ny = dx; let lo = 1e9, hi = -1e9, lo2 = 1e9, hi2 = -1e9;
      for (let i = 0; i < P.length; i += 2) { const u = P[i] * nx + P[i + 1] * ny, v = P[i] * dx + P[i + 1] * dy; lo = Math.min(lo, u); hi = Math.max(hi, u); lo2 = Math.min(lo2, v); hi2 = Math.max(hi2, v); }
      const n = Math.max(1, Math.ceil((hi - lo) / (cap * 0.45)));
      for (let k = 0; k < n; k++) {
        if (R() < 0.07) continue;                                                     // (a row skipped, as a hand does)
        const u = lo + (k + 0.3 + R() * 0.4) * (hi - lo) / n; let f = null, l = null;
        for (let j = 0; j <= 30; j++) { const v = lo2 + (hi2 - lo2) * j / 30, px = nx * u + dx * v, py = ny * u + dy * v; if (inPoly(P, px, py)) { if (!f) f = [px, py]; l = [px, py]; } }
        if (!f) continue; let [A, B] = k % 2 ? [l, f] : [f, l];
        const mx = (A[0] + B[0]) / 2, my = (A[1] + B[1]) / 2, ta = 0.82 + R() * 0.26, tb = 0.82 + R() * 0.26, tw = (R() - 0.5) * cap * 0.8;   // (ends short or over, the line a little tilted)
        A = [mx + (A[0] - mx) * ta + nx * tw, my + (A[1] - my) * ta + ny * tw]; B = [mx + (B[0] - mx) * tb - nx * tw, my + (B[1] - my) * tb - ny * tw];
        sub(A[0], A[1], B[0], B[1], cap * (0.7 + R() * 0.6), (k0 + k / n) / (cross ? 2 : 1), (R() - 0.5) * cap * 1.4);
      }
    };
    pass(an, 0); if (cross) pass(an + Math.PI / 2 + (R() - 0.5) * 0.6, 1);
  }
  const res = out.length ? out : null; FILLS.set(q, { m: fm, r: res }); return res;
}
// a fill stroke part-way: the passes done so far whole, the one being drawn part-way (by length)
function fillUpTo(parts, u) {
  const len = parts.map(p => Math.hypot(p.args[4] - p.args[0], p.args[5] - p.args[1]) + 1), tot = len.reduce((a, b) => a + b, 0);
  let d = u * tot; const done = [];
  for (let i = 0; i < parts.length; i++) { if (d >= len[i]) { done.push(parts[i]); d -= len[i]; } else return { done, cur: parts[i], f: d / len[i] }; }
  return { done, cur: null, f: 1 };
}
function drawQ(x, q) {
  const fp = fillParts(q); if (fp) { for (const p of fp) drawQ(x, p); return; }
  const round = q.t === 'S' || q.t === 'B' || q.t === 'E';
  if (q.st === 'graffiti' && round) spray(x, q);
  else if (RELIEF[q.st]) { if (!(RLF.on && x === X)) reliefFlat(x, q); }      // (arriving on the stage: the relief itself shows it, lit)
  else if (STYLE_DRAW[q.st]) STYLE_DRAW[q.st](x, q);
  else if (q.brush) brushed(x, q);
  else SHP.lib(x)[q.t](...q.args);
}
// a shape onto the painting: into its relief when one is in use (the first relief stroke starts it)
function putShape(q) {
  if (RLF.on && (RLF.st.out !== S.out || !reliefMode())) reliefStop();
  if (!RLF.on && RELIEF[q.st] && reliefOk()) reliefStart();
  if (RLF.on) reliefAdd(RLF.st, q); else drawQ(S.outX, q);
}
function commitShape(q) { putShape(q); if (S.mode === 'auto' && !S.endless.on) snapMaybe(++S.committed / S.total); }
// the painting so far drawn again from its shapes (after the light, the brush or a style's look changed)
function redrawAll() {
  const done = S.drawn.length - pendingN();
  paintBg(S.outX); for (let i = 0; i < done; i++) putShape(S.drawn[i]); reliefFlush(true); S.big = null;
}
// small seeded random numbers, so a sprayed stroke looks the same every time it is drawn (re-bakes, 4K / 8K renders)
function rngFor(a) {
  let h = 2166136261; for (let i = 0; i < 6; i++) { h ^= Math.round((a[i] || 0) * 10); h = Math.imul(h, 16777619); }
  let s = h >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; };
}
// spray grain: a real can (and Photoshop's / Affinity's spray brushes) lays paint down as a cloud of tiny droplets,
// dense in the middle and thinning out, so the colour builds up grainy rather than as a smooth band. Two particle
// masks per size, made once with fixed seeds (so a stroke looks the same every time): body (a gaussian cloud over a
// soft core) and mist (sparse overspray). A stroke stamps them along its path, tinted, at random turns.
const SPG = { m: {}, t: {} };
const spCanvas = n => { const c = typeof document !== 'undefined' ? document.createElement('canvas') : new OffscreenCanvas(n, n); c.width = c.height = n; return c; };
function sprayMask(kind, n) {
  const key = kind + n; if (SPG.m[key]) return SPG.m[key];
  const c = spCanvas(n), g = c.getContext('2d'), h = n / 2;
  let sd = (n * 7919 + (kind === 'mist' ? 104729 : 0)) >>> 0 || 1; const R = () => { sd ^= sd << 13; sd >>>= 0; sd ^= sd >>> 17; sd ^= sd << 5; sd >>>= 0; return sd / 4294967296; };
  if (kind === 'body') { const G = g.createRadialGradient(h, h, 0, h, h, h); G.addColorStop(0, 'rgba(255,255,255,.5)'); G.addColorStop(0.4, 'rgba(255,255,255,.26)'); G.addColorStop(0.8, 'rgba(255,255,255,.04)'); G.addColorStop(1, 'rgba(255,255,255,0)'); g.fillStyle = G; g.fillRect(0, 0, n, n); }
  g.fillStyle = '#fff';
  const N = Math.round(n * n * (kind === 'body' ? 0.3 : 0.035));
  for (let i = 0; i < N; i++) {
    const r = kind === 'body' ? Math.abs(R() + R() + R() + R() - 2) * h * 0.62 : h * (0.2 + 0.8 * Math.sqrt(R())), an = R() * 6.2832;
    if (r > h - 1.5) continue;
    const px = h + Math.cos(an) * r, py = h + Math.sin(an) * r, d = 0.45 + R() * R() * (kind === 'body' ? 1.3 : 1.7);   // (droplets of about a pixel; now and then a bigger one)
    g.globalAlpha = (kind === 'body' ? 0.3 : 0.4) + R() * 0.6;
    if (d < 0.8) g.fillRect(px - d, py - d, d * 2, d * 2); else { g.beginPath(); g.arc(px, py, d, 0, 6.2832); g.fill(); }
  }
  return SPG.m[key] = c;
}
function sprayTint(kind, n, colour) {
  const key = kind + n, t = SPG.t[key] || (SPG.t[key] = spCanvas(n)), g = t.getContext('2d');
  g.globalCompositeOperation = 'copy'; g.globalAlpha = 1; g.drawImage(sprayMask(kind, n), 0, 0);
  g.globalCompositeOperation = 'source-in'; g.fillStyle = colour; g.fillRect(0, 0, n, n); g.globalCompositeOperation = 'source-over';
  return t;
}
// the mask size for a stamp D units across on x (a power of two near its size in real pixels: droplets stay ~1 px)
const spSize = (x, D) => { const m = x.getTransform(), dev = D * (Math.hypot(m.a, m.b) || 1); return Math.min(512, Math.max(16, 2 ** Math.ceil(Math.log2(Math.max(1, dev))))); };
// splatter: a few droplets thrown off the can, most tiny, a rare big one with its little satellites
function splats(x, R, n, at, o) {
  for (let i = 0; i < n; i++) {
    const [px, py, r] = at();
    x.globalAlpha = o * (0.55 + R() * 0.4); x.beginPath(); x.arc(px, py, r, 0, 6.2832); x.fill();
    if (r > 1.6 && R() < 0.6) for (let k = 0, m = 1 + Math.floor(R() * 3); k < m; k++) { const an = R() * 6.2832, dd = r * (1.6 + R() * 2.5); x.beginPath(); x.arc(px + Math.cos(an) * dd, py + Math.sin(an) * dd, r * (0.12 + R() * 0.25), 0, 6.2832); x.fill(); }
  }
}
// a drip: wet paint running down out of the sprayed film. It grows out of the paint (no hard top), keeps about
// the same thin width as it runs, wanders a little, ends in a round bead and catches a thin wet shine on one side.
function drip(x, R, colour, dx, dy, w, o) {
  const m = x.getTransform(), px = 1 / (Math.hypot(m.a, m.b) || 1);
  const hw = Math.max(0.7 * px, w * (0.03 + R() * 0.035)), L = w * (0.5 + R() * R() * 3), y0 = dy + w * 0.1, y1 = y0 + L;
  const wob = (R() - 0.5) * hw * 1.2, ph = R() * 6.28, xs = t => dx + wob * t * t + Math.sin(ph + t * 5) * hw * 0.18;
  const hwAt = t => hw * (t < 0.15 ? 0.6 + t / 0.15 * 0.55 : 1.15 - t * 0.35);      // (a little fuller where it leaves the paint, thinner as it runs)
  const n = 14, Lp = [], Rp = [];
  for (let i = 0; i <= n; i++) { const t = i / n, y = y0 + L * t, xx = xs(t), h = hwAt(t); Lp.push([xx - h, y]); Rp.push([xx + h, y]); }
  const G = x.createLinearGradient(0, y0 - w * 0.15, 0, y0 + Math.min(L * 0.5, w * 0.45));
  G.addColorStop(0, colour + '00'); G.addColorStop(1, colour);
  x.globalAlpha = o * 0.92; x.fillStyle = G; x.beginPath();
  Lp.forEach((p, i) => x[i ? 'lineTo' : 'moveTo'](p[0], p[1])); for (let i = Rp.length - 1; i >= 0; i--) x.lineTo(Rp[i][0], Rp[i][1]); x.closePath(); x.fill();
  const bx = xs(1), br = hw * (1.25 + R() * 0.35);           // the bead at the end, where the paint gathers
  x.fillStyle = colour; x.beginPath(); x.ellipse(bx, y1 + br * 0.15, br, br * 1.15, 0, 0, 6.2832); x.fill();
  x.globalAlpha = o * 0.28; x.strokeStyle = shade(colour, 0.45); x.lineWidth = Math.max(0.5 * px, hw * 0.35); x.lineCap = 'round';   // the wet shine
  x.beginPath(); for (let i = 3; i <= n; i++) { const t = i / n; x[i > 3 ? 'lineTo' : 'moveTo'](xs(t) - hwAt(t) * 0.4, y0 + L * t); } x.stroke();
  x.beginPath(); x.arc(bx - br * 0.35, y1 - br * 0.2, br * 0.28, 0, 6.2832); x.fillStyle = shade(colour, 0.6); x.fill();
  x.fillStyle = x.strokeStyle = colour;
}
// graffiti: a spray-can stroke — a grainy body of droplets, a fine overspray mist round it, a few splatters and,
// on heavy strokes, drips running down. u (0..1) draws only the first part (for the draw motion); returns where the can is.
function spray(x, q, u = 1, dir = 1) {
  const a = q.args, t = q.t, R = rngFor(a), colour = a[t === 'S' ? 8 : 6], o = a[a.length - 1];
  const g = () => (R() + R() + R() - 1.5) / 1.5;
  x.save(); x.fillStyle = x.strokeStyle = colour; x.lineCap = 'round'; x.lineJoin = 'round';
  if (t === 'S') {
    let [x0, y0, x1, y1, x2, y2, w] = a; if (dir < 0) [x0, y0, x2, y2] = [x2, y2, x0, y0];
    const pt = s => { const v = 1 - s; return [v * v * x0 + 2 * v * s * x1 + s * s * x2, v * v * y0 + 2 * v * s * y1 + s * s * y2]; };
    const tn = s => { const dx = 2 * (1 - s) * (x1 - x0) + 2 * s * (x2 - x1), dy = 2 * (1 - s) * (y1 - y0) + 2 * s * (y2 - y1), d = Math.hypot(dx, dy) || 1; return [dx / d, dy / d]; };
    const [ex, ey] = pt(u), C = CAPS[capOf(w)], len = Math.hypot(x1 - x0, y1 - y0) + Math.hypot(x2 - x1, y2 - y1);
    // the mist first, then the body: stamps of droplets along the path, each at a random turn
    const stamps = (kind, D, step, al) => {
      const n = sprayTint(kind, spSize(x, D), colour), cnt = Math.max(2, Math.min(240, Math.ceil(len * u / step) + 1));
      x.globalAlpha = o * al; const M0 = x.getTransform();
      for (let i = 0; i < cnt; i++) {
        const s = u * (cnt > 1 ? i / (cnt - 1) : 0), [px, py] = pt(s), [tx, ty] = tn(s), j = g() * w * 0.06, dd = D * (0.9 + R() * 0.2), an = R() * 6.2832;
        x.setTransform(M0); x.translate(px - ty * j, py + tx * j); x.rotate(an); x.drawImage(n, -dd / 2, -dd / 2, dd, dd);
      }
      x.setTransform(M0);
    };
    const Db = w * C.body, Dm = w * C.mist;
    stamps('mist', Dm, Math.max(1, Dm * 0.35), C.mistA);
    if (C.flat) {          // a flat cap: a ribbon, wide across its edge and thin along it, with crisp sides
      const n2 = 28, Lp = [], Rp = []; for (let i = 0; i <= n2; i++) { const s = u * i / n2, [px, py] = pt(s), [tx, ty] = tn(s), wd = w * 0.55 * (0.16 + 0.84 * Math.abs(Math.sin(Math.atan2(ty, tx) - C.flat))); Lp.push([px - ty * wd, py + tx * wd]); Rp.push([px + ty * wd, py - tx * wd]); }
      x.globalAlpha = o * 0.82; x.beginPath(); Lp.forEach((p, i) => x[i ? 'lineTo' : 'moveTo'](p[0], p[1])); for (let i = Rp.length - 1; i >= 0; i--) x.lineTo(Rp[i][0], Rp[i][1]); x.closePath(); x.fill();
    }
    stamps('body', Db, Math.max(0.6, Db * 0.14), C.a);
    // splatter, thrown off to the sides
    const nsp = Math.min(14, Math.round(C.splat * (len * u / Math.max(4, w) * 0.6 + 1) * (0.5 + R())));
    splats(x, R, nsp, () => { const s = R() * u, [px, py] = pt(s), [tx, ty] = tn(s), off = g() * Dm * 0.55; return [px - ty * off, py + tx * off, Math.max(0.5, w * 0.035 * (0.4 + R() ** 3 * 3.5))]; }, o);
    // drips: where much paint lands in one place (a wide, short stroke; a fat cap) it runs (a filling pass drips less: the can keeps moving)
    const pool = Math.min(1.6, w / Math.max(8, len) * 3);
    if (u >= 1 && w > 4 && o > 0.45 && R() < (q.sub ? 0.12 : 1) * Math.min(0.9, C.drip * (0.6 + pool)))
      for (let d = 0, nd = R() < 0.35 ? 2 : 1; d < nd; d++) { const [dx, dy] = pt(0.15 + R() * 0.7); drip(x, R, colour, dx, dy, w, o * Math.min(1, C.a * 2.2)); }
    x.restore(); return [ex, ey];
  }
  // a blob / ellipse: an airbrushed burst — a soft core, droplets over it, mist and splatter round it
  const [cx, cy, rx, ry, rot] = a, m = Math.max(rx, ry), C = CAPS[capOf(m)];
  const nb = sprayTint('body', spSize(x, m * 2.5), colour);
  x.translate(cx, cy); x.rotate(rot); x.scale(rx / m, ry / m);
  const G = x.createRadialGradient(0, 0, 0, 0, 0, m * 1.05);
  G.addColorStop(0, colour); G.addColorStop(0.55, colour); G.addColorStop(1, colour + '00');
  x.globalAlpha = o * 0.6 * u; x.fillStyle = G; x.beginPath(); x.arc(0, 0, m * 1.05 * Math.max(0.2, u), 0, 7); x.fill();
  const bs = m * 2.5 * Math.max(0.2, u);
  for (let k = 0; k < 3; k++) { const an = R() * 6.2832; x.rotate(an); x.globalAlpha = o * 0.55 * u; x.drawImage(nb, -bs / 2, -bs / 2, bs, bs); x.rotate(-an); }
  const nm = sprayTint('mist', spSize(x, m * 3.4), colour), ms = m * 3.4 * Math.max(0.2, u);
  x.globalAlpha = o * C.mistA * u; x.drawImage(nm, -ms / 2, -ms / 2, ms, ms);
  x.fillStyle = colour;
  splats(x, R, Math.round(C.splat * 6 * u), () => { const an = R() * 6.283, rr = m * (0.95 + Math.abs(g()) * 0.8); return [Math.cos(an) * rr, Math.sin(an) * rr, Math.max(0.5, m * 0.025 * (0.4 + R() ** 3 * 3))]; }, o);
  x.restore(); return [cx, cy];
}
// ═════════════════════════════════════════════════════════════
//  Stroke renderers: claymation / relief shading, and brush stamps
// ═════════════════════════════════════════════════════════════
const hexRgb = h => { const n = parseInt(h.slice(1, 7), 16); return [n >> 16 & 255, n >> 8 & 255, n & 255]; };
const shade = (h, k) => { const [r, g, b] = hexRgb(h), f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k); return `rgb(${f(r)},${f(g)},${f(b)})`; };
// the first u of a quadratic stroke as a path (dir < 0 starts from the other end); returns the end point
function strokePath(x, a, u, dir) {
  let [x0, y0, x1, y1, x2, y2] = a; if (dir < 0) [x0, y0, x2, y2] = [x2, y2, x0, y0];
  const qx = x0 + (x1 - x0) * u, qy = y0 + (y1 - y0) * u, ex = qx + (x1 + (x2 - x1) * u - qx) * u, ey = qy + (y1 + (y2 - y1) * u - qy) * u;
  x.beginPath(); x.moveTo(x0, y0); x.quadraticCurveTo(qx, qy, ex, ey);
  return [ex, ey];
}

// ═════════════════════════════════════════════════════════════
//  The newer styles' own looks. The painter scores plain shapes (tuned per style: tiles on a grid, straight
//  strings, level bars, round lenses…); these draw them in their own way, from the same seeded randomness every
//  time (re-bakes, 4K / 8K renders, stills). A saved program that uses them carries this code with it.
//    mosaic   glazed tiles on a grid, with grout between      glass    stained glass: pieces in lead
//    scribble a pen scribbled back and forth inside the shape comic    halftone dots, growing along the gradient
//    glitch   level bars with a chromatic split, some slipped bokeh    out-of-focus lights with a bright rim
//    paper    torn paper with a white fibre edge and a shadow chrome   liquid metal: banded reflections
//    stitch   cross-stitch on a fixed fabric grid             (string: long straight threads — plain shapes)
// ═════════════════════════════════════════════════════════════
const colsOf = q => { const a = q.args, i = q.t === 'T' ? 7 : q.t === 'S' ? 8 : 6; return [a[i], a[i + 1], a[a.length - 1]]; };
function outlinePath(x, q) {
  const a = q.args; x.beginPath();
  if (q.t === 'E' || q.t === 'B') { x.ellipse(a[0], a[1], Math.max(0.1, a[2]), Math.max(0.1, a[3]), a[4], 0, 7); return; }
  const p = SHP.poly({ t: q.t, p: a }); x.moveTo(p[0], p[1]); for (let i = 2; i < p.length; i += 2) x.lineTo(p[i], p[i + 1]); x.closePath();
}
function boxOf(P) {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (let i = 0; i < P.length; i += 2) { if (P[i] < x0) x0 = P[i]; if (P[i] > x1) x1 = P[i]; if (P[i + 1] < y0) y0 = P[i + 1]; if (P[i + 1] > y1) y1 = P[i + 1]; }
  return { x0, y0, x1, y1, w: x1 - x0, h: y1 - y0, cx: (x0 + x1) / 2, cy: (y0 + y1) / 2 };
}
function inPoly(P, px, py) {
  let c = false;
  for (let i = 0, j = P.length - 2; i < P.length; j = i, i += 2) { const yi = P[i + 1], yj = P[j + 1]; if ((yi > py) !== (yj > py) && px < (P[j] - P[i]) * (py - yi) / (yj - yi) + P[i]) c = !c; }
  return c;
}
// where a point sits on the shape's gradient (0 = first colour, 1 = second): along its axis, or out from a blob's middle
function gradT(q) {
  if (q.t === 'B') { const [cx, cy, rx, ry] = q.args, r = Math.max(1, (rx + ry) / 2); return (px, py) => clamp01(Math.hypot(px - cx, py - cy) / r); }
  const [dx, dy, m, n] = SHP.axis({ t: q.t, p: q.args }), inv = 1 / Math.max(1e-6, n - m);
  return (px, py) => clamp01((px * dx + py * dy - m) * inv);
}
// a gradient with many stops along the shape's own gradient (linear, or radial for blobs)
function gradOf(x, q, stops) {
  let G;
  if (q.t === 'B') { const [cx, cy, rx, ry] = q.args; G = x.createRadialGradient(cx, cy, 0, cx, cy, Math.max(1, (rx + ry) / 2)); }
  else { const [dx, dy, m, n] = SHP.axis({ t: q.t, p: q.args }); G = x.createLinearGradient(dx * m, dy * m, dx * n, dy * n); }
  for (const [o, c] of stops) G.addColorStop(clamp01(o), c);
  return G;
}
// fill the shape (or, for a stroke, stroke it) with a style
function fillShape(x, q, style) {
  const a = q.args;
  if (q.t === 'S') { x.strokeStyle = style; x.lineWidth = a[6]; x.lineCap = 'round'; x.beginPath(); x.moveTo(a[0], a[1]); x.quadraticCurveTo(a[2], a[3], a[4], a[5]); x.stroke(); return; }
  x.fillStyle = style; outlinePath(x, q); x.fill();
}
// ── stamped brush lines and layered washes ───────────────────────────────────────────────────────────────────────────
// After p5.brush by Alejandro Campos Uribe (MIT licence, https://github.com/acamposuribe/p5.brush), written again for this
// painter. stampLine: a path is walked in small steps and a tip stamped at each; the tip's size follows a pressure profile
// along the stroke (light, firm, light), the stamps scatter across the line, and a grain skips some of them, so a line breaks
// up like pencil or charcoal on paper. hobbsGrow: Tyler Hobbs' watercolour polygon: every edge gets a midpoint pushed
// sideways by a gaussian amount, again and again, so an outline frays into a natural, fractal edge.
const gaussR = R => (R() + R() + R() + R() - 2) * 1.732;
const STAMP_CACHE = new WeakMap();
// the stamps of one pass of one shape are made once and kept (a shape is drawn the same way every time)
function stampSet(q, id, make) {
  let m = STAMP_CACHE.get(q); if (!m) STAMP_CACHE.set(q, m = new Map());
  let v = m.get(id); if (!v) m.set(id, v = make()); return v;
}
// lines: one polyline or a list of them; o: { args, salt, w, spacing, scatter, sharp, grain, pmin, pmax, peak, hw, alpha, fast }
function stampBuild(lines, o) {
  const R = rngFor(o.args.slice(0, 6).map(v => (v || 0) + o.salt * 0.5)), A = new Path2D(), B = new Path2D(), w = o.w, st = [];
  const speed = o.fast ? 3 : 1, add = (Q, sx, sy, r, t) => { st.push(sx, sy, r, Q === A ? 0 : 1, t); if (r < 1.5) Q.rect(sx - r, sy - r, r * 2, r * 2); else { Q.moveTo(sx + r, sy); Q.arc(sx, sy, r, 0, 7); } };
  const all = typeof lines[0][0] === 'number' ? [lines] : lines; let li = -1;
  for (const P of all) { li++;
    const n = P.length; if (n < 2) continue;
    const cum = [0]; for (let i = 1; i < n; i++) cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
    const L = cum[n - 1]; if (L < 0.01) continue;
    const step = Math.max(o.minStep || 0.5, w * o.spacing * speed), steps = Math.min(o.fast ? 40 : (o.maxSteps || 240), Math.max(2, Math.ceil(L / step)));
    const peak = o.peak + (R() - 0.5) * 0.2, hw = o.hw * (0.85 + R() * 0.3), c = 1 + R() * 0.6;
    let j = 1;
    for (let k = 0; k <= steps; k++) {
      const t = k / steps, d = t * L; while (j < n - 1 && cum[j] < d) j++;
      const seg = cum[j] - cum[j - 1] || 1, f = (d - cum[j - 1]) / seg, tx = (P[j][0] - P[j - 1][0]) / seg, ty = (P[j][1] - P[j - 1][1]) / seg;
      const px = P[j - 1][0] + (P[j][0] - P[j - 1][0]) * f, py = P[j - 1][1] + (P[j][1] - P[j - 1][1]) * f;
      const pr = o.pmin + (o.pmax - o.pmin) / (1 + Math.pow(Math.abs((t - peak) / hw), 2 * c));       // pressure along the stroke
      if (R() < o.grain * (0.62 - 0.4 * Math.min(1, pr))) continue;                                    // grain: this stamp is skipped
      const sc = gaussR(R) * o.scatter * w * 0.5 * (1.15 - o.sharp * 0.5), par = (R() - 0.5) * step * speed;
      add(R() < 0.55 ? A : B, px - ty * sc + tx * par, py + tx * sc + ty * par, Math.max(0.4, w * 0.5 * (0.4 + 0.6 * Math.min(1.1, pr)) * (0.8 + R() * 0.4) * (o.fast ? 1.5 : 1)), (li + t) / all.length);
    }
  }
  return { A, B, st, base: o.alpha * (0.8 + R() * 0.2) };
}
// o.upto (0..1): only the stamps that far along are laid down — the line being drawn, at its finished quality
function stampLine(x, lines, o) {
  const set = o.q && !o.fast ? stampSet(o.q, o.id + (o.dir < 0 ? '~' : ''), () => stampBuild(lines, o)) : stampBuild(lines, o);
  let A = set.A, B = set.B;
  if (o.upto != null && o.upto < 1) {
    A = new Path2D(); B = new Path2D(); const S2 = set.st;
    for (let i = 0; i < S2.length; i += 5) {
      if (S2[i + 4] > o.upto) continue; const Q = S2[i + 3] ? B : A, sx = S2[i], sy = S2[i + 1], r = S2[i + 2];
      if (r < 1.5) Q.rect(sx - r, sy - r, r * 2, r * 2); else { Q.moveTo(sx + r, sy); Q.arc(sx, sy, r, 0, 7); }
    }
  }
  x.fillStyle = o.fill; x.globalAlpha = Math.min(1, set.base); x.fill(A); x.globalAlpha = Math.min(1, set.base * 0.5); x.fill(B);
}
function hobbsGrow(pts, R, sigma) {
  const out = [], n = pts.length;
  for (let i = 0; i < n; i++) {
    const p = pts[i], q = pts[(i + 1) % n], dx = q[0] - p[0], dy = q[1] - p[1], len = Math.hypot(dx, dy) || 1, d = gaussR(R) * sigma * len * p[2];
    out.push(p, [(p[0] + q[0]) / 2 - dy / len * d, (p[1] + q[1]) / 2 + dx / len * d, Math.max(0.25, Math.min(2, p[2] * (1 + gaussR(R) * 0.12)))]);
  }
  return out;
}
const WET_TILE = { cv: null, x: null };
// embroidery: the stitches of one shape, made once. A stroke gets satin stitches laid across it, one every pitch along its length, each leaning
// a little; a shape gets rows of long-and-short stitches (every other row staggered) running across it
function threadStitches(q, R) {
  const a = q.args, list = []; let tw, end;
  if (q.t === 'S') {
    const w = Math.max(3, a[6]), P = quadPts(a, 1, 1, 48), cum = [0];
    for (let i = 1; i < P.length; i++) cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
    const L = cum[cum.length - 1] || 1, pitch = Math.max(1.2, w * 0.3); tw = Math.max(1.3, pitch * 1.05); let j = 1;
    for (let d = 0; d <= L; d += pitch) {
      while (j < P.length - 1 && cum[j] < d) j++;
      const seg = cum[j] - cum[j - 1] || 1, f = (d - cum[j - 1]) / seg, tx = (P[j][0] - P[j - 1][0]) / seg, ty = (P[j][1] - P[j - 1][1]) / seg;
      const cx = P[j - 1][0] + (P[j][0] - P[j - 1][0]) * f, cy = P[j - 1][1] + (P[j][1] - P[j - 1][1]) * f, half = w / 2 * (0.9 + R() * 0.14), sl = pitch * 0.8;
      list.push({ x0: cx + ty * half - tx * sl * 0.5, y0: cy - tx * half - ty * sl * 0.5, x1: cx - ty * half + tx * sl * 0.5, y1: cy + tx * half + ty * sl * 0.5, t: d / L, b: Math.floor(R() * 4) });
    }
    end = [a[4], a[5]];
  } else {
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), ang = q.t === 'R' ? a[4] : R() * Math.PI, dx = Math.cos(ang), dy = Math.sin(ang), nx = -dy, ny = dx;
    const n = P.length / 2, U = [], V = [], ext = Math.hypot(b.w, b.h) / 2 + 1; let rowGap = Math.max(1.4, size * 0.035);
    for (let i = 0; i < n; i++) { const ox = P[i * 2] - b.cx, oy = P[i * 2 + 1] - b.cy; U.push(ox * dx + oy * dy); V.push(ox * nx + oy * ny); }
    for (let tries = 0; tries < 3; tries++) {
      list.length = 0; let row = 0;
      for (let r = -ext; r <= ext; r += rowGap, row++) {
        const xs = [];
        for (let i = 0; i < n; i++) { const k = (i + 1) % n, v0 = V[i], v1 = V[k]; if ((v0 - r) * (v1 - r) <= 0 && v0 !== v1) xs.push(U[i] + (r - v0) / (v1 - v0) * (U[k] - U[i])); }
        xs.sort((p, s2) => p - s2);
        for (let m = 0; m + 1 < xs.length; m += 2) {
          let p = xs[m]; const e = xs[m + 1], stitch = size * (0.14 + R() * 0.2); p += (row % 2 ? 0.55 : 0.15) * stitch * R();
          while (p < e - 0.2) {
            const p1 = Math.min(e, p + stitch * (0.8 + R() * 0.4)), ux0 = Math.max(xs[m], p), t = (r + ext) / (2 * ext);
            list.push({ x0: b.cx + ux0 * dx + r * nx, y0: b.cy + ux0 * dy + r * ny, x1: b.cx + p1 * dx + r * nx, y1: b.cy + p1 * dy + r * ny, t, b: Math.floor(R() * 4) });
            p = p1 + 0.01;
          }
        }
      }
      if (list.length <= 520) break; rowGap *= 1.5;
    }
    tw = rowGap * 1.08; end = [a[0], a[1]];
  }
  return { list, tw, end };
}
// a thread lit from the top left: a shadow under it, the body in a few shades, a thin highlight along it
function drawThread(x, st, u, c0, c1, o) {
  const shadow = new Path2D(), hi = new Path2D(), body = [new Path2D(), new Path2D(), new Path2D(), new Path2D()], tw = st.tw, hx = LIGHT.x * tw * 0.3, hy = LIGHT.y * tw * 0.3;
  for (const s of st.list) {
    if (s.t > u) break;
    shadow.moveTo(s.x0 - LIGHT.x * tw * 0.45, s.y0 - LIGHT.y * tw * 0.45); shadow.lineTo(s.x1 - LIGHT.x * tw * 0.45, s.y1 - LIGHT.y * tw * 0.45);
    body[s.b].moveTo(s.x0, s.y0); body[s.b].lineTo(s.x1, s.y1); hi.moveTo(s.x0 + hx, s.y0 + hy); hi.lineTo(s.x1 + hx, s.y1 + hy);
  }
  const mid = mixHex(c0, c1, 0.5); x.save(); x.lineCap = 'round'; x.lineJoin = 'round';
  x.globalAlpha = o * 0.55; x.strokeStyle = '#000'; x.lineWidth = tw * 1.3; x.stroke(shadow);
  [-0.12, 0.06, -0.22, 0.14].forEach((k, i) => { x.globalAlpha = o; x.strokeStyle = shade2(mid, k); x.lineWidth = tw; x.stroke(body[i]); });
  x.globalAlpha = o * 0.5; x.strokeStyle = '#fff'; x.lineWidth = Math.max(0.5, tw * 0.28); x.stroke(hi);
  x.restore();
}
// ── light, and helpers for the lit styles (hylics, glass, embroidery, and the relief materials) ────────────────────────
// LIGHT points from the picture towards the light (top left by default); the light pad in the style panel moves it.
const LIGHT = { x: -0.62, y: -0.78 };
// spray paint: the cap on the can (auto picks one by the stroke's width: skinny for lines, fat for most, soft for the
// biggest washes) and the surface it goes on
const SPRAY = { cap: 'auto', wall: 'none' };
const CAPS = {      // body / mist: the droplet cloud's and the overspray's width (× the stroke's) · a / mistA: how much paint each puts down
  skinny: { body: 1.3, mist: 2.3, a: 0.5, mistA: 0.22, splat: 0.25, drip: 0.22 },          // sharp lines, little overspray
  fat:    { body: 1.75, mist: 3.1, a: 0.44, mistA: 0.3, splat: 0.7, drip: 0.62 },          // broad, soft edged, overspray
  soft:   { body: 2.5, mist: 3.8, a: 0.3, mistA: 0.26, splat: 0.3, drip: 0.06 },           // a wide fade
  calli:  { body: 1.1, mist: 1.9, a: 0.36, mistA: 0.18, splat: 0.3, drip: 0.45, flat: 0.6 }  // a flat cap: wide or thin by direction
};
const capOf = w => SPRAY.cap !== 'auto' && CAPS[SPRAY.cap] ? SPRAY.cap : w < 9 ? 'skinny' : w > 38 ? 'soft' : 'fat';
const lightKey = () => LIGHT.x.toFixed(2) + ',' + LIGHT.y.toFixed(2);
// a colour pushed towards full saturation (hylics, neon)
function vivid(hex, k = 0.45) {
  const [r, g, b] = hexRgb(hex), m = (r + g + b) / 3;
  return SHP.hex([r, g, b].map(v => Math.max(0, Math.min(255, m + (v - m) * (1 + k)))));
}
// the outline of a shape as a path (a stroke's ribbon included), and a quick stand-in while it is still arriving
const outlineOf = q => { const P = SHP.poly({ t: q.t, p: q.args }), pa = new Path2D(); for (let i = 0; i < P.length; i += 2) pa[i ? 'lineTo' : 'moveTo'](P[i], P[i + 1]); pa.closePath(); return pa; };
function quickDraw(x, q, u, dir, col, alpha) {
  const a = q.args; x.save(); x.globalAlpha = alpha; x.lineCap = 'round';
  const end = shapePath(x, q, u, dir);
  if (q.t === 'S') { x.strokeStyle = col; x.lineWidth = a[6]; x.stroke(); } else { x.fillStyle = col; x.fill(); }
  x.restore(); return end;
}
const endOf = q => q.t === 'S' ? [q.args[4], q.args[5]] : [q.args[0], q.args[1]];
// what is on the canvas under a shape right now, copied to a small canvas, so glass can bend it (null when the canvas is turned)
const UNDER_TMP = { cv: null, x: null };
function underRegion(x, x0, y0, w, h) {
  const m = x.getTransform(); if (Math.abs(m.b) > 1e-6 || Math.abs(m.c) > 1e-6 || m.a <= 0 || m.d <= 0) return null;
  const sx = Math.floor(m.a * x0 + m.e), sy = Math.floor(m.d * y0 + m.f), cx0 = Math.max(0, sx), cy0 = Math.max(0, sy);
  const cx1 = Math.min(x.canvas.width, Math.ceil(m.a * (x0 + w) + m.e)), cy1 = Math.min(x.canvas.height, Math.ceil(m.d * (y0 + h) + m.f));
  const sw = cx1 - cx0, sh = cy1 - cy0; if (sw < 2 || sh < 2) return null;
  if (!UNDER_TMP.cv) { UNDER_TMP.cv = document.createElement('canvas'); UNDER_TMP.x = UNDER_TMP.cv.getContext('2d'); }
  if (UNDER_TMP.cv.width < sw || UNDER_TMP.cv.height < sh) { UNDER_TMP.cv.width = Math.max(UNDER_TMP.cv.width, sw); UNDER_TMP.cv.height = Math.max(UNDER_TMP.cv.height, sh); }
  UNDER_TMP.x.clearRect(0, 0, sw, sh); UNDER_TMP.x.drawImage(x.canvas, cx0, cy0, sw, sh, 0, 0, sw, sh);
  return { cv: UNDER_TMP.cv, sw, sh, x0: (cx0 - m.e) / m.a, y0: (cy0 - m.f) / m.d, w: sw / m.a, h: sh / m.d };
}
// a raised edge: the path stroked a few times, shifted towards (light) or away from the light, in narrowing bands
function litEdge(x, path, d, col, w0, alpha, towards) {
  const s = towards ? 1 : -1; x.translate(-LIGHT.x * d * s, -LIGHT.y * d * s); x.strokeStyle = col;
  for (let k = 0; k < 3; k++) { x.globalAlpha = alpha * 0.45; x.lineWidth = w0 * (1 - k * 0.36); x.stroke(path); }
  x.translate(LIGHT.x * d * s, LIGHT.y * d * s);
}
// embroidery yarn: short stitches laid in close rows (tatami fill), each a twisted thread
function yarnStitches(q, R) {
  const a = q.args, list = []; let tw;
  if (q.t === 'S') {
    const w = Math.max(3, a[6]), P = quadPts(a, 1, 1, 40), rows = Math.max(1, Math.round(w / 2.2)); tw = Math.max(1.4, w / rows * 1.15);
    for (let r = 0; r < rows; r++) {
      const off = (r + 0.5) / rows * w - w / 2, L = offsetPts(P, off), cum = [0];
      for (let i = 1; i < L.length; i++) cum.push(cum[i - 1] + Math.hypot(L[i][0] - L[i - 1][0], L[i][1] - L[i - 1][1]));
      const tot = cum[cum.length - 1], st = Math.max(2.5, tw * 2.6); let j = 1;
      for (let d = (r % 2) * st * 0.5; d < tot; d += st * (0.85 + R() * 0.3)) {
        const e = Math.min(tot, d + st), at = v => { while (j < L.length - 1 && cum[j] < v) j++; const k = j, f = (v - cum[k - 1]) / ((cum[k] - cum[k - 1]) || 1); return [L[k - 1][0] + (L[k][0] - L[k - 1][0]) * f, L[k - 1][1] + (L[k][1] - L[k - 1][1]) * f]; };
        j = 1; const p0 = at(d); j = 1; const p1 = at(e);
        list.push({ x0: p0[0], y0: p0[1], x1: p1[0], y1: p1[1], t: d / tot, b: Math.floor(R() * 4) });
      }
    }
    list.sort((p, s2) => p.t - s2.t);
  } else {
    const st = threadStitches(q, R); tw = st.tw * 0.8;
    for (const s of st.list) {           // the long stitches of the fill cut into short ones, like a machine lays them
      const len = Math.hypot(s.x1 - s.x0, s.y1 - s.y0), n = Math.max(1, Math.round(len / Math.max(2.5, tw * 2.6)));
      for (let k = 0; k < n; k++) list.push({ x0: s.x0 + (s.x1 - s.x0) * k / n, y0: s.y0 + (s.y1 - s.y0) * k / n, x1: s.x0 + (s.x1 - s.x0) * (k + 1) / n, y1: s.y0 + (s.y1 - s.y0) * (k + 1) / n, t: s.t, b: Math.floor(R() * 4) });
    }
  }
  return { list, tw, end: endOf(q) };
}
// a twisted yarn: its shadow, the body in a few shades, and the twist: little slanted ridges of light along it (with dark between)
function drawYarn(x, st, u, c0, c1, o) {
  const tw = st.tw, shadow = new Path2D(), lite = new Path2D(), dark = new Path2D(), body = [new Path2D(), new Path2D(), new Path2D(), new Path2D()];
  for (const s of st.list) {
    if (s.t > u) break;
    shadow.moveTo(s.x0 - LIGHT.x * tw * 0.35, s.y0 - LIGHT.y * tw * 0.35); shadow.lineTo(s.x1 - LIGHT.x * tw * 0.35, s.y1 - LIGHT.y * tw * 0.35);
    body[s.b].moveTo(s.x0, s.y0); body[s.b].lineTo(s.x1, s.y1);
    const dx = s.x1 - s.x0, dy = s.y1 - s.y0, len = Math.hypot(dx, dy) || 1, tx = dx / len, ty = dy / len, nx = -ty, ny = tx, k = Math.max(1, Math.round(len / (tw * 0.9)));
    for (let i = 0; i < k; i++) {
      const f = (i + 0.5) / k, px = s.x0 + dx * f, py = s.y0 + dy * f, h = tw * 0.42, sl = tw * 0.35;
      lite.moveTo(px - nx * h - tx * sl, py - ny * h - ty * sl); lite.lineTo(px + nx * h + tx * sl, py + ny * h + ty * sl);
      dark.moveTo(px - nx * h - tx * sl + tx * tw * 0.45, py - ny * h - ty * sl + ty * tw * 0.45); dark.lineTo(px + nx * h + tx * sl + tx * tw * 0.45, py + ny * h + ty * sl + ty * tw * 0.45);
    }
  }
  const mid = mixHex(c0, c1, 0.5); x.save(); x.lineCap = 'round';
  x.globalAlpha = o * 0.5; x.strokeStyle = '#000'; x.lineWidth = tw * 1.2; x.stroke(shadow);
  [[c0, 0.04], [c1, -0.1], [mid, 0.12], [mid, -0.2]].forEach(([c, k], i) => { x.globalAlpha = o; x.strokeStyle = shade2(c, k); x.lineWidth = tw; x.stroke(body[i]); });
  x.lineCap = 'butt'; x.globalAlpha = o * 0.32; x.strokeStyle = '#000'; x.lineWidth = Math.max(0.4, tw * 0.16); x.stroke(dark);
  x.globalAlpha = o * 0.5; x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(0.4, tw * 0.2); x.stroke(lite);
  x.restore();
}
// ── relief: materials with real height ───────────────────────────────────────────────────────────────────────────────
// The relief styles don't paint a picture of a rope, they build one. Every stroke raises a rope into a height map (round
// in section, lying on top of what is already there, or fused with it), every shape a rounded slab; a material is noted
// for each pixel. The page then lights the whole relief at once on the graphics card (WebGL 2): normals from the height,
// shadows cast along the light, darker hollows, and each material's own surface (glaze, grain, polished or rough metal…).
// Moving the light only relights; nothing is drawn again. Without WebGL 2 (or in endless zoom) the ropes are drawn flat.
// Inspired by the relief brushes of Vooolume (krftoools) and the Glazed Ceramic / Stone / Kinetic Metal / Volumetric Foam /
// Modeling Clay brushes; written from scratch for this painter.
const RELIEF = {
  //        id  layer: how far a rope lies on what is under it (1: on top, 0: fused into one mass); fuse: how softly they melt
  //            together (px); hk: height of a rope against its radius; bead: how the rope is built; taper: pointed ends
  ceramic:  { id: 1, layer: 0.55, fuse: 1, hk: 0.95, taper: 0.35 },
  stone:    { id: 2, layer: 0.1, fuse: 7, hk: 0.75 },
  metal:    { id: 3, layer: 0.5, fuse: 2, hk: 0.95, taper: 0.2 },
  foam:     { id: 4, layer: 0.75, fuse: 0, hk: 1, bead: 'foam' },
  plast:    { id: 5, layer: 0.35, fuse: 3, hk: 0.65 },
  molten:   { id: 6, layer: 0.35, fuse: 5, hk: 0.9, taper: 0.45 },
  pewter:   { id: 7, layer: 0.45, fuse: 2, hk: 0.85 },
  terrazzo: { id: 8, layer: 0.25, fuse: 5, hk: 0.7 },
  copper:   { id: 9, layer: 0.5, fuse: 2, hk: 0.9 },
  gold:     { id: 10, layer: 0.5, fuse: 2, hk: 0.9, taper: 0.2 },
  bronze:   { id: 11, layer: 0.45, fuse: 3, hk: 0.85 },
  beads:    { id: 12, layer: 0.75, fuse: 0, hk: 1, bead: 'chain' },
  puffy:    { id: 13, layer: 0.5, fuse: 2, hk: 1.15, puff: true },
  // paint with body (a bristle brush, see reliefBristle): thick oil, flatter acrylic, a palette knife
  oil:      { id: 14, layer: 0.55, fuse: 0, hk: 1, bristle: 'oil', thick: 0.62 },
  acrylic:  { id: 15, layer: 0.5, fuse: 0, hk: 1, bristle: 'acrylic', thick: 0.32 },
  knife:    { id: 16, layer: 0.5, fuse: 1, hk: 1, bristle: 'knife', thick: 0.6 },
  // clear materials (see reliefClear): what lies under them is bent through their surface by the shader
  glass:    { id: 17, clear: 'glass', layer: 0.5, fuse: 0, hk: 1 },
  lens:     { id: 18, clear: 'lens', layer: 0.5, fuse: 0, hk: 1 },
  crystal:  { id: 19, clear: 'crystal', layer: 0.5, fuse: 0, hk: 1 }
};
const RELIEF_TINT = { molten: '#d6d8dc', pewter: '#6d6f73', copper: '#b8673f', gold: '#e2b04a', bronze: '#8a6236', puffy: '#151517' };
let GLR = null;                         // the WebGL renderer (made the first time; false when there is none)
const RLF = { on: false, st: null };    // the live relief of the painting being made (S.out), when one is in use
const reliefMode = () => S.mode === 'auto' || (S.mode === 'replay' && !!S.mix);     // pictures, videos, zooms, and a replay's live strokes
const reliefOk = () => reliefMode() && !!reliefGL();
// a relief: albedo (a 2D canvas: the colours), height (px, float) and material per pixel, at a scale k of the painting
// (k: painting → relief pixels; u: the size of a relief pixel against a 1000 px painting, so ropes look the same at any size)
function makeRelief(w, h, k, u = k) {
  const alb = document.createElement('canvas'); alb.width = w; alb.height = h;
  return { w, h, k, u, alb, ax: alb.getContext('2d'), H: new Float32Array(w * h), M: new Uint8Array(w * h), D: new Uint8Array(w * h), dirty: true, last: 0, added: 0 };     // (D: the stroke's direction, 0..π as 0..255)
}
function reliefStart() {
  const R = makeRelief(S.out.width, S.out.height, 1, Math.max(S.out.width, S.out.height) / 1000);
  R.ax.drawImage(S.out, 0, 0);                       // what is painted so far becomes the flat ground
  R.out = S.out; RLF.st = R; RLF.on = true; RLF.last = 0;
}
function reliefStop() { RLF.on = false; RLF.st = null; }
// a shape into a relief: relief styles raise ropes / slabs, the others are painted on (and paint over the material)
function reliefAdd(R, q) {
  const fp = fillParts(q); if (fp) { for (const p of fp) reliefAdd(R, p); return; }
  // the older layers settle a little as new ones go on (a long painting would otherwise build into one flat sheet at the
  // height cap, with new strokes hardly standing out)
  if (!R.scratch && !q.strand && !q.sub && ++R.added >= 32) { R.added = 0; const H = R.H; for (let i = 0; i < H.length; i++) H[i] *= 0.985; }
  const m = RELIEF[q.st], x = R.ax;
  x.setTransform(R.k, 0, 0, R.k, 0, 0);
  if (m && m.clear) { x.setTransform(1, 0, 0, 1, 0, 0); reliefClear(R, q, m); R.dirty = true; return; }
  if (m && !m.bristle && q.t === 'S' && !q.strand && q.args[6] * R.k > 70 * R.u) { for (const sq of strandsOf(q, R)) reliefAdd(R, sq); x.setTransform(1, 0, 0, 1, 0, 0); R.dirty = true; return; }
  if (m && m.bristle) for (const sq of q.t === 'S' ? [q] : bristleFill(q)) reliefBristle(R, sq, m);
  else if (m) {
    reliefAlbedo(x, q, m);
    if (q.t === 'S') reliefRope(R, q, m); else reliefSlab(R, q, m);
  } else { drawQ(x, q); reliefPaint(R, q); }
  x.setTransform(1, 0, 0, 1, 0, 0); R.dirty = true;
}
// a wide rope of a material would only be a flat-topped band (the height of a rope is capped): it is laid as a bundle
// of strands side by side instead, a little uneven in width and length, so it keeps its roundness at any size
function strandsOf(q, R) {
  const a = q.args, rnd = rngFor(q.seed || a), w = a[6], n = Math.min(3, Math.ceil(w * R.k / (60 * R.u))), out = [];     // (two or three fat strands that melt together, not a bundle of lines)
  const nrm = (ax, ay, bx, by) => { const dx = bx - ax, dy = by - ay, l = Math.hypot(dx, dy) || 1; return [-dy / l, dx / l]; };
  const n0 = nrm(a[0], a[1], a[2], a[3]), n1 = nrm(a[0], a[1], a[4], a[5]), n2 = nrm(a[2], a[3], a[4], a[5]);
  for (let i = 0; i < n; i++) {
    const off = ((i + 0.5) / n - 0.5) * w * 0.7 + (rnd() - 0.5) * w / n * 0.3, sw = w / n * (1.35 + rnd() * 0.3), pt = q.part || 1, s0 = Math.min(0.5, rnd() * 0.08 / pt), r1 = rnd(), s1 = pt < 1 ? 1 : 1 - r1 * 0.08;     // (trims measured on the whole stroke)
    const A = [a[0] + n0[0] * off, a[1] + n0[1] * off], C = [a[2] + n1[0] * off * (1 + (rnd() - 0.5) * 0.2), a[3] + n1[1] * off], B = [a[4] + n2[0] * off, a[5] + n2[1] * off];
    const at = t => { const u = 1 - t; return [u * u * A[0] + 2 * u * t * C[0] + t * t * B[0], u * u * A[1] + 2 * u * t * C[1] + t * t * B[1]]; };
    const p0 = at(s0), p2 = at(s1), pm = at((s0 + s1) / 2), cx = 2 * pm[0] - (p0[0] + p2[0]) / 2, cy = 2 * pm[1] - (p0[1] + p2[1]) / 2;
    out.push({ ...q, strand: true, args: [p0[0], p0[1], cx, cy, p2[0], p2[1], sw, ...a.slice(7)], seed: [...(q.seed || a).slice(0, 6).map(v => v + i * 7.3), i] });
  }
  return out;
}
// ── paint with body: a bristle brush laid into the relief (oil, acrylic, palette knife) ──
// The stroke is a band of bristles. Each bristle carries its own colour (the brush loaded with both of the stroke's
// colours, side by side, a little uneven), leaves its own ridge, and runs dry somewhere towards the end, so the tail
// breaks up into separate tracks with the ground showing between them. The start is thicker (where the loaded brush
// touched down). A palette knife instead lays a flat slab with sharp raised edges and only faint scrape lines.
function bristleSet(q, m, rnd, r) {
  const knife = m.bristle === 'knife', n = Math.max(4, Math.min(16, Math.round(r / (knife ? 5 : 3.2)))), b = [];
  // clumps of bristles: uneven widths (edges from 0 to 1 across the band), some carrying more paint than others
  const cuts = [0]; for (let i = 1; i < n; i++) cuts.push(i / n + (rnd() - 0.5) * 0.6 / n); cuts.push(1);
  for (let i = 0; i < n; i++) b.push({ lo: cuts[i], hi: cuts[i + 1], amp: 0.35 + 0.65 * rnd(), end: knife ? 0.82 + 0.18 * rnd() : 0.55 + 0.45 * Math.pow(rnd(), 0.5), tone: (rnd() - 0.5) * 0.12, mixAt: Math.min(1, Math.max(0, (i + 0.5) / n + (rnd() - 0.5) * 0.3)) });
  return b;
}
// an area in paint: filled the way a painter fills it, with brush strokes side by side across it (each ending at its edge)
function bristleFill(q) {
  const a = q.args, P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), [c0, c1, o] = colsOf(q), R = rngFor(a);
  const an = (q.t === 'E' || q.t === 'B' || q.t === 'R' ? a[4] : R() * Math.PI) + (R() - 0.5) * 0.4, dx = Math.cos(an), dy = Math.sin(an), nx = -dy, ny = dx;
  let lo = 1e9, hi = -1e9, lo2 = 1e9, hi2 = -1e9;
  for (let i = 0; i < P.length; i += 2) { const u = P[i] * nx + P[i + 1] * ny, v = P[i] * dx + P[i + 1] * dy; lo = Math.min(lo, u); hi = Math.max(hi, u); lo2 = Math.min(lo2, v); hi2 = Math.max(hi2, v); }
  const across = hi - lo, sw = Math.max(3, Math.min(across / 2.2, Math.max(b.w, b.h) / 3)), n = Math.max(1, Math.ceil(across / (sw * 0.8))), out = [];
  for (let k = 0; k < n; k++) {
    const u = lo + (k + 0.5) * across / n + (R() - 0.5) * sw * 0.3; let f = null, l = null;
    for (let j = 0; j <= 40; j++) { const v = lo2 + (hi2 - lo2) * j / 40, px = nx * u + dx * v, py = ny * u + dy * v; if (inPoly(P, px, py)) { if (!f) f = [px, py]; l = [px, py]; } }
    if (!f || Math.hypot(l[0] - f[0], l[1] - f[1]) < sw * 0.5) continue;
    const flip = (k + (R() < 0.3 ? 1 : 0)) % 2, A = flip ? l : f, B = flip ? f : l, bend = (R() - 0.5) * sw * 0.6;
    const t = k / Math.max(1, n - 1), ca = mixHex(c0, c1, t), cb = mixHex(c0, c1, Math.min(1, t + 0.25));
    out.push({ t: 'S', st: q.st, args: [A[0], A[1], (A[0] + B[0]) / 2 + nx * bend, (A[1] + B[1]) / 2 + ny * bend, B[0], B[1], sw, an, ca, cb, o], seed: [a[0] + k * 7.1, a[1] + k * 3.3, a[2], a[3], k, 1] });
  }
  return out;
}
function reliefBristle(R, q, m) {
  const a = q.args, rnd = rngFor(q.seed || q.args), P = quadPts(a, 1, 1, 48), part = q.part || 1, knife = m.bristle === 'knife';
  const k = R.k, r = Math.max(1.5, a[6] * k / 2), cum = [0];
  for (let i = 1; i < P.length; i++) cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
  const tot = cum[cum.length - 1] || 1, pts = P.map((p, i) => ({ x: p[0] * k, y: p[1] * k, s: cum[i] / tot * part }));
  const B = bristleSet(q, m, rnd, r), N = B.length;
  // the ground under it, smoothed along the stroke
  const top = 18 * R.u, base = pts.map(p => Math.min(top, hAt(R, p.x, p.y) * m.layer));
  for (let pass = 0; pass < 12; pass++) for (let i = 1; i < base.length - 1; i++) base[i] = (base[i - 1] + base[i] * 2 + base[i + 1]) / 4;
  if (knife) { const mean = base.reduce((v, b) => v + b, 0) / base.length; base.fill(mean * 0.85); }   // (a knife rides one flat plane: what stands above it is scraped over)
  // the brush's shape: a knife narrows to its tip; acrylic is a flat (a chisel held at one angle by the hand: wide when it moves
  // across its edge, thin when it moves along it, square ends); oil is a filbert (even width, a rounded tip)
  const acr = m.bristle === 'acrylic', nib = 0.7 + (rnd() - 0.5) * 0.35;
  const wv = pts.map((p, i) => {
    if (knife) return 1.12 - 0.42 * p.s;
    if (!acr) return 1;
    const A = pts[Math.max(0, i - 1)], C = pts[Math.min(pts.length - 1, i + 1)];
    return 0.2 + 0.8 * Math.abs(Math.sin(Math.atan2(C.y - A.y, C.x - A.x) - nib));
  });
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const p of pts) { x0 = Math.min(x0, p.x - r); y0 = Math.min(y0, p.y - r); x1 = Math.max(x1, p.x + r); y1 = Math.max(y1, p.y + r); }
  x0 = Math.max(0, Math.floor(x0) - 1); y0 = Math.max(0, Math.floor(y0) - 1); x1 = Math.min(R.w - 1, Math.ceil(x1) + 1); y1 = Math.min(R.h - 1, Math.ceil(y1) + 1);
  const pw = x1 - x0 + 1, ph = y1 - y0 + 1; if (pw <= 0 || ph <= 0) return;
  const oilB = m.bristle === 'oil', patch = new Float32Array(pw * ph), near = new Float32Array(pw * ph).fill(1e9), cap = 13 * R.u, hr = (r < cap ? r : cap + (r - cap) * 0.2) * m.hk * m.thick;   // (each pixel from the nearest piece of the stroke)
  for (let i = 0; i < pts.length - 1; i++) {
    const A = pts[i], C = pts[i + 1], ex = C.x - A.x, ey = C.y - A.y, L2 = ex * ex + ey * ey || 1e-6, L = Math.sqrt(L2);
    const bx0 = Math.max(x0, Math.floor(Math.min(A.x, C.x) - r)), bx1 = Math.min(x1, Math.ceil(Math.max(A.x, C.x) + r)), by0 = Math.max(y0, Math.floor(Math.min(A.y, C.y) - r)), by1 = Math.min(y1, Math.ceil(Math.max(A.y, C.y) + r));
    for (let y = by0; y <= by1; y++) for (let x = bx0; x <= bx1; x++) {
      // (flat ends at the stroke's two ends; between pieces, the joins are filled from both sides)
      let t = ((x - A.x) * ex + (y - A.y) * ey) / L2; if ((!oilB && ((i === 0 && t < 0) || (i === pts.length - 2 && t > 1))) || t < -0.6 || t > 1.6) continue;     // (oil: the filbert's round tip)
      const tc = t < 0 ? 0 : t > 1 ? 1 : t, px = A.x + ex * tc, py = A.y + ey * tc, dd = Math.hypot(x - px, y - py), o = (y - y0) * pw + x - x0, rl = r * (wv[i] + (wv[i + 1] - wv[i]) * tc); if (dd >= rl || dd >= near[o]) continue; near[o] = dd;
      const tt = Math.sign(ex * (y - A.y) - ey * (x - A.x)) * dd / rl; t = tc;
      const s = A.s + (C.s - A.s) * t, uu = (tt + 1) / 2; let kk = 0; while (kk < N - 1 && uu > B[kk].hi) kk++;
      const br = B[kk], f = Math.max(0, Math.min(1, (uu - br.lo) / Math.max(1e-3, br.hi - br.lo)));
      const dry = s > br.end ? 0 : s > br.end - 0.1 ? (br.end - s) / 0.1 : 1; if (dry <= 0) { patch[o] = 0; continue; }
      const lead = Math.min(1, s / 0.06), start = Math.min(1, 0.35 + lead);       // (the first touch: rounder, then the full band)
      const edge = 1 - Math.pow(Math.abs(tt), knife ? 16 : 4), load = knife ? 1 : 1.25 - 0.5 * s, ridge = (0.5 - 0.5 * Math.cos(2 * Math.PI * f)) * br.amp;     // (smooth-shouldered ridges, no sharp grooves)
      let h = hr * edge * load * start * dry;
      if (oilB) {        // oil: a soft domed body of wet paint, a little lip at each edge, fine bristle streaks that wander, a pile where it lifts
        const wide = Math.min(1, rl / (24 * R.u)), dome = Math.sqrt(Math.max(0, 1 - Math.pow(Math.abs(tt), 2 + 6 * wide))), lip = (0.18 - 0.1 * wide) * Math.exp(-(((Math.abs(tt) - 0.86) / 0.08) ** 2));     // (a wide wash lies flatter: a plateau with rounded shoulders)
        // (bristle marks a few pixels apart whatever the brush's size — a big brush gets more of them, never bigger ones — uneven, and wandering a little)
        const qq = tt * rl / (2.2 * R.u) + 1.3 * Math.sin(s * 6 + br.amp * 5), i0 = Math.floor(qq), ff = qq - i0, hh = v => { const z = Math.sin(v * 127.1 + br.amp * 311.7) * 43758.5453; return z - Math.floor(z); };
        const streak = hh(i0) + (hh(i0 + 1) - hh(i0)) * ff * ff * (3 - 2 * ff);
        const pile = 0.28 * Math.exp(-(((s - br.end + 0.04) / 0.045) ** 2));
        h = hr * load * start * dry * (0.85 * dome + lip + 0.07 * streak * dome + pile);
      } else h *= knife ? 0.92 + 0.08 * ridge : acr ? 0.94 + 0.06 * ridge : 0.8 + 0.2 * ridge;
      if (knife) h = hr * 0.75 * edge * dry * start + hr * 0.4 * Math.exp(-(((Math.abs(tt) - 0.92) / 0.05) ** 2)) * dry; // flat, and the raised edges
      patch[o] = base[i] + (base[i + 1] - base[i]) * t + h;
    }
  }
  let skip = null;
  if (knife) { skip = new Uint8ClampedArray(pw * ph * 4); for (let y = 0; y < ph; y++) for (let x = 0; x < pw; x++) { const o = y * pw + x; if (patch[o] > 0 && R.H[(y + y0) * R.w + x + x0] > patch[o] + 0.3) skip[o * 4 + 3] = 255; } }
  reliefMerge(R, patch, x0, y0, pw, ph, m, Math.atan2(a[5] - a[1], a[4] - a[0]));
  // what was there before (oil drags it along, a knife leaves it where it scraped over)
  const ax = R.ax, before = (m.bristle === 'oil' || knife) ? copyRegion(R.alb, x0, y0, pw, ph) : null;
  // the colours: each bristle a line of its own colour, as far as it carried paint
  const [c0, c1] = colsOf(q); ax.save(); ax.setTransform(1, 0, 0, 1, 0, 0); ax.lineCap = 'butt'; ax.lineJoin = 'round';
  const P1 = pts.map(p => [p.x, p.y]), N1 = offsetPts(P1, 1), side = sg => P1.map((p, i) => { const w2 = r * wv[i] * sg; return [p[0] + (N1[i][0] - p[0]) * w2, p[1] + (N1[i][1] - p[1]) * w2]; });
  const fill = new Path2D(), Lp = side(1), Rp = side(-1);
  const shortest = Math.min(...B.map(b => b.end)), upto = pts.findIndex(p => p.s > shortest); const nFill = upto < 0 ? pts.length : Math.max(2, upto);
  for (let i = 0; i < nFill; i++) fill[i ? 'lineTo' : 'moveTo'](Lp[i][0], Lp[i][1]); for (let i = nFill - 1; i >= 0; i--) fill.lineTo(Rp[i][0], Rp[i][1]); fill.closePath();
  const oil = m.bristle === 'oil', dx = (pts[pts.length - 1].x - pts[0].x), dy = (pts[pts.length - 1].y - pts[0].y), dl = Math.hypot(dx, dy) || 1;
  if (knife) { const G = ax.createLinearGradient(pts[0].x, pts[0].y, pts[pts.length - 1].x, pts[pts.length - 1].y); G.addColorStop(0, c0); G.addColorStop(0.5, mixHex(c0, c1, 0.6)); G.addColorStop(1, c1); ax.fillStyle = G; }     // (a knife smears its two colours into each other)
  else if (oil) {      // (oil: the two colours blend softly across the brush, wet into each other)
    const mi = Math.floor(pts.length / 2), mp = P1[mi], mn = N1[mi], G = ax.createLinearGradient(mp[0] + (mn[0] - mp[0]) * r, mp[1] + (mn[1] - mp[1]) * r, mp[0] - (mn[0] - mp[0]) * r, mp[1] - (mn[1] - mp[1]) * r);
    G.addColorStop(0, c0); G.addColorStop(0.5, mixHex(c0, c1, 0.5)); G.addColorStop(1, c1); ax.fillStyle = G;
  } else ax.fillStyle = mixHex(c0, c1, 0.5);
  ax.fill(fill); ax.lineCap = 'round';
  const line = (off, from, upto, col, lw, al) => { const L = offsetPts(pts.map(p => [p.x, p.y]), off); ax.globalAlpha = al; ax.strokeStyle = col; ax.lineWidth = lw; ax.beginPath(); let st = false; for (let i = 0; i < pts.length && pts[i].s <= upto; i++) { if (pts[i].s < from) continue; ax[st ? 'lineTo' : 'moveTo'](L[i][0], L[i][1]); st = true; } ax.stroke(); };
  if (knife) {                                   // a palette knife: one flat colour, a couple of long scrape marks
    for (let j = 0; j < 3; j++) { const v = rnd(); line((v * 2 - 1) * r * 0.8, 0, 1, shade2(mixHex(c0, c1, v), rnd() < 0.5 ? 0.12 : -0.12), Math.max(0.6, r * 0.04), 0.3); }
  } else {
    for (let j = 0; j < N; j++) {               // the two colours, side by side; oil thins out along the stroke (the wet paint under it shows through)
      const br = B[j], mid = (br.lo + br.hi) / 2, col = shade2(mixHex(c0, c1, acr ? 0.5 + 0.5 * Math.tanh((mid - 0.5) * 9) : mid), br.tone * (acr ? 0.3 : 0.6)), off = ((br.lo + br.hi) - 1) * r, lw = (br.hi - br.lo) * 2 * r * 1.2;     // (acrylic: a double-loaded flat, the two colours crisp side by side)
      if (acr) {                                   // (a flat: each band of the brush a ribbon that narrows and widens with the chisel)
        const rb = new Path2D(), ii = []; for (let i = 0; i < pts.length && pts[i].s <= br.end; i++) ii.push(i);
        if (ii.length < 2) continue;
        const at = (i, v) => { const w2 = r * wv[i] * (v * 2 - 1); return [P1[i][0] + (N1[i][0] - P1[i][0]) * w2, P1[i][1] + (N1[i][1] - P1[i][1]) * w2]; };
        ii.forEach((i, k) => { const q2 = at(i, br.lo); rb[k ? 'lineTo' : 'moveTo'](q2[0], q2[1]); }); for (let k = ii.length - 1; k >= 0; k--) { const q2 = at(ii[k], br.hi); rb.lineTo(q2[0], q2[1]); } rb.closePath();
        ax.globalAlpha = 1; ax.fillStyle = col; ax.fill(rb); continue;
      }
      if (oil) { line(off, 0, br.end * 0.6, col, lw * 0.7, 0.32); line(off, br.end * 0.55, br.end, col, lw * 0.6, 0.22); }     // (faint: the colour is in the blend, the bristles only streak it)
      else line(off, 0, br.end, col, lw, 1);
    }
    const hairs = acr ? 0 : Math.min(40, Math.round(r * 0.9));
    for (let j = 0; j < hairs; j++) { const v = rnd(), br = B[Math.min(N - 1, Math.floor(v * N))]; line((v * 2 - 1) * r * 0.95, 0, br.end * (0.85 + 0.15 * rnd()), rnd() < 0.5 ? shade2(mixHex(c0, c1, v), 0.16) : shade2(mixHex(c0, c1, v), -0.16), Math.max(0.6, r * 0.04), oil ? 0.16 : 0.2); }   // fine streaks
  }
  if (before && (oil || knife)) {                // wet-in-wet: the paint that was there dragged along inside the stroke
    ax.save(); ax.clip(fill);
    for (let kk = 1; kk <= (oil ? 3 : 2); kk++) { ax.globalAlpha = oil ? 0.16 : 0.12; ax.drawImage(before, x0 + dx / dl * r * 0.55 * kk, y0 + dy / dl * r * 0.55 * kk); }
    ax.restore();
  }
  ax.globalAlpha = 1;
  if (skip && before) {                          // the knife skipped over the high spots: the old paint shows there
    const mk = document.createElement('canvas'); mk.width = pw; mk.height = ph; mk.getContext('2d').putImageData(new ImageData(skip, pw, ph), 0, 0);
    const bx = before.getContext('2d'); bx.globalCompositeOperation = 'destination-in'; bx.drawImage(mk, 0, 0); bx.globalCompositeOperation = 'source-over';
    ax.globalAlpha = 0.6; ax.drawImage(before, x0, y0); ax.globalAlpha = 1;
  }
  ax.restore();
}
// a copy of part of a canvas (GPU to GPU, no read-back)
function copyRegion(cv, x0, y0, w, h) { const c = document.createElement('canvas'); c.width = Math.max(1, w); c.height = Math.max(1, h); c.getContext('2d').drawImage(cv, x0, y0, w, h, 0, 0, w, h); return c; }
// the rope's points along its curve, each with a radius (tapered, or beaded) — in relief pixels
function ropePts(q, m, k, rnd) {
  const a = q.args, P = quadPts(a, 1, 1, 64), cum = [0];
  for (let i = 1; i < P.length; i++) cum.push(cum[i - 1] + Math.hypot(P[i][0] - P[i - 1][0], P[i][1] - P[i - 1][1]));
  const len = cum[cum.length - 1] * k, R0 = Math.max(1.2, a[6] * k / 2), out = [];
  const at = s => { let j = 1; while (j < cum.length - 1 && cum[j] < s) j++; const f = (s - cum[j - 1]) / ((cum[j] - cum[j - 1]) || 1); return [(P[j - 1][0] + (P[j][0] - P[j - 1][0]) * f) * k, (P[j - 1][1] + (P[j][1] - P[j - 1][1]) * f) * k]; };
  if (m.bead) {                                        // spheres along the curve: foam (bulbous, irregular), chain (even beads)
    const chain = m.bead === 'chain', r = chain ? Math.max(1.5, R0 * 0.9) : R0, step = chain ? r * 1.9 : r * 1.05;
    for (let s = 0; s <= len / k + 1e-6; s += step / k) {
      const p = at(s), rr = chain ? r : r * (0.72 + 0.5 * rnd());
      out.push({ x: p[0], y: p[1], r: rr, s: s * k / (len || 1) });
      if (step / k <= 0) break;
    }
    if (!out.length) { const p = at(0); out.push({ x: p[0], y: p[1], r: R0, s: 0 }); }
    return { pts: out, beads: true, R0 };
  }
  const n = Math.max(2, Math.min(80, Math.ceil(len / Math.max(1.5, R0 * 0.5))));
  for (let i = 0; i <= n; i++) {
    const s = i / n, p = at(s * cum[cum.length - 1]); let r = R0;
    if (m.taper) { const sf = s * (q.part || 1), e = Math.min(sf, 1 - sf) / m.taper; if (e < 1) r *= 0.35 + 0.65 * Math.sqrt(Math.max(0, e)); }     // (measured on the whole stroke: a rope being drawn has no tip yet, so nothing changes when it lands)
    out.push({ x: p[0], y: p[1], r, s });
  }
  return { pts: out, beads: false, R0 };
}
const hAt = (R, x, y) => { const i = Math.round(x), j = Math.round(y); return i < 0 || j < 0 || i >= R.w || j >= R.h ? 0 : R.H[j * R.w + i]; };
// raise a rope: the patch of new height (max over its pieces), each piece lying on the ground under it (smoothed along
// the rope), then melted into what is there
function reliefRope(R, q, m) {
  const rnd = rngFor(q.seed || q.args), { pts, beads, R0 } = ropePts(q, m, R.k, rnd);
  // what the rope lies on: the height under each point, smoothed along it
  const top = 18 * R.u, base = pts.map(p => Math.min(top, hAt(R, p.x, p.y)) * Math.max(m.layer, 0.85));     // (on the surface, capped: a long video doesn't pile up for ever)
  const sm = Math.max(3, Math.min(40, Math.round(R0 * 2.5 / Math.max(1, (pts.length > 1 ? Math.hypot(pts[1].x - pts[0].x, pts[1].y - pts[0].y) : 1)))));
  for (let pass = 0; pass < sm; pass++) for (let i = 1; i < base.length - 1; i++) base[i] = (base[i - 1] + base[i] * 2 + base[i + 1]) / 4;
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const p of pts) { x0 = Math.min(x0, p.x - p.r); y0 = Math.min(y0, p.y - p.r); x1 = Math.max(x1, p.x + p.r); y1 = Math.max(y1, p.y + p.r); }
  x0 = Math.max(0, Math.floor(x0) - 1); y0 = Math.max(0, Math.floor(y0) - 1); x1 = Math.min(R.w - 1, Math.ceil(x1) + 1); y1 = Math.min(R.h - 1, Math.ceil(y1) + 1);
  const pw = x1 - x0 + 1, ph = y1 - y0 + 1; if (pw <= 0 || ph <= 0) return;
  const patch = new Float32Array(pw * ph), hk = m.hk, puff = m.puff, cap = 13 * R.u;
  // the rope's section: round while thin, a flattened ellipse when wide (so the big first strokes don't tower)
  const prof = (r, d2) => { const v = Math.sqrt(Math.max(0, 1 - d2 / (r * r))), hr = r < cap ? r : cap + (r - cap) * 0.25; return hr * (puff ? Math.pow(v, 0.55) : v); };
  if (beads) {
    for (let i = 0; i < pts.length; i++) {
      const p = pts[i], b = base[i], bx0 = Math.max(x0, Math.floor(p.x - p.r)), bx1 = Math.min(x1, Math.ceil(p.x + p.r)), by0 = Math.max(y0, Math.floor(p.y - p.r)), by1 = Math.min(y1, Math.ceil(p.y + p.r));
      for (let y = by0; y <= by1; y++) for (let x = bx0; x <= bx1; x++) {
        const dx = x - p.x, dy = y - p.y, d2 = dx * dx + dy * dy; if (d2 >= p.r * p.r) continue;
        const v = b + hk * prof(p.r, d2), o = (y - y0) * pw + x - x0; if (v > patch[o]) patch[o] = v;
      }
    }
  } else {
    for (let i = 0; i < pts.length - 1; i++) {
      const A = pts[i], B = pts[i + 1], rm = Math.max(A.r, B.r), ex = B.x - A.x, ey = B.y - A.y, L2 = ex * ex + ey * ey || 1e-6;
      const bx0 = Math.max(x0, Math.floor(Math.min(A.x, B.x) - rm)), bx1 = Math.min(x1, Math.ceil(Math.max(A.x, B.x) + rm)), by0 = Math.max(y0, Math.floor(Math.min(A.y, B.y) - rm)), by1 = Math.min(y1, Math.ceil(Math.max(A.y, B.y) + rm));
      for (let y = by0; y <= by1; y++) for (let x = bx0; x <= bx1; x++) {
        let t = ((x - A.x) * ex + (y - A.y) * ey) / L2; t = t < 0 ? 0 : t > 1 ? 1 : t;
        const dx = x - A.x - ex * t, dy = y - A.y - ey * t, d2 = dx * dx + dy * dy, r = A.r + (B.r - A.r) * t; if (d2 >= r * r) continue;
        const v = base[i] + (base[i + 1] - base[i]) * t + hk * prof(r, d2), o = (y - y0) * pw + x - x0; if (v > patch[o]) patch[o] = v;
      }
    }
  }
  reliefMerge(R, patch, x0, y0, pw, ph, m, Math.atan2(q.args[5] - q.args[1], q.args[4] - q.args[0]), 0.6);     // (it lies on top, pressing what is under it down a little)
}
// a shape raised as a slab with rounded shoulders (its distance from the edge, capped) and a slight dome
const SLAB = { cv: null, x: null };
// ── clear materials: glass, lens, crystal. The colours under the piece stay in the albedo (tinted by the piece);
// the height gives its shape — a pane with a bevel (glass), a dome (lens), flat facets rising to a ridge (crystal) —
// and the shader looks through that surface: what is behind is bent (refraction), the studio is reflected (Fresnel),
// a sharp glint. Each piece gets its own number in D, so the shader can lay lead between stained-glass pieces.
function reliefClear(R, q, m) {
  const M = maskOf(q, R.k, 2); if (!M) return;
  const { A, x0, y0, w, h } = M, [c0, c1, o] = colsOf(q), rnd = rngFor(q.seed || q.args), kind = m.clear;
  // the tint: deep for stained glass, light for a lens, between for crystal
  // (laid over what is there at part strength, not multiplied: pieces over pieces would sink to black)
  const ax = R.ax, k = R.k; ax.save(); ax.setTransform(k, 0, 0, k, 0, 0);
  const tw = kind === 'glass' ? 0.1 : kind === 'lens' ? 0.5 : 0.35;
  ax.globalAlpha = (kind === 'glass' ? 0.55 : kind === 'lens' ? 0.18 : 0.3) * Math.min(1, o + 0.1); const G = gradOf(ax, q, [[0, mixHex(c0, '#ffffff', tw)], [1, mixHex(c1, '#ffffff', tw)]]);
  if (q.t === 'S') fillShape(ax, q, G); else { ax.fillStyle = G; outlinePath(ax, q); ax.fill(); }
  ax.restore();
  // distance to the edge (two-pass chamfer), inside the piece
  const D = new Float32Array(w * h), BIG = 1e6;
  for (let i = 0; i < D.length; i++) D[i] = A[i] > 0.5 ? BIG : 0;
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y * w + x; if (!D[i]) continue; let v = D[i];
    if (x > 0) v = Math.min(v, D[i - 1] + 1); if (y > 0) { v = Math.min(v, D[i - w] + 1); if (x > 0) v = Math.min(v, D[i - w - 1] + 1.414); if (x < w - 1) v = Math.min(v, D[i - w + 1] + 1.414); } D[i] = v; }
  for (let y = h - 1; y >= 0; y--) for (let x = w - 1; x >= 0; x--) { const i = y * w + x; if (!D[i]) continue; let v = D[i];
    if (x < w - 1) v = Math.min(v, D[i + 1] + 1); if (y < h - 1) { v = Math.min(v, D[i + w] + 1); if (x < w - 1) v = Math.min(v, D[i + w + 1] + 1.414); if (x > 0) v = Math.min(v, D[i + w - 1] + 1.414); } D[i] = v; }
  let dmax = 1; for (let i = 0; i < D.length; i++) if (D[i] > dmax) dmax = D[i];
  const u = R.u, piece = 1 + Math.floor(rnd() * 254), top = 18 * u;
  const hmax = kind === 'lens' ? Math.min(dmax * 0.7, 34 * u) : kind === 'crystal' ? Math.min(dmax * 0.55, 30 * u) : 0, bev = 3 * u;
  for (let y = 0; y < h; y++) {
    const yy = y + y0; if (yy < 0 || yy >= R.h) continue;
    for (let x = 0; x < w; x++) {
      const xx = x + x0, a = A[y * w + x]; if (xx < 0 || xx >= R.w || a <= 0.5) continue;
      const i = yy * R.w + xx, d = D[y * w + x], f = d / dmax, base = Math.min(top, R.H[i]) * 0.4;
      let hh;
      if (kind === 'lens') hh = hmax * Math.sqrt(Math.max(0, 1 - (1 - f) * (1 - f)));          // a dome (a circular section)
      else if (kind === 'crystal') hh = hmax * f + 2 * u;                                    // facets: straight up from every edge to the ridge
      else hh = 5 * u * Math.min(1, d / bev);                                                // a pane, bevelled at its edge
      R.H[i] = base + hh; R.M[i] = m.id; R.D[i] = piece;
    }
  }
}
function maskOf(q, k, pad = 2) {
  const P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P);
  const x0 = Math.floor(b.x0 * k) - pad, y0 = Math.floor(b.y0 * k) - pad, w = Math.ceil(b.x1 * k) + pad - x0, h = Math.ceil(b.y1 * k) + pad - y0;
  if (w <= 0 || h <= 0 || w * h > 9e6) return null;
  if (!SLAB.cv) { SLAB.cv = document.createElement('canvas'); SLAB.x = SLAB.cv.getContext('2d', { willReadFrequently: true }); }
  if (SLAB.cv.width < w || SLAB.cv.height < h) { SLAB.cv.width = Math.max(SLAB.cv.width, w); SLAB.cv.height = Math.max(SLAB.cv.height, h); }
  const x = SLAB.x; x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, w, h);
  x.setTransform(k, 0, 0, k, -x0, -y0); x.fillStyle = '#fff'; x.strokeStyle = '#fff';
  if (q.t === 'S') fillShape(x, q, '#fff'); else { outlinePath(x, q); x.fill(); }
  const d = x.getImageData(0, 0, w, h).data, A = new Float32Array(w * h);
  for (let i = 0; i < A.length; i++) A[i] = d[i * 4 + 3] / 255;
  return { A, x0, y0, w, h };
}
function reliefSlab(R, q, m) {
  const M = maskOf(q, R.k); if (!M) return;
  const { A, x0, y0, w, h } = M, D = new Float32Array(w * h), BIG = 1e6;
  for (let i = 0; i < D.length; i++) D[i] = A[i] > 0.5 ? BIG : 0;
  // two-pass chamfer distance from the edge
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) { const i = y * w + x; if (!D[i]) continue; let v = D[i]; if (x) v = Math.min(v, D[i - 1] + 1); if (y) v = Math.min(v, D[i - w] + 1); if (x && y) v = Math.min(v, D[i - w - 1] + 1.414); if (y && x < w - 1) v = Math.min(v, D[i - w + 1] + 1.414); D[i] = v; }
  let dmax = 0;
  for (let y = h - 1; y >= 0; y--) for (let x = w - 1; x >= 0; x--) { const i = y * w + x; if (!D[i]) continue; let v = D[i]; if (x < w - 1) v = Math.min(v, D[i + 1] + 1); if (y < h - 1) v = Math.min(v, D[i + w] + 1); if (x < w - 1 && y < h - 1) v = Math.min(v, D[i + w + 1] + 1.414); if (y < h - 1 && x) v = Math.min(v, D[i + w - 1] + 1.414); D[i] = v; if (v > dmax) dmax = v; }
  const cap = Math.max(2, Math.min(dmax, 13 * R.u)), hk = m.hk, rnd = rngFor(q.args);
  const dome = Math.min(2.2 * cap, Math.max(0, dmax - cap) * 0.45);
  // the ground under it (a few samples), so a slab sits on what is there
  let g = 0; for (let i = 0; i < 6; i++) g = Math.max(g, hAt(R, x0 + w * (0.2 + 0.6 * rnd()), y0 + h * (0.2 + 0.6 * rnd())));
  g = Math.min(18 * R.u, g * m.layer);
  const patch = new Float32Array(w * h);
  for (let i = 0; i < D.length; i++) {
    const d = D[i] + (A[i] > 0.5 ? 0 : A[i] - 0.5); if (d <= 0) continue;
    const t = Math.min(1, d / cap), sh = Math.sqrt(1 - (1 - t) * (1 - t));
    patch[i] = g + hk * (cap * (m.puff ? Math.pow(sh, 0.6) : sh) + dome * Math.sqrt(Math.max(0, d - cap) / Math.max(1, dmax - cap)));     // (a pillow: shoulders, then a dome over the middle)
  }
  if (m.bristle) {                                     // paint: the slab brushed in one direction (ridges across it)
    const an = rnd() * Math.PI, dx = Math.cos(an), dy = Math.sin(an), fr = 2 * Math.PI / (10 * R.u), ph = [rnd() * 6, rnd() * 6];
    for (let i = 0; i < patch.length; i++) if (patch[i] > g) {
      const px = i % w, py = (i / w) | 0, along = px * dy - py * dx, wav = Math.sin(along * 0.03 + ph[0]) * 3 + Math.sin(along * 0.011 + ph[1]) * 6;   // (the bristle tracks wander)
      patch[i] = g + (patch[i] - g) * (0.88 + 0.12 * (0.5 - 0.5 * Math.cos((px * dx + py * dy + wav) * fr)));
    }
  }
  if (m.bead) {                                        // foam / bead areas: a heap of balls instead of a slab
    patch.fill(0); const n = Math.min(400, Math.max(3, Math.round(w * h / (Math.PI * cap * cap * 0.35))));
    for (let k = 0; k < n; k++) {
      const cx = rnd() * w, cy = rnd() * h, i0 = Math.min(w * h - 1, Math.floor(cy) * w + Math.floor(cx)); if (A[i0] < 0.5) continue;
      const r = Math.max(1.5, Math.min(D[i0] + 1, cap) * (0.6 + 0.6 * rnd()));
      for (let y = Math.max(0, Math.floor(cy - r)); y <= Math.min(h - 1, Math.ceil(cy + r)); y++) for (let x = Math.max(0, Math.floor(cx - r)); x <= Math.min(w - 1, Math.ceil(cx + r)); x++) {
        const d2 = (x - cx) ** 2 + (y - cy) ** 2; if (d2 >= r * r) continue; const v = g + hk * Math.sqrt(r * r - d2), o = y * w + x; if (v > patch[o]) patch[o] = v;
      }
    }
  }
  // clip to the picture
  const cx0 = Math.max(0, x0), cy0 = Math.max(0, y0), cx1 = Math.min(R.w, x0 + w), cy1 = Math.min(R.h, y0 + h);
  if (cx1 <= cx0 || cy1 <= cy0) return;
  const pw = cx1 - cx0, ph = cy1 - cy0, P2 = new Float32Array(pw * ph);
  for (let y = 0; y < ph; y++) for (let x = 0; x < pw; x++) P2[y * pw + x] = patch[(y + cy0 - y0) * w + x + cx0 - x0];
  reliefMerge(R, P2, cx0, cy0, pw, ph, m, q.t === 'E' || q.t === 'B' || q.t === 'R' ? q.args[4] : 0);
}
// the new height into the map: on top where it is higher (it takes the pixel's material), melted in by a soft maximum
function reliefMerge(R, patch, x0, y0, pw, ph, m, ang = 0, press = 1) {
  const Dt = R.D, dv = Math.round(((ang % Math.PI) + Math.PI) % Math.PI / Math.PI * 255), H = R.H, Mt = R.M, k = m.fuse * R.u, id = m.id, knee = 30 * R.u, cap = 44 * R.u;     // (cap: melting in again and again can't build up for ever)
  // tall stacks are squeezed above a knee, so a long painting doesn't build into mountains
  for (let i = 0; i < patch.length; i++) { const v = patch[i]; if (v > knee) patch[i] = knee + (v - knee) * 0.3; }
  for (let y = 0; y < ph; y++) {
    const row = (y + y0) * R.w + x0;
    for (let x = 0; x < pw; x++) {
      const v = patch[y * pw + x]; if (v <= 0) continue;
      const i = row + x, o = H[i] * press;     // (press < 1: the new stroke lies on top, what was under it pressed down)
      if (v >= o - 0.25) { Mt[i] = id; Dt[i] = dv; }
      if (k > 0) { const d = Math.abs(v - o); H[i] = Math.min(cap, Math.max(v, o) + (d < k ? (k - d) * (k - d) / (4 * k) : 0)); }
      else H[i] = Math.min(cap, Math.max(v, o));
    }
  }
}
// a flat style painted on the relief: where it covers, the surface is paint (its height stays, so paint follows the bumps)
function reliefPaint(R, q) {
  const M = maskOf(q, R.k, 1); if (!M) return;
  const { A, x0, y0, w, h } = M;
  for (let y = Math.max(0, -y0); y < h && y + y0 < R.h; y++) for (let x = Math.max(0, -x0); x < w && x + x0 < R.w; x++) if (A[y * w + x] > 0.5) R.M[(y + y0) * R.w + x + x0] = 0;
}
// the rope's / slab's colour (its two colours along it), into the albedo
function reliefAlbedo(x, q, m) {
  const [c0, c1] = colsOf(q), tint = RELIEF_TINT[q.st];
  const col = c => tint ? mixHex(tint, c, q.st === 'puffy' ? 0.12 : q.st === 'molten' ? 0.6 : 0.28) : c;
  x.save(); x.globalAlpha = 1;
  if (q.t === 'S') {
    const a = q.args, P = quadPts(a, 1, 1, 16), w = a[6] * (m.bead === 'foam' ? 1.25 : 1.04);
    x.lineCap = 'round'; x.lineWidth = w;
    for (let i = 0; i < P.length - 1; i++) { x.strokeStyle = col(mixHex(c0, c1, i / (P.length - 2))); x.beginPath(); x.moveTo(P[i][0], P[i][1]); x.lineTo(P[i + 1][0], P[i + 1][1]); x.stroke(); }
  } else { x.fillStyle = gradOf(x, q, [[0, col(c0)], [1, col(c1)]]); outlinePath(x, q); x.fill(); x.lineWidth = 1.5; x.strokeStyle = col(c1); x.stroke(); }
  x.restore();
}
// the stand-in while a relief stroke is still arriving (and the look without WebGL): a shaded tube in the material's colour
function reliefFlat(x, q, u = 1, dir = 1) {
  if (RELIEF[q.st] && RELIEF[q.st].clear && STYLE_DRAW[q.st]) return STYLE_DRAW[q.st](x, q, u, dir);     // (no WebGL: the clear materials' own 2D look)
  if (x === X) RLF.flat = (RLF.flat || 0) + 1;       // (how often the stand-in reaches the stage: should stay 0 while the relief is lit)
  const m = RELIEF[q.st] || RELIEF.ceramic, [c0, c1, o] = colsOf(q), tint = RELIEF_TINT[q.st], c = tint ? mixHex(tint, mixHex(c0, c1, 0.5), 0.28) : mixHex(c0, c1, 0.5);
  x.save(); x.globalAlpha = Math.max(0.9, o); x.lineCap = 'round'; x.lineJoin = 'round';
  if (q.t === 'S') {
    const a = q.args, w = a[6], P = quadPts(a, u, dir, 24), line = () => { x.beginPath(); P.forEach((p, i) => x[i ? 'lineTo' : 'moveTo'](p[0], p[1])); };
    x.translate(-LIGHT.x * w * 0.12, -LIGHT.y * w * 0.12); x.strokeStyle = 'rgba(0,0,0,0.35)'; x.lineWidth = w * 1.05; line(); x.stroke();
    x.translate(LIGHT.x * w * 0.12, LIGHT.y * w * 0.12); x.strokeStyle = shade(c, -0.45); x.lineWidth = w; line(); x.stroke();
    x.strokeStyle = c; x.lineWidth = w * 0.72; x.translate(LIGHT.x * w * 0.06, LIGHT.y * w * 0.06); line(); x.stroke();
    x.strokeStyle = shade(c, 0.55); x.lineWidth = w * 0.22; x.translate(LIGHT.x * w * 0.14, LIGHT.y * w * 0.14); line(); x.stroke();
    x.restore(); const e = P[P.length - 1]; return [e[0], e[1]];
  }
  const P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), s = Math.max(2, Math.min(b.w, b.h) * 0.08);
  x.fillStyle = 'rgba(0,0,0,0.3)'; x.translate(-LIGHT.x * s, -LIGHT.y * s); outlinePath(x, q); x.fill(); x.translate(LIGHT.x * s, LIGHT.y * s);
  x.fillStyle = gradOf(x, q, [[0, shade(c, 0.25)], [1, shade(c, -0.3)]]); outlinePath(x, q); x.fill();
  x.restore(); return [q.args[0], q.args[1]];
}
// ── the lighting, on the graphics card ──
const RELIEF_FS = `#version 300 es
precision highp float;
uniform sampler2D uA, uH, uM, uD;
uniform vec2 uRes; uniform vec3 uL; uniform float uK;
out vec4 frag;
float H(vec2 p) { return texture(uH, p / uRes).r; }
float hash(vec2 p) { p = fract(p * vec2(123.34, 456.21)); p += dot(p, p + 45.32); return fract(p.x * p.y); }
float vn(vec2 p) { vec2 i = floor(p), f = fract(p); f = f * f * (3. - 2. * f);
  return mix(mix(hash(i), hash(i + vec2(1, 0)), f.x), mix(hash(i + vec2(0, 1)), hash(i + vec2(1, 1)), f.x), f.y); }
float fbm(vec2 p) { float s = 0., a = .5; for (int i = 0; i < 4; i++) { s += a * vn(p); p = p * 2.03 + 7.1; a *= .5; } return s; }
vec2 ngrad(vec2 p, float f) { float e = .5; return vec2(vn((p + vec2(e, 0)) * f) - vn((p - vec2(e, 0)) * f), vn((p + vec2(0, e)) * f) - vn((p - vec2(0, e)) * f)) / (2. * e) ; }
vec2 fgrad(vec2 p, float f) { float e = 1.; return vec2(fbm((p + vec2(e, 0)) * f) - fbm((p - vec2(e, 0)) * f), fbm((p + vec2(0, e)) * f) - fbm((p - vec2(0, e)) * f)) / (2. * e); }
float spec(vec3 n, vec3 h, float s) { return pow(max(dot(n, h), 0.), s); }
vec3 env(vec3 r, vec3 tint) {            // a studio for the polished metals: dark floor, bright soft boxes, a horizon line
  float up = -r.y, side = r.x;
  vec3 c = mix(vec3(.04), vec3(.95), smoothstep(-.25, .35, up));
  c += vec3(1.2) * smoothstep(.55, .75, up) * smoothstep(.2, -.1, abs(side + .25) - .25);
  c *= mix(vec3(1), tint, .35);
  c += vec3(.5) * exp(-abs(up + .05) * 30.);
  return c;
}
void main() {
  vec2 p = vec2(gl_FragCoord.x, uRes.y - gl_FragCoord.y), uv = p / uRes, ps = p / uK;
  vec4 A = texture(uA, uv);
  int m = int(texture(uM, uv).r * 255. + .5);
  float h = H(p), e1 = 1.2 * uK, e2 = 3. * uK;
  vec2 g = .55 * vec2(H(p + vec2(e1, 0)) - H(p - vec2(e1, 0)), H(p + vec2(0, e1)) - H(p - vec2(0, e1))) / (2. * e1)
         + .45 * vec2(H(p + vec2(e2, 0)) - H(p - vec2(e2, 0)), H(p + vec2(0, e2)) - H(p - vec2(0, e2))) / (2. * e2);
  float grain = hash(floor(ps * 1.3)), slope = length(g);
  // surface detail per material, on top of the shape's own normal
  if (m == 2) g += 0.55 * ngrad(ps, 1.1) + 0.25 * fgrad(ps, .12);                 // stone: grain and a little rock
  else if (m == 5) g += 1.3 * fgrad(ps, .07);                                     // clay: dents and thumb marks
  float an = texture(uD, uv).r * 3.14159; vec2 dv = vec2(cos(an), sin(an)), dn = vec2(-dv.y, dv.x);
  float streak = vn(vec2(dot(ps, dv) * .045, dot(ps, dn) * 1.6));                 // brushed lines, along the stroke
  if (m == 7) g += .55 * (streak - .5) * dn + .12 * ngrad(ps, .4);                 // pewter: brushed metal
  else if (m == 9) g += .55 * fgrad(ps, .06) + .15 * ngrad(ps, .8);                // copper: hammered dents
  else if (m == 10) g += .12 * fgrad(ps, .1);                                     // gold leaf: smooth under the flakes
  else if (m == 11) g += 0.35 * ngrad(ps, .5) + .2 * fgrad(ps, .12);              // bronze: cast
  else if (m == 6) g += 0.08 * ngrad(ps, 2.);                                      // chrome: a hint of grain
  else if (m == 8) g += 0.2 * fgrad(ps, .2);
  vec3 n = normalize(vec3(-g, 1.)), L = normalize(uL), V = vec3(0, 0, 1), Hh = normalize(L + V);
  // cast shadow: walk towards the light; anything above the ray shades this pixel (softly, more so far away)
  vec2 dir = normalize(L.xy + 1e-5); float rise = L.z / max(1e-3, length(L.xy)), sh = 1., t = 1.2 * uK;
  for (int i = 0; i < 26; i++) {
    float hs = H(p + dir * t), hr = h + rise * t;
    sh = min(sh, clamp(1. - (hs - hr) / (.18 * t + 1.2 * uK), 0., 1.));
    t = t * 1.17 + .8 * uK;
  }
  sh = sh * sh * (3. - 2. * sh);
  // hollows: lower than the ground around it
  float avg = 0.;
  for (int i = 0; i < 8; i++) { float a = float(i) * .785 + .3; avg += H(p + vec2(cos(a), sin(a)) * 5. * uK) + H(p + vec2(cos(a + .4), sin(a + .4)) * 14. * uK); }
  avg /= 16.; float ao = clamp(1. - max(0., avg - h) / (14. * uK), .35, 1.);
  float dif = max(dot(n, L), 0.), lam = dot(n, L) / max(.2, L.z);
  vec3 c = A.rgb, o;
  if (m == 0) {                                     // paint and the ground: lit as it lies, with the ropes' shadows on it
    o = c * clamp(.72 + .28 * lam, .25, 1.35) * (.42 + .58 * sh) * ao;
  } else if (m == 1) {                              // glazed ceramic: porcelain body, lacquer highlight, a soft sheen
    vec3 b = mix(c, vec3(.97, .94, .88), .12);
    o = b * (.2 + .88 * dif * sh) * ao + vec3(1.15) * spec(n, Hh, 140.) * sh + vec3(.14) * spec(n, Hh, 14.) * sh + b * .18 * pow(1. - n.z, 2.);
  } else if (m == 2) {                              // stone: matte, grain lit on the slopes towards the light
    vec3 b = c * (.78 + .4 * grain) * (.85 + .3 * fbm(ps * .05));
    o = b * (.16 + .95 * dif * sh) * ao + vec3(.07) * grain * dif * sh;
  } else if (m == 3) {                              // kinetic metal: the colour as a polished ramp (shadow, mid, highlight)
    float band = .5 + .5 * sin(n.x * 9. + n.y * 13.), sl = length(n.xy);
    float v = clamp(.12 + .5 * dif * sh + .45 * band * smoothstep(.04, .3, sl) * (.4 + .6 * sh) - .35 * (1. - ao), 0., 1.);
    vec3 lo = c * .1, mid = c * .9, hi = mix(c, vec3(1), .85);
    o = v < .5 ? mix(lo, mid, v * 2.) : mix(mid, hi, (v - .5) * 2.);
    o += vec3(1.3) * spec(n, Hh, 220.) * sh + mix(c, vec3(1), .6) * .35 * spec(n, Hh, 30.) * sh;
  } else if (m == 4) {                              // foam: soft, wrapped light, a faint sheen, deep shadows between the balls
    float w = clamp((dot(n, L) + .45) / 1.45, 0., 1.);
    o = c * (.22 + .9 * w * mix(1., sh, .85)) * ao + vec3(.18) * spec(n, Hh, 22.) * sh + c * .08 * (1. - sh);
  } else if (m == 5) {                              // modelling clay: matte, a little waxy
    o = c * (.24 + .86 * dif * sh) * ao + vec3(.05) * spec(n, Hh, 9.) * sh;
  } else if (m == 6) {                              // liquid chrome: the studio reflected, speckled grain
    float sl = length(n.xy), fa = dot(n.xy / max(sl, 1e-4), normalize(L.xy + 1e-5));
    float e = .3 + .8 * smoothstep(.05, .5, sl) * (.5 + .5 * fa) + .7 * exp(-pow((sl - .32) * 7., 2.)) * (.6 + .4 * fa) - .2 * smoothstep(.55, .9, sl);
    e += .25 * smoothstep(.6, .95, -fa) * smoothstep(.2, .6, sl);                   // a second, dimmer light from behind
    o = vec3(e) * mix(vec3(1), c * 1.35, .6) * (.5 + .5 * sh) * ao + vec3(2.) * spec(n, Hh, 320.) * sh + (grain - .5) * .035;
  } else if (m == 7) {                              // pewter: brushed metal, its highlight drawn out across the brushing
    vec3 b = mix(c, vec3(.62, .63, .66), .5); float th = dot(vec3(dv, 0.), Hh);
    float aniso = pow(sqrt(max(0., 1. - th * th)) * max(dot(n, Hh), 0.), 36.);
    o = b * (.18 + .72 * dif * sh) * ao + vec3(.85) * aniso * sh * (.5 + streak) + b * .1 * streak;
  } else if (m == 8) {                              // terrazzo: polished, with chips of stone set in it
    vec2 cell = floor(ps / 13.), f = fract(ps / 13.) - .5; float hc = hash(cell), hv = hash(cell + 3.7);
    vec2 off = vec2(hash(cell + 1.3), hash(cell + 7.1)) - .5;
    vec3 b = mix(c, vec3(.95, .93, .9), .2);
    float chip = step(length((f - off * .4) * vec2(1., .7 + .6 * hv)), .18 + .14 * hash(cell + 2.2));
    if (hc > .55 && chip > .5) b = hv < .33 ? vec3(.13) : hv < .66 ? vec3(.93, .91, .87) : c * .5;
    o = b * (.22 + .85 * dif * sh) * ao + vec3(.35) * spec(n, Hh, 70.) * sh;
  } else if (m == 9) {                              // copper: polished where it stands up, green verdigris in the hollows
    vec3 cu = mix(vec3(.80, .42, .26), c, .2), r = reflect(vec3(0, 0, -1), n);
    vec3 shine = cu * (.1 + .6 * dif * sh) * ao + cu * env(r, cu) * .5 * (.5 + .5 * sh) + mix(cu, vec3(1), .4) * spec(n, Hh, 50.) * 1.2 * sh;
    float pa = smoothstep(.15, .6, (1. - ao) * 2.2 + max(0., avg - h) / (5. * uK) + .45 * (fbm(ps * .04) - .45));
    vec3 verd = vec3(.32, .62, .52) * (.75 + .45 * fbm(ps * .09));
    o = mix(shine, verd * (.3 + .7 * dif * sh) * ao, pa * .92);
  } else if (m == 10) {                             // gold leaf: flakes laid side by side, each tilted its own way, dark cracks between them
    vec2 cs = ps / 26., ic = floor(cs), id = ic; float d1 = 9., d2 = 9.;        // irregular flakes: the nearest of a few scattered points
    for (int j = -1; j <= 1; j++) for (int i = -1; i <= 1; i++) { vec2 c2 = ic + vec2(i, j), pt = c2 + vec2(hash(c2), hash(c2 + 5.1)); float dd = length(cs - pt); if (dd < d1) { d2 = d1; d1 = dd; id = c2; } else if (dd < d2) d2 = dd; }
    float crack = smoothstep(0., .06, d2 - d1), hc = hash(id);
    vec3 n2 = normalize(n + vec3((hash(id + 1.3) - .5) * .22, (hash(id + 2.7) - .5) * .22, 0.)), H2 = normalize(L + V), r = reflect(vec3(0, 0, -1), n2);
    vec3 au = mix(vec3(1., .78, .34), c, .12);
    o = (au * (.12 + .5 * max(dot(n2, L), 0.) * sh) * ao + au * env(r, au) * .62 * (.6 + .4 * sh) + vec3(1., .9, .6) * spec(n2, H2, 90.) * 1.3 * sh) * (.9 + .18 * hc) * mix(.55, 1., crack);
  } else if (m == 11) {                             // bronze: dark patina in the low parts, polished golden-brown on the high points
    vec3 bz = mix(vec3(.72, .52, .28), c, .2), r = reflect(vec3(0, 0, -1), n);
    vec3 pol = bz * (.1 + .6 * dif * sh) * ao + bz * env(r, bz) * .42 * (.5 + .5 * sh) + mix(bz, vec3(1), .45) * spec(n, Hh, 70.) * 1.1 * sh;
    vec3 pat = mix(vec3(.24, .29, .21), vec3(.36, .42, .32), fbm(ps * .06)) * (.45 + .65 * dif * sh) * ao;
    o = mix(pat, pol, smoothstep(-2.5 * uK, 2. * uK, h - avg));
  } else if (m == 12) {                             // beads: glossy, lacquered
    vec3 b = c * 1.05;
    o = b * (.18 + .85 * dif * sh) * ao + vec3(1.2) * spec(n, Hh, 180.) * sh + b * .25 * pow(1. - n.z, 3.);
  } else if (m == 14) {                             // oil paint: wet and glossy, a soft broad sheen over the body of the paint
    o = c * (.28 + .8 * dif * sh) * ao + vec3(.15) * spec(n, Hh, 20.) * sh + vec3(.07) * spec(n, Hh, 5.) * sh;
  } else if (m == 16) {                             // palette knife: wet, glossy paint, a sharp highlight on every ridge
    o = c * (.26 + .84 * dif * sh) * ao + vec3(.26) * spec(n, Hh, 60.) * sh + vec3(.05) * spec(n, Hh, 8.) * sh;
  } else if (m == 15) {                             // acrylic: satin, flatter
    o = c * (.3 + .78 * dif * sh) * ao + vec3(.07) * spec(n, Hh, 9.) * sh;     // (a matte satin sheen, no wet highlight)
  } else if (m >= 17 && m <= 19) {                  // glass, lens, crystal: looked through
    vec2 gg = g;
    if (m == 17) gg += 3.2 * fgrad(ps, .05) + .35 * ngrad(ps, .3);                   // hammered, rippled cathedral glass
    vec3 n2 = normalize(vec3(-gg, 1.)), H2 = normalize(L + V);
    float ior = m == 18 ? 16. : m == 19 ? 12. : 9.;
    vec2 off = clamp(gg, -2.5, 2.5) * ior * uK;                                       // refraction: what is behind, seen through the slope
    vec3 bent;
    if (m == 19) bent = vec3(texture(uA, (p + off * .94) / uRes).r, texture(uA, (p + off) / uRes).g, texture(uA, (p + off * 1.08) / uRes).b);   // crystal: a little dispersion
    else bent = texture(uA, (p + off) / uRes).rgb;
    vec3 r = reflect(vec3(0, 0, -1), n2);
    float fr = .05 + .95 * pow(1. - clamp(n2.z, 0., 1.), 4.);
    float thick = clamp(length(gg) * .6, 0., 1.);
    o = bent * (.82 + .25 * dif) * mix(1., .62, thick * (m == 17 ? .3 : 1.));         // the glass darkens where it is thick (its rim)
    o += env(r, vec3(1)) * fr * .55;                                // the studio reflected, strongest at grazing angles
    o += vec3(1.8) * spec(n2, H2, m == 19 ? 900. : 500.) * sh + vec3(.12) * spec(n2, H2, 30.) * sh;
    if (m == 18) o += bent * .22 * smoothstep(.2, 1., n2.z) * dif;                    // a lens gathers light in its middle
    if (m == 19) { float tw = hash(floor(ps / 3.)); o += vec3(2.) * step(.992, tw) * smoothstep(.3, .8, spec(n2, H2, 40.)) * sh; }   // crystal: sparkle
    if (m == 17) { float wv = fract(dot(uv, normalize(vec2(-L.y, L.x) + vec2(.6, .8))) * 1.3 + .1 * gg.x);     // a window reflected across the panes
      o += vec3(.9, .95, 1.) * (.32 * exp(-pow((wv - .3) * 12., 2.)) + .2 * exp(-pow((wv - .38) * 28., 2.))); }
    if (m == 17) {                                                                    // stained glass: lead between pieces, raised and lit
      float me = texture(uD, uv).r, lead = 0.;
      for (int i = 0; i < 8; i++) { float a = float(i) * .785; vec2 q2 = (p + vec2(cos(a), sin(a)) * 2.6 * uK) / uRes;
        if (int(texture(uM, q2).r * 255. + .5) != 17 || abs(texture(uD, q2).r - me) > .002) lead = 1.; }
      if (lead > .5) o = vec3(.16, .16, .17) * (.5 + .7 * dif * sh) + vec3(.6) * spec(n, Hh, 30.) * sh;
    }
  } else {                                          // puffy: inflated, glossy black vinyl
    o = c * (.3 + .7 * dif * sh) * ao + vec3(.85) * spec(n, Hh, 70.) * sh + vec3(.12) * spec(n, Hh, 6.) * sh + vec3(.18) * pow(1. - n.z, 3.) * sh;
  }
  frag = vec4(clamp(o, 0., 1.) * A.a, A.a);
}`;
function reliefGL() {
  if (GLR !== null) return GLR;
  GLR = false;
  try {
    const cv = document.createElement('canvas'), gl = cv.getContext('webgl2', { premultipliedAlpha: true, antialias: false });
    if (!gl) return GLR;
    const sh = (type, src) => { const s = gl.createShader(type); gl.shaderSource(s, src); gl.compileShader(s); if (!gl.getShaderParameter(s, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(s)); return s; };
    const pr = gl.createProgram();
    gl.attachShader(pr, sh(gl.VERTEX_SHADER, '#version 300 es\nin vec2 a; void main() { gl_Position = vec4(a, 0, 1); }'));
    gl.attachShader(pr, sh(gl.FRAGMENT_SHADER, RELIEF_FS)); gl.linkProgram(pr);
    if (!gl.getProgramParameter(pr, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(pr));
    gl.useProgram(pr);
    const buf = gl.createBuffer(); gl.bindBuffer(gl.ARRAY_BUFFER, buf); gl.bufferData(gl.ARRAY_BUFFER, new Float32Array([-1, -1, 3, -1, -1, 3]), gl.STATIC_DRAW);
    const loc = gl.getAttribLocation(pr, 'a'); gl.enableVertexAttribArray(loc); gl.vertexAttribPointer(loc, 2, gl.FLOAT, false, 0, 0);
    const tex = (unit, filter) => { const t = gl.createTexture(); gl.activeTexture(gl.TEXTURE0 + unit); gl.bindTexture(gl.TEXTURE_2D, t); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, filter); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE); gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE); return t; };
    const T = { A: tex(0, gl.LINEAR), H: tex(1, gl.LINEAR), M: tex(2, gl.NEAREST), D: tex(3, gl.NEAREST) };
    const U = n => gl.getUniformLocation(pr, n);
    gl.uniform1i(U('uA'), 0); gl.uniform1i(U('uH'), 1); gl.uniform1i(U('uM'), 2); gl.uniform1i(U('uD'), 3);
    GLR = { cv, gl, T, uRes: U('uRes'), uL: U('uL'), uK: U('uK'), max: gl.getParameter(gl.MAX_TEXTURE_SIZE) };
  } catch (e) { console.warn('relief: no WebGL 2 lighting', e); GLR = false; }
  return GLR;
}
// light the relief, into the 2D context x (at the relief's own size)
function reliefRender(R, x) {
  const G = reliefGL(); if (!G || R.w > G.max || R.h > G.max) return false;
  const { gl, cv, T } = G;
  if (cv.width !== R.w || cv.height !== R.h) { cv.width = R.w; cv.height = R.h; }
  gl.viewport(0, 0, R.w, R.h);
  if (!(R === RLF.st && !R.dirty && G.up === R)) {     // (only the light moved: the surface is already up)
    gl.pixelStorei(gl.UNPACK_ALIGNMENT, 1);
    gl.activeTexture(gl.TEXTURE0); gl.bindTexture(gl.TEXTURE_2D, T.A); gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, R.alb);
    gl.activeTexture(gl.TEXTURE1); gl.bindTexture(gl.TEXTURE_2D, T.H); gl.texImage2D(gl.TEXTURE_2D, 0, gl.R16F, R.w, R.h, 0, gl.RED, gl.FLOAT, R.H);
    gl.activeTexture(gl.TEXTURE2); gl.bindTexture(gl.TEXTURE_2D, T.M); gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, R.w, R.h, 0, gl.RED, gl.UNSIGNED_BYTE, R.M);
    gl.activeTexture(gl.TEXTURE3); gl.bindTexture(gl.TEXTURE_2D, T.D); gl.texImage2D(gl.TEXTURE_2D, 0, gl.R8, R.w, R.h, 0, gl.RED, gl.UNSIGNED_BYTE, R.D);
    G.up = R;
  }
  // (with music in the paint the light swings round on the beats and drops lower, more raking, with the bass)
  const ca = Math.cos(LDANCE.a), sa = Math.sin(LDANCE.a), lx = LIGHT.x * ca - LIGHT.y * sa, ly = LIGHT.x * sa + LIGHT.y * ca, l = Math.min(1, Math.hypot(lx, ly));
  gl.uniform2f(G.uRes, R.w, R.h); gl.uniform3f(G.uL, lx, ly, (0.62 + 0.7 * (1 - l)) * (1 - 0.7 * LDANCE.z)); gl.uniform1f(G.uK, R.u); LDANCE.shown = LDANCE.a + LDANCE.z;
  gl.drawArrays(gl.TRIANGLES, 0, 3);
  x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, x.canvas.width, x.canvas.height); x.drawImage(cv, 0, 0); x.restore();
  R.dirty = false; return true;
}
// the light on the music: a hit, then stillness. Each beat snaps the light round to one side (the other side on the next
// beat) and drops it low and raking, so the whole surface flares; it eases back within a third of a second and holds
// still until the next beat — the rhythm shows as hits, not as a light that keeps wobbling
const LDANCE = { a: 0, z: 0, side: 1, t: 0, shown: 0 };
function lightKick(st) { LDANCE.side = -LDANCE.side; LDANCE.a = LDANCE.side * 1.15 * st; LDANCE.z = Math.min(1, 0.35 + 0.75 * st); }
function lightStep() {
  const t = clock(), dt = Math.min(0.1, Math.max(0, (t - (LDANCE.t || t)) / 1000)); LDANCE.t = t;
  LDANCE.a *= Math.exp(-dt * 9); LDANCE.z *= Math.exp(-dt * 8);
  if (Math.abs(LDANCE.a) < 0.003) LDANCE.a = 0;
  if (LDANCE.z < 0.004) LDANCE.z = 0;
  return Math.abs(LDANCE.a + LDANCE.z - LDANCE.shown) > 0.004;          // (the light has moved since the last relight)
}
// the live painting: relit when something changed (at most ~25 times a second, unless forced)
function reliefFlush(force) {
  if (RLF.on && (RLF.st.out !== S.out || !reliefMode())) reliefStop();
  if (!RLF.on || !RLF.st || !S.outX) return;
  const R = RLF.st, now = performance.now(), arriving = reliefArriving(), moved = lightStep();
  if (!R.dirty && !arriving.length && !RLF.wasArriving && !moved) return;
  if (!force && !OFF.on && now - RLF.last < (arriving.length ? 30 : 40)) return;     // (a render: every frame, whatever the wall clock says)
  RLF.last = now; RLF.wasArriving = arriving.length > 0;
  if (!(arriving.length ? reliefRender(reliefScratch(R, arriving), S.outX) : reliefRender(R, S.outX))) { reliefStop(); return; }
  R.dirty = false;
}
// relief strokes still arriving (the draw motion): each with how much of it is down so far
// (at most 48 a frame — each is laid into a scratch relief, which costs. The ones already showing keep their place and
// newcomers wait behind them: a stroke never drops out for a frame and comes back, which flickered)
function reliefArriving() {
  const out = [], t = clock(), was = RLF.showing || new Set(), now = new Set(), act = [];
  for (const L of S.landing || []) if (RELIEF[L.q.st] && t >= L.t0) act.push(L);
  const pick = new Set(act.filter(L => was.has(L)).concat(act.filter(L => !was.has(L))).slice(0, 48));
  for (const L of act) {
    if (!pick.has(L)) continue;       // (laid in the order they were painted, so nothing changes places when they land)
    const u = clamp01((t - L.t0) / L.dur), drawn = L.q.t === 'S';      // (paint is always painted out, whatever the motion)
    const fp = fillParts(L.q);
    if (fp) { const { done, cur, f } = fillUpTo(fp, u); for (const p of done) out.push({ q: p }); if (cur) out.push({ q: quadPart(cur, f, 1) }); }
    else out.push({ q: drawn ? quadPart(L.q, S.pen && S.mode === 'auto' ? u : easeInOut(u), L.dir) : L.q });
    now.add(L);
  }
  RLF.showing = now;
  return out;
}
// the first u of a stroke as a stroke of its own (the quadratic split at u, from whichever end it is drawn)
function quadPart(q, u, dir) {
  const a = q.args.slice(); if (u >= 0.999) return q;
  let [x0, y0, x1, y1, x2, y2] = a; if (dir < 0) [x0, y0, x2, y2] = [x2, y2, x0, y0];
  const v = Math.max(0.02, u), qx = x0 + (x1 - x0) * v, qy = y0 + (y1 - y0) * v, ex = qx + (x1 + (x2 - x1) * v - qx) * v, ey = qy + (y1 + (y2 - y1) * v - qy) * v;
  a[0] = x0; a[1] = y0; a[2] = qx; a[3] = qy; a[4] = ex; a[5] = ey;
  return { ...q, args: a, seed: q.seed || q.args, part: v };
}
// a scratch copy of the relief with the arriving strokes added (the real one only takes them once they have landed)
function reliefScratch(R, list) {
  let T = RLF.tmp;
  if (!T || T.w !== R.w || T.h !== R.h) { T = RLF.tmp = makeRelief(R.w, R.h, R.k, R.u); T.scratch = true; }
  T.u = R.u; T.k = R.k; T.H.set(R.H); T.M.set(R.M); T.D.set(R.D);
  T.ax.setTransform(1, 0, 0, 1, 0, 0); T.ax.globalCompositeOperation = 'copy'; T.ax.drawImage(R.alb, 0, 0); T.ax.globalCompositeOperation = 'source-over';
  for (const it of list) reliefAdd(T, it.q);
  return T;
}
// endless zoom: the relief scaled about the middle with the canvas (heights too); zooming out keeps the old edge
function reliefZoom(R, v) {
  const { w, h } = R, cx = w / 2, cy = h / 2, H0 = R.H.slice(), M0 = R.M.slice(), D0 = R.D.slice();
  for (let y = 0; y < h; y++) for (let x = 0; x < w; x++) {
    const sx = Math.round(cx + (x - cx) / v), sy = Math.round(cy + (y - cy) / v), i = y * w + x;
    if (sx >= 0 && sy >= 0 && sx < w && sy < h) { const j = sy * w + sx; R.H[i] = H0[j] * v; R.M[i] = M0[j]; R.D[i] = D0[j]; }
    else if (v > 1) { R.H[i] = 0; R.M[i] = 0; }
  }
  const t = document.createElement('canvas'); t.width = w; t.height = h; t.getContext('2d').drawImage(R.alb, 0, 0);
  const x = R.ax; x.setTransform(1, 0, 0, 1, 0, 0); if (v > 1) x.clearRect(0, 0, w, h);
  x.setTransform(v, 0, 0, v, cx - v * cx, cy - v * cy); x.drawImage(t, 0, 0); x.setTransform(1, 0, 0, 1, 0, 0); R.dirty = true;
}
// a big render of the whole painting with its relief, every shape added again at the bigger scale
function reliefBig(k) {
  const W = Math.round(S.out.width * k), H = Math.round(S.out.height * k), R = makeRelief(W, H, k, k * RLF.st.u);
  R.ax.setTransform(k, 0, 0, k, 0, 0); paintBg(R.ax); R.ax.setTransform(1, 0, 0, 1, 0, 0);
  for (const d of S.drawn) reliefAdd(R, d);
  const cv = document.createElement('canvas'); cv.width = W; cv.height = H;
  return reliefRender(R, cv.getContext('2d')) ? cv : null;
}
// (blur and shadows are measured in the canvas's own pixels, not the drawing's: scaled here, so a stroke looks the same
// drawn on the stage while it arrives as in the painting it lands in)
const devK = x => { const m = x.getTransform(); return Math.hypot(m.a, m.b) || 1; };
const blurDo = (x, px, fn, on = true) => { if (CAN_BLUR && on) { x.save(); x.filter = `blur(${Math.max(0.4, px * devK(x)).toFixed(2)}px)`; fn(); x.restore(); } else fn(); };
const MEDIA = new Set(['calligraphy', 'watercolour', 'gouache', 'sumi', 'marker', 'pencil', 'pastel', 'pen', 'ink', 'wash', 'wet', 'charcoal', 'thread', 'hylics', 'lens', 'crystal', 'frost', 'neon', 'embroid']);
// (a canvas blur: for the wet bleed; browsers without it get the sharp version)
const CAN_BLUR = (() => { try { const t = document.createElement('canvas').getContext('2d'); t.filter = 'blur(1px)'; return t.filter === 'blur(1px)'; } catch (e) { return false; } })();
const RISO_INKS = ['#ff48b0', '#0078bf', '#ffe800', '#00a95c', '#ff6c2f', '#765ba7', '#f15060', '#3d5588', '#00838a', '#000000'];    // fluorescent pink, blue, yellow, green, orange, violet, red, federal blue, teal, black
let RISO_GRAIN = null;
function risoGrain(x) {          // the riso's speckle: a tile of fine white grain (where the stencil let less ink through)
  if (!RISO_GRAIN) { const c = document.createElement('canvas'); c.width = c.height = 96; const t = c.getContext('2d'), d = t.createImageData(96, 96), R = rngFor([7, 3, 1]);
    for (let i = 0; i < 96 * 96; i++) { const v = R(); d.data[i * 4] = d.data[i * 4 + 1] = d.data[i * 4 + 2] = 255; d.data[i * 4 + 3] = v < 0.18 ? 120 + v * 700 : 0; }
    t.putImageData(d, 0, 0); RISO_GRAIN = c; }
  return x.createPattern(RISO_GRAIN, 'repeat');
}
const STYLE_DRAW = {
  mosaic(x, q) {          // a glazed square tile, grout showing round it
    const [cx, cy, w, h, r] = q.args, [c, , o] = colsOf(q), R = rngFor(q.args), g = Math.max(0.5, Math.min(w, h) * 0.09);
    x.save(); x.globalAlpha = o; x.translate(cx, cy); x.rotate(r);
    x.fillStyle = shade(c, -0.62); x.fillRect(-w / 2, -h / 2, w, h);
    x.rotate((R() - 0.5) * 0.07);
    const G = x.createLinearGradient(-w / 2, -h / 2, w / 2, h / 2); G.addColorStop(0, shade(c, 0.2)); G.addColorStop(0.45, c); G.addColorStop(1, shade(c, -0.14));
    x.fillStyle = G; x.beginPath(); x.roundRect(-w / 2 + g, -h / 2 + g, w - 2 * g, h - 2 * g, Math.min(w, h) * 0.14); x.fill();
    x.restore();
  },
  glass(x, q, u = 1, dir = 1) {    // stained glass: the window behind it bent through rippled cathedral glass, the colour glowing where the
    // light comes through, a sky / window reflection sliding across its surface, seeds (bubbles) in it, held in raised, lit lead
    const [c0, c1, o] = colsOf(q), a = q.args;
    if (u < 1) return quickDraw(x, q, u, dir, c0, o * 0.5);
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), R = rngFor(a), size = Math.max(b.w, b.h, 2), path = outlineOf(q);
    const under = underRegion(x, b.x0 - 2, b.y0 - 2, b.w + 4, b.h + 4), la = Math.atan2(LIGHT.y, LIGHT.x);
    x.save(); x.save(); x.clip(path);
    if (under) {                         // refraction: the hammered glass shifts what is behind it in wavy bands
      const n = Math.max(6, Math.min(48, Math.round(b.h / 2.5))), ph = R() * 6.28, amp = size * 0.035, bh = b.h / n, fq = 6.28 * (1.5 + R()) / n;
      for (let k = 0; k < n; k++) {
        const sy = b.y0 + k * bh, dx = Math.sin(ph + k * fq) * amp;
        x.save(); x.beginPath(); x.rect(b.x0 - 2, sy - 0.5, b.w + 4, bh + 1); x.clip(); x.globalAlpha = o;
        x.drawImage(under.cv, 0, 0, under.sw, under.sh, under.x0 + dx - LIGHT.x * size * 0.03, under.y0 - LIGHT.y * size * 0.03, under.w, under.h); x.restore();
      }
    }
    x.globalCompositeOperation = 'multiply'; x.globalAlpha = 0.9 * o;            // the colour of the glass (deep where it is thick)
    x.fillStyle = gradOf(x, q, [[0, c0], [1, c1]]); x.fill(path);
    x.globalCompositeOperation = 'screen';                                        // light coming through: a glow off centre, towards the light
    const gx = b.cx + LIGHT.x * b.w * 0.2, gy = b.cy + LIGHT.y * b.h * 0.2, G = x.createRadialGradient(gx, gy, 0, gx, gy, size * 0.7);
    G.addColorStop(0, rgbaOf(mixHex(mixHex(c0, c1, 0.5), '#ffffff', 0.35), 0.55 * o)); G.addColorStop(1, rgbaOf(c0, 0)); x.fillStyle = G; x.fill(path);
    x.globalAlpha = 0.18 * o; x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(0.6, size * 0.012);    // the ripples in cathedral glass
    for (let k = 0, n = 2 + Math.round(R() * 3); k < n; k++) {
      const y = b.y0 + b.h * (k + 0.5) / n + (R() - 0.5) * b.h * 0.1; x.beginPath(); x.moveTo(b.x0, y);
      for (let t = 1; t <= 8; t++) x.lineTo(b.x0 + b.w * t / 8, y + Math.sin(t * 1.1 + k) * size * 0.04);
      x.stroke();
    }
    // the reflection: a window (two pale panes and their bar) mirrored in the surface, sliding with the light
    x.save(); x.translate(b.cx - LIGHT.x * size * 0.25, b.cy - LIGHT.y * size * 0.25); x.rotate(la + Math.PI / 2 + 0.5);
    const ref = x.createLinearGradient(-size * 0.6, 0, size * 0.6, 0);
    ref.addColorStop(0, 'rgba(255,255,255,0)'); ref.addColorStop(0.35, `rgba(235,245,255,${0.42 * o})`); ref.addColorStop(0.48, `rgba(235,245,255,${0.42 * o})`);
    ref.addColorStop(0.5, 'rgba(255,255,255,0)'); ref.addColorStop(0.56, `rgba(235,245,255,${0.3 * o})`); ref.addColorStop(0.72, 'rgba(255,255,255,0)');
    x.globalAlpha = 1; x.fillStyle = ref; x.fillRect(-size, -size, size * 2, size * 2); x.restore();
    x.globalCompositeOperation = 'source-over';
    for (let k = 0, n = Math.round(size / 25 + R() * 3); k < n; k++) {      // seeds: little bubbles, a glint on each
      const sx = b.x0 + R() * b.w, sy = b.y0 + R() * b.h, sr = Math.max(0.6, size * (0.006 + R() * 0.01));
      x.globalAlpha = 0.35 * o; x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(0.4, sr * 0.4); x.beginPath(); x.ellipse(sx, sy, sr * 1.6, sr, 0, 0, 7); x.stroke();
    }
    x.globalAlpha = 0.35 * o; x.strokeStyle = '#000'; x.lineWidth = size * 0.06; x.stroke(path);    // darker where the glass meets the lead
    x.restore();
    // the lead came: dark, raised, a highlight on its lit side and a shadow on the other
    const lw = Math.max(1.4, Math.min(7, size * 0.05));
    x.lineJoin = 'round'; x.globalAlpha = 1;
    x.strokeStyle = '#141416'; x.lineWidth = lw; x.stroke(path);
    x.save(); x.lineWidth = lw * 0.35; x.globalAlpha = 0.55; x.strokeStyle = '#9a9ca2'; x.translate(LIGHT.x * lw * 0.22, LIGHT.y * lw * 0.22); x.stroke(path); x.restore();
    x.save(); x.lineWidth = lw * 0.22; x.globalAlpha = 0.5; x.strokeStyle = '#000'; x.translate(-LIGHT.x * lw * 0.3, -LIGHT.y * lw * 0.3); x.stroke(path); x.restore();
    x.restore(); return endOf(q);
  },
  linocut(x, q) {         // a lino print: one solid ink, the lit side carved away in white gouge cuts that follow the form, the ink a little patchy
    const [c0, , o] = colsOf(q), a = q.args, P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), R = rngFor(a), size = Math.max(b.w, b.h, 2), path = outlineOf(q);
    const paper = '#f3eee2', ink = shade(c0, -0.1);
    x.save(); x.globalAlpha = o; x.fillStyle = ink; x.fill(path);
    x.clip(path); x.fillStyle = paper; x.strokeStyle = paper; x.lineCap = 'round';
    const cut = (pts, w) => {                     // a gouge cut: thin in, wide in the middle, thin out
      for (let i = 1; i < pts.length; i++) { const t = i / (pts.length - 1); x.lineWidth = Math.max(0.3, w * Math.sin(Math.PI * Math.min(0.98, Math.max(0.02, t)))); x.beginPath(); x.moveTo(pts[i - 1][0], pts[i - 1][1]); x.lineTo(pts[i][0], pts[i][1]); x.stroke(); }
    };
    if (q.t === 'S') {                             // along the stroke, on its lit side
      const Q = quadPts(a, 1, 1, 24), w = a[6], [nx, ny] = normalAt(Q, 12), lit = Math.sign(nx * LIGHT.x + ny * LIGHT.y) || 1, gap = Math.max(2.2, w * 0.13);
      for (let off = 0; off < w / 2; off += gap) {
        const f = off / (w / 2), cw = gap * 0.85 * Math.min(1, f * 1.5); if (cw < 0.4) continue;
        const L = offsetPts(Q, off * lit), s0 = Math.floor(R() * 5), s1 = Q.length - Math.floor(R() * 5);
        x.globalAlpha = 0.95; cut(L.slice(s0, s1), cw);
      }
    } else {                                       // across the light: lines of cuts, wider towards the light
      const tx = -LIGHT.y, ty = LIGHT.x, l = Math.hypot(LIGHT.x, LIGHT.y) || 1, lx = LIGHT.x / l, ly = LIGHT.y / l, half = size * 0.6, gap = Math.max(2.6, size * 0.06);
      for (let v = -half; v < half; v += gap) {
        const f = (v / half + 0.3) / 1.3; if (f <= 0) continue;
        const cw = gap * 0.85 * Math.min(1, f * 1.5), bend = (R() - 0.5) * gap * 2;
        for (let s0 = -half; s0 < half;) {
          const len = half * (0.5 + R() * 1.2), pts = [];
          for (let k = 0; k <= 10; k++) { const s = s0 + len * k / 10, c = bend * Math.sin(Math.PI * k / 10); pts.push([b.cx + lx * (v + c) + tx / l * s, b.cy + ly * (v + c) + ty / l * s]); }
          x.globalAlpha = 0.95; cut(pts, cw * (0.7 + R() * 0.5)); s0 += len + gap * (0.5 + R() * 2);
        }
      }
    }
    x.globalAlpha = 0.5; x.fillStyle = paper;      // where the ink missed: a few specks, more near the edge
    for (let k = 0, n = Math.min(160, Math.round(size * size / 500)); k < n; k++) { const px = b.x0 + R() * b.w, py = b.y0 + R() * b.h, r2 = 0.3 + R() * Math.max(0.6, size * 0.006); x.beginPath(); x.arc(px, py, r2, 0, 7); x.fill(); }
    x.restore(); return endOf(q);
  },
  riso(x, q) {            // risograph: two spot inks printed one over the other (they multiply), each grainy, the second a little off register
    const [c0, c1, o] = colsOf(q), a = q.args, P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), R = rngFor(a), size = Math.max(b.w, b.h, 2), path = outlineOf(q);
    const dist = (h, k) => { const A = hexRgb(h), B = hexRgb(k); return (A[0] - B[0]) ** 2 * 0.3 + (A[1] - B[1]) ** 2 * 0.59 + (A[2] - B[2]) ** 2 * 0.11; };
    const near = (h, not) => RISO_INKS.filter(k => k !== not).reduce((m, k) => dist(h, k) < dist(h, m) ? k : m, RISO_INKS.find(k => k !== not));
    const A = near(c0), B = near(c1, A), grain = risoGrain(x);
    x.save(); x.globalAlpha = 0.9 * o; x.fillStyle = A;          // (the first ink covers what was there; only the second overprints it, so a dense picture doesn't sink to black)
    if (q.t === 'S') fillShape(x, q, A); else x.fill(path);
    x.globalCompositeOperation = 'multiply';
    const dx = (R() - 0.5) * size * 0.05 + (R() < 0.5 ? -1.5 : 1.5), dy = (R() - 0.5) * size * 0.05 + 1;
    x.translate(dx, dy);                            // the second drum, off register: only where the picture goes towards its second colour
    x.fillStyle = gradOf(x, q, [[0, rgbaOf(B, 0)], [0.45, rgbaOf(B, 0.25)], [1, rgbaOf(B, 0.95)]]);
    if (q.t === 'S') fillShape(x, q, x.fillStyle); else x.fill(path);
    x.translate(-dx, -dy);
    if (grain) { x.globalCompositeOperation = 'screen'; x.globalAlpha = 0.5 * o; if (q.t === 'S') fillShape(x, q, grain); else { x.fillStyle = grain; x.fill(path); } }
    x.restore(); return endOf(q);
  },
  tape(x, q, u = 1, dir = 1) {    // strips of coloured paper tape: straight, a little see-through, torn zigzag ends, a soft sheen and a shadow
    const [c0, c1, o] = colsOf(q), a = q.args, R = rngFor(a);
    const strips = [];
    if (q.t === 'S') strips.push([a[0], a[1], a[4], a[5], Math.max(3, a[6]), c0]);
    else if (q.t === 'R') { const [cx, cy, w, h, r] = a, lg = w >= h, L = (lg ? w : h) / 2, an = r + (lg ? 0 : Math.PI / 2); strips.push([cx - Math.cos(an) * L, cy - Math.sin(an) * L, cx + Math.cos(an) * L, cy + Math.sin(an) * L, lg ? h : w, c0]); }
    else {                                           // an area: covered with strips side by side
      const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), an = R() * Math.PI, dx = Math.cos(an), dy = Math.sin(an), nx = -dy, ny = dx, size = Math.max(b.w, b.h), tw = Math.max(4, size / 4);
      for (let v = -size / 2; v < size / 2; v += tw * 0.85) {
        let f = null, l = null; for (let j = 0; j <= 24; j++) { const s = -size / 2 + size * j / 24, px = b.cx + nx * v + dx * s, py = b.cy + ny * v + dy * s; if (inPoly(P, px, py)) { if (!f) f = [px, py]; l = [px, py]; } }
        if (f) strips.push([f[0] - dx * tw * 0.2, f[1] - dy * tw * 0.2, l[0] + dx * tw * 0.2, l[1] + dy * tw * 0.2, tw, mixHex(c0, c1, (v / size) + 0.5)]);
      }
    }
    x.save();
    for (const [x0, y0, x1, y1, w, col] of strips) {
      const L0 = Math.hypot(x1 - x0, y1 - y0); if (L0 < 1) continue;
      const L = L0 * (q.t === 'S' ? u : 1), an = Math.atan2(y1 - y0, x1 - x0), sx = dir < 0 && q.t === 'S' ? x1 : x0, sy = dir < 0 && q.t === 'S' ? y1 : y0;
      x.save(); x.translate(sx, sy); x.rotate(dir < 0 && q.t === 'S' ? an + Math.PI : an);
      const hw = w / 2, tooth = Math.max(1, w * 0.09), body = new Path2D();
      body.moveTo(0, -hw); body.lineTo(L, -hw);
      for (let k = 0, n = Math.max(3, Math.round(w / (tooth * 1.6))); k <= n; k++) body.lineTo(L + (k % 2 ? tooth : -tooth * 0.3) * (u >= 1 || q.t !== 'S' ? 1 : 0), -hw + w * k / n);
      body.lineTo(0, hw);
      for (let k = 0, n = Math.max(3, Math.round(w / (tooth * 1.6))); k <= n; k++) body.lineTo((k % 2 ? -tooth : tooth * 0.3), hw - w * k / n);
      body.closePath();
      const dk = devK(x); x.shadowColor = 'rgba(0,0,0,0.28)'; x.shadowBlur = Math.max(1, w * 0.12) * dk; x.shadowOffsetX = -LIGHT.x * w * 0.06 * dk; x.shadowOffsetY = -LIGHT.y * w * 0.06 * dk;
      x.globalAlpha = 0.86 * o; x.fillStyle = col; x.fill(body); x.shadowColor = 'transparent';
      const G = x.createLinearGradient(0, -hw, 0, hw); G.addColorStop(0, 'rgba(255,255,255,0.22)'); G.addColorStop(0.3, 'rgba(255,255,255,0.04)'); G.addColorStop(0.75, 'rgba(0,0,0,0.04)'); G.addColorStop(1, 'rgba(0,0,0,0.14)');
      x.globalAlpha = o; x.fillStyle = G; x.fill(body);
      x.save(); x.clip(body); x.globalAlpha = 0.12 * o; x.strokeStyle = shade(col, -0.35); x.lineWidth = Math.max(0.4, w * 0.02);     // the crêpe of paper tape, and a crease or two
      for (let s = R() * 4; s < L; s += 2 + R() * 4) { x.beginPath(); x.moveTo(s, -hw); x.lineTo(s + (R() - 0.5) * 2, hw); x.stroke(); }
      x.globalAlpha = 0.25 * o; x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(0.5, w * 0.03);
      for (let k = 0, n = R() < 0.5 ? 1 : 0; k < n; k++) { const s = L * (0.2 + R() * 0.6); x.beginPath(); x.moveTo(s, -hw); x.lineTo(s + w * 0.6, hw); x.stroke(); }
      x.restore(); x.restore();
    }
    x.restore(); return q.t === 'S' ? [a[4], a[5]] : endOf(q);
  },
  scribble(x, q) {        // a pen going back and forth inside the shape, a bit wobbly, sometimes a second layer across
    const [c, , o] = colsOf(q), P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), R = rngFor(q.args), size = Math.max(b.w, b.h, 2);
    const lw = Math.max(0.7, Math.min(3.2, size * 0.03)), gap = lw * 2.3, half = size * 0.75;
    x.save(); outlinePath(x, q); x.clip();
    x.globalAlpha = o; x.strokeStyle = c; x.lineWidth = lw; x.lineCap = x.lineJoin = 'round';
    for (let pass = 0, n = R() < 0.45 ? 2 : 1; pass < n; pass++) {
      x.save(); x.translate(b.cx, b.cy); x.rotate(R() * Math.PI + pass * 1.3);
      x.beginPath(); let y = -half, side = 1; x.moveTo(-half, y);
      while (y < half) { y += gap * (0.8 + R() * 0.5); x.lineTo(side * half + (R() - 0.5) * gap * 3, y); side = -side; }
      x.stroke(); x.restore();
    }
    x.restore();
  },
  halftone(x, q) {        // comic-book dots on a 45° screen, small at the first colour, big at the second
    const [c0, c1, o] = colsOf(q), P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), size = Math.max(b.w, b.h, 2), T = gradT(q);
    const d = Math.max(3.2, Math.min(13, size * 0.07)), n = Math.ceil(size * 0.75 / d) + 1, cs = Math.SQRT1_2;
    const paths = [new Path2D(), new Path2D(), new Path2D(), new Path2D()];
    for (let i = -n; i <= n; i++) for (let j = -n; j <= n; j++) {
      const u = i * d, v = j * d, px = b.cx + (u - v) * cs, py = b.cy + (u + v) * cs;
      if (px < b.x0 - d || px > b.x1 + d || py < b.y0 - d || py > b.y1 + d) continue;
      const t = T(px, py), k = Math.min(3, Math.floor(t * 4)), r = d * (0.2 + 0.32 * t);
      paths[k].moveTo(px + r, py); paths[k].arc(px, py, r, 0, 7);
    }
    x.save(); outlinePath(x, q); x.clip(); x.globalAlpha = o;
    paths.forEach((p, k) => { x.fillStyle = mixHex(c0, c1, (k + 0.5) / 4); x.fill(p); });
    x.restore();
  },
  glitch(x, q) {          // a level bar with a magenta / cyan split on its edges; now and then a slipped copy
    const a = q.args, [cx, cy, w, h] = a, [, , o] = colsOf(q), R = rngFor(a), off = Math.max(1, h * 0.4 + w * 0.006), e = Math.max(0.6, h * 0.22);
    SHP.lib(x).R(...a);
    x.save(); x.globalAlpha = 0.75 * o;
    x.fillStyle = '#ff2f6e'; x.fillRect(cx - w / 2 - off, cy - h / 2, w, e);
    x.fillStyle = '#2cf2ff'; x.fillRect(cx - w / 2 + off, cy + h / 2 - e, w, e);
    if (R() < 0.3) { const s = (R() - 0.5) * w * 0.3, k = 0.3 + R() * 0.4; x.globalAlpha = 0.55 * o; SHP.lib(x).R(cx + s, cy + (R() - 0.5) * h * 3, w * k, h * (0.4 + R() * 0.5), 0, a[5], a[6], a[7], 0.55 * o); }
    x.restore();
  },
  bokeh(x, q) {           // an out-of-focus light: a soft disc with a brighter rim
    const [cx, cy, rx, ry] = q.args, [c, , o] = colsOf(q), r = Math.max(0.5, (rx + ry) / 2), rim = mixHex(c, '#ffffff', 0.42);
    const G = x.createRadialGradient(cx, cy, 0, cx, cy, r);
    G.addColorStop(0, rgba(c, 0.5 * o)); G.addColorStop(0.78, rgba(c, 0.62 * o)); G.addColorStop(0.92, rgba(rim, 0.95 * o)); G.addColorStop(1, rgba(c, 0));
    x.save(); x.fillStyle = G; x.beginPath(); x.arc(cx, cy, r, 0, 7); x.fill(); x.restore();
  },
  paper(x, q) {           // torn paper: the outline roughened, a white fibre edge, laid on with a soft shadow
    const [c, , o] = colsOf(q), P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), size = Math.max(b.w, b.h, 2), R = rngFor(q.args);
    const amp = Math.max(0.5, Math.min(4, size * 0.028)), step = Math.max(1.5, size / 36);
    const torn = (inset, jit) => {
      const o2 = [], n = P.length / 2;
      for (let i = 0; i < n; i++) {
        const ax = P[i * 2], ay = P[i * 2 + 1], j = (i + 1) % n, bx = P[j * 2], by = P[j * 2 + 1], L = Math.hypot(bx - ax, by - ay), k = Math.max(1, Math.round(L / step));
        const nx = -(by - ay) / (L || 1), ny = (bx - ax) / (L || 1);
        for (let s = 0; s < k; s++) {
          const f = s / k, px = ax + (bx - ax) * f, py = ay + (by - ay) * f, dcx = b.cx - px, dcy = b.cy - py, dl = Math.hypot(dcx, dcy) || 1;
          const w = (R() - 0.5) * jit * amp * 2;
          o2.push(px + nx * w + dcx / dl * inset, py + ny * w + dcy / dl * inset);
        }
      }
      x.beginPath(); x.moveTo(o2[0], o2[1]); for (let i = 2; i < o2.length; i += 2) x.lineTo(o2[i], o2[i + 1]); x.closePath();
    };
    x.save(); x.globalAlpha = o;
    x.shadowColor = 'rgba(0,0,0,.34)'; x.shadowBlur = Math.max(1, Math.min(12, size * 0.06)) * devK(x); x.shadowOffsetX = x.shadowBlur * 0.25; x.shadowOffsetY = x.shadowBlur * 0.45;
    x.fillStyle = mixHex(c, '#f4f1ea', 0.82); torn(0, 1); x.fill();
    x.shadowColor = 'transparent'; x.fillStyle = c; torn(amp * 0.9, 1.3); x.fill();
    x.restore();
  },
  // ── drawing media ──
  pencil(x, q, u = 1, dir = 1) {   // coloured pencil: stamped, grainy lines that press harder in the middle; areas shaded with close strokes
    const [c, , o] = colsOf(q), R = rngFor(q.args), fast = false;     // (always the finished stamps: a line being drawn shows only as far as it has got)
    const pen = { q, args: q.args, fill: c, fast, upto: u, dir, spacing: 0.3, scatter: 0.55, sharp: 0.4, grain: 0.3, pmin: 0.55, pmax: 1.1, peak: 0.4, hw: 0.5, maxSteps: 200 };
    x.save(); x.lineCap = x.lineJoin = 'round';
    if (q.t === 'S') {
      const a = q.args, w = Math.max(0.9, Math.min(4.5, a[6])), P = quadPts(a, 1, dir, 20);
      stampLine(x, P, { ...pen, id: 'a', salt: 1, w: w * 1.15, alpha: o });                                  // the firm line
      stampLine(x, offsetPts(P, w * 0.5 * (R() < 0.5 ? 1 : -1)), { ...pen, id: 'b', salt: 2, w: w * 0.7, scatter: 0.9, grain: 0.5, alpha: o * 0.5 });     // a lighter pass a hair beside it
      x.restore(); const e = quadPts(a, u, dir, 1); return e[e.length - 1];
    }
    const P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), size = Math.max(b.w, b.h, 2);
    const lw = Math.max(0.8, Math.min(2.4, size * 0.02)), gap = lw * (fast ? 4 : 1.7), half = size * 0.75, ang = -0.95 + (R() - 0.5) * 0.3;
    outlinePath(x, q); x.clip();
    for (let pass = 0, n = size > 40 && !fast && R() < 0.5 ? 2 : 1; pass < n; pass++) {
      const lines = [], cs = Math.cos(ang + pass * 0.55), sn = Math.sin(ang + pass * 0.55), rot = (px, py) => [b.cx + px * cs - py * sn, b.cy + px * sn + py * cs];
      for (let y = -half; y <= half; y += gap * (0.85 + R() * 0.3)) { const j = (R() - 0.5) * gap * 0.4; lines.push([rot(-half + R() * size * 0.15, y + j), rot(half - R() * size * 0.15, y - j)]); }
      stampLine(x, lines, { ...pen, id: 'h' + pass, salt: 3 + pass, w: lw * 1.9, spacing: 0.7, maxSteps: Math.max(4, Math.min(60, Math.round(700 / lines.length))), alpha: o * (pass ? 0.55 : 0.95), peak: 0.5 });
    }
    x.restore(); return [q.args[0], q.args[1]];
  },

  pastel(x, q, u = 1, dir = 1) {   // soft pastel: chalky, broken up by the paper's grain, ragged at the edges, a little powdery
    const [c0, c1, o] = colsOf(q), R = rngFor(q.args), a = q.args, pat = patternFor('pastel', mixHex(c0, '#ffffff', 0.08)), dust = patternFor('grain', mixHex(c1, '#ffffff', 0.12));
    const ang = q.t === 'S' ? Math.atan2(a[5] - a[1], a[4] - a[0]) : R() * Math.PI;
    pat.setTransform(new DOMMatrix().translate(R() * 64, R() * 64).rotateSelf(ang * 57.29578));
    x.save(); x.lineCap = x.lineJoin = 'round';
    if (q.t === 'S') {
      const w = a[6], P = quadPts(a, u, dir, 24);
      for (let k = 0; k < 4; k++) {      // the body, then thinner passes wandering off its edges (the stick's corners catching the paper)
        const off = k ? (R() - 0.5) * w * 0.7 : 0;
        x.globalAlpha = o * (k ? 0.42 : 0.95); x.lineWidth = k ? w * (0.3 + R() * 0.3) : w * 0.85; x.strokeStyle = k === 3 ? dust : pat;
        offsetLine(x, P, off); x.stroke();
      }
      x.restore(); return P[P.length - 1];
    }
    const path = raggedPath(q, R, 0.05);
    x.globalAlpha = o * 0.95; x.fillStyle = pat; x.fill(path);
    x.globalAlpha = o * 0.35; x.fillStyle = dust; x.fill(path);
    x.restore(); return [a[0], a[1]];
  },
  pen(x, q, u = 1, dir = 1) {      // fine-liner: crisp even lines — strokes as single lines, shapes as their outline and contours inside it, over a pale wash
    const [c, , o] = colsOf(q), ink = shade(c, -0.38);
    x.save(); x.lineCap = x.lineJoin = 'round'; x.strokeStyle = ink;
    if (q.t === 'S') {
      const a = q.args, P = quadPts(a, u, dir, 20);
      x.globalAlpha = o; x.lineWidth = Math.max(0.8, Math.min(2.2, a[6] * 0.25)); offsetLine(x, P, 0); x.stroke();
      x.restore(); return P[P.length - 1];
    }
    const P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), size = Math.max(b.w, b.h, 2), lw = Math.max(0.7, Math.min(1.8, size * 0.012));
    x.globalAlpha = o * 0.4; x.fillStyle = c; outlinePath(x, q); x.fill();
    x.globalAlpha = o;
    const rings = Math.max(1, Math.min(6, Math.round(size / 12)));
    for (let k = 0; k < rings; k++) {
      const s = 1 - k / rings * 0.9;
      x.save(); x.translate(b.cx, b.cy); x.scale(s, s); x.translate(-b.cx, -b.cy); x.lineWidth = lw / s; outlinePath(x, q); x.stroke(); x.restore();
    }
    x.restore(); return [q.args[0], q.args[1]];
  },
  ink(x, q, u = 1, dir = 1) {      // ink brush: a loaded brush that swells and tapers, its tail breaking into dry streaks; shapes as ink pools
    const [c0, c1, o] = colsOf(q), R = rngFor(q.args), a = q.args;
    x.save(); x.lineCap = x.lineJoin = 'round';
    if (q.t === 'S') {
      const w = a[6], P = quadPts(a, u, dir, 28), n = P.length, cut = Math.round((n - 1) * 0.66);
      const wid = i => w * (0.22 + 0.9 * Math.pow(Math.sin(Math.PI * Math.min(1, (i / (n - 1)) * u * 0.92 + 0.06)), 0.55));
      // the loaded part of the stroke: one filled ribbon
      const L = [], Rt = [];
      for (let i = 0; i <= Math.min(cut, n - 1); i++) { const [nx, ny] = normalAt(P, i), h = wid(i) / 2; L.push([P[i][0] + nx * h, P[i][1] + ny * h]); Rt.push([P[i][0] - nx * h, P[i][1] - ny * h]); }
      x.globalAlpha = o; x.fillStyle = c0; x.beginPath();
      L.forEach(([px, py], i) => x[i ? 'lineTo' : 'moveTo'](px, py)); for (let i = Rt.length - 1; i >= 0; i--) x.lineTo(Rt[i][0], Rt[i][1]); x.closePath(); x.fill();
      x.beginPath(); x.arc(P[0][0], P[0][1], wid(0) * 0.6, 0, 7); x.fillStyle = shade(c0, -0.18); x.fill();     // where the brush touched down
      // the tail: separate hairs running dry, some stopping early
      if (n - 1 > cut) {
        const hairs = 7;
        for (let h = 0; h < hairs; h++) {
          const off = ((h + 0.5) / hairs - 0.5) * wid(cut) * 0.95, stop = cut + Math.round((n - 1 - cut) * (0.45 + R() * 0.55));
          x.globalAlpha = o * (0.55 + R() * 0.4); x.strokeStyle = c0; x.lineWidth = Math.max(0.6, wid(cut) / hairs * (0.9 + R() * 0.8));
          x.beginPath();
          for (let i = cut - 1; i <= stop; i++) { const [nx, ny] = normalAt(P, i), k = off * wid(i) / Math.max(0.1, wid(cut)); x[i === cut - 1 ? 'moveTo' : 'lineTo'](P[i][0] + nx * k, P[i][1] + ny * k); }
          x.stroke();
        }
      }
      x.restore(); return P[n - 1];
    }
    // an ink pool: denser at its rim where the ink dried, a soft feathered edge
    const path = raggedPath(q, R, 0.035), b = boxOf(SHP.poly({ t: q.t, p: a })), r = Math.max(1, Math.max(b.w, b.h) / 2);
    const G = x.createRadialGradient(b.cx, b.cy, 0, b.cx, b.cy, r); G.addColorStop(0, rgbaOf(c0, 0.62 * o)); G.addColorStop(0.75, rgbaOf(mixHex(c0, c1, 0.3), 0.72 * o)); G.addColorStop(1, rgbaOf(shade2(c0, -0.2), 0.9 * o));
    x.fillStyle = G; x.fill(path);
    x.globalAlpha = o * 0.35; x.strokeStyle = shade(c0, -0.3); x.lineWidth = Math.max(0.6, r * 0.04); x.stroke(path);
    x.restore(); return [a[0], a[1]];
  },
  hylics(x, q, u = 1, dir = 1) {        // after Hylics (Mason Lindroth): photographed clay, printed like a photocopy: flat vivid colour, a hard black
    // shadow on the far side, black stipple for the shading, a white highlight on the round pieces
    const [c0, c1, o] = colsOf(q), a = q.args, col = vivid(mixHex(c0, c1, 0.35)), round = q.t === 'E' || q.t === 'B';
    if (u < 1) return quickDraw(x, q, u, dir, col, o);
    const g = stampSet(q, 'hylics' + lightKey(), () => {
      const R = rngFor(a), path = raggedPath(q, R, 0.035, 1), P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), stroke = q.t === 'S';
      const rx = Math.max(1, b.w / 2), ry = Math.max(1, b.h / 2), half = stroke ? Math.max(1, a[6] / 2) : 1, mid = stroke ? quadPts(a, 1, 1, 16) : null;
      const dot = Math.max(1.1, Math.min(2.2, (stroke ? a[6] * 4 : size) * 0.009)), n = Math.min(2400, Math.round(b.w * b.h / (dot * dot * 9))), dots = new Path2D();
      for (let i = 0; i < n; i++) {
        const px = b.x0 + R() * b.w, py = b.y0 + R() * b.h; let ux, uy;
        if (stroke) { let bd = 1e9, vx = 0, vy = 0; for (const m of mid) { const dx = px - m[0], dy = py - m[1], dd = dx * dx + dy * dy; if (dd < bd) { bd = dd; vx = dx; vy = dy; } } ux = vx / half; uy = vy / half; }
        else { ux = (px - b.cx) / rx; uy = (py - b.cy) / ry; }
        const away = -(ux * LIGHT.x + uy * LIGHT.y), rim = Math.min(1, Math.hypot(ux, uy)), s = 0.5 * away + 0.55 * rim * rim + 0.08 * gaussR(R) - 0.05;
        if (R() < Math.max(0, Math.min(1, (s - 0.18) / 0.75))) dots.rect(px, py, dot, dot);
      }
      const hl = new Path2D(), hasHl = round && size > 28 && R() < 0.35;
      if (hasHl) hl.ellipse(b.cx + LIGHT.x * rx * 0.38, b.cy + LIGHT.y * ry * 0.38, rx * 0.4, ry * 0.34, Math.atan2(LIGHT.y, LIGHT.x) + Math.PI / 2, 0, 7);
      let line = null;                                  // a drawn line: now and then a white gleam along its lit side
      if (stroke && a[6] > 6 && R() < 0.55) { line = new Path2D(); const i0 = 3 + Math.floor(R() * 3), i1 = 13 - Math.floor(R() * 3); for (let i = i0; i <= i1; i++) line[i > i0 ? 'lineTo' : 'moveTo'](mid[i][0] + LIGHT.x * half * 0.42, mid[i][1] + LIGHT.y * half * 0.42); }
      return { path, dots, hl, hasHl, line, lw: half * 0.32, d: stroke ? a[6] * 0.16 : size * 0.06 };
    });
    x.save(); x.globalAlpha = o; x.fillStyle = '#000'; x.fill(g.path);                 // the black: where the light doesn't reach
    x.save(); x.clip(g.path);
    x.translate(LIGHT.x * g.d, LIGHT.y * g.d); x.fillStyle = col; x.fill(g.path); x.translate(-LIGHT.x * g.d, -LIGHT.y * g.d);   // the lit colour, shifted towards the light
    if (g.hasHl) { x.fillStyle = '#fbfbf6'; x.fill(g.hl); }
    x.fillStyle = '#000'; x.fill(g.dots);                                             // stipple shading
    if (g.line) { x.strokeStyle = '#fbfbf6'; x.lineCap = 'round'; x.lineWidth = g.lw; x.stroke(g.line); }
    x.restore(); x.restore(); return endOf(q);
  },
  lens(x, q, u = 1, dir = 1) {          // clear glass: what lies under it is bent (magnified; turned over in round pieces), tinted, with a bright rim on
    // the lit side, a glint, and a soft caustic thrown on the far side
    const [c0, , o] = colsOf(q), a = q.args;
    if (u < 1) return quickDraw(x, q, u, dir, c0, o * 0.35);
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), path = outlineOf(q), round = q.t === 'E' || q.t === 'B';
    const rx = Math.max(1, b.w / 2), ry = Math.max(1, b.h / 2), under = underRegion(x, b.x0 - 2, b.y0 - 2, b.w + 4, b.h + 4);
    x.save();
    const kx = b.cx - LIGHT.x * rx * 0.95, ky = b.cy - LIGHT.y * ry * 0.95, kr = Math.max(4, size * 0.42), K = x.createRadialGradient(kx, ky, 0, kx, ky, kr);
    K.addColorStop(0, rgbaOf(mixHex(c0, '#ffffff', 0.4), 0.28 * o)); K.addColorStop(1, rgbaOf(c0, 0));
    x.globalCompositeOperation = 'screen'; x.fillStyle = K; x.beginPath(); x.ellipse(kx, ky, kr, kr * 0.65, Math.atan2(LIGHT.y, LIGHT.x), 0, 7); x.fill(); x.globalCompositeOperation = 'source-over';   // the caustic
    x.save(); x.clip(path);
    if (under) {
      x.save(); x.translate(b.cx - LIGHT.x * size * 0.04, b.cy - LIGHT.y * size * 0.04);
      if (round) x.scale(-1.18, -1.18); else x.scale(1.14, 1.14);
      x.drawImage(under.cv, 0, 0, under.sw, under.sh, under.x0 - b.cx, under.y0 - b.cy, under.w, under.h); x.restore();
    }
    x.globalCompositeOperation = 'multiply'; x.globalAlpha = 0.75 * o; x.fillStyle = mixHex(c0, '#ffffff', 0.12); x.fill(path); x.globalCompositeOperation = 'source-over';
    x.globalAlpha = 0.3 * o; x.strokeStyle = '#000'; x.lineWidth = size * 0.1; x.stroke(path);                 // the glass thickens towards its edge
    litEdge(x, path, Math.max(1, size * 0.025), '#ffffff', Math.max(1.2, size * 0.025), 0.6 * o, true);
    const sx = b.cx + LIGHT.x * rx * 0.48, sy = b.cy + LIGHT.y * ry * 0.48, sr = Math.max(1.5, size * 0.13), Gs = x.createRadialGradient(sx, sy, 0, sx, sy, sr);
    Gs.addColorStop(0, 'rgba(255,255,255,0.8)'); Gs.addColorStop(1, 'rgba(255,255,255,0)'); x.globalAlpha = o; x.fillStyle = Gs; x.beginPath(); x.ellipse(sx, sy, sr, sr * 0.6, Math.atan2(LIGHT.y, LIGHT.x) + 1.57, 0, 7); x.fill();
    x.restore();
    x.globalAlpha = 0.25 * o; x.strokeStyle = '#ffffff'; x.lineWidth = 0.7; x.stroke(path);
    x.restore(); return endOf(q);
  },
  crystal(x, q, u = 1, dir = 1) {       // cut crystal: the shape cut into facets from a point near the light; each facet bends what is under it its own way,
    // facets that face the light flash white, the others darken, the cuts catch the light, and a sparkle on the brightest corner
    const [c0, , o] = colsOf(q), a = q.args;
    if (u < 1) return quickDraw(x, q, u, dir, c0, o * 0.4);
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), n = P.length / 2, step = Math.max(1, Math.ceil(n / 16)), pts = [];
    for (let i = 0; i < n; i += step) pts.push([P[i * 2], P[i * 2 + 1]]);
    const ax = b.cx + LIGHT.x * b.w * 0.12, ay = b.cy + LIGHT.y * b.h * 0.12, under = underRegion(x, b.x0 - size * 0.15, b.y0 - size * 0.15, b.w + size * 0.3, b.h + size * 0.3);
    x.save(); let best = -2, bp = pts[0];
    for (let i = 0; i < pts.length; i++) {
      const p0 = pts[i], p1 = pts[(i + 1) % pts.length], mx = (p0[0] + p1[0]) / 2 - ax, my = (p0[1] + p1[1]) / 2 - ay, ml = Math.hypot(mx, my) || 1, nx = mx / ml, ny = my / ml, lit = nx * LIGHT.x + ny * LIGHT.y;
      const tri = new Path2D(); tri.moveTo(ax, ay); tri.lineTo(p0[0], p0[1]); tri.lineTo(p1[0], p1[1]); tri.closePath();
      x.save(); x.clip(tri);
      if (under) { x.globalAlpha = o; x.drawImage(under.cv, 0, 0, under.sw, under.sh, under.x0 - nx * size * 0.12, under.y0 - ny * size * 0.12, under.w, under.h); }
      x.globalAlpha = 0.42 * o; x.fillStyle = c0; x.fill(tri);
      x.globalAlpha = o * Math.abs(lit) * (lit > 0 ? 0.32 : 0.14); x.fillStyle = lit > 0 ? '#ffffff' : '#000000'; x.fill(tri);
      x.restore();
      x.globalAlpha = 0.35 * o; x.strokeStyle = '#ffffff'; x.lineWidth = 0.6; x.stroke(tri);
      const vl = (p0[0] - b.cx) * LIGHT.x + (p0[1] - b.cy) * LIGHT.y; if (vl > best) { best = vl; bp = p0; }
    }
    x.globalAlpha = 0.3 * o; x.strokeStyle = '#000'; x.lineWidth = 0.9; x.stroke(outlineOf(q));
    const sr = Math.max(2, size * 0.09); x.globalAlpha = size > 80 && (b.cx * 7 + b.cy * 13) % 10 < 3 ? o : 0; x.fillStyle = '#ffffff'; x.beginPath();         // the sparkle (now and then, on big pieces)
    x.moveTo(bp[0], bp[1] - sr); x.quadraticCurveTo(bp[0], bp[1], bp[0] + sr, bp[1]); x.quadraticCurveTo(bp[0], bp[1], bp[0], bp[1] + sr); x.quadraticCurveTo(bp[0], bp[1], bp[0] - sr, bp[1]); x.quadraticCurveTo(bp[0], bp[1], bp[0], bp[1] - sr); x.fill();
    x.restore(); return endOf(q);
  },
  frost(x, q, u = 1, dir = 1) {         // frosted glass: what is under it blurred and whitened, a fine grain, the edge lit on one side
    const [c0, , o] = colsOf(q), a = q.args;
    if (u < 1) return quickDraw(x, q, u, dir, mixHex(c0, '#ffffff', 0.5), o * 0.4);
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), path = q.t === 'S' ? outlineOf(q) : raggedPath(q, rngFor(a), 0.02, 1), pad = size * 0.1;
    const under = underRegion(x, b.x0 - pad, b.y0 - pad, b.w + pad * 2, b.h + pad * 2);
    x.save(); x.save(); x.clip(path);
    if (under) {
      if (CAN_BLUR) { x.filter = `blur(${(Math.max(2, Math.min(14, size * 0.04)) * devK(x)).toFixed(1)}px)`; x.drawImage(under.cv, 0, 0, under.sw, under.sh, under.x0, under.y0, under.w, under.h); x.filter = 'none'; }
      else { x.imageSmoothingQuality = 'high'; x.drawImage(under.cv, 0, 0, under.sw, under.sh, under.x0, under.y0, under.w, under.h); }
    }
    x.globalAlpha = 0.62 * o; x.fillStyle = mixHex(c0, '#ffffff', 0.12); x.fill(path);
    x.globalAlpha = 0.14 * o; x.fillStyle = patternFor('chalk', '#ffffff'); x.fillRect(b.x0 - 2, b.y0 - 2, b.w + 4, b.h + 4);
    litEdge(x, path, Math.max(1, size * 0.025), '#ffffff', Math.max(2, size * 0.05), 0.75 * o, true);
    litEdge(x, path, Math.max(1, size * 0.025), '#000000', Math.max(2, size * 0.05), 0.25 * o, false);
    x.restore(); x.globalAlpha = 0.5 * o; x.strokeStyle = '#ffffff'; x.lineWidth = 0.8; x.stroke(path);
    x.restore(); return endOf(q);
  },
  neon(x, q, u = 1, dir = 1) {          // neon: a glass tube of light (glowing halo, the coloured tube, a white-hot core); shapes are drawn as their outline
    const [c0, c1, o] = colsOf(q), a = q.args, col = mixHex(vivid(mixHex(c0, c1, 0.4), 1), '#ffffff', 0.12);
    const P = SHP.poly({ t: q.t, p: a }), b = boxOf(P), size = Math.max(b.w, b.h, 2), lw = q.t === 'S' ? Math.max(1.2, a[6] * 0.55) : Math.max(1.2, Math.min(5, size * 0.03));
    x.save(); x.lineCap = x.lineJoin = 'round';
    const end = q.t === 'S' ? strokePath(x, a, u, dir) : (outlinePath(x, q), endOf(q));
    if (q.t !== 'S') { x.globalAlpha = 0.07 * o; x.fillStyle = col; x.fill(); }
    x.globalCompositeOperation = 'lighter';
    for (const [k, al] of [[4, 0.05], [2.6, 0.09], [1.6, 0.16]]) { x.globalAlpha = al * o; x.strokeStyle = col; x.lineWidth = lw * k; x.stroke(); }
    x.globalCompositeOperation = 'source-over'; x.globalAlpha = 0.95 * o; x.strokeStyle = col; x.lineWidth = lw; x.stroke();
    x.strokeStyle = mixHex(col, '#ffffff', 0.75); x.lineWidth = lw * 0.35; x.stroke();
    x.restore(); return end;
  },
  embroid(x, q, u = 1) {                // machine embroidery: short stitches laid in close rows, each a twisted yarn (see yarnStitches / drawYarn)
    const [c0, c1, o] = colsOf(q), st = stampSet(q, 'yarn', () => yarnStitches(q, rngFor(q.args)));
    drawYarn(x, st, u, c0, c1, o); return st.end;
  },
  thread(x, q, u = 1) {            // embroidery: stitched thread (see threadStitches / drawThread)
    const [c0, c1, o] = colsOf(q), st = stampSet(q, 'thread', () => threadStitches(q, rngFor(q.args)));
    drawThread(x, st, u, c0, c1, o); return st.end;
  },
  wet(x, q, u = 1) {               // wet watercolour: Tyler Hobbs' layered wash (a fractal-edged outline stacked in many transparent layers, each edge
    // darkening where they pile up, circles of pigment lifted out for the grain), glazed onto the canvas so overlapping washes darken
    const [c0, c1, o] = colsOf(q), a = q.args, R = rngFor(a), mid = mixHex(c0, c1, 0.5), stroke = q.t === 'S';
    const fast = u < 1, layers = fast ? 3 : 8, sig = 0.115;
    const geo = stampSet(q, 'wet' + layers, () => {      // the layers' outlines: made once and kept
      const P = SHP.poly({ t: q.t, p: a }), n = P.length / 2, stepI = Math.max(1, Math.ceil(n / 12));
      let base = []; for (let i = 0; i < n; i += stepI) base.push([P[i * 2], P[i * 2 + 1], 0.6 + R() * 0.8]);
      base = hobbsGrow(hobbsGrow(base, R, sig), R, sig * 0.8);
      let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9; const paths = [];
      for (let i = 0; i < layers; i++) {
        let p = base; for (let k = 0; k < 2; k++) p = hobbsGrow(p, R, sig * 0.62 * Math.pow(0.85, k));
        const pa = new Path2D(); p.forEach((v, j) => { pa[j ? 'lineTo' : 'moveTo'](v[0], v[1]); if (v[0] < x0) x0 = v[0]; if (v[0] > x1) x1 = v[0]; if (v[1] < y0) y0 = v[1]; if (v[1] > y1) y1 = v[1]; });
        pa.closePath(); paths.push(pa);
      }
      return { paths, x0, y0, x1, y1 };
    });
    const { paths, x0, y0, x1, y1 } = geo;
    const size = Math.max(x1 - x0, y1 - y0, 2), rim = shade(mid, -0.32);
    const paint = (c, lay) => {
      c.lineJoin = 'round'; const G = gradOf(c, q, [[0, c0], [1, c1]]);
      for (let i = 0; i < paths.length; i++) {
        c.globalAlpha = o * (fast ? 0.22 : 0.14); c.fillStyle = G; c.fill(paths[i]);
        c.globalAlpha = o * (fast ? 0.12 : 0.11); c.strokeStyle = rim; c.lineWidth = Math.max(0.5, size * 0.006); c.stroke(paths[i]);     // edges pile up darker
      }
    };
    if (fast) { x.save(); paint(x); x.restore(); return [stroke ? a[4] : a[0], stroke ? a[5] : a[1]]; }
    const m = x.getTransform(), sc0 = Math.hypot(m.a, m.b) || 1, bw = x1 - x0 + 4, bh = y1 - y0 + 4, sc = Math.min(sc0, 700 / Math.max(bw, bh));
    const tw = Math.max(2, Math.ceil(bw * sc)), th = Math.max(2, Math.ceil(bh * sc));
    if (!WET_TILE.cv) { WET_TILE.cv = document.createElement('canvas'); WET_TILE.x = WET_TILE.cv.getContext('2d'); }
    if (WET_TILE.cv.width < tw || WET_TILE.cv.height < th) { WET_TILE.cv.width = Math.max(WET_TILE.cv.width, tw); WET_TILE.cv.height = Math.max(WET_TILE.cv.height, th); }
    const t = WET_TILE.x; t.setTransform(1, 0, 0, 1, 0, 0); t.globalCompositeOperation = 'source-over'; t.globalAlpha = 1; t.clearRect(0, 0, tw, th);
    t.setTransform(sc, 0, 0, sc, (2 - x0) * sc, (2 - y0) * sc);
    paint(t);
    // granulation: pigment lifted out in soft circles (every fifth left out), then dark grains where pigment is
    const cx = (x0 + x1) / 2, cy = (y0 + y1) / 2, cnt = Math.min(90, 30 + Math.round(size * 0.2));
    t.globalCompositeOperation = 'destination-out';
    for (let i = 0; i < cnt; i++) { if (i % 5 === 4) continue; const r = size * (0.015 + R() * 0.12); t.globalAlpha = 0.05 + R() * 0.07; t.beginPath(); t.arc(cx + gaussR(R) * size * 0.3, cy + gaussR(R) * size * 0.3, r, 0, 7); t.fill(); }
    t.globalCompositeOperation = 'source-atop'; t.fillStyle = shade(c0, -0.45); t.globalAlpha = o * 0.25; t.beginPath();
    for (let i = 0, g = Math.min(110, Math.round(size * 0.5)); i < g; i++) { const gx = x0 + R() * (x1 - x0), gy = y0 + R() * (y1 - y0), r = Math.max(0.3, size * 0.004 * (0.5 + R())); t.moveTo(gx + r, gy); t.arc(gx, gy, r, 0, 7); }
    t.fill(); t.globalCompositeOperation = 'source-over'; t.globalAlpha = 1; t.setTransform(1, 0, 0, 1, 0, 0);
    x.save(); x.globalAlpha = 1;
    x.drawImage(WET_TILE.cv, 0, 0, tw, th, x0 - 2, y0 - 2, tw / sc, th / sc);
    if (tw * th < 400000) { x.globalCompositeOperation = 'multiply'; x.globalAlpha = 0.55; x.drawImage(WET_TILE.cv, 0, 0, tw, th, x0 - 2, y0 - 2, tw / sc, th / sc); }       // the glaze: darker where washes overlap
    x.restore(); return [stroke ? a[4] : a[0], stroke ? a[5] : a[1]];
  },

  wash(x, q) {                     // watercolour shapes: wet wavering washes, pigment pooled darker at the edge, a little granulation, now and then a bloom
    const [c0, c1, o] = colsOf(q), R = rngFor(q.args), b = boxOf(SHP.poly({ t: q.t, p: q.args })), size = Math.max(b.w, b.h, 2);
    x.save(); x.lineJoin = 'round';
    let path;
    for (let layer = 0; layer < 2; layer++) {
      path = raggedPath(q, R, 0.07 + layer * 0.04, layer ? 0.82 : 1);
      const c = layer ? mixHex(c0, c1, 0.6) : c0;
      x.globalAlpha = o * (layer ? 0.4 : 0.6); x.fillStyle = c; x.fill(path);
      x.globalAlpha = o * (layer ? 0.3 : 0.45); x.strokeStyle = shade(c, -0.3); x.lineWidth = Math.max(0.7, size * 0.016); x.stroke(path);
    }
    x.clip(path);
    const n = Math.min(160, Math.round(size * 0.8)), dot = Math.max(0.5, size * 0.006);
    x.globalAlpha = o * 0.22; x.fillStyle = shade(c0, -0.35); x.beginPath();
    for (let i = 0; i < n; i++) { const px = b.x0 + R() * b.w, py = b.y0 + R() * b.h; x.moveTo(px + dot, py); x.arc(px, py, dot * (0.5 + R()), 0, 7); }
    x.fill();
    if (R() < 0.3) {                  // a bloom: paler, where water ran back into the drying wash
      const px = b.x0 + b.w * (0.3 + R() * 0.4), py = b.y0 + b.h * (0.3 + R() * 0.4), r = size * (0.15 + R() * 0.15), G = x.createRadialGradient(px, py, 0, px, py, r);
      G.addColorStop(0, rgbaOf(mixHex(c0, '#ffffff', 0.4), 0.45 * o)); G.addColorStop(0.8, rgbaOf(mixHex(c0, '#ffffff', 0.3), 0.3 * o)); G.addColorStop(1, rgbaOf(shade2(c0, -0.25), 0));
      x.globalAlpha = 1; x.fillStyle = G; x.beginPath(); x.arc(px, py, r, 0, 7); x.fill();
    }
    x.restore(); return [q.args[0], q.args[1]];
  },
  // ── paint strokes (2D): the stroke as a ribbon that follows a brush, wobbling and swelling as a real one does ──
  watercolour(x, q, u = 1, dir = 1) {   // watercolour: transparent glazes that wander a little, a darker tide line at the edge, granulation, and a bead of wet pigment at the tip
    if (q.t !== 'S') return STYLE_DRAW.wash(x, q);
    const [c0, c1, o] = colsOf(q), a = q.args, R = rngFor(q.seed || a), w = a[6], P = quadPts(a, u, dir, 32);
    x.save(); x.lineJoin = 'round';
    let outer = null;
    for (let L = 0; L < 4; L++) {
      const rib = paintRibbon(P, s => w * (0.62 + 0.38 * Math.pow(Math.sin(Math.PI * Math.min(1, 0.08 + 0.92 * s * u)), 0.35)) * (1 - L * 0.07), R, 0.16, L * 1.7);
      if (!L) outer = rib;
      x.globalAlpha = o * 0.2; x.fillStyle = mixHex(c0, c1, L / 3); x.fill(rib);
    }
    x.globalAlpha = o * 0.32; x.strokeStyle = shade(mixHex(c0, c1, 0.5), -0.32); x.lineWidth = Math.max(0.6, w * 0.05); x.stroke(outer);   // the tide line
    x.save(); x.clip(outer); x.globalAlpha = o * 0.2; x.fillStyle = shade(c0, -0.35); x.beginPath();        // granulation
    const len = P.length, dots = Math.min(220, Math.round(w * len * 0.25)), d = Math.max(0.45, w * 0.025);
    for (let i = 0; i < dots; i++) { const p = P[Math.floor(R() * len)], j = (R() - 0.5) * w; const [nx, ny] = normalAt(P, Math.floor(R() * len)); x.moveTo(p[0] + nx * j + d, p[1] + ny * j); x.arc(p[0] + nx * j, p[1] + ny * j, d * (0.5 + R()), 0, 7); }
    x.fill(); x.restore();
    const e = P[P.length - 1], G = x.createRadialGradient(e[0], e[1], 0, e[0], e[1], w * 0.55);     // the wet bead where the brush is (or lifted off)
    G.addColorStop(0, rgbaOf(shade2(c1, -0.15), 0.32 * o)); G.addColorStop(1, rgbaOf(c1, 0)); x.globalAlpha = 1; x.fillStyle = G; x.beginPath(); x.arc(e[0], e[1], w * 0.55, 0, 7); x.fill();
    x.restore(); return e;
  },
  gouache(x, q, u = 1, dir = 1) {      // gouache: opaque, matte paint; the brush's streaks show in it, and its end breaks into dry bristles
    const [c0, c1, o] = colsOf(q), a = q.args, R = rngFor(q.seed || a);
    if (q.t !== 'S') {
      const path = raggedPath(q, R, 0.025), b = boxOf(SHP.poly({ t: q.t, p: a })), an = R() * Math.PI, sz = Math.max(b.w, b.h);
      x.save(); x.globalAlpha = o; x.fillStyle = gradOf(x, q, [[0, c0], [1, c1]]); x.fill(path); x.clip(path);
      x.translate(b.cx, b.cy); x.rotate(an); x.lineWidth = Math.max(0.6, sz * 0.012);
      for (let i = -sz; i < sz; i += Math.max(1.5, sz * 0.025)) { x.globalAlpha = o * (0.08 + R() * 0.12); x.strokeStyle = R() < 0.5 ? shade(c0, 0.18) : shade(c1, -0.15); x.beginPath(); x.moveTo(-sz, i + R() * 2); x.lineTo(sz, i + R() * 2); x.stroke(); }
      x.restore(); return [a[0], a[1]];
    }
    const w = a[6], P = quadPts(a, u, dir, 32), n = P.length, solid = Math.round((n - 1) * 0.8);
    x.save(); x.lineJoin = 'round'; x.lineCap = 'butt';
    const body = paintRibbon(P.slice(0, Math.max(2, solid + 1)), s => w * (0.85 + 0.15 * Math.sin(Math.PI * Math.min(1, s * 1.2 + 0.1))), R, 0.05, 0);
    x.globalAlpha = o; x.fillStyle = mixHex(c0, c1, 0.5); x.fill(body);
    const N = Math.max(4, Math.min(18, Math.round(w / 2.2)));
    for (let k = 0; k < N; k++) {                                       // bristles: streaks of both colours, the tail breaking up
      const off = ((k + 0.5) / N - 0.5) * w * 0.92, line = offsetPts(P, off), stop = Math.round((n - 1) * (0.72 + R() * 0.28));
      x.globalAlpha = o * (0.55 + R() * 0.4); x.strokeStyle = shade2(mixHex(c0, c1, (k + 0.5) / N), (R() - 0.5) * 0.25); x.lineWidth = w / N * 1.15;
      x.beginPath(); for (let i = 0; i <= Math.min(stop, n - 1); i++) x[i ? 'lineTo' : 'moveTo'](line[i][0], line[i][1]); x.stroke();
    }
    x.restore(); return P[n - 1];
  },
  sumi(x, q, u = 1, dir = 1) {         // sumi-e: grey-black ink on rice paper — the wet edge bleeds out in fine fibres, ink pools where the brush lands, and towards the end the dry brush splits into "flying white" (streaks of bare paper)
    const [c0, , o] = colsOf(q), a = q.args, R = rngFor(q.seed || a), g = hexRgb(c0), l = g[0] * 0.3 + g[1] * 0.59 + g[2] * 0.11;
    const ink = mixHex(SHP.hex([l, l, l].map(v => v * 0.55)), c0, 0.12), wash = mixHex(ink, '#ffffff', 0.45);
    x.save();
    if (q.t !== 'S') {                 // an ink wash: a pale pool, darker where it dried at the rim, fibres bleeding out
      const path = raggedPath(q, R, 0.05), b = boxOf(SHP.poly({ t: q.t, p: a })), size = Math.max(b.w, b.h, 2);
      x.globalAlpha = o * 0.5; x.fillStyle = wash; x.fill(path);
      x.globalAlpha = o * 0.4; x.strokeStyle = ink; x.lineWidth = Math.max(0.6, size * 0.012); x.stroke(path);
      x.restore(); return [a[0], a[1]];
    }
    const w = a[6], P = quadPts(a, u, dir, 36), n = P.length, wid = s => w * (0.5 + 0.5 * Math.pow(Math.sin(Math.PI * Math.min(1, 0.06 + 0.94 * s * u)), 0.5));
    const body = paintRibbon(P, wid, R, 0.12, 0);
    // fibres: the wet ink running out into the paper along both edges
    x.globalAlpha = o * 0.18; x.strokeStyle = wash; x.lineWidth = Math.max(0.4, w * 0.03); x.beginPath();
    for (let i = 0; i < n; i += 1) for (const sg of [1, -1]) {
      if (R() < 0.35) continue; const [nx, ny] = normalAt(P, i), h = wid(i / (n - 1)) / 2, len = w * (0.08 + R() * 0.3), ang = (R() - 0.5) * 0.9;
      const ex = P[i][0] + nx * h * sg, ey = P[i][1] + ny * h * sg, cs = Math.cos(ang), sn = Math.sin(ang), vx = (nx * cs - ny * sn) * sg, vy = (nx * sn + ny * cs) * sg;
      x.moveTo(ex, ey); x.lineTo(ex + vx * len, ey + vy * len);
    }
    x.stroke();
    x.globalAlpha = o * 0.35; x.fillStyle = wash; x.fill(paintRibbon(P, s => wid(s) * 1.18, R, 0.2, 2));     // the pale wet halo
    // the body: dark, a little paler in the middle where the brush was full of water; flying white towards its end
    const tmp = offscreenFor(x, P, w * 1.4); if (tmp) {
      const t = tmp.x; t.globalAlpha = o * 0.92; t.fillStyle = ink; t.fill(body);
      t.globalAlpha = o * 0.25; t.fillStyle = wash; t.fill(paintRibbon(P, s => wid(s) * 0.35, R, 0.3, 4));
      t.globalCompositeOperation = 'destination-out'; t.lineCap = 'round';
      const start = Math.floor((n - 1) * 0.45);
      for (let k = 0; k < 7; k++) {    // flying white: the dry brush skips, bare streaks along it
        const off = (R() - 0.5) * 0.8, from = start + Math.floor(R() * (n - start) * 0.5); if (from >= n - 1) continue;
        t.globalAlpha = 0.5 + R() * 0.5; t.lineWidth = Math.max(0.5, w * (0.04 + R() * 0.08)); t.beginPath();
        for (let i = from; i < n; i++) { const [nx, ny] = normalAt(P, i), h = wid(i / (n - 1)) * off; t[i === from ? 'moveTo' : 'lineTo'](P[i][0] + nx * h, P[i][1] + ny * h); }
        t.stroke();
      }
      t.globalCompositeOperation = 'source-over'; tmp.done();
    }
    const s0 = P[0], G = x.createRadialGradient(s0[0], s0[1], 0, s0[0], s0[1], w * 0.6);     // ink pooled where the brush landed
    G.addColorStop(0, rgbaOf(shade2(ink, -0.35), 0.55 * o)); G.addColorStop(1, rgbaOf(ink, 0)); x.globalAlpha = 1; x.fillStyle = G; x.beginPath(); x.arc(s0[0], s0[1], w * 0.6, 0, 7); x.fill();
    x.restore(); return P[n - 1];
  },
  calligraphy(x, q, u = 1, dir = 1) {  // broad-nib calligraphy: a chisel nib held at 40°, thick across it and a hairline along it, ink pooled at both ends
    const [c0, c1, o] = colsOf(q), a = q.args;
    if (q.t !== 'S') { SHP.lib(x)[q.t](...a); return [a[0], a[1]]; }
    const P = quadPts(a, u, dir, 32), w = Math.max(2, a[6]), cx = Math.cos(0.7) * w / 2, cy = Math.sin(0.7) * w / 2, band = new Path2D();
    for (let i = 0; i < P.length; i++) band[i ? 'lineTo' : 'moveTo'](P[i][0] + cx, P[i][1] + cy);
    for (let i = P.length - 1; i >= 0; i--) band.lineTo(P[i][0] - cx, P[i][1] - cy); band.closePath();
    x.save(); x.globalAlpha = o; const G = x.createLinearGradient(P[0][0], P[0][1], P[P.length - 1][0], P[P.length - 1][1]); G.addColorStop(0, c0); G.addColorStop(1, c1);
    x.fillStyle = G; x.fill(band); x.strokeStyle = G; x.lineWidth = Math.max(0.6, w * 0.06); x.stroke(band);
    for (const e of [P[0], P[P.length - 1]]) { x.globalAlpha = o * 0.35; x.fillStyle = shade(c0, -0.3); x.beginPath(); x.ellipse(e[0], e[1], w * 0.32, w * 0.16, 0.7, 0, 7); x.fill(); }
    x.restore(); return P[P.length - 1];
  },
  points(x, q) {                       // pointillism: each dot a dab of paint, with two small dabs of neighbouring colours beside it (the eye mixes them)
    const [c0, , o] = colsOf(q), a = q.args, R = rngFor(a), r = Math.max(0.8, (a[2] + a[3]) / 2), [h0, s0, l0] = rgbToHsl(...hexRgb(c0));
    x.save();
    const dab = (px, py, rr, col) => { x.fillStyle = col; x.beginPath(); x.ellipse(px, py, rr, rr * (0.75 + R() * 0.3), R() * 3.14, 0, 7); x.fill(); };
    for (const dh of [-0.07, 0.07]) { x.globalAlpha = o * 0.8; dab(a[0] + (R() - 0.5) * r * 1.6, a[1] + (R() - 0.5) * r * 1.6, r * 0.55, hslHex(h0 + dh, Math.min(1, s0 * 1.25), l0)); }
    x.globalAlpha = o; dab(a[0], a[1], r, c0);
    x.globalAlpha = o * 0.35; dab(a[0] - r * 0.25, a[1] - r * 0.3, r * 0.35, mixHex(c0, '#ffffff', 0.35));     // the dab's wet highlight
    x.restore(); return [a[0], a[1]];
  },
  marker(x, q, u = 1, dir = 1) {       // alcohol marker: a chisel tip at 45°, see-through ink that darkens where strokes cross, streaks along it, a blot where it rested
    const [c0, , o] = colsOf(q), a = q.args, w = Math.max(2, a[6]);
    x.save();
    if (q.t !== 'S') { x.globalAlpha = o * 0.6; x.fillStyle = c0; outlinePath(x, q); x.fill(); x.restore(); return [a[0], a[1]]; }
    const P = quadPts(a, u, dir, 24), cx = Math.cos(0.785) * w / 2, cy = Math.sin(0.785) * w / 2, band = new Path2D();
    for (let i = 0; i < P.length; i++) band[i ? 'lineTo' : 'moveTo'](P[i][0] + cx, P[i][1] - cy);
    for (let i = P.length - 1; i >= 0; i--) band.lineTo(P[i][0] - cx, P[i][1] + cy); band.closePath();
    x.globalAlpha = o * 0.7; x.fillStyle = c0; x.fill(band);
    x.globalAlpha = o * 0.12; x.strokeStyle = '#ffffff'; x.lineWidth = Math.max(0.5, w * 0.08);
    for (const f of [-0.25, 0.2]) { x.beginPath(); P.forEach((p, i) => x[i ? 'lineTo' : 'moveTo'](p[0] + cx * f * 2, p[1] - cy * f * 2)); x.stroke(); }
    if (u >= 1 && !q.sub) { x.globalAlpha = o * 0.25; x.fillStyle = shade(c0, -0.2); const e = P[P.length - 1]; x.beginPath(); x.arc(e[0], e[1], w * 0.42, 0, 7); x.fill(); }
    x.restore(); return P[P.length - 1];
  },
  charcoal(x, q, u = 1, dir = 1) { // charcoal (its colours already greyed by the painter): dusty, smudged, stamped with a wide scatter, broken by the grain
    const [c0, c1, o] = colsOf(q), R = rngFor(q.args), a = q.args, pat = patternFor('charcoal', c0), fast = false;
    const ang = q.t === 'S' ? Math.atan2(a[5] - a[1], a[4] - a[0]) : R() * Math.PI;
    pat.setTransform(new DOMMatrix().translate(R() * 64, R() * 64).rotateSelf(ang * 57.29578));
    x.save(); x.lineCap = x.lineJoin = 'round';
    const end = shapePath(x, q, u, dir);
    if (q.t === 'S') {
      x.globalAlpha = o * 0.1; x.strokeStyle = mixHex(c0, c1, 0.5); x.lineWidth = a[6] * 1.5; x.stroke();       // the faintest smudge
      x.globalAlpha = Math.min(1, o * 0.7); x.strokeStyle = pat; x.lineWidth = a[6] * 0.7; x.stroke();           // the body, in the paper's grain
      const P = quadPts(a, 1, dir, 20), ink = mixHex(c0, c1, 0.3), dust = { q, args: a, fast, upto: u, dir, fill: ink, w: Math.max(1.5, a[6] * 1.1), pmin: 0.55, pmax: 1.15, peak: 0.35, hw: 0.5, minStep: 0.55, maxSteps: 200, sharp: 0.68 };
      stampLine(x, P, { ...dust, id: 'c', salt: 1, spacing: 0.1, scatter: 1.7, grain: 0.55, alpha: Math.min(1, o * 1.1) });      // the thick, rough, pressed line
      stampLine(x, P, { ...dust, id: 'd', salt: 2, spacing: 0.2, scatter: 2.6, grain: 0.8, w: dust.w * 0.8, alpha: o * 0.7 });    // ragged crumbs along its edges
    } else {
      const size = Math.max(a[2] || 0, a[3] || 0, 4);
      x.globalAlpha = o * 0.12; x.strokeStyle = c0; x.lineWidth = size * 0.18; x.stroke();                         // smudged rim
      x.globalAlpha = o * 0.3; x.fillStyle = mixHex(c0, c1, 0.5); x.fill();
      x.globalAlpha = Math.min(1, o * 0.85); x.fillStyle = pat; x.fill();
    }
    x.restore(); return end;
  },

  stitch(x, q) {          // cross-stitch: an × in every square of a fixed fabric grid whose middle is inside the shape
    const [c, , o] = colsOf(q), P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), cell = STITCH;
    const i0 = Math.floor(b.x0 / cell), i1 = Math.ceil(b.x1 / cell), j0 = Math.floor(b.y0 / cell), j1 = Math.ceil(b.y1 / cell), X = new Path2D();
    const m = cell * 0.36;
    for (let j = j0; j <= j1; j++) for (let i = i0; i <= i1; i++) {
      const px = (i + 0.5) * cell, py = (j + 0.5) * cell; if (!inPoly(P, px, py)) continue;
      X.moveTo(px - m, py - m); X.lineTo(px + m, py + m); X.moveTo(px + m, py - m); X.lineTo(px - m, py + m);
    }
    x.save(); x.globalAlpha = o; x.lineCap = 'round'; x.lineWidth = cell * 0.26;
    x.save(); x.translate(cell * 0.07, cell * 0.09); x.strokeStyle = shade(c, -0.5); x.stroke(X); x.restore();
    x.strokeStyle = c; x.stroke(X);
    x.lineWidth = cell * 0.07; x.strokeStyle = shade(c, 0.35); x.globalAlpha = o * 0.6; x.save(); x.translate(-cell * 0.05, -cell * 0.05); x.stroke(X); x.restore();
    x.restore();
  }
};
const STITCH = 7;   // the fabric grid, in painting pixels (1000 across the long side)
// points along (the first part of) a quadratic stroke, for the media that build a stroke out of several lines
// a layer of its own for one stroke (so parts of it can be cut away without cutting into the canvas under it): covers the
// points P (± pad), in x's own coordinates; done() lays it onto x
function offscreenFor(x, P, pad) {
  const m = x.getTransform(); let a = 1e9, b = 1e9, c = -1e9, d = -1e9;
  for (const p of P) for (const [ox, oy] of [[-pad, -pad], [pad, -pad], [-pad, pad], [pad, pad]]) { const X0 = m.a * (p[0] + ox) + m.c * (p[1] + oy) + m.e, Y0 = m.b * (p[0] + ox) + m.d * (p[1] + oy) + m.f; a = Math.min(a, X0); b = Math.min(b, Y0); c = Math.max(c, X0); d = Math.max(d, Y0); }
  a = Math.max(0, Math.floor(a)); b = Math.max(0, Math.floor(b)); c = Math.min(x.canvas.width, Math.ceil(c)); d = Math.min(x.canvas.height, Math.ceil(d));
  const w = c - a, h = d - b; if (w < 1 || h < 1 || w * h > 1.6e7) return null;
  if (!OFFS.cv) { OFFS.cv = document.createElement('canvas'); OFFS.x = OFFS.cv.getContext('2d'); }
  if (OFFS.cv.width < w || OFFS.cv.height < h) { OFFS.cv.width = Math.max(OFFS.cv.width, w); OFFS.cv.height = Math.max(OFFS.cv.height, h); }
  const t = OFFS.x; t.setTransform(1, 0, 0, 1, 0, 0); t.globalCompositeOperation = 'source-over'; t.globalAlpha = 1; t.clearRect(0, 0, w, h);
  t.setTransform(m.a, m.b, m.c, m.d, m.e - a, m.f - b);
  return { x: t, done: () => { x.save(); x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1; x.drawImage(OFFS.cv, 0, 0, w, h, a, b, w, h); x.restore(); } };
}
const OFFS = { cv: null, x: null };
function rgbToHsl(r, g, b) {
  r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, s = 0;
  if (mx !== mn) { const d = mx - mn; s = l > 0.5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h /= 6; }
  return [h, s, l];
}
function hslHex(h, s, l) {
  h = ((h % 1) + 1) % 1; const f = n => { const k = (n + h * 12) % 12, a = s * Math.min(l, 1 - l); return l - a * Math.max(-1, Math.min(k - 3, 9 - k, 1)); };
  return SHP.hex([f(0), f(8), f(4)].map(v => v * 255));
}
// a brush stroke's ribbon along the points P: its width from w(s) (s = 0..1 along it), both edges wandering a little
// (amp of the width) on their own slow waves, round at both ends
function paintRibbon(P, w, R, amp, phase) {
  const ph = [R() * 6.28 + phase, R() * 6.28 + phase, R() * 6.28, R() * 6.28], n = P.length, L = [], Rt = [];
  const wav = (s, a, b) => 0.55 * Math.sin(s * 7 + a) + 0.3 * Math.sin(s * 17 + b) + 0.15 * Math.sin(s * 37 + a * 2);
  for (let i = 0; i < n; i++) {
    const s = i / Math.max(1, n - 1), [nx, ny] = normalAt(P, i), h = w(s) / 2;
    const hl = h * (1 + amp * wav(s, ph[0], ph[1])), hr = h * (1 + amp * wav(s, ph[2], ph[3]));
    L.push([P[i][0] + nx * hl, P[i][1] + ny * hl]); Rt.push([P[i][0] - nx * hr, P[i][1] - ny * hr]);
  }
  const path = new Path2D(); L.forEach((p, i) => path[i ? 'lineTo' : 'moveTo'](p[0], p[1]));
  // round ends: from one edge round the front (or back) of the stroke to the other
  const cap = (c, from, to, fwd) => {
    const fx = from[0] - c[0], fy = from[1] - c[1], tx = to[0] - c[0], ty = to[1] - c[1], r = (Math.hypot(fx, fy) + Math.hypot(tx, ty)) / 2 || 0.01;
    for (let k = 1; k < 8; k++) { const th = k / 8 * Math.PI, cs = Math.cos(th), sn = Math.sin(th); path.lineTo(c[0] + (fx * (1 + cs) + tx * (1 - cs)) / 2 + fwd[0] * r * sn, c[1] + (fy * (1 + cs) + ty * (1 - cs)) / 2 + fwd[1] * r * sn); }
  };
  const tan = (i, j) => { const dx = P[j][0] - P[i][0], dy = P[j][1] - P[i][1], l = Math.hypot(dx, dy) || 1; return [dx / l, dy / l]; };
  cap(P[n - 1], L[n - 1], Rt[n - 1], tan(Math.max(0, n - 2), n - 1));
  for (let i = n - 1; i >= 0; i--) path.lineTo(Rt[i][0], Rt[i][1]);
  const t0 = tan(0, Math.min(1, n - 1)); cap(P[0], Rt[0], L[0], [-t0[0], -t0[1]]); path.closePath();
  return path;
}
function offsetPts(P, off) {      // a polyline moved sideways
  return P.map((p, i) => { const a = P[Math.max(0, i - 1)], b = P[Math.min(P.length - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], l = Math.hypot(dx, dy) || 1; return [p[0] - dy / l * off, p[1] + dx / l * off]; });
}
function quadPts(a, u = 1, dir = 1, n = 24) {
  let [x0, y0, x1, y1, x2, y2] = a; if (dir < 0) [x0, y0, x2, y2] = [x2, y2, x0, y0];
  const P = [];
  for (let i = 0; i <= n; i++) { const s = u * i / n, v = 1 - s; P.push([v * v * x0 + 2 * v * s * x1 + s * s * x2, v * v * y0 + 2 * v * s * y1 + s * s * y2]); }
  return P;
}
function normalAt(P, i) {
  const a = P[Math.max(0, i - 1)], b = P[Math.min(P.length - 1, i + 1)], dx = b[0] - a[0], dy = b[1] - a[1], d = Math.hypot(dx, dy) || 1;
  return [-dy / d, dx / d];
}
// the line through the points, shifted sideways by off (as the current path)
function offsetLine(x, P, off) {
  x.beginPath();
  for (let i = 0; i < P.length; i++) { const [nx, ny] = normalAt(P, i); x[i ? 'lineTo' : 'moveTo'](P[i][0] + nx * off, P[i][1] + ny * off); }
}
// the shape's outline made organic: subdivided, nudged in and out (amp × its size), smoothed; k scales it about its middle
function raggedPath(q, R, amp, k = 1) {
  const P = SHP.poly({ t: q.t, p: q.args }), b = boxOf(P), size = Math.max(b.w, b.h, 2), step = Math.max(2, size / 28), pts = [];
  const n = P.length / 2;
  for (let i = 0; i < n; i++) {
    const ax = P[i * 2], ay = P[i * 2 + 1], j = (i + 1) % n, bx = P[j * 2], by = P[j * 2 + 1], m = Math.max(1, Math.round(Math.hypot(bx - ax, by - ay) / step));
    for (let s = 0; s < m; s++) pts.push([ax + (bx - ax) * s / m, ay + (by - ay) * s / m]);
  }
  let ph = R() * 6.28, f = 2 + Math.floor(R() * 3);
  const Q = pts.map(([px, py], i) => {
    const t = i / pts.length * 6.28, w = 1 + amp * (Math.sin(f * t + ph) * 0.6 + (R() - 0.5) * 0.8);
    return [b.cx + (px - b.cx) * w * k, b.cy + (py - b.cy) * w * k];
  });
  const path = new Path2D(), N = Q.length, mid = i => [(Q[i % N][0] + Q[(i + 1) % N][0]) / 2, (Q[i % N][1] + Q[(i + 1) % N][1]) / 2];
  const m0 = mid(N - 1); path.moveTo(m0[0], m0[1]);
  for (let i = 0; i < N; i++) { const m1 = mid(i); path.quadraticCurveTo(Q[i][0], Q[i][1], m1[0], m1[1]); }
  path.closePath();
  return path;
}
const rgbaOf = (c, a) => { const [r, g, b] = c.startsWith('#') ? hexRgb(c) : c.match(/\d+/g).map(Number); return `rgba(${r},${g},${b},${Math.max(0, Math.min(1, a))})`; };
const shade2 = (h, k) => { const [r, g, b] = hexRgb(h), f = v => Math.round(k < 0 ? v * (1 + k) : v + (255 - v) * k); return '#' + [f(r), f(g), f(b)].map(v => v.toString(16).padStart(2, '0')).join(''); };

// brushes.
//   texture brushes (bristle, chalk, sponge, canvas weave, crackle, grain, dry brush, wood grain): every stroke, blob, triangle and bar is filled with the
//     texture at one fixed scale — running along each stroke — over a faint wash of its second colour, so the
//     texture shows at any size.
//   stamp brushes (ink splat, your own picture): pressed along strokes as separate dabs, and as one dab per blob.
// Changing the brush repaints the picture with it (while zooming / live, it applies to the strokes that follow).
const BRUSH = { name: 'default', custom: null };
const TEXTURE_BRUSHES = new Set(['bristle', 'chalk', 'sponge', 'canvas', 'crackle', 'grain', 'dry', 'wood']);
const seeded = seed => { let s = seed >>> 0 || 1; return () => { s ^= s << 13; s >>>= 0; s ^= s >>> 17; s ^= s << 5; s >>>= 0; return s / 4294967296; }; };
const TILES = {};
function textureTile(kind) {           // 64 × 64, seamless, white with alpha
  if (TILES[kind]) return TILES[kind];
  const N = 64, c = document.createElement('canvas'); c.width = c.height = N; const x = c.getContext('2d'), R = seeded(97531);
  x.fillStyle = '#fff';
  if (kind === 'bristle') {            // hairs along the stroke, some dry and broken
    for (let i = 0; i < 20; i++) {
      const y = i * 3.2 + R() * 1.2, h = 0.8 + R() * 1.5, a = 0.35 + R() * 0.65;
      for (let px = 0; px < N;) { const len = 8 + R() * 40; x.globalAlpha = a * (0.55 + R() * 0.45); x.fillRect(px, y, Math.min(len, N - px), h); px += len + (R() < 0.4 ? 2 + R() * 7 : 0); }
    }
  } else if (kind === 'chalk') {       // dry grain: clumps and specks
    const G = Array.from({ length: 256 }, R), id = x.createImageData(N, N);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const clump = G[(j >> 2) * 16 + (i >> 2)] > 0.38, on = clump ? R() > 0.28 : R() > 0.9;
      id.data.set([255, 255, 255, on ? 200 + R() * 55 : 0], (j * N + i) * 4);
    }
    x.putImageData(id, 0, 0);
  } else if (kind === 'sponge') {      // porous: paint with holes punched through it
    x.fillRect(0, 0, N, N); x.globalCompositeOperation = 'destination-out';
    for (let i = 0; i < 70; i++) {
      const cx = R() * N, cy = R() * N, r = 1.2 + R() * 4.5;
      for (const ox of [-N, 0, N]) for (const oy of [-N, 0, N]) { x.beginPath(); x.arc(cx + ox, cy + oy, r, 0, 7); x.fill(); }
    }
  } else if (kind === 'canvas') {      // woven canvas: threads over and under, plus a little grain
    for (let i = 0; i < N; i += 4) for (let j = 0; j < N; j += 4) {
      const over = ((i + j) >> 2) % 2; x.globalAlpha = 0.55 + R() * 0.35;
      if (over) x.fillRect(i, j + 0.5, 4, 2.6); else x.fillRect(i + 0.5, j, 2.6, 4);
    }
  } else if (kind === 'crackle') {     // old varnish: plates of paint with fine cracks between them (cells that wrap round)
    const P = Array.from({ length: 16 }, () => [R() * N, R() * N, 0.72 + R() * 0.28]), id = x.createImageData(N, N);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      let d1 = 1e9, d2 = 1e9, k1 = 0;
      P.forEach(([px, py], k) => { let dx = Math.abs(i - px), dy = Math.abs(j - py); dx = Math.min(dx, N - dx); dy = Math.min(dy, N - dy); const d = Math.hypot(dx, dy); if (d < d1) { d2 = d1; d1 = d; k1 = k; } else if (d < d2) d2 = d; });
      const crack = d2 - d1 < 1.3;
      id.data.set([255, 255, 255, crack ? 0 : Math.round(255 * P[k1][2] * (0.9 + R() * 0.1))], (j * N + i) * 4);
    }
    x.putImageData(id, 0, 0);
  } else if (kind === 'grain') {       // fine pastel grain: specks of paint and bare paper
    const id = x.createImageData(N, N);
    for (let i = 0; i < N * N; i++) id.data.set([255, 255, 255, R() < 0.6 ? 170 + R() * 85 : R() * 70], i * 4);
    x.putImageData(id, 0, 0);
  } else if (kind === 'dry') {         // dry brush: a few long streaks with bare gaps, dragged across
    for (let i = 0; i < 11; i++) {
      const y = R() * N, h = 0.6 + R() * 3.2, a = 0.45 + R() * 0.55;
      for (let px = -R() * 30; px < N;) { const len = 14 + R() * 50; x.globalAlpha = a * (0.6 + R() * 0.4); x.fillRect(px, y, len, h); x.fillRect(px - N, y, len, h); x.fillRect(px, y - N, len, h); px += len + 4 + R() * 18; }
    }
  } else if (kind === 'graphite') {    // pencil on paper: firm lead, the paper's tooth showing through as fine specks
    const id = x.createImageData(N, N);
    for (let i = 0; i < N * N; i++) id.data.set([255, 255, 255, R() < 0.14 ? 95 + R() * 60 : 195 + R() * 60], i * 4);
    x.putImageData(id, 0, 0);
  } else if (kind === 'pastel') {      // soft pastel on rough paper: the colour sits on the paper's ridges and misses its dips
    const G = Array.from({ length: 64 }, R), v = (i, j) => G[((j & 7) * 8 + (i & 7))], id = x.createImageData(N, N);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const fx = i / 8, fy = j / 8, i0 = Math.floor(fx), j0 = Math.floor(fy), tx = fx - i0, ty = fy - j0;
      const ridge = (v(i0, j0) * (1 - tx) + v(i0 + 1, j0) * tx) * (1 - ty) + (v(i0, j0 + 1) * (1 - tx) + v(i0 + 1, j0 + 1) * tx) * ty;
      const on = ridge + (R() - 0.5) * 0.5 > 0.44;
      id.data.set([255, 255, 255, on ? 190 + R() * 65 : R() * 60], (j * N + i) * 4);
    }
    x.putImageData(id, 0, 0);
  } else if (kind === 'charcoal') {    // charcoal: dense streaks along the stroke, dust and bare specks
    const id = x.createImageData(N, N), row = Array.from({ length: N }, () => 0.45 + R() * 0.55);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) id.data.set([255, 255, 255, R() < 0.18 * (1.4 - row[j]) ? R() * 50 : row[j] * (150 + R() * 105)], (j * N + i) * 4);
    x.putImageData(id, 0, 0);
  } else if (kind === 'wood') {        // wood grain: rings running along the stroke, wavering
    const id = x.createImageData(N, N);
    for (let j = 0; j < N; j++) for (let i = 0; i < N; i++) {
      const w = Math.sin(2 * Math.PI * (j * 5 / N + 0.35 * Math.sin(2 * Math.PI * i / N) + 0.12 * Math.sin(2 * Math.PI * i * 3 / N + 1.7)));
      id.data.set([255, 255, 255, Math.round(120 + 110 * Math.pow((w + 1) / 2, 2.2) + R() * 25)], (j * N + i) * 4);
    }
    x.putImageData(id, 0, 0);
  }
  return (TILES[kind] = c);
}
// the texture tinted with a colour, as a repeating pattern (kept for the colours in use)
const PATS = new Map(); let patCtx = null;
function patternFor(kind, col) {
  const key = kind + col; let p = PATS.get(key);
  if (!p) {
    if (PATS.size > 700) PATS.clear();
    const t = document.createElement('canvas'); t.width = t.height = 64; const x = t.getContext('2d');
    x.drawImage(textureTile(kind), 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = col; x.fillRect(0, 0, 64, 64);
    patCtx = patCtx || document.createElement('canvas').getContext('2d');
    PATS.set(key, p = patCtx.createPattern(t, 'repeat'));
  }
  return p;
}
// the shape's outline as the current path (u < 1: only the first part of a stroke / a smaller blob)
function shapePath(x, q, u = 1, dir = 1) {
  const a = q.args, t = q.t;
  if (t === 'S') return strokePath(x, a, u, dir);
  x.beginPath();
  if (t === 'E' || t === 'B') x.ellipse(a[0], a[1], Math.max(0.1, a[2] * u), Math.max(0.1, a[3] * u), a[4], 0, 7);
  else { const p = SHP.poly({ t, p: a }); for (let i = 0; i < p.length; i += 2) x[i ? 'lineTo' : 'moveTo'](p[i], p[i + 1]); x.closePath(); }
  return [a[0], a[1]];
}
function textured(x, q, u = 1, dir = 1) {
  const a = q.args, t = q.t, o = a[a.length - 1], c1 = a[t === 'T' ? 7 : t === 'S' ? 8 : 6], c2 = a[t === 'T' ? 8 : t === 'S' ? 9 : 7];
  const R = rngFor(a), ang = t === 'S' ? Math.atan2(a[5] - a[1], a[4] - a[0]) : t === 'T' ? a[6] : a[5];
  const pat = patternFor(q.brush, c1);
  pat.setTransform(new DOMMatrix().translate(R() * 64, R() * 64).rotateSelf(ang * 57.29578).scaleSelf(1.3));
  x.save(); x.lineCap = 'round'; x.lineJoin = 'round';
  const end = shapePath(x, q, u, dir);
  const paint = style => { x.fillStyle = x.strokeStyle = style; if (t === 'S') { x.lineWidth = a[6]; x.stroke(); } else x.fill(); };
  x.globalAlpha = o * 0.3; paint(c2);                       // faint wash of the second colour (shows in the gaps)
  x.globalAlpha = Math.min(1, o * 1.1); paint(pat);         // the texture in the first colour
  x.restore(); return end;
}
// stamp brushes: your own picture (its transparency, or its dark parts, are the paint) or the ink splat
function stampFromImage(img) {
  const N = 128, c = document.createElement('canvas'); c.width = c.height = N; const x = c.getContext('2d');
  const k = Math.min(N / srcW(img), N / srcH(img)), w = srcW(img) * k, h = srcH(img) * k;
  x.drawImage(img, (N - w) / 2, (N - h) / 2, w, h);
  const id = x.getImageData(0, 0, N, N), d = id.data;
  let transparent = false; for (let i = 3; i < d.length; i += 4) if (d[i] < 250) { transparent = true; break; }
  for (let i = 0; i < d.length; i += 4) { const a = transparent ? d[i + 3] : 255 - (d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11); d[i] = d[i + 1] = d[i + 2] = 255; d[i + 3] = a; }
  x.putImageData(id, 0, 0);
  return c;
}
// stamps (128 × 128, white with alpha): ink splat, sparkle star, leaf, drop, smoke puff
const MASKS = {};
function stampMask(kind) {
  if (kind === 'custom') return BRUSH.custom;
  if (MASKS[kind]) return MASKS[kind];
  const N = 128, c = document.createElement('canvas'); c.width = c.height = N; const x = c.getContext('2d'), R = seeded(4242);
  x.fillStyle = '#fff';
  if (kind === 'star') {              // a four-pointed sparkle, curved in between its points
    x.beginPath(); x.moveTo(64, 4);
    for (const [px, py] of [[124, 64], [64, 124], [4, 64], [64, 4]]) x.quadraticCurveTo(64, 64, px, py);
    x.fill();
  } else if (kind === 'leaf') {       // a pointed leaf with its midrib and veins left bare
    x.beginPath(); x.moveTo(8, 64); x.bezierCurveTo(40, 12, 92, 14, 122, 64); x.bezierCurveTo(92, 114, 40, 116, 8, 64); x.fill();
    x.globalCompositeOperation = 'destination-out'; x.strokeStyle = '#000'; x.lineCap = 'round';
    x.lineWidth = 3; x.beginPath(); x.moveTo(12, 64); x.lineTo(116, 64); x.stroke();
    x.lineWidth = 1.6; for (let i = 0; i < 6; i++) { const px = 26 + i * 15; x.beginPath(); x.moveTo(px, 64); x.lineTo(px + 14, 64 - 22 + i * 1.5); x.moveTo(px, 64); x.lineTo(px + 14, 64 + 22 - i * 1.5); x.stroke(); }
  } else if (kind === 'drop') {       // a drop, with a small highlight left bare
    x.beginPath(); x.moveTo(64, 6); x.bezierCurveTo(78, 40, 104, 62, 104, 86); x.arc(64, 86, 40, 0, Math.PI); x.bezierCurveTo(24, 62, 50, 40, 64, 6); x.fill();
    x.globalCompositeOperation = 'destination-out'; x.beginPath(); x.ellipse(50, 84, 7, 12, 0.4, 0, 7); x.fill();
  } else if (kind === 'smoke') {      // a soft puff: overlapping blurry balls
    for (let i = 0; i < 9; i++) {
      const px = 40 + R() * 48, py = 40 + R() * 48, r = 16 + R() * 20, G = x.createRadialGradient(px, py, 0, px, py, r);
      G.addColorStop(0, 'rgba(255,255,255,.55)'); G.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = G; x.fillRect(0, 0, N, N);
    }
  } else {                            // ink splat
    x.beginPath();
    for (let i = 0; i <= 40; i++) { const a = i / 40 * 6.283, r = 30 + R() * 16 + (R() < 0.2 ? R() * 22 : 0); x[i ? 'lineTo' : 'moveTo'](64 + Math.cos(a) * r, 64 + Math.sin(a) * r); }
    x.fill();
    for (let i = 0; i < 14; i++) { const a = R() * 6.283, r = 50 + R() * 12; x.beginPath(); x.arc(64 + Math.cos(a) * r, 64 + Math.sin(a) * r, 1.5 + R() * 3.5, 0, 7); x.fill(); }
  }
  return (MASKS[kind] = c);
}
const TINTS = new WeakMap();      // per stamp: colour -> tinted stamp
function tinted(mask, col) {
  let M = TINTS.get(mask); if (!M) TINTS.set(mask, M = new Map());
  let t = M.get(col);
  if (!t) {
    if (M.size > 600) M.clear();
    t = document.createElement('canvas'); t.width = t.height = 128; const x = t.getContext('2d');
    x.drawImage(mask, 0, 0); x.globalCompositeOperation = 'source-in'; x.fillStyle = col; x.fillRect(0, 0, 128, 128);
    M.set(col, t);
  }
  return t;
}
const mixHex = (a, b, f) => { const A = hexRgb(a), B = hexRgb(b), c = A.map((v, i) => Math.round(v + (B[i] - v) * f)); return '#' + c.map(v => v.toString(16).padStart(2, '0')).join(''); };
// dabs along the stroke, clearly spaced, a little turned and sized at random; colour runs from one gradient colour to the other
function stamped(x, q, u = 1, dir = 1) {
  const a = q.args, t = q.t, o = a[a.length - 1], mask = stampMask(q.brush), R = rngFor(a);
  if (!mask) { SHP.lib(x)[t](...a); return [a[0], a[1]]; }
  x.save();
  if (t === 'S') {
    let [x0, y0, x1, y1, x2, y2, w] = a, h0 = a[8], h1 = a[9]; if (dir < 0) { [x0, y0, x2, y2] = [x2, y2, x0, y0]; [h0, h1] = [h1, h0]; }
    const size = Math.max(3, w * 1.7), len = Math.hypot(x1 - x0, y1 - y0) + Math.hypot(x2 - x1, y2 - y1);
    const n = Math.max(1, Math.min(40, Math.round(len * u / (size * 0.55)))); let ex = x0, ey = y0;
    x.globalAlpha = Math.min(1, o);
    for (let i = 0; i <= n; i++) {
      const s = u * i / n, v = 1 - s, px = v * v * x0 + 2 * v * s * x1 + s * s * x2, py = v * v * y0 + 2 * v * s * y1 + s * s * y2;
      const tx = 2 * v * (x1 - x0) + 2 * s * (x2 - x1), ty = 2 * v * (y1 - y0) + 2 * s * (y2 - y1), k = size * (0.8 + R() * 0.45);
      x.save(); x.translate(px, py); x.rotate(Math.atan2(ty, tx) + (R() - 0.5) * 0.9);
      x.drawImage(tinted(mask, mixHex(h0, h1, Math.round(s * 3) / 3)), -k / 2, -k / 2, k, k); x.restore();
      ex = px; ey = py;
    }
    x.restore(); return [ex, ey];
  }
  const [cx, cy, rx, ry, rot] = a;
  x.globalAlpha = o; x.translate(cx, cy); x.rotate(rot);
  x.drawImage(tinted(mask, a[6]), -rx * 1.2 * u, -ry * 1.2 * u, rx * 2.4 * u, ry * 2.4 * u);
  x.restore(); return [cx, cy];
}
function brushed(x, q, u = 1, dir = 1) {
  if (TEXTURE_BRUSHES.has(q.brush)) return textured(x, q, u, dir);
  if (q.t === 'S' || q.t === 'B' || q.t === 'E') return stamped(x, q, u, dir);
  SHP.lib(x)[q.t](...q.args); return [q.args[0], q.args[1]];
}
// the light pad: the sun sits where the light comes from; letting go relights the painting (every shape drawn again, in order)
const LIT_2D = new Set(['linocut', 'tape', 'hylics', 'frost', 'thread', 'embroid']);
function relight() {
  if (RLF.on && RLF.st && (S.endless.on || S.mode !== 'auto')) { RLF.st.dirty = true; reliefFlush(true); return; }
  if (S.mode !== 'auto' || !S.out || S.endless.on || !S.drawn.length) return;
  // relief: only the lighting is done again (unless 2D styles that follow the light are mixed in: those are drawn again)
  if (RLF.on && !S.drawn.some(d => LIT_2D.has(d.st))) { RLF.st.dirty = true; reliefFlush(true); S.big = null; return; }
  redrawAll();
}
function drawLightPad() {
  const c = $('lightpad'); if (!c) return; const dpr = Math.max(1, devicePixelRatio || 1);
  if (c.clientWidth && c.width !== Math.round(c.clientWidth * dpr)) { c.width = Math.round(c.clientWidth * dpr); c.height = Math.round(c.clientHeight * dpr); }
  const x = c.getContext('2d'), W = c.width, H = c.height, cx = W / 2, cy = H / 2, k = H / 48;
  x.clearRect(0, 0, W, H);
  const sx = cx + LIGHT.x * (W / 2 - 14 * k), sy = cy + LIGHT.y * (H / 2 - 9 * k), G = x.createRadialGradient(sx, sy, 0, sx, sy, W * 0.6);
  G.addColorStop(0, 'rgba(255,255,255,0.14)'); G.addColorStop(1, 'rgba(255,255,255,0)'); x.fillStyle = G; x.fillRect(0, 0, W, H);
  const B = x.createRadialGradient(cx + LIGHT.x * 6 * k, cy + LIGHT.y * 6 * k, 1, cx, cy, 14 * k); B.addColorStop(0, '#f2f2ef'); B.addColorStop(0.5, '#8e9198'); B.addColorStop(1, '#2b2c31');
  x.fillStyle = B; x.beginPath(); x.arc(cx, cy, 13 * k, 0, 7); x.fill();
  x.strokeStyle = getComputedStyle(document.body).getPropertyValue('--accent') || '#39ff88'; x.lineWidth = 2 * k; x.setLineDash([3 * k, 4 * k]); x.beginPath(); x.moveTo(cx, cy); x.lineTo(sx, sy); x.stroke(); x.setLineDash([]);
  x.fillStyle = x.strokeStyle; x.beginPath(); x.arc(sx, sy, 7 * k, 0, 7); x.fill();
}
function setBrush(name, customImg) {
  if (customImg) BRUSH.custom = stampFromImage(customImg);
  if (name === 'custom' && !BRUSH.custom) name = 'default';
  BRUSH.name = name; $('brush').value = name;
}
// repaint the picture so far with the current brush (not while zooming / live: those keep no stroke list)
function rebrush() {
  const b = BRUSH.name !== 'default' ? BRUSH.name : null;
  for (const L of S.landing || []) L.q.brush = b;
  if (S.mode !== 'auto' || !S.out || S.endless.on || !S.drawn.length) return false;
  for (const d of S.drawn) d.brush = b;
  redrawAll();
  return true;
}
// styles that draw a stroke part-way themselves (stamped lines laid down as the pen moves); the rest are drawn finished
// and uncovered along the stroke (clipReveal), so every style arrives in its own look, never as a plain stand-in
// (only the stamped media draw part-way themselves: their stamps are laid out over the whole stroke, so what is down
// never changes. Every other style shows its finished look uncovered along the stroke, so a line, once drawn, stays.)
const NATIVE_U = new Set(['pencil', 'charcoal', 'tape']);
const WIPE = new Set(['wet', 'wash']);
const REVEAL_PAD = { neon: 3.6, sumi: 2, watercolour: 1.8, wet: 2.8, wash: 2.4, ink: 1.7, calligraphy: 1.7, gouache: 1.6, thread: 1.6, embroid: 1.6, marker: 1.6, pastel: 1.6 };     // (how far round the line its look reaches: halos, bleeds, glows)
function clipReveal(x, q, u, dir) {
  if (WIPE.has(q.st)) {        // a wash spreads far round its line: wiped in instead, everything behind a front that moves along the stroke
    const a = q.args, [sx, sy, ex, ey] = dir < 0 ? [a[4], a[5], a[0], a[1]] : [a[0], a[1], a[4], a[5]], dx = ex - sx, dy = ey - sy, l = Math.hypot(dx, dy) || 1, ux = dx / l, uy = dy / l;
    const far = l * 3 + a[6] * 4, d = u * (l * 1.25 + a[6] * 4) - a[6] * 2 * (1 - u), fx = sx + ux * d, fy = sy + uy * d, back = l * 2 + a[6] * 8;
    x.save(); x.beginPath(); x.moveTo(fx - uy * far, fy + ux * far); x.lineTo(fx + uy * far, fy - ux * far); x.lineTo(fx + uy * far - ux * back * 2, fy - ux * far - uy * back * 2); x.lineTo(fx - uy * far - ux * back * 2, fy + ux * far - uy * back * 2); x.closePath(); x.clip();
    drawQ(x, q); x.restore(); return [fx, fy];
  }
  const a = q.args, P = quadPts(a, u, dir, 24), m = x.getTransform(), px = 1 / Math.max(1e-6, Math.hypot(m.a, m.b));
  const w = Math.max(a[6] / 2 * (REVEAL_PAD[q.st] || 1.4), a[6] / 2 + 6 * px) + 2 * px, L = offsetPts(P, w), Rr = offsetPts(P, -w);
  let area = 0; const poly = [...L, ...Rr.reverse()];
  for (let i = 0; i < poly.length; i++) { const p = poly[i], r = poly[(i + 1) % poly.length]; area += p[0] * r[1] - r[0] * p[1]; }
  const ccw = area < 0, e = P[P.length - 1], s0 = P[0], clip = new Path2D();
  poly.forEach((p, i) => clip[i ? 'lineTo' : 'moveTo'](p[0], p[1])); clip.closePath();
  for (const c of [e, s0]) { clip.moveTo(c[0] + w, c[1]); clip.arc(c[0], c[1], w, 0, Math.PI * 2, ccw); }    // (the same turning as the ribbon, so they add up)
  x.save(); x.clip(clip); drawQ(x, q); x.restore();
  return [e[0], e[1]];
}
// one stroke part-way (the draw motion), in whatever renderer it uses
function strokePart(a, u, dir, x = X) {
  let [x0, y0, x1, y1, x2, y2, w, g, h0, h1, o] = a;
  if (dir < 0) [x0, y0, x2, y2] = [x2, y2, x0, y0];
  const dx = Math.cos(g), dy = Math.sin(g); let m = 1e9, n = -1e9;
  for (const d of [x0 * dx + y0 * dy, x1 * dx + y1 * dy, x2 * dx + y2 * dy]) { if (d < m) m = d; if (d > n) n = d; }
  m -= w / 2; n += w / 2;
  const G = x.createLinearGradient(dx * m, dy * m, dx * n, dy * n); G.addColorStop(0, h0); G.addColorStop(1, h1);
  const qx = x0 + (x1 - x0) * u, qy = y0 + (y1 - y0) * u, ex = qx + (x1 + (x2 - x1) * u - qx) * u, ey = qy + (y1 + (y2 - y1) * u - qy) * u;
  x.globalAlpha = o; x.strokeStyle = G; x.lineWidth = w; x.lineCap = 'round';
  x.beginPath(); x.moveTo(x0, y0); x.quadraticCurveTo(qx, qy, ex, ey); x.stroke();
  return [ex, ey];
}
function strokeAt(x, q, u, dir) {
  const fp = fillParts(q);
  if (fp) { const { done, cur, f } = fillUpTo(fp, u); for (const p of done) drawQ(x, p); if (cur) return strokeAt(x, cur, f, 1); const e = done[done.length - 1]; return e ? [e.args[4], e.args[5]] : [q.args[0], q.args[1]]; }
  if (q.st === 'graffiti') return spray(x, q, u, dir);
  if (RELIEF[q.st]) { if (RLF.on && x === X) { const p = quadPart(q, u, dir).args; return [p[4], p[5]]; } return reliefFlat(x, q, u, dir); }
  if (NATIVE_U.has(q.st)) return STYLE_DRAW[q.st](x, q, u, dir);
  if (STYLE_DRAW[q.st]) return clipReveal(x, q, u, dir);       // (its finished look, uncovered along the stroke as it goes)
  if (q.brush) return brushed(x, q, u, dir);
  return strokePart(q.args, u, dir, x);
}

// ⟦style-runtime⟧ end
// ═════════════════════════════════════════════════════════════
//  Playlist: six slots, each a picture or a video. Playing a slot (click it, press 1–6, or drop something on it)
//  paints it over whatever is on the canvas now; the viewer shows all filled slots. A video slot plays (muted,
//  looping) while it is the one being painted.
//  cycle: the slots take turns (hold time, or the next hit with music); by hand: they change only when you play one.
// ═════════════════════════════════════════════════════════════
const SLOTS = Array(10).fill(null);
const slotList = () => SLOTS.filter(Boolean).map(s => ({ el: s.el, name: s.name }));
function renderSlots() {
  document.querySelectorAll('#slots .slot').forEach((el, i) => {
    const s = SLOTS[i];
    el.classList.toggle('full', !!s); el.classList.toggle('on', !!s && S.fromSlots && S.orig === s.el);
    el.style.backgroundImage = s ? `url("${s.url}")` : ''; el.classList.toggle('isvid', !!s && !!s.video);
  });
}
async function fillSlot(i, file, play = true) {
  const url = URL.createObjectURL(file);
  try {
    if (isVideo(file)) {
      const v = document.createElement('video'); v.muted = true; v.loop = true; v.playsInline = true; v.preload = 'auto'; v.src = url;
      await new Promise((ok, bad) => { v.onloadeddata = ok; v.onerror = () => bad(new Error("this browser can't play it")); });
      await seekTo(v, Math.min(0.5, (v.duration || 1) / 3));
      const c = document.createElement('canvas'); c.width = 192; c.height = 108; drawCover(c.getContext('2d'), v, 0, 0, 192, 108);
      SLOTS[i] = { el: v, url: c.toDataURL('image/jpeg', 0.8), name: nameOf(file), video: true };
    } else SLOTS[i] = { el: await loadImg(url), url, name: nameOf(file) };
  } catch (e) { $('hint').textContent = `Couldn't open ${file.name} (${e.message}).`; return false; }
  renderSlots(); if (play) playSlot(i);
  return true;
}
// several pictures / videos at once: the first into slot i, the rest into the empty slots after it (round to the start);
// then the first one plays
async function fillSlots(i, files) {
  files = files.filter(f => isImage(f) || isVideo(f)).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  if (!files.length) return;
  const at = [i];
  for (let k = 1; k < SLOTS.length && at.length < files.length; k++) { const j = (i + k) % SLOTS.length; if (!SLOTS[j]) at.push(j); }
  let first = -1;
  for (let k = 0; k < at.length; k++) { if (await fillSlot(at[k], files[k], false) && first < 0) first = at[k]; }
  if (first >= 0) playSlot(first);
  const left = files.length - at.length;
  if (left > 0) $('hint').textContent = `The playlist holds ${SLOTS.length}: ${left} of them didn't fit (empty a slot with its ✕ to make room).`;
  else if (files.length > 1) $('hint').textContent = `${files.length} added to the playlist: press 1 – 9 / 0 (or click a slot) to paint one.`;
}
// a video slot plays while it is the one being painted; the one before it stops
function slotVideo(prev, next) {
  if (prev && prev !== next && prev.pause) prev.pause();
  if (!next || !(next instanceof HTMLVideoElement)) return;
  S.video = next; next.muted = true; next.loop = false; next.onended = () => videoTick(); next.playbackRate = +$('vspeed').value;
  const [a, b] = vRange(next); if (next.currentTime < a || next.currentTime >= b - 0.05) next.currentTime = a;
  if (!OFF.on) next.play().catch(() => {});
}
function clearSlot(i) {
  const s = SLOTS[i]; if (!s) return;
  SLOTS[i] = null; if (s.video) { s.el.pause(); if (S.video === s.el) S.video = null; }
  if (S.fromSlots) {
    const list = slotList();
    if (list.length) {
      const k = list.findIndex(t => t.el === S.orig); S.list = list; S.li = Math.max(0, k); if (k < 0) S.orig = list[0].el;
      S.startArgs = [S.orig, list[S.li].name, '', { list: list.length > 1 ? list : null, slots: true, first: S.li, video: S.orig instanceof HTMLVideoElement ? S.orig : null }];
    }
  }
  renderSlots();
}
async function playSlot(i) {
  const s = SLOTS[i]; if (!s) return;
  const list = slotList(), k = list.findIndex(t => t.el === s.el);
  // nothing painted yet (or a replay): start a painting of this picture
  if (S.mode !== 'auto' || !S.out) { await startAuto(s.el, s.name, '', { list: list.length > 1 ? list : null, slots: true, first: k, video: s.video ? s.el : null }); renderSlots(); return; }
  // otherwise it is painted over what is there: a video / live input stops (unless it is this slot), the painter
  // carries on with this picture or video
  if (S.video && S.video !== s.el) { S.video.pause(); if (S.video.srcObject) stopLive(); S.video = null; }
  S.fromSlots = true; S.list = list; S.li = k; S.orig = s.el; S.holdT = 0; S.wantNext = false; S.done = false; S.picN = (S.picN || 0) + 1;
  S.startArgs = [s.el, s.name, '', { list: list.length > 1 ? list : null, slots: true, first: k, video: s.video ? s.el : null }];   // (⟲ / ⏺ start from here)
  slotVideo(null, s.video ? s.el : null);
  if (!S.endless.on) beginEndless();
  if (!S.running) { S.running = true; S.pausedTotal += clock() - (S.pausedAt || clock()); S.pausedAt = 0; setButtons(); }
  $('hint').textContent = `Slot ${i + 1}: painting ${s.name} over the picture.`;
  renderSlots();
}
// what the viewer shows next to the painting: the filled slots (the one being painted highlighted), or the original
function viewerItems() {
  if (S.fromSlots) { const v = SLOTS.map((s, i) => s && { el: s.el, on: S.orig === s.el, n: i + 1 }).filter(Boolean); if (v.length) return v; }
  return S.orig ? [{ el: S.orig, on: true, n: 0 }] : [];
}
// pictures side by side in a rectangle, cropped to fill their tile; the one being painted is lit, the rest dimmed
function drawTiles(items, R, radius, labels) {
  const n = items.length, gap = 14, tw = (R.w - gap * (n - 1)) / n;
  items.forEach((it, i) => {
    const r = { x: R.x + i * (tw + gap), y: R.y, w: tw, h: R.h };
    X.save(); X.beginPath(); X.roundRect(r.x, r.y, r.w, r.h, radius); X.clip();
    X.globalAlpha = it.on ? 1 : 0.5; drawCover(X, it.el, r.x, r.y, r.w, r.h); X.restore();
    rr(r.x + 0.5, r.y + 0.5, r.w - 1, r.h - 1, radius, null, it.on ? COL.accent2 : 'rgba(255,255,255,.07)', it.on ? 2 : 1);
    if (labels && it.n) chip(r.x + 10, r.y + 10, String(it.n), it.on ? COL.accent2 : COL.dim);
  });
}
// ∞ infinite: when the picture is finished the painter keeps painting over it (and over each picture that follows)
const infinite = () => $('infinite').checked;
// the colours of the code (numbers / keywords, and function names + the highlight)
function setCodeColours() {
  const c1 = $('codec1').value, c2 = $('codec2').value;
  COL.num = COL.kw = c1; COL.fn = c2; COL.hi = rgba(c2, 0.11); COL.hi2 = rgba(c1, 0.14);
  store('cp-codec', c1 + ',' + c2);
}

// ═════════════════════════════════════════════════════════════
//  The painting panel: the painting inside the chosen frame cut-out, with its rim
// ═════════════════════════════════════════════════════════════
const frameReact = () => $('framereact').checked && musicOn() ? AU.bass : 0;
function paintPanel(b, now, r) {
  const P = frameShape(b, now);
  X.save(); tracePts(X, P); X.clip();
  paintContent(b, now, r);
  if (SPRAY.wall !== 'none' && S.out) wallOver(X, b.x, b.y, b.w, b.h);
  X.restore();
  drawRim(b, now, P);
}
// the surface the painting is sprayed on: a concrete or a brick wall, showing through the paint (multiplied over it, so
// the mortar, the pits and the grain come through like paint on a real wall). Made once per kind and size, seeded.
const WALL = { key: '', cv: null };
function wallTexture(kind, w, h) {
  const key = kind + w + 'x' + h; if (WALL.key === key) return WALL.cv;
  const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'), R = rngFor([w, h, kind === 'brick' ? 7 : 3, 1, 2, 5]), L = Math.max(w, h);
  x.fillStyle = '#ffffff'; x.fillRect(0, 0, w, h);
  if (kind === 'brick') {
    const bh = L / 26, bw = bh * 2.15, mo = Math.max(1.5, bh * 0.12);
    x.fillStyle = '#bdb7ae'; x.fillRect(0, 0, w, h);                                  // the mortar
    for (let row = 0, y = 0; y < h; row++, y += bh) for (let bx = -(row % 2) * bw / 2; bx < w; bx += bw) {
      const v = 225 + Math.round((R() - 0.5) * 40); x.fillStyle = `rgb(${v},${v - 6},${v - 14})`;
      x.fillRect(bx + mo / 2, y + mo / 2, bw - mo, bh - mo);
      x.fillStyle = 'rgba(0,0,0,0.07)'; x.fillRect(bx + mo / 2, y + bh - mo * 1.6, bw - mo, mo * 0.9);   // (a shadow under each brick)
    }
  }
  // blotches, pits and grain
  for (let i = 0; i < L * 0.6; i++) { const px = R() * w, py = R() * h, r = L * (0.004 + R() * R() * 0.05), G = x.createRadialGradient(px, py, 0, px, py, r), d = R() < 0.6; G.addColorStop(0, d ? 'rgba(60,55,50,0.10)' : 'rgba(255,255,255,0.18)'); G.addColorStop(1, 'rgba(0,0,0,0)'); x.fillStyle = G; x.fillRect(px - r, py - r, r * 2, r * 2); }
  for (let i = 0; i < L * 3; i++) { x.fillStyle = `rgba(40,36,32,${0.08 + R() * 0.22})`; const r = R() * L * 0.0016 + 0.4; x.beginPath(); x.arc(R() * w, R() * h, r, 0, 7); x.fill(); }
  if (kind === 'concrete') for (let i = 0; i < 3; i++) {          // a few hairline cracks
    let px = R() * w, py = R() * h, a = R() * 6.28; x.strokeStyle = 'rgba(40,36,32,0.35)'; x.lineWidth = Math.max(0.6, L * 0.0009); x.beginPath(); x.moveTo(px, py);
    for (let k = 0; k < 40; k++) { a += (R() - 0.5) * 0.9; px += Math.cos(a) * L * 0.006; py += Math.sin(a) * L * 0.006; x.lineTo(px, py); } x.stroke();
  }
  const img = x.getImageData(0, 0, w, h), d = img.data; for (let i = 0; i < d.length; i += 4) { const n = (R() - 0.5) * 26; d[i] += n; d[i + 1] += n; d[i + 2] += n; } x.putImageData(img, 0, 0);
  WALL.key = key; WALL.cv = c; return c;
}
function wallOver(x, X0, Y0, w, h) {
  const k = Math.min(1, 1400 / Math.max(w, h)), T = wallTexture(SPRAY.wall, Math.round(w * k), Math.round(h * k));
  x.save(); x.globalCompositeOperation = 'multiply'; x.globalAlpha = 0.85; x.drawImage(T, X0, Y0, w, h); x.restore();
}
// the frame outline as a closed list of points [x0, y0, x1, y1, …]; the blob breathes on its own and (with ♪ react)
// everything swells a little on the bass and the blob wobbles with it
function frameShape(b, now) {
  const f = $('frame').value, cx = b.x + b.w / 2, cy = b.y + b.h / 2, t = now / 1000, bass = frameReact(), T = Math.PI * 2;
  const k = f === 'rect' ? 1 : 0.97 * (1 + 0.035 * bass), rx = b.w / 2 * k, ry = b.h / 2 * k, P = [];
  const add = (x, y) => P.push(x, y);
  const edge = (x0, y0, x1, y1, n = 40) => { for (let i = 0; i < n; i++) add(x0 + (x1 - x0) * i / n, y0 + (y1 - y0) * i / n); };
  const arc = (ax, ay, r1, r2, a0, a1, n) => { for (let i = 0; i < n; i++) { const a = a0 + (a1 - a0) * i / n; add(ax + Math.cos(a) * r1, ay + Math.sin(a) * r2); } };
  const polygon = (n, rot, inner) => {
    const m = n * (inner ? 2 : 1), V = [];
    for (let i = 0; i < m; i++) { const a = rot + i / m * T, q = inner && i % 2 ? inner : 1; V.push(cx + Math.cos(a) * rx * q, cy + Math.sin(a) * ry * q); }
    for (let i = 0; i < V.length; i += 2) { const j = (i + 2) % V.length; edge(V[i], V[i + 1], V[j], V[j + 1]); }
  };
  if (f === 'rounded') {
    const r = Math.min(rx, ry) * 0.22, x0 = cx - rx, x1 = cx + rx, y0 = cy - ry, y1 = cy + ry;
    edge(x0 + r, y0, x1 - r, y0); arc(x1 - r, y0 + r, r, r, -T / 4, 0, 16);
    edge(x1, y0 + r, x1, y1 - r); arc(x1 - r, y1 - r, r, r, 0, T / 4, 16);
    edge(x1 - r, y1, x0 + r, y1); arc(x0 + r, y1 - r, r, r, T / 4, T / 2, 16);
    edge(x0, y1 - r, x0, y0 + r); arc(x0 + r, y0 + r, r, r, T / 2, T * 0.75, 16);
  } else if (f === 'circle') { const R = Math.min(rx, ry); arc(cx, cy, R, R, 0, T, 240); }
  else if (f === 'oval') arc(cx, cy, rx, ry, 0, T, 240);
  else if (f === 'arch') {
    const top = cy - ry + Math.min(rx, ry * 0.9);
    edge(cx - rx, cy + ry, cx - rx, top); arc(cx, top, rx, Math.min(rx, ry * 0.9), Math.PI, T, 120);
    edge(cx + rx, top, cx + rx, cy + ry); edge(cx + rx, cy + ry, cx - rx, cy + ry);
  } else if (f === 'hexagon') polygon(6, Math.PI / 6);
  else if (f === 'diamond') polygon(4, -Math.PI / 2);
  else if (f === 'star') polygon(6, -Math.PI / 2, 0.62);
  else if (f === 'blob') {
    for (let i = 0, n = 240; i < n; i++) {
      const a = i / n * T, q = 0.9 + 0.045 * Math.sin(3 * a + t * 0.7) + 0.03 * Math.sin(5 * a - t * 1.1) + 0.02 * Math.sin(2 * a + t * 0.4) + bass * 0.07 * Math.sin(7 * a + t * 3);
      add(cx + Math.cos(a) * rx * q, cy + Math.sin(a) * ry * q);
    }
  } else { edge(b.x, b.y, b.x + b.w, b.y); edge(b.x + b.w, b.y, b.x + b.w, b.y + b.h); edge(b.x + b.w, b.y + b.h, b.x, b.y + b.h); edge(b.x, b.y + b.h, b.x, b.y); }
  return P;
}
function tracePts(x, P) { x.beginPath(); x.moveTo(P[0], P[1]); for (let i = 2; i < P.length; i += 2) x.lineTo(P[i], P[i + 1]); x.closePath(); }
// walking along the outline: cumulative lengths, and the point / direction at a distance s
function along(P) {
  const n = P.length / 2, cum = new Float32Array(n + 1);
  for (let i = 0; i < n; i++) { const j = (i + 1) % n; cum[i + 1] = cum[i] + Math.hypot(P[j * 2] - P[i * 2], P[j * 2 + 1] - P[i * 2 + 1]); }
  const L = cum[n];
  const at = s => {
    s = ((s % L) + L) % L; let lo = 0, hi = n;
    while (lo < hi) { const m = (lo + hi) >> 1; if (cum[m + 1] < s) lo = m + 1; else hi = m; }
    const i = Math.min(lo, n - 1), j = (i + 1) % n, seg = cum[i + 1] - cum[i] || 1, u = (s - cum[i]) / seg;
    const dx = P[j * 2] - P[i * 2], dy = P[j * 2 + 1] - P[i * 2 + 1], d = Math.hypot(dx, dy) || 1;
    return [P[i * 2] + dx * u, P[i * 2 + 1] + dy * u, dx / d, dy / d];
  };
  return { L, at };
}
const lighten = (hex, k) => { const n = parseInt(hex.slice(1), 16), c = v => Math.round(v + (255 - v) * k); return `rgb(${c(n >> 16 & 255)},${c(n >> 8 & 255)},${c(n & 255)})`; };
// the rim: a pattern drawn along the frame in two chosen colours; ♪ react makes it flare with the bass
//   glow  one neon tube          flow     the two colours flowing round     rainbow  all hues flowing round
//   dashes marching dashes       dots     marching beads                    double   two lines
//   comets two lights chasing    sparkle  twinkling stars (more on beats)   electric a crackling line
function drawRim(b, now, P) {
  if (!$('rim').checked) return;
  const pat = $('rimpat').value, c1 = $('rimc1').value, c2 = $('rimc2').value, t = now / 1000, bass = frameReact();
  const m = Math.min(b.w, b.h), lw = Math.max(0.8, +$('rimsize').value * m / 900) * (1 + 1.2 * bass), G = 1 + 2 * bass;
  const cx = b.x + b.w / 2, cy = b.y + b.h / 2;
  X.save(); X.lineJoin = 'round'; X.lineCap = 'round';
  const line = (style, w, blur, glowCol, alpha = 1, pts = P) => { X.strokeStyle = style; X.lineWidth = w; X.shadowColor = glowCol; X.shadowBlur = blur; X.globalAlpha = alpha; tracePts(X, pts); X.stroke(); };
  const conic = stops => { if (!X.createConicGradient) return stops[0]; const g = X.createConicGradient(t * 0.8, cx, cy); stops.forEach((c, i) => g.addColorStop(i / (stops.length - 1), c)); return g; };
  if (pat === 'glow') { line(c1, lw * 2, lw * 4 * G, c1, 0.55); line(lighten(c1, 0.55), lw * 0.8, lw * 1.5, c1); }
  else if (pat === 'flow') { const g = conic([c1, c2, c1]); line(g, lw * 2.2, lw * 3.5 * G, c1, 0.55); line(g, lw, lw * 1.2, c2); }
  else if (pat === 'rainbow') { const g = conic(['#ff3b3b', '#ffb13b', '#f4ff3b', '#3bff7a', '#3bd8ff', '#6b5bff', '#ff3bd8', '#ff3b3b']); line(g, lw * 2.2, lw * 3 * G, '#ffffff', 0.5); line(g, lw, lw, '#ffffff'); }
  else if (pat === 'dashes' || pat === 'dots') {
    const dots = pat === 'dots', d = dots ? lw * 2.4 : lw * 4, off = -t * lw * (dots ? 10 : 14);
    X.setLineDash(dots ? [0.01, d * 2 - 0.01] : [d, d]);
    X.lineDashOffset = off; line(c1, dots ? lw * 1.5 : lw, lw * 2.5 * G, c1);
    X.lineDashOffset = off + d; line(c2, dots ? lw * 1.5 : lw, lw * 2.5 * G, c2);
    X.setLineDash([]);
  } else if (pat === 'double') {
    const s = 1 - lw * 3.2 / (m / 2), inner = P.map((v, i) => i % 2 ? cy + (v - cy) * s : cx + (v - cx) * s);
    line(c1, lw, lw * 3 * G, c1); line(c2, lw * 0.7, lw * 2 * G, c2, 1, inner);
  } else if (pat === 'comets') {
    line(c1, lw * 0.6, 0, c1, 0.18);
    const A = along(P), tail = A.L * 0.22, steps = 48;
    [[c1, 0], [c2, 0.5]].forEach(([col, ph]) => {
      const head = (t * 0.18 + ph) * A.L;
      X.strokeStyle = col; X.shadowColor = col; X.shadowBlur = lw * 3 * G;
      for (let i = 0; i < steps; i++) {
        const s0 = head - tail * i / steps, s1 = head - tail * (i + 1) / steps, f = 1 - i / steps, [ax, ay] = A.at(s0), [bx, by] = A.at(s1);
        X.globalAlpha = f * f; X.lineWidth = lw * (0.4 + 1.4 * f); X.beginPath(); X.moveTo(ax, ay); X.lineTo(bx, by); X.stroke();
      }
    });
  } else if (pat === 'sparkle') {
    line(c1, lw * 0.5, lw * 2, c1, 0.25);
    const A = along(P), n = Math.round(36 + 40 * AU.beat * (bass > 0 ? 1 : 0.4));
    for (let k = 0; k < n; k++) {
      const h1 = Math.sin(k * 127.1) * 43758.5453 % 1, h2 = Math.sin(k * 311.7) * 12345.678 % 1, ph = Math.abs(h2) * 6.28;
      const [x, y] = A.at(Math.abs(h1) * A.L + t * 12 * (k % 2 ? 1 : -1)), tw = Math.pow(Math.max(0, Math.sin(t * (1.5 + Math.abs(h1) * 3) + ph)), 6);
      if (tw < 0.03) continue;
      const col = k % 2 ? c1 : c2, r = lw * (1.2 + 2.2 * tw);
      X.globalAlpha = tw; X.fillStyle = X.shadowColor = col; X.shadowBlur = lw * 3;
      X.beginPath(); X.moveTo(x, y - r); X.quadraticCurveTo(x, y, x + r, y); X.quadraticCurveTo(x, y, x, y + r); X.quadraticCurveTo(x, y, x - r, y); X.quadraticCurveTo(x, y, x, y - r); X.fill();
    }
  } else if (pat === 'electric') {
    const seed = Math.floor(t * 18), n = P.length / 2, J = [];
    for (let i = 0; i < n; i++) {
      const j = (i + 1) % n, dx = P[j * 2] - P[i * 2], dy = P[j * 2 + 1] - P[i * 2 + 1], d = Math.hypot(dx, dy) || 1;
      const nz = Math.sin(i * 0.37 + seed * 1.7) * 0.6 + Math.sin(i * 1.93 + seed * 3.1) * 0.4, amp = lw * (1.6 + 2.5 * bass) * nz;
      J.push(P[i * 2] - dy / d * amp, P[i * 2 + 1] + dx / d * amp);
    }
    line(c1, lw * 1.6, lw * 4 * G, c1, 0.6, J); line(c2, lw * 0.7, lw * 2, c2, 0.9, J); line('#ffffff', lw * 0.3, 0, c1, 0.8, J);
  }
  X.restore();
}

// ── camera moves on the painting, in time with the bars (a steady 120 BPM without a song) ──
//   push: eases in over n bars and back out over the next n · pan: glides across, along the picture's long side
//   drift: a slow float with a slight turn · pulse: a small push on every beat, a bigger one on the first of the bar
// It never shows less than the whole frame (always zoomed in at least as far as it moves), so no edge comes into view.
const camBars = () => [1, 2, 4, 8][+$('cambars').value] || 2;
function cameraMove(b) {
  const mode = $('cam').value; if (mode === 'off' || S.mode === 'idle') return null;
  const A = (0.03 + 0.22 * (+$('camamt').value / 100)) * (sectOn() ? 0.5 + S.secE : 1), beat = beatNow(), c = beat / (camBars() * 4);
  const pp = u => { const f = ((u % 2) + 2) % 2; return easeInOut(f < 1 ? f : 2 - f); };      // 0 → 1 → 0 over two moves
  if (mode === 'push') return [1 + A * pp(c), 0, 0, 0];
  if (mode === 'pan') { const s = 1 + A, m = (s - 1) / 2 * (pp(c) * 2 - 1); return b.w >= b.h ? [s, m * b.w, 0, 0] : [s, 0, m * b.h, 0]; }
  if (mode === 'drift') {
    const T = Math.PI * c, rot = A * 0.1 * Math.sin(T * 0.5 + 0.7), ar = Math.max(b.w / b.h, b.h / b.w);
    const s = (1 + A) * (Math.abs(Math.cos(rot)) + Math.abs(Math.sin(rot)) * ar), m = A * 0.45;
    return [s, Math.sin(T) * m * b.w, Math.sin(T * 0.73 + 1.3) * m * b.h, rot];
  }
  const f = beat - Math.floor(beat), one = ((Math.floor(beat) % 4) + 4) % 4 === 0;     // pulse
  return [1 + A * 0.45 * (one ? 1.6 : 1) * Math.exp(-f * 6), 0, 0, 0];
}
// ── the loop back to empty ──
// fade: the painting dissolves into the empty canvas in soft, blotchy patches (a fixed noise, thresholded)
const DIS = { n: null, cv: null, id: null };
function dissolveLayer(dz, col) {
  const N = 96;
  if (!DIS.n) {
    let a = new Float32Array(N * N); const R = seeded(4242);
    for (let i = 0; i < a.length; i++) a[i] = R();
    for (let pass = 0; pass < 3; pass++) {
      const o = new Float32Array(N * N);
      for (let y = 0; y < N; y++) for (let x = 0; x < N; x++) { let t = 0; for (let dy = -2; dy <= 2; dy++) for (let dx = -2; dx <= 2; dx++) t += a[((y + dy + N) % N) * N + (x + dx + N) % N]; o[y * N + x] = t / 25; }
      a = o;
    }
    let lo = 1, hi = 0; for (const v of a) { if (v < lo) lo = v; if (v > hi) hi = v; }
    for (let i = 0; i < a.length; i++) a[i] = (a[i] - lo) / (hi - lo || 1);
    DIS.n = a; DIS.cv = document.createElement('canvas'); DIS.cv.width = DIS.cv.height = N; DIS.id = DIS.cv.getContext('2d').createImageData(N, N);
  }
  const [r, g, bl] = hexRgb(col), d = DIS.id.data;
  for (let i = 0; i < N * N; i++) { d[i * 4] = r; d[i * 4 + 1] = g; d[i * 4 + 2] = bl; d[i * 4 + 3] = 255 * clamp01((dz * 1.3 - DIS.n[i]) / 0.3); }
  DIS.cv.getContext('2d').putImageData(DIS.id, 0, 0);
  return DIS.cv;
}
// subject / background: the painter's mask, shown on the painting for a moment (subject green, background violet)
function showMask() { if (S.mask) S.maskUntil = performance.now() + 2600; }
function maskLayer() {
  if (S.maskCv) return S.maskCv;
  const { w, h, mask } = S.mask, c = document.createElement('canvas'); c.width = w; c.height = h;
  const x = c.getContext('2d'), id = x.createImageData(w, h), d = id.data;
  for (let i = 0; i < w * h; i++) { const t = mask[i] / 255; d[i * 4] = 57 + (179 - 57) * (1 - t); d[i * 4 + 1] = 255 + (107 - 255) * (1 - t); d[i * 4 + 2] = 136 + (255 - 136) * (1 - t); d[i * 4 + 3] = 70 + 60 * (1 - t); }
  x.putImageData(id, 0, 0);
  return (S.maskCv = c);
}
// rewind: the painting goes back through its own build (snapshots taken on the way), easing into the empty canvas
const SNAPS = 32;
function snapMaybe(frac) {
  if (!S.snaps || !S.out || $('loop').value !== 'rewind') return;
  if (S.snaps.length < SNAPS && S.snaps.length <= Math.floor(frac * SNAPS)) reliefFlush(true);
  while (S.snaps.length < SNAPS && S.snaps.length <= Math.floor(frac * SNAPS)) {
    const k = Math.min(1, 800 / Math.max(S.out.width, S.out.height)), c = document.createElement('canvas');
    c.width = Math.round(S.out.width * k); c.height = Math.round(S.out.height * k);
    c.getContext('2d').drawImage(S.out, 0, 0, c.width, c.height); S.snaps.push(c);
  }
}
function drawRewind(b) {
  const F = S.snaps, pos = (1 - easeInOut(S.dz)) * F.length, i = Math.floor(pos), f = pos - i;
  const at = j => j >= F.length ? hiRes(b.k) : F[j];
  X.drawImage(at(i), b.x, b.y, b.w, b.h);
  if (f > 0.001 && i < F.length) { X.globalAlpha = f; X.drawImage(at(i + 1), b.x, b.y, b.w, b.h); X.globalAlpha = 1; }
}
// per frame: the length (a recording stops on time) and the loop: hold the finished painting, then go back to empty —
// over the last 14% of the song's part or of the length, or (free) 1.5 s after the painting is done. The last frame is
// the first frame again. Without a recording the run then starts over, so it keeps looping.
function reelStep() {
  if (S.mode === 'idle' || !S.out) return;
  const song = audioActive() && !(S.video && AU.el === S.video);
  if (S.rec && reelLen() && !song && S.running && elapsed() >= reelLen() && !S.capped) { S.capped = true; recStopSoon(0); }
  if (!loopOn() || !finiteRun()) { S.dz = 0; return; }
  let dz = 0;
  if (song) dz = !S.songOn ? 0 : AU.ended ? 1 : clamp01(((aTime() - AU.in) / Math.max(0.01, AU.out - AU.in) - 0.86) / 0.14);
  else if (reelLen()) dz = clamp01((elapsed() / reelLen() - 0.86) / 0.14);
  else if (S.done) { if (S.doneAt == null) S.doneAt = clock(); dz = clamp01((clock() - S.doneAt - 1500) / 1800); }
  if (dz > 0 && !(S.dz > 0)) flushLandings();
  S.dz = dz;
  if (dz >= 1 && !S.looped) {
    S.looped = true;
    if (S.rec) recStopSoon(0);
    if (!OFF.on) setTimeout(() => { if (S.looped && !OFF.on && S.mode !== 'idle') restart(); }, 60);
  }
}
// the painting plus whatever is still arriving on it; b = where it sits on the stage (callers clip)
function paintContent(b, now, r) {
  X.save();
  const cx = b.x + b.w / 2, cy = b.y + b.h / 2, cam = cameraMove(b);
  if (cam) { X.beginPath(); X.rect(b.x, b.y, b.w, b.h); X.clip(); X.translate(cx + cam[1], cy + cam[2]); X.rotate(cam[3]); X.scale(cam[0], cam[0]); X.translate(-cx, -cy); }
  // beat punch (beat FX only): the painting pops a little towards the viewer on every hit
  const z = 1 + 0.035 * AU.beat * r;
  X.translate(cx, cy); X.scale(z, z); X.translate(-cx, -cy);
  // endless zoom: the camera's scale since the canvas was last re-baked (everything below moves with it)
  const E = S.endless, v = S.mode === 'auto' && E.on ? Math.exp(E.Z - E.Zb) : 1;
  if (v !== 1) {
    X.beginPath(); X.rect(b.x, b.y, b.w, b.h); X.clip();
    if (v < 1) X.drawImage(S.out, b.x, b.y, b.w, b.h);      // zooming out: the old edge fills the ring until it is painted
    X.translate(cx, cy); X.scale(v, v); X.translate(-cx, -cy);
  }
  const loop = S.dz > 0 && finiteRun() ? $('loop').value : null, under = underOn();
  if (under) drawUnder(b);
  if (loop === 'rewind' && S.snaps && S.snaps.length) drawRewind(b);
  else X.drawImage(hiRes(b.k * v * RS), b.x, b.y, b.w, b.h);
  if (loop === 'fade') {
    const m = dissolveLayer(S.dz, S.loopBg || S.bgHex);
    if (!under) X.drawImage(m, b.x, b.y, b.w, b.h);
    else {                // (with the source under it, the painting dissolves back to the source)
      const w = Math.max(1, Math.round(b.w)), h = Math.max(1, Math.round(b.h));
      if (!UNDER.cv) { UNDER.cv = document.createElement('canvas'); UNDER.x = UNDER.cv.getContext('2d'); }
      if (UNDER.cv.width !== w || UNDER.cv.height !== h) { UNDER.cv.width = w; UNDER.cv.height = h; }
      const u = UNDER.x, src = S.list && S.list.length ? itemAt(0) : S.orig;
      u.globalCompositeOperation = 'copy'; u.drawImage(m, 0, 0, w, h); u.globalCompositeOperation = 'source-in'; drawCover(u, src, 0, 0, w, h); u.globalCompositeOperation = 'source-over';
      X.drawImage(UNDER.cv, b.x, b.y, b.w, b.h);
    }
  }
  if (S.mask && S.mode === 'auto' && !OFF.on && performance.now() < (S.maskUntil || 0)) {
    X.save(); X.globalAlpha = Math.min(1, (S.maskUntil - performance.now()) / 400); X.imageSmoothingEnabled = true; X.drawImage(maskLayer(), b.x, b.y, b.w, b.h); X.restore();
  }
  if (!loop && (S.mode === 'auto' || S.mix) && (S.recent.length || S.landing.length)) {
    X.save(); X.beginPath(); X.rect(b.x, b.y, b.w, b.h); X.clip();
    // shapes still arriving: drawn / swept / stretched in (they are committed to the painting once finished)
    const L = SHP.lib(X), tips = [];
    X.save(); X.translate(b.x, b.y); X.scale(b.k, b.k);
    const tg = tipGlowNow(), lit = [];
    for (const it of S.landing) {
      if (now < it.t0) continue;
      const u = clamp01((now - it.t0) / it.dur), n0 = tips.length; drawMotion(it, u, L, tips);
      if (tg > 0.01 && u < 1 && tips.length > n0) lit.push([it, u, tips[tips.length - 1], it.q.t === 'S' ? it.q.args[6] : sizeOf(it.q) * 0.25]);
    }
    // (the biggest few brushes in flight glow — never a field of dots)
    if (lit.length) { lit.sort((a, b) => b[3] - a[3]); for (const [it, u, tp] of lit.slice(0, 6)) glowTip(it, u, tp, tg); }
    if (S.fr) frCircles();
    X.restore(); X.globalAlpha = 1;
    // highlights (optional, in the chosen colour): small glowing points riding the ends of the strokes being drawn...
    const hl = marks(), hc = markCol();
    if (hl && tips.length) {
      glow(hc, 12, () => {
        X.fillStyle = hc;
        X.save(); X.setTransform(1, 0, 0, 1, 0, 0);
        for (const [x, y, u] of tips) { X.globalAlpha = 0.9 * (1 - u * u); X.beginPath(); X.arc(x, y, 3.5, 0, 7); X.fill(); }
        X.restore(); X.globalAlpha = 1;
      });
    }
    // ...and a flash of outline on freshly laid shapes (pop / off motion, or with beat FX in alternating beat colours)
    if (COL.glow) X.shadowBlur = 10;
    const k = S.k * b.k, life = r ? 520 : 380;
    for (const it of S.recent) {
      if (!hl) break;
      if (!r && it.mode !== 'pop' && it.mode !== 'off') continue;
      const age = now - it.t; if (age < 0 || age > life) continue;
      const col = r ? (it.beat % 2 ? COL.accent2 : hc) : hc;
      X.shadowColor = col; outline(it.s, b, k, col, (1 - age / life) * (0.7 + 0.3 * r), 2 + 2 * AU.beat * r);
    }
    X.restore();
  }
  X.restore();
}
const UNDER = { cv: null, x: null };
// tiny syntax highlighter
const JS_RE = /(\/\/.*$)|('(?:[^'\\]|\\.)*'|"(?:[^"\\]|\\.)*"|`(?:[^`\\]|\\.)*`)|(\b\d*\.?\d+(?:e-?\d+)?\b)|(\b(?:const|let|var|for|of|in|if|else|return|new|function|while|true|false|null|await|async)\b)|([A-Za-z_$][\w$]*)(?=\s*\()|([^\s])/g;
// (returns where the drawn text ends: everything — swatches too — stays inside maxW, a long line ends in …)
function drawTokens(text, x, y, maxW) {
  let px = x; JS_RE.lastIndex = 0; let m, last = 0;
  const cw = X.measureText('M').width, end = x + maxW, sw = Math.round(cw * 1.45), sg = Math.round(cw * 0.45);
  while ((m = JS_RE.exec(text))) {
    if (m.index > last) px += (m.index - last) * cw;
    const t = m[0], swatch = m[2] && /^'#[0-9a-f]{6}'$/i.test(t);
    X.fillStyle = m[1] ? COL.com : m[2] ? COL.str : m[3] ? COL.num : m[4] ? COL.kw : m[5] ? COL.fn : /\w/.test(t) ? COL.ident : COL.punct;
    if (px + t.length * cw + (swatch ? sg + sw : 0) > end - cw) { X.fillStyle = COL.dim; X.fillText('…', px, y); return px + cw; }
    X.fillText(t, px, y);
    if (swatch) { const h = Math.round(cw * 1.45); rr(px + t.length * cw + sg * 0.6, y - h * 0.85, h, h, 3, t.slice(1, -1), 'rgba(255,255,255,.35)'); px += sg + sw; }
    px += t.length * cw; last = m.index + t.length;
  }
  return px;
}
// the gutter for the line numbers shown: as wide as the longest of them
const gutterW = (lines, cw) => Math.max(3, ...lines.map(([n]) => String(n).length)) * cw;
// neon EQ in the code panel's tab strip, fed by the live spectrum
function eq(x, y, w, h) {
  if (!musicOn()) return;
  const n = 40, bw = w / n, g = X.createLinearGradient(x, 0, x + w, 0); g.addColorStop(0, COL.accent); g.addColorStop(1, COL.accent2);
  X.fillStyle = g;
  glow(COL.accent, 8, () => {
    for (let i = 0; i < n; i++) {
      const lo = Math.floor(Math.pow(i / n, 2) * 380) + 1, hi = Math.floor(Math.pow((i + 1) / n, 2) * 380) + 2;
      let s = 0; for (let j = lo; j < hi; j++) s += AU.fft[j]; const v = s / (hi - lo) / 255;
      const bh = Math.max(2, v * h);
      X.fillRect(x + i * bw + 1, y + h - bh, bw - 3, bh);
    }
  });
}
// the lines of code to show in `rows` rows: auto = the newest lines (last one highlighted);
// replay = the piece's source around the line that is drawing now (+ the helper it called, in the second colour)
// replay + live: the code panel splits in two, the painter's own strokes as they are made (left) beside the program that
// made the picture being replayed (right)
const splitCode = () => S.mode === 'replay' && !!S.mix && S.src.length > 0;
function codeLines(rows, which) {
  const lines = []; let hiRow = -1, hi2Row = -1;
  if (which === 'live') {
    const n = S.lines.length, start = Math.max(0, n - rows);
    for (let i = start; i < n; i++) lines.push([i + 1, S.lines[i]]);
    if (!n) lines.push([1, "// the painter's own strokes are written here as it paints"]);
    hiRow = lines.length - 1;
  } else if (which !== 'src' && S.mode === 'auto') {
    // (looping back to empty, the program goes back with the painting)
    const head = ['// every shape has a 2-colour gradient: E ellipse · B soft blob · T triangle · R bar · S brush', `bg('${S.bgHex}')`];
    const keep = S.dz > 0 ? Math.round(S.lines.length * (1 - easeInOut(S.dz))) : S.lines.length;
    const all = head.length + keep, start = Math.max(0, all - rows), skip = S.endless.on ? S.count - S.lines.length : 0;
    for (let i = start; i < all; i++) lines.push([i + 1 + (i < head.length ? 0 : skip), i < head.length ? head[i] : S.lines[i - head.length]]);
    hiRow = lines.length - 1;
  } else if ((S.mode === 'replay' || which === 'src') && S.src.length) {
    const cur = S.cur ? S.cur.line.outer : 1, start = Math.max(0, Math.min(S.src.length - rows, cur - 1 - Math.floor(rows / 2)));
    for (let i = start; i < Math.min(S.src.length, start + rows); i++) lines.push([i + 1, S.src[i]]);
    hiRow = S.cur ? cur - 1 - start : -1;
    hi2Row = S.cur && S.cur.line.inner !== S.cur.line.outer ? S.cur.line.inner - 1 - start : -1;
  } else lines.push([1, '// the program that paints the picture is written here, line by line']);
  return { lines, hiRow, hi2Row };
}
// how far along the run is (the chosen part of the song when one is loaded)
const progress = () => AU.el && AU.dur ? clamp01((aTime() - AU.in) / Math.max(0.01, AU.out - AU.in)) : S.total ? Math.min(1, S.count / S.total) * (1 - easeInOut(S.dz || 0)) : 0;
function codePanel(now) {
  const CODE = LY.code;
  rr(CODE.x, CODE.y, CODE.w, CODE.h, 14, COL.panel2, COL.line, 1);
  [COL.accent, COL.accent2, COL.dim].forEach((c, i) => { X.fillStyle = c; X.beginPath(); X.arc(CODE.x + 24 + i * 18, CODE.y + 23, 5, 0, 7); X.fill(); });
  const file = S.mode === 'replay' ? `recreate/pieces/${S.name}.js` : S.mode === 'auto' ? 'painting.js' : 'code';
  X.font = `600 16px ${MONO}`; X.fillStyle = COL.dim; X.fillText(file, CODE.x + 84, CODE.y + 29);
  let right = CODE.x + CODE.w - 20;
  if (S.mode === 'replay' && S.cur) { X.textAlign = 'right'; X.fillStyle = COL.accent2; const t = `op ${S.count}/${S.total} · ${S.cur.kind}`; X.fillText(t, right, CODE.y + 29); right -= X.measureText(t).width + 20; X.textAlign = 'left'; }
  const eqX = CODE.x + 84 + X.measureText(file).width + 30; eq(eqX, CODE.y + 10, Math.max(0, right - eqX), 26);
  X.fillStyle = COL.line; X.fillRect(CODE.x + 1, CODE.y + 44, CODE.w - 2, 1);
  const LH = LY.lh, top = CODE.y + 56, split = splitCode(), rows = Math.floor((CODE.h - 74) / LH) - 1 - (split ? 1 : 0), r = fxAmt();
  X.font = `${LY.font}px ${MONO}`;
  const cw = X.measureText('M').width, base = Math.round(LH * 0.62);
  const column = (bx, bw, which, label) => {
    const { lines, hiRow, hi2Row } = codeLines(rows, which), gw = gutterW(lines, cw), gx = bx + 18, tx = gx + gw + 16, maxW = bx + bw - 16 - tx, T0 = top + (label ? LH : 0);
    if (label) { X.fillStyle = COL.dim; X.font = `600 ${Math.max(12, LY.font - 4)}px ${MONO}`; X.fillText(label, bx + 16, top + base); X.font = `${LY.font}px ${MONO}`; }
    lines.forEach(([n, text], ri) => {
      const y = T0 + ri * LH;
      if (ri === hiRow) { X.fillStyle = COL.hi; X.fillRect(bx + 8, y - 4, bw - 16, LH); glow(COL.accent, 10 + 24 * AU.beat * r, () => { X.fillStyle = COL.accent; X.fillRect(bx + 8, y - 4, 3, LH); }); }
      else if (ri === hi2Row) { X.fillStyle = COL.hi2; X.fillRect(bx + 8, y - 4, bw - 16, LH); X.fillStyle = COL.accent2; X.fillRect(bx + 8, y - 4, 3, LH); }
      X.fillStyle = ri === hiRow ? COL.accent : COL.com; X.textAlign = 'right'; X.fillText(String(n), gx + gw, y + base); X.textAlign = 'left';
      const ex = drawTokens(text.replace(/\t/g, '  '), tx, y + base, maxW - cw * 1.6);      // (room left for the cursor)
      if (ri === hiRow && S.mode === 'auto' && Math.floor(now / 450) % 2 === 0 && !S.done) {
        const kw = Math.round(cw * 0.9); glow(COL.accent, 12, () => { X.fillStyle = COL.accent; X.fillRect(Math.min(ex + cw * 0.35, bx + bw - 14 - kw), y - 1, kw, LH - 4); });
      }
    });
  };
  if (split) {
    const hw = Math.floor(CODE.w / 2);
    column(CODE.x, hw, 'live', 'live · the painter'); column(CODE.x + hw, CODE.w - hw, 'src', 'recreate · ' + S.name + '.js');
    X.fillStyle = COL.line; X.fillRect(CODE.x + hw, CODE.y + 52, 1, CODE.h - 72);
  } else column(CODE.x, CODE.w, undefined, '');
  // the footer stays at the bottom while the code rolls above it
  X.fillStyle = COL.line; X.fillRect(CODE.x + 14, CODE.y + CODE.h - 22 - LH + 6, CODE.w - 28, 1);
  X.font = `${Math.max(11, LY.font - 5)}px ${MONO}`; X.fillStyle = COL.dim; X.textAlign = 'center'; X.fillText(FOOTER, CODE.x + CODE.w / 2, CODE.y + CODE.h - 22 - Math.round(LH * 0.2)); X.textAlign = 'left';
  const p = progress();
  rr(CODE.x + 20, CODE.y + CODE.h - 13, CODE.w - 40, 4, 2, COL.line);
  if (p) {
    const g = X.createLinearGradient(CODE.x + 20, 0, CODE.x + CODE.w - 20, 0); g.addColorStop(0, COL.accent); g.addColorStop(1, COL.accent2);
    glow(COL.accent, 10, () => rr(CODE.x + 20, CODE.y + CODE.h - 13, (CODE.w - 40) * p, 4, 2, g));
  }
}
// ═════════════════════════════════════════════════════════════
//  Simple display (for reels): the painting big, the original and the code underneath,
//  no titles, labels or stats — just a soft halo in the painting's own colours.
// ═════════════════════════════════════════════════════════════
const rgba = (hex, a) => { const n = parseInt(hex.slice(1), 16); return `rgba(${n >> 16 & 255},${n >> 8 & 255},${n & 255},${a})`; };
// Where Instagram's Reels interface sits on a 1080×1920 video (approximate, it varies a little by phone):
// the header ("Reels", camera) above `top`, username / caption / audio below `bottom`, and the like / comment /
// share column right of `right` from `rightTop` down. Everything that matters is kept inside; the ▢ IG guides
// toggle shows these areas over the stage (as a page overlay, so they are never in a recording).
const IG = { top: 210, bottom: 1540, right: 950, rightTop: 1000 };
function simpleGeom() {
  const ar = S.out ? S.out.width / S.out.height : S.orig ? srcW(S.orig) / srcH(S.orig) : 1;
  const oar = S.orig ? srcW(S.orig) / srcH(S.orig) : 1, music = !!AU.rms && audioActive(), nItems = viewerItems().length;
  // tall and square frames stack everything in one column: reels keep inside the band Instagram leaves free, feed
  // posts use the whole frame
  const B = LY.feed ? { top: 40, bottom: SH - 40 } : IG;
  if (SH >= SW && nItems >= 2) {
    // 9:16 with slots: painting, (waveform), the slot pictures in a row, the code underneath — one centred column
    const avail = B.bottom - B.top, g = 16, waveH = music ? 56 : 0, tilesH = 200, codeH = music ? 170 : 200;
    let pw = 1000, ph = pw / ar;
    const phMax = avail - tilesH - codeH - g * 2 - (music ? waveH + g : 0);
    if (ph > phMax) { ph = phMax; pw = ph * ar; }
    const total = ph + g + (music ? waveH + g : 0) + tilesH + g + codeH, x = Math.round((SW - pw) / 2), top = Math.round(B.top + (avail - total) / 2);
    let y = top + ph + g; const wave = music ? { x, y: Math.round(y), w: Math.round(pw), h: waveH } : null; if (music) y += waveH + g;
    const tiles = { x, y: Math.round(y), w: Math.round(pw), h: tilesH }; y += tilesH + g;
    return { paint: { x, y: top, w: Math.round(pw), h: Math.round(ph) }, wave, tiles, orig: null, code: { x, y: Math.round(y), w: Math.round(pw), h: codeH } };
  }
  if (SH >= SW) {
    // 9:16: painting, then the song's waveform (with music), then the original + the code, all inside the safe band
    const avail = B.bottom - B.top, waveH = music ? 56 : 0, g1 = music ? 16 : 26, g2 = music ? 16 : 0, rowMin = 236, rowMax = 320;
    let pw = 1000, ph = pw / ar;
    const phMax = avail - rowMin - waveH - g1 - g2;
    if (ph > phMax) { ph = phMax; pw = ph * ar; }                 // tall pictures get narrower instead of taller
    const rowH = Math.min(rowMax, avail - ph - waveH - g1 - g2), total = ph + g1 + waveH + g2 + rowH;
    const x = Math.round((SW - pw) / 2), top = Math.round(B.top + (avail - total) / 2);
    const wave = music ? { x, y: Math.round(top + ph + g1), w: Math.round(pw), h: waveH } : null, y2 = Math.round(top + ph + g1 + waveH + g2);
    // the original stays on the left, clear of the buttons; the code (texture, fine under them) takes the rest
    const ow = Math.round(Math.min(pw * 0.45, Math.max(pw * 0.26, rowH * oar)));
    return { paint: { x, y: top, w: Math.round(pw), h: Math.round(ph) }, wave, orig: { x, y: y2, w: ow, h: Math.round(rowH) },
      code: { x: x + ow + 20, y: y2, w: Math.round(pw) - ow - 20, h: Math.round(rowH) } };
  }
  // 16:9: the painting on the left; the original, the code and (with music) the waveform stacked on the right
  const ph = 1000, pw = Math.round(Math.min(1180, Math.max(700, ph * ar))), x2 = 40 + pw + 40, w2 = SW - 40 - x2;
  const oh = nItems >= 2 ? Math.round(Math.min(320, (w2 - 14 * (nItems - 1)) / nItems)) : Math.round(Math.min(520, Math.max(300, w2 / oar))), waveH = music ? 56 : 0, wg = music ? 20 : 0;
  return { paint: { x: 40, y: 40, w: pw, h: ph }, orig: nItems >= 2 ? null : { x: x2, y: 40, w: w2, h: oh }, tiles: nItems >= 2 ? { x: x2, y: 40, w: w2, h: oh } : null,
    code: { x: x2, y: 40 + oh + 24, w: w2, h: ph - oh - 24 - waveH - wg }, wave: music ? { x: x2, y: 40 + ph - waveH, w: w2, h: waveH } : null };
}
// the chosen part of the song as a row of bars: played part bright, the rest faint, the bar at the playhead
// breathing with the beat. It doubles as the progress bar.
function waveStrip(W) {
  const n = Math.max(8, Math.floor(W.w / 7)), f0 = AU.in / AU.hop, f1 = AU.out / AU.hop, p = progress(), mid = W.y + W.h / 2, v = new Float32Array(n);
  let top = 1e-6;
  for (let i = 0; i < n; i++) {
    const a = Math.floor(f0 + (f1 - f0) * i / n), e = Math.max(a + 1, Math.floor(f0 + (f1 - f0) * (i + 1) / n));
    for (let f = a; f < e; f++) v[i] = Math.max(v[i], AU.rms[f] || 0);
    top = Math.max(top, v[i]);
  }
  const bw = W.w / n, head = p * n;
  for (let i = 0; i < n; i++) {
    let h = Math.max(3, Math.pow(v[i] / top, 0.8) * W.h);
    const d = Math.abs(i + 0.5 - head);
    if (d < 2 && musicOn()) h = Math.min(W.h, h * (1 + 0.3 * AU.beat * (1 - d / 2)));
    X.fillStyle = i + 0.5 <= head ? 'rgba(255,255,255,.82)' : 'rgba(255,255,255,.16)';
    X.beginPath(); X.roundRect(W.x + i * bw + (bw - 3) / 2, mid - h / 2, 3, h, 1.5); X.fill();
  }
}
// soft halo behind the painting, in its own colours (a tiny blurred copy, faded out towards the edges)
const halo = document.createElement('canvas'); halo.width = halo.height = 64; let haloAt = -1e9;
function haloOf(src, now) {
  if (now - haloAt < 200) return halo;
  haloAt = now; const h = halo.getContext('2d');
  h.globalCompositeOperation = 'source-over'; h.clearRect(0, 0, 64, 64);
  h.filter = 'blur(4px)'; h.drawImage(src, 10, 10, 44, 44); h.filter = 'none';
  const g = h.createRadialGradient(32, 32, 12, 32, 32, 32); g.addColorStop(0, '#000'); g.addColorStop(1, 'rgba(0,0,0,0)');
  h.globalCompositeOperation = 'destination-in'; h.fillStyle = g; h.fillRect(0, 0, 64, 64); h.globalCompositeOperation = 'source-over';
  return halo;
}
function simpleCode(C, o = {}) {
  if (!o.which && splitCode()) {
    const gap = 8, hw = Math.floor((C.w - gap) / 2);
    simpleCode({ ...C, w: hw }, { ...o, which: 'live' }); simpleCode({ ...C, x: C.x + hw + gap, w: C.w - hw - gap }, { ...o, which: 'src' });
    return;
  }
  const fs = o.fs || (SH > SW ? 17 : 18), LH = Math.round(fs * 1.45), pad = o.bg ? 0 : 16, R = 16, bg = o.bg || COL.panel2;
  if (o.bg) { X.fillStyle = bg; X.fillRect(C.x, C.y, C.w, C.h); } else rr(C.x, C.y, C.w, C.h, R, COL.panel2, 'rgba(255,255,255,.06)', 1);
  X.font = `${fs}px ${MONO}`;
  const foot = o.which !== 'src', rows = Math.floor((C.h - pad * 2) / LH) - (foot ? 1 : 0), { lines, hiRow, hi2Row } = codeLines(rows, o.which);
  const cw = X.measureText('M').width, numW = Math.max(gutterW(lines, cw), cw * 4), tx = C.x + pad + numW + 12, maxW = C.x + C.w - pad - tx, base = Math.round(LH * 0.66);
  X.save(); X.beginPath(); X.roundRect(C.x, C.y, C.w, C.h, R); X.clip();
  const y0 = C.y + C.h - pad - (foot ? LH : 0) - lines.length * LH;   // lines sit at the bottom, like a terminal
  lines.forEach(([n, text], ri) => {
    const y = y0 + ri * LH;
    if (ri === hiRow || ri === hi2Row) { X.fillStyle = ri === hiRow ? COL.hi : COL.hi2; X.fillRect(C.x, y - 2, C.w, LH); X.fillStyle = ri === hiRow ? COL.accent : COL.accent2; X.fillRect(C.x, y - 2, 2, LH); }
    X.fillStyle = COL.com; X.textAlign = 'right'; X.fillText(String(n), C.x + pad + numW, y + base); X.textAlign = 'left';
    drawTokens(text.replace(/\t/g, '  '), tx, y + base, maxW);
  });
  if (foot) { X.fillStyle = COL.line; X.fillRect(C.x + pad, C.y + C.h - pad - LH + 1, C.w - pad * 2, 1); X.fillStyle = COL.dim; X.font = `${Math.max(10, fs - 3)}px ${MONO}`; X.textAlign = 'center'; X.fillText(FOOTER, C.x + C.w / 2, C.y + C.h - pad - Math.round(LH * 0.28), C.w - pad * 2 - 8); X.textAlign = 'left'; }
  // older lines fade out at the top as the program grows
  const g = X.createLinearGradient(0, C.y, 0, C.y + LH * 3); g.addColorStop(0, bg); g.addColorStop(1, rgba(bg, 0));
  X.fillStyle = g; X.fillRect(C.x, C.y, C.w, LH * 3);
  X.restore();
}
function simple(now) {
  const G = simpleGeom(), r = fxAmt();
  if (!S.orig) {   // idle hint (never recorded: a run always has an image)
    X.setLineDash([10, 10]); rr(G.paint.x, G.paint.y, G.paint.w, G.paint.h, 20, null, COL.line); X.setLineDash([]);
    X.fillStyle = COL.dim; X.font = `600 30px ${MONO}`; X.textAlign = 'center';
    X.fillText('drop any image', G.paint.x + G.paint.w / 2, G.paint.y + G.paint.h / 2); X.textAlign = 'left';
    return;
  }
  const b = S.out ? fit(S.out, G.paint) : null;
  const framed = $('frame').value !== 'rect';     // (a cut-out painting gets no rectangular halo or edge)
  if (b && !framed) { X.save(); X.globalAlpha = 0.5; X.drawImage(haloOf(S.out, now), b.x - b.w * 10 / 44, b.y - b.h * 10 / 44, b.w * 64 / 44, b.h * 64 / 44); X.restore(); }
  if (G.tiles) drawTiles(viewerItems(), G.tiles, 16, false);
  else {
    const a = fit(S.orig, G.orig);
    X.save(); X.beginPath(); X.roundRect(a.x, a.y, a.w, a.h, 16); X.clip(); X.drawImage(S.orig, a.x, a.y, a.w, a.h); X.restore();
    rr(a.x + 0.5, a.y + 0.5, a.w - 1, a.h - 1, 16, null, 'rgba(255,255,255,.07)', 1);
  }
  simpleCode(G.code);
  if (b) {
    // (a cut-out clips itself, and its rim glows past the picture's rectangle: clipping that too cut the glow into a
    // visible square corner)
    if (framed) paintPanel(b, now, r);
    else { X.save(); X.beginPath(); X.roundRect(b.x, b.y, b.w, b.h, 20); X.clip(); paintPanel(b, now, r); X.restore(); }
    if (!framed) rr(b.x + 0.5, b.y + 0.5, b.w - 1, b.h - 1, 20, null, 'rgba(255,255,255,.08)', 1);
    if (!G.wave && !framed) {   // without music: a hairline of progress under the painting (not under a cut-out)
      const py = Math.min(SH - 14, G.paint.y + G.paint.h + 12);
      X.fillStyle = 'rgba(255,255,255,.08)'; X.fillRect(b.x + 20, py, b.w - 40, 2);
      X.fillStyle = 'rgba(255,255,255,.55)'; X.fillRect(b.x + 20, py, (b.w - 40) * progress(), 2);
    }
  }
  if (G.wave) waveStrip(G.wave);
}
// ═════════════════════════════════════════════════════════════
//  Paint + code display: the painting on top, its code underneath — no original, no labels. In 9:16 it stays inside
//  the band Instagram leaves free (4:5 and 1:1: the whole frame); the song's waveform sits between them with music.
// ═════════════════════════════════════════════════════════════
function duoGeom() {
  const ar = S.out ? S.out.width / S.out.height : S.orig ? srcW(S.orig) / srcH(S.orig) : 1, music = !!AU.rms && audioActive();
  const tall = SH >= SW, B = tall && !LY.feed ? IG : { top: 40, bottom: SH - 40 }, avail = B.bottom - B.top, maxW = SW - 80;
  const g = 22, waveH = music ? 52 : 0, codeH = Math.round(avail * (tall ? 0.24 : 0.27));
  let ph = avail - codeH - g - (music ? waveH + g : 0), pw = ph * ar;
  if (pw > maxW) { pw = maxW; ph = pw / ar; }
  const total = ph + g + (music ? waveH + g : 0) + codeH, top = Math.round(B.top + (avail - total) / 2), x = Math.round((SW - pw) / 2);
  const cw = Math.round(Math.max(pw, Math.min(maxW, tall ? maxW : SW * 0.62))), cx = Math.round((SW - cw) / 2);
  let y = top + ph + g; const wave = music ? { x, y: Math.round(y), w: Math.round(pw), h: waveH } : null; if (music) y += waveH + g;
  return { paint: { x, y: top, w: Math.round(pw), h: Math.round(ph) }, wave, code: { x: cx, y: Math.round(y), w: cw, h: codeH } };
}
function duo(now) {
  const G = duoGeom(), r = fxAmt();
  if (!S.orig) {
    X.setLineDash([10, 10]); rr(G.paint.x, G.paint.y, G.paint.w, G.paint.h, 20, null, COL.line); X.setLineDash([]);
    X.fillStyle = COL.dim; X.font = `600 30px ${MONO}`; X.textAlign = 'center';
    X.fillText('drop any image', G.paint.x + G.paint.w / 2, G.paint.y + G.paint.h / 2); X.textAlign = 'left';
    return;
  }
  const b = S.out ? fit(S.out, G.paint) : null, framed = $('frame').value !== 'rect';
  if (b && !framed) { X.save(); X.globalAlpha = 0.5; X.drawImage(haloOf(S.out, now), b.x - b.w * 10 / 44, b.y - b.h * 10 / 44, b.w * 64 / 44, b.h * 64 / 44); X.restore(); }
  simpleCode(G.code, document.body.classList.contains('phone') ? { fs: 30 } : {});      // (on a phone's small screen: bigger code)
  if (b) {
    if (framed) paintPanel(b, now, r);
    else { X.save(); X.beginPath(); X.roundRect(b.x, b.y, b.w, b.h, 20); X.clip(); paintPanel(b, now, r); X.restore(); rr(b.x + 0.5, b.y + 0.5, b.w - 1, b.h - 1, 20, null, 'rgba(255,255,255,.08)', 1); }
    if (!G.wave && !framed) {
      const py = b.y + b.h + 10;
      X.fillStyle = 'rgba(255,255,255,.08)'; X.fillRect(b.x + 20, py, b.w - 40, 2);
      X.fillStyle = 'rgba(255,255,255,.55)'; X.fillRect(b.x + 20, py, (b.w - 40) * progress(), 2);
    }
  }
  if (G.wave) waveStrip(G.wave);
}
// ═════════════════════════════════════════════════════════════
//  Circles (one line: circles): the picture redrawn as one unbroken line traced by spinning circles — a Fourier
//  series. Its lines are found (the edges, traced into chains), put in an order where each jump to the next is short,
//  joined into one loop and sampled at up to 65,536 evenly spaced points; an FFT turns the loop into as many
//  circles, each turning at its own speed, which added end to end trace it back. The line is drawn as the tip goes
//  (every few points a stroke of its own, so the code, the SVG and the big PNGs have it), with the chain of the
//  biggest circles shown spinning over the painting. ink: navy on paper · colour: the picture's colours on dark.
// ═════════════════════════════════════════════════════════════
function frStart(data, w, h) {
  const colour = S.line.colour;
  S.fr = { ready: false, colour, hide: !!S.line.hide, w, h, data, i: 0, t0: null, gen: S.gen };
  S.bgHex = S.loopBg = colour ? '#0f0f12' : '#efe9dc'; paintBg(S.outX); S.bgSet = true;
  worker.postMessage({ type: 'chains', gen: S.gen, w, h, data: data.slice(), dense: true });
  $('hint').textContent = 'Circles: finding the lines and putting them in order…';
}
function fftInPlace(re, im, inv) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) { let b = n >> 1; for (; j & b; b >>= 1) j ^= b; j ^= b; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; } }
  for (let len = 2; len <= n; len <<= 1) {
    const a = (inv ? 2 : -2) * Math.PI / len, wr = Math.cos(a), wi = Math.sin(a);
    for (let i = 0; i < n; i += len) { let cr = 1, ci = 0; for (let k = 0; k < len / 2; k++) {
      const p = i + k, q = p + len / 2, tr = re[q] * cr - im[q] * ci, ti = re[q] * ci + im[q] * cr;
      re[q] = re[p] - tr; im[q] = im[p] - ti; re[p] += tr; im[p] += ti; const nr = cr * wr - ci * wi; ci = cr * wi + ci * wr; cr = nr;
    } }
  }
}
function frChains(chains) {
  const F = S.fr; if (!F || F.gen !== S.gen) return;
  if (!chains.length) { $('hint').textContent = 'Circles: no lines found in this picture.'; S.workerDone = true; S.fr = null; return; }
  // the order: from the longest line, always on to the nearest end of a line not drawn yet (turned round if need be)
  const L = chains.length, used = new Uint8Array(L), seq = [];
  let cur = chains.reduce((b, c, i) => c.length > chains[b].length ? i : b, 0), flip = false;
  for (let n = 0; n < L; n++) {
    used[cur] = 1; seq.push([cur, flip]);
    const c = chains[cur], ex = flip ? c[0] : c[c.length - 2], ey = flip ? c[1] : c[c.length - 1];
    let best = -1, bd = Infinity, bf = false;
    for (let j = 0; j < L; j++) if (!used[j]) { const d = chains[j]; const d0 = (d[0] - ex) ** 2 + (d[1] - ey) ** 2, d1 = (d[d.length - 2] - ex) ** 2 + (d[d.length - 1] - ey) ** 2; if (d0 < bd) { bd = d0; best = j; bf = false; } if (d1 < bd) { bd = d1; best = j; bf = true; } }
    if (best < 0) break; cur = best; flip = bf;
  }
  // one loop: the lines one after another, joined by the jumps between them (and back to the start)
  const P = []; const J = [];
  for (const [ci, fl] of seq) { const c = chains[ci], m = c.length / 2; for (let k = 0; k < m; k++) { const kk = fl ? m - 1 - k : k; P.push(c[kk * 2], c[kk * 2 + 1]); J.push(k === 0 ? 1 : 0); } }
  P.push(P[0], P[1]); J.push(1);
  // evenly along it: N points (a power of two), about one per pixel of line
  const cum = [0]; for (let i = 2; i < P.length; i += 2) cum.push(cum[cum.length - 1] + Math.hypot(P[i] - P[i - 2], P[i + 1] - P[i - 1]));
  const len = cum[cum.length - 1], N = Math.min(65536, Math.max(1024, 2 ** Math.ceil(Math.log2(len / 0.9))));
  const re = new Float64Array(N), im = new Float64Array(N), jump = new Uint8Array(N); let s = 0;
  for (let k = 0; k < N; k++) {
    const d = k * len / N; while (s < cum.length - 2 && cum[s + 1] < d) s++;
    const f = (d - cum[s]) / Math.max(1e-9, cum[s + 1] - cum[s]); re[k] = P[s * 2] + (P[s * 2 + 2] - P[s * 2]) * f; im[k] = P[s * 2 + 1] + (P[s * 2 + 3] - P[s * 2 + 1]) * f; jump[k] = J[s + 1];
  }
  const x = Float64Array.from(re), y = Float64Array.from(im);
  fftInPlace(re, im, false);
  // the circles: each frequency's amplitude and phase, biggest first (the constant one is where the chain is fixed)
  const cs = []; for (let k = 0; k < N; k++) { const a = Math.hypot(re[k], im[k]) / N; cs.push([k < N / 2 ? k : k - N, re[k] / N, im[k] / N, a]); }
  const c0 = cs.shift(); cs.sort((p, q) => q[3] - p[3]);
  Object.assign(F, { ready: true, N, x, y, jump, c0, cs: cs.slice(0, 300), nAll: N, t0: clock(), i: 0, wpx: Math.max(0.6, Math.max(F.w, F.h) / 900), lens: len });
  S.total = Math.ceil(N / 8); S.workerDone = false;
  $('hint').textContent = `Circles: ${seq.length} lines in one loop, ${N.toLocaleString()} points — drawn by ${N.toLocaleString()} spinning circles ${S.fr.hide ? ' (hidden: only the line shows)' : '(the biggest 300 shown)'}.`;
}
// how far along the loop the tip is: with a song, where the song is; otherwise the speed sets the time
function frTarget() {
  const F = S.fr; if (!F || !F.ready) return 0;
  if (audioActive() && !AU.ended) return Math.min(1, audioProgress(aTime()) / 0.97);
  const secs = Math.max(4, F.N / 2600 / Math.min(speedFactor(), 400) * 3);
  return Math.min(1, (clock() - F.t0) / 1000 / secs);
}
function frStep() {
  const F = S.fr; if (!F || !F.ready || F.done) return;
  const upto = Math.floor(frTarget() * F.N), G = 8, D = F.data, w = F.w, h = F.h;
  while (F.i + G <= upto || (upto >= F.N && F.i < F.N - 1)) {
    const a = F.i, b = Math.min(F.N - 1, F.i + G), m = (a + b) >> 1;
    // the colour: ink, or the picture's own colour where the line is (a little deeper)
    let col = [37, 49, 92];
    if (F.colour) { const px = Math.min(w - 1, Math.max(0, Math.round(F.x[m]))), py = Math.min(h - 1, Math.max(0, Math.round(F.y[m]))), o = (py * w + px) * 4; col = [D[o], D[o + 1], D[o + 2]].map(v => Math.min(255, v * 1.15 + 18)); }
    let isJump = false; for (let k = a + 1; k <= b; k++) if (F.jump[k]) isJump = true;
    const sh = { t: 'S', p: [F.x[a], F.y[a], 2 * F.x[m] - (F.x[a] + F.x[b]) / 2, 2 * F.y[m] - (F.y[a] + F.y[b]) / 2, F.x[b], F.y[b], F.wpx * (isJump ? 0.55 : 1), 0], c0: col, c1: col, a: isJump ? 0.35 : 0.92 };
    reveal({ s: sh, sim: S.sim });
    F.i = b; if (b >= F.N - 1) break;
  }
  F.tip = [F.x[Math.min(F.N - 1, upto)], F.y[Math.min(F.N - 1, upto)]]; F.at = Math.min(F.N - 1, upto);
  if (F.i >= F.N - 1) { F.done = true; S.workerDone = true; S.total = S.count; try { simPrepare(S.orig); S.finalSim = S.sim = simOf(S.out); } catch (e) { S.finalSim = S.sim = 0; } }
}
// the spinning circles over the painting (X already in the painting's coordinates)
function frCircles() {
  const F = S.fr; if (!F || !F.ready || F.done || !F.tip || F.hide) return;
  const k = S.k, t = 2 * Math.PI * F.at / F.N, m = X.getTransform(), px = 1 / Math.hypot(m.a, m.b);
  let cx = F.c0[1], cy = F.c0[2];
  X.save(); X.lineWidth = 1.1 * px; const ink = !F.colour;
  for (let i = 0; i < F.cs.length; i++) {
    const [f, re, im, a] = F.cs[i], c = Math.cos(f * t), sn = Math.sin(f * t), nx = cx + re * c - im * sn, ny = cy + re * sn + im * c;
    if (a * k > 0.8) { X.globalAlpha = Math.max(0.12, 0.5 - i * 0.002); X.strokeStyle = ink ? '#55607f' : '#c9cbd6'; X.beginPath(); X.arc(cx * k, cy * k, a * k, 0, 7); X.stroke(); }
    X.globalAlpha = 0.75; X.strokeStyle = ink ? '#3a4672' : '#f0f0f4'; X.beginPath(); X.moveTo(cx * k, cy * k); X.lineTo(nx * k, ny * k); X.stroke();
    cx = nx; cy = ny;
  }
  X.globalAlpha = 0.6; X.beginPath(); X.moveTo(cx * k, cy * k); X.lineTo(F.tip[0] * k, F.tip[1] * k); X.stroke();       // (the rest, too small to show)
  X.globalAlpha = 1; X.fillStyle = COL.accent; X.beginPath(); X.arc(F.tip[0] * k, F.tip[1] * k, 3.2 * px, 0, 7); X.fill();
  X.restore();
}
// ═════════════════════════════════════════════════════════════
//  Editor display: the painting beside its program in an editor window — painting.js with its three dots, big line
//  numbers, the newest line highlighted with a blinking cursor and a progress bar along the bottom. 16:9 side by side;
//  the tall and square frames put the editor under the painting.
// ═════════════════════════════════════════════════════════════
function editorGeom() {
  // a thin black trim round the painting; in the tall frames the editor under it shares its left and right edges
  const ar = S.out ? S.out.width / S.out.height : S.orig ? srcW(S.orig) / srcH(S.orig) : 1, m = Math.round(Math.min(SW, SH) * 0.025), g = m;
  if (SW > SH * 1.2) {
    const maxW = SW * 0.6; let ph = SH - 2 * m, pw = ph * ar; if (pw > maxW) { pw = maxW; ph = pw / ar; }
    const paint = { x: m, y: Math.round((SH - ph) / 2), w: Math.round(pw), h: Math.round(ph) }, cx = paint.x + paint.w + g;
    return { paint, code: { x: cx, y: paint.y, w: SW - m - cx, h: paint.h } };
  }
  const avail = SH - 2 * m - g, minCode = Math.round(avail * (SH > SW * 1.3 ? 0.2 : 0.26));
  let pw = SW - 2 * m, ph = pw / ar; if (ph > avail - minCode) { ph = avail - minCode; pw = ph * ar; }
  pw = Math.round(pw); ph = Math.round(ph);
  const x = Math.round((SW - pw) / 2), codeH = Math.min(avail - ph, Math.max(minCode, Math.round(avail * 0.45))), y = Math.round((SH - (ph + g + codeH)) / 2);
  return { paint: { x, y, w: pw, h: ph }, code: { x, y: y + ph + g, w: pw, h: codeH } };
}
function editorCode(C, now) {
  const fs = Math.max(16, Math.min(SW > SH ? 26 : 30, Math.round(C.w / 34))), LH = Math.round(fs * 1.45), barH = Math.round(fs * 2), R = Math.round(fs * 0.5), pad = Math.round(fs * 0.9);
  rr(C.x, C.y, C.w, C.h, R, COL.panel2, 'rgba(255,255,255,.07)', 1);
  [COL.accent, COL.accent2, COL.dim].forEach((c, i) => { X.fillStyle = c; X.beginPath(); X.arc(C.x + pad + 4 + i * fs * 0.8, C.y + barH / 2, fs * 0.25, 0, 7); X.fill(); });
  const file = S.mode === 'replay' ? `${S.name}.js` : 'painting.js';
  X.font = `600 ${Math.round(fs * 0.8)}px ${MONO}`; X.fillStyle = COL.dim; X.fillText(file, C.x + pad + 4 + fs * 2.9, C.y + barH / 2 + fs * 0.28);
  X.fillStyle = 'rgba(255,255,255,.07)'; X.fillRect(C.x + 1, C.y + barH, C.w - 2, 1);
  const top = C.y + barH + Math.round(fs * 0.5), bottom = C.y + C.h - Math.round(fs * 1.4), rows = Math.max(1, Math.floor((bottom - top) / LH));
  X.font = `${fs}px ${MONO}`;
  const { lines, hiRow } = codeLines(rows, S.mode === 'replay' && S.mix ? 'live' : undefined), cw = X.measureText('M').width;
  const gw = gutterW(lines, cw), gx = C.x + pad, tx = gx + gw + Math.round(fs * 0.8), base = Math.round(LH * 0.66), y0 = bottom - lines.length * LH;
  X.save(); X.beginPath(); X.rect(C.x, top - 4, C.w, bottom - top + 8); X.clip();
  lines.forEach(([n, text], ri) => {
    const y = y0 + ri * LH;
    if (ri === hiRow) { X.fillStyle = COL.hi; X.fillRect(C.x + 1, y, C.w - 2, LH); }
    X.fillStyle = ri === hiRow ? COL.accent : COL.com; X.textAlign = 'right'; X.fillText(String(n), gx + gw, y + base); X.textAlign = 'left';
    const ex = drawTokens(text.replace(/\t/g, '  '), tx, y + base, C.x + C.w - pad - tx - cw * 1.6);
    if (ri === hiRow && S.mode === 'auto' && !S.done && Math.floor(now / 450) % 2 === 0) { const kw = Math.round(cw * 0.6); X.fillStyle = COL.accent; X.fillRect(Math.min(ex + cw * 0.3, C.x + C.w - pad - kw), y + LH * 0.12, kw, LH * 0.76); }
  });
  // older lines fade out at the top as the program grows
  const g = X.createLinearGradient(0, top - 4, 0, top + LH * 2); g.addColorStop(0, COL.panel2); g.addColorStop(1, rgba(COL.panel2, 0)); X.fillStyle = g; X.fillRect(C.x + 1, top - 4, C.w - 2, LH * 2);
  X.restore();
  // the progress bar
  const p = progress(), py = C.y + C.h - Math.round(fs * 0.8);
  rr(C.x + pad, py, C.w - 2 * pad, 5, 2.5, 'rgba(255,255,255,.08)');
  if (p) { const gr = X.createLinearGradient(C.x + pad, 0, C.x + C.w - pad, 0); gr.addColorStop(0, COL.accent); gr.addColorStop(1, COL.accent2); glow(COL.accent, 10, () => rr(C.x + pad, py, (C.w - 2 * pad) * p, 5, 2.5, gr)); }
}
function editor(now) {
  const G = editorGeom(), r = fxAmt();
  if (!S.orig) {
    X.setLineDash([10, 10]); rr(G.paint.x, G.paint.y, G.paint.w, G.paint.h, 20, null, COL.line); X.setLineDash([]);
    X.fillStyle = COL.dim; X.font = `600 30px ${MONO}`; X.textAlign = 'center'; X.fillText('drop any image', G.paint.x + G.paint.w / 2, G.paint.y + G.paint.h / 2); X.textAlign = 'left';
    editorCode(G.code, now); return;
  }
  const b = S.out ? fit(S.out, G.paint) : null, framed = $('frame').value !== 'rect';
  editorCode(G.code, now);
  if (b) {
    if (framed) paintPanel(b, now, r);
    else { X.save(); X.beginPath(); X.roundRect(b.x, b.y, b.w, b.h, 12); X.clip(); paintPanel(b, now, r); X.restore(); rr(b.x + 0.5, b.y + 0.5, b.w - 1, b.h - 1, 12, null, 'rgba(255,255,255,.08)', 1); }
  }
}
// ▢ IG guides: the Reels interface areas drawn over the stage as a page overlay (never part of the recording)
function updateGuides() {
  const on = $('igguides').checked && LY === LAYOUTS.vertical && DISPLAY !== 'painting', g = $('guides');
  g.hidden = !on; if (!on) return;
  const pct = (v, of) => (v / of * 100).toFixed(3) + '%', [t, b, r] = g.children;
  t.style.height = pct(IG.top, SH);
  b.style.height = pct(SH - IG.bottom, SH);
  Object.assign(r.style, { top: pct(IG.rightTop, SH), height: pct(IG.bottom - IG.rightTop, SH), width: pct(SW - IG.right, SW) });
}
// ═════════════════════════════════════════════════════════════
//  Painting display: nothing but the painting, edge to edge, as big as the window (or ⛶ the screen) allows
// ═════════════════════════════════════════════════════════════
function paintingOnly(now) {
  if (!S.out) {
    X.fillStyle = COL.dim; X.font = `600 ${Math.round(SH / 30)}px ${MONO}`; X.textAlign = 'center';
    X.fillText(S.orig ? '' : 'drop any image', SW / 2, SH / 2); X.textAlign = 'left';
    return;
  }
  // with a rim, leave room for its glow so the edge of the video doesn't cut it off
  const pad = $('rim').checked ? Math.max(0.8, +$('rimsize').value * Math.min(SW, SH) / 900) * 4 : 0;
  paintPanel(fit(S.out, { x: pad, y: pad, w: SW - 2 * pad, h: SH - 2 * pad }), now, fxAmt());
}
// shown bigger than its 1000 px canvas, an auto painting is redrawn from its recorded calls at the display size,
// so it stays sharp (kept in step as shapes are committed; shapes still arriving are drawn live on top)
function hiRes(k) {
  if (S.freeze) return S.freeze;
  if (S.mode !== 'auto' || k <= 1.05 || !S.out || S.endless.on || RLF.on) return S.out;
  const K = Math.round(k * 100) / 100, done = S.drawn.length - pendingN(), und = underOn();
  if (!S.big || !S.bigs) S.bigs = [];          // (S.big = null anywhere drops every kept size)
  let c = S.bigs.find(c => c.K === K);
  if (c && (c.N > done || c.bg !== S.bgHex || c.under !== und)) { S.bigs.splice(S.bigs.indexOf(c), 1); c = null; }
  if (!c) {
    const cv = document.createElement('canvas'); cv.width = Math.round(S.out.width * K); cv.height = Math.round(S.out.height * K);
    const x = cv.getContext('2d'); x.setTransform(K, 0, 0, K, 0, 0); paintBg(x);
    c = { cv, x, K, N: 0, bg: S.bgHex, under: und }; S.bigs.push(c); if (S.bigs.length > 2) S.bigs.shift();
  }
  for (; c.N < done; c.N++) drawQ(c.x, S.drawn[c.N]);
  return (S.big = c.cv);
}
// ═════════════════════════════════════════════════════════════
//  Mouse on the recording: your pointer drawn onto the stage (so it is in the video), with a choice of icon,
//  a glow colour, an optional trail, and a ripple on every click. The system cursor is hidden over the stage.
//  auto = a hand over a 3D object (closing to a grab while you drag it), otherwise an arrow.
// ═════════════════════════════════════════════════════════════
const MOUSE = { x: 0, y: 0, in: false, down: false, seen: 0, trail: [], ripples: [] };
const mouseOn = () => $('mouseon').checked;
function stagePoint(e) { const r = stage.getBoundingClientRect(); return [(e.clientX - r.left) * stage.width / r.width, (e.clientY - r.top) * stage.height / r.height]; }
stage.addEventListener('pointermove', e => { if (!MOUSE.in) MOUSE.trail = []; [MOUSE.x, MOUSE.y] = stagePoint(e); MOUSE.in = true; MOUSE.seen = performance.now(); MOUSE.trail.push([MOUSE.x, MOUSE.y, MOUSE.seen]); if (MOUSE.trail.length > 80) MOUSE.trail.shift(); });
stage.addEventListener('pointerdown', e => { [MOUSE.x, MOUSE.y] = stagePoint(e); MOUSE.in = true; MOUSE.down = true; MOUSE.seen = performance.now(); MOUSE.ripples.push([MOUSE.x, MOUSE.y, MOUSE.seen]); });
addEventListener('pointerup', () => { MOUSE.down = false; });
stage.addEventListener('pointerleave', () => { if (!MOUSE.down) { MOUSE.in = false; MOUSE.seen = performance.now(); } });
function updateMouseCursor() { stage.classList.toggle('nocursor', mouseOn()); }
function drawMouse(now) {
  if (!mouseOn()) return;
  const vis = MOUSE.in ? 1 : clamp01(1 - (now - MOUSE.seen) / 400);
  MOUSE.trail = MOUSE.trail.filter(p => now - p[2] < 380); MOUSE.ripples = MOUSE.ripples.filter(r => now - r[2] < 550);
  if (vis <= 0 && !MOUSE.ripples.length) return;
  const col = $('mousecol').value, s = Math.min(SW, SH) / 34, down = MOUSE.down;
  let icon = $('mouseicon').value; if (icon === 'auto') icon = LIVE.view3d ? 'hand' : 'arrow';
  X.save(); X.lineCap = 'round'; X.lineJoin = 'round';
  // trail: a fading tail behind the pointer
  if ($('mousetrail').checked && MOUSE.trail.length > 1 && vis > 0) {
    X.strokeStyle = col; X.shadowColor = col; X.shadowBlur = s * 0.6;
    for (let i = 1; i < MOUSE.trail.length; i++) {
      const [ax, ay] = MOUSE.trail[i - 1], [bx, by, bt] = MOUSE.trail[i], f = 1 - (now - bt) / 380;
      X.globalAlpha = f * 0.7 * vis; X.lineWidth = s * 0.28 * f; X.beginPath(); X.moveTo(ax, ay); X.lineTo(bx, by); X.stroke();
    }
  }
  // click ripples
  for (const [rx, ry, rt] of MOUSE.ripples) {
    const u = (now - rt) / 550; X.globalAlpha = (1 - u) * 0.9; X.strokeStyle = col; X.shadowColor = col; X.shadowBlur = s * 0.6; X.lineWidth = s * 0.1 * (1 - u) + 1;
    X.beginPath(); X.arc(rx, ry, s * (0.35 + 1.4 * u), 0, 7); X.stroke();
  }
  if (vis > 0) {
    X.globalAlpha = vis; X.translate(MOUSE.x, MOUSE.y); X.shadowColor = col; X.shadowBlur = s * 0.9;
    const outline = w => { X.lineWidth = w; X.strokeStyle = col; X.stroke(); };
    if (icon === 'arrow') {
      const P = [[0, 0], [0, 1.05], [0.27, 0.8], [0.46, 1.2], [0.62, 1.13], [0.44, 0.74], [0.78, 0.74]], k = s * 1.15;
      X.beginPath(); P.forEach(([px, py], i) => X[i ? 'lineTo' : 'moveTo'](px * k, py * k)); X.closePath();
      X.fillStyle = '#ffffff'; X.fill(); outline(s * 0.09);
    } else if (icon === 'hand') {
      const k = s * 1.1, fl = down ? 0.16 : 0.5;       // fingers curl in while you drag
      X.translate(-0.05 * k, 0.05 * k);
      X.beginPath();
      for (let i = 0; i < 4; i++) { const fx = (-0.34 + i * 0.19) * k, len = (fl + (i === 1 || i === 2 ? 0.08 : 0)) * k; X.roundRect(fx, -len, 0.16 * k, len + 0.1 * k, 0.08 * k); }
      X.roundRect(-0.36 * k, 0, 0.74 * k, 0.62 * k, 0.2 * k);
      X.save(); X.translate(-0.26 * k, 0.34 * k); X.rotate(down ? 0.35 : 0.8); X.roundRect(-0.42 * k, -0.08 * k, 0.5 * k, 0.17 * k, 0.085 * k); X.restore();
      outline(s * 0.17); X.shadowBlur = 0; X.fillStyle = '#ffffff'; X.fill();   // outline under the fill: one clean silhouette
    } else if (icon === 'dot') {
      X.fillStyle = col; X.beginPath(); X.arc(0, 0, s * (down ? 0.42 : 0.3), 0, 7); X.fill();
      X.shadowBlur = 0; X.fillStyle = '#ffffff'; X.beginPath(); X.arc(0, 0, s * 0.11, 0, 7); X.fill();
    } else if (icon === 'ring') {
      X.beginPath(); X.arc(0, 0, s * (down ? 0.42 : 0.6), 0, 7); if (down) { X.fillStyle = col; X.globalAlpha = vis * 0.35; X.fill(); X.globalAlpha = vis; } outline(s * 0.12);
    } else if (icon === 'crosshair') {
      const a = s * 0.75, g = s * 0.2; X.beginPath();
      X.moveTo(-a, 0); X.lineTo(-g, 0); X.moveTo(g, 0); X.lineTo(a, 0); X.moveTo(0, -a); X.lineTo(0, -g); X.moveTo(0, g); X.lineTo(0, a);
      outline(s * 0.1); X.beginPath(); X.arc(0, 0, s * (down ? 0.3 : 0.08), 0, 7); X.fillStyle = col; X.fill();
    } else {                                              // touch: a soft circle, like a phone screen recording
      X.beginPath(); X.arc(0, 0, s * (down ? 0.6 : 0.72), 0, 7);
      X.fillStyle = down ? 'rgba(255,255,255,.55)' : 'rgba(255,255,255,.35)'; X.fill(); outline(s * 0.06);
    }
  }
  X.restore();
}

// ═════════════════════════════════════════════════════════════
//  The bridge to Resolume / VJ apps: the small app in send/ (Syphon on a Mac, Spout on Windows), over one local
//  connection. Out: the painting (as the paint display shows it: frame, rim, the source under it) as the source
//  "Code Painter", and (code on) its code as "Code Painter code". In: any Syphon / Spout source — Resolume's output,
//  another app — as a live input. Frames travel as JPEGs, at most two on their way per stream.
// ═════════════════════════════════════════════════════════════
const BRIDGE_URL = 'ws://127.0.0.1:8792';
const BR = { ws: null, retry: null, via: '', name: '', tried: false };
const SEND = { on: false, code: false, ch: [{ cv: null, x: null, busy: 0 }, { cv: null, x: null, busy: 0 }], n: 0, t: 0, fps: 0, last: -1e9 };
const IN = { want: false, id: null, name: '', cv: null, x: null, stream: null, n: 0 };
const bridgeWanted = () => SEND.on || IN.want;
const bridgeSend = m => { if (BR.ws && BR.ws.readyState === 1) BR.ws.send(typeof m === 'object' && !ArrayBuffer.isView(m) && !(m instanceof ArrayBuffer) ? JSON.stringify(m) : m); };
const BRIDGE_HELP = 'start the bridge app first — in the studio\'s folder: send → send-to-resolume (.command on a Mac, .bat on Windows). It connects by itself once it runs.';
function bridgeConnect() {
  clearTimeout(BR.retry); if (!bridgeWanted() || BR.ws) return;
  let ws; try { ws = new WebSocket(BRIDGE_URL); } catch (e) { BR.retry = setTimeout(bridgeConnect, 2000); return; }
  ws.binaryType = 'arraybuffer';
  ws.onopen = () => { BR.ws = ws; for (const c of SEND.ch) c.busy = 0; SEND.n = 0; SEND.t = performance.now(); };
  ws.onmessage = e => {
    if (typeof e.data !== 'string') return inFrame(e.data);
    let m; try { m = JSON.parse(e.data); } catch (err) { return; }
    if (m.hello) {
      BR.via = m.via; BR.name = m.name;
      if (SEND.on) { sendStatus('on'); sendHint(); }
      if (IN.want) bridgeSend(IN.id ? { in: IN.id } : { sources: 1 });
    }
    if (m.ack !== undefined) { const c = SEND.ch[m.ch || 0]; if (c) c.busy = Math.max(0, c.busy - 1); }
    if (m.sources) inSources(m.sources);
    if (m.inerr) $('hint').textContent = `${BR.via} input: ${m.inerr}`;
  };
  ws.onclose = () => {
    const was = BR.ws === ws; if (was) BR.ws = null;
    for (const c of SEND.ch) c.busy = 0;
    if (!was || !bridgeWanted()) return;
    if (SEND.on) sendStatus('wait');
    $('hint').textContent = 'The bridge app stopped: ' + BRIDGE_HELP;
    BR.retry = setTimeout(bridgeConnect, 2000);
  };
  ws.onerror = () => { if (!BR.tried) $('hint').textContent = (SEND.on ? 'Send: ' : 'Syphon / Spout input: ') + BRIDGE_HELP; BR.tried = true; if (BR.ws !== ws) BR.retry = setTimeout(bridgeConnect, 2000); };
}
// (nothing needs the bridge any more: let it go)
function bridgeIdle() { if (bridgeWanted()) return; clearTimeout(BR.retry); BR.tried = false; if (BR.ws) { const ws = BR.ws; BR.ws = null; ws.close(); } }

// ── out: the painting (and its code) ──
function sendDims(ch = 0) {
  const v = $('sendsize').dataset.v, L = 1920;
  if (v === 'v') return [1080, 1920];
  if (v === 'sq') return [1080, 1080];
  if (v === 'hd' || ch === 1) return [1920, 1080];          // (the code: 16:9 unless a shape is chosen)
  const w = S.out ? S.out.width : 16, h = S.out ? S.out.height : 9, k = L / Math.max(w, h);       // the painting's own shape
  return [2 * Math.round(w * k / 2), 2 * Math.round(h * k / 2)];
}
// the send key: green when the bridge has it, blinking while it waits for the bridge; the frame rate in its tooltip
function sendStatus(state) { const k = $('sendon'); k.classList.toggle('on', state === 'on'); k.classList.toggle('arm', state === 'wait'); }
function sendHint() { $('hint').textContent = `Sending the painting to ${BR.via} as "${BR.name}"${SEND.code ? ` and its code as "${BR.name} code"` : ''}: in Resolume it is under Sources → ${BR.via}.`; }
function sendSwitch() {
  SEND.on = !SEND.on;
  if (SEND.on) { if (BR.ws && BR.via) { sendStatus('on'); sendHint(); } else { sendStatus('wait'); BR.tried = false; bridgeConnect(); } }
  else { sendStatus('off'); bridgeIdle(); $('hint').textContent = 'Send off.'; }
}
$('sendon').onclick = sendSwitch;
{
  const SIZES = [['paint', 'paint'], ['hd', '16:9'], ['v', '9:16'], ['sq', '1:1']], k = $('sendsize');
  const set = v => { const i = Math.max(0, SIZES.findIndex(s => s[0] === v)); k.dataset.v = SIZES[i][0]; k.textContent = SIZES[i][1]; };
  set(store('cp-sendsize') || 'paint');
  k.onclick = () => { const i = SIZES.findIndex(s => s[0] === k.dataset.v); set(SIZES[(i + 1) % SIZES.length][0]); store('cp-sendsize', k.dataset.v); const [w, h] = sendDims(); $('hint').textContent = `Send size: ${k.textContent} (${w}×${h}).`; };
  const c = $('sendcode'), setCode = on => { SEND.code = on; c.classList.toggle('on', on); };
  setCode(store('cp-sendcode') === '1');
  c.onclick = () => { setCode(!SEND.code); store('cp-sendcode', SEND.code ? '1' : '0'); $('hint').textContent = SEND.code ? 'Send code: the code goes out too, as its own source ("Code Painter code"), white and coloured text on black — in Resolume, layer it with Add or Screen.' : 'Send code off.'; };
}
// the code alone, full frame, on black (a source to layer over the painting in Resolume with Add / Screen)
function codeFrame(C) { simpleCode({ x: C.x + C.w * 0.03, y: C.y + C.h * 0.04, w: C.w * 0.94, h: C.h * 0.92 }, { fs: Math.round(Math.min(C.w, C.h) / 30), bg: '#000000' }); }
const JENC = { w: null, failed: false };
function jpegWorker() {
  if (JENC.w || JENC.failed) return JENC.w;
  if (typeof OffscreenCanvas === 'undefined' || typeof createImageBitmap === 'undefined') { JENC.failed = true; return null; }
  const src = `const cv = {};
onmessage = async e => {
  const { bm, ch, q } = e.data;
  try {
    const k = bm.width + 'x' + bm.height, c = cv[k] || (cv[k] = new OffscreenCanvas(bm.width, bm.height));
    c.getContext('2d').drawImage(bm, 0, 0); bm.close();
    const b = new Uint8Array(await (await c.convertToBlob({ type: 'image/jpeg', quality: q })).arrayBuffer()), out = new Uint8Array(b.length + 1);
    out[0] = ch; out.set(b, 1); postMessage({ ch, buf: out.buffer }, [out.buffer]);
  } catch (err) { postMessage({ ch, buf: null }); }
};`;
  try { JENC.w = new Worker(URL.createObjectURL(new Blob([src], { type: 'text/javascript' }))); }
  catch (e) { JENC.failed = true; return null; }
  JENC.w.onmessage = e => {
    const { ch, buf } = e.data, c = SEND.ch[ch], ws = BR.ws;
    if (!buf || !ws || ws.readyState !== 1) { if (c) c.busy = Math.max(0, c.busy - 1); return; }
    ws.send(buf);
  };
  return JENC.w;
}
function sendOut(now) {
  const ws = BR.ws; if (!SEND.on || !ws || ws.readyState !== 1 || ws.bufferedAmount > 4e6) return;
  if (now - SEND.last < 30) return;                // (at most ~30 a second: plenty for a painting, half the work of 60)
  SEND.last = now;
  for (let ch = 0; ch < (SEND.code ? 2 : 1); ch++) {
    const c = SEND.ch[ch]; if (c.busy >= 2) continue;
    const [w, h] = sendDims(ch);
    if (!c.cv) { c.cv = document.createElement('canvas'); c.x = c.cv.getContext('2d'); }
    if (c.cv.width !== w || c.cv.height !== h) { c.cv.width = w; c.cv.height = h; }
    const x = c.x; x.setTransform(1, 0, 0, 1, 0, 0); x.globalAlpha = 1;
    X = x;
    try {
      if (ch === 0) { x.clearRect(0, 0, w, h); if (S.out) paintPanel(fit(S.out, { x: 0, y: 0, w, h }), now, fxAmt()); }
      else { x.fillStyle = '#000'; x.fillRect(0, 0, w, h); codeFrame({ x: 0, y: 0, w, h }); }
    } finally { X = STAGE_X; }
    c.busy++;
    // each frame travels as a high-quality JPEG (a few hundred KB instead of ~10 MB of raw pixels), after one byte
    // saying which stream it is. It's made in a worker (a snapshot of the canvas goes there): turning pixels into a
    // JPEG on the page itself held up the painting, and with it everything else
    const done = () => { c.busy = Math.max(0, c.busy - 1); };
    const enc = jpegWorker();
    if (enc) createImageBitmap(c.cv).then(bm => enc.postMessage({ bm, ch, q: 0.85 }, [bm]), done);
    else {
      const post = buf => { if (BR.ws !== ws || ws.readyState !== 1) return done(); const b = new Uint8Array(buf.byteLength + 1); b[0] = ch; b.set(new Uint8Array(buf), 1); ws.send(b); };
      c.cv.toBlob(b => { if (b) b.arrayBuffer().then(post, done); else done(); }, 'image/jpeg', 0.85);
    }
    if (ch === 0) { SEND.n++; const dt = now - SEND.t; if (dt > 1000) { SEND.fps = SEND.n * 1000 / dt; SEND.n = 0; SEND.t = now; $('sendon').title = `Sending to ${BR.via} at ${Math.round(SEND.fps)} fps (click to stop)`; bridgeSend({ studio: { fps: Math.round(SEND.fps), hidden: document.hidden } }); } }
  }
}

// ── in: a Syphon / Spout source as a live input ──
// live input → "Syphon / Spout": the bridge lists what it sees; one source starts straight away, several go into the
// live input menu to pick from
function inSources(list) {
  const sel = $('livein'); let g = $('inlist');
  if (!g) { g = document.createElement('optgroup'); g.id = 'inlist'; sel.insertBefore(g, sel.querySelector('option[value="stop"]')); }
  g.label = `${BR.via} sources`; g.innerHTML = '';
  for (const s of list) g.appendChild(new Option(`↳ ${s.name}`, '__in:' + s.id));
  if (IN.id) return;
  if (!list.length) { $('hint').textContent = `No ${BR.via} sources found. In Resolume switch on its ${BR.via} output (Output menu), or start the app that sends, then pick live input → ${BR.via} again.`; IN.want = false; bridgeIdle(); return; }
  if (list.length === 1) return startLive('__in:' + list[0].id, list[0].name);
  $('hint').textContent = `${list.length} ${BR.via} sources: pick one under live input.`;
}
function inFrame(buf) {
  const id = IN.id; if (!IN.want || !id) return;
  createImageBitmap(new Blob([buf], { type: 'image/jpeg' })).then(bm => {
    bridgeSend({ inack: 1 });
    if (IN.id !== id) { bm.close(); return; }
    if (!IN.cv) { IN.cv = document.createElement('canvas'); IN.x = IN.cv.getContext('2d'); }
    if (IN.cv.width !== bm.width || IN.cv.height !== bm.height) { IN.cv.width = bm.width; IN.cv.height = bm.height; }
    IN.x.drawImage(bm, 0, 0); bm.close();
    if (++IN.n === 1) inStart();
  }, () => bridgeSend({ inack: 1 }));
}
// the first frame is in: the source becomes a live stream (like a camera) and the painter starts on it
async function inStart() {
  IN.stream = IN.cv.captureStream(60); LIVE.stream = IN.stream; LIVE.bridge = true;
  const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.srcObject = IN.stream;
  await v.play().catch(() => {});
  // (a canvas stream only starts with the next picture drawn on it: wait for a real frame, or the painter's first
  // look at the source would be an empty, black one)
  await new Promise(r => { if (v.requestVideoFrameCallback) v.requestVideoFrameCallback(() => r()); setTimeout(r, 3000); });
  if (!IN.want) return;
  await startAuto(v, IN.name, '', { video: v });
  $('hint').textContent = `Painting ${IN.name} live, from ${BR.via}.`;
}
function inStop() {
  if (!IN.want) return;
  IN.want = false; IN.id = null; IN.n = 0; IN.stream = null;
  bridgeSend({ in: null }); bridgeIdle();
}
// one frame of the stage: listen, pace, reel, draw (the screen's animation frames call it, or an offline render does)
function step(now, dt) {
  listen(now, dt); sectionStep(dt); pace(dt); reelStep(); sndFrame(dt);
  applyStageSize(); X.setTransform(RS, 0, 0, RS, 0, 0);
  background();
  if (DISPLAY === 'simple') simple(now); else if (DISPLAY === 'duo') duo(now); else if (DISPLAY === 'editor') editor(now); else if (DISPLAY === 'painting') paintingOnly(now); else { header(); panes(now); codePanel(now); }
  if (!OFF.on) { drawMouse(now); videoTick(); }     // (the pointer lives in real time: not in an offline render)
}
// ═════════════════════════════════════════════════════════════
//  Performance window: the stage alone in a window of its own — drag it to any monitor or projector, resize it, and
//  double-click it (or press F) for full screen. It shows whatever the stage shows: choose paint or +code for a clean
//  picture. While the studio window is hidden behind it, its own frames keep the studio running.
// ═════════════════════════════════════════════════════════════
const PERF = { win: null, cv: null, x: null, tip: null, tipT: 0 };
const perfOpen = () => !!(PERF.win && !PERF.win.closed);
function perfButton() { $('perfwin').classList.toggle('on', perfOpen()); }
function perfToggle() {
  if (perfOpen()) { PERF.win.close(); PERF.win = null; perfButton(); $('hint').textContent = 'Performance window closed.'; return; }
  const w = window.open('', 'cp-performance', 'popup,width=960,height=560');
  if (!w) { $('hint').textContent = 'The browser blocked the performance window: allow pop-ups for this site, then press window again.'; return; }
  const d = w.document;
  d.open(); d.write(`<!doctype html><html><head><meta charset="utf-8"><title>Code Painter · performance</title><style>
    html, body { margin: 0; height: 100%; background: #000; overflow: hidden; }
    canvas { display: block; width: 100vw; height: 100vh; }
    body.idle { cursor: none; }
    #tip { position: fixed; left: 50%; bottom: 28px; transform: translateX(-50%); padding: 9px 16px; border-radius: 9px; background: rgba(18,19,20,.86); color: #e4e4e1; font: 13px/1.4 ui-monospace, Menlo, Consolas, monospace; letter-spacing: .02em; white-space: nowrap; transition: opacity .6s; pointer-events: none; }
    body.idle #tip { opacity: 0; }
  </style></head><body><canvas></canvas><div id="tip">double-click or F: full screen · Esc: leave · drag this window to any screen</div></body></html>`); d.close();
  PERF.win = w; PERF.cv = d.querySelector('canvas'); PERF.x = PERF.cv.getContext('2d'); PERF.tipT = performance.now();
  const full = () => { if (d.fullscreenElement) d.exitFullscreen().catch(() => {}); else d.documentElement.requestFullscreen().catch(() => {}); };
  w.addEventListener('dblclick', full);
  w.addEventListener('keydown', e => { if (e.key === 'f' || e.key === 'F') full(); });
  w.addEventListener('pointermove', () => { PERF.tipT = performance.now(); d.body.classList.remove('idle'); });
  w.addEventListener('pagehide', () => { if (PERF.win === w) { PERF.win = null; perfButton(); schedule(); } });
  d.addEventListener('visibilitychange', schedule);
  perfButton(); schedule();
  $('hint').textContent = 'Performance window open: drag it to any screen, resize it, double-click it (or press F) for full screen. It shows the stage — paint or +code give a clean picture.';
}
$('perfwin').onclick = perfToggle;
addEventListener('pagehide', () => { if (perfOpen()) PERF.win.close(); });
function perfDraw() {
  if (!PERF.win) return;
  if (PERF.win.closed) { PERF.win = null; perfButton(); return; }
  const w = PERF.win, dpr = w.devicePixelRatio || 1, W = Math.max(1, Math.round(w.innerWidth * dpr)), H = Math.max(1, Math.round(w.innerHeight * dpr));
  if (PERF.cv.width !== W || PERF.cv.height !== H) { PERF.cv.width = W; PERF.cv.height = H; }
  const x = PERF.x, f = fit(stage, { x: 0, y: 0, w: W, h: H });
  x.fillStyle = '#000'; x.fillRect(0, 0, W, H); x.imageSmoothingQuality = 'high'; x.drawImage(stage, f.x, f.y, f.w, f.h);
  if (performance.now() - PERF.tipT > 2500) w.document.body.classList.add('idle');
}
// the frame loop runs on the animation frames of whichever window can be seen (a window hidden behind another gets
// none), and takes its time from this page's clock (each window's frame times start at its own opening)
let lastNow = performance.now(), frameTok = 0;
function schedule() {
  const tok = ++frameTok, run = ts => { if (tok === frameTok) frame(performance.now(), ts); };
  (perfOpen() && document.hidden && !PERF.win.document.hidden ? PERF.win : window).requestAnimationFrame(run);
}
document.addEventListener('visibilitychange', () => { schedule(); keepAwake(); });
// a 120 Hz screen (a MacBook Pro's, say) would draw everything twice as often as needed: every other one is skipped,
// which leaves that time to the painting, the recording and the feed to Resolume (the screen's own frame times are
// used, so a 60 Hz screen never skips one)
let lastTs = -1e9;
function frame(now, ts = now) {
  if (ts - lastTs >= 11) { lastTs = ts; frameBody(now); }
  schedule();
}
// a slow computer: when our own work per frame stays over the frame budget, heavy styles' strokes land without their arrival animation
// (the stroke is drawn once instead of every frame while it travels), until it keeps up again
const LAG = { ema: 8, lite: false };
const HEAVY = new Set(['pencil', 'charcoal', 'pastel', 'pen', 'ink', 'wash', 'wet', 'thread', 'hylics', 'lens', 'crystal', 'frost', 'embroid', 'glass', 'scribble', 'halftone', ...Object.keys(RELIEF)]);
function frameBody(now) {
  const t0 = performance.now(), dt = Math.min(100, now - lastNow); lastNow = now;
  reliefFlush();
  if (!OFF.on) { step(now, dt); sendOut(now); }
  drawTimeline(); drawVT(); perfDraw();
  LAG.ema = LAG.ema * 0.9 + (performance.now() - t0) * 0.1;
  if (!LAG.lite && LAG.ema > 26) { LAG.lite = true; if (S.mode === 'auto' && S.running) $('hint').textContent = 'This is a lot to draw: the heavy styles are drawn in with a plain motion to keep up (a lighter style, fewer shapes or the fast detail also help).'; }
  else if (LAG.lite && LAG.ema < 13) LAG.lite = false;
}
// the window hidden (another app in front of it, minimised, on another desktop): the browser stops drawing it, which
// froze a recording (its frames repeat) and the feed to Resolume. While either is running a small worker's clock keeps
// the frames coming instead (a worker's timers aren't held back the way the page's are).
const AWAKE = { w: null, on: false, hiddenMs: 0, since: 0 };
const awakeWanted = () => document.hidden && !(perfOpen() && !PERF.win.document.hidden) && ((S.rec && !S.rec.offline) || SEND.on);
function keepAwake() {
  const want = awakeWanted(); if (want === AWAKE.on) return;
  AWAKE.on = want;
  if (want) AWAKE.since = performance.now(); else AWAKE.hiddenMs += performance.now() - AWAKE.since;
  if (!AWAKE.w) {
    try {
      AWAKE.w = new Worker(URL.createObjectURL(new Blob(['let t = 0; onmessage = e => { clearInterval(t); if (e.data) t = setInterval(() => postMessage(0), e.data); };'], { type: 'text/javascript' })));
      AWAKE.w.onmessage = () => {
        if (!awakeWanted()) return keepAwake();
        frameBody(performance.now());
        if (S.rec && S.rec.mp4 && window.MP4REC) MP4REC.capture();      // (the recorder's own animation frames are stopped too)
      };
    } catch (e) { return; }
  }
  AWAKE.w.postMessage(want ? 1000 / 60 : 0);
}
{ const q = new URLSearchParams(location.search); setLayout(q.get('layout') || store('cp-layout') || 'landscape'); setDisplay(q.get('display') || store('cp-display') || 'simple'); }
schedule();

// ═════════════════════════════════════════════════════════════
//  Song sections: intro / verse / build / drop / break / outro, found on the song's own bar grid.
//  Every bar gets its loudness, bass, brightness and busyness; a section starts where the four bars before and the
//  four after differ most (preferring the phrase grid of 4 and 8 bars that the song itself shows), at least 4 bars
//  apart. Sections are named by their energy within the song: the loudest are drops, the quietest breaks, a rising one
//  before a louder one a build, a quiet start / end the intro / outro.
// ═════════════════════════════════════════════════════════════
function findSections() {
  const hop = AU.hop, N = AU.rms.length, dur = AU.dur, one = [{ t0: 0, t1: dur, kind: 'verse', e: 0.5, slope: 0 }];
  if (dur < 12 || !AU.low) return one;
  const bpm = estimateBpm(0, dur), g = bpm ? beatGrid(0, dur, bpm) : null, bar = g ? 4 * g.p : 2;
  let s0 = g ? g.t0 % bar : 0; if (s0 > 0.05) s0 -= bar;
  const F = [];
  for (let t = s0; t < dur - bar * 0.25; t += bar) {
    const a = Math.max(0, Math.floor(t / hop)), b = Math.min(N, Math.floor((t + bar) / hop)); if (b <= a) continue;
    let r = 0, l = 0, h = 0, o = 0; for (let f = a; f < b; f++) { r += AU.rms[f]; l += AU.low[f]; h += AU.hi[f]; o += AU.on[f]; }
    const k = b - a; F.push({ t: Math.max(0, t), v: [r / k, l / k, h / k, o / k] });
  }
  const B = F.length; if (B < 8) return one;
  for (let j = 0; j < 4; j++) { let lo = 1e9, hi = -1e9; for (const f of F) { lo = Math.min(lo, f.v[j]); hi = Math.max(hi, f.v[j]); } for (const f of F) f.v[j] = (f.v[j] - lo) / (hi - lo || 1); }
  const Wf = [1, 1, 0.7, 0.8], mean = (a, b) => { const m = [0, 0, 0, 0]; let n = 0; for (let k = Math.max(0, a); k < Math.min(B, b); k++, n++) for (let j = 0; j < 4; j++) m[j] += F[k].v[j]; return m.map(v => v / Math.max(1, n)); };
  const D = new Float32Array(B);
  for (let k = 2; k < B - 1; k++) { const x = mean(k - 4, k), y = mean(k, k + 4); let d = 0; for (let j = 0; j < 4; j++) d += Wf[j] * (x[j] - y[j]) ** 2; D[k] = Math.sqrt(d); }
  // the song's phrase grid: which bar of 4 (and of 8) its changes tend to fall on
  const by4 = [0, 0, 0, 0], by8 = new Array(8).fill(0); for (let k = 0; k < B; k++) { by4[k % 4] += D[k]; by8[k % 8] += D[k]; }
  const p4 = by4.indexOf(Math.max(...by4)), p8 = by8[p4] >= by8[p4 + 4] ? p4 : p4 + 4;
  for (let k = 0; k < B; k++) D[k] *= (k % 4 === p4 ? 1.15 : 1) * (k % 8 === p8 ? 1.13 : 1);
  let mu = 0, sd = 0; for (let k = 0; k < B; k++) mu += D[k]; mu /= B; for (let k = 0; k < B; k++) sd += (D[k] - mu) ** 2; sd = Math.sqrt(sd / B);
  const cand = []; for (let k = 3; k < B - 2; k++) if (D[k] >= D[k - 1] && D[k] >= D[k + 1] && D[k] > mu + 0.35 * sd) cand.push(k);
  cand.sort((a, b) => D[b] - D[a]);
  const cuts = []; for (const k of cand) if (k >= 4 && B - k >= 3 && cuts.every(c => Math.abs(c - k) >= 4)) cuts.push(k);
  cuts.sort((a, b) => a - b);
  const edges = [0, ...cuts, B], secs = [];
  for (let i = 0; i + 1 < edges.length; i++) {
    const a = edges[i], b = edges[i + 1], E = []; for (let k = a; k < b; k++) E.push(0.55 * F[k].v[0] + 0.45 * F[k].v[1]);
    const e = E.reduce((x, y) => x + y, 0) / E.length, n = E.length, mx = (n - 1) / 2; let num = 0, den = 0;
    E.forEach((v, j) => { num += (j - mx) * (v - e); den += (j - mx) ** 2; });
    secs.push({ t0: i ? F[a].t : 0, t1: b < B ? F[b].t : dur, e, slope: den ? num / den : 0, bars: n });
  }
  const lo = Math.min(...secs.map(s => s.e)), hi = Math.max(...secs.map(s => s.e));
  for (const s of secs) s.e = (s.e - lo) / (hi - lo || 1);
  secs.forEach((s, i) => {
    s.kind = s.e >= 0.66 ? 'drop' : s.e <= 0.3 ? 'break' : 'verse';
    const next = secs[i + 1];
    if (s.kind !== 'drop' && next && next.e > s.e + 0.2 && s.slope > 0.012) s.kind = 'build';
  });
  if (secs.length > 1 && secs[0].e < 0.5) secs[0].kind = 'intro';
  const last = secs[secs.length - 1]; if (secs.length > 2 && last.e < 0.5) last.kind = 'outro';
  return secs;
}
const secAt = t => { const L = AU.sections; if (!L) return null; for (const s of L) if (t < s.t1) return s; return L[L.length - 1]; };
const sectOn = () => $('sections').checked && !!AU.el && !!AU.sections && S.songOn && S.mode !== 'idle';
// per frame: where the song is, its energy (smoothed), the drop punch and the slow push-in of a build
function sectionStep(dt) {
  S.kick = (S.kick || 0) * Math.exp(-dt / 520);
  if (!sectOn()) { S.sec = null; S.secE = 0.5; S.push = 0; return; }
  const t = aTime(), s = secAt(t);
  if (S.secE == null) S.secE = s.e;
  S.secE += (s.e - S.secE) * (1 - Math.exp(-dt / 450));
  S.push = s.kind === 'build' ? clamp01((t - s.t0) / Math.max(0.5, s.t1 - s.t0)) : Math.max(0, (S.push || 0) - dt / 250);
  if (s !== S.sec) { const prev = S.sec; S.sec = s; if (prev && !aPaused()) onSection(prev, s); }
}
function onSection(prev, s) {
  // a drop: a punch, a flash on the beat, a burst of strokes and a chord
  if (s.kind === 'drop' && s.e > prev.e + 0.12) {
    S.kick = 1; AU.beat = Math.max(AU.beat, 1); sndDrop();
    if (S.mode === 'auto' && S.endless.on) S.debt += Math.round(30 + 0.015 * S.total);
  }
  // a playlist moves on with the song's sections
  if (S.mode === 'auto' && S.endless.on && S.list.length > 1 && !S.endless.travel && (!S.video || S.fromSlots) && ['bars', 'cycle'].includes($('slotmode').value)) advancePlaylist();
}
// the song's key (Krumhansl–Schmuckler: its pitch-class profile against the major / minor key profiles), so the stroke
// sounds can play in it
function fft(re, im) {
  const n = re.length;
  for (let i = 1, j = 0; i < n; i++) { let bit = n >> 1; for (; j & bit; bit >>= 1) j ^= bit; j ^= bit; if (i < j) { [re[i], re[j]] = [re[j], re[i]]; [im[i], im[j]] = [im[j], im[i]]; } }
  for (let size = 2; size <= n; size <<= 1) {
    const h = size >> 1, st = -2 * Math.PI / size;
    for (let k = 0; k < h; k++) {
      const wr = Math.cos(st * k), wi = Math.sin(st * k);
      for (let i = k; i < n; i += size) { const q = i + h, tr = re[q] * wr - im[q] * wi, ti = re[q] * wi + im[q] * wr; re[q] = re[i] - tr; im[q] = im[i] - ti; re[i] += tr; im[i] += ti; }
    }
  }
}
function songKey(buf) {
  const sr = buf.sampleRate, N = 8192, a = buf.getChannelData(0), b = buf.numberOfChannels > 1 ? buf.getChannelData(1) : a;
  const count = Math.min(220, Math.max(1, Math.floor(buf.length / N))), step = Math.max(N, Math.floor((buf.length - N) / count));
  const chroma = new Float64Array(12), re = new Float64Array(N), im = new Float64Array(N);
  const k0 = Math.ceil(55 * N / sr), k1 = Math.floor(1760 * N / sr);
  for (let s = 0; s + N <= buf.length; s += step) {
    for (let i = 0; i < N; i++) { const w = 0.5 - 0.5 * Math.cos(2 * Math.PI * i / N); re[i] = (a[s + i] + b[s + i]) * 0.5 * w; im[i] = 0; }
    fft(re, im);
    for (let k = k0; k <= k1; k++) { const f = k * sr / N, pc = ((Math.round(12 * Math.log2(f / 440)) % 12) + 12 + 9) % 12; chroma[pc] += Math.sqrt(Math.hypot(re[k], im[k])); }
  }
  const MAJ = [6.35, 2.23, 3.48, 2.33, 4.38, 4.09, 2.52, 5.19, 2.39, 3.66, 2.29, 2.88], MIN = [6.33, 2.68, 3.52, 5.38, 2.6, 3.53, 2.54, 4.75, 3.98, 2.69, 3.34, 3.17];
  const corr = (x, y) => { const mx = x.reduce((p, v) => p + v, 0) / 12, my = y.reduce((p, v) => p + v, 0) / 12; let s = 0, sx = 0, sy = 0; for (let i = 0; i < 12; i++) { s += (x[i] - mx) * (y[i] - my); sx += (x[i] - mx) ** 2; sy += (y[i] - my) ** 2; } return s / Math.sqrt(sx * sy || 1); };
  let best = { r: -2, root: 2, minor: true };
  for (let root = 0; root < 12; root++) for (const minor of [false, true]) {
    const prof = (minor ? MIN : MAJ).map((_, i) => (minor ? MIN : MAJ)[(i - root + 12) % 12]), r = corr([...chroma], prof);
    if (r > best.r) best = { r, root, minor };
  }
  return best;
}
const NOTE_NAMES = ['C', 'C♯', 'D', 'E♭', 'E', 'F', 'F♯', 'G', 'A♭', 'A', 'B♭', 'B'];

// ═════════════════════════════════════════════════════════════
//  Stroke sounds. Every stroke plays a note, synthesised (no samples): its style is the instrument — kalimba, marimba,
//  glockenspiel, glass, a plucked string (Karplus–Strong), a soft pad, pencil, paper, spray, a clay
//  "boing", glitch blips, stitch ticks, bubbles — its colour the note of a pentatonic scale, its size the octave (big =
//  low), where it lands the stereo position, its size and opacity how loud. Notes land on a rhythmic grid (8ths of the
//  song's beat, or 16ths at 120 BPM), at most three at once and fourteen ringing; the strokes too many to play become a
//  soft brush-on-canvas hiss. A room reverb, a feedback delay and a compressor glue it together. With a song: in the
//  song's key, on its beat, quieter. Recorded with the video; an offline render plays the very same notes into its
//  sound track.
// ═════════════════════════════════════════════════════════════
const SND = { on: false, g: null, log: null, bedLog: null, lastSlot: null, slotN: 0, voices: [], skip: 0, rate: 0, bedT: 0, walk: 2, tokens: 3, tokT: null };
const DUR = { kalimba: 1.6, marimba: 1, glock: 1.1, bell: 3.2, glass: 1.8, pluck: 2.2, pad: 2.4, bubble: 0.22, pencil: 0.1, scribble: 0.4, paper: 0.3, spray: 0.42, boing: 0.5, glitch: 0.16, stitch: 0.55 };
const INSTR = { painterly: 'kalimba', soft: 'pad', mixed: 'kalimba', geometric: 'marimba', bubbles: 'bubble', flat: 'marimba', points: 'glock', hatch: 'pencil',
  calligraphy: 'pluck', watercolour: 'pad', confetti: 'glock', graffiti: 'spray', clay: 'boing', relief: 'boing', mosaic: 'marimba', glass: 'glass', linocut: 'paper', riso: 'paper', tape: 'paper',
  scribble: 'scribble', halftone: 'glock', string: 'pluck', glitch: 'glitch', bokeh: 'pad', paper: 'paper', stitch: 'stitch',
  pencil: 'pencil', pastel: 'paper', pen: 'pencil', ink: 'pluck', wash: 'pad', wet: 'pad', thread: 'stitch', plast: 'pad', hylics: 'pad', lens: 'glass', crystal: 'glass', frost: 'glass', pewter: 'bell', molten: 'bell', neon: 'glass', embroid: 'stitch', ceramic: 'glock', stone: 'pad', metal: 'bell', foam: 'pad', terrazzo: 'glock', copper: 'bell', gold: 'bell', bronze: 'bell', beads: 'glock', puffy: 'pad', oil: 'pad', acrylic: 'pad', knife: 'pluck', gouache: 'pad', sumi: 'pluck', marker: 'pencil', watercolour: 'pad', charcoal: 'paper' };
const sndGain = () => 1.5 * Math.pow(+$('sndvol').value / 100, 1.5);
const CACHE = new WeakMap();      // per audio context: the reverb's impulse, a noise buffer, the bit-crusher curve
function ctxBits(ctx) {
  let c = CACHE.get(ctx); if (c) return c;
  const sr = ctx.sampleRate, len = Math.floor(sr * 2.4), ir = ctx.createBuffer(2, len, sr);
  for (let ch = 0; ch < 2; ch++) {
    const d = ir.getChannelData(ch), R = seeded(77 + ch); let lp = 0;
    for (let i = 0; i < len; i++) { const t = i / sr, env = Math.exp(-t / 0.5) * (t < 0.01 ? t / 0.01 : 1), damp = 0.18 + 0.75 * Math.exp(-t / 0.35); lp += damp * ((R() * 2 - 1) - lp); d[i] = lp * env; }
    for (const [ms, gn] of [[9, 0.55], [17, 0.4], [26, 0.3], [39, 0.22], [53, 0.15]]) d[Math.floor((ms + ch * 1.7) / 1000 * sr)] += gn * (ch ? -1 : 1);
  }
  const nb = ctx.createBuffer(1, sr * 2, sr), nd = nb.getChannelData(0), R = seeded(991); for (let i = 0; i < nd.length; i++) nd[i] = R() * 2 - 1;
  const crush = new Float32Array(1024); for (let i = 0; i < 1024; i++) { const x = i / 511.5 - 1; crush[i] = Math.round(x * 4) / 4; }
  c = { ir, noise: nb, crush }; CACHE.set(ctx, c); return c;
}
// the chain every note goes through: dry + room + a soft delay → compressor → volume; and the brush hiss underneath
function sndGraph(ctx, dest, vol) {
  const B = ctxBits(ctx), inp = ctx.createGain(), comp = ctx.createDynamicsCompressor(), out = ctx.createGain();
  comp.threshold.value = -18; comp.knee.value = 12; comp.ratio.value = 3.5; comp.attack.value = 0.003; comp.release.value = 0.22; out.gain.value = vol;
  const dry = ctx.createGain(), rev = ctx.createConvolver(), wet = ctx.createGain(); dry.gain.value = 0.85; rev.buffer = B.ir; wet.gain.value = 0.34;
  const dl = ctx.createDelay(1.5), fb = ctx.createGain(), dlf = ctx.createBiquadFilter(), dlw = ctx.createGain();
  dl.delayTime.value = 0.375; fb.gain.value = 0.27; dlf.type = 'lowpass'; dlf.frequency.value = 2400; dlw.gain.value = 0.15;
  inp.connect(dry); dry.connect(comp); inp.connect(rev); rev.connect(wet); wet.connect(comp);
  inp.connect(dl); dl.connect(dlf); dlf.connect(fb); fb.connect(dl); dlf.connect(dlw); dlw.connect(comp);
  comp.connect(out); out.connect(dest);
  const bed = ctx.createBufferSource(), bf = ctx.createBiquadFilter(), bh = ctx.createBiquadFilter(), bedGain = ctx.createGain();
  bed.buffer = B.noise; bed.loop = true; bf.type = 'bandpass'; bf.frequency.value = 2300; bf.Q.value = 0.6; bh.type = 'highpass'; bh.frequency.value = 900; bedGain.gain.value = 0;
  bed.connect(bf); bf.connect(bh); bh.connect(bedGain); bedGain.connect(inp); bed.start();
  return { inp, out, bedGain };
}
// Karplus–Strong plucked string for a note (made once per note and sample rate)
const KS = new Map();
function pluckBuf(ctx, midi) {
  const key = ctx.sampleRate + ':' + midi; if (KS.has(key)) return KS.get(key);
  const sr = ctx.sampleRate, f = 440 * 2 ** ((midi - 69) / 12), len = Math.floor(sr * 2.4), N = Math.max(2, Math.round(sr / f)), R = seeded(midi * 31 + 7);
  const b = new AudioBuffer({ length: len, sampleRate: sr, numberOfChannels: 1 }), d = b.getChannelData(0);
  let lp = 0, m = 0; for (let i = 0; i < N; i++) { lp += 0.55 * ((R() * 2 - 1) - lp); d[i] = lp * 0.9; m += d[i] / N; }
  for (let i = 0; i < N; i++) d[i] -= m;                    // (no DC: the string rings round zero)
  const rho = 0.9968 - Math.min(0.004, f / 400000);
  for (let i = N; i < len; i++) d[i] = rho * 0.5 * (d[i - N] + d[i - N - 1 < 0 ? 0 : i - N - 1]);
  for (let i = len - Math.floor(sr * 0.2); i < len; i++) d[i] *= (len - i) / (sr * 0.2);
  KS.set(key, b); return b;
}
// one note on a context at time `when` (s) into `bus`; returns when it has died away
function sndVoice(ctx, bus, when, n) {
  const B = ctxBits(ctx), f = 440 * 2 ** ((n.midi - 69) / 12), v = n.vel, out = ctx.createGain(), pan = ctx.createStereoPanner();
  pan.pan.value = n.pan; out.connect(pan); pan.connect(bus);
  const env = (p, peak, a, d, t0 = when) => { p.setValueAtTime(0.0001, t0); p.linearRampToValueAtTime(peak, t0 + a); p.exponentialRampToValueAtTime(0.0001, t0 + a + d); };
  const tone = (type, fr, dst, t0, t1) => { const o = ctx.createOscillator(); o.type = type; o.frequency.value = fr; o.connect(dst); o.start(t0); o.stop(t1); return o; };
  const partials = (dst, list) => { for (const [ratio, amp, d, a = 0.003] of list) { const g = ctx.createGain(); g.connect(dst); env(g.gain, v * amp, a, d); tone('sine', f * ratio, g, when, when + a + d + 0.02); } };
  const noise = (dst, t0, dur, type, fr, q, amp, a = 0.004) => {
    const s = ctx.createBufferSource(), fl = ctx.createBiquadFilter(), g = ctx.createGain();
    s.buffer = B.noise; fl.type = type; fl.frequency.value = fr; fl.Q.value = q; s.connect(fl); fl.connect(g); g.connect(dst);
    env(g.gain, amp, a, dur, t0); s.start(t0, Math.random() * 1.5); s.stop(t0 + a + dur + 0.02); return fl;
  };
  const lowpass = fr => { const l = ctx.createBiquadFilter(); l.type = 'lowpass'; l.frequency.value = fr; l.connect(out); return l; };
  const k = n.kind;
  if (k === 'kalimba') { const d = 1.7 - Math.min(0.9, (n.midi - 40) / 55); partials(lowpass(5200), [[1, 0.55, d], [2.01, 0.1, d * 0.45], [5.43, 0.07, 0.08]]); noise(out, when, 0.006, 'bandpass', 3400, 2, v * 0.1, 0.001); return when + d; }
  if (k === 'marimba') { const d = 1.0 - Math.min(0.55, (n.midi - 40) / 70); partials(lowpass(4200), [[1, 0.6, d], [3.93, 0.16, d * 0.2], [9.2, 0.04, 0.035]]); noise(out, when, 0.008, 'lowpass', 1400, 0.7, v * 0.12, 0.001); return when + d; }
  if (k === 'glock') { const d = 1.1; partials(out, [[2, 0.34, d], [2 * 2.76, 0.14, d * 0.5], [2 * 5.4, 0.07, d * 0.25], [2 * 8.93, 0.03, 0.12]]); return when + d; }
  if (k === 'bell' || k === 'glass') {        // FM: a modulator at a non-integer ratio, its depth decaying — metal, or glass
    const ratio = k === 'bell' ? 3.5 : 2.0, d = k === 'bell' ? 3.2 : 1.8, g = ctx.createGain(), m = ctx.createGain(), fc = k === 'glass' ? f * 2 : f;
    g.connect(lowpass(k === 'bell' ? 6500 : 8000)); env(g.gain, v * 0.42, 0.002, d);
    const car = tone('sine', fc, g, when, when + d + 0.05), mod = tone('sine', fc * ratio, m, when, when + d + 0.05); m.connect(car.frequency);
    m.gain.setValueAtTime(fc * (k === 'bell' ? 4.5 : 2.2), when); m.gain.exponentialRampToValueAtTime(fc * 0.08, when + d * 0.7);
    const g2 = ctx.createGain(); g2.connect(out); env(g2.gain, v * 0.12, 0.002, d * 0.8); tone('sine', fc * (k === 'bell' ? 1.0023 : 4.2), g2, when, when + d);
    return when + d;
  }
  if (k === 'pluck') { const s = ctx.createBufferSource(), g = ctx.createGain(); s.buffer = pluckBuf(ctx, n.midi); s.connect(g); g.connect(lowpass(3600 + 3000 * v)); g.gain.value = v * 0.75; s.start(when); return when + 2.2; }
  if (k === 'pad') {
    const g = ctx.createGain(), lp = lowpass(700 + 1100 * v), d = 2.4; g.connect(lp);
    g.gain.setValueAtTime(0.0001, when); g.gain.linearRampToValueAtTime(v * 0.2, when + 0.28); g.gain.setTargetAtTime(0.0001, when + 0.7, 0.55);
    tone('triangle', f, g, when, when + d + 0.1).detune.value = -7; tone('triangle', f, g, when, when + d + 0.1).detune.value = 7; tone('sine', f / 2, g, when, when + d + 0.1);
    return when + d;
  }
  if (k === 'bubble') { const g = ctx.createGain(); g.connect(out); env(g.gain, v * 0.4, 0.004, 0.16); const o = tone('sine', f * 0.6, g, when, when + 0.22); o.frequency.exponentialRampToValueAtTime(f * 1.6, when + 0.08); return when + 0.22; }
  if (k === 'pencil') { noise(out, when, 0.07, 'bandpass', 2800 + 600 * (n.midi % 5), 1.4, v * 0.5); return when + 0.1; }
  if (k === 'scribble') { let t = when; for (let i = 0, m = 3 + (n.midi % 3); i < m; i++) { noise(out, t, 0.035 + 0.02 * ((n.midi + i) % 3), 'bandpass', 2400 + 900 * ((n.midi * 7 + i) % 4), 1.6, v * 0.42); t += 0.045 + 0.02 * ((n.midi + i * 3) % 3); } return t + 0.05; }
  if (k === 'paper') { let t = when; for (let i = 0, m = 4 + (n.midi % 4); i < m; i++) { noise(out, t, 0.014 + 0.012 * ((i * 5 + n.midi) % 3), 'bandpass', 1300 + 700 * ((i + n.midi) % 4), 0.9, v * 0.55, 0.001); t += 0.022 + 0.018 * ((i * 3 + n.midi) % 3); } return t + 0.05; }
  if (k === 'spray') { const fl = noise(out, when, 0.36, 'highpass', 2600, 0.5, v * 0.32, 0.03); fl.frequency.setValueAtTime(2600, when); fl.frequency.exponentialRampToValueAtTime(5200, when + 0.3); return when + 0.42; }
  if (k === 'boing') {
    const g = ctx.createGain(), lp = lowpass(1800); g.connect(lp); env(g.gain, v * 0.5, 0.004, 0.42);
    const o = tone('sine', f * 1.9, g, when, when + 0.5); o.frequency.exponentialRampToValueAtTime(f, when + 0.11);
    const t2 = ctx.createGain(); t2.connect(lp); env(t2.gain, v * 0.35, 0.002, 0.12); tone('sine', f / 2, t2, when, when + 0.16);
    return when + 0.5;
  }
  if (k === 'glitch') {
    const g = ctx.createGain(), sh = ctx.createWaveShaper(); sh.curve = B.crush; g.connect(sh); sh.connect(lowpass(5200)); env(g.gain, v * 0.2, 0.001, 0.13);
    const o = tone('square', f, g, when, when + 0.16); o.frequency.setValueAtTime(f * 1.5, when + 0.035); o.frequency.setValueAtTime(f * 0.75, when + 0.07); o.frequency.setValueAtTime(f * 2, when + 0.105);
    return when + 0.16;
  }
  if (k === 'stitch') {
    noise(out, when, 0.006, 'bandpass', 2600, 3, v * 0.35, 0.001); noise(out, when + 0.075, 0.006, 'bandpass', 2100, 3, v * 0.3, 0.001);
    partials(lowpass(4000), [[1, 0.25, 0.5], [2.01, 0.05, 0.2]]); return when + 0.55;
  }
  partials(out, [[1, 0.5, 1]]); return when + 1;
}
// the key to play in: the song's, or D (major for a light painting, minor for a dark one)
function sndKey() {
  if (AU.el && AU.key) return AU.key;
  const [r, g, b] = hexRgb(S.bgHex || '#000000');
  return { root: 2, minor: (0.3 * r + 0.59 * g + 0.11 * b) / 255 < 0.42 };
}
function sndNote(q) {
  const [c0, , o] = colsOf(q), [r, g, b] = hexRgb(c0), mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 510;
  let h = 0; if (mx !== mn) { const d = mx - mn; h = (mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4) / 6; }
  const key = sndKey(), scale = key.minor ? [0, 3, 5, 7, 10] : [0, 2, 4, 7, 9], size = sizeOf(q);
  const deg = mx - mn < 24 ? Math.min(4, Math.floor(l * 5)) : Math.floor(h * 5) % 5;        // greys walk the scale by lightness
  let oct = size > 280 ? 0 : size > 110 ? 1 : 2;                                              // big = low (from C3)
  if (l > 0.78 && size <= 40) oct++;
  const kind = INSTR[q.st] || 'kalimba';
  if (kind === 'pad') oct = Math.min(oct, 1);
  const c = centreOf(q);
  return { big: size > 150, midi: 48 + key.root + scale[deg] + 12 * oct, vel: Math.min(1, 0.2 + 0.6 * Math.min(1, size / 260)) * (0.55 + 0.45 * Math.min(1, o)), pan: Math.max(-0.75, Math.min(0.75, c[0] / (S.out ? S.out.width : 1000) * 1.5 - 0.75)), kind };
}
// the sound clock (s): the audio context's, or during an offline render the video's
const sndTime = () => OFF.on ? (OFF.t - OFF.t0) / 1000 : AU.ctx ? AU.ctx.currentTime : 0;
function sndPlay(n, delayMs = 0, force = false) {
  if (!SND.on || (!OFF.on && !SND.g)) return;
  const now = sndTime(), song = audioActive() && AU.grid && S.songOn && !aPaused();
  let t = now + delayMs / 1000 + (OFF.on ? 0 : 0.03);
  const step = song ? AU.grid.p / 2 : 0.125, phase = song ? now - aTime() + AU.grid.t0 : 0;
  const slot = Math.ceil((t - phase) / step - 1e-3); t = phase + slot * step;
  // an even flow of notes: about five a second (one and a half a beat with a song), a big stroke may borrow a little;
  // at most two on one step of the grid; the rest become the hiss
  const rate = song ? 1.5 / AU.grid.p : 5;
  SND.tokens = Math.min(3, SND.tokens + (SND.tokT == null ? 3 : Math.max(0, now - SND.tokT) * rate)); SND.tokT = now;
  if (!force) {
    if (SND.tokens < 1 && !(n.big && SND.tokens > 0.4)) { SND.skip++; return; }
    if (slot === SND.lastSlot) { if (++SND.slotN > 1) { SND.skip++; return; } } else { SND.lastSlot = slot; SND.slotN = 0; }
    SND.voices = SND.voices.filter(e => e > now); if (SND.voices.length >= 14) { SND.skip++; return; }
    SND.tokens -= 1;
  }
  n.vel *= (song ? 0.5 : 1) * (sectOn() ? 0.6 + 0.6 * S.secE : 1);
  if (OFF.on) { SND.log.push({ t, n }); SND.voices.push(t + (DUR[n.kind] || 1.5)); return; }
  SND.voices.push(sndVoice(AU.ctx, SND.g.inp, t, n));
}
function sndStroke(q, delayMs) { if (SND.on && S.out) sndPlay(sndNote(q), delayMs); }
// a replay's code steps: a marimba walking the scale
function sndStep() {
  if (!SND.on) return;
  const key = sndKey(), scale = key.minor ? [0, 3, 5, 7, 10] : [0, 2, 4, 7, 9];
  SND.walk = Math.max(0, Math.min(14, SND.walk + [-2, -1, 1, 2, 1][Math.floor(Math.random() * 5)]));
  sndPlay({ midi: 48 + key.root + scale[SND.walk % 5] + 12 * Math.floor(SND.walk / 5), vel: 0.4, pan: Math.random() * 0.8 - 0.4, kind: 'marimba' });
}
// a drop: root, fifth and octave, bell over pad
function sndDrop() {
  if (!SND.on) return;
  const key = sndKey(), r = 36 + key.root;
  for (const [m, kind, vel] of [[r, 'pad', 0.8], [r + 7, 'pad', 0.6], [r + 24, 'bell', 0.55], [r + 31, 'bell', 0.35]]) sndPlay({ midi: m, vel, pan: 0, kind }, 0, true);
}
// per frame: the hiss under the strokes that were too many to play
function sndFrame(dt) {
  if (!SND.on) { SND.skip = 0; return; }
  SND.rate += (SND.skip * 1000 / Math.max(1, dt) - SND.rate) * (1 - Math.exp(-dt / 300)); SND.skip = 0;
  const lv = Math.min(0.03, SND.rate / 2500) * (audioActive() && !aPaused() ? 0.5 : 1), now = sndTime();
  if (OFF.on) { if (now - SND.bedT >= 0.1) { SND.bedT = now; SND.bedLog.push([now, lv]); } }
  else if (SND.g) SND.g.bedGain.gain.setTargetAtTime(lv, AU.ctx.currentTime, 0.15);
}
function sndEnable(on) {
  SND.on = on;
  if (on) {
    audioCtx(); AU.ctx.resume();
    if (!SND.g) { const o = AU.ctx.createGain(); o.connect(AU.ctx.destination); o.connect(AU.mix); SND.g = sndGraph(AU.ctx, o, sndGain()); }
  } else if (SND.g) SND.g.bedGain.gain.setTargetAtTime(0, AU.ctx.currentTime, 0.1);
}
// an offline render's stroke sounds, played into a buffer with the same chain
async function sndOffline(len, rate) {
  const oc = new OfflineAudioContext(2, len, rate), g = sndGraph(oc, oc.destination, sndGain());
  for (const [t, lv] of SND.bedLog) if (t < len / rate) g.bedGain.gain.setTargetAtTime(lv, t, 0.15);
  for (const e of SND.log) if (e.t < len / rate) sndVoice(oc, g.inp, e.t, e.n);
  return oc.startRendering();
}

// ═════════════════════════════════════════════════════════════
//  Offline render (⏺ with "offline" on): the run plays on the video's own clock, one frame at a time. Each frame
//  first waits for what it needs — the painters' strokes, the video's frame, the replay's next step — and is then
//  encoded with its exact time, so the video is perfectly smooth at 30 / 60 fps however long a frame takes to make.
//  The song goes in straight from its file; beats, bands and the EQ are read from it frame by frame.
// ═════════════════════════════════════════════════════════════
let wakers = [];
const nextMsg = () => new Promise(r => wakers.push(r));
function wake() { if (wakers.length) { const w = wakers; wakers = []; for (const f of w) f(); } }
const yieldTask = () => new Promise(r => { const c = new MessageChannel(); c.port1.onmessage = () => r(); c.port2.postMessage(0); });
// wait (in real time) until cond() holds, re-checking on every message from a painter; poke() nudges things along
async function until(cond, ms, poke, fast) {
  const t0 = performance.now();
  while (!cond()) {
    if (performance.now() - t0 > ms) return false;
    if (poke) poke();
    await (fast ? yieldTask() : Promise.race([nextMsg(), sleep(25)]));
  }
  return true;
}
// a pause on the run's clock (the replay waits between its steps like this)
function wait(ms) {
  if (!OFF.on) return sleep(ms);
  return new Promise(r => { OFF.parked++; OFF.timers.push({ t: OFF.t + ms, r: () => { OFF.parked--; r(); } }); });
}
// the replay: let every step that is due by now happen, each one finished before the frame is drawn
async function runReplay() {
  if (S.mode !== 'replay') return;
  for (let n = 0; n < 64; n++) {
    await until(() => OFF.parked > 0 || !S.loops, 15000, null, true);
    const due = OFF.timers.filter(x => x.t <= OFF.t + 1e-6); if (!due.length) return;
    OFF.timers = OFF.timers.filter(x => x.t > OFF.t + 1e-6); for (const x of due) x.r();
  }
  await until(() => OFF.parked > 0 || !S.loops, 15000, null, true);
}
// how many strokes this frame will want (a generous guess: waiting longer only costs render time)
function demand(dt) {
  const E = S.endless, f = speedFactor(), hq = OFF.on && hqOn() ? 3 : 1;      // (hq offline: three times the strokes in every frame of a video / zoom)
  if (E.on) return Math.min(400 * hq, Math.ceil(((f === Infinity ? 120 : S.acc + dt / 1000 * f * 1.5 * Math.min(150, 12 + 0.06 * S.total)) + S.debt) * hq) + 1);
  const rest = S.total - S.count; if (rest <= 0 || S.waitAudio) return 0;
  const m0 = (S.video && AU.el === S.video) ? 'none' : musicMode(), mode = m0 === 'hits' && !S.plan ? 'flow' : m0;
  let n;
  if (fitOn()) n = S.total * fitCurve((elapsed() + dt / 1000) / fitBuild()) - S.count;
  else if (S.pen && (mode === 'hits' || mode === 'flow') && !AU.ended && penWant() != null) n = penWant() - S.count + 24;     // (one line: what the pen will draw, a little ahead)
  else if (mode === 'hits' && S.plan && !AU.ended) { n = S.debt; for (let i = S.plan.i; i < S.plan.t.length && S.plan.t[i] <= OFF.aT; i++) n += S.plan.n[i]; }
  else if (mode === 'flow' && !AU.ended) n = S.total * audioProgress(OFF.aT) - S.count;
  else n = f === Infinity || AU.ended ? 60 : S.acc + dt / 1000 * f * (mode === 'free' ? 2.7 : 1) * (12 + 0.06 * S.count);
  return Math.min(rest, Math.ceil(n) + 1);
}
// while a song plays into the paint, the painter is kept only a few strokes ahead of the stage (it is far quicker
// than the painting is shown): what it paints next is chosen now, at this loudness, not seconds ago
function musicHold(need) {
  const on = S.mode === 'auto' && S.running && !S.waitAudio && !S.endless.on && !S.workerDone && musicAmt() > 0 && audioActive() && !AU.ended;
  if (!(need >= 0)) need = 0;
  // (enough for what the song asks for in the next second and a half: a hit's flurry is never kept waiting)
  let ahead = 0; const t = OFF.on ? OFF.aT : aTime(), m0 = musicMode();
  if (on && m0 === 'hits' && S.plan) { for (let i = S.plan.i; i < S.plan.t.length && S.plan.t[i] <= t + 1.5; i++) ahead += S.plan.n[i]; }
  else if (on && m0 === 'flow') ahead = S.total * (audioProgress(Math.min(AU.out, t + 1.5)) - audioProgress(t));
  // (and enough that the busiest stretch still to come can be met at the painter's own measured pace: the song's
  // plan is known in advance, so a big drop is prepared for during the quiet part before it)
  const now = performance.now(), W = S.wr || (S.wr = { t: now, made: 0, run: 0, r: 40 });
  if (!S.held) W.run += Math.min(200, now - W.t); W.t = now;      // (its pace is measured only while it is free to paint)
  if (W.run > 700) { W.r = W.r * 0.6 + 0.4 * W.made / (W.run / 1000); W.made = 0; W.run = 0; }
  let req = 0;
  if (on && !OFF.on) {
    const r = Math.max(5, W.r * 0.6);
    if (m0 === 'hits' && S.plan) { let cum = 0; for (let i = S.plan.i; i < S.plan.t.length && S.plan.t[i] <= t + 40; i++) { cum += S.plan.n[i]; req = Math.max(req, cum - r * (S.plan.t[i] - t)); } }
    else if (m0 === 'flow') for (let u = 0.5; u <= 40 && t + u <= AU.out + 0.5; u += 0.5) req = Math.max(req, S.total * (audioProgress(Math.min(AU.out, t + u)) - audioProgress(t)) - r * u);
  }
  const cap = Math.max(24, need + 8 + Math.ceil(ahead || 0), Math.ceil(req));
  const hurry = on && S.debt > 12 ? 2.2 : 1;      // (behind the song: the painter looks a little less hard for each stroke)
  if (hurry !== (S.hurry || 1)) { S.hurry = hurry; worker.postMessage({ type: 'hurry', k: hurry }); }
  // (the painter is given a budget: how many strokes it may have made by now; it waits for more by itself)
  const lim = on ? (S.wCount || 0) + Math.max(0, cap - S.queue.length) : null;
  if (lim !== S.until && (lim == null || S.until == null || Math.abs(lim - S.until) >= 3 || lim > S.until && S.queue.length < need + 2)) { S.until = lim; worker.postMessage({ type: 'until', n: lim }); }
  S.held = lim != null && (S.wCount || 0) >= lim;
}
async function feedPainter(dt) {
  if (S.fr) { if (!S.fr.ready) await until(() => !S.fr || S.fr.ready, 20000); return; }      // (circles: their own pace, see frStep)
  if (S.mode === 'auto' && S.running && S.out && !(S.dz > 0)) {
    if (S.accWant) await until(() => !S.accWant, 1500);           // (a render: the beat's stroke is in before the frame)
    const need = demand(dt);
    musicHold(need);
    if (need <= 0) return;
    await until(() => S.mode !== 'auto' || S.queue.length >= need || (!S.endless.on && S.workerDone), 8000, S.endless.on ? () => sendFrame() : null);
  } else if (S.mode === 'replay' && S.mix && S.running && S.mix.debt >= 1) {
    await until(() => !S.mix || S.queue.length >= Math.min(48, Math.ceil(S.mix.debt)), 4000, () => { if (S.mix && !S.mix.busy) sendMixFrame(); });
  }
}
// a video (not a live input) is moved on to this frame's moment; one that plays once ends the render with it
async function syncVideo() {
  const v = S.video;
  if (!v || v.srcObject || S.mode !== 'auto' || !S.endless.on) return;
  let t;
  if (AU.el === v) { if (!OFF.aPlaying) return; t = OFF.aT; }
  else {
    const rate = v.playbackRate || 1, [a, b] = vRange(v), len = Math.max(0.05, b - a);
    if (OFF.vCur !== v) { OFF.vCur = v; OFF.vStart = OFF.t - Math.max(0, v.currentTime - a) / rate * 1000; }
    let u = (OFF.t - OFF.vStart) / 1000 * rate;
    if (u >= len - 0.03 && (S.vOnce || OFF.vOnce)) { if (!OFF.vOnce) { OFF.vOnce = true; recStopSoon(600); } u = len - 0.03; }
    else u %= len;
    t = a + u;
  }
  if (Math.abs(v.currentTime - t) > 0.4 / OFF.fps) await seekTo(v, t);
}
// the run's stored times, moved by d ms (after a render the clock is real time again)
function rebase(d) {
  S.t0 += d; if (S.waitSince) S.waitSince += d; if (S.doneAt != null) S.doneAt += d;
  for (const L of S.landing || []) L.t0 += d;
  for (const q of S.recent || []) q.t += d;
  if (S.cur) S.cur.t += d;
}
async function renderOffline() {
  if (S.mode === 'idle' || OFF.on) return false;
  if (LIVE.stream || LIVE.view3d || AU.live || (S.video && S.video.srcObject)) {
    $('hint').textContent = 'Offline render works with pictures, videos, playlists and replays. Live inputs (camera, screen, microphone, 3D) record in real time: switch offline off.'; return false;
  }
  if (!window.MP4REC || typeof VideoEncoder === 'undefined') { $('hint').textContent = "This browser can't render offline (no video encoder). Switch offline off to record in real time."; return false; }
  const bt = '';
  const fps = +$('recfps').value || 30, dt = 1000 / fps, wall = performance.now();
  recKey(true, 'stop'); S.lastRec = null; $('savevid').disabled = true;
  document.body.classList.add('rendering');
  let R = null, pcm = null, vpcm = null, failed = null, blob = null; const vtimes = [];
  try {
    // the song, decoded again from its file: the sound track, and the beats / bands frame by frame
    if (AU.el && AU.file) {
      $('hint').textContent = 'Offline render: reading the song…';
      applyReelLen();
      const buf = await AU.ctx.decodeAudioData(await AU.file.arrayBuffer()), r = buf.sampleRate;
      const a = Math.max(0, Math.floor(AU.in * r) - 4096), b = Math.min(buf.length, Math.ceil(AU.out * r) + 4096);
      const L = buf.getChannelData(0).slice(a, b), Rr = (buf.numberOfChannels > 1 ? buf.getChannelData(1) : buf.getChannelData(0)).slice(a, b);
      pcm = { L, R: Rr, rate: r, t0: a / r };
    }
    RS = +$('rsize').value / Math.min(LY.W, LY.H); if (DISPLAY === 'painting') { const [w0, h0] = stageSize(); RS = +$('rsize').value / Math.min(w0, h0); }
    applyStageSize(true);
    // the video's own sound, kept: decoded, and laid under each frame at the moment of the video that frame shows
    if (!pcm && S.vsound === 'keep' && S.vfile) {
      try { audioCtx(); const buf = await AU.ctx.decodeAudioData(await S.vfile.arrayBuffer()); vpcm = { L: buf.getChannelData(0), R: buf.numberOfChannels > 1 ? buf.getChannelData(1) : buf.getChannelData(0), rate: buf.sampleRate }; } catch (e) { vpcm = null; }
    }
    R = await MP4REC.startOffline(stage, { fps, bitrate: Math.round(16e6 * Math.max(0.5, RS * RS)), audioRate: pcm ? pcm.rate : vpcm ? vpcm.rate : SND.on ? audioCtx().sampleRate : 0 });
  } catch (e) { document.body.classList.remove('rendering'); recIdle(); $('hint').textContent = `Offline render couldn't start: ${e.message}`; return false; }
  Object.assign(OFF, { on: true, t: performance.now(), frame: 0, fps, aT: 0, aPlaying: false, aStarted: false, aStart: 0, aEnd: -1, timers: [], parked: 0, endAt: Infinity, vCur: null, vOnce: false, pcm });
  if (FFT.mag) FFT.mag.fill(0);
  SND.log = []; SND.bedLog = []; SND.voices = []; SND.bedT = -1; SND.rate = 0; SND.tokens = 3; SND.tokT = null;
  S.rec = { offline: true };
  let frames = 0;
  try {
    $('hint').textContent = 'Offline render: starting…';
    await restart();
    if (S.mode === 'auto') await until(() => S.bgSet && painterReady(), 15000);
    // runs with no end of their own (zoom, video, playlist, ∞) and no song or length: 30 s
    const song = !!(pcm && AU.el), silentVideo = S.mode === 'auto' && S.video && !AU.el && !S.fromSlots;
    OFF.t0 = OFF.t;
    OFF.endAt = OFF.t0 + (reelLen() ? reelLen() * 1000 : S.mode === 'auto' && liveRun() && !song && !silentVideo ? 30000 : 20 * 60000);
    for (let i = 0; ; i++) {
      OFF.frame = i; OFF.t = OFF.t0 + i * dt;
      if (i && OFF.t >= OFF.endAt - 1e-6) break;          // (the length is up: this frame would be one too many)
      if (OFF.aPlaying) OFF.aT = AU.in + (i - OFF.aStart) / fps;
      await syncVideo();
      if (vpcm) vtimes[i] = S.video && S.endless.on ? S.video.currentTime : null;
      await runReplay();
      await feedPainter(dt);
      for (let g = 0; S.cut && g < 400; g++) { cutStep(); if (S.cut) await until(() => !S.cut || S.queue.length > 0, 4000, () => sendFrame()); }
      reliefFlush(true);                                   // (the lit relief, brought up to this very frame)
      step(OFF.t, dt);
      if (S.looped && OFF.endAt <= OFF.t + 1e-6) break;    // (a loop is back at empty: that is frame 0 again, so it isn't repeated)
      await R.add(i); frames = i + 1;
      if (R.failed) throw new Error(R.failed);
      if (OFF.t >= OFF.endAt - 1e-6) break;
      if (i % 10 === 0) {         // where it is, and (once it has a pace) about how long is left
        const v = frames / fps, el = (performance.now() - wall) / 1000, fpsR = frames / Math.max(0.001, el), cap = OFF.t0 + 20 * 60000 - 1;
        let left = null;
        if (OFF.endAt < cap) left = Math.max(0, (OFF.endAt - OFF.t) / dt) / Math.max(0.01, fpsR);
        else if (S.vOnce && S.video && isFinite(S.video.duration) && frames > 15) { const [, b] = vRange(S.video), rest = Math.max(0, b - S.video.currentTime) / (S.video.playbackRate || 1); left = rest * fps / Math.max(0.01, fpsR); }     // (a silent video: it ends with its part)
        else if (S.mode === 'auto' && !S.endless.on && S.count > 20) { const pr = S.count / Math.max(1, S.total); left = el * (1 - pr) / Math.max(0.02, pr) + (+$('hold').value || 0) / Math.max(0.05, fpsR / fps); }
        const mmss = t => { t = Math.round(t); return t >= 3600 ? `${Math.floor(t / 3600)}:${String(Math.floor(t / 60) % 60).padStart(2, '0')}:${String(t % 60).padStart(2, '0')}` : `${Math.floor(t / 60)}:${String(t % 60).padStart(2, '0')}`; };
        $('hint').textContent = `${bt}Rendering ${stage.width}×${stage.height}… ${v.toFixed(1)} s of video (${fpsR / fps >= 0.1 ? (fpsR / fps).toFixed(2) : (fpsR / fps).toPrecision(1)}× real time)${left != null && frames > 15 ? ` · about ${mmss(left)} left` : ''}. ⏹ ends it here.`;
      }
    }
    // the sound: the song (silent until it came in, for as long as it played) and the stroke sounds, mixed
    const rate = pcm ? pcm.rate : vpcm ? vpcm.rate : AU.ctx ? AU.ctx.sampleRate : 48000, songIn = pcm && OFF.aStarted, notes = SND.on && SND.log.length, vIn = vpcm && vtimes.some(t => t != null);
    if (songIn || notes || vIn) {
      const len = Math.ceil(frames / fps * rate), L = new Float32Array(len), Rr = new Float32Array(len);
      if (songIn) {
        const lead = Math.round(OFF.aStart / fps * rate), endF = OFF.aEnd >= 0 ? OFF.aEnd : frames, a = Math.round((AU.in - pcm.t0) * rate);
        const n = Math.max(0, Math.min(pcm.L.length - a, Math.round((endF - OFF.aStart) / fps * rate), len - lead));
        L.set(pcm.L.subarray(a, a + n), lead); Rr.set(pcm.R.subarray(a, a + n), lead);
      }
      if (vIn) {                   // the video's sound, frame by frame from the moment each frame shows
        const fl = rate / fps;
        for (let i = 0; i < frames; i++) { const t = vtimes[i]; if (t == null) continue; const a = Math.round(t * rate), o = Math.round(i * fl), n = Math.min(Math.round(fl) + 1, vpcm.L.length - a, len - o); if (n > 0 && a >= 0) { L.set(vpcm.L.subarray(a, a + n), o); Rr.set(vpcm.R.subarray(a, a + n), o); } }
      }
      if (notes) {
        $('hint').textContent = `${bt}Playing the stroke sounds into the sound track…`;
        const b = await sndOffline(len, rate), l = b.getChannelData(0), r = b.getChannelData(1);
        for (let i = 0; i < len; i++) { L[i] += l[i]; Rr[i] += r[i]; }
        for (const ch of [L, Rr]) for (let i = 0; i < len; i++) { const v = ch[i]; if (v > 0.95 || v < -0.95) ch[i] = Math.sign(v) * (0.95 + 0.05 * Math.tanh((Math.abs(v) - 0.95) / 0.05)); }
      }
      R.audio(L, Rr);
    }
    blob = await MP4REC.stop(p => { $('hint').textContent = `Finishing the video… ${Math.round(p * 100)}%`; });
  } catch (e) { failed = e; if (R) MP4REC.cancel(); }
  // back to real time: the run stays where the render left it, paused (▶ carries on from there)
  const vt = OFF.t0 + Math.max(0, frames - 1) * dt, song = OFF.aPlaying, at = OFF.aT;     // (the last frame that was made)
  RS = 1; applyStageSize(true);
  OFF.on = false; OFF.pcm = null; const T = OFF.timers; OFF.timers = []; OFF.parked = 0; for (const x of T) x.r();
  S.rec = null; document.body.classList.remove('rendering'); recIdle();
  rebase(performance.now() - vt);
  if (S.running) { S.running = false; S.pausedAt = performance.now(); if (S.mode === 'auto') { worker.postMessage({ type: 'pause' }); helpersPost({ type: 'pause' }); } }
  if (AU.el && song) AU.resumeAt = at;
  setButtons();
  if (failed) { $('hint').textContent = 'Offline render failed: ' + failed.message; return false; }
  const name = recName('mp4'), st = MP4REC.stats;
  S.lastRec = { blob, name }; $('savevid').disabled = false; download(blob, name);
  $('hint').textContent = `${bt}Rendered ${name}: ${(frames / fps).toFixed(1)} s, ${fps} fps, every frame exact (${(blob.size / 1e6).toFixed(1)} MB, H.264${st && st.audio ? ' + AAC' : ', no sound'}; took ${((performance.now() - wall) / 1000).toFixed(0)} s). No download? Click ⬇ video.`;
  return true;
}

// ═════════════════════════════════════════════════════════════
//  Presets A–D: every setting on the console (not the pictures, the song or the playlist), kept in this browser
// ═════════════════════════════════════════════════════════════
const PRESET_SKIP = new Set(['example', 'livein', 'replay', 'igguides', 'sendon']);
const presetEls = () => [...document.querySelectorAll('#app input[id], #app select[id]')].filter(el => !PRESET_SKIP.has(el.id) && el.type !== 'file' && el.type !== 'text');
const fire = (el, type) => el.dispatchEvent(new Event(type, { bubbles: true }));
function presetGet() {
  const v = {}; for (const el of presetEls()) v[el.id] = el.type === 'checkbox' ? el.checked : el.value;
  return { v, styles: stylePick.values(), bgStyles: stylePick.bg(), motions: motionPick.values(), display: DISPLAY };
}
function presetApply(p) {
  for (const el of presetEls()) {
    if (!(el.id in p.v)) continue;
    const val = p.v[el.id];
    if (el.type === 'checkbox') { if (el.checked !== !!val) { el.checked = !!val; fire(el, 'change'); } continue; }
    if (el.value === String(val)) continue;
    if (el.tagName === 'SELECT' && ![...el.options].some(o => o.value === String(val))) continue;
    if (el.id === 'brush' && val === 'custom' && !BRUSH.custom) continue;
    el.value = val; fire(el, 'input'); fire(el, 'change');
  }
  if (p.styles) stylePick.set(p.styles, p.bgStyles || []);
  if (p.motions) motionPick.set(p.motions);
  if (p.display) setDisplay(p.display);
}
const PRESETS = (() => { try { return JSON.parse(store('cp-presets') || '{}') || {}; } catch (e) { return {}; } })();
const PR = { arm: false, on: null };
function renderPresets() {
  for (const b of document.querySelectorAll('#presets [data-p]')) { b.classList.toggle('full', !!PRESETS[b.dataset.p]); b.classList.toggle('on', PR.on === b.dataset.p); }
  $('pstore').classList.toggle('arm', PR.arm);
}
function presetKey(k) {
  if (PR.arm) { PRESETS[k] = presetGet(); store('cp-presets', JSON.stringify(PRESETS)); PR.arm = false; PR.on = k; $('hint').textContent = `Preset ${k} stored.`; }
  else if (PRESETS[k]) { presetApply(PRESETS[k]); PR.on = k; $('hint').textContent = `Preset ${k}.`; }
  else $('hint').textContent = `Preset ${k} is empty: press store, then ${k}, to keep the current settings there.`;
  renderPresets();
}

// ═════════════════════════════════════════════════════════════
//  Palette lock: the painter paints only in the palette's colours (it picks the best pair of them for every stroke,
//  and blends between them along its gradient). "grab" takes the six main colours of the current picture.
// ═════════════════════════════════════════════════════════════
const PAL_IDS = ['pal0', 'pal1', 'pal2', 'pal3', 'pal4', 'pal5'];
const palette = () => $('pallock').checked ? PAL_IDS.map(id => hexRgb($(id).value)) : null;
const nearest = (c, pal) => pal.reduce((b, p) => { const d = (p[0] - c[0]) ** 2 + (p[1] - c[1]) ** 2 + (p[2] - c[2]) ** 2; return d < b[0] ? [d, p] : b; }, [Infinity, pal[0]])[1];
function meanOf(d) { let r = 0, g = 0, b = 0; const n = d.length / 4; for (let i = 0; i < d.length; i += 4) { r += d[i]; g += d[i + 1]; b += d[i + 2]; } return [r / n, g / n, b / n]; }
function sendPalette() {
  const p = palette(); worker.postMessage({ type: 'palette', pal: p }); helpersPost({ type: 'palette', pal: p });
  store('cp-palette', PAL_IDS.map(id => $(id).value).join(',') + '|' + ($('pallock').checked ? 1 : 0));
}
function grabPalette() {
  if (!S.orig) { $('hint').textContent = 'Open a picture first: grab takes its main colours.'; return; }
  setSwatches(paletteOf(S.orig));
  sendPalette();
  $('hint').textContent = `Palette taken from ${S.name}.${$('pallock').checked ? ' New strokes use it (⟲ restart to paint the whole picture with it).' : ' Switch lock on to paint with it.'}`;
}
// the six main colours of a picture or video frame (k-means), dark to light
function paletteOf(el) {
  const c = document.createElement('canvas'); c.width = c.height = 64;
  const x = c.getContext('2d', { willReadFrequently: true }); drawCover(x, el, 0, 0, 64, 64);
  const d = x.getImageData(0, 0, 64, 64).data, px = [];
  for (let i = 0; i < d.length; i += 4) px.push([d[i], d[i + 1], d[i + 2]]);
  const d2 = (a, b) => (a[0] - b[0]) ** 2 + (a[1] - b[1]) ** 2 + (a[2] - b[2]) ** 2;
  // k-means (k = 6), seeded with far-apart colours
  const C = [px.reduce((a, p) => p[0] + p[1] + p[2] < a[0] + a[1] + a[2] ? p : a).slice()];
  while (C.length < 6) { let best = -1, bi = 0; for (let i = 0; i < px.length; i += 2) { const m = Math.min(...C.map(c2 => d2(px[i], c2))); if (m > best) { best = m; bi = i; } } C.push(px[bi].slice()); }
  for (let it = 0; it < 14; it++) {
    const sum = C.map(() => [0, 0, 0, 0]);
    for (const p of px) { let k = 0, m = Infinity; C.forEach((c2, j) => { const v = d2(p, c2); if (v < m) { m = v; k = j; } }); const s2 = sum[k]; s2[0] += p[0]; s2[1] += p[1]; s2[2] += p[2]; s2[3]++; }
    sum.forEach((s2, j) => { if (s2[3]) C[j] = [s2[0] / s2[3], s2[1] / s2[3], s2[2] / s2[3]]; });
  }
  C.sort((a, b) => (0.3 * a[0] + 0.59 * a[1] + 0.11 * a[2]) - (0.3 * b[0] + 0.59 * b[1] + 0.11 * b[2]));
  return C;
}
const setSwatches = cols => PAL_IDS.forEach((id, i) => { if (cols[i]) $(id).value = typeof cols[i] === 'string' ? cols[i] : SHP.hex(cols[i]); });

// ═════════════════════════════════════════════════════════════
//  Colour for the output, and a reference picture.
//  Palettes: ready-made sets, or a tint (six steps of any colour). The reference picture gives the palette its six
//  main colours and, as "mood", pushes the picture's light, contrast and colour cast towards its own (colour
//  statistics matched in Lab space, the way Reinhard's colour transfer does), as strongly as the slider says.
// ═════════════════════════════════════════════════════════════
const PALETTES = {
  mono: ['#0b0b0c', '#2b2c31', '#55565c', '#8e9198', '#c9cbd0', '#f2f2ef'], sepia: ['#1b120b', '#3c2a1c', '#6b4a31', '#9b7550', '#cfae82', '#f1e3c8'],
  blueprint: ['#06142e', '#0b2a5c', '#1357a6', '#3b8be0', '#9cc8f5', '#f4f9ff'], sunset: ['#1d0b3a', '#4b1a6b', '#a02a7a', '#e8506a', '#ff9a56', '#ffe3a0'],
  riso: ['#0d0d0d', '#2d3a8c', '#00a6d6', '#ff48b0', '#ffd23f', '#f5f0e1'], pastel: ['#3a3550', '#f7a8b8', '#fbd3a2', '#b8e0c8', '#a9cdf2', '#fff8f0'],
  neon: ['#0b0b0c', '#39ff88', '#b36bff', '#00e5ff', '#ff3df2', '#f2f2ef'], forest: ['#0c1a12', '#1f4d33', '#3d7a4a', '#8aae5c', '#d6d08a', '#f3efd5'],
  ocean: ['#031a2b', '#0a4a6e', '#0e7c9a', '#46b6c4', '#a9e3dc', '#f2fbf6'], fire: ['#120505', '#5c0f0a', '#b8260f', '#f26a1b', '#ffb534', '#fff1b8']
};
function tintRamp(hex) {
  const [r, g, b] = hexRgb(hex).map(v => v / 255), mx = Math.max(r, g, b), mn = Math.min(r, g, b), d = mx - mn;
  let h = 0; if (d) h = mx === r ? ((g - b) / d + 6) % 6 : mx === g ? (b - r) / d + 2 : (r - g) / d + 4;
  const l0 = (mx + mn) / 2, sat = Math.max(0.35, d ? d / (1 - Math.abs(2 * l0 - 1)) : 0), hue = h * 60;
  const hsl = (L, Sa) => { const c = (1 - Math.abs(2 * L - 1)) * Sa, x = c * (1 - Math.abs((hue / 60) % 2 - 1)), m = L - c / 2, k = Math.floor(hue / 60) % 6, t = [[c, x, 0], [x, c, 0], [0, c, x], [0, x, c], [x, 0, c], [c, 0, x]][k]; return SHP.hex(t.map(v => (v + m) * 255)); };
  return [0.07, 0.2, 0.36, 0.54, 0.74, 0.93].map((L, i) => hsl(L, Math.min(1, sat * (i === 5 ? 0.5 : i === 0 ? 0.7 : 1))));
}
// (colour changes repaint the picture from the start, once the last change has settled)
let rerunT = 0;
function rerunSoon() { clearTimeout(rerunT); rerunT = setTimeout(() => { if (S.mode === 'auto' && S.startArgs && !OFF.on) restart(); }, 250); }
function usePalette(cols, what) {
  setSwatches(cols); $('pallock').checked = true; sendPalette();
  $('hint').textContent = `Palette: ${what}. Repainting with it.`; rerunSoon();
}
function originalColours() {
  $('pallock').checked = false; sendPalette(); $('palpreset').value = '';
  $('hint').textContent = 'Back to the picture\'s own colours. Repainting.'; rerunSoon();
}
$('palpreset').onchange = () => { const k = $('palpreset').value; if (k === '__off') originalColours(); else if (PALETTES[k]) usePalette(PALETTES[k], k); };
$('tintgo').onclick = () => { $('palpreset').value = ''; usePalette(tintRamp($('tintcol').value), 'a tint of ' + $('tintcol').value); };
// Lab (D65) for the colour transfer
const lin = v => (v /= 255) <= 0.04045 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4);
const unlin = v => 255 * (v <= 0.0031308 ? 12.92 * v : 1.055 * Math.pow(v, 1 / 2.4) - 0.055);
function toLab(r, g, b, o) {
  r = lin(r); g = lin(g); b = lin(b);
  const f = t => t > 0.008856 ? Math.cbrt(t) : 7.787 * t + 16 / 116, X = f((0.4124 * r + 0.3576 * g + 0.1805 * b) / 0.95047), Y = f(0.2126 * r + 0.7152 * g + 0.0722 * b), Z = f((0.0193 * r + 0.1192 * g + 0.9505 * b) / 1.08883);
  o[0] = 116 * Y - 16; o[1] = 500 * (X - Y); o[2] = 200 * (Y - Z);
}
function fromLab(L, a, b, o) {
  const fy = (L + 16) / 116, fx = fy + a / 500, fz = fy - b / 200, g = t => t * t * t > 0.008856 ? t * t * t : (t - 16 / 116) / 7.787;
  const X = g(fx) * 0.95047, Y = g(fy), Z = g(fz);
  o[0] = unlin(3.2406 * X - 1.5372 * Y - 0.4986 * Z); o[1] = unlin(-0.9689 * X + 1.8758 * Y + 0.0415 * Z); o[2] = unlin(0.0557 * X - 0.2040 * Y + 1.0570 * Z);
}
function labStats(d, step = 1) {
  const m = [0, 0, 0], q = [0, 0, 0], t = [0, 0, 0]; let n = 0;
  for (let i = 0; i < d.length; i += 4 * step) { toLab(d[i], d[i + 1], d[i + 2], t); for (let c = 0; c < 3; c++) { m[c] += t[c]; q[c] += t[c] * t[c]; } n++; }
  return { m: m.map(v => v / n), s: q.map((v, c) => Math.sqrt(Math.max(1e-6, v / n - (m[c] / n) ** 2))) };
}
const REF = { img: null, name: '', stat: null };
const moodOn = () => !!REF.stat && $('refuse').value !== 'palette' && +$('refmix').value > 0;
function moodShift(data) {
  const A = labStats(data, 3), B = REF.stat, k = +$('refmix').value / 100, out = new Uint8ClampedArray(data.length), t = [0, 0, 0], u = [0, 0, 0];
  const sc = [0, 1, 2].map(c => Math.min(2.5, Math.max(0.4, B.s[c] / A.s[c])));
  for (let i = 0; i < data.length; i += 4) {
    toLab(data[i], data[i + 1], data[i + 2], t);
    for (let c = 0; c < 3; c++) t[c] = t[c] + k * ((t[c] - A.m[c]) * sc[c] + B.m[c] - t[c]);
    fromLab(t[0], t[1], t[2], u);
    out[i] = u[0]; out[i + 1] = u[1]; out[i + 2] = u[2]; out[i + 3] = data[i + 3];
  }
  return out;
}
function refThumb() {
  const c = $('refthumb'), x = c.getContext('2d'); x.clearRect(0, 0, c.width, c.height);
  if (REF.img) drawCover(x, REF.img, 0, 0, c.width, c.height);
}
async function setReference(file) {
  try {
    const url = URL.createObjectURL(file), img = await loadImg(url);
    const c = document.createElement('canvas'); c.width = c.height = 96; const x = c.getContext('2d', { willReadFrequently: true }); drawCover(x, img, 0, 0, 96, 96);
    REF.img = img; REF.name = file.name.replace(/\.[^.]+$/, ''); REF.stat = labStats(x.getImageData(0, 0, 96, 96).data);
    refThumb(); refApply();
  } catch (e) { $('hint').textContent = `Couldn't open ${file.name} as a reference (${e.message}).`; }
}
function refApply() {
  if (!REF.img) return;
  const u = $('refuse').value;
  REF.palette = u !== 'mood';
  if (u !== 'mood') { setSwatches(paletteOf(REF.img)); $('pallock').checked = true; sendPalette(); }
  $('palpreset').value = '';
  $('hint').textContent = `Reference: ${REF.name}${u === 'mood' ? ' (mood only)' : u === 'palette' ? ' (its colours)' : ' (its colours and mood)'}. Repainting.`;
  rerunSoon();
}
function refClear() {
  if (!REF.img) return; REF.img = null; REF.stat = null; refThumb();
  if (REF.palette) { REF.palette = false; $('pallock').checked = false; sendPalette(); }       // its colours go with it
  $('hint').textContent = 'Reference removed.'; rerunSoon();
}
$('reffile').onchange = e => { const f = e.target.files[0]; e.target.value = ''; if (f) setReference(f); };
$('refuse').onchange = () => { if (REF.img) refApply(); };
$('refmix').onchange = () => { if (REF.img && moodOn()) { $('hint').textContent = 'Mood strength changed. Repainting.'; rerunSoon(); } };
$('refx').onclick = refClear;
{ const row = $('refrow');
  row.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); row.classList.add('drop'); });
  row.addEventListener('dragleave', () => row.classList.remove('drop'));
  row.addEventListener('drop', e => { e.preventDefault(); e.stopPropagation(); row.classList.remove('drop'); document.body.classList.remove('drag'); const f = [...e.dataTransfer.files].find(isImage); if (f) setReference(f); }); }

// ═════════════════════════════════════════════════════════════
//  Path: the painting order (sweeping across the picture instead of biggest-mistake-first) and one line
//  (the whole picture as one unbroken line). Both are made by the painter's worker; see painter-worker.
// ═════════════════════════════════════════════════════════════
function lineSpec() { const v = $('line').value; return v === 'pen' ? { kind: 'pen' } : ['circles', 'circlesc', 'tracei', 'tracec'].includes(v) ? { kind: 'circles', colour: v === 'circlesc' || v === 'tracec', hide: v[0] === 't' } : null; }      // (trace: the same one-loop drawing, without the circles)
$('order').onchange = () => { $('hint').textContent = $('order').value === 'free' ? 'Order: free.' : 'Order: ' + $('order').selectedOptions[0].textContent + '. Repainting.'; rerunSoon(); };
const outlineMode = () => $('outline').value;
const pieceOn = () => $('sprayorder').value === 'lines' && stylePick.values().includes('graffiti');
const rfillMode = () => $('rfill').value;
$('rfill').onchange = () => { store('cp-rfill', rfillMode()); worker.postMessage({ type: 'rfill', on: rfillMode() }); helpersPost({ type: 'rfill', on: rfillMode() }); $('hint').textContent = { off: 'Shapes by hand off.', outline: 'Shapes by hand: big patches of one colour get their outline drawn, then a scribble fills them in.', rows: 'Shapes by hand: big patches get their outline, then are filled line by line.', scribble: 'Shapes by hand: big patches are scribbled in, back and forth.' }[rfillMode()]; };
{ const v = store('cp-rfill'); if (['off', 'outline', 'rows', 'scribble'].includes(v)) $('rfill').value = v; }
$('outline').onchange = () => {
  store('cp-outline', outlineMode());
  $('hint').textContent = outlineMode() === 'off' ? 'Outlines off.' : outlineMode() === 'first' ? 'Outlines: the picture\'s lines are drawn first, then the colour fills between them. Repainting.' : 'Outlines: the colour first, then the picture\'s lines as a final pass. Repainting.';
  if (S.mode === 'auto' && S.endless.on) { worker.postMessage({ type: 'outline', on: outlineMode() }); helpersPost({ type: 'outline', on: outlineMode() }); } else rerunSoon();
};
$('fillmode').onchange = () => { store('cp-fill', $('fillmode').value); $('hint').textContent = { zigzag: 'Fill zigzag: wide strokes and big patches are filled back and forth at the tool\'s own size.', cross: 'Fill cross: zigzag, then rows over it the other way.', off: 'Fill one stroke: every tool grows to whatever size is asked.' }[$('fillmode').value] + fillNote(); };
$('cuts').onchange = () => { store('cp-cuts', $('cuts').value); $('hint').textContent = $('cuts').value === 'pre' ? 'Cuts pre-drawn: a new scene is painted before it is shown.' : 'Cuts drawn: the painter paints the change as it happens.'; };
{ const o = store('cp-outline'), c = store('cp-cuts'); if (['off', 'first', 'last'].includes(o)) $('outline').value = o; if (c === 'pre') $('cuts').value = 'pre'; }
$('line').onchange = () => { $('hint').textContent = $('line').value === 'off' ? 'One line off.' : 'One line: a pen that never lifts, one stroke after another in the ticked styles. Repainting.'; rerunSoon(); };

// ═════════════════════════════════════════════════════════════
//  Text: a word or a short line, set big in the palette's colours (background, then a gradient of the 3rd → 4th
//  colour), and painted like any picture. '|' starts a new line; longer text wraps into up to three lines.
// ═════════════════════════════════════════════════════════════
function wrapWords(t) {
  const w = t.split(/\s+/).filter(Boolean); if (w.length < 2 || t.length < 14) return [t];
  const n = Math.min(3, w.length, Math.ceil(t.length / 12)), goal = t.length / n, lines = [''];
  for (const word of w) { const cur = lines[lines.length - 1]; if (cur && cur.length + word.length / 2 > goal && lines.length < n) lines.push(word); else lines[lines.length - 1] = cur ? cur + ' ' + word : word; }
  return lines;
}
async function paintText(raw) {
  const txt = raw.trim(); if (!txt) { $('textin').focus(); return; }
  try { await document.fonts.load('800 120px Archivo'); } catch (e) { /* the fallback font will do */ }
  const W = LY === LAYOUTS.landscape ? 1920 : 1080, H = LY === LAYOUTS.square ? 1080 : LY === LAYOUTS.landscape ? 1080 : 1350, c = document.createElement('canvas'); c.width = W; c.height = H;
  const x = c.getContext('2d'), col = PAL_IDS.map(id => $(id).value);
  x.fillStyle = col[0]; x.fillRect(0, 0, W, H);
  const lines = txt.includes('|') ? txt.split('|').map(v => v.trim()).filter(Boolean) : wrapWords(txt);
  const font = sz => `800 ${sz}px Archivo, "Arial Black", Helvetica, sans-serif`;
  x.font = font(200); const widest = Math.max(...lines.map(l => x.measureText(l).width));
  const size = Math.min(200 * W * 0.84 / widest, H * 0.74 / lines.length);
  x.font = font(size); x.textAlign = 'center'; x.textBaseline = 'middle';
  const g = x.createLinearGradient(W * 0.08, 0, W * 0.92, 0); g.addColorStop(0, col[2]); g.addColorStop(1, col[3]); x.fillStyle = g;
  const lh = size * 1.04, y0 = H / 2 - lh * (lines.length - 1) / 2;
  lines.forEach((l, i) => x.fillText(l, W / 2, y0 + i * lh));
  const img = await loadImg(c.toDataURL('image/png'));
  stopLive(); startAuto(img, lines.join(' '));
}

// ═════════════════════════════════════════════════════════════
//  Stills: the painting at evenly spaced moments of its build (numbered PNGs in a zip, for a carousel post), or the
//  same moments side by side on one contact sheet. Auto paintings are redrawn from their strokes (spaced on a curve:
//  most of the change happens early, while the big shapes go down), replays re-run.
const stillAt = (i, n) => S.mode === 'auto' ? (i / n) ** 2 : i / n;
// ═════════════════════════════════════════════════════════════
const stillsOk = () => (S.mode === 'auto' && !S.endless.on && S.drawn.length > 0) || (S.mode === 'replay' && !S.mix && !!S.api && !!S.out);
async function eachStill(n, long, cb) {
  if (S.mode === 'auto') {
    flushLandings();
    const N = S.drawn.length, k = long / Math.max(S.out.width, S.out.height), cv = document.createElement('canvas');
    cv.width = Math.round(S.out.width * k); cv.height = Math.round(S.out.height * k);
    const x = cv.getContext('2d'); x.setTransform(k, 0, 0, k, 0, 0); SHP.lib(x).bg(S.bgHex);
    for (let i = 1, j = 0; i <= n; i++) {
      for (const upto = Math.round(N * stillAt(i, n)); j < upto; j++) drawQ(x, S.drawn[j]);
      await cb(cv, i); await yieldTask();
    }
  } else {
    const k = long / Math.max(S.out.width, S.out.height);
    const sn = S.mix && S.mixSnaps && S.mixSnaps.length ? S.mixSnaps : null;
    for (let i = 1; i <= n; i++) {
      if (sn) {     // (replay + live strokes: the snapshots taken as it went; the last one is the canvas now)
        const f = stillAt(i, n), s = sn.reduce((b, v) => Math.abs(v.f - f) < Math.abs(b.f - f) ? v : b, sn[0]);
        await cb(i === n ? canvasAsShown(long) : (() => { const c = document.createElement('canvas'); c.width = Math.round(S.out.width * k); c.height = Math.round(S.out.height * k); const x = c.getContext('2d'); x.imageSmoothingQuality = 'high'; x.drawImage(s.c, 0, 0, c.width, c.height); return c; })(), i);
      } else await cb(await S.api.render(Math.max(1, Math.round(S.total * stillAt(i, n))), k), i);
    }
  }
}
const CRC = (() => { const t = new Uint32Array(256); for (let n = 0; n < 256; n++) { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xEDB88320 ^ (c >>> 1) : c >>> 1; t[n] = c >>> 0; } return t; })();
const crc32 = b => { let c = ~0; for (let i = 0; i < b.length; i++) c = CRC[(c ^ b[i]) & 255] ^ (c >>> 8); return ~c >>> 0; };
// a plain zip (stored: PNGs are compressed already)
function zipOf(files) {
  const le16 = v => [v & 255, v >> 8 & 255], le32 = v => [v & 255, v >> 8 & 255, v >> 16 & 255, v >>> 24 & 255];
  const parts = [], central = []; let off = 0;
  for (const f of files) {
    const name = new TextEncoder().encode(f.name), crc = crc32(f.data), n = f.data.length;
    const head = new Uint8Array([...le32(0x04034b50), ...le16(20), ...le16(0), ...le16(0), ...le16(0), ...le16(0x21), ...le32(crc), ...le32(n), ...le32(n), ...le16(name.length), ...le16(0)]);
    parts.push(head, name, f.data);
    central.push(new Uint8Array([...le32(0x02014b50), ...le16(20), ...le16(20), ...le16(0), ...le16(0), ...le16(0), ...le16(0x21), ...le32(crc), ...le32(n), ...le32(n), ...le16(name.length), ...le16(0), ...le16(0), ...le16(0), ...le16(0), ...le32(0), ...le32(off)]), name);
    off += head.length + name.length + n;
  }
  const size = central.reduce((a, p) => a + p.length, 0);
  return new Blob([...parts, ...central, new Uint8Array([...le32(0x06054b50), ...le16(0), ...le16(0), ...le16(files.length), ...le16(files.length), ...le32(size), ...le32(off), ...le16(0)])], { type: 'application/zip' });
}
const pngOf = cv => new Promise((ok, bad) => cv.toBlob(b => b ? ok(b) : bad(new Error('PNG failed')), 'image/png'));
async function saveStills() {
  if (!stillsOk()) return;
  const n = +$('stillsn').value, files = [];
  $('hint').textContent = `Rendering ${n} stills…`;
  try {
    await eachStill(n, 2160, async (cv, i) => {
      files.push({ name: `${safeName()}-${String(i).padStart(2, '0')}.png`, data: new Uint8Array(await (await pngOf(cv)).arrayBuffer()) });
      $('hint').textContent = `Rendering stills… ${i}/${n}`;
    });
    const z = zipOf(files); download(z, `${safeName()}-stills.zip`);
    $('hint').textContent = `Saved ${n} stills (${(z.size / 1e6).toFixed(1)} MB zip), from ${Math.max(1, Math.round(100 * stillAt(1, n)))}% to 100% of the build.`;
  } catch (e) { $('hint').textContent = "Couldn't make the stills: " + e.message; }
}
async function saveSheet() {
  if (!stillsOk()) return;
  const n = +$('stillsn').value, cols = n === 12 ? 4 : 3, rows = Math.ceil(n / cols), ar = S.out.width / S.out.height;
  const M = 64, G = 28, cw = Math.round((3240 - 2 * M - (cols - 1) * G) / cols), ch = Math.round(cw / ar), lab = 46;
  const sheet = document.createElement('canvas'); sheet.width = 3240; sheet.height = M + rows * (ch + lab + G) - G + 96;
  const x = sheet.getContext('2d'); x.fillStyle = '#0b0b0c'; x.fillRect(0, 0, sheet.width, sheet.height);
  $('hint').textContent = 'Rendering the contact sheet…';
  try {
    await eachStill(n, Math.max(cw, ch) * 1.5, (cv, i) => {
      const c = (i - 1) % cols, r = Math.floor((i - 1) / cols), px = M + c * (cw + G), py = M + r * (ch + lab + G);
      x.imageSmoothingQuality = 'high'; x.drawImage(cv, px, py, cw, ch);
      x.fillStyle = '#6f7074'; x.font = `500 22px ${MONO}`; x.fillText(`${String(i).padStart(2, '0')}  ·  ${Math.max(1, Math.round(100 * stillAt(i, n)))}%`, px, py + ch + 32);
    });
    x.font = `600 22px ${MONO}`; x.fillStyle = '#6f7074'; x.textAlign = 'right';
    x.fillText(`CODE PAINTER · JAS.BLACK — ${S.name}`, sheet.width - M, sheet.height - 40);
    const b = await pngOf(sheet); download(b, `${safeName()}-sheet.png`);
    $('hint').textContent = `Saved the contact sheet: ${n} moments, ${sheet.width}×${sheet.height} (${(b.size / 1e6).toFixed(1)} MB).`;
  } catch (e) { $('hint').textContent = "Couldn't make the sheet: " + e.message; }
}
// ── the examples menu's pictures (not its actions): artworks, or in the public version the drawn demos ──
// (set: the first letter of the ids to take — s / g / u — or none for every picture in the menu)
const examples = set => [...$('example').options].filter(o => o.value && (!o.value.startsWith('__') || o.value.startsWith('__demo:')))
  .filter(o => !set || (o.text[0] === set && /^[sgu]\d/.test(o.text)))
  .map(o => ({ src: o.value.startsWith('__demo:') ? demoPicture(o.value.slice(7)) : o.value, name: o.text }));
// demo pictures, drawn in code (1600 × 1000): a chrome orb in a studio, retro dusk waves, a bloom of petals, colour blocks
function demoPicture(kind) {
  if (kind === 'jas' && window.CP_DEMO_JAS) return window.CP_DEMO_JAS;
  const W = 1600, H = 1000, c = document.createElement('canvas'); c.width = W; c.height = H;
  const x = c.getContext('2d'), R = seeded(kind.length * 977 + kind.charCodeAt(0) * 13);
  const lin = (x0, y0, x1, y1, stops) => { const g = x.createLinearGradient(x0, y0, x1, y1); stops.forEach(([o, col]) => g.addColorStop(o, col)); return g; };
  const rad = (cx, cy, r0, r1, stops, fx = cx, fy = cy) => { const g = x.createRadialGradient(fx, fy, r0, cx, cy, r1); stops.forEach(([o, col]) => g.addColorStop(o, col)); return g; };
  if (kind === 'orb') {
    x.fillStyle = lin(0, 0, 0, H, [[0, '#101116'], [0.6, '#2b2d36'], [0.61, '#1a1b20'], [1, '#07070a']]); x.fillRect(0, 0, W, H);
    const cx = W * 0.5, cy = H * 0.46, r = H * 0.33;
    x.fillStyle = rad(cx, H * 0.83, 0, r * 1.3, [[0, 'rgba(0,0,0,.75)'], [1, 'rgba(0,0,0,0)']]); x.beginPath(); x.ellipse(cx, H * 0.83, r * 1.3, r * 0.22, 0, 0, 7); x.fill();
    x.save(); x.beginPath(); x.arc(cx, cy, r, 0, 7); x.clip();
    x.fillStyle = lin(0, cy - r, 0, cy + r, [[0, '#f4f5f8'], [0.38, '#8b90a0'], [0.5, '#2a2c34'], [0.54, '#c7cad3'], [0.8, '#5d6170'], [1, '#15161b']]); x.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    x.globalCompositeOperation = 'lighter';
    x.fillStyle = rad(cx - r * 0.95, cy + r * 0.1, 0, r * 0.9, [[0, 'rgba(57,255,136,.75)'], [1, 'rgba(57,255,136,0)']]); x.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    x.fillStyle = rad(cx + r * 0.95, cy - r * 0.1, 0, r * 0.9, [[0, 'rgba(179,107,255,.8)'], [1, 'rgba(179,107,255,0)']]); x.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    x.fillStyle = rad(cx - r * 0.35, cy - r * 0.45, 0, r * 0.28, [[0, 'rgba(255,255,255,.95)'], [1, 'rgba(255,255,255,0)']]); x.fillRect(cx - r, cy - r, 2 * r, 2 * r);
    x.restore();
    x.strokeStyle = 'rgba(255,255,255,.14)'; x.lineWidth = 3; x.beginPath(); x.arc(cx, cy, r - 1.5, 0, 7); x.stroke();
  } else if (kind === 'dusk') {
    x.fillStyle = lin(0, 0, 0, H * 0.62, [[0, '#150f33'], [0.45, '#5b2a6e'], [0.8, '#d4566a'], [1, '#f7a95e']]); x.fillRect(0, 0, W, H);
    for (let i = 0; i < 90; i++) { x.fillStyle = `rgba(255,255,255,${0.3 + R() * 0.6})`; x.beginPath(); x.arc(R() * W, R() * H * 0.35, 0.8 + R() * 1.8, 0, 7); x.fill(); }
    const sx = W * 0.64, sy = H * 0.5, sr = H * 0.17;
    x.fillStyle = rad(sx, sy, 0, sr * 2.4, [[0, 'rgba(255,200,120,.55)'], [1, 'rgba(255,200,120,0)']]); x.fillRect(0, 0, W, H);
    x.save(); x.beginPath(); x.arc(sx, sy, sr, 0, 7); x.clip();
    x.fillStyle = lin(0, sy - sr, 0, sy + sr, [[0, '#fff4c2'], [0.55, '#ffb35c'], [1, '#ff5f7e']]); x.fillRect(sx - sr, sy - sr, 2 * sr, 2 * sr);
    for (let k = 0; k < 6; k++) { const y = sy + sr * (0.1 + k * 0.16); x.clearRect(sx - sr, y, 2 * sr, 3 + k * 2.2); }
    x.restore();
    const layers = [['#3a1f5c', '#241440'], ['#2c1850', '#1a0f33'], ['#20123f', '#120a26'], ['#150c2d', '#0b0619'], ['#0c0720', '#050310']];
    layers.forEach(([a, b], k) => {
      const base = H * (0.6 + k * 0.085), amp = 18 + k * 9, f1 = 2 + k * 0.7, ph = R() * 6;
      x.beginPath(); x.moveTo(0, H);
      for (let px = 0; px <= W; px += 8) x.lineTo(px, base + Math.sin(px / W * Math.PI * f1 + ph) * amp + Math.sin(px / W * Math.PI * f1 * 2.7 + ph * 2) * amp * 0.35);
      x.lineTo(W, H); x.closePath(); x.fillStyle = lin(0, base - amp, 0, base + H * 0.25, [[0, a], [1, b]]); x.fill();
    });
  } else if (kind === 'bloom') {
    x.fillStyle = rad(W / 2, H / 2, 0, W * 0.6, [[0, '#13261d'], [1, '#040806']]); x.fillRect(0, 0, W, H);
    const cx = W * 0.5, cy = H * 0.5, rings = [[13, H * 0.42, H * 0.12, ['#b36bff', '#3b1f66']], [10, H * 0.3, H * 0.1, ['#39ff88', '#0f5a36']], [8, H * 0.19, H * 0.075, ['#ffd166', '#b3541e']]];
    for (const [n, len, wid, [c0, c1]] of rings) {
      for (let i = 0; i < n; i++) {
        const a = i / n * Math.PI * 2 + R() * 0.2;
        x.save(); x.translate(cx, cy); x.rotate(a);
        x.fillStyle = lin(0, 0, len, 0, [[0, c1], [0.75, c0], [1, '#ffffff']]);
        x.beginPath(); x.ellipse(len * 0.55, 0, len * 0.5, wid, 0, 0, 7); x.fill(); x.restore();
      }
    }
    x.fillStyle = rad(cx, cy, 0, H * 0.09, [[0, '#fff1b8'], [1, '#e08a1e']]); x.beginPath(); x.arc(cx, cy, H * 0.09, 0, 7); x.fill();
    for (let i = 0; i < 70; i++) { const a = R() * 6.283, d = Math.sqrt(R()) * H * 0.08; x.fillStyle = R() < 0.5 ? '#6b3a0c' : '#fff6d8'; x.beginPath(); x.arc(cx + Math.cos(a) * d, cy + Math.sin(a) * d, 2 + R() * 3, 0, 7); x.fill(); }
  } else {
    x.fillStyle = '#efe9dd'; x.fillRect(0, 0, W, H);
    const P = ['#e63946', '#1d3557', '#f4a261', '#2a9d8f', '#111111', '#a8dadc', '#ffb703'];
    for (let i = 0; i < 16; i++) { x.fillStyle = P[Math.floor(R() * P.length)]; x.fillRect(Math.floor(R() * 8) * W / 8, Math.floor(R() * 5) * H / 5, W / 8 * (1 + Math.floor(R() * 3)), H / 5 * (1 + Math.floor(R() * 2))); }
    for (let i = 0; i < 5; i++) { x.fillStyle = P[Math.floor(R() * P.length)]; x.beginPath(); x.arc(W * (0.1 + R() * 0.8), H * (0.15 + R() * 0.7), 60 + R() * 140, 0, 7); x.fill(); }
    for (let i = 0; i < 4; i++) { x.fillStyle = P[Math.floor(R() * P.length)]; const px = R() * W, py = R() * H, s2 = 120 + R() * 200; x.beginPath(); x.moveTo(px, py); x.lineTo(px + s2, py + s2 * 0.2); x.lineTo(px + s2 * 0.3, py + s2); x.closePath(); x.fill(); }
    x.strokeStyle = '#111'; x.lineWidth = 12;
    for (let i = 1; i < 8; i++) if (R() < 0.6) { x.beginPath(); x.moveTo(i * W / 8, 0); x.lineTo(i * W / 8, H); x.stroke(); }
    for (let j = 1; j < 5; j++) if (R() < 0.7) { x.beginPath(); x.moveTo(0, j * H / 5); x.lineTo(W, j * H / 5); x.stroke(); }
  }
  return c.toDataURL('image/jpeg', 0.92);
}
// ── reel cover: the finished painting filling the frame's shape (9:16, 4:5, 1:1, 16:9), saved clean and with its title
// (in 9:16 the title sits inside the middle 3:4 that a profile grid shows) ──
async function saveCover() {
  if (S.mode === 'idle' || !S.out) return;
  const sizes = { landscape: [1920, 1080], vertical: [1080, 1920], portrait: [1080, 1350], square: [1080, 1080] }, [W, H] = sizes[document.body.dataset.layout] || [1080, 1920];
  $('hint').textContent = 'Making the cover…';
  try {
    if (S.mode === 'auto') flushLandings();
    const art = await renderBig(Math.round(Math.max(W, H) * 1.25));
    const c = document.createElement('canvas'); c.width = W; c.height = H; const x = c.getContext('2d');
    x.fillStyle = '#0b0b0c'; x.fillRect(0, 0, W, H); x.imageSmoothingQuality = 'high'; drawCover(x, art, 0, 0, W, H);
    const clean = await pngOf(c);
    try { await document.fonts.load('800 80px Archivo'); } catch (e) { /* the fallback font will do */ }
    const title = S.name.replace(/^s\d+\s*·\s*/, '').replace(/[_-]+/g, ' ').trim() || 'untitled', base = H > W ? H * 0.8 : H - H * 0.1, pad = W * 0.07;
    const g = x.createLinearGradient(0, base - H * 0.34, 0, Math.min(H, base + H * 0.12)); g.addColorStop(0, 'rgba(0,0,0,0)'); g.addColorStop(1, 'rgba(0,0,0,.72)');
    x.fillStyle = g; x.fillRect(0, base - H * 0.34, W, H);
    let size = Math.round(Math.min(W, H) * 0.095); x.font = `800 ${size}px Archivo, "Arial Black", sans-serif`;
    while (x.measureText(title).width > W - 2 * pad && size > 20) { size -= 2; x.font = `800 ${size}px Archivo, "Arial Black", sans-serif`; }
    x.fillStyle = '#f2f2ef'; x.textBaseline = 'alphabetic'; x.fillText(title, pad, base);
    x.font = `600 ${Math.round(size * 0.3)}px "IBM Plex Mono", ${MONO}`; x.fillStyle = COL.accent; x.fillText('CODE PAINTER', pad, base - size * 1.05);
    const cw = x.measureText('CODE PAINTER  ').width; x.fillStyle = COL.accent2; x.fillText('JAS.BLACK', pad + cw, base - size * 1.05);
    const titled = await pngOf(c);
    download(clean, `${safeName()}-cover.png`); download(titled, `${safeName()}-cover-title.png`);
    $('hint').textContent = `Saved the cover, ${W}×${H}: clean and with its title (two PNGs).`;
  } catch (e) { $('hint').textContent = "Couldn't make the cover: " + e.message; }
}
// with a song, a length trims the chosen part of it (from its in point)
function applyReelLen() {
  const L = reelLen(); if (!L || !AU.el || !AU.dur) return;
  AU.out = Math.min(AU.dur, AU.in + L); if (AU.out - AU.in < L - 0.01) AU.in = Math.max(0, AU.out - L);
  updateSelectionInfo();
}
// per run: nothing looping yet, no snapshots, the playlist's bar counter unset
function newRun() { S.place = null; S.mixSnaps = null; S.kick = 0; S.push = 0; S.sec = null; S.secE = null; S.sizeMul = 1; SND.lastSlot = null; SND.tokT = null; S.dz = 0; S.looped = false; S.doneAt = null; S.capped = false; S.songOn = false; S.cutN = null; S.snaps = []; S.committed = 0; S.cut = null; S.freeze = null; S.cutSig = null; S.cutAvg = null; S.cutAt = null; }

// ── controls ─────────────────────────────────────────────────
// tick-box pickers for style and motion: tick any mix (every stroke picks one of the ticked at random), or all.
// The choice is remembered. Style needs at least one; motion with none ticked = shapes simply appear.
function multiPick(id, key, defaults, noneText, onChange) {
  const root = $(id), btn = root.querySelector('.multibtn'), panel = root.querySelector('.multipanel') || root, boxes = [...panel.querySelectorAll('input[type=checkbox]:not([id])')];
  const count = root.closest('.panel') && root.closest('.panel').querySelector('.count');
  const saved = store(key), start = saved === '-' ? [] : saved ? saved.split(',') : defaults;
  for (const b of boxes) b.checked = start.includes(b.value);
  const values = () => boxes.filter(b => b.checked).map(b => b.value);
  const label = () => {
    const v = boxes.filter(b => b.checked);
    if (count) count.textContent = !v.length && noneText ? noneText : `${v.length} / ${boxes.length}`;
    const tg = root.closest('.panel') && root.closest('.panel').querySelector('[data-set="toggle"]'); if (tg) tg.classList.toggle('on', v.length === boxes.length);
    if (btn) btn.textContent = `${root.dataset.label}: ${!v.length ? noneText : v.length === boxes.length ? 'all' : v[0].parentElement.textContent.trim() + (v.length > 1 ? ` +${v.length - 1}` : '')} ▾`;
  };
  const save = () => { if (!noneText && !values().length) boxes[0].checked = true; store(key, values().join(',') || '-'); label(); if (onChange) onChange(values()); };
  if (btn) btn.onclick = () => { panel.hidden = !panel.hidden; };
  panel.addEventListener('change', save);
  for (const b of panel.querySelectorAll('[data-set]')) b.onclick = () => { for (const x of boxes) x.checked = b.dataset.set === 'all'; save(); };
  // a toggle in the panel title: all on, or back to none (style keeps its first one)
  const tog = root.closest('.panel') && root.closest('.panel').querySelector('[data-set="toggle"]');
  if (tog) tog.onclick = () => { const all = boxes.every(x => x.checked); for (const x of boxes) x.checked = !all; save(); };
  if (btn) addEventListener('pointerdown', e => { if (!root.contains(e.target)) panel.hidden = true; });
  if (!noneText && !values().length) boxes[0].checked = true;
  label();
  const set = vs => { for (const b of boxes) b.checked = vs.includes(b.value); save(); };
  return { values, set };
}
// style: two layers — the subject's styles (green LEDs) and the background's (violet; none = the same everywhere).
// "subject" / "bg" in the title choose which layer the keys show and change. Remembered.
function stylePicker() {
  const root = $('stylepick'), panel = root.closest('.panel'), boxes = [...root.querySelectorAll('input[type=checkbox]:not([id])')], count = panel.querySelector('.count'), tog = panel.querySelector('[data-set="toggle"]');
  const load = (k, def) => { const v = store(k); if (v === '-') return []; const r = v ? v.split(',').filter(x => document.querySelector(`#stylepick input[value="${x}"]`)) : def; return r.length ? r : def; };
  const L = { subj: load('cp-styles', ['painterly']), bg: load('cp-bgstyles', []), edit: 'subj' };
  const show = () => {
    const cur = L[L.edit];
    for (const b of boxes) b.checked = cur.includes(b.value);
    panel.classList.toggle('bgset', L.edit === 'bg');
    $('stysubj').classList.toggle('on', L.edit === 'subj'); $('stybg').classList.toggle('on', L.edit === 'bg'); $('stybg').classList.toggle('set', L.bg.length > 0);
    count.textContent = L.edit === 'bg' && !cur.length ? 'same' : `${cur.length} / ${boxes.length}`;
    tog.classList.toggle('on', cur.length === boxes.length);
  };
  const keep = () => { store('cp-styles', L.subj.join(',')); store('cp-bgstyles', L.bg.join(',') || '-'); show(); restyle(); };
  const save = () => {
    let v = boxes.filter(b => b.checked).map(b => b.value);
    if (L.edit === 'subj' && !v.length) v = [boxes[0].value];
    L[L.edit] = v; keep(); if (L.edit === 'bg') showMask();
  };
  root.addEventListener('change', save);
  tog.onclick = () => { const all = boxes.every(x => x.checked); for (const x of boxes) x.checked = !all; save(); };
  $('stysubj').onclick = () => { L.edit = 'subj'; show(); };
  $('stybg').onclick = () => {
    L.edit = 'bg'; show(); showMask();
    $('hint').textContent = `Background styles (violet): tick the styles for the background${S.mask ? ' — shown in violet on the painting; the subject in green' : ''}. None ticked: painted like the subject.`;
  };
  show();
  return { values: () => L.subj, bg: () => L.bg, set: (subj, bg) => { L.subj = subj && subj.length ? subj : ['painterly']; if (bg) L.bg = bg; keep(); } };
}
const stylePick = stylePicker();
// spray: cap (nozzle), wall and piece order
{ for (const [id, k] of [['spraycap', 'cap'], ['spraywall', 'wall'], ['sprayorder', null]]) { const v = store('cp-' + id); if (v && [...$(id).options].some(o => o.value === v)) $(id).value = v; if (k) SPRAY[k] = $(id).value; }
  const name = id => $(id).selectedOptions[0].textContent;
  $('spraycap').onchange = () => { SPRAY.cap = $('spraycap').value; store('cp-spraycap', SPRAY.cap); S.big = null; $('hint').textContent = `Spray cap: ${name('spraycap').replace('cap: ', '')}. Repainting.`; rerunSoon(); };
  $('spraywall').onchange = () => { SPRAY.wall = $('spraywall').value; store('cp-spraywall', SPRAY.wall); WALL.key = ''; S.big = null; $('hint').textContent = SPRAY.wall === 'none' ? 'Painting on plain canvas.' : `Painting on ${SPRAY.wall}: the paint takes on the wall's texture.`; };
  $('sprayorder').onchange = () => { store('cp-sprayorder', $('sprayorder').value); $('hint').textContent = $('sprayorder').value === 'lines' ? 'Spray + lines: once the piece is painted, black outlines and white shines go over it.' : 'Spray clean: nothing is added over the finished piece.'; rerunSoon(); }; }
// a style's own size: right-click a style key for a slider (×0.25 … ×4); the key shows it when it isn't ×1
{
  const pop = $('stysz'), inp = $('styszin'), out = $('styszval'); let cur = null;
  const toK = v => Math.pow(2, v / 50), fromK = k => Math.round(Math.log2(k) * 50);
  const mark = () => { for (const l of document.querySelectorAll('#stylepick label.key')) { const v = l.querySelector('input').value, k = SSZ[v]; if (k && Math.abs(k - 1) > 0.02) l.dataset.sz = '×' + (k < 1 ? k.toFixed(2).replace(/^0/, '') : k.toFixed(1)); else delete l.dataset.sz; } };
  const send = () => { store('cp-stysize', JSON.stringify(SSZ)); worker.postMessage({ type: 'stylesize', map: SSZ }); helpersPost({ type: 'stylesize', map: SSZ }); mark(); showAutoShapes(); };
  const set = k => { if (!cur) return; if (Math.abs(k - 1) < 0.02) delete SSZ[cur]; else SSZ[cur] = Math.round(k * 100) / 100; out.textContent = '×' + (SSZ[cur] || 1).toFixed(2).replace(/\.?0+$/, ''); send(); };
  $('stylepick').addEventListener('contextmenu', e => {
    const l = e.target.closest('label.key'); if (!l) return; e.preventDefault();
    cur = l.querySelector('input').value; $('styszname').textContent = l.textContent.trim();
    inp.value = fromK(styleSizeOf(cur)); out.textContent = '×' + styleSizeOf(cur).toFixed(2).replace(/\.?0+$/, '');
    const pr = l.closest('.panel').getBoundingClientRect(), r = l.getBoundingClientRect(); pop.hidden = false;
    pop.style.left = Math.max(4, Math.min(pr.width - pop.offsetWidth - 4, r.left - pr.left - 40)) + 'px'; pop.style.top = (r.bottom - pr.top + 6) + 'px';
    $('hint').textContent = `${cur}: its own stroke size, on top of the size knob (for mixing a small style with a big one).`;
  });
  inp.oninput = () => set(toK(+inp.value));
  $('styszx').onclick = () => { inp.value = 0; set(1); };
  addEventListener('pointerdown', e => { if (!pop.hidden && !pop.contains(e.target)) pop.hidden = true; });
  addEventListener('keydown', e => { if (e.key === 'Escape') pop.hidden = true; });
  mark();
}
// style groups: the tabs over the style keys (a dot on each group that has a ticked style in it)
const STYLE_TABS = (() => {
  const root = $('stylepick'), tabs = [...document.querySelectorAll('#stytabs [data-cat]')];
  const mark = () => {
    const on = new Set([...root.querySelectorAll('label.key[data-cat] input:checked')].map(i => i.closest('label').dataset.cat));
    for (const t of tabs) t.classList.toggle('has', on.has(t.dataset.cat));
  };
  const show = c => { root.dataset.tab = c; for (const t of tabs) t.classList.toggle('on', t.dataset.cat === c); store('cp-stytab', c); mark(); };
  for (const t of tabs) t.onclick = () => show(t.dataset.cat);
  root.addEventListener('change', () => setTimeout(mark));
  const first = root.querySelector('label.key[data-cat] input:checked');
  show(store('cp-stytab') || (first ? first.closest('label').dataset.cat : 'paint'));
  return { mark, show };
})();
const motionPick = multiPick('motionpick', 'cp-motions', ['draw', 'sketch'], 'instant');
$('file').onchange = e => { openFiles([...e.target.files]); e.target.value = ''; };
// ═════════════════════════════════════════════════════════════
//  Phone: on a small screen the studio shows the painting with its code on top (4:5, or 9:16 for reels) and a strip
//  of essentials under it — a picture / video, the examples, the camera, the style, the view and frame, shapes,
//  speed, restart, record and save — all driving the studio's own controls. The full studio is for computers (a line
//  says so). ?phone / ?desktop choose either on any screen. The desktop's own choices of view and frame are kept
//  aside, not overwritten.
// ═════════════════════════════════════════════════════════════
{
  const q = new URLSearchParams(location.search), sizeQ = matchMedia('(max-width: 760px), (max-height: 500px) and (pointer: coarse)');
  const P = { on: false, view: 'duo', frame: 'portrait', keep: null };
  // (also a phone when the page is laid out wider than the phone itself — "desktop site" in the browser, or an app's
  // own browser: the screen's real size and a touch screen still tell)
  const coarse = matchMedia('(pointer: coarse)'), smallScreen = () => coarse.matches && Math.min(screen.width, screen.height) <= 600 && Math.max(screen.width, screen.height) <= 1000;
  const phoneSize = () => q.has('phone') || (!q.has('desktop') && (sizeQ.matches || smallScreen()));
  const wanted = phoneSize;      // (a phone always gets this: the full studio is for computers)
  // iPhones zoom in on a menu with small text when it's tapped; this stops that (pinching to zoom still works there)
  if (/iP(hone|od|ad)/.test(navigator.userAgent) || (/Macintosh/.test(navigator.userAgent) && navigator.maxTouchPoints > 1)) {
    const m = document.querySelector('meta[name=viewport]'); if (m) m.content = 'width=device-width, initial-scale=1, maximum-scale=1';
  }
  const segOn = (id, v) => document.querySelectorAll(`#${id} button`).forEach(b => b.classList.toggle('on', b.dataset.v === v));
  const apply = () => { setLayout(P.frame, false); setDisplay(P.view, false); segOn('phview', P.view); segOn('phframe', P.frame); };
  function set(on) {
    document.body.classList.toggle('phonesize', phoneSize());
    if (on === P.on) return;
    P.on = on; document.body.classList.toggle('phone', on);
    if (on) { P.keep = { layout: document.body.dataset.layout, display: DISPLAY }; apply(); }
    else if (P.keep) { setLayout(P.keep.layout, false); setDisplay(P.keep.display, false); }
    fitStage();
  }
  // the controls, copied from (and driving) the studio's own
  const pex = $('phex'); pex.innerHTML = $('example').innerHTML; pex.value = '';
  pex.onchange = () => {
    if (pex.value === '__text') { pex.value = $('example').value; $('phtextrow').hidden = false; fitStage(); $('phtextin').focus(); return; }      // (a word, typed here: the studio's own text box is in the hidden column)
    $('example').value = pex.value; $('example').dispatchEvent(new Event('change')); pex.value = $('example').value; };
  $('example').addEventListener('change', () => { pex.value = $('example').value; });
  const phText = () => { const t = $('phtextin').value; if (!t.trim()) return $('phtextin').focus(); $('phtextin').blur(); $('textin').value = t; pex.value = ''; paintText(t); };
  $('phtextgo').onclick = phText;
  $('phtextin').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); phText(); } });
  $('phtextx').onclick = () => { $('phtextrow').hidden = true; fitStage(); };
  $('phfile').onchange = e => { openFiles([...e.target.files]); e.target.value = ''; pex.value = ''; };
  $('phcam').onclick = () => { pex.value = ''; startLive('camera'); };
  // the ready-made looks (as in easy mode) and the path, then every style
  setTimeout(() => { for (const L of LOOKS) { const b = document.createElement('button'); b.type = 'button'; b.dataset.look = L.id; b.textContent = L.name; b.onclick = () => { pex.value = ''; applyLook(L); for (const c of $('phlooks').children) c.classList.toggle('on', c === b); }; $('phlooks').appendChild(b); } });     // (after the looks are defined, further down)
  for (const b of document.querySelectorAll('#phpath [data-p]')) b.onclick = () => setPath(b.dataset.p, true);
  const chips = $('phstyles');
  for (const box of document.querySelectorAll('#stylepick input[type=checkbox]:not([id])')) {
    const b = document.createElement('button'); b.type = 'button'; b.dataset.v = box.value; b.textContent = box.parentElement.textContent.trim();
    b.onclick = () => { stylePick.set([box.value], []); showChips(); };
    chips.appendChild(b);
  }
  const showChips = () => { const v = stylePick.values(); for (const b of chips.children) b.classList.toggle('on', v.includes(b.dataset.v)); };
  document.getElementById('stylepick').addEventListener('change', showChips); showChips();
  for (const b of document.querySelectorAll('#phview button')) b.onclick = () => { P.view = b.dataset.v; apply(); };
  for (const b of document.querySelectorAll('#phframe button')) b.onclick = () => { P.frame = b.dataset.v; apply(); };
  const psh = $('phshapes'); psh.innerHTML = $('shapes').innerHTML; psh.value = $('shapes').value;
  psh.onchange = () => { $('shapes').value = psh.value; $('shapes').dispatchEvent(new Event('change')); $('hint').textContent = `${psh.value} shapes from the next picture (or ⟲ restart).`; };
  const psp = $('phspeed'), showSpeedP = () => { psp.value = $('speed').value; $('phspeedval').textContent = $('speedval').textContent; };
  psp.oninput = () => { $('speed').value = psp.value; $('speed').dispatchEvent(new Event('input')); showSpeedP(); };
  $('speed').addEventListener('input', showSpeedP); new MutationObserver(showSpeedP).observe($('speedval'), { childList: true, characterData: true, subtree: true }); showSpeedP();
  $('phgo').onclick = () => { if ($('restart').disabled) $('hint').textContent = 'Pick a picture, a photo or the camera first.'; else $('restart').click(); };
  const goOn = () => $('phgo').classList.toggle('off', $('restart').disabled);
  new MutationObserver(goOn).observe($('restart'), { attributes: true, attributeFilter: ['disabled'] }); goOn();
  $('phrec').onclick = () => $('rec').click();
  new MutationObserver(() => { $('phrec').classList.toggle('on', $('rec').classList.contains('on')); $('phrec').lastChild.textContent = $('rec').textContent.trim() || 'record'; }).observe($('rec'), { attributes: true, childList: true, subtree: true });
  // (a picture is saved at 4K on a phone: 8K is more than a phone's memory likes)
  $('phsave').onclick = () => {
    if (!$('savevid').disabled) return $('savevid').click();
    if ($('savepng').disabled) { $('hint').textContent = 'Nothing to save yet: pick a picture first.'; return; }
    const keep = $('bigres').value; $('bigres').value = '3840'; $('savepng').click(); $('bigres').value = keep;
  };
  sizeQ.addEventListener('change', () => set(wanted()));
  set(wanted());
}

// slots: click an empty slot to choose pictures, a full one to play it; drop pictures on a slot; 1 – 9 / 0 play them
let slotPick = 0;
document.querySelectorAll('#slots .slot').forEach((el, i) => {
  el.onclick = e => { if (e.target.classList.contains('slotx')) { clearSlot(i); return; } if (SLOTS[i]) playSlot(i); else { slotPick = i; $('slotfile').click(); } };
  el.addEventListener('dragover', e => { e.preventDefault(); e.stopPropagation(); el.classList.add('drop'); });
  el.addEventListener('dragleave', () => el.classList.remove('drop'));
  el.addEventListener('drop', e => {
    e.preventDefault(); e.stopPropagation(); el.classList.remove('drop'); document.body.classList.remove('drag');
    fillSlots(i, [...e.dataTransfer.files]);
  });
});
$('slotfile').onchange = e => { fillSlots(slotPick, [...e.target.files]); e.target.value = ''; };
// narrow window: the playlist's label steps aside so the slots keep their room
new ResizeObserver(([en]) => $('slots').classList.toggle('narrow', en.contentRect.width < 820)).observe($('slots'));
addEventListener('keydown', e => {
  if (e.target.closest && e.target.closest('input, select, textarea') || e.metaKey || e.ctrlKey || e.altKey || OFF.on) return;
  if (e.key >= '0' && e.key <= '9') { const i = (+e.key + 9) % 10; if (SLOTS[i]) playSlot(i); }      // (1 – 9, then 0 for the tenth)
  if (e.key === ' ' && !$('play').disabled && !(e.target.closest && e.target.closest('button'))) { e.preventDefault(); $('play').click(); }
});
$('infinite').onchange = () => { if (infinite() && S.mode === 'auto' && S.done && !S.endless.on) { S.running = true; S.pausedAt = 0; beginEndless(); } };
// brushes (the custom one is remembered)
{ const c = $('lightpad'), t = (store('cp-light') || '').split(',').map(Number);
  if (t.length === 2 && t.every(Number.isFinite)) { const l = Math.hypot(t[0], t[1]) || 1; LIGHT.x = t[0] / l; LIGHT.y = t[1] / l; }
  const setFrom = e => { const r = c.getBoundingClientRect(), dx = (e.clientX - r.left - r.width / 2) / (r.width / 2), dy = (e.clientY - r.top - r.height / 2) / (r.height / 2), l = Math.hypot(dx, dy); if (l < 0.05) return; LIGHT.x = dx / l; LIGHT.y = dy / l; drawLightPad(); if (RLF.on && RLF.st) { RLF.st.dirty = true; S.big = null; } };   // a relief relights as the sun moves
  let drag = false;
  c.addEventListener('pointerdown', e => { drag = true; c.setPointerCapture(e.pointerId); setFrom(e); });
  c.addEventListener('pointermove', e => { if (drag) setFrom(e); });
  const done = () => { if (!drag) return; drag = false; store('cp-light', LIGHT.x.toFixed(3) + ',' + LIGHT.y.toFixed(3)); relight(); $('hint').textContent = RLF.on ? 'Light moved: the relief is lit from there now.' : 'Light moved: the lit styles are drawn again with it.'; };
  c.addEventListener('pointerup', done); c.addEventListener('pointercancel', done);
  c.addEventListener('dblclick', () => { LIGHT.x = -0.62; LIGHT.y = -0.78; drawLightPad(); store('cp-light', ''); relight(); });
  drawLightPad(); addEventListener('resize', drawLightPad); }
$('brush').onchange = () => {
  if ($('brush').value === 'custom' && !BRUSH.custom) { $('brushfile').click(); return; }
  setBrush($('brush').value); store('cp-brush', BRUSH.name);
  $('hint').textContent = rebrush() ? `Brush: ${$('brush').selectedOptions[0].text} — the picture is repainted with it.` : `Brush: ${$('brush').selectedOptions[0].text} — new strokes use it.`;
};
$('brushfile').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) { if (!BRUSH.custom) $('brush').value = BRUSH.name; return; }
  try { const img = await loadImg(URL.createObjectURL(f)); setBrush('custom', img); store('cp-brush', 'custom'); store('cp-brushimg', BRUSH.custom.toDataURL()); $('hint').textContent = rebrush() ? 'Your brush is in: the picture is repainted with it.' : 'Your brush is in: new strokes use it.'; }
  catch (err) { $('hint').textContent = "Couldn't use that picture as a brush."; $('brush').value = BRUSH.name; }
};
(async () => {
  const b = store('cp-brush'), img = store('cp-brushimg');
  if (img) { try { BRUSH.custom = stampFromImage(await loadImg(img)); } catch (e) { /* forget it */ } }
  if (b && b !== 'default') setBrush(b);
})();
// code colours (remembered)
{ const c = (store('cp-codec') || '').split(','); if (/^#[0-9a-f]{6}$/i.test(c[0] || '')) $('codec1').value = c[0]; if (/^#[0-9a-f]{6}$/i.test(c[1] || '')) $('codec2').value = c[1]; setCodeColours(); }
$('codec1').oninput = $('codec2').oninput = setCodeColours;
// mouse on the recording (choices remembered)
{ const m = (store('cp-mouse') || '').split(','); if (m[0] === '1') $('mouseon').checked = true; if (m[1]) $('mouseicon').value = m[1]; if (/^#[0-9a-f]{6}$/i.test(m[2] || '')) $('mousecol').value = m[2]; if (m[3] === '0') $('mousetrail').checked = false; updateMouseCursor(); }
for (const id of ['mouseon', 'mouseicon', 'mousecol', 'mousetrail']) $(id).addEventListener(id === 'mousecol' ? 'input' : 'change', () => { updateMouseCursor(); store('cp-mouse', [$('mouseon').checked ? 1 : 0, $('mouseicon').value, $('mousecol').value, $('mousetrail').checked ? 1 : 0].join(',')); });
$('livein').onchange = e => { const v = e.target.value; e.target.value = ''; if (v) { menusClear(); startLive(v); } };
$('file3d').onchange = e => { const f = e.target.files[0]; if (f) open3D(f); e.target.value = ''; };
// a picture / demo stays shown in the menu while it paints (so the wheel and the arrow keys can step on from it); the
// menu's actions (your text, a whole set) go back to "examples…"
const isItem = o => !!o.value && (!o.value.startsWith('__') || o.value.startsWith('__demo:'));
$('example').onchange = e => {
  RSHOW.ids = null;
  const o = e.target.selectedOptions[0], v = e.target.value, name = o ? o.text : v;
  if (!o || !isItem(o)) e.target.value = '';
  $('replay').value = '';
  if (v === '__text') { $('textrow').hidden = false; $('textin').focus(); $('textin').select(); return; }
  stopLive();
  if (v.startsWith('__playlist')) return startPlaylist(examples(v.split(':')[1]));
  if (v.startsWith('__demo:')) return startAuto(demoPicture(v.slice(7)), name);
  if (v) startAuto(v, name);
};
for (const id of ['layerfmt', 'layershape', 'layerfit']) { const v = store('cp-' + id); if (v && [...$(id).options].some(o => o.value === v)) $(id).value = v; $(id).onchange = () => store('cp-' + id, $(id).value); }
$('replaylayer').onclick = () => {
  $('example').value = ''; $('replay').value = '';
  if (!(+$('mix').value)) { $('mix').value = 35; $('mix').dispatchEvent(new Event('input', { bubbles: true })); }
  replayShow(null, true);
};
$('replay').onchange = e => {
  const v = e.target.value; if (!v) return;
  $('example').value = '';
  if (v.startsWith('__show')) return replayShow(v.split(':')[1]);
  RSHOW.ids = null; startReplay(v);
};
// replays one after another: every piece of a set (or all of them) in turn, each held for the playlist's hold time
// once it is done, round and round until something else is picked
const RSHOW = { ids: null, i: 0, layer: false };
// layering keeps one frame for the whole show: its shape (the first piece's, or a fixed one), only the pieces of that
// shape or all of them, each piece cropped to fill the frame or fitted inside it (black bars)
// each piece's own canvas size (the local version's build fills this in), for layering only pieces of one shape
let PIECE_SIZE = {"g001":[726,1024],"g002":[726,1024],"g003":[726,1024],"g004":[726,1024],"g005":[701,1024],"g006":[701,1024],"g007":[701,1024],"g008":[701,1024],"g009":[701,1024],"g010":[701,1024],"g011":[701,1024],"g012":[726,1024],"g013":[726,1024],"g014":[726,1024],"g015":[726,1024],"g016":[726,1024],"g017":[726,1024],"g018":[726,1024],"g019":[726,1024],"g020":[726,1024],"g021":[726,1024],"g022":[726,1024],"g023":[726,1024],"g024":[726,1024],"g025":[726,1024],"g026":[726,1024],"g027":[726,1024],"g028":[726,1024],"g029":[726,1024],"g030":[726,1024],"g031":[726,1024],"g032":[726,1024],"g033":[726,1024],"g034":[726,1024],"g035":[726,1024],"g036":[726,1024],"g037":[726,1024],"g038":[726,1024],"g039":[726,1024],"g040":[726,1024],"g041":[726,1024],"g042":[726,1024],"g043":[726,1024],"g044":[726,1024],"g045":[726,1024],"g046":[726,1024],"g047":[726,1024],"g048":[726,1024],"g049":[726,1024],"g050":[726,1024],"g051":[726,1024],"g052":[726,1024],"g053":[726,1024],"g054":[726,1024],"g055":[726,1024],"g056":[726,1024],"g057":[726,1024],"g058":[726,1024],"g059":[726,1024],"g060":[726,1024],"g061":[726,1024],"g062":[726,1024],"g063":[726,1024],"g064":[726,1024],"g065":[726,1024],"g066":[726,1024],"g067":[726,1024],"g068":[726,1024],"g069":[726,1024],"g070":[726,1024],"g071":[726,1024],"g072":[726,1024],"g073":[726,1024],"g074":[726,1024],"g075":[726,1024],"g076":[726,1024],"g077":[726,1024],"g078":[726,1024],"g079":[726,1024],"g080":[726,1024],"g081":[726,1024],"g082":[726,1024],"g083":[726,1024],"g084":[726,1024],"g085":[726,1024],"g086":[726,1024],"g087":[726,1024],"g088":[726,1024],"g089":[726,1024],"g090":[726,1024],"g091":[726,1024],"g092":[726,1024],"g093":[726,1024],"g094":[726,1024],"g095":[726,1024],"g096":[726,1024],"g097":[726,1024],"g098":[726,1024],"g099":[726,1024],"g100":[726,1024],"g101":[726,1024],"g102":[726,1024],"g103":[726,1024],"g104":[726,1024],"g105":[726,1024],"g106":[726,1024],"g107":[726,1024],"g108":[726,1024],"g109":[726,1024],"g110":[726,1024],"g111":[726,1024],"g112":[726,1024],"g113":[726,1024],"g114":[726,1024],"g115":[726,1024],"g116":[726,1024],"g117":[726,1024],"g118":[726,1024],"g119":[726,1024],"g120":[726,1024],"g121":[726,1024],"g122":[726,1024],"g123":[726,1024],"g124":[726,1024],"g125":[726,1024],"g126":[726,1024],"g127":[726,1024],"g128":[726,1024],"g129":[726,1024],"g130":[726,1024],"g131":[726,1024],"g132":[726,1024],"g133":[726,1024],"g134":[726,1024],"g135":[726,1024],"g136":[726,1024],"g137":[726,1024],"g138":[726,1024],"g139":[726,1024],"g140":[726,1024],"g141":[726,1024],"g142":[726,1024],"g143":[726,1024],"g144":[726,1024],"g145":[726,1024],"g146":[726,1024],"g147":[726,1024],"g148":[726,1024],"g149":[726,1024],"g150":[726,1024],"g151":[726,1024],"g152":[726,1024],"g153":[726,1024],"g154":[726,1024],"g155":[726,1024],"g156":[726,1024],"g157":[726,1024],"g158":[726,1024],"g159":[726,1024],"g160":[726,1024],"g161":[726,1024],"g162":[726,1024],"g163":[726,1024],"g164":[726,1024],"g165":[726,1024],"g166":[726,1024],"g167":[726,1024],"g168":[726,1024],"g169":[726,1024],"g170":[726,1024],"g171":[726,1024],"g172":[726,1024],"g173":[726,1024],"g174":[726,1024],"g175":[726,1024],"g176":[726,1024],"g177":[726,1024],"g178":[726,1024],"g179":[726,1024],"g180":[726,1024],"g181":[726,1024],"g182":[726,1024],"g183":[726,1024],"g184":[726,1024],"g185":[726,1024],"g186":[726,1024],"g187":[726,1024],"g188":[726,1024],"g189":[726,1024],"g190":[1024,726],"g191":[1024,726],"g192":[1024,726],"g193":[1024,726],"g194":[1024,726],"g195":[1024,726],"g196":[1024,726],"g197":[1024,726],"g198":[1024,726],"g199":[1024,726],"g200":[1024,726],"g201":[1024,726],"g202":[1024,726],"g203":[578,1024],"g204":[578,1024],"g205":[578,1024],"g206":[578,1024],"g207":[578,1024],"g208":[578,1024],"g209":[578,1024],"g210":[578,1024],"g211":[578,1024],"g212":[578,1024],"g213":[578,1024],"g214":[578,1024],"g215":[578,1024],"g216":[578,1024],"g217":[1024,726],"g218":[1024,726],"g219":[1024,726],"g220":[1024,726],"g221":[726,1024],"g222":[726,1024],"g223":[726,1024],"g224":[726,1024],"g225":[726,1024],"g226":[706,1024],"g227":[706,1024],"s01":[1024,1024],"s02":[1024,1024],"s03":[1024,1024],"s04":[1024,1024],"s05":[1024,559],"s06":[1024,1024],"s07":[1024,1024],"s08":[1024,1024],"s09":[1024,1024],"s10":[1024,1024],"s11":[1024,1024],"s12":[768,1024],"s13":[1024,580],"s14":[1024,1024],"s15":[1024,1024],"s16":[575,1024],"s17":[1024,1024],"s18":[1024,1024],"s19":[716,862],"s20":[1024,1024],"s21":[859,1024],"s22":[1024,947],"s23":[819,1024],"s24":[1024,1024],"s25":[818,1024],"s26":[1024,1024],"s27":[1024,1024],"s28":[1024,1024],"s29":[922,1024],"s30":[1024,1024],"s31":[1024,1024],"s32":[1024,1024],"s33":[1024,1024],"s34":[578,1024],"s35":[819,1024],"s36":[869,1024],"s37":[706,1024],"s38":[1024,1024],"s39":[1024,1024],"s40":[726,1024],"s41":[726,1024],"s42":[726,1024],"s43":[726,1024],"s44":[726,1024],"s45":[726,1024],"s46":[726,1024],"s47":[726,1024],"s48":[726,1024],"s49":[726,1024],"s50":[726,1024],"s51":[726,1024],"s52":[726,1024],"s53":[1024,1024],"s54":[1024,580],"s55":[1024,580],"s56":[1024,683],"u001":[726,1024],"u002":[726,1024],"u003":[726,1024],"u004":[726,1024],"u005":[726,1024],"u006":[726,1024],"u007":[726,1024],"u008":[726,1024],"u009":[726,1024],"u010":[726,1024],"u011":[726,1024],"u012":[726,1024],"u013":[726,1024],"u014":[726,1024],"u015":[726,1024],"u016":[726,1024],"u017":[726,1024],"u018":[726,1024],"u019":[726,1024],"u020":[726,1024],"u021":[726,1024],"u022":[726,1024],"u023":[726,1024],"u024":[726,1024],"u025":[726,1024],"u026":[726,1024],"u027":[726,1024],"u028":[726,1024],"u029":[726,1024],"u030":[726,1024],"u031":[726,1024],"u032":[726,1024],"u033":[726,1024],"u034":[726,1024],"u035":[726,1024],"u036":[726,1024],"u037":[726,1024],"u038":[726,1024],"u039":[726,1024],"u040":[726,1024],"u041":[726,1024],"u042":[726,1024],"u043":[726,1024],"u044":[726,1024],"u045":[726,1024],"u046":[726,1024],"u047":[726,1024],"u048":[726,1024],"u049":[726,1024],"u050":[726,1024],"u051":[726,1024],"u052":[726,1024],"u053":[726,1024],"u054":[726,1024],"u055":[726,1024],"u056":[726,1024],"u057":[726,1024],"u058":[726,1024],"u059":[726,1024],"u060":[726,1024],"u061":[726,1024],"u062":[726,1024],"u063":[726,1024],"u064":[726,1024],"u065":[726,1024],"u066":[726,1024],"u067":[726,1024],"u068":[726,1024],"u069":[726,1024],"u070":[726,1024],"u071":[726,1024],"u072":[726,1024],"u073":[726,1024],"u074":[726,1024],"u075":[726,1024],"u076":[726,1024],"u077":[726,1024],"u078":[726,1024],"u079":[726,1024],"u080":[726,1024],"u081":[726,1024],"u082":[726,1024],"u083":[726,1024],"u084":[726,1024],"u085":[726,1024],"u086":[726,1024],"u087":[726,1024],"u088":[726,1024],"u089":[726,1024],"u090":[726,1024],"u091":[726,1024],"u092":[726,1024],"u093":[726,1024],"u094":[726,1024],"u095":[726,1024],"u096":[726,1024],"u097":[726,1024],"u098":[726,1024],"u099":[726,1024],"u100":[726,1024]};
const FRAMES = { '1:1': 1, '4:5': 4 / 5, '5:7': 726 / 1024, '9:16': 9 / 16, '16:9': 16 / 9, '7:5': 1024 / 726 };
const aspectOf = id => { const s = PIECE_SIZE[id]; return s ? s[0] / s[1] : null; };
function replayShow(set, layer = false) {
  let ids = PIECES.map(([id]) => id).filter(id => !set || id[0] === set); if (!ids.length) return;
  if (layer) for (let i = ids.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [ids[i], ids[j]] = [ids[j], ids[i]]; }     // (a random order)
  RSHOW.frame = null; let note = '';
  if (layer) {
    const fmt = $('layerfmt').value, A = fmt === 'first' ? aspectOf(ids[0]) || 726 / 1024 : FRAMES[fmt] || 1;
    if ($('layershape').value === 'same') {
      const same = ids.filter(id => { const a = aspectOf(id); return a && Math.abs(Math.log(a / A)) < 0.05; });
      if (same.length) ids = same; else note = ' (no piece has that shape: all of them, ' + $('layerfit').value + ')';
    }
    RSHOW.frame = { A, fit: $('layerfit').value };
    RSHOW.note = `${ids.length} pieces${note}`;
  }
  RSHOW.ids = ids; RSHOW.i = 0; RSHOW.layer = layer; startReplay(ids[0], { layer });
}
function replayShowNext(gen) {
  if (!RSHOW.ids) return;
  const ids = RSHOW.ids, t0 = clock();
  const tick = () => {
    if (RSHOW.ids !== ids || gen !== S.replayGen || S.mode !== 'replay') return;           // (something else took over)
    if (clock() - t0 < +$('hold').value * 1000) return setTimeout(tick, 200);
    RSHOW.i = (RSHOW.i + 1) % ids.length; startReplay(ids[RSHOW.i], { layer: RSHOW.layer });
  };
  setTimeout(tick, 200);
}
// examples / replay: the mouse wheel over the menu, or ↑ ↓ (page up / down: 10 at a time) while it has the focus, step
// through its pictures; each one starts after a short pause, so a quick spin doesn't start every one in between
function menuStepper(sel, ok) {
  let timer = null, acc = 0;
  const step = d => {
    const L = [...sel.options].filter(ok); if (!L.length) return;
    let i = L.findIndex(o => o.value === sel.value);
    i = i < 0 ? (d > 0 ? 0 : L.length - 1) : Math.min(L.length - 1, Math.max(0, i + d));
    if (L[i].value === sel.value) return;
    sel.value = L[i].value;
    const g = L[i].parentElement.tagName === 'OPTGROUP' ? ` · ${L[i].parentElement.label}` : '';
    $('hint').textContent = `${L[i].text}   (${i + 1} / ${L.length}${g})`;
    clearTimeout(timer); timer = setTimeout(() => sel.dispatchEvent(new Event('change')), 380);
  };
  sel.addEventListener('wheel', e => {
    e.preventDefault();
    const d = e.deltaY * (e.deltaMode === 1 ? 33 : e.deltaMode === 2 ? 400 : 1);
    if (Math.abs(d) >= 50) { acc = 0; step(Math.sign(d)); return; }        // a mouse wheel's notch: one step
    acc += d; if (Math.abs(acc) >= 90) { step(Math.sign(acc)); acc = 0; }   // a trackpad's glide: one step per little stretch
  }, { passive: false });
  sel.addEventListener('keydown', e => {
    const d = { ArrowDown: 1, ArrowUp: -1, PageDown: 10, PageUp: -10 }[e.key];
    if (d) { e.preventDefault(); step(d); }
  });
}
menuStepper($('example'), isItem);
menuStepper($('replay'), o => !!o.value && !o.value.startsWith('__'));
// anything opened another way: the menus go back to their titles
const menusClear = () => { $('example').value = ''; $('replay').value = ''; RSHOW.ids = null; };
// size: stroke size, sent to the painters straight away (applies to the strokes that follow); remembered
$('ssize').oninput = () => {
  const k = sizeK(), rand = sizeRand(); $('ssizeval').textContent = rand ? 'all' : '×' + (k < 0.995 ? k.toFixed(2) : k.toFixed(1)); $('ssize').disabled = rand;
  worker.postMessage({ type: 'size', k, rand }); helpersPost({ type: 'size', k, rand }); store('cp-size', $('ssize').value); store('cp-sizerand', rand ? '1' : '');
};
$('ssizerand').onchange = $('ssize').oninput;
{ const v = store('cp-size'); if (v) $('ssize').value = v; $('ssizerand').checked = store('cp-sizerand') === '1'; $('ssize').oninput(); }
// + live: how many live strokes join a replay (applies from the next replay / ⟲ restart); remembered
$('mix').oninput = () => { const v = +$('mix').value; $('mixval').textContent = v ? v + '%' : 'off'; store('cp-mix', v); };
{ const v = store('cp-mix'); if (v) $('mix').value = v; $('mix').oninput(); }
// code finish: the last part of a mixed replay is code only, so its finishing layers land on top of the strokes
$('mixfin').oninput = () => { const v = +$('mixfin').value; $('mixfinval').textContent = v + '%'; store('cp-mixfin', v); };
{ const v = store('cp-mixfin'); if (v !== null && v !== undefined && v !== '') $('mixfin').value = v; $('mixfin').oninput(); }
$('audio').onchange = e => { const f = e.target.files[0]; if (f) loadAudio(f); e.target.value = ''; };
$('audiox').onclick = removeAudio;
$('vsound').onclick = () => setVideoSound({ off: 'keep', keep: 'music', music: 'off' }[S.vsound || 'off']);
$('sens').oninput = () => { if (AU.on) detectHits(); };
$('perhit').onchange = updateSelectionInfo;
$('listen').onclick = toggleListen;
// the demo songs (audio/demo/): loaded just like a song you drop in
$('demosong').onchange = async () => {
  const k = $('demosong').value; if (!k) return;
  $('hint').textContent = `Loading the demo song ${$('demosong').selectedOptions[0].textContent}…`;
  try {
    const r = await fetch(`audio/demo/${k}.mp3`); if (!r.ok) throw new Error(r.status);
    await loadAudio(new File([await r.blob()], `${k}.mp3`, { type: 'audio/mpeg' }));
  } catch (e) { $('hint').textContent = `Couldn't load the demo song (${e.message}).`; }
};
// set the shape count so every hit of the selection gets about "strokes per hit" shapes
$('matchshapes').onclick = () => {
  const n = Math.max(20, hitsInSel().length * +$('perhit').value), sel = $('shapes');
  let opt = [...sel.options].find(o => +o.value === n);
  if (!opt) { [...sel.options].filter(o => o.dataset.custom).forEach(o => o.remove()); opt = new Option(`${n} (hits)`, n); opt.dataset.custom = 1; sel.add(opt, [...sel.options].find(o => +o.value > n) || null); }
  sel.value = n;
  $('hint').textContent = `Shapes set to ${n} to match the hits. ${S.mode === 'idle' ? 'Pick an image to paint.' : 'Press ⟲ restart to paint it.'}`;
};
$('musicmode').onchange = () => { $('hint').textContent = S.mode === 'idle' ? '' : 'Press ⟲ restart to paint with the new music mode.'; };
$('play').onclick = () => {
  if (S.running) {
    S.running = false; S.pausedAt = clock(); if (S.mode === 'auto') { worker.postMessage({ type: 'pause' }); helpersPost({ type: 'pause' }); } if (AU.el) AU.el.pause();
    if (S.video) S.video.pause();
  } else {
    S.running = true; S.pausedTotal += clock() - (S.pausedAt || clock()); S.pausedAt = 0;
    if (S.mode === 'auto') { worker.postMessage({ type: 'resume' }); helpersPost({ type: 'resume' }); }
    if (AU.preview) { AU.preview = false; setListen(); }
    if (AU.el && AU.resumeAt != null) { AU.el.currentTime = AU.resumeAt; AU.resumeAt = null; }
    // (a video and its soundtrack only run once the live phase has started)
    const early = S.video && !S.endless.on;
    if (AU.el && !AU.ended && !(early && AU.el === S.video)) { AU.ctx.resume(); AU.el.play(); }
    if (S.video && S.endless.on && AU.el !== S.video) S.video.play().catch(() => {});
  }
  setButtons();
};
$('restart').onclick = restart;
$('speed').oninput = showSpeed; showSpeed();
// zoom: moving the slider on a finished painting starts the endless zoom from there
$('zoom').oninput = () => { showZoom(); if (S.mode === 'auto' && S.done && zoomWanted() && !S.endless.on) { S.running = true; S.pausedAt = 0; beginEndless(); } };
$('zoomstart').oninput = showZoom; showZoom();
$('hold').oninput = () => { $('holdval').textContent = $('hold').value + ' s'; };
$('vspeed').onchange = () => { if (S.video && !S.video.srcObject) S.video.playbackRate = +$('vspeed').value; };
$('layout').onchange = e => setLayout(e.target.value);
for (const b of document.querySelectorAll('#view [data-display]')) b.onclick = () => setDisplay(b.dataset.display);
// ⛶: the stage fills the screen; where the browser refuses, the toolbars are hidden instead (Esc brings them back)
const solo = on => { document.body.classList.toggle('solo', on); fitStage(); };
// the size of the controls: the whole studio scaled (CSS zoom), so the painting gets the room the panels give up;
// auto shrinks them on a smaller window. The panels under the painting can be hidden too (H). A phone keeps its own layout
function uiScale() {
  const v = $('uiscale').value, phone = document.body.classList.contains('phone');
  const z = phone ? 1 : v === 'auto' ? Math.max(0.72, Math.min(1, innerHeight / 980, innerWidth / 1600)) : +v || 1;
  document.documentElement.style.zoom = z === 1 ? '' : String(z); document.documentElement.style.setProperty('--uiz', String(z));
  fitStage();
}
{ const v = store('cp-uiscale'); if (v && [...$('uiscale').options].some(o => o.value === v)) $('uiscale').value = v; }
$('uiscale').onchange = () => { store('cp-uiscale', $('uiscale').value); uiScale(); };
addEventListener('resize', () => { if ($('uiscale').value === 'auto') uiScale(); });
new MutationObserver(uiScale).observe(document.body, { attributes: true, attributeFilter: ['class'] });
const setDeck = hide => { document.body.classList.toggle('nodeck', hide); $('deckbtn').classList.toggle('on', hide); store('cp-deck', hide ? '1' : ''); fitStage(); };
$('deckbtn').onclick = () => setDeck(!document.body.classList.contains('nodeck'));
addEventListener('keydown', e => { if ((e.key === 'h' || e.key === 'H') && !e.metaKey && !e.ctrlKey && !e.altKey && !(e.target.closest && e.target.closest('input, select, textarea'))) setDeck(!document.body.classList.contains('nodeck')); });
if (store('cp-deck') === '1') setDeck(true);
uiScale();
// every menu's chosen text fits its box: a little less padding, then a smaller font (not under 7.5 px), when it doesn't
function fitSelects() {
  const c = fitSelects.c || (fitSelects.c = document.createElement('canvas').getContext('2d'));
  for (const el of document.querySelectorAll('select.sel')) {
    if (!el.offsetWidth) continue;
    const o = el.selectedOptions[0], t = o ? o.textContent : ''; el.classList.remove('snug'); el.style.fontSize = '';
    const cs = getComputedStyle(el), base = parseFloat(cs.fontSize), avail = el.clientWidth - parseFloat(cs.paddingLeft) - parseFloat(cs.paddingRight);
    c.font = `${cs.fontWeight} ${base}px ${cs.fontFamily}`; const w = c.measureText(t).width + t.length * (parseFloat(cs.letterSpacing) || 0);
    if (w <= avail) continue;
    el.classList.add('snug'); const cs2 = getComputedStyle(el), avail2 = el.clientWidth - parseFloat(cs2.paddingLeft) - parseFloat(cs2.paddingRight);
    if (w > avail2) el.style.fontSize = Math.max(7.5, Math.floor(base * avail2 / w * 10) / 10) + 'px';
  }
}
document.addEventListener('change', e => { if (e.target.matches && e.target.matches('select.sel')) requestAnimationFrame(fitSelects); }, true);
addEventListener('resize', () => requestAnimationFrame(fitSelects));
setInterval(fitSelects, 2000);         // (some menus change their own text: auto (1000), the songs…)
setTimeout(fitSelects, 300);
$('fullscreen').onclick = () => {
  const m = stage.closest('main');
  if (document.fullscreenElement) return document.exitFullscreen();
  if (document.body.classList.contains('solo')) return solo(false);
  const req = m.requestFullscreen ? m.requestFullscreen() : m.webkitRequestFullscreen ? (m.webkitRequestFullscreen(), null) : Promise.reject();
  if (req) req.catch(() => solo(true));
  setTimeout(() => { if (!document.fullscreenElement && !document.webkitFullscreenElement) solo(true); }, 900);
};
addEventListener('fullscreenchange', () => { if (!document.fullscreenElement) solo(false); fitStage(); });
addEventListener('keydown', e => { if (e.key === 'Escape' && document.body.classList.contains('solo')) solo(false); });
$('igguides').onchange = updateGuides;
// remember the highlight choices between sessions
{ const m = store('cp-marks'), c = store('cp-markcol'); if (m !== null) $('marks').checked = m === '1'; if (/^#[0-9a-f]{6}$/i.test(c || '')) $('markcol').value = c; }
$('marks').onchange = () => { store('cp-marks', $('marks').checked ? '1' : '0'); $('markcol').disabled = !$('marks').checked; };
$('markcol').oninput = () => store('cp-markcol', $('markcol').value);
// ── theme: two colours for the app's lights and buttons and the stage's accents (the code and rim colours stay as set) ──
function applyTheme(a, b, keep = true) {
  COL.accent = a; COL.accent2 = b; gridCv = null;
  document.body.style.setProperty('--accent', a); document.body.style.setProperty('--accent2', b);
  if (keep) store('cp-theme', a + ',' + b);
}
$('theme1').oninput = $('theme2').oninput = () => applyTheme($('theme1').value, $('theme2').value);
{ const t = (store('cp-theme') || '').split(','); if (/^#[0-9a-f]{6}$/i.test(t[0] || '') && /^#[0-9a-f]{6}$/i.test(t[1] || '')) { $('theme1').value = t[0]; $('theme2').value = t[1]; applyTheme(t[0], t[1], false); } }
$('markcol').disabled = !$('marks').checked;
$('rec').onclick = () => {
  if (S.rec) return stopRecording();
  const m = recMode();
  if (m === 'offline' && liveInput()) return startRecording(false);     // (a live input can't be rendered: it is recorded as it happens)
  return m === 'offline' ? renderOffline() : m === 'full' ? startScreenRecording() : startRecording(m === 'now');
};
const liveInput = () => !!(LIVE.stream || LIVE.view3d || AU.live || (S.video && S.video.srcObject));
$('recmode').onchange = () => { if (!S.rec) recIdle(); $('hint').textContent = { stage: '⏺ records the stage in real time.', offline: '⏺ now renders the run offline at hq, frame by frame: perfectly smooth and the finest strokes, however long it takes (live inputs are recorded live).', now: '⏺ now records the stage from the moment you press it, as it is (nothing starts over), until you press ⏹.', full: '⏺ now records the whole interface, every knob and key (the browser asks to share this tab).' }[recMode()]; };
recIdle();
// the reel: length (a song's part is trimmed to it) and loop
$('reellen').onchange = () => { applyReelLen(); const L = reelLen(); $('hint').textContent = L ? `Length ${L} s: ${audioActive() ? "the song's part is trimmed to it" : 'the painting is timed to fit'}; a recording is exactly that long. ${S.mode === 'idle' ? '' : '⟲ restart to paint it that way.'}` : 'Free length: the run takes as long as it takes.'; };
$('loop').onchange = () => { $('hint').textContent = loopOn() ? `Loop: the painting builds, holds, then ${$('loop').value === 'fade' ? 'dissolves' : 'rewinds'} back to empty — without recording it keeps looping. ${S.mode === 'idle' ? '' : '⟲ restart to see it.'}` : 'Loop off.'; };
// camera + playlist bars
const camShow = () => { $('camamtval').textContent = $('camamt').value + '%'; $('cambarsval').textContent = String(camBars()); $('cutbarsval').textContent = String(cutBars()); };
for (const id of ['camamt', 'cambars', 'cutbars']) $(id).addEventListener('input', camShow);
camShow();
// stroke sounds (on / volume; remembered)
$('sndon').onchange = () => { sndEnable($('sndon').checked); store('cp-snd', $('sndon').checked ? '1' : ''); $('hint').textContent = $('sndon').checked ? `Stroke sounds on: every stroke plays a note${AU.el && AU.key ? ` in ${NOTE_NAMES[AU.key.root]}${AU.key.minor ? ' minor' : ' major'}, the song's key` : ''} (its style is the instrument).` : 'Stroke sounds off.'; };
$('sndvol').oninput = () => { store('cp-sndvol', $('sndvol').value); $('sndvolval').textContent = $('sndvol').value + '%'; if (SND.g) SND.g.out.gain.setTargetAtTime(sndGain(), AU.ctx.currentTime, 0.05); };
{ const v = store('cp-sndvol'); if (v) $('sndvol').value = v; $('sndvolval').textContent = $('sndvol').value + '%'; if (store('cp-snd') === '1') $('sndon').checked = true; }
// (browsers only start sound after a click: a remembered "on" waits for the first one)
if ($('sndon').checked) addEventListener('pointerdown', () => { if ($('sndon').checked && !SND.on) sndEnable(true); }, { once: true });
$('sections').onchange = () => { drawTimeline(); $('hint').textContent = $('sections').checked ? 'Song sections on: drops paint denser and bolder, breaks finer and calmer, builds push in.' : 'Song sections off.'; };
// presets
for (const b of document.querySelectorAll('#presets [data-p]')) {
  const k = b.dataset.p;
  b.onclick = () => presetKey(k);
  b.oncontextmenu = e => { e.preventDefault(); if (!PRESETS[k]) return; delete PRESETS[k]; store('cp-presets', JSON.stringify(PRESETS)); if (PR.on === k) PR.on = null; $('hint').textContent = `Preset ${k} emptied.`; renderPresets(); };
}
$('psave').onclick = () => {
  if (!Object.keys(PRESETS).length) { $('hint').textContent = 'No presets to save yet: store one first (store, then a letter).'; return; }
  download(new Blob([JSON.stringify({ app: 'code-painter', presets: PRESETS }, null, 1)], { type: 'application/json' }), 'code-painter-presets.json');
  $('hint').textContent = `Saved presets ${Object.keys(PRESETS).sort().join(' ')} to code-painter-presets.json.`;
};
$('pload').onclick = () => $('pfile').click();
// reset: every setting back to its default — the stored choices are cleared and the page starts again (presets A–D and
// easy / console stay). Press twice: the first press only asks
$('preset_reset').onclick = () => {
  const b = $('preset_reset');
  if (!b.classList.contains('arm')) { b.classList.add('arm'); $('hint').textContent = 'Press reset again to put every setting back to its default (your presets A–D are kept).'; clearTimeout(b._t); b._t = setTimeout(() => b.classList.remove('arm'), 4000); return; }
  try { const keep = new Set(['cp-presets', 'cp-mode']); for (const k of Object.keys(localStorage)) if (k.startsWith('cp-') && !keep.has(k)) localStorage.removeItem(k); } catch (e) { /* storage off: the page still starts again */ }
  location.reload();
};
$('pfile').onchange = async e => {
  const f = e.target.files[0]; e.target.value = ''; if (!f) return;
  if (!/\.json$/i.test(f.name)) { const m = await readMeta(f); if (m) applyMeta(m, f.name); else $('hint').textContent = `${f.name} carries no settings: only pictures, videos, SVGs and code pages saved from Code Painter 4.25.3 on do.`; return; }
  try {
    const j = JSON.parse(await f.text()), P = j && j.presets; if (!P || typeof P !== 'object') throw new Error('not a presets file');
    const got = Object.keys(P).filter(k => /^[ABCD]$/.test(k) && P[k] && P[k].v);
    if (!got.length) throw new Error('no presets in it');
    for (const k of got) PRESETS[k] = P[k];
    store('cp-presets', JSON.stringify(PRESETS)); renderPresets();
    $('hint').textContent = `Loaded presets ${got.join(' ')} — press a letter to use one.`;
  } catch (err) { $('hint').textContent = `Couldn't load ${f.name}: ${err.message}.`; }
};
$('pstore').onclick = () => { PR.arm = !PR.arm; $('hint').textContent = PR.arm ? 'Store: press A, B, C or D to keep the current settings there.' : ''; renderPresets(); };
renderPresets();
// palette (remembered)
{ const [cols, lock] = (store('cp-palette') || '').split('|'); (cols || '').split(',').forEach((c, i) => { if (/^#[0-9a-f]{6}$/i.test(c) && PAL_IDS[i]) $(PAL_IDS[i]).value = c; }); $('pallock').checked = lock === '1'; }
$('pallock').addEventListener('change', () => { $('palpreset').value = ''; rerunSoon(); });
$('pallock').onchange = () => { sendPalette(); $('hint').textContent = $('pallock').checked ? `Palette lock on: new strokes use only these colours${S.mode === 'auto' && S.count ? ' (⟲ restart to paint the whole picture with them)' : ''}.` : 'Palette lock off.'; };
for (const id of PAL_IDS) $(id).addEventListener('input', sendPalette);
$('palgrab').onclick = grabPalette;
// text
$('textgo').onclick = () => paintText($('textin').value);
$('textin').addEventListener('keydown', e => { if (e.key === 'Enter') { e.preventDefault(); paintText($('textin').value); } if (e.key === 'Escape') $('textrow').hidden = true; });
$('textx').onclick = () => { $('textrow').hidden = true; };
// stills
$('savestills').onclick = saveStills;
$('savecover').onclick = saveCover;
$('savesheet').onclick = saveSheet;
$('savevid').onclick = () => { if (S.lastRec) download(S.lastRec.blob, S.lastRec.name); };
$('savecode').onclick = async () => {
  const animate = $('animate').checked, music = animate && $('embedmusic').checked && !!AU.file;
  const html = await autoProgram({ animate, music });
  download(new Blob([html], { type: 'text/html' }), `${safeName()}-${animate ? 'self-painting' : 'painted-in-code'}.html`);
  $('hint').textContent = `Saved ${animate ? 'self-painting ' : ''}program: ${(html.length / 1024).toFixed(1)} KB${music ? ' (song included)' : ''}.`;
};
$('savesvg').onclick = () => download(new Blob([SHP.svg(S.drawn, S.out.width, S.out.height, S.bgHex)], { type: 'image/svg+xml' }), `${safeName()}-painted.svg`);
$('savepng').onclick = async () => {
  const L = +$('bigres').value;
  if (S.mode === 'auto') flushLandings();
  $('hint').textContent = L > 1 ? `Rendering ${L >= 7680 ? '8K' : '4K'} PNG…` : 'Saving PNG…';
  try {
    const cv = L > 1 || (S.mode === 'auto' && S.endless.on) ? await renderBig(L > 1 ? L : Math.max(S.out.width, S.out.height)) : S.out;
    cv.toBlob(b => { download(b, `${safeName()}-${L > 1 ? (L >= 7680 ? '8k' : '4k') : 'code'}.png`); $('hint').textContent = `Saved ${cv.width}×${cv.height} PNG (${(b.size / 1e6).toFixed(1)} MB).`; }, 'image/png');
  } catch (e) { $('hint').textContent = 'Could not render that size: ' + e.message; }
};
addEventListener('dragover', e => { e.preventDefault(); document.body.classList.add('drag'); });
addEventListener('dragleave', e => { if (e.target === document.documentElement || !e.relatedTarget) document.body.classList.remove('drag'); });
// dropped files are recognised by type, or by extension when the app they came from didn't say (some Mac apps don't);
// an image dragged straight out of a web page arrives as a link instead of a file
const IMG_EXT = /\.(jpe?g|png|webp|gif|avif|bmp|heic|heif|tiff?|svg)$/i, AUD_EXT = /\.(mp3|m4a|aac|wav|aiff?|flac|ogg|opus)$/i, VID_EXT = /\.(mp4|m4v|mov|webm|mkv|avi)$/i;
const nameOf = f => f.name.replace(/\.[^.]+$/, '');
const isVideo = f => f.type.startsWith('video/') || (!f.type && VID_EXT.test(f.name));
const isImage = f => f.type.startsWith('image/') || (!f.type && IMG_EXT.test(f.name));
const isAudio = f => f.type.startsWith('audio/') || (!f.type && AUD_EXT.test(f.name));
// ── sources: one picture, a playlist of pictures, or a video ──
// several pictures: load them all (skipping any that can't be opened), then paint the first; the rest follow
async function startPlaylist(entries) {
  const token = ++loadToken;
  $('hint').textContent = `Opening ${entries.length} pictures…`;
  const list = [];
  for (const e of entries) { try { list.push({ el: await loadImg(e.src), name: e.name }); } catch (err) { /* skipped */ } }
  if (token !== loadToken) return;
  if (!list.length) { $('hint').textContent = "Couldn't open any of those pictures."; return; }
  return list.length === 1 ? startAuto(list[0].el, list[0].name) : startAuto(list[0].el, list[0].name, '', { list });
}
// a video: its first frame is painted, then it plays and the painter keeps repainting the live frame.
// Its own soundtrack becomes the music unless a song is already loaded (then the video runs silent, looping).
// ── loading: a video, the camera, a screen, a live feed or the 3D viewer can take a moment to get going (the
//    permission prompt, the first frame, the painters warming up). Until the first strokes land the stage shows a
//    spinner and a few changing words, so it never looks frozen. It sits over the stage: never in a recording.
const LOADING = { el: null, on: false, delay: 0, words: 0, poll: 0 };
const LOAD_FIRST = { video: 'spooling the video…', camera: 'waking the camera…', screen: 'tuning in…', live: 'listening for the feed…', '3d': 'building the 3D viewer…', picture: 'unrolling the picture…' };
const LOAD_WORDS = ['mixing the paints…', 'warming the brushes…', 'sharpening the pencils…', 'stretching the canvas…', 'finding the colours…', 'limbering up…', 'writing the first lines…', 'dipping the brush…', 'squeezing the tubes…', 'cracking the knuckles…'];
function loading(kind, after = 0) {
  clearTimeout(LOADING.delay); clearInterval(LOADING.words); clearInterval(LOADING.poll);
  LOADING.on = !!kind;
  if (!kind) { if (LOADING.el) LOADING.el.classList.remove('on'); return; }
  if (!LOADING.el) {
    const d = document.createElement('div'); d.id = 'loading'; d.setAttribute('role', 'status'); d.setAttribute('aria-live', 'polite');
    d.innerHTML = '<div class="box"><div class="sp"><i></i><b></b></div><span></span></div>';
    $('stagewrap').parentElement.appendChild(d); LOADING.el = d;
  }
  const g0 = S.gen, t0 = performance.now(), span = LOADING.el.querySelector('span');
  const words = [LOAD_FIRST[kind] || 'whirring up…', 'whirring up…', ...LOAD_WORDS.slice().sort(() => Math.random() - 0.5)];
  let i = 0; span.textContent = words[0]; span.classList.remove('out');
  LOADING.delay = setTimeout(() => LOADING.el.classList.add('on'), after);
  LOADING.words = setInterval(() => {
    i = (i + 1) % words.length; span.classList.add('out');
    setTimeout(() => { span.textContent = performance.now() - t0 > 20000 ? 'still whirring… nearly there' : words[i]; span.classList.remove('out'); }, 180);
  }, 1500);
  // gone once the new run's first strokes are on the stage (or a replay took over, or it's been far too long)
  LOADING.poll = setInterval(() => {
    if ((S.gen !== g0 && S.count > 0) || S.mode === 'replay' || performance.now() - t0 > 45000) loading(false);
  }, 150);
}
async function startVideo(file) {
  loading('video');
  const v = document.createElement('video'); v.playsInline = true; v.preload = 'auto'; v.src = URL.createObjectURL(file);
  $('hint').textContent = `Opening ${file.name}…`;
  try { await new Promise((ok, bad) => { v.onloadeddata = ok; v.onerror = () => bad(new Error("this browser can't play it")); }); }
  catch (err) { loading(false); $('hint').textContent = `Couldn't open ${file.name} (${err.message}). Try an MP4 (H.264) or a WebM.`; return; }
  v.muted = true; S.vfile = file; S.vsound = 'off'; vsoundShow();       // (its sound is not the music unless asked: see video sound)
  v.loop = false;       // (videos go round their chosen part: videoTick)
  return startAuto(v, nameOf(file), file.name, { video: v });
}
// ── live inputs: camera, a screen / window / tab (a music visualiser, say — with its sound), microphone, 3D ──
const LIVE = { stream: null, mic: null, view3d: null };
const MODEL_EXT = /\.(glb|gltf|obj|stl|ply)$/i;
async function startStream(stream, name) {
  const v = document.createElement('video'); v.muted = true; v.playsInline = true; v.srcObject = stream;
  await v.play().catch(() => {});
  await new Promise(r => { if (v.videoWidth) r(); else { v.onloadedmetadata = r; setTimeout(r, 3000); } });
  const vt = stream.getVideoTracks()[0]; if (vt) vt.addEventListener('ended', () => stopLive());
  return startAuto(v, name, '', { video: v });
}
async function startLive(kind, name) {
  try {
    if (kind === 'camera') {
      loading('camera'); stopLive(); const st = await navigator.mediaDevices.getUserMedia({ video: { width: { ideal: 1280 }, height: { ideal: 720 } }, audio: false });
      LIVE.stream = st; await startStream(st, 'camera');
    } else if (kind === 'screen') {
      loading('screen'); stopLive(); const st = await navigator.mediaDevices.getDisplayMedia({ video: { frameRate: 30 }, audio: true });
      LIVE.stream = st; if (st.getAudioTracks().length) setLiveAudio(st, 'screen sound');
      await startStream(st, 'screen');
    } else if (kind === 'mic') {
      const st = await navigator.mediaDevices.getUserMedia({ audio: { echoCancellation: false, noiseSuppression: false, autoGainControl: false } });
      LIVE.mic = st; setLiveAudio(st, 'microphone'); $('hint').textContent = 'Listening to the microphone: its beats drive the painting.';
    } else if (kind === '3d') $('file3d').click();
    else if (kind === '3ddemo') await open3D(null);
    else if (kind === 'stop') { loading(false); stopLive(true); $('hint').textContent = 'Live input stopped.'; }
    else if (kind === 'bridge') {                    // Syphon / Spout: ask the bridge what it sees
      IN.want = true; IN.id = null;
      if (BR.ws && BR.via) bridgeSend({ sources: 1 }); else { BR.tried = false; bridgeConnect(); }
      $('hint').textContent = 'Looking for Syphon / Spout sources…';
    } else if (kind.startsWith('__in:')) {           // one of its sources
      loading('live'); stopLive(); IN.want = true; IN.id = kind.slice(5); IN.n = 0;
      IN.name = name || ($('livein').querySelector(`option[value="${CSS.escape(kind)}"]`) || {}).textContent?.replace(/^↳ /, '') || 'Syphon / Spout';
      if (BR.ws && BR.via) bridgeSend({ in: IN.id }); else { BR.tried = false; bridgeConnect(); }
      $('hint').textContent = `Waiting for ${IN.name}…`;
    }
  } catch (e) { loading(false); $('hint').textContent = e.name === 'NotAllowedError' ? 'Permission was not given (or the picker was cancelled).' : `Couldn't start that input (${e.message}).`; }
}
// a 3D object: a small viewer (three.js) whose picture the painter paints live; drag on the stage to turn it
async function open3D(file) {
  $('hint').textContent = 'Opening the 3D viewer…'; loading('3d');
  try {
    if (location.protocol === 'file:') throw new Error('the 3D input needs the page opened from a web address (a host, or a local server), not from the disk');
    const V = await import('./viewer3d.js?v=4.26.3');
    stopLive();
    LIVE.view3d = await V.open(file, stage);
  } catch (e) { loading(false); $('hint').textContent = `Couldn't open that 3D file (${e.message}).`; return; }
  await startAuto(LIVE.view3d.video, LIVE.view3d.name, '', { video: LIVE.view3d.video });
  $('hint').textContent = 'Drag on the picture to turn the object, scroll / pinch to zoom (it turns slowly by itself when left alone).';
}
// stop whatever is live; `all` also stops the microphone and freezes the painting
function stopLive(all) {
  if (LIVE.stream) { LIVE.stream.getTracks().forEach(t => t.stop()); LIVE.stream = null; }
  if (LIVE.bridge || IN.want) { LIVE.bridge = false; inStop(); }
  if (LIVE.view3d) { LIVE.view3d.dispose(); LIVE.view3d = null; }
  if (all && LIVE.mic) { LIVE.mic.getTracks().forEach(t => t.stop()); LIVE.mic = null; }
  if (AU.live && (all || AU.live.label === 'screen sound')) releaseLiveAudio();
  if (all && S.video && S.video.srcObject) { S.running = false; S.pausedAt = clock(); setButtons(); }
}
async function openFiles(files, asInput) {
  menusClear();
  // a file made here (PNG, MP4, SVG, code page) carries its settings: dropping it brings them back instead of painting it
  // (hold Alt / Option while dropping to paint it instead)
  if (!asInput && files.length === 1 && /\.(png|mp4|m4v|svg|html?)$/i.test(files[0].name)) { const m = await readMeta(files[0]); if (m) return applyMeta(m, files[0].name); }
  const model = files.find(f => MODEL_EXT.test(f.name)); if (model) return open3D(model);
  stopLive();
  const vid = files.find(isVideo), au = files.find(isAudio);
  const ims = files.filter(isImage).sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  if (au) await loadAudio(au);
  if (vid) return startVideo(vid);
  if (ims.length > 1) return startPlaylist(ims.map(f => ({ src: URL.createObjectURL(f), name: nameOf(f) })));
  if (ims.length) return startAuto(URL.createObjectURL(ims[0]), nameOf(ims[0]), ims[0].name);
  if (!au && files.length) $('hint').textContent = `That doesn't look like a picture, a video or a song: ${files[0].name}`;
}
addEventListener('drop', e => {
  e.preventDefault(); document.body.classList.remove('drag');
  const files = [...e.dataTransfer.files];
  if (files.length) return openFiles(files, e.altKey);
  const url = (e.dataTransfer.getData('text/uri-list') || e.dataTransfer.getData('text/plain') || '').split('\n').find(l => /^https?:/.test(l.trim()));
  if (url) startAuto(url.trim(), decodeURIComponent(url.trim().split('/').pop().split('?')[0]).replace(/\.[^.]+$/, '') || 'image');
});
setButtons();
// the public page opens painting its first demo (the JAS.BLACK picture), so a visitor sees what it does straight away;
// anything they open or pick replaces it. ?nodemo opens it empty.
if (PUBLIC && window.CP_DEMO_JAS && !new URLSearchParams(location.search).has('nodemo'))
  setTimeout(() => { if (S.mode === 'idle') startAuto(demoPicture('jas'), 'demo · JAS.BLACK'); }, 900);
// ═════════════════════════════════════════════════════════════
//  easy: the first five minutes. Four steps down the left — source, look, motion, export — with six ready-made looks
//  (styles, outlines, palette and motion together), a demo to try, and the full console one click away. Every button
//  here drives the console's own controls, so the two never disagree.
// ═════════════════════════════════════════════════════════════
// (each look's thumbnail: the demo picture painted in it, made by the studio itself)
const LOOK_THUMBS = {"pencil": "data:image/webp;base64,UklGRngoAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggiiYAANB5AJ0BKrQAtAA+iTaSSCUjIaE0PV0goBEJbAC+e+jsB6OofeVfA7m/wfj3+7+Aj/nerb/M+oZ/evS/6NPM35yPo8/x/qAf3j0wf/N7L3+N/7nsP/t361Xq5/4f/09QB///bi1FFiz559c/w/756KmJPs51Gu+/Pr/W9+f7R/QegX7g3Z8AP2D80P8jzR+0/sA+VX/i8NH8P/0vYH/T/pD54X2f/h+wP5eXsS/eX//+7Z+2qOBM9dKz1z+yZrtUjxbEPGYqgbPB9dvhiH4WR7q3uUYnvnMyzhfwIfjQ9lDOrcazZvvpzlge+PVGa7wVNGGWr2jC46qpVl+YajanzOou5kVodvLLK1MMqGjiOoaDI0dnFrmGYEhqBY24hL5mTWelJZF8QDsLBJScXg7SVwZANtltG/Izk1k3Fs/zcouachWoesHoM1R34H+u5uRj1p3bzkcVLDlteKJ7dVrtr0NuS2787ElN0Rvxx5+wRR0/He/jX5AfzAYe+LojLqEcCiOGCBfEV2HprjaD2AbxU5UlRg99jiklFd3VhlsHf6BTruiVXNTk1qgy+2/pRaEtv9yop1Taw1yCP5Xc42mJLlxoZoVH5mbX22+oGqgGo5i+oIa+KEuZ/5on1eZUZy9TSGCDJd29jx4FWpVTVncp4WOxWNIb7vaaphr6FGkCmksheO6l/0lLwlas0xEaSXOz2j8bQgZzTEUWNL4i8uK83jpIGg/YodfhCP4AcfPVvb6PdFMzZLQN1m6Sctm0mNeCaB9ajx0tjHujHuH+sC+2jDZl2T7SEZH3mINfKeMTDhk6YskgkY4K+S8rssPW7tPLP4mm7BsMF0AUA0WYgz5XP5a7l/S53T6UljALLFvD1lZc/VsCsN6byeuS5wR0brearoMz6ctUoLXm1yEVqO7ucx3GDvwDPZqbgXLsrhpFTfqy0IOhcvLynfsgouMrZSHqpxrQ7VLnR8/LOcjXu7jljJPsmDzYRSdNV0d9KAoNAhhyT5Dy8EJxih6C16WOAiewYMf5eJ53OEvVatT7vcF4shH50MNk9ATrDC+pl4aGaDYv7xKdHa7kFYp9bBm1y8nnK0rtk7TqkkrVYJgNchlnS65F9dhKlnFJbzeN8ETIYilXss+cNp56VQDFtgdx4YkqU2vr/yRkSQCc38u+UGMWj4QbztYd5dagCWs7Hgt32TVDrVxlbKQ99RVIVDJ+DLpyAlFJbCJiYxnwlxGigKgcLxbmWyEvlHUlM2wtxJm1qQfiyu9b++ljfzrMLcef2vzWkelz/0Ac6v+AOVyr2VSJTCwyToBnNZ8wAP7ovM0x1bhIRxN5HjF+ig+3HlAaDQHSxNdmLbYIrcRM4gcreb6tPOtAFKooA3pYeTf4qye//42Q8/vWCvvR8DftwkxNqi5yaV3TGlgQSVBzGSqVmk0ZK6PfvRXHlYsXybRcCu9FHrO0fhC+7X0N24soabBOUArzu6IjIT6XrJXvU6msNtwoZ7ZJNszxEZCp5+NuIGcKtB4Yc1k19hZkqXwWs/OZovzTR1AC3lrQR/wcbgzwXoB/nZ/esviOEFM7LadYpbwsmrOuJXjtfEW1iEKTKPFe1oWSppIbgVSL/4dwKWh0hNoTvKPHaGcZt+clZ5CHeI4FbdDsanYiGmjkjuqrUmhrxnpWBuAcDCuwp90g7eUJtbHSiJ3Wi1ULSaPZmQtnVmVugFqqRLZE2mdgsiZnxeGX7w8+zxSlfTPPRJHMZprAct9oI3tkO1ChcvTmzpubJoP6ACK0+MlWWFaiEqam+xyLwTEAIeoA/7E2D8I1QfkBO+Z8ik5FPaNdVXzilWYt9zVCEWSmbUh+3aGwoubA801ZXi+xMHgUjLlUTUR5M3TKqL78ARYzDVVCtY5u95xU/p2KRUWMVsXXFj6W0I5hYrFznGOmBDFY4KZn7h1rIKdPZD/iV7oy2h2yQg5vkqV9P+B2+OozK1rjFVw5D+s3E7uJnYq7LBtq5rVBALecyRCOcD8Koa5kRFgJrfvyD4Ysc/oaSTbK+RwLaId3hezlHulF7d293LdNdFMctCytJ5fuUM/SXsIOueyydjEwxhFN16q3YL5Zc/gDbj2DpUjrodVaaV9yYa7kv5Ro5+Pcs0cQJJI/3AZ27dkJaisDfgwfMg0NDpNeW9h8cT/fZz3nVqY+txtVZNWHW9ILXUbawIhQybmwIrtFscnswM2gfNb7SONqNMEpUyHLANbjMDdw3r6wePPWJLhkIurxKthO8mzEKkx5qmKk5uIvkT6r+h3KBqFCG18v1xJiNfUlDejIVaKH2IQ/1cneA8iDVNzl9trZyYn+FF35mrP96qRFtukqeOGFBU3oebdK7gBi6r/5hmP4v9JX8G4zyvpHYiCveJBOHWLsyUgYF2ClXCMXfvEgS94OmW7U9BZKHCzz4M7xeeCv6N9suIQ5NCxReCciL0XVPVj+UpTXuXGaiHpgut9RTWyvlKYq/3FebgmiJ2a//iAz9Uf9LqdHHfkhzS55G3UeC3jLiLYQmZgoyezUx03fk+OrMl6Q3v3u0aYgLF8/IeOt2ExZRRCUY6NkI/ZUHNuL5eRLAzHZ2OQTIjTb+EKAZpsSgCRWj4QwYAL5SPHswh3sLZfcDzsFTOVNVM9KVYKJaOvwkiTTClLWvU/Zy3mwJSGD9cHws1NX+JmvT4jRBA1OT1EGjFcpd+KbdKTHN9uXR6fMiIGqJnPE4VR0sMgMxoVJgoPXvwyj3ct8B9Y/p6ty7WOmiUhWInE1GLTfKzOhKJEmsv/EVJJWm1Vy3W1cdTst9SiIBNlQLmmKHiTOUhhuB8kAslq+ABfJ2OlQo22ltchIWmCo6e1w2iUdvURMm4RBMquVaF7zZ1iOsEOgYMFNtt44b9d10cPheLOuVtQaUlxVekjT09oHd6eCjCRW6hBBw49TL6pGM5roEFUjrIWWRyZ5PGWk3ODUFRDKvTZbM9ByL4ge9pvxBFokoWpE58WEfQzxwe00q3uaJuYrP97x9oWOv4RgpILnVPkWm3PzAEilS225eI43Ah4flkljI1gBhQk6dB32GXMCbXISFUSpZakwjycGHEIaqHmuYeOuEesq3BInGz3PWlPaN7zaM5WLv56K8HaArBvV4xlsJtNyZOAFD9bSZ5cyXSNxiVvYu+LJP+YkTtpP/hObykc+HLS80wBCWnocfRbcTQjkQGeRwhNPFhlBHak/QKieoTGHKQRfdoaEg909L+N293sr4xVuTl8MCyQF2i6LcEPiIFuBWiN+v5e++yY7zT3uymaiIP5gCgusbriEHtdq1YXnMpLRnFdoCZ4OW576akC4Kqln0g1cmLeuvXL0PdN2sc1unp6NKp7yUkEgzB10r0jrYXLYM6SAIQGg3dZjgDnooTZwC5BNaQj8Tudk9y9e1CgIZ2i5URHXrZhb4LVHdrWfJoKgPnvVGFkOYvMgZR0j49vRtQeZUD7cluWNnXNqwt8yTr1rIUy9Zlm4jyR5UOyCsbNC0ppmmVrhTsj/Q5yosKcMeVis4PMtcI+s/k3wNms+xD3atgapuFwOvjZapkm1AjBthLtil+h4qcl4FUQLQ/ADg5g/GwdTJw5VXkIiytfElQNvOMCBOzJrJCZBdRWxG0Z7Pnfl+QeTY1BZc08x/GhOqhthJ4QmXDMQ9maU1DDExeSNr2TMKbaI+4COdOZEt31Lau6s4HOnGPCwRSmAAfprlqmG3UgJuzMPxY24CAl3plUwWpsKryRX+kts19B0P3EGf+DoS5JcFDCj4DM8TPCs+0E8JdELpL43X6mZlNixmwO5b+QKDAIWd156fFBN3a1uiuNdPgQA4KHejRKHLKEetyvV13Y5cIut22bdVX8M/h7ULReezJXBtIQ2761PRUQGJqUBa7VmTZpXNVIx3swMZlYKa683du+qhMpDaLpKOz6pHcQJFbrOzRPzuGEf1BihV4psTue7XIqn1gg9vZf+VKoP02XgPnxXJfvpYJ1bdNsQjW8uQ76jwdDtmTA26K23ZZ4+aGyPYEsGWIj5RJHYWRVYu+h8ysYOeT71+vk/Jl7Eot2LpevMO+CzCjIKALLCwDgGHWMILcdVr2JZqwTrmnJCsl+ntVonlt9oxOWH/mwcb4t2vdi+dpCndkb4bCEYGKKovS5TmEqQGhNIZl4KcCkxDs03AmvykeggZ3CU/t+oNGl0jh6HzEXww658ULGd3aZL1OWdN9BXaiE17UYLMuTFBe+2HdJjL285X2AZE6Nmft1F9qxGdYFJGXpNyamJMPDvr458DHC2bAwiITWNu9Tt8e/F9+Oejdog5TvIbGEeY+1YHRlCrLWeB+VOq8ut2Zc4kh4ugKKzd7ybaaH6lHekFsT722jXwfVlUK4kZCOg2HBj9Qi1ZjvP+pcfa5j3Y5OmZYkoEHIFi+G6VIs8p4Xg9z0e1DpYIUrSlhOdqe9JEUSnWXChCOsJ3qp+eIoqdntU0LI4J9Z2QD+RsfhTf53vpsxYicFzxdS5mPjOgucHQNvoGL64QArx+OfKWULvK99XYACen4PPkxtjlI90tmmEGh8cs9WkE9ZDGeIMtQnUgiglI06ItEFu1wr3SqwXFVJ8KyALG2PR2CYl9LTcXAX5WLOlQ5Ux3ftX32ZsL7OwYs/uax3XvHcog0mj3AguFFE7ncg8vns7lM29Dh9ZK6JhJx71kZOZlsSk3JRvd6VoPvXjGEfRB1kaXnuDWZhC91XvxMSbsGUzBogCLfozhPhH1aWwHAmUqba7CBcN6jkQm5bVC9uyt0hcIckGKw8J1fVnLF1w/Fkq6daridIt4pnrGAHjY9kzM+hKfWin0qdDsvaSdsiqLgr6MZhA5JHleAP1A0xLbXGH9s0kvBZIXkqmnnf1njzemf3l15ctv5UgKh3RHt3x3fJGi3ZWPPkolRHqxk2lgnua7AYxAoNWTK9wwcQSkUcMG/vs1bLc9uxPIXlYGGUOXE55qSdqlCm8TITGTs1tSFZN1CWKD66cVrttphn3LmKRayNtIe39fR9IdH9I0t4Vr2sVnbY+rYF3UqHjhjLzVmiYY5oTNLExK1bMO0KEIb8DWh/w9ZilDG17mrnCQSxlEKt/8mbWbo0ewCxo8k9KnrR+GYc+tIy93DFsVrujqjsaG1hffDzWRFbfcmo1JHFwy7fxGW8JUJt0McVL01ts5kwFoCR0eiQjsJRxXSaEaMwqCRdWOi5uuSdtj5Itt7VfHdoAt05a9+oQqNHIBWAYK70utJt96LlA3iydeTZ00h+5rJLhXxbAzLeyOvzi/7gKOzjbQNyWa0XHRCWiAo9CWnvUQPJX3uLwTwbp3mRUu2tKEmeQWYm34kbNN/7pSZc1kO/0JKxdjBuN5qYZRkktKBuwqE3qxmUHWkF93JnsWArFAlYlQJHByNc1SCRaoSpL40Gb3Nh20LW0+6e7Sp2bYdxUIfU8BMR54suIiaRIO/9ELiXY4n4getWCahQeDe3HKG80TRZP6yRaBwt0NLTeEZWbGhhQZpenTGvqPvwy6ET98zm2wAmtbsUU7L/9j5J2ov4GdsEQjeDqAhQrdOBCPLlfQ15bXuAsi6SLYaLCAMo+WutKrehscotfLVJIbr3GVt1pTifA376/1DIjaXQUT/M0gy2zeHdfQ8xZYwLWxlJviehpI+U6z84WlS6ICwYO70TNQYftsq0fQK0EfvuLPsF8Qj+PJuhKz7UTHiZf+EyBQcUxNqERF5t0i1Nz6bQVWB1/3JaGJd06AEwjN8KXEfHnBM1BWVNlfI+pLCm7lBuMYi73+ExX8iGTdqMLpZHXTIh3QbA2H85IWBw9xZx8uEE4wYfJR0+W0nUWbnla2Mp/UgpxQRDYlJTIn3ZEs9yYUan+RjGtUEaI2QctCzaaGgNqj1MxIRmkRWLoZVMQyAWA0M7eIkIVeqNFHJ+Q0qmdLqaLP/dFQXxHbM4z5zPM4qGpujcBbsFDmrFoGhYsFE48XWTgfcm6mLdllvY7DmYCfUewObcNmte+15xit66VPqNVQbPwW24cG+iRy5Sih4F7RFO2mFq/EwsEykG7xxxK8N/LD4APmiFn4yI5aVpj18LdlIwKJLkhzHfXLVOdX1GCt4hmcNn+XNPFcDrDfWq4u+Ym0/3XsGsazBftq5gxkPCbYwSVtGhLwR6X0OLqoOhkjDbK6lOhE4wtDWArFBmNBDRuvU6YjZp0qmKgOi9XORGZstHRuyEjugeOjOeuEMkxwBOet3bbhb8XX+tyRNT91FE4dWmh5BB5le43ySQKuJoh5qfhfm0O0Okv1maDwqd2nEI+iIFFbpG8AvS1orHquPcNTv2r7GUhe7BIz6hQIjRbkLlzNoMAS6OZQp9Rn1CjeOSRRBAk71OBwFnU0SiZk2Kbji944hq/YQKva8RoOnafBuV0rU90SUDQ7wvPrIMSyRvlgQRnbcdqzO9XSKyReKadQhCwkeBXnAfnCqRWGJg/UYmq11ugwuuqtqykWBBoe/OHG8S5K0IWTnRUgz7TfV1hg51gDgoZ2g4E+vxzln3GNvnn8/wHb4gcI2pRIT3I+ELgDkDhvptoH7bVR109wHJZmlwkpQWHsZtBpEXcE6IX3kgvr4XTcx+BtI2Qlf5HCPe0zip5Lr4fnXBIfbXq5cWk8e1Qt+eCvhFbEkLICylu8+Bc4aW/PXzvzIzF6DsUeMxnE6kYLewYjrN26SmAR9tFQ4cVgrGuhEX810+2yQLbIDpefszJk9BvOl1AQMkQuKx1ebJOzjW7PbWKIovlCkXChi79GF4r2cfcYK0srZgbbmgT1SSKvD+Nviq5qwG5X5C6Veh5hwPas0xN3Hud2PeSQTkQKniZmL+0cKzCZ4RTT/AR5etNFdbgVW4mWfqNyLXI7uHbKQcTqzyrUhRVQgael69ApoWqibroVY6mU/N5lwAvqfFXGlJdxQed/AE9T0HUswVQGlTWrTGW/1RlYq3FIjVQQLtHKydd/5m4HdxPvHCHpIOiNz1VQvLkBIZ+1rPe+E1feietSj7PYmmVOUAtd+LqZvLVrV4sZuq6QAaH+5gyyoiXnpx+icDjKFd3AHJm/7uvLd6Xsbsdyq1YfJOT8uUgEJou4B+9Dbn2D3Apdwjr+QzZy1nBsHH9DnZ690NSQhK35zcVWqbpWLXNQqZtyr44n8UvaNKtXCuuJcNVvQmHtIxUQSFaxbZ/NDZKLCLNkoH2dZR/xGNzsPWO9wjM+na/Zzd/ulX7Ojiapy2dc1xZJWcRipzlKQLfBqCT8ryRFdTr8CYSgqgsVQcM/uluvEf96GYALomsiADpzbq+ZL8hKVOgTqhU55JWB3KQQOB9isZx+GXaJT+vLn1Kmqgi7ZcPMISZACG9OPQhlLKKBcU5TrPvtEkzPbGuCmR7hnMpkVC1S7YtaVsZvCR/+ESSo5PlQZdvNiT7txdqdpOxfMAzMa9/LV77ayyoCIeoDM/QYcNN3EZk8kC28hrwWQcpQwPximqXJGCjSHvTEgcvxBfY23VElU1BY3r2cZITRSe42IVT6eGMKYqLVNWgKgBkb5MeqagzNLzBNnB2+xUdUOmPduN3DoPVlB9+dkkqiOJdZUQwc2BpIfgblu2wuGr+XOC1EXpZAG3C+/0weiH+Sghx6JPdieZ2Pj0HUS+/Gg+IMERR5DBmpPhfQQEYfyOieQhL9TMaPtpR2nvfatvkp3xt+1MRSfTplFctrXJAVtyYYtDibhIovVQh/eGMQ01J0WsZJFiJmGcQzbxiBYgl4UkKoNPJ6YZytstJQjasZxFJT7UC1sfKUX82XxBejK7UtQRgyq1Ol6v+OyqaOBW4Tct7RpsP5cfx8UcA2mAWCllotakS3Lg3heeHo5BwSm5f7dbK+fKW1liXS00Ks7lB3YJxwipq+i1y78YaUyOCQCn5CpfOJthoG0yBzwo98RhdRIsZmCL+lRyaHDp3QumdZmHPEqMKtm2MxQYZ4erpd6CLFDZpyP8aRuNDS337oHoicECT3e8PQB75eNZFP6MYWq3Mo4iWWnvEzOgnGkNj6FQDyJkDx3/SiO/mjHpBZwDfhUCJHqfI3Q187/K7v5rRwCedGFcmVYd0jDWdcbQ3dYKNNUjBbKX/tsnkfxu3CQKnJZDPKulQvnth1g6r66IMhHzX6a/SKeUFWKiDokQGkvVB9FEDC4lsxN/99Qws3DF/Poqe1Lun9eOxlfbTXK6/E9In05PZC71I6sR5jOeO/QXL3Z3aTKrs3uiOGTnQ174HsABgcGf0rAGxApIgK1D5yHp/hJ1KNKqlxoRf0K0EFD8z7KXk1cCLHzqPIA0mgO0kO063qyDRl2dFtPseeqBZJVtH1y75/3gUqZzFaNPCoTqA63UKHg1iCqu3IpRUMRTpP7XoMVmLXkHCFRZQ+ShjGkifZjONLbFLz23gA8mQoLn5kr00K+CfQPYlw/Zdw4u1cl1bAtBvywsOld4/K0s348YuE70SWBapJOmtZ8bSpRWMqJWKr8jMUOLSMSvTmdW82kkQIMZq1isS4RCEYLHR1p3iL5AIfeXGSNcaxIPPhKSJrXDifCvGoVblDh1mI35WyOiB0VQkQwPCdDdRu5FgbslFK1hcXBK7IxOfBZfAHCFGnk0Wb0P/Gj0TaqS/NXOc8+b3Nmp6WzYqhf3L8GA3NXPO4Nkk+jopYkBc2G2cSLqxMf1OX7znSzhpDSPhOklbwr5Kvw/rUL1X2erB2wCtLBoDtQplGZ0x0kO3RENK9Dtrjfs5DUMAATX/K0y4fhlGQNwchASAP9pQSx0oHcfZHsPW7ncNvC+aumcD5hLQrDE+6XiXvZRP+IKONmjnUV36tzzwfhmVTlW3IE0ey4iueQc/7d3Ibt+3qMgst0TtJce8ShxA/zgOGqOagtHVrDmSYl9d7LORjbr5SDkg4dr1GHym4bFXqo40T6SWhmqxAAhIvSft7Q0rpLHKeeGyfB7CQy6yHACLejkv0CyveL6Xcr0ZL4/0UdjBW4AaGRmmgQSv8d7Q3ta6ZrLWqZKuWUyng16vbSJJ0aFpt95ljBb+pAUI5r7ACpIcj798SZZsruNuwRi6aPCDkq/GpXX3ILQHH3vPJJiGL7dV7hFNkdp2pn4iUjWZzSrVqizmlfKOkMcJxlwUnbuzvMNZ9PBjKOnqxTZFoYXRxL0OLEWOoLZZsZJvPhA8UBJAO6caxNSOe4Rt7IA3sENI0SdSpm5VBHJrlsjZ9LcxrYk1VAS1mKcs30MI0ArzajGFJSAdvrvn/G9FMMn/gBb2z0Isr1KmkfCz4Xg4ZCaoVmMF5TvL1nKBdIROAhZyy9V9xqM/fBx65R5P00Ehw3J4SjjPaUIeS37Z4V9AomD9K/42mSxCdenzgf14VTMWMlS0VHP87iZ5+60RgejhxyhiYGbQ4OJRaldzVlyrio9sMsOHEcsUzoeFq1sJEJ5AOTb71760RpgZL5rrcMCunDNwiiwmBPdYQ5qvgQAgdH6f7E1UVxAotnd1Xgas1NnKbo18wl85To/2zldCbDFpuoAj2G47zPReK/UHX/2jr8nLPDwqH+gizddlJLoJuhzAIwARN0v5o3Wiftd1XRESwFWhg3m6mtiGXcZ2aC207QwabNqdxK72S1iSv+fxlzGQotV6C4H8mYz7h2ykjqmepK2n+o5t3nskRTkh/RDTHoAG0+tL1Z2vsf+toXbpyionj/KE9/TnUpDibyfA99YJzVrdV6LH8XQQsH07pz9MrZu0/W4gMDQGuGgkNGM23M5nXf4MJfG0K6Q8aVr16uR1kZz/1ab/6Jb0xqVjaI2GF/YOUqAXMdsnIlDn6QcqgCZgqrqX55kd2fctUsL50SxRZ4QnvmelvVY9VhRJMdLzs9Xp2SHRT/GmNYSNsuV6rHGuNMDDG9SKmrTSwWDr6HBVQeQKenB5ZtfCFF53JuB98KVSDbSp1OiV7NFIjlebdVqfJgD6dImtT0g5LqtlabiJSClAJg26QqEYksQgELWmLpJe1wyhDjJiJFRk+EvIjqyXTqaul/eb9k+DcjFXey3Ak4IaDiJsPXHRHJv57wT/o8ngQWFhFNjRP1DndFkaYQCTuTYJmKH11oic3aZ3eZ93JaTfCU41M9NEkepVQLn+f3TOYgITPSHru9L2hTu5ubOfEnYj8dQsnK2730GkaQpT8rVQvSV/mTkt0J0he4+TfUzaSY2F46UpXrveFUWj9Ob/l5uQO/Fig2C/d+7zTvzgS4rnWFOztlU66VFSxmSzzi82g9hvuBd8gmam4lHEJ53qHrAng7EhIailCdJN0bg+EH5vMcLOOFTjixm4jGjv8i1l16SdWuIxG+lcktFeH/qqHspw6btD+AvRbZftyafzZ5+JDgJWC3AeP460uJU8glJ9c4Qguxv5HIvqk9IO86YQ9FBlG/7Nmzs0/4WFL8o6gciZ9GDv9N/w/Thc9wFhPzDXnjF4X+iCk/o1ad7YJ1D1adVOg/VAm/X1Q8fDgwBLEESNT6g4vVKfJCTObAkmcNhbT6t++/z7iPbgho0BVAS+QwLwuFXIBJ3baDJysWOG0YKezb3368kcVPfGCwZXHWJgY8njTYCSprCC5Z/CFZmyxTizLPr2x0fB/yt9ypc3RlROdsAYTO6DHSLFEGxn8BbXuys2usqaMDrVfDAUj7BSkMrvMqwXZoVYlCcUIpjC3E/WPW325zbj5H6DM5jesMqCqlvn1RKVOfLRd/EXaJtHX/JTmORoJVhWuvbERfSzC6bZ1LuynAg1Kc1YDFxzKh1lJ2UhYZGVC7hJhHLJgEgX6BMPITGhupZksjgWjWGLiCWrZWcjwZTnNzaS5fwZ+icHE/SFQRDeLpZMhHptsqonbled9Bqsh54UFMqw4ILCkXf+0dCdXd4y4+YDwwyit2nldWJ7g4jMfmtI86xvwInNBIkOp3IQ9nuZuHfAD1LuROmC4JTYTttnq740TnboflhaJBB3KRmtRsfKxUZok9LXUq8Kcd5etl7gLkxCPqeepKq143ZjEpTyy5HMn3qXDgTFLGNlf9mOmLiwZFSS6gh9TZvLf9FuAAzplP+ugNFmUo8FxP7NXo0LArC1etoOVG//SgW9oEQDQRjetxfGUy1B+QEEQmWw91EaV33+m5QSDSZD5HuNrIoetk5RBu9Xrieka1nh0cknZTdTQ8z6OmM0SR9e8m4yiVimU36RxDxZTEGf9pjRhub/VvCsVr3jFu/4q0D08kFfcg/dwX6rXegt/ZTNVoAVAJiyjqGBJ4xV574ZjIZIWrv0ap0eT8Vx5VkJ6neYskV4vFPAXMmWYBHpX4rNDo4FyXYs76puILII5GG25+jGyj9eJwEQxzfAbhwu87hnF+48UHZt4fR/ATSj5Rz5AfeGKYe2e6wy/4giet12vlr2KJCkjk4xuXcN/CIQwR9y88bll603Bd74NYngPjzY1MhXQ7wUNVk40+WbDkAl49IdWs9Blt3BBzhUXwNnJFWfHIf5bLy5QwVehXN/3/kwpgJbq2aQY/3umR8erYvC/NbEeWAd8foQv8SZxbqL//aGu6WzPFenytAVCAr+VKqywD9PJ/Va/DdBjrDdGVehh8YL2iScDF1D4GST3zZPIzHbD7KM5McXXNa4VidDt0IVhj0yRxfEFtgFQHMv4K+YVBs+6Fv4PRhAK2HYqmCUV6OaumQ95Z2CVUOSqXCySqrpV/wHgXwkj9I0AGMndwqQdQV4o46Z2qmfK5uQww8cZy5iGK39AwjCDBtYJgdbm7FG9QWPgCl2ZlBV6UbiJv93yYg74wwPZLYl8FS5wvQlkpAX7sjJz21HYGw9vgSG7w6aKZnkyMeTqFx1esaGmwwc+3X6Pvu+rxM8gTgAeIB2rtuJDvQ+/ZEYZk6qwq1QMPVtuY+BSSTKtC/w+L7LkHVarauks4ED6THl2grjIEr9Qzn4ouQzBE9qcyu4jhgrL3DfXfm4VKenU/azOqyP2SRetahLu5VoSWzoHNWtaQCsx9xaoBzWDqUG2t+mBNZ5AIoyEJ1cfM2TB0+vEmV1ZGw4odBl0KlLiWS/LScEBseC72r66t98V4geKgMWA9FelUQOCfHX35CjO5OaGH3cWIupTmUNSn1RrfLV6wojws9vUC46yrZjTr8l12ELkl1wa5+WJSIzTxa2XOpOehPYv//M+XBeEJwt2OFUn4LXE9BNRfyNtlmdn/soNU45AswzejkHbsTqEBklRwchnX+QZJCrlTT9rsCrz71IIQ/3wafsYyLIi1SiELWf1Z1CnqfezCjFjWNit2YcWJzQt36nPw6c35/wzi1QCjwTCqbDFzA7/VgjqiIIMPWpaGPmGY6Jr0bpmiWzHwF0ddjfJ0+14xVB+Xm7iBhnocWgKtSKGKfTyUCxWqHh7wZT7jTOdiTyb69tMt3mctLocsKgKGq9oonhlTFzxJOF2NwM5gACKytsHpSRbcheO1d6J737Y4d+q7UVADHklnLQ5LbqW56emGqey0pKFxsoUzM1KI9P3ZCJD2PLJimMv6Nw8xmQ2BG89wjxOV++NP8vFXl733w25VCekS5rJ5OJLZL/eGVtmmJg4+tvVfljgZT4enXvKPuEWt3KiH0T/Dsts+8ONMgsjxGPpfRE8dfBFldZcq32OzDWAFYTPR22B4h/zpiO/1Ywxwph5LVuzr6hWp+D1UoujVuan8v2tsR86UwC5dQOOYfmfgxuOUzvvWXZ51rPeHsaOg+474mgZghPCfsX4enfhhrzdgkGhQCGgYKRhHwxPdzfiE1mh3SEacv8LTqnDWRdsivUCjVzVIUXzua+DuEl0lz60wj2E16PHRBTdJV8dxt4rP7HTObGZAkNND8KCaanqAXUOTC5Rm5p3uhSU7PhXKuudp2iTdFNJ3HKRngMLPQBi552goxv66xKIqWzCN7MxVQm8VPd59OFj96z0yn15GN1XtXJIIYB8P/MAk/IK1ETVQJFnK6wr7A/5bkoGy7s+96WOVgzfydDvOwOYtdr4udRCmlMm2wm9XgDnEoul1TkKUGlUpV9oFt/HVd5vO9zEAgA5B4OxRErj9quv7sFgh9eEchWbvfOWx7IIEKIIoEa3IF1L2CEZzstrYfT8APVdx/mRG9STIV77qOpD7xAN6dGCZuN6vzTkeBV0CKK2qT/idwevkiRWLfEnfd1CKLkhnIjL1QSfheqpz/aQi5lLvqSMPg2TMDuG8ESwAAA", "graffiti": "data:image/webp;base64,UklGRhwWAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggLhQAAHBcAJ0BKrQAtAA+lUCaSCWkIqGudLwIsBKJZADCADATbKuuP+545NIFs300eYZz8fNB5rfpq/sHqAf6rqiN6EtPNsNrQM6vOPBfOf/geEPAOe3uHM8uVOzUzyPf+/dd9UiEgGeIPNaxSNgYmIgr6DK/nZdo35uECe0yAhmBM8Kh2fsfEy1OIaVrzML3ZjhtLM9fl6uSoxSiET4VUeIILooBH+EOw1fFJOUhQ9MFFt4bUq1pXA151773SzskyBYOLczC6g0yk+LTYQzCS3KzxIx9rKqbS1o62vgqhMa/iTjGGKKhHGHzKIQOXGFpFkdZRtFhUgxK6H21P4fOyFMI49IQLTbFiCL7YwDEPQr+H42nLDSfTCtLS/u8Ti3rR4xsAl+cEl/QHwmZzFAq+17Dap4C8xS+oM7KVtFol7wAdddErY6j3YMs30Vbb3/4o0xOK0JPBS62TEpk3VvnVZpukTXrKzvKOond1cCS7J9uQsr4J4ETaXsLBRMdEQTipA+u3YEfruQHpfPt2ZidZA88uNah5Zx021Y6Bcd/3Q28zoDR/vKIAtniSzCegv/08EvPqT6koym+E6nYv7uMP7YJKYiQhdMJdRWYi2a6iHKnHhMTSdesYUa7SCba7tLX/95khubeSRNZUJPZM4mqKCIxg6p3Iw7pW/QE8RihaKNoYzWgWs1g4+p6IXJiBevqZVrEFdFmjSaDJRQQvOkaYLp48lpZFBR+S+KPLhEhBmpwa77yT7aAYMRxOvcEeJSdYSh1xj5jcioHpUfYk0Qr1+bJxFY7jJgAF9nqwo6bxJgYVAR1gjMdci2Oal9TeUywCZ+t5a/dNSvtu1Isq5O/cazuNjFihLbCXeOCoYCRf2jbSdCl7a/q6rVAG++C5w9J16G0Fw2cWErVVMs5y/JRQyrdf2y6lL2E2Fw2FAcR0X8+8wQoP4st7kvej1ST02Itb1E2z8e9UrfdXoz15+mU61Mh8MvksEYscPJavDcNxmAA/vvZMWjV68Vf/84I/6S/4PxI9p80+TOtyqlp357sFqPPQKbepyJeCdQM++cHXvN4mRkYH05vmYEbEJh1lbvQpKKlL9O+YEV9sZfbjxL7+6NjtgD2Qc87znAOCJg5D4VSlh04OmTJHZKXxOThDPOhsNvrOcW2yVEGXCyVI5vdDeh0SRIr07O+ENMCpRFOCy01ys21BiIR4trw7TJ8NFlivxYF4L6fMYbuS8irB8TBBraERMRXNVGZeCnqahrMduiFqiNfkLMOcJF89wEdvctSOOa8iOs7sRuqGqW6vHRmXqyLiWqJmErjJ8sJa8dDrasD9zsQH3LDNhhhA/TjPNpaFU5l9MtVI3umxa8ZJY3U87mXpbBMeoaKyaxtd+AS0z3yFmb0fjif1xaB8l32ECUkEWxeuLyQvw3prTWnDv/Sz8VkgdS5BAdJKFyWqGvZYKPB9eYsnXLHMl0AiHt7oFqsieGx1oWi1J4iZt2QWeJhLvX7M6BI03/FMdOrm0C19CMVBfHJM/+3mbITNMMxgu3vgdiqwhuxBig21vO2acKPF7YHrw7X+cgnGtX8RSp0xvkl5PofP1/qq0p/1P0wBZbcnJYElSxJ49kKgQd1J6Ox73HGt76neH4JaxjQ0SFqbRfYG1G/JY577qTsuiy5gg3Kl8qcfeRQbobLSW7UnqCyrErXkXEm2PbkJEk2gaZhwwBpoYruVzWuNI/qa1bShiZ1NubD5wBB601VRvRzoUFNoEduIrXqblSB2XGiwFckTeTmQKf9BpMb1EfH3IQSCkcvalP02VudpdSXYk5kmtM/zUDOXM2p+5MEKycSUnMSsbTzAoIr+6u/8bLLByUGhzNjbUuakGkV7F3Ap/ovCgoa5OF9rHu1QwvhU9bP4PMW5u3J4NytLTT85YoRGnyr7wptLgxvbFIAMYetOw+O6jqdhlT8BM5TJLPmojS3NYb5y5ukxoEHx7JEfr6UdUuxN3snQGY2MooHGtpeVg3UWkl3G8zMSxAEZIIACfREnmkmU7sX8e3I/4/WnAP0gqDW6DODMp7flSWoBWpDVEP+2yaaHbnwb1i25lwIYDqCvcLUbwm+12q468Te3Klh/Vi4feuez6DXDcoTEXSV2k0sPG2dC08C4rhi5DPjozC3WsAAj5/+GUXF4GEEdtbpysrIJ4l1mEahH89eJcUU0UmRX7W21H55DOzxsW1hfjkkWpbAoDCTXk0nrymcoPSR/KM+52SUAqOQi6LELUfJV3sIkx/NU8Ly4fM9rm7MP/GTdupjEau32/60eNYSi4L0kS34jhG5dXnBSo+ny+JNQbVfvyC0liTbBEhdTYYm/HsRlRdGTtBsdOmZdouV5ZyMreAFqLDH/tjFvpAGZYJezwLLpK2D2rSgupLTuN3ZE5Ur8G3TIyic8vkrnsd//YzX/qgQweY+gujW9uKFgUvvHEE5Dgw9+m4cfCio6leM7Vk+hMn+wSU0d07D5GLpA7UpHc1B5keSD5Jn5qPzGerkt8SCFuwOQ/QIT4GZE99kn7q3R36Y0CLIqfTZLb5mUhx2LY9rRTPWqiuDSxU4PSh5ZKFXwnzRJJlFFqtipJZIWC3gYIpGQPiHSDVqlafveZbnzygFhjHqvrK3jXlUxtoem0fRiPDatwPWNr/tQY/htn38A/rdswtXjphBP2ZN2wEWtgOHQd/+j2fd3xuFR9YRM70EDJzuzSydFB/qbqoV6lyw74TVaY2ldw89HugHHMj53fAo4LtiaK8Jv4H56WIb/bxVwQQfVhmyt5b8VVaFW9SsOWJg2501v0xV3lFoTUvmv9oWUHZGhGiSgzPgs1s/KhFH+GhBDeQGoo0sQJcpUorRrKeCUBlL/aca+8j7UK/3mywg7CeYcLlCkdKEwNqCbmmTdM3U4hRLmk/ssGdMlL0i3nRDsTrk74BEt4nS3cRUtLSD4eZ6qCafkc7g5auZWYrl2T7u7yImVhUTge6vpcSmXpd+knEmtoqVWA8kttDbwW6k7tVRqkocyQEtgDp4ziHnWFS6k09qqCJSG1E9Xet54NsGdUujpQtXlgIUq4KHC6K5YbRpPFY6zhM1VFt6Mx57NMw7EYZx5VV0uQ+4zWnDt9Ah2WG0z4JxeY4cYj1GhSbDLBLHtGSHfTgaactNSUcDa5+BKoOMw1pzX4g2T3RcotHKNEQvSajDej6wgx5APyGMC86h5C/prOV8eHxX9LY2jiZLUhhzRRyRvgGzwH45lDA0NYHinqJcWPSMSJS6HBodCE5sMIvVSqhu54llLB7BuLoluQDLbsDYReG802M5vleDwQomT+5QbtpHyDFegt40tFfrwsth1rxrY2cm6WRJ5uzk1u72JpZ8bXH4xyAs659zZhZ5BqWEdGeD8k+SM6TrHyX9AxzjBXfuKdiCtZFn7ILGal118efOC7oNLhLcfWNMxYE9q+R+RDzATB7yLQASVuzh3hRQMPRON8ueK4xSfFUq+TBg2jzkGdRrGxHlCZtU4pZQcYSbqZ5bBoH3WgmAK0ZG7A3B76hvcf15zdTIgEzmO4g7Adbj+tBEE9vMO/3PsM4JXzkweC/yP7w0X/lGO+l2f6YlirvJXsxvvj649vSiaJcnwCeq9H/ViMuTChl5JdZTgdly3l665et9xMh5cK26vTWDDyYr4KIGOaQv+pNvygl+6Z0IAMkpfP6rB82Oit5nQ2UymApot1xaUizHdj/e11MUsNd9EeLozv8PPLdwrP3J0WdJkhVmiZmQakrl0JsQJJzJZbahwOBxfgnv597vkCCmDwPH5A4DsyjSjv3V0sANMIZf7Koec3qSwSJRVatwpPalFMvxYJV/0ne1teFI/aRB2jnPdtftVGX7aCT5hwWGZ3/5F7OC63yZnW+wx2Mtji1NrkRMhwMvO1HlMPlVv61zMQ/W/nX+ar9fjz247bJ/5aHj/h5retzrdnapdW4DvimCuDYnw8tY3ugd1A8PpNwv9oh/TgY6vR9P09fwexJO6cnKfufPu3e4HntTj4//3lOiGGUJLhucEAOKzClTXS3MMdHsojeAOOJgw8affMSyWf89l6/vKeUFX8MeSNv9FBZWRVjwI4XRaZG6Ks2mDMfFglq4odPo/uchFoXS9IBdZZyy+zaCzd+JSBcPj1mJoBnpSba1/sfIFUuYeraYhA0o8BSq3XjRhyOQ2h+tU5a4Ui+LU/QcPSy9AEzn8GMermzZjRApjocgNK8tT99n8TG5kozuUdTcn4xudMARJlP8pnsmXy4dsVsTHZmLyPyqo/Jf/znysCxllasPqipbNkZL8dUz3OY4KTLJJ8h2B8fJLF+cEeq2Tcv7FUWRWbm5ZOBzv7nDlo+6x2uO9WqC0gCyPK2ekg4dZ0hDNq20jM85f35Hb15XHylz31SNbDtyYeTn8tYa3ubB/xguVxSh39daxOwepBN4uxAoi5t+0YVAgR0gb+a+Hl3k6aHK1TSDpNiTIwgNFGcJ4kmICu06lIqEYF9ThWIoZFXQLFYDhi39Wed8CPcvO8X1ZGgw2DL3c9lcqPbJaYY+wc3zmTAIlZN3rukC71gTDjzwgvsENbcAuQQruOm3ee4H3oqqpEfeGJl3QsveclhoUCMDFCvULGZUMGk9XSug+YH9RTpD/V7WD2AVTUSyhpBU3+hCePZoGBGRFszW7qsGuKtMuluofKtzc+uVpbsV6/lH4z0FZVbS3jRce+scnaaRtPyHRFivfdS3NyziGuXAyxfMKg1ic/eZguVNnlQeOspQFrWA78odOuYO2jnuXXUK7vT3eHpOH6JhnAgJ1xXFLAhr9jTX1RR8tWbM0LKLz+fEZ3xZseF/i24TQRJIuG1L+0dXklsDvM1ZMzIK26OIcIZseb3FfjTJbfoqUzRVaoN9YZB4CaR0E5FrdD2ysdrMFE4B+24qkj8CwdJROwDX0TrzPgd7aZyvZDlY84FXFPVO3FBVOQnoiFJLw2DBTPyBuHkUJJiYq6LPa3avs2WglIgbjjfx/9WWUT8tjol4SfqlP6idEmf2YyrsAP8xTIPCI0V7gBKm6GVWj144r5nqnZYyr9BRNz6xnHoWK6+BYPuEpAIjyUNL3rveFpZsblegHF7JgA6z/xEgOi66llliDbCtd/f6LLmFvLScRrbLXhE5J200PJkjkq0cZ9Tfyq2fadV2t5dFJuDj2pznq2ugCRq+ELhXQiI85hoNQOxlTjE7hZrs+HWNk8PbT2j+uw4JH3s0sKHyUs7sWSjGGo1KxhEVrYOQd0HtOyKdcPz9tXJWgI/urAlgPP1/YKaLqCRnwkXzXfX36+vw2ZpTT2j91RPgy+muu/yfpwxy66drP8JvAmqQfn7Oc0r1D25xZ9L9SNXWfBQtuydn9VrcENknxbW6lMKqyNVXIMXY7I5u/dfPv8O0M3gGso4GkXNzhiPo/vvcLIQcZjXH77n4MZiG747ZtoURpwOhL6O1S2EpGTMvaBGFFTvNlIxGHgywafCUWkec7EqALiUFMJrUAiO6p4NTUUYmS5SeobermD7I4aPC0O5S9opEFPzhDLucqrR3lXK7PuuvqJdWzLYXHdAbcTa8XIbW4WjXh8C9+zLahiEaIhYvNqDXYVlbdFS3sdjasNEw6OFdNLnR/9t/M80iFAWWgf3h9NERXI72iGdzjlwD/t8r2vousJwG7VHLniu9NE0KLyhASYFbkiH0BpumkmRd1u3MmuHZTQ/npoRGK8b4VP9JvCQ0aFBhlH3xFQfVOd8Jap4JenlZXRf73T+6+eFwbWzVROSQIE5kWHFa+7qtzwLNtfdXsU7SQY0BE9fhh+q0W13EYQ13sJ59+ifB4imaajDq/IjqxVYlwX0TyAMfBSij4kFaEkRVD7VimOghYY4nDNH0vK7fL6TZKecmNL8cM3eRW+hBRF/4UzsW5JVHUNkHq5EZJ1IkJJaJ7hrydKnOIMQGNtJVXXiiCtuZcPOQBlJMhqWfTLP6MZ1p8m32eOjm05iaONJLQxjnUICbQS8mI7VHhIin1wTSxnV/j7LNTc63+pNyt0R0/SJA/F/mvtXiT5DgCjDrw/FwIdp1s24q3uhcktKPql4PR40/UOJLqhV+jO3AWXh5wkubrIB/rxNdl4lTdb5QkwC0VmRSMaQ1cbQXil978nz3kR+qHjE26fATWyXXe9tMjjg4ST/t/6NNfUQdtW69RitMMzCUEQq8J33b1Cqbpi3SpmYSe8EM4fyS5Ip2PDCMf21dx0U8N10udCubNfXhTzx/k1p1KjB5wyMPbl3tuEh5HZ++/WZeyZFKingTTbWBUjXLgKGcXBFu7Jqi8XZp2zbOWx90ywZNp4LZSiuPHkL1SYzNrkaButxATSFbv2xLY9yM878S3IexJ9B5SAgC1/2kXWk0S4zNzsiyFkgjBRgvVdivgTDOeDPiajZ1F9sBgN/F0bqLNrxZjHM/3V5loUE1nE0SmTFHyCe7V/tcECxZa7MkZTpAmrtPmeHloa/wCJhLJpMhWMBmvwARNtdWQ4P5ZFdFZyZC583D7Dl2RkI3Iy+1BZBJ0OPFVZD5SsKAXH00Hc41IaHLB3l2uKUpsYgmVXvCWTJkVrGN/ysNFY/ylUb15mPpsZ8WjOEkcqP+4R5RhZVVwUM/weMrWP5o3z2UnPM2xheU78k+znP1SSRCjfy9nKaryD2qA+Is4EJih52215yCaaRPxwDEhz014jhWs8DsYmSlf7idxQImXRVo8DraSaZM3Wt/8goJfRO6wpxSh8qWmpoc4L/H0GW4QLYgWlVjOS68k+wYPQMsbqnGYqULK9WVodOa9qi93S4ihoED1eqyE9zhkcF+bFpRbom4sEkAUiLFL75khfTyhEQuYggI+PTiUKaehCyVvikoMbp5cJQ3sStBaqP9Kol7JlJtXZhN9bIugAAAAA==", "water": "data:image/webp;base64,UklGRgQYAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggFhYAADBfAJ0BKrQAtAA+lT6ZSCWjpaOwNisosBKJZGssUu/AD5F/1HfZASwCnsp+nfcEeZXzX/Tr/bvR06qL0UOmdn33UaH3cd2ZO1f9r8Q57G5szhvqBliPNf+fmE/e9+Ck6jl7Z2jsbNnaB7+lC2cg5S+pXceqy5mrK6iI9raWraXcajnnNuWG7f7dZ/4KTRPGPBpOG1ouckqZiCtDaUMlzbtUtyjQbm/AhNhgFdhfrvHNcnwrAhnbchwC+XhIyQtRq9TSJWWDGGpd6D3AOCyaouhNywfqczwUL2xUHkNuCzUhwYvLND25Jigr9MyGZmz5Yqq6vLknd26JtpSqIx/9KKZ3bEzyYbopqJ46ibh08iNdBpQBIp1xjikETVHuFRPh3SGvvsKU67gTZmF42A4Zlbze59bRLXl+eCBw5LYa/prVGoE2h/ezSdIrzPNHn+NgRTUDVYg+eSWttUA1tW3OdOxGpxzyDPwTTXSkhPTZg3ZvbTX4AvASLzjToaeRwBaqegiyWEdZX+uKfNunKXoHXCdRBD0DHUY3lBUqLxPEzcAi/FDLvYSPEem5OzUlmBjwyijhRXuARk2TpcAxni17bzrJ5mTybwrsmzgegzP6RpRj7Bh0VOGkjhGkWhXOHCxTcBeBSD0LRA/SdhMCYVsyAy7oNtmDCk6tq5GZ1rrDnibxbOltKTeb1FJRsyZE0BJ/Dy1BlDyjSAVahAMDQAnjyIlwBNi9rW7OavS/n1SWJCJolRkhfe9FWb4x+oLWXT2rHjTet1sntIVAdlmkqTKtfxNuIWdBJr4ve5BRM5CwtsFP++kv/wE0R0ONkmcNVbcwbFVJbFUdCJtN324EAuOIDo5XqHmMKvRC/USG4fT+Y3cX6UiUYjc2TP0B10LD2nV30/b7brZ2H2BO5WkSiWHJNOzEg0fcle4hFqCmU0Elu2htLjzCNqYi4byVv8s7Yngp1K3PHWBZZOICH5KjBZAFsT08KizeqtgEwZ5Ugi+bqB3e91CM40wrzPSqUVEiuPQdWfCIAP74TDJeP+cD/9j/9j/FYjmpo8KSk04MzS76XubB9CUIruoBfcLHW4fqgpSkIoNWGSxw9rsne+QKR8Z0o3NPn3IsOYxLMPrPmkEA74L4vMy49rZYPW8OwRiAs748Rj9iubBNLeHbLZ8gYmB51d47qqkUqhnvrKzyoLM0FzwRpRllQ0CU0M6wNN4VuXUQmGf1HQ/zQ1kgjywYQB8m+FywGyuUtuBMva6Nu//vhySlpghfpk4P2fAiOQj9RtzkJQZGNAFY02PCLtCSNjk00FTNDR4/MuMQ00nXFMIiCXpbam0rP97mSlZSH4JuTaIpGliSprVMugDBMV9qvN6VtpyO+zQgH2Wl1EH1VE3E5zs6DPsQiQISexalSGRM4lxHQGmKRye2ZkWw/zrmUr039P95cFM/YpAcNA9ZO2yhmrITHgyiFc8522mhhzp5gmMJkJx5QN98lOeCHdT3MTz1oXbfAjzEOU8UH7PNkTaCHYcOqmFrfyvH1yk/cd9uHOAekwcwk76z3pgN/2iBzskFxyf6OZ7BTZbXJeldqV0i5mubNu3czKIXNv2ii/nN+thiAGNPPnfspcE6Rf4QfD/XYKq+Cy+hhkQmoM+BuUSBH1fwRMpcTN+I+pb28/RPuuWskmvlm1dbA0CRM8lpsXTg12AGp4/3XgcNj8Bc0cuWkMHOcqONQMGZfRNDsyk4Q2CJLqIcQiZQ01amNRWgwh+N+H7MGFsIcl0s9QPu61DwQdrfwmlDZyYPgM2BrZ+uZ4I7ttuS8Ulm5Ax5zk8U35sIRq54SWqY7PmvWYk5A7w4CNaD5ajFWdECf6q11ecR/TcUrWdbQuRTepPENHjVjhZvwOxf7UZBn1MQqGIvU8Wh22l0Hlx1hLXv40Xp5QBqObSxqzs9CYosERgu/XeBUqPKGeTQreQ/BA3vGn8GTfCb1LK0Wvsg3HuVW4TQLbdqtUFtb8lCceTU9Lxwt9J7cB8GG+xKZpmU6klGtrLorBJhVQ6bnqeZ8vANSGAbZxNqE/qvUqfG7+4KtL9Y3w1JhFqQHVTwEW8Scu5xaN6DuXa0dDkQ+i4ECSdFe13AKbYd+wNMDC8R17v5jAQPQH1lCnrbVMG4jH2UbR3a7DqF9lGlEM9D85C80bt29YWhx2YXiNPkdppAPMhx2frrQwAQuIS6/2f0X9FjI2UAMuajDBaXyMPxd0zRebmOWaAEG5nlTfrX9qkoTrPs4J17gHUgD270r8TzAzv54qSQ31qSdnROKnBgi7v2gUl2g/z2AnPF64F9KR1hJNxcm8KCVpQ9ZdqOrYzZ7ctfUpHE/vV+sYoBIUXgEragGvFl7RiQz2dIx6p5X764qpmsM73R+mJAVSCWEo6a936JOlzGycwBWJvyVR5j3yPEbA8+zS5wUT62FP6U+tmj+UmttHI/a7pYQq3XbwIFtylknxseiwrssR+JxPIMyrk5ykEh5vfjCrzMbNqKdBqmBcID+VoxYAsNFkNz7xZFbGQBELh+04fg8LUnMKWt3DIDOeuiBEPjsnV4JvAGOdONqNGkqcdgJG775fIksbZwQnIZ9DMS1JkfIL7huFkF8MCfT4w2ai4efHLvx5vhW0Pq6gSPoQ48XdtKGKfZRpSuckXzW+U5i/pDaNKxj4Ft5oYBjXgGGNHpftDfEoRUh24UCzgUUJm4bBtzN8XLPqdR9R8d0ZHCKjuaSf/lWrInHMjwb3CHnllkUEEjb0CsCDA7F56z5kaChX750/hMRnUsxLyT8FVNbJfrsDPw7AtYy4nz59NvYyAor9KhvJqeqAcGMYfGDm9chsFGeraE78I0biRpTBozPqYcxg0ZjF0cKDWlw9S4D0XfNTxxhmODpuCBiNYUzJsmQty+puH0DTzHe2hmAX5mXYvOu1cOpzYVRKYcc7nFIpRXDP7uVZ8qHdQ06Rt+BTxEMGZ3XbXq5sXrWSBIskSzqKsl9vBYCaa2NrvIJCKVQayUUt26XIYm/qT+iEeD7KS62B/j3ElZXuU0oVmNfCQdAB71WmwJuj6hlfMaKXBadFbXYO4cvDPgIpP8avDp5cfld45jfSGzvLDvFV5Qs+TbrNT/0TjtcvD6KYeUhB7Gu5KSvNZIsbrGAPWDOb67ttcY/ek2RQdPnTj2TbFnGydE6w7qW2l+pOq2pQEx+Hc8JVrV2Wb7oCgIK0DObTyCNNQE/Za6FIDJekNQ7/eKEX7D+ZX/2rPNPIY23Cv/iWZ13OAqebWT1qPsNhFPm7T2mCbBF2xXZKgBeQGPBJqbFfMQ7l2Fbb4E6dsKHYQh54gM0XX8dx3rJP5s5B3SrgsAGvzxRSlNg+9hajIu/DMyGhkkFITFW1r8JcFI7YcdEHGvierzbge/eu5mgDH2JcdfotJ3YFQWA0C8FtOV1iqiq2lCvxy/qiVB+PLLGtE7txgBH0AD/gP8Pd0f/gxFkZ3wwNZta3hDPiFbnMR4HC3NVJRHyyXlntMW2beDU8Goj+jGDPr15xuza7g26mb9VhsoNPqxSeXBApiPWvbgLRIb07MZn6idjHHZ1LXIek1qcDsxQSjdmcnsi9bwvf92AZGbHsvQ29Kyn66/U+F6OQ6dzTtLtOm6D5epHRVSjpKuog3u7/zomqdWpNjzux/jJYed9duhxUEtgDfCUnLCa76lgculrLH/ibMfWNpibx2olG9xU7JyktJjw9H7k0tn8CY1p0AF3VJf6bQbnHTXTxygMotR98jf/e4zKeWCDJ4ZQDcxBUNbXxqXKvBH1RswVW4drATgBICskRScFVdmRJywbPVFRvxUE13onzjcsi4HVdvRVXgviDb4CKRdZXirOhQlB1IfmZ+FOeUxPlsXSK7nE4tOIVG9/pphj/hGVWjMI9Pqw0TpirMyk8oTVVzHVFQD445PpVG/1HXcM1LCnCEGHE+gG4CI15+8wORJc04A3FzXGHBjwrBHOa/wZz+ngOWeW5w+4g4GzeHhQTno/y4/JnLiCBRTek+DG2xYUmVZVul9hii2V90KiFmLEIuASOHb/0tGX5GSBTdQ0S+WaCuqIcIuZysfhLKD8N4DhxeHSad48XTxNn2IsvC1gAE4OyUlQ/rpMoTX3igrxq1BSD7Cl+WoQg/3t9IAneogkZhZz1YgGmbVJOpKCUzoBGeta8aGzDh6OfZSm3lz8kdz6c6I5RBQoWvREweI/WQSBE3G5S41wjOjAjR//3fZ8CuaQLiLm+2XyOp3mqeeMUEiOn7M1w3UYXE92dYiZCS5jeO2TYJ/dDam2yuYbMmHaW+wHsnJyEhhh4yHX4v4ZPU2sql7aMiXD8uiealZh4oUN1q3YlLKtmWmwhlfyOxfK+jslePNKZ66zXQQb/VZnw2KyjRiYUn7h7PxTfFTjd590RfOIw1QUD689TtBSQNXkr82qwHT+7ro5xeHtHLLKvI24HjRQVCoYbKwQMUw/cTU1WdXKMGOlz6+N5oqf69YTn6hIwPFPAxg1IEfkCcDRtuHRhrxFaG7Q1+sfSFOV/cbUUnyQ+XNGikZrepqeseVL992LiLYiCscLqMvMwU8NOulXg2BEp0NrNBlAIdjyFn/buTyk42na3DgOU7pRMrKrpqReU/dOhrFKsh0Ztuc9GAf7nW+KXZicNisMcRRFjYxtPEH0tEtVtqmSfhWVIYXBNHSgijlBj4SzBoYoMRVgcRANMAXgzThJm7J/+013phmksSqbB94g015ypg5TcIs6iCay38ecCcKxQXJykXEZfaW1SzqbL1mPuFW+ovuiF/SorY81TWu7Y5WJzHrXiWkUuRdwzn6mE9FQp2GDILqg+9dSFwMeRpnVO8rz6/sS3sJlo527MpvPk4u+Igo9zXHlVHGqEmls6MHsLEVKsDfsycfB1zVfZ/srex+xHl1K2k3snFQKUeUlIzw2ZNRNe7LleQ9tH2ACmdy6ohiOMLwcDLJAFIJEDXVmRCIs4CRFFxv9jrn8GjYYH3lC4qBNJ48qCjknN/ngCZB7fufQcZJUXNIl8m4Uo9gMTGI8duqlaUlgEeyO7thvYcCf38n7NiXRKNTegeBb+5/kGFPl4PN9rklk14Y18LPlEwEAGSsvDdLEfQ55kWOgr/0pSHogr6Gv4bW8ryFjPEQloI8dX3rlikU0CzJP4LAOga+VY+HBpVoOWR59Og7EcWgMyobtaNHVMuaC5LYqMb6TPIwoRAJtXsm0XnDmLKMjN6978Mpu+FWptBq7A2qmLHwOQoFH3IcOIE1CFaquMI7NvD66E3UpDn2F8K2bSDpWgchCoTkBReODMYTycLDeFOI3k3P7dlPK8VbvlZwOyMH4LfVxMecdjcQesKSdLArcLczPSoHrKGzlRlftRlhW/6MlH/ysh8yb3bxh7nOIXepEKULmXDnalRgxbmZLWKHxACGJuHlikywuTz7jPqV6OmDTQnPT6tQ30gx2wVEOYs5ylyGtdPwWWGMw82SGzBk06ja6mPG8fdJLqPNYxwiCOvZ1BAzCBjt5X2ZGs635ABv57E9f+UJt1H/osniZb97gK4Zr7ZpcrfKro/x2dPz9/q74+EeBuf0Yx+lGb/mGmV0pm685Bv8/PXMUVL0s0fTWEIe6g+2XNOc0HnQ3Es6VayazIWfB9axD1QqzwiRbmLxD/SMowf4VItF4Np1X7xKGjFGGt+Ba6B18nhQ+25s93LkQpsiFy2FCyKUWJ55DyDFzpJhOLvXFLR28in9d1DuGFljQbB8DU6mVVGvXTffyZ8Hyufn5rSs550qSBrZg6TaYwfTdmuQH0elZwMzI/SYOOB86JsLy/Jv8Fg4NJwb3B3V2K2YCKforJeEUkbTWrVzgQ5PCtXS0laY60KOxubABi683pSrYMQg9YqPZVCnxYRDrEKdYFGp+jbdVN3Wj0Y0B3x3GP3hO3rA6LRXeTKSBnNRTWhHpzzqZNDGq9RSx3hjMmX4JLP0uiCWn92tQEcc1aBaRNhFGDSEhQocDN6AtZARfYN8JW6uItEbqtpDYR1hnIoCBYz8k8p5qiCtjezUhg62/1l5tH2hcdv8latRxCWKRb6Fg6wxknRpzvmu9j3cqslYBhJ7OUocRLp0J74WWIOUFL9SJWJtqN4WnrOfXlcaqIZiEn3T3BXWvI4En57/lXsLuT5vZO/SXPf3SgLPiH6ptYUSerjS9XsCTuaPNeXG6/yIln9yT8v3UQekUArKRwKoqcopJFipTJKVY1eitQ/wMzxlTfeT12urSvb6F7TZcaHF2AJDuamFSU53O1vJZMVVXnErL+OTLwHj8IRmsKeybPTCIiMQjfqJVXoSR+G/TIDfmrsw7yRWMZtdv0UQ2G4HXAf2BtAyzOJF8T5ZVEKl9Z6Wgmd8vcWy+Tsh8tTJnTIe87+8TP6MMKXJHO62PWfrVUklI0cbgRnvQSQtC6baJp+cFblMkAnp/X2moWavPmvU2MIKGe3bPiXB9CBMq2DIt2K+Z+Cln797/AgxQVXK96WkvCU8bk0feoUZvzfC+xQelB2sSPQJItcHwh42u0Q4uO4/SfFA07YzlPhMtR/ohtTBwsLhkcZlsU3KsNxFOncxezPnt7g0RjT9+nr6CRlq9cY4AF8fa9vchZTvPMYoU/z6kvaB331fWJSdLBiUKs848a8B2yBX8sn21ZH08JN1jf7PxTTYpHd7jtCAlEmQcrN2ESIrR39Gd5h3p9oGtTmxeFyRlexFOZANsCoV+hHcjLFFRf8Ub7A+pXXIM80gsLwwSAiX0/zVvPpfJ8j6O1J+228m/alZW9klfYh1dXauTRQixJpLftchq215auoHpNb+PwAnaVlU1DCZyuZrR7tABn5lco3kh/Vw8VBukVPpsw5oeRq/P0jT146sR8GzMWwA8kqcoGC2eNsYZ90DKh5UC4RkWXDniT9jCWJnm1/ypRqdXUh8hIsqdnuzqZevntAmWyoSsajiu7EhfxYzZmecR7HMHYa5EWRyUrLnJ1H+o03UVT5qB04rhOEDaGOGcniEKkyjet9fzeOywFIh5gH+WPNIkYOlZuzXB4656tMrwqtre6Ipkxk6Dh8ZpIjAwTvUK+5XXHokRcGGa/1QrFnUz7Phv2+YseLtIoJ77hBx9BSvJBJw5xDNeZuZ0g2IMR2xWzWVKkb1mv+knOVtTA7d8K/ae7rx3KUth8WgNUMFC/yDMwTL2Lw9kpY7TAKMkM07bOmywu4Q3M8X7hNjiWgUY8KuGgu6Pfmlu4FMmqHISr/JbqDtnctdf7h6XVIHnge3DvXPPJLYhyGoz6e5hLINuvAGILm5RIdzwMsxOwHkRgAiWUQLir/Jqj33ImvDEyBzbFVTHaSLYJRurh3OKYsu5YEyTKhLlQ2Cs11E03y8nsiAZmPHEelRid26MA1LuDfCzhukC3ryG4k8t+i4i0aWO5TMQQOMz2XXOmtIsnSswyYUqFpEblKVHJFXwUGCaJwBQuBopayP0nnilaB+roQEhADRz1rourASlp56iSQC/YYNVA46zfU3TfMwjCZSTv4gidMIDgAcZH1ccPWxF2bMYeo0HhY/XAAA", "ink": "data:image/webp;base64,UklGRiYbAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggOBkAADBrAJ0BKrQAtAA+lTyWSCWjIiExlxuQsBKJQBhHi/MqmB3vw6iJbYnpv2//mi83H0+b1xvVlpqtfNkpgl59bc7T/2XxCHldopgH4R/w3QN4BNAP9M+sX/x+ST9r9Q3+2efL7Df3c///unftmn/rnuaNIl/Lc7zyScb4P2SxZ0AkIKjtZDmH98H9131q6JhUBms+fj07VQ8gzP4n8J58S7D0PX150P3UifDcsrbCHli5XG/p5eOdbat7bBGqtyTeH2jP2/eKabnp1I7UTXmAFgmHYo/TgP+vbdPy+Od3I431Dq0afpk5RGc0WDRT4d9TjF8FKzvqj7biXEvli5y5EMZjtNV8GlWikJTO/515dDQicYQH/eHb2Ek1IUuOHi2T1GIPLF0+pCS446QoSHQY6Hk+KXJ74mOTAbVZ30E2sQrkzB/RXt4IiSA1TQcBbH7rbwuBSj78SmzDvzbruKP8c1OwRcQp6ghGXAffnJePor6H1GCwbhQkcSactJLvYQCMBhcO4N1tSNJrVpdDWe+sOLzmvKjJYFec+e3EGTOPUxN7d2TyRJrOPCy3OAkz/DY/6nbMmEC5n+FOE34OcX+bhD8E/I+fCafnqhjogPIPR4uBRr1Pe7DZnIU2Veb3PcNRU15cF1O2dBCzBVT2waOqNl8eYOvitG+Fczv9/s1dHr3exVAOCxoAtcFjPprxtayvXJRMYAVm0FztC8DsY9Nwkm/VcmXdviAiEh24Xb8TZWibtSFIZSuNZgENQe8WccT70NayyC2EyDyKDIt5ItEpa6lJ+3psYH49R6BGdz9g3e0JaCRrwaDfl6zUVl7kw41KZeGGXYMb4odIVQ8GU4lRpAZEXYzEVx1X+PDwGMLoS0rXXaSG42Sj6kSotJS8k5/UCfAaiv6/7HsChH1YFB3YknKiF1IZDnEQ6YWYDazGHcCHkRQEHdebit/qpCdqx3mOxaFWpIp6lBI5X4/sW3mjcDJsTjqR3nuxJrOjCh/G6FDkTXJ07ofWkC7GDlcoiyzQusVoXZ7Hj3z1GngqWCQrN2t7C5SSQ9e5FTbTnywTsz/5fu8w1TAvvVm7A1WC+IQp+ysJ+o06enuvPTQQdAqdeWahyrQAHR+ehcy13SGivYZbtUWjvQwIzmaVqY6vONqilWxQAP79AAxNU7CYB165+7uHYadjc6Rf/8kT/WD+6XfHxOMLOSac7G7umyeqAbRL478hTIyLZDcpV+5j/OXAKcXtpi0Nijx4ZdWkSXhH6ZCb/px4x48WsASR+Ct3VKFURqKNsy8/mNITlRIkPXMlm38xLNT0b3G4hQTswV6Ezkbk7rBH6h87f6Y0wf556QrafvtqfEeRBJtee2mLTnW6WIWmWuiVn6hRHPTMcyCp5eLhvdyIP7dLbDwizKRYTX/MN7EPpUkh0tvxGFzMj13ArXi9uhzfks9pOv16lmFD/X0iYhI8CwE/KYcewydlgWZNziZlXLkFJ3RKOmFozlKKJAgA+6DaDO+C4djQzyP/OQsE9+5y4E2MbeqsFJNdMTeB1vnDBgnpmt/MWEALT8ttVOkbuBVs586H/1ucHzqOA6GoQitkBhWWbAoJoVqByuSBF5XsPGlGbKX+DcfdnKvRWweQFt1+w8voIQ5bNsSRhBCTEZy4CCFvH6P670hZBP1UO7D8/3gtZB5X5McpiSX9sNxjRvw1QT5VpL82bDzdP22LGeZyYkkbYPbrib/djG5IrhsWzYFZxvDZtKnj+M7w9JFuzvYwvXyBYHF/ElR0ksvRhz+qNLJeWNMy0pnqtBLtG+q2Ir33GKt9TwhmwVUJ03w1+wDcex9L0jz5tubrFg5cbFgAwk9XDZcLMwJ7Gdr2Vj2ZQsa3etaxXeECXEbXlmXLyY7PGkIgiBaFOSKiNbf6jm7dG30am3ZuixxiGaNCctCUMznzjfxG0NoF3kIiMR9LCGTdBEWkVbqvonz9wTzYZ+x4BpariW1s2ehHLCqPj2mFU1niaOy3zjveSeaodgetjvr9+rVYQlmZG7KHDQ3DjLnZwiZjC6wkIFRcXAFZjZPW3YKKuvJ8Ett10qQTGSrotqHPhrG1zncZrudOVllajMRvc2TSvgzKa7zXOpKPhAOukK+uxXLWS3HoMjffJDGCXw3vgdwPCq7xzj6TB+QGMFlEpJjATWmux8Nh+0AQ3PugwSIJ+BY1Tas36NGv86Wsuch0L4JdrngYJIdpOqUcOCsuE7q4J0sqOvPoSKKRmrmQQW55svAGPswLx9MiBIw7YW/qoYEvoiw+51ExtmA86Ldd0kKFPJT8Xe9YlYrnOqqErj7g/7oW/MAERBA2sf3CSnIkWbUXKGfHKcJI9gBwvJlqnFUm55XJqfTCkfFugxD/AaSZEaXyP2aXu/esIPFEDwqSc6o3xcMMzY3KDNN96iwuUzxOhq11gH8JSjr2UNfk0ewjSXK2R5utDlfuNhcTPZOlBldl6oUmHpq7i3pB9ciha1uWWaViTTof4UKqa787T3WX22Lhk28S8CQ9G5BtfiCPcohExlm/WPa7oGka5pKtgo3b7ot0SqTKWZJMI040/mCDpdds4mj38nwp/jAgWmnEY+uIQISJ0GTrDXTGRLpO/oCQcVfftinDR8aT85Ci/VpBLyx4vNkUcQ7tJNooQCyvn7/pXfcLn5umfBLXaOuoD8RE0xLLZDUg47it5x7OshmNzPcJ2sG/9Um+jaf6J1YNwV0lkLZd9Jz0ZcFemJjz7sDmoRl80L5Q/IYieAFekFb0mkYMSUP8+FmHE+6xL3wAbx9D9yBu+8nVhhMRvDKzwdAHEY1Gt8T219FglQw/dS+rrKUyt+MY9/znBFEO4MsgORILdhVU7vLJB7kcwaOIroy6YJSE7EkCPauT2dXExYpD9OOTB65B1bkSx26kWYCgPAqiWtRQCoqj9QlVQYoWTB6T7YK3QkXOUHOLp+rWvzQCJsgAhsaaQujzdqozRkyrS1T4t6md5NFbD/Qi6eH3fVyXj8A9YjqwvgqcQHT74skaLUrS6GotfgpbpMzD/rJRgZJEUCl7alRv/Atf5n8rjEUEXIHefQw7RHk/CrfrtIs2s8TwyX8NP7j/BTwy034uhL8zphsqnZWeeX2gv09u5+IXU8RQKBrYjGVq2G8zDOjCCg/H/r3yq6NKWm1c8+ezN/u4NVSMUvL7+/sPu+B+mYdL3IlLcpWCcJIMvbsDEbrhQWIO6pdov0ETqc8RtIaU6pqdKsZndzj5fE2m1WIavHd3zkq5dgHr8Mg/jKnFEaa3D/x2bNix3j1dYMV0XgggyJIWGEo7pHulHlogHvcX6jMbrOQh0F1wZv6iDk3Fz26LMCJ25lFicwiFXQD4juM8GehvOo3X18LCKIrf/SjmCpeT1rhYj6V9O2UiATr/Gtx6tk8m2YX7AQ5EskX5IwK3yjuhNhTzYqaDf53GWNFpREYU6KAHz++dF9GCJ+jm6/LtwJceI0F/ePZOLMH7ruV4c8TJgco+EFltu8K4Aux58+ujBrzoTBXwsIDUXFt+o3VXmIrXklVAR+6MZgiZpVEHhVGvJgjUlrFur3mDmJUoohvQrBUr6NQPBLesZ0/1oBRG1Tc1vOCD6by3rCXHK+uxeHovhTAWJFv+KmR55r5z3qj+Zsqf6P1e/a+PUq/6VYRudlrrnbmshEsD8gcS+HIy0agCX+XMkyruU15924zoleQDP9K18sbflEgcqnzeIyRjHJc/bhEgXOwtcy4BJNhSjgOM81FHYp3tk8OICOYuEG1QmhrxQl2SVxsU1EixlLy56lvE6IoJWS1WuDns1pKpuqCBn86l7cIuNOIyH3Fg/0qDDtm/H3c7xyYD57ZqveXCeFH4ka7ZhS2QobgHCB5QJn8CTwY5Sx66GhvBZN+/r2CkugCQS9OmPYdPcYnXQAbJXzPg92AHSwdcI2uVJmZw1Ac/1CnXp8KP7/6dHcyAkqVKWWdaWD+MCfmRzoj7t5eN62kvX4nnaXLDbBVmUE4tyPtlsVGQl2PMiFtnIdnqOlQyuzvMUK8qym4e0BaKfX/UBAFH9GTKC3h8XjAF04KWDuAV+8MwhyVaiif2NznZsio6/dgWE1YvTzuinY+Ggcgr/ivwE9XjGslmnJ2LSs8/OLMVwY7BvJ6XHbBWvfrS2iEWUgQ/OMaRFQAGBpQDg60+Fn2VtM9IfznQzd+dNtH/FA/uu+foRa8veeHIZdGZzFBKAJSVWyB1E/HjfH/4ov1gjhf0vamMENWza57XpdzlOK9O5bvXyODbWE55MOuu3KU//cPm6pqSyv6351N6rm2E8zTu5jXSAf/oNVMvdkzepZYRzw8BCPvaym+15PbcRaYZJV048qrBhctKJxdJsbblhd/N/IvH5I+jQzh6pPbxB4cN4iFov6usoWNy6m0uQKtgHkqv7dE1U7IkC6QPo8Vikx/TaEvUMp3rx9ASwFO9l2gqs3+Gp0eOVpjM1gq4svQ7TpyW1YHemB++TD9/YQzvmssyHeX93T0go5cuvnkzhjwf1fevzHDNfN/X/PLhxToPuPWGtK95K5Yz7rPQCDo6HnxpViOJzTYLVx1Ijb6LSNtfM+4KVhR5VIGjLZBoOn6puNEjdOzZd3uCGW9OXWlqoEaFs9X+GZW7Tzg3Pk4jpYi3h7h/p1lrRH85HQKAxP9KzBXBzFLQ6UOInTRdhASpkmAXfrTGNQeduoHVFYpLp0vTGYrwhS+toyacUHlo1OIXXBqj8xOwFlgAQ1LXK8uyu7m2726UCQS70M7neU7WyHdR3potTM6L0LX0bdn+KcKQGxJt1LuB4FjQkL9J8imrjNwMF5FOsc/j+8ZS8p0OCQjsmQQmGzzwrmeSWHx521EtG0SnYJAd15oEIjF4zEsgg30t8CQB0fklFtPTReCB1MbJTzFNROtqZV24AjRI2Fje/ElMw4h6124YN+hDuPfZscts3WH7oc8rMJmivilMbX3lLc/DDEiRu1dwIIPTJ1Jp2cNXbcvjC9lowixpJK85WD7GG1Diu29W7ADKSkVjlXgrkFyDadKp/VX/m9h3K5yfJCHlzgVhwo9FWdyRxFXM2r3p9DwufNDKIDaWbTqswd1TWZPfsyPxEIilisxK7A7dzQe2/LN43Li5bTpqj6Pnr7Kjdyj4lvLjHjQz48xWgERKTQwS8/8fw50xsd5ZPIRdgFhlbTQJytxudDCfZL4tONW6sIdC06AVOm2cgNGHrxMeRkY8h1UyZzORvyMAgi7ovF1kvqWfATi8oZlLLce51CJZ0yUd3rgHRZd2zULIIVCEl24EyoIvw+5hIy4ujqsJVrmtaHO/RRwlJdPZ3IIy8Ylg6fC3NPThzrjCwlrTCCos5DBTDuB+LRKwIm+o1XTYhypOppbP3miryj/TorvGHnZ/13uwgBgAAyjtiDDz4QHJnDQ3BpoKDs3Mgu70/D/M7h2f99HGMluHbV6FrJvvpIe2OjgBznnGCmnqTF1t1/WfoywbfxLo4m3ulLKxB7W4M5mkj6FCX6xHGYYkuSaNNHDYpRXZ2VuPuFKp2/azToFdHsi6NK6vMiADF3aNIWzrGCCo0EV98MPQOmxo9bBWfuP1tIjUT7rqh3Wi/mPDHXnyssl8HqAxvbe1vdm1RGq3dgUZDrBZFzOo5nHo+u/M8Y4oddCbNSfEbmKbalc7ttoURd7mMbrqdae6Z3xD8vXOrvX6Tn175EY68Llr1u9qhxfWg1eCxEQgMWfOwZDKgdZs2Wytkn8W7alw0mpplwy/cECnyTrdJhyW4SuJPILTjCkDZn8jFEZzHgEy97E8yzVk+iusKvJZX6FhNUSo8+akn0IulVbZnMqBG8GXywGW+lsJPpehnmRcyR0nAbwZk3pfqTBeOhPpiHzXR30FKWpriA3Si760V3209fm36HnyORt2LmBe00W1oF39b5kG6bZmwpzaBzL100WkmhfIU9aTGnvo3Jty2XwjSC5GvXwnW9qQ7186cYELWOMLflYLFBOpILprO9dhp/dOuSl0Gy+bj0nhO19Tog/9lR1om9dhs92WeqaBNScQy0eznRpSlSbEKqUlh7CI61KhHwl8T6zT9lRDH32IheHFKuCPlNECAe7SnKXbPAMhuHgMU53nqIilTgGVZOCLmqj84A0ney6lTEu8vyDV1gWq2TsoUyYRD1VH9dGoUlf89A+ZNpmKv2xLmk43uDgAq/dR6CB0Ojstz5fclJEKdLJ7xzjgR+F5lIE2G9IMbFr1jdG/hkAC7FG8O2zRvAVADy0nDNgA5trAZICbr0RILJlekM5C9C3vk+HTvLBrpBpUCI/y+qvKp6bjxWtVQKuw0A381i/pXjWuhpSLGY3vsIXejfkKO7uKUjHijOsOfBGWqswmgnBcQNgHXi+tmOEYQAZDCXCvqf19htyzQJHDB8ocml/BGtRa8U8Qqec2DlH/1UCejEvLUI5B014SBddZdvpm1/QiekZw1y4dpyYUu194NtKWklL8R1tcUly9XjzlKSla/1zly3y0eoX59oWhazsDbI07NLwj6ycPmDXP0Qj+Bv3aHmPIC3ZKU8rWZIDSNULSEW8Y0uR2W6vJA8YgZlu8fHHFgY/4faAtaLTzUpXw/t1fWk7QTLutezYK8KvXbxbnhgYE1sioQOxQ3VjRIY8uexvtjr3sEHCSZPMk3QX3tlS+CneYaD5myAs/HmspdgTUvx1PgYbKGuWFcevt5oJDq5eZeZa8lF6cEfxL7hqiax4j8g9kynlF0wE2n4lyoa3QxScSKaH6p8ur0VVXWEWivRBmsL+JcO4Drjv7kfVoUiYhWRzh1YFnOC8SZfj5GZdeyz0K43Cj500rS8hJH/FAxj/B4RH+WnsY7Q/d0UI1Rvv8ZffWNEzGKYrcnLN/oMhzuIhmCmlBF0wcAZ4NKUZdRYt6F0g3vIGpqtamsP+HhGoFIYd3GDYRM3qPiH1uQT7cArAw0cjg8nipYO3ZDY8VOxEtvpxPFhadkAh7iWtDgiRwJml2omgEZd2/Ct2mdqCZmXwHowRvoQsMg5n/s5TBlMwubr1UQhi+ldKVCqyP49CbxAsna0dcu47cUohjPkXiNNMRzrvUNpklpDd0y3lMpzazQS8xOyYOnlQORG6/OvNkEq4oiG+FvxXulBP5edDI0SGApTZ6caa5EGgv8w3smb/ZRHIHFxW07otfd8W8IhGCHvlLewKPOjKUF0QE7S2xshuGyb81k3YUcqFiFS6jaBsoLqh4OK5hq+IZ28l62/aS5Osdd1vJDi2q/Zt5AbC+VmkAZAZobNizfSj6GQLhdU1MA3/hRCrWebxBBpEEamF3Pk2rrBOCMtRKkLBMvLC9Tfb613OkMT+9NilpOm2UpzcWZ0JbrpECVG3xABHfehsljfCNq8ItQJVNAmC2CmPqpWrRuPJfb82/SIxfPNLIVeAoF5kGEAKB58Gp5UgusPglv9OoC7BWSr28EFW5yG75AxX1H+05dx91pl3PYxMmXRxnF5l89hFEXkCWimMF4wiJCY1B8h+kMgd7YXpO8ryrdBbzJur9v8NnKRP70ykQ9YiBtoNmzvLaLFXqKxF3T/xc6NfROu2m9KD5E3LDXG1JPuwWWQLyu1nu0fDYrxHxawjl6NMR+fxmSdClsCLVQQTo9dw8FOLyOT12AYoeAT/IJJLwlf/ZDFlAjmYeilqTSi2QY9gSz9QNJotHlEimzCFoBaUP4QdiPCzFq//WVwGHLcKA5835EI7Phx0b3fHxgVhCob+FzQsfJlYCNvyHtYnFUgwGNV2PxLTidZJ9sBrQpy3eNvN9fXzH+1OD8qcuSJv1N5pNLZVpJrdimAyKejMGG14iCiwvklZ+h2gr02zgwvkPa1CPl3xi263i1kYJwP9dtC4iDq1taPCfrcHJQVapu4j2EAzbthEfhEPFv/W3nwLUZOSAYzS0ujyDnL//A96BmbEYw6B8qzp/yKt48obxxGa3wbBvfu5eX96uqgzsMrR8zTOja3Ps17MaQnxKRoKnS5J7Ls9RSb1U/PGI8dloQ+kQFijStfYqFxcWapLux3Apox2BfATxtiEcfd+Pmfs0z3A9At8FtIdcMAxRzaBDXjIGZfEdugNpPh8D+SBTRLA+iIeLhVWZJiDwAW3P60LtmA6UnQraF1RxcivqG8k8c1n7UrWMCYMqLK+t9PqJlWm7VuVbar/UItODGyHLhxD7ISFta6wNzxODNQxb7fOyN7PXrocfJfkqiiSWJwStTb1OVrkY+KRpe163vWIKTa1bWLq/JrHBbkhZl9i3lbDuRCia0K7+P1IgVXl4dN6c6T/AR0gkiibCpDKRf+RsCsGfB0gaDgTzrhhK/CQCOrzwx3T7KT2ts1Z2XcU9F1fGFDiQKoYJjH3y4XzQzrkC5el3JQ8AnW6++cHzt9qirLQAb0QdK7Cs8fHwrz167tno215hc2LhhNuoRn/LwEA7bi5BnUBIK5dnuF77fRHje9xlIOlTyojdRCuM1SMw+761Il3KjEtDyCVoBIBYNpGiihOxK6lwmx5mjf0qy+ahf4EyT4lqa29MLHjqKAVqBhYPMaSMSCbP1/CxEgYSIqZGWCQ4Q0WJhgCebXI81ESWz//oZupqUEHzwrBNFC29Qa/zaJO7wAAAAA==", "chrome": "data:image/webp;base64,UklGRgAhAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggEh8AANBsAJ0BKrQAtAA+lTqVSCWjIiOwuc1wsBKJZQDNuRQsAFFdK0E3OzOUV068IfL58t0IcgfXRqR9y/871zf2/fvwBXgdovgP/m+bf2P9gD+gf1/0p78P1v2A/6N/nvWI/0P/x/ufQH+yf7X9rvgJ/YT05P//7if3V///uo/tF//12v4c6PIzC8dr+142wDULP+x266QZNknpA3pm2VBF1dm568FWh/MyZsU13vgR3q9ZMWEmEpv/fHwZKln9wNbLJ/43NRvomoodJjsTUmPSlEGgPhNiN4KIvRU6TnNnhanwxZ3xnCrsKvAII1+GEShTvYt78zZx1v3OBmJmxJovQHV3JQPLQ6viPTimx08FXfgSCn002X+O3vBoZU/r+jvjRheFBuXr1qQWaar/1CoxskNbuszPZIufrQx20i/LqO9VFwWJ1mI73F+wM3x1wV55QvZhkHYdKZiPXr9zhge/NnOeSjmHRhLolnlX1+tt476tZYdNDZDixRf17XVH3OtDA/GC62kgoCzry8V6lne7fPBep80jCUexh62A/NzqR3ibHKfhCOlp+nUZEkhHm+6Py2f6Yn00n88FsRyEN38LTh4e9vZxUS8WN8BPK4sLLknoEZUiaPCb51KE+KTPnYjan0MEnLyA9oK0KjzPx0x/ByU26HfX0g6SBBrqFV3sF//wKg6yMb+0+S938pUGTosa2KjcYhmCYQcSPcCJ51L1BBpVCbHTz+qZ2dA5IzpnD/CL+MO4DNwarTja/4IwGFUPxTufjT8p/rgzSEk3V0WGq4khyQkqZK0AwjLfCWNx5Wxnmb6jrs1NQGNLmjGK+1UJWUASN3kIxC62jekfmDBo+wRuS4Oxhdlh8Wa0R/ulNvsneslpcE2WERwOmmHUKEAOBW6/Eajw7JpiszW+K0tbAvJtYVWZuTBmX43WB3Vjn8omOB4ia6xgcoQ7U3ncWNFrRZabQjMXcsiLPEj93xmdOzJyugUNPhV2Ud/mDmWBA9uVDaMO/mtyvevBZ8fNfpJRwdGChbv6chsG5maDRkEf2Cdh0Ld4VrbJ2+VTm73dFyQuQZQV7ksWqYaZAEMTiAcQPpBPEPtXn/tZdaK7aL7n9XK181/iu0N51wfOjaiRRIh7BqEmh/r0zeEHmcSw0mU79kCnhAi8zijcSwYewXU0AAD+9r9nBVNwRSuwP+9a2GEAfUZR9khROk9YWpOv7bX07YKNFkTOOe3RZh4lLkTgpVoO5lo3xO6+2dJJYQL3amjWroWOjpspRjczIF14sqNz/XAL38EPyIwLR3lYZvPm9ublYRJuz6EEyrwcrCJbKt2qQT7saqwJ7qNR5L0cN87Qj1pf7h2XScF5w9i9o2ytOsDfcbLjc+hoPnYVJqC34XpMFw1BEUL3ax3viBIXjCJFtXxwtqZ3+0NCAvegUO31O9pvSplIY2d0avAhXjVQpOMGBRyUHw0DDIeeK0X5tWV0p/5/ksp+6mHDD7FsDN4z1TEppZBsG1dA/h3nWkq8hAFXqHnvtrjFAqcn4T78yvQ4dOjjWh+I9SNIGdoSt5W+brEhEofbXdxzSwlFZCqSoavLNUqsUGqsFOJGrPnnnJBs4ksERsFXvBJR7tnel5bE7kWvnNL1OxixRYCzvjuvWGbikskwiPBcAmqzlfXGhgctDIErj4zysSY1Pf+EPD3wj4ceTbGdZMT02Yn27oMP0Bqhfgy2NcXQcVp5rgc4q4Y+hfSaYrgyn+9tTU+xXqdYU0Uo4Ly3RFM8QdeLGFX1RbgfTK9Cgd9z+lonrbBBU35ozy8ChGNvi3+fSJqVB1NmbYLNRXFBYXVYXx3sTC31LtC0KCE22EbvSyUfIIJUPpZN7RCvZ/FEANyIEdnysqmNlH83ogH4qSyVGHV1uGjgAYkagkZ0r6R0o+I6HCS+hDYy2Znz6jEPjzrOpXJ7+oa/eeMbrYnmbu7L7anZ9GjVsWANEdLA8ZEhSl+cVeLVMkLIX5/Ri/ThRUQsqIvKVsNZtqzgesUS8aTN2CpXA8SYTeooBDMi9f7vJdvZpQ9nr0Jv7TUkp9BTM5++u3rJriTLp3edvmH78FrGFUhuorw6QDvR/qU/oAGhs4C6LNT1DK2i4fA6BiAUIQcXGG2JK6wUzMMl4RQtN6m2/lFbTBHXYDb23vXgX9KXzHmNkuDRZeR1iRfktOFIPBCuKcAO+6L/U/NIhJNH6uuDhNH8cegnpo4zY/Cp8DRSxMhV/dsfs6Sl9GoTS1cY01/D4XihS9YE/FtdTUckT3fZazj5hPVONRi1EbkrfZc930KWAI9ncOoQJCvzm6gYRNXT/yrH9hRdvOZ6oQRft4yHjkpH/9NaHx41dkU/ehxQrMnPUiUiUbouP2uhUODZ4Lzkm8K193Gl6wC6Qt99em2jILhmLjjNryzLVysgx1h40vv8pIuiUxuOfNOX4IzfMusH4f/u97lSx+y/5g6CHg8wmiyDfOGfN3+5efTrfI5CUc2ZtpDCPOlmNQJ5oBSg28E1I0LurC0qHFJRNST2S+8yStkOTccNeaghuDVpQM7UKTtyMmwfQ7YX96GDuDdo+YDGDDxNfoeo4cIz7x8Foh1WNnRVmljwT+lzJXLmJgZ/L8K3D2RYDJqJEB4EoGgdLSHjRTVau6djCMWGpmlCDIIwWm5rxxyJ69caOk86lZ8TnTd/Z3AZnGs/UD0D5g+ycDs8F68yN60FQIuciAlDv+AhJ+ZHMQE4R6/TiiHeVKuhtm4/AEOTXHtcE8jggtGwVyS6Nj9ZNe90wnQApKR3JAq5DYNMtz2MbaJazMqq1d241iGu+B4Erpu013bElQpATzmYNiki+c/D+BIpQi0lbNG31RomXjmkgpt8ai+3GD2+vokWQBwPZ8siUUH93a5S9y0fgEKQ5DPZgkh3YfCjWx/pOFjN3vsCfkIKwAscPa8YKTxg/pRsKbGZ8BWy+QPlLgWVcXByfqdU/mkKjZ5/jbmejkzNgF/O5TV3LHhnzSZtubnH0o6j3Eq7keKyoh8lxaBRs09HGXiUbTsldfX9LcKw3phh5qQQLumq+fp1noaOncBpNd/wXu1bG1x6rJ/7ibj6qItYnP9DiPVYiC1QHxbrkE16pM8uVv768m7MnzFouizAD0kJEL16MeelFcucSbPOj+FjXCQj3TRonraDsPrnZhZRNfA0V/L5Dedbe3LOhCR+3aycAqYu9G5Xf60CNR2wCNGnkoaxK1t/lvMqV+/s9zmVLPnv+CfiLUVOAJoOnlUKMUviP7r9opCa2esEMHQ39k08cGDPsV9Ncw56TKdZ9KJJ0AI7BJgfjub/TSWSHBtf+t3k90l9VeHM1yhmc0JXMmai8olTUOZBnKc+JPeFmTDbN7OxfjjTEKSoLBla2zl+zlNb9avpMgTsDygkybFMUHNIY3MjftZj8P/m7QYuZGsLwVYBY+8MfHM4gc2lINXVbxg4bPQZux8c1BBXOobyqNEVbyJ1+Ijj1/aeN1NZ0+jMVvQ2Ia6SHBqf4SMOe6EaVKkmkVkmk72O52qrDsvVOz9pkjEobpQX+39REdX7MdefbwX2t7Gs2kqLGvj4vkq1XcrpnUyUhNmHs752idCAYnbk+6LwnNRTV9w7s/LpxD4d6A4hRoWmDd8AsoHPJYj8hw/XwYF1a9hkiOEs3tS+zljKPBwlnEiqzNDNQdcbHQPgYmhSLRupkGw87zbpUQd6poZzw3IbYyiTWj+08D5ZUdgsx1LQgysXx6z+AkEYck2eouTbNJKTgVZZSSOuLjDdIzB/LW9Y90LMn6ai5wHQNPnWEIXk9sLQlN4HrBYUrpA7t6zyF0R9dJ0g9H4DLmw58r6VdoxUmG89AbJOAdp64ogBXhDDotPQDNruqE8YHeqQ0QONRb5l0fozov1P0tGDlEiHsbWqDvVLrnZy+7w1oL/b3D5wyevdqnFrKm/px2MM6JIM/bYmBiOuF3OmxMwUllJNlwep3MisIpo5md6VjQ/YlyC/MrZKzN30omsCBtQlzCwBEThHe311tOr8i9qCqruTl6kIxtN31LXb6gH5vCRrxRptZtcltdMHPymnWHyT5HlypK9ifS7i8RiWKl4nkQqQ/voLXW4+ZCDDKMiZtxMZDscmyI3+Nedwg1adqSyaRL95t/pdjHHfCtthmMUQd/FD9u1vZHRzbfSx+8j2inkQ4E0wpOnV0bk8FGHdDs+DhtO7LeDj6gW8EJ9ByNbj0CRMs24s0DOkcEg8cq7gA+VRNv3MoLXxqppdF5nOOoVAh7O7knRXyAbT0FUw3QkLP78rvvE2/eG/fdtGRN0QjHXnTbna5wHEu5G1R+BxBn2m5mG1sS+vSsR5qyXPtyi6GU53B7lVFPMaiUzNt+dpK9uh4DV+pjVZy5Fa2fw4VQWMGgS2SblLZRp6GfwmsPGtLVxIAg++tyoRQBaGOISZfdQRseGhDFWEkzU0r76xw3TwY7vwb/h7rDid7FNdOhIW9q5LdwfYXqrTyKCCwPSppcPN33JNHy5FqNz426URNLFRSmKZLgWhMP+YKrCZJ1i6Zaf0EmUkTWi5y7sMdPqaBm/udKzPpQMVVn2G5pyM9mShGB+OsDBWZJmfWn4hM7XI0Sb6L57kUlNqJ6nSgQEl+VjpjBXbuMUPVdxhlB7q7J0qJL5IyvAsRMTqa/aTyUUT8ENtSsadZlaGe/5xK3AL+ZTeIstjHnukEUjjwhgPDEr0kkDyTPrWRJD4dB8fOZzVzvfDRJ3+bJNvdTeg/QnnltuYOwMTMw4efuc4AOIfVFiYmvfs6dRtB9DuB1wJ6DeOvaNebE+S9107CEDGEipG1qHLkFKFLI5dO+a4+ZFfszoZnTgxIDsMMPaFgmiNv02sgQod16KIWdonGSnDMkKfPr05TJzKk1946xZXKBUVWrcipE7nzSqVJjwk6f1Oj66vQC1h3EOX1vL2U7RAJ8nHr6sW+J2bOsSwj22kwL9xG5f9LvyRN3b2t4IUfBpShhJF0foFEz0ogFsTHHPaiCvplqEHPNiQXnO5BporCo9DFknYSFq0mkcgyuc+EjQoP8dsoo5X+Qb3uX/K2GTG8e9NCOq1gPbZL7eOyh+38jJgtAukrMPV8re79eZOjKycrCBHQI5SM/i5CydP1VmKUXFazt8piIL1YMHKExrvv3+sC9zn3eAYj/g4hN4SyJbHmy+5E8br8i41vqGXuzUlOtZ0bb3tKxqJJkIkbh8x9OhIeN1ZbNtsYILF1fB7+Z1v+DOc13f5zLtX6E6cq0TGks3/lRDfPTYhN9hU3l7XKy2to//y880bL+mtL8Jn2LnbcgpHi3yXS0tXtnBzNr0FJF5A3agNNkfKdKcgzgdlN1yMBjXtyFK6NgGTDQ+OEwBaMdZPPYyONiiOm3NpWJDIK7dk4DDYD8PcZVMXUJpSkWxHbnFWZWbzdc+dRrrHTN/LiVLMEsMOXmUkTinX+0ebMhQTt5lPLOTUHuThaKhOWXtInCr5bf1S1zDsh1rKAX7990Peg0uAvn71XCsAGptJ9A7RJ7MR29RpkY6jEPUIGSPisAAPH+vi87OQFvOLtIZ/3GXqimxZUSs+/H/mfL9bTqraD0oN9fmvb91DylrfXC8A3fJCDLuQwAIDec059bV5nw8R5sAcZBXMVdwCFY072OMop5RTIxH4pALboRFOExlddPgJ7O1tR5+yVXhM32HTpqpVGRHohSMD11n/EgS6FKx/enjDzFpozh52wo0l2IlfICJZhV5tR9MDEaW7IPGV9DXVv9GJMWX/wpGtt8Naj455oOvG1mA212iq4O0TAHe/CdkGJLoI5Fzksb9RwYHw3i83dGsP3j5dQDrklyoFxWd//UBm0JOZB1muqm8/Dlz1LCcY+njg/dPztgeON7Hl41qhGz8VA+0GQlfiCAdJ8r2bsZ/+DJsa2DYbf9PVnQcnGMO5njl3EGOiaDlogOlYrUntWl05Jr93APPnmXJG2lWNnKmTd4I9678jPl4MzRzYo+AwMHZJ9DgRgXqGc2VcYWQCAXQUXuDKIBCIcW/9YNwXZ7ze51gtnG4ewQ9Nucw8iqCWT00BZ11bvuySSjO9RAuBO4X7UGbhOJlhjwn/iwNN4dhXTeFDAoW3QeoI37q2X9pFajLdbaxDHhBfbGxW98+EpDKIHeFufooY11/XM5iGJ/VwFQVNhVygxFSNENe244EB4m3fQi5enVWGsonV9hFINp5O0cijt2Ea/NOQw8nDUMH1KKktIMXAsqO82thYxjgEr6X6uyLHmRV2Xgr0hZ8WlmuozQ6gfPW4ywSfpLks+cBvO7baGV2XJ875UeMun0rN/3wadli3l3SJaN8knOF6b86siVvOlcHk01BzrArH9glWweEEXVleYxcYwTVZE/koVRTHl2d8Oc/QWJHLFxMDO5xmcxbdN38/HJjEEbuhdlExZ3QyDTdS6h3t/eicbkEOkxrqZ4wm+ZwwtD3cHRxqa397DfYuSbHt47FzHys/xy1UcE7pcwJpoedi7ch+r3Lsw4zIvoHO5Rh0K/RrkssubZb9ace/u474hRjXIZ9euC2rKDkcEn4C6W3qsHovLdar1cuw7q/veUNPk71f/w0uKyAy20KVurxCboo3/iAaIYA32wbHvWyiA39pEZ6v2DYT6s/QQaihFqNZuGmNWdAWaaP5R1v9LSm7GfvN1GxOqpQ007bvU293Mm2ENoxCQUDCU1CMNkdcfXVpysHg3Ju+R+u2KASpIKg0VQyhI2D0iozHMOsga6nX2Jt3VRJvA1IO/BkBbpfT0+w30DdvHmrCEm4xoeDBuL2+rqptQb6XmhmGoCsA4+6jaU3vDSEAswKQxI3K/wvpkGjbXZfYWZBBhs5p/OFIscfhq8meb4RA1V3YLJB9mxeoa+vIohQVxOwHFCrENKnc0Vq5md2DLmQL2F3+shzqTmXGES+O+3clsfPyz1OJfZsJQAedvHG4YG35rnIv3DoZr1KkoJtveAaoehCX+xcriQyKdPwiXZlo5Ft06TY8BXJKHrX2NDPehIMfzkdNPnvAFVTlGxCUmkcAJX5Fp2nLG1B1550RtRxy5xhH6RamNXswd0cXvKrOpkaVwKRi9Qno9HKeY6xeL5yDZBslpsOBIXtB5OV1sOu6ny/iUNQ6x3KIRduL/8jCIQGkVXpRzwTlo6tfqW57h9ItDNskXvauH/eN8v1aP8tPiqb66EW9kEZzC7vAFYMqB46hc8p1GgpwHDBxqZ7n1lttBgowsy/di3ACqANA2hsX4KPjVXCc1WSh8GLCkgWgO0uWPab2nA3+xcc+ZlZJw3Hxdo8P1FzvmdvHqoFkZcDYhPCG9o6PFonOPJEiz0qy290vL3WUWrrL/2Nd3ikAwZ6N2lcbJZ6JqoWtC8+JoIGo1eFOAMnTDHJFfAbDjridAYzHfbMlHT7n4nAHEKgrvXf2dLrNmHHW0ys9otQKN4inQ9v1MN2iWUp5n608Xcg6Ow04Bucp8rFAwgzqGQZ3Isy9dZTDkK9/HfNXVjxACLqGoyR9e58Dj3HJdj1yXX+/mAAIrpBeZcaItOQkvMYhxm+hb6a55IxLuhXfM2aPUrPd6zyyFcowYVvbR8qXSTs9WzVGzKJa+fk9IXux0Fm7q5ZhN4UBPRi9oWaHmdbDMFBKeMGd2aABlmQzC8EjTkPpvcPAAhfLJZmftvYmhUcXaNsVP0fyNhsR3YxC0WTLjbrEVqv3UT9FnHWIfkJ8CddB68GChi/BdpBXSo45EBEwUmAWWGJ1STtLH7mFRVCth+PzbPlENQCUYTEbTaSx6/SbtYCx4B+1k9nERt53p2fw/8NulcQgCmyBS4VKZNq1wokVBxnA99vGYgkf/CL+AS6xmBOdJFZ0EQyFPVOxoqRm6rDXSCudMt2sQPOwTrW3I454wURvIG9ZeLKweVG8DTZDwYRuWoV7nhmD0Yx7SPRJSVVLHTxQskoh8aolJ2ssah5rv+fUntR5OTL1qf//MAgPBm9maW0mCNYILDyHGHVruVnsHvj6UbwCpGdw4Eh2oZq9cC/H+CFZ6BdkCCwedOxRPBg1M5nOBeD3QmYMjOjD+X83yyDXT+R1bpgsI9C2O3SfWETq2WXQc4Qmrf3mgTdSD2oC+jeyNKNbChfmA86HtnJon79shbxfpOYac3iCn2pOS7l75EZu79ikAvaviXHP5BKGM0WtzfVfa5dsnpvU2eOOS5k2JegWnsi+RxPEGRnKbYEVjVP1A/zU1SuPXRLsiSnesRxXc0SCwMXdBxz/+vo4Q7IdepMIhnncsJMq+/q0JMNYZaP2Uylo11ye+q8r1pWoKtcTvlSCUlTH73zWQUsKsR6p/fZU7OAK8Wf1veki8aci6WjoQ569bncajd3dudr2epA2+ZDRYajbTaSOOerEtWXnPINa1dh0/p+FKgzUuW33F0kxJ8KJ8U894Esiu1ExcFYzOt0ee2c7kKcHOh2tJgzTG1wqCxXffobix7exElQ4U/K2L+t/uJI7iCnv486sTJt/YnHciclhjaAbdee68RpRq3C/3qeLhV5uNaaQm8lCA7UZ59ilzo1b+iZy/shdSIXGEpVS7ckMgtdfSfNgYaG13PTw+b4R6PwHqf1CnpUJ/f/jxefVLpCsP5DkXA3FE17VGnzWY0wO3FATdU59JJ1rp0hZNYE4PGezLHweEpF3ahEpklE8xBYxkvRNaApNIvNTRcEIGCvATwG/ldEGMUaMfNoMu2lhMRfQ9wZ89nV31ziWpM/s3jRoBN/vxddRH6SQJjRs6Ii+goMWNSnWDYWkoXH9cVuKimOB8HcYE5HU4Lk6w8UY4nUZ9PuUSMI0q85TmbYFnycwyS7mTt3AuiDmpUxLaLwNSb/3k5MK2d+q4j5vOtz3txvGwrffgM044/EOPCJjgTyNSg173rI95yP74NrGSMkZ951DFz/M7gzH3qFll1IP/iWTHwFIP6eW3y+bp9rLqIlhZEwkla7P+158p/nkVUu/cPuwVihazGgyI+ALPLLkVr7s//xM2h/15hbEuLi+UEIlHllsfuxGFghHxlmaJtocy6q7txkyxS+wDnI4sbGqLJPe24SfWQ1pp0lCOiL47NkFyf/emwTCyVmSJTiT4wbs8TU6adNtx12J+Kx9XAMHfExo+1BuUI2WUXOfefYT2LdCIhKT4g0dTRqgRMegLq9PPbWWnzejk+PKmDQZqrw+1Yb/d0zd3lX1unFJqockwcgIOKCsZQ4LEpZbNMuQ9q8NCFrUbnvQvQMYTxC66u9Ee4Y24n1r6pH0dRTQbBQ9Ab8fbMXMT0I67ZNaXeA9iT/ZaMbnANu6lHh7sD8Z5iYXsIAGUFsZqJKn9XjSJTdTU8MaqplXDYduS4TnuzBkb4BaJzXIKeLZpeHR+KG+y8HQ5ljD2XHzjEyfQOjQHPKBYM6EfsBhMPr9pSmJF5yikxbwdGTW6ytNaselxAcVdvWjR+A0pOyJBlNrSZVl8+jdMNhNXsvNsuH7h3uQlt34rSQOf3pIB2G9KP8Pq+uTtg2ji63L5xTsn45u11BCUliNqALP0I0mkYC8jdm4U5x5gn7VdgMY/kudtr0IdTB7jAPDznjIJJ+meEGirDPOYtfQfYpCMHdG515XPu9XFrCKr0Za2fCkqA6MecIJLhOonR/KeulTw6g1BLfVS5oRwJe4gp+X5E9zeYLD0Vq1dTL8WslgH7XZyZ1Fq6gwQVpLfU+0oCVO3NG55pm6gRq+8U6qtoz5pYMuD6w1coiP/lzmYLbY95YLE5JWw5SLrdh/D8TfRWc+rm5PJrntPU82sUDZTcwjyr0EY4ycNUcV61/tr7wbqHqPRXT0fBEklXOv0rkv9G+ebxn56S2Rv1RVQkf+nro4U3E3xB4Ks30eUZARF4a23Xn2ZlcThp2aan8A5SFls8Ire7pH/q/3mJFSxD3PF3IjrSdCCBz3rY9oJTsNLr9DhxpsAB5MBA1pxutD+6jBODE3uJzipWsYW3tSr5q8kDtg1RKUrXEV0Y22dAfk2/oy3CHNJhrgTYVU2CrPytt9jOwD+xCIJjv7ZKFgy/ZzHAcM8NAn/ktgGWyoTNb+i3WRQb/zAuazefd/evP9rQnN74K7k59GQNdQv77fmwfafk/ayw2IG2opdR8AlXSozEYL9QohCjFFvGKgYC99ZuszQYpWQSJn24OouZG96VqojgnBGJUd5Iv/28lLvrtpr37H2SgLmwDEslgnFOvP1zO7yTHPtPdf8ADm6ORfgRC2dyTdWeT+nd4WziBD1j3l7olOmil0cZTFcj1EZ3YAP2gnFKpM5EboHUyPvsdIBRX4AT2u6laae+Wzq1ehWjj+WzqIACHHoXEZeen1aye1NW315aYM2+Xbhjt/ogDeheUF7NFDfCriaJk0lHeHJK92TgSOw9ahD6drC2A4Xlp3LJmv5GM3vckv8I0QPU+BjswB7Il1n3Xuh4LgFwgMzhJ9SqcAjGLnVsl11DnPmZxbfxgo+pSFV/sI8uDAuH3p5byprvIlsNSWLTQEPrXwtlJZyfOpkEnLCKYZjGCYEHHWXtGBZL7o/alR1j7Hzc0tCyyRgEysQeWqLqXqREhqIhVk3RR7Z5OyYuYtLoMbLhE5OABDYuW7P19GlaHk+UblYDBwAAA=", "clay": "data:image/webp;base64,UklGRkYwAABXRUJQVlA4WAoAAAAgAAAAswAAswAASUNDUMgBAAAAAAHIAAAAAAQwAABtbnRyUkdCIFhZWiAH4AABAAEAAAAAAABhY3NwAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAQAA9tYAAQAAAADTLQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAlkZXNjAAAA8AAAACRyWFlaAAABFAAAABRnWFlaAAABKAAAABRiWFlaAAABPAAAABR3dHB0AAABUAAAABRyVFJDAAABZAAAAChnVFJDAAABZAAAAChiVFJDAAABZAAAAChjcHJ0AAABjAAAADxtbHVjAAAAAAAAAAEAAAAMZW5VUwAAAAgAAAAcAHMAUgBHAEJYWVogAAAAAAAAb6IAADj1AAADkFhZWiAAAAAAAABimQAAt4UAABjaWFlaIAAAAAAAACSgAAAPhAAAts9YWVogAAAAAAAA9tYAAQAAAADTLXBhcmEAAAAAAAQAAAACZmYAAPKnAAANWQAAE9AAAApbAAAAAAAAAABtbHVjAAAAAAAAAAEAAAAMZW5VUwAAACAAAAAcAEcAbwBvAGcAbABlACAASQBuAGMALgAgADIAMAAxADZWUDggWC4AADB5AJ0BKrQAtAA+hS6QSCUiIaE4PX1AoBCJbAC6u9ErR4ZoravPrvpm5PGx/M/6d89X/E9Xn9s9QDnj+Yv9xfWX/6X7He7v/DeoB/Tf+T1qPoS+XX7K/93/8vpdeoB/9vUA1VHi3+n8GfIZ8h0JMY/YTqR/PPyfnw/sO9X5m6gvtrz2fuOxX33/aegL7qfefMl+m/Zf1G+yXsAf0b+9+j//I8Ez7p/tfYB/oH9//7n+i/KT6cP77/7/7PzlfVH/z/1vwDfzr+8+mT/9vbx+2n/69zH9ff/Sz3/5YLQfid5VNUMJEUW81Mng9g+VWEE3VR/HUNq/kD3SMlFwUVSdLbYf7tUs/EFg7D/oK82DmLV/aDzdrRMc943Qof9G02t+zcf5aVxFugH0C2ZK2d8KDjyDPA9FoKZ2PyxM57kIGt6ayEXAvH6dY8SAz3ymn1wS4oNQ1xeADSD/qn2rGp7VYLamBdUuvsJRSX3RZMLmtaTvhDfMUE1kUqkswfu5mbIhH5+OQN3LntUkqM/LUT2jckHDq1egyEm7WTAzFvivnQ6HqFofRGUQBycaAGy5iX7cwwuNEJ+zbOtuSOGOADGoPgpTb5cuds6KahQkq7qqqT2zAlbVpbvvQBdZXjalM3VEv3jvQlxeKA5wN7QcNic80NerxBv/YRXImloUieO5NCDZXHwNJr0todXtxAB1k22cnylD48DQ9MVTtXfUwwtoJzUcZ+dqE2hJXEBgyUD9AsIOmcZ4SeO9vW+19HoOi9iGqK0iyG/neo/pGhZ13Lm96AiIEzF/CznyvMwBaseq6JFDvWc304TSmrjoA3P9Wa0aExmTwbzMJggs75XXIkXpfu+StrlVZOLNwIt7nC2hgaP85G2gMKbdTY+V6faLpgCevwtM5fnk/x9hOyBuyOXYjGkxgI0PWQtiGEj/+s1hkT4v7L11Vo5IEr1Djl49b58OltZa+4xa9+IC1MaOlTfDLDxYa/yU/UB93AZnch24f18Pu2ef7YG/ytIe2sLMfuQu3NjfLCPTpnILbTZgeUXAzPs4j1DHW533kQJPrNHMUHBW7yxZcaNbPS9dMLhdAMKt9pZnganWTHR26f4OH0HXXFpeEBBo8gT0mAexJfsP1/1GjbavgoSknqK5wl9hTIENIvNhkM3J5CX6zEnFn9ZiOUe92ZsXY3CyZLxZbUjEuga4AGNzLFZ0sNseqgH49vjkQzjFZBPYrGv2vG51LsmpRwDnAuqwDpeS1P8hLlBkWgBL5BdGcfKUTrfbrU4elKdz/TkwJy3qPPPXzYZ5rDywlx3AwAD+/x8DnzUwYM5n2Qd8l0hpyVhnBf4S8N7dkvohAQxvt035pPyeD0oGTaHxhuxovNA6TY7DEMYOl38mEdM+Tc6VuD6eTv/9c3fUm7/+ovf/pN+soW8FiL0uN1R9NiKA7yk9CdEXHOzOxkIBZhr7rH/SSPXQb3h+kMygP0PvIlq7/ZbYKhuzMr5/4M1Z0pFTvl3XL9unEfCg8ZpyAXy/yCntGtJTP3J2ZxnY7/CAi/zA+9WwPn3D9EaMh6K2mg38u5rKDxJ9iXNsKB1aTHB7M6xWCJkC3IywJNEoAaHmCcbaF40LjsQxj9LdxLRsWvco2ZH90Yn6931dEkrcJUyE/kv/w+Y+GxMVojK2gFIOl5wqfuBZb/B77BXq3J0kZDpewQ7xl65L6xsuMNJw4FCrL/3By0kn34w+V3F6qaxSwRpYt+N/b7FiWa6oK30H8KOMxUe5t2NUJtuq3wCcbaLWIydol5OB6NMeeCYVsOZIg/PemTyBOElEa4nWhleWcj1nLma4pkpk5JmMNlZhV2mxxwnCm+pphS/ssEHFps3PdP3q6zAS0EYyZ+Hi1xnyLC9Hnp/B2GMHUY7kIRCyBH8aeBvbgaH6Ers1T16ZtHMNSZHfmR2mStox9OwpbDvWkuys1A9L6Domf0vPxPSBbPX4RbUJeSQpijJ6C5SVUTjuob2LLkW2U9OmzjCTXkymrYXDQRi9sJua+pdCxFqUAo2oQQosUo3lqO3veIJHxgNA2G1m2SL11UVrPnVf7qOCJNKbTf4cgxJHrVLbvOK7ZQKIw3NOqrRlmqAPk9WX1D5GI0RKpaunhcK9itLDJkPyJVMg8EvmqoEB7xVZuIWdhrrig3Hn1TpYP/UttXQa76kW4uUYMIgssIqm3UnUz8M8olGa12Gnkff4fdHm4tmpmzjmXhN9kz4G7kfrQCgi8/zVCNHw1oco5zhd6l1+kpsQS3zX36H/FRYWXC7R1WjlE6FGq/JzJhPJ++1DTJNLKzRgrYL0i55HD4/YCCjUqP3qIlnTkNJS+FeHOKrIHNnU8Toyabq4d8xz11U3BvED0HPRiLTBmu8uO0RmZ3aY+IasphZ4G9jVA+t9Qb8lKOZLJJJ2mRie3gUB02rB/eK74NqZ13Knkl5xtM/mGkgyNvEDFoRPyLTVWG467QaUF61a3FPeClWoVIzG6zPiS2ZxrOQDp/9g2WrMftvZ8PtQNWATQ/Qh8pkOD+0rpMHitPi2O3rrElOGrmwL98DXmtk6ZLBQuO+euyaWP5BYiKjdS12cg1UL/Wu8mztszGAI5zQl4lJOg44lxJJTDu05p+0a1YTUwRP//5SKajcBZbUKHQNSfP3rOH1ityfkP+RmFabK/8CMfRPtdobueQbcnMkDbiloAdYzbUTGPwDKeyiGLMHLbsJCJzqePMBCTHbey5AGW1KdwBmrRCq+2Li6HuMuCQKE8GboH66psod6+/MZ5bPMqXZrDZh2rIduQR2ufniVM16/KvIQ0m7lSFnO8Onnq0CACJhpNTd7uOyxDM9F1YOyoiV2v5Rcv08RNIp2+vYMXlVt4MxmyQgm4UqUBjO+2PdqTHvTtqPg87ZOZeGVwsg51ML3VNUeJ55WLOWt94fgZ4f3sTQLDArWcOtOwFwXY/Uxwxx3oPn0hFQFMtQYOAj8TgAMXbzKahTye3/eolIQy5II8GNPr4ANg+G/EyPTamnZlnXYQkUXEOcaezez5C3NleVezM+yXV3NEQnDZAmbgcKaTi5o/6wYtrnZRB0nAfUF7M9pULnqJgylC5zjXK+vdLqHWLkoVEUEeLYpu6TMF8vXmB2yXC9dZW+dKTxpiApd5GxC+YpGHK60hke1ze/9trcfhOFpNGrCVrEzH/j3EnEi0Sjd3fZEVU4HupnHyUNDNi/99bdOhGCenBCIL2ACGBGCyhrrAlwYPIPXgJ7Y04+zCJp+O4XbhOQF0gj0Fr4KppK8WfCHc6KuPy+a2UQ0VFlaRsPbUOH12eDmCC9rIZgmOqJDiiDAKSSRu+HmbLbVykFK3JmP7YaI0EIwhaD8U/azMEfKATwz4YUN9g3dq7h8R4zl1U12hieohhxfjpPiGwVoh7Xb4EjYSfOSmpUXufP9BV2qmwlv6RSWY/cVENbV4W4zJpi6GX+MwOceGXyL1XN5z1uLkIaRZeMK8MShJNTn5IfrVHtrsHpxRWp4gXY++culUWMUt+10gZBl9ub0wDGZK79PYmubNOBpLvNIzPTCpGaPsLyCk783Yvt5Heac86EM8stTKjsSzna747F03ilW46KOzp0w2oCHoeRiPdnquFODIGSfqDw01y1ADJ89M/l4VdcruUNtE/K6ypDZHab9cwxy0aAVVZK1YQHkquRxVGpiOqweTgkS5asXi+9dLkCsnRuE4ncjbr3lteG0CVYZnz6BufB2ZDTPg4hDwAdAJHDySvHgOkzFj6d3SDEgvilGIh5P2aLdZrjB+29Wl+zKV7xpcxxKUJNEYXMabhAD0Cc00bXdURaseiWo9j7O4PKA7hOgjTXidYFXwtI1LdVb8bzdTNn3+SzFllaBYBte1Lh2cNdd8MSUtZcMftNyc3iUKv5pWe2Ar/gHD5almqd5Xf7tK2UpmKMwhSQZ4W8kYo0LiKQga2uZzsBjoBbBMqU6s+r68pFjdtgJV87sjN5vdfLFS2xw74lJWWBGn6BjEXLJJvDfImamP6a8OexBgAK2JF+pdTDAsOqZmIrEb7u4Je+mzuylptvWeKtQgmlwgJLt187WBMwgoryP06NIU6W/Pg7yecdrMUU5NdzJT0b0WnmcXMYBQjjQnpUQZf9zCcU3QevjPbWaEI8XbGSJ6OTkPFbdzpxU4u0BALNwvKSL6iCDU8XmH4t8IUYHZRg7uvrnMYFaIgTjeeDirHmPqvEF+FExr+zxd/CzjG4pVQh6IaH15+i1yyVepDl2X0+76ThrQA3eAVq14ZAWAqb692zyN8YlA0YslkoxZQ0d08TRX00hGcxLJbyPAhcUJ7kVw6W44h6R8bYlt1rrXJj9lBNDk0MU4WtCcYiFOz3VC18yJlvcEI5qtltmeRhaHXWKV0PmnRwVSLdvo6PGo68rh/jCJ3OEp9SLfJaYbE577WGbCCPEerXGZU+bsR8lV7yMRR+EU3VtYJR9LhWx1yFaiz3D3H1/smRhqkcuin6yUSjMsIo0oTc47gImLgLNBi+G4vetyoGNh6656qHFi2MrDFtZAiqFNBNy7kWwO5TkIIAqbr/58M3YCK6llCJgs0kOQZOWgC6yJ969ja2d+39CWaph/Zzt3LlXMnm/5GlQCVIa7GVBAshHgvITozaLS9SOI9A7ZqznBhKrpEhkz87p3A85r8u8YA9M2F7dXEwV06m7E1yR4VhHUO17wVJBARwyQlpke7cZeq7PqVLhpooHUEOcJlQALNJ+UMmxUr6fh5DLECtMs4MwFNrc0dKdphg1ypjflA8lfBhwcz4ak6Hwk/vr/6JAjqiMJuFUyfmhx3O5x4Sksult7CihLwZPZsWHVoFEotpa/VusmSX9u85iGGBXwvFC41le6MqZ0A4pJEWX4i1VEDJhMQGI7CAwwQDS/sA66zkHUpFuHwPw12k8a5gy6ekndm3a2MRft15Ejd9DHh0Ot0GnFQBzcLc2aae7v8TaRomYCNbqqaqvTuaW/BwoO1JII0Ws1iIEQyK2HJChHUBC7ipveCSUr9uE3tUaNiCWmYoj9K3N7ZuuoC/xLE/gertRRetKu8A86tw2Wc6PT0lLsGlU4Hl+ymI46t1iPQGhNwnzw3GQMbyWijZs4vZ2TtHWp5qCHKA4tZqp/lIFzswNWtla3V3M15oLoNBfKtreXJT2T6/xcRD6kXx3ZcAWACS8RJioivRyG/BATIy8alB9QyuyvLnnuuQEB2bfyr8EV116nv1FYAXV3JjVbUsfzi52cZqB733umKHftz/l8J50L+kcg1eYh4601dyQAF7okGc6KrLlMz0l3A6DNjg3wnmRtlc6oWuW0+G3OewpsOf/y3H9hMm/r4Nu8UaT3EdcNwHgxX5yVH9aSUJPmS5x5xqtawUkPUAwQ4KhIXtgVGXYkSUorv9OS2N33okuDrEHsV60A/Q3qSE8Vpu9LYUNOpH6fvoPcEHqqiV0pW+hoMvUZIhBfAf3oXumN4GvT1xBHt2JKoIhzK859ihVj3BdwKwRGAqXFcqpi8hTY2R/M2KzZgyjgJn1phIgCvjIcHPd2KG0C+/OAiClRrySmYSxJWVl+V073iHuvMVypizEzuQtw4DYigscM6L2uwJAcTIUIOFfgSgMEhHYGJwjvUM/rPYf1zdb7+0Z2+mUPLhq/k/bDOaLF91UJDYWpQ7EjmRMU5B9DLGEWl1iRSxHHKZ/0/VywgRiDfNMrzaBbtQlTSdDEzTOe8DP6UA3X6hsWbbCqMDAs76+hKGWcuAGL28W+gpHmZrO3jjtBM6tz+ZsB6tQzkUznE0gbW4ueX3XsAeFpqMGkRJJItcJzgLwkyU0o0/9MWWHzPojBldT+lYKIp3jttDVq0FwuoZ4KW0wpdGS+7wUdj6Of6X+hAzkarZAgy1njlBr4HziliGNE0IsEpEBnn/l+z6cVYtjnqMTB2FkktoQtx9Q7cscjZx2/avugwb8JSDAVX5wHe3wYinHMs1YDTNbx63Ud+8RHU8PUHhkFIwAF6N2vpTl8QcSMsGJzvzJscnw22AICeJ/KoxxqwedPgFDBShapkb6VuIC1xzRUQxYcOFQn8AIhYGV+VyeFXP8etESgifT8jm1XIvLHjHgREQZ4oqUvABlOn6IX18ZvGfsYO3mU9Eans5ZxzDN07fatKFcrXC5bpMDZ5RV+FyjUH4nZ9piWTLwI/R3f6tUlj8q8rmuetVl6naN1Ayxs2OZgWgG0Q6LgRDLo++VccfUpbn6GMMinbBFhQZbz5vEd5lwZbnzH+0b+tpElJ3djBN/0Uboy7ThtaAhFhCtXj+m7wpg3sTrGyWnPrjWgRQoUyUXic05VNNtOIIUpDIHeS+CVD5t4SLIi4113U94nVE7k08RwJCKXRBnqo36YAqaU0Gguy5goe8DOL9FLEcAuL0FasY5A01hKw2pbLbPk7rNRqKmQmx/NSr6DuunXlW5GHfF135RCDFeKrE4FGh18sy68ewQ/MwNmrMM33slk7zdi6KKeEOhrzwbEkKFHGSZdnqdLAWR+MIMydWAgGCjmH0ALqeXUSIBWeY57myObkuFYQmHRVJqVfE03a8LLI3Beh5KlxGBklqqr28YnoyAVBT3raNuLhtTWl72Qcl3iVVvg3mvtowEQ7pLRurFhZYWKhjgRSYmC/ozTL34RvrfnXeB5F8LOY38pdHFM9cMD7Zy3k5Azw5AHtzOpIOqevwIjQcoxgXpIPisSTzpJKYNjaNNXwTKpfBs4/kxxUkDiA01FJqR/5xMB64UZUmjTDfvI0WVSM4CEOcCI52EP22Cmljiaamy4O5zVav8t1zUgQOFpawMUjaR1O7wSh5nzbcxOVxZvAqrxK/kzEhUHJ+Kz2/O+8rCfmv/HUiSYkL/iNPsgpVek7S8m07hd1zYEEPstmrK7rzUn4IHy9gm/0yxGFCnZlJs1QEy2slRHqs4QQ8CqarpFvIFMJpd5r3Z6gE9bMf1m5eO2XiNTlY2iI6IP9YXN+ykKDa/aI5NfAN+HFOQ6w+33SEhdT54GjiG8q/NdihdRxpGyABUIgrByyKTUkHes1zrOrIZ3CzCvLDQMyRRdkzyrTud7dih6e/J1nhP8Xsy9mJRLQIt8cE+BZhvwp/EARnPXR7b/37XwSWc1B7XGA5lIP0V4yqxJyyx0/NgwHNnaR6yoESz8UxgsR4F1SPUtTUxexfEY+PckFUIzuEIeF4gih4/JjYLV7mXxf5CPeyD+lsxOW55CVshndmGPzPWkg3RN3EICJYHaFTYdbDGEOO8IeqHCvpwkfZY5KD1eUzrxXnNXky3i3eFXbJW9GHSxEWqFzOHSzchzW1PGLbyeOP68xhgq3Odk1Ey2i/31rG0K1Y/t+rpDd8Fm1xEKa9rzBWF6x0RZEkV8DLMFsPp2TQdNC1hl+FXT4Tmrug7TsHa+LGeOe71ft+7GHBGUcTiGvIuGjaH2Jda/FwCn80l9aX+MtjPnJAi4myyM5Ck6OJGkfvzqzh/Dq2TFEG6qsdcnRb1pbOtdclLUDhPNPo2viSRbJmKdJqJWvU3ERgdTiQODzANpXG3twxXSKfPzQjnovM8OpD3X7cNTBsdgZnpXBuTXMeLuTLl+HXPiVwlXARsvqpgu22M0tiU4aPFWD9iCcM8GT6D1PxrMqAyqSME9qDUE2dVeKrxn1746s0hRNZSUcXB4Mz1OxO9AjiuWDpqBX1lq9wyl4a0gkxVEKpbFeedW403XfPG5XOGC0sSa8NQR56uR285Sq3QMKOmMhT2HYOCEfFd8fpFRJ79mpkIgHw77tCjpQLVKPdC1ib7Zuq2gKdb2qMg3T6oS83XJkmPaTv0MsQfQqO44oeZHJZq4Vcdk5TmbQIfi/q3W8KqUnPHnGmgVl7a/es0EzrWwebJJhHDdKtuVd0KVx4IT2VNRq7nfce+1GHz93uI+ahjihpeAxXK/n9sh2kWT8u5lK+HTt8dPKOpHRbVQiKAyqK1EXgAVS3PQSunjzw3IIHn/OvFCxR6gYa3InIybDhVMXk5SO7r3bSVnE3POgr9EZOHrXIO98qlrorK1pXxBVN9X/vncHpMYsd2v9Vd/BuM+qTKfcDB9i5cVy3beTWo6n9cimj1XxhBPzNsptg+sfRgFtyRybewdrP+tFuspitJE//La13+EZPMZL9RBQBo3UmO3ju6jqymqOhk6c+jF2apfqD1+V7QK+SRa32owjWv3FO0vK8owiUjV/NEqfHpE5cGvgSe/6me8Yd7GIWlpdvoYnkN0Wy1dXUtxUjgcj9b/tWQ7/nTXhePclfW6Nm0J1yJ4BGnkap4YirllN1U5D596ebZXHgdjl80G5b8enw98hbZeLJYp8NqXTXWsU1EnAeWOu1LH0KG3CU0ke6yRwe6RUV9TlJO11cnEHfDoOmSJFAp5D22ioH58uhlSZiN8Wpolyx3GAiXFkvoCeZtI3Myiq8F0wBzfWHN2F3Jn/t0trX5AoKzNd2zOszsJj9I4Psup34jhtljqBjcUdygZe/EeB6NMYHvchK8DOisvngesoZ0NIDUY78azzN3joJLcTuEVt8V0rL2KhX8f1bhfRIOIsO3WzWKFUkednBT7KvzV7oamjT3V8ukZeBL+dJgJneh+ouceZZzowbdQ9dAya+gcP6U15EUBVeq7YPLF/pTZEuZC9jKZAKefBYCMwnf03c1DEVnnTP/d2dnKNy1c9K2DIxVcRmBhxrC5T67jvNguTT05MhVmd+CW9gfOKJ/QQuJ95YWN0DZeQWH9N1Y/9LzUmXDDH7dRdAoB8vlAEvJXH1smFHH8aZ+8ENiU6qRj4CcV1icvf9RE9uS1tjedslvonmk3rFZz0Gk5thxNX/lID/NW7DXKNw2xyvbLNzU2rId+VgfuF5BCCcE7pOWCVwGy2YsNspG/Pi7UhB2WTmOS+H/ybxdESRDNEyNpolaf2RLfH5MFKzVa6hnlZElQZMWRR8yaZT7ZHPr3jGFJ+MocxfnyjMEp4KdU3UDxvdPR5BFeyq5uLwfHrv+nmnWdAQ3SqDCCnbWxrRKXP+uGWDeXufElgpPScGX5CXZFl/oWUGq7w43b25oGHZ9fmeuRSibK5WV6uHj6gcjPPHO3Z1P3RNSSDevpplY3PuSKdpx82w1rXSeWEfaRg5zROjW/843urRejklueJsfYrrmkAIavG1VlGi73jeHvffwKsxCHrCu9MQdtWLUSaSLiCUCwmHoeamqdhbzoXeKDJUUUL73XjRepIFak2PG5H/XSSyFMOPVqxviQJIaukT6WcBQ1QLiUvmmJ8MDUi2ju22oi5vGbUliIH3mB6vJpl0v6ZVYPnO28Bm6380ONkY4aHXtCF8DnX8Jawoi4knpFh9MrJe4rz6+GhU/jQ/sPktEAf0tf5fb6CtkninkC9oOb8cBAKsNREhZZdHGhkHiuLcqdYpA4cSdbrpVXwoC1dQiO9IsIANckxihyZdcKeY7zW9RrtzoscG+IHXKalc7FKaZ3KnVITSmLVOMcmWS7YfL3nM4QRXgcTElpZAcd8l9rzjIYETBTEPaOh0DOiYDhVbrX/tFTQx9qjI9BeYEVcDbU6nixu5PaEGUnuM1UVncdegPN8R67LaHhhC9Y57/UNt6bEhNt+twTsmq0IO7OVGzkgMHDXh3PfGQgR+omwOZoXXLYz04aSxky75Gqdv/dmdoAaXw4khaH2vjJsPiZjHUmpsP1pEdH2yEPXRKx4tkz3vAOGF34xGkow2HBMUbbC2cm+GxI7aOWePJ8DszZqh01NczB/3eAExZPNCeyyGdyDDUNKSh6Dzar00ewbgbFIqP68OYM8tmlHxLtb8S/rK39R+/nlv+TXMiX/i0c0xgG8EAPN2RIzb6VOZ9XbQ5s59dBR4MSt0QT6kywS4U9I3pbQFcTkrHkHbKM1+wZS1OCIXXPX0p2UNjYYhf0k9IJBxLIjVMOkihU/tq4tt+t9V7wDTpRnNsakgakb2+c2AAgIfFCTLDIkYWe73XbUK0NJSqt4M+m7VxqpzUYcDB2FfIQ0vEaIu87SrSlc1LSv8AZQcPnJqRyC3K7o6LU/XxEv+rSYqpuCuNULooDkQdogEqtEHtwT8i8/afSRKabYpl+HMrqT9vsBtbfwPaQypV7vZcMfw3Xg62UAEBp4/YwqbyQQYxh/0teDa3PKse+jtSQJkDvA/yb+vrnlfdz5QG8j5yI5QQsgcRuKIhqQuv/uv8Q//7C9yQGB1vIg/XUFYsbzb8Jvv2NZLMhhDSvI1rIMNrZqp9olrwwx1rLX3ZBXT7pLE1l61tp3gfURcxlzOOaa9HGXkuzLIxKQz6bqtfztMYuKs5PR7Ow4zBffiK7oIh9MTz/MKhyfgWsApYcofRfK+bpcTHLfXGoov2EXcJxmVNloWpvNRS1dPIdVPDi2dq0ZPe5AZeV/l+WVcnf60K+E1HnI/Fe4AAZLUK34LqJRxDKI5ZCGtdinG20l1mUrC3qs54qibFBc5alBSe1zfcpg1oDvPEAqs6waRAc/LFvN/toGBY+bVBm2xNfBeIe0R2qgCkajSGB7VUyYXdFVbC94v4nlTv0g60KTG9f+i04cMzyACO6uBbUgG/6QKTpOFDgR4DXUuUxAKKdH3hfyS55hfOjOv/pNSJvA8s9+QecC7j4wlJF1JfYaKbNPFAjwo8qpXmsYksmCzUTzxHFKdR55XT9i7WIxi0N4jiDcPAWZGxLw1IHzoKv5R7G18HnAmjV/y6VwnheDiIJXYonwg01AZAuJfLnGYXdUZxgcLcKxMecmelICbEoGEPnqL0sSak6uzOaeE1MwkIcRZaMX6e4juUVhLCeF3GANuhWkKXEnSo9AQqk48jVd21uSJ+Z3AJk/Udj8v3MzYhbJwoBlYAAuggLPkeTteb3o3ICh3Xxhtk4Zk+eCEGGH7H+tcKZweFt1eDiCKfdSRa1Y9aYuZrM+1sm4WYUv6FD3kmZFZqw0iV+ajWB+WKTPNO9UVBEC9aQvoPJo3GLTADgnmlYLXDMui/F+vpAX1wxbs8QJ7OJsK1OwuQAOnw+yuyZ7IKmHpSfHosW5Dx+05sDPrPjRENxF/nJR8eZwLKiJGi54Dpda8apgaW1bzcCmVV5aDjvpO7gvZuT8GEUnewG2PPPjCs2b3CynT3nBEdkIS1IN2cAGlkCqfjn9beItcUAGesLD2959SMCe6NVwzjAWAqHVhgY12bjGpQkgf4wUxRjPLfnntd30HI8W7hNXIjr9nkfuCsRYwqsUmOJgiKTXjxJ8dxgNjKDK01H74Vd1odLJ7scgSZzxwjFnkfflGagN6Uo+N6DkQdEhn3LT3in0URIyLu4/BNTEOsphMkNWdMC8USdvGS3V8jZjv7HcY75Dx8qganf0f6TfIM6KAje3cshEbYBvW7v6626Eixt7qrN3vRe+J1GORepWjMttolRKGmNdzV16wZhCgBZyc6JG3hOWggzaYE0QlwV+98vMCZoietPgONKpEO5K6np24Xhwi0mdkYIOGkeUwJWVWEtOU655Fu6I7shU8BC2Dn58lWAOkxYfA1oETbj2QsIVRBYr2VDcdu2vCUbRpUoc4Vyfob7MesIv3AAelYbNImlkGEPNLNPElGonjLZPyZoMY5q8UDZojYnt5/zsKgkZ9UkVUcb2tDTtoV2JDa4y9tYhaAsdhxP3LSw9DdamKzq2Osz/VX7xlVZGp5Z1IASBlHYkNt4+/b9r36RsHXGAT0X3s1dwo4SC8DdqcwPvez7siaKBO6pAk8yzZuXJzT710cwLmwkTrbGHMcPmnDXOw1o8kAEVwM+vnYzztxlxu/jVLArkULAoFXDnbiftYxxV/webmgoqcQB5H7kC7uOkD/zO13TVnSAlgUY2siuDNlBAxT+h2Bptv/RaHfScvQVD0blDgyjZYpY+o3V27DvHUr4ZwFgY4/zLmNGoPDOlHXXprTN9jI9ZqFpueuX9rIWln8cnWwNbn0VJeLcouZueDoED1eJ76x6GcvTf7NG8v122jbce4qmdxLQwFbhA1kwDM6oh6O8MvxT7kvnHQ5xiEfd/rF+awI6vfJ8FG+leDmaUE67gVl0xBeQEOzl0NLb6bbmok4i1mE1JjFHTKPbGdfCLEjiWUd+URMtEst+BSAcJ0/uANgsXX+KhM/bbdZHWaawr5+Vg5doJOpr45yLtjQ1F+K6HO70A/0XP3/J9ZZ6u9e876xFGAdSOTsYyNegomkTboDYO6PuhyyG2xr7LyXd9o2Xonc9o0RXP1Q3AJeoOU5ZxTdbq2etFSIK5UXufxcpzno1V7Hcp6IZAXd8+xC2AJKfQpk7ZcX+oAfj93er4Bi3WrrudbbsoCNzCbDK/sYGPUhRuSI1NOgRTDw4ihS44D624AjggNLNpFStDs6fHNAsM0N8WvW7oHESlFNk0sMGEAIc336setbWTvSD3CRPkkiq/fqJzhnTl4YLCRwbhk0cUfFnXNsAd3rpyUeqtu9cOmcos7fOy7lVG/lPFW15+7Jt3njCAIR0+/9u6rYgL1usiwzw9rFcOzu2mbJ90khMiOdF7wb8jzsz0J3f4SyMR1ock0B196vfFN5E1GPd7qNViquvvvDB8IphTRPIrGuDICVE5r4jiSgIJ//Z6bZxvpcUEZ9wdKVnpb/4sqjZkLQsjyHI43anpio86A2koukoUIYVNzlgsf9IHji7TD4YlDlIRFpCx3bqHhf8tAUM004m966TFwD7bNBJXsbTID8xsH/01Kqg7jM2MQigNJzEUhVPVyOPNOcTGKdX/vDeBKc7RnbnoziWdvWCz5fP3pL/WLIgmWquHQ02tXz0FYM19v1SUCSay1T1pbelHmaoS+7tRdHioZxvIhMsWAOZr7V/NghR11CjVaaclySnQGdfXm1qlnWCfvdvVUKxaJrlJ1ygeHFhWoUvneHK132Lya7Y9Gs7wVAeB3ixH3Dh1x0VTRoOCvp1rB96Jqjwb80wnLtRhhYDBVDdz3Hdilpgffjy7WfDn8zxek/OEZihfvBwddwCTuk5bCw94oG3i2QEu4BCHxOHWaGHmD7IsbjqvaWwlDm5qtPnxume3sfOSYmkXWOdXosMxPlIb7M28YQeKf3ANrWHyRXl9NBB97gogW7dS7ifXRkf+xEO2cKPkXbicEn6+isQgzP+BUNb8DrcliDpR2Bvm4rDOVJaSravgte81e7f5CBveWg7k1WcSKCNc2GB4tzqAJATTp2E/pA9Hge+WZmQmX5o27YAHZUx0iNmHQqowTASloOJm3JEyQG9kbhhxMrF9rLL16yntvTO1a1CEu/k71t79tJGxuSvdse8a8ueStQLkunPfAhH2Pl25KSFDzqXhFzVcSvuWj03XKcI60DmCoEU1dnc/7tZVXnL0vsn9rxQ74uf0/wzcgRR9bn5azLnjKDMmBEtfqVbv6oC57mefAPapE9fOQU4YUkFGpt8udDgkf75MDSMtnHjGGx5XxwR7120g9rcqNycLvYdqGVB0A3HLCM7nSfJokzuaBwAs60zTVMxPe5I4PJI6r9vfekmbxPrGeAo96j8kLBxizN/FR6OPlhCfDwgiKaA07EB4cjLXf3loW/ZrllY2GBVNjisDVJP5wQH2WtQQ/47oXO2GXWQ3oeEwgOP89g79fm0DUh4TTfMPLAmMtc/jhr6EbRz7i8uqfjXf8v4xpLGji1eDH6Ev/zqJaNpR9hVK1OjL9S977uZsBI3VFVp71In+EQz719jYKK6SoM1I/qwljxtMtzRYNnnPEmQ6Dwc/gsCjbNKf2k2Znu3zUxCYAAk0mwhiAJ1oxFL8sLbKb+2Tn0JkufQZIgy3NETmEpWRdmtidiOGGS7aEW7iVtJfRAV2wNvOsPhwKKmmj4cYzb3IswKpGNUE6lDlhMS10NcqBk95/7/Cu4et3vudY+XFaY79490P+GoOSCNMUEoBZ8IMB8eqxM2LppS0NR3E4oWbOAES2daAudlBN/I8CejxeCnHe+r2YQqFmdraVPGVzuATjVO+9WEYRQDPUbUpgWlhaAaydXkljphL6qx2wSWcgfkeBrQo3C7O94Hb3ccrbewPrIg49Gg/ImdKJY50Srpi9rAzcSxZvpKaP6GvAAbm0LBN7pFA1i11hrc+Vv64s+00EwRRhrMhf3SbmsN+EzyqV0GjIoFA2GkpYUUkezv7+k1iPqU2AJbp/Jf2JnLqqWP4s8uaZW9oxKMpnjM2/ENmjpniNCOK3/yrPFwFcEU74E4Pfi9w43w9Se1ZeDgVo+gwmNDMxEEf1iYp4EhdjhWdM6XPu4SM9tappqo02WFNDDbAjkuGLpJ5MIktvpCmDI8BFJvPyYKnO9tnysOowisF2Q5w9HumcYZMIKhpKzrMaz1QlU+WY0u1TU+gDARYQO5nzVOYfCwQZ2/A3vmem9fJLbjmJJCkv0l6jsH6P5BlPYwPkt+Y1oDF+3/Aj+Ohr78NsWCmEmB8fhkOeKTQjgNKCnM8MyLb6Foglci7OfPFK+cOOF/IdFv7tB6epQ8rNVi4Dx9AiXHOO+ICHlAB7ZLRZGG9ujIK6ZhVYlllxK1zRrHiEoMw5+h277jw9s5wjKzDYYoUabpVxsvfl3nwZKF0td039RsHJFxFPJcXFb185l630pWgfjHH5Gui8l6qZq1hK2OzJEGrkoqD41uiSSVnnYYYPi5Q8aZnfsSLqmSYKPBNmxaEbtfANHf8mz8jxP0SLYOZOwIxY3NJe3m+Crn1DpUkVTo/oLNokxs9zOGT7tWP/JT1sy5S8MEqTRCy7JCLuxWl4wA1hR19heylstvvVIZBxkhiErhTHHbHyy7f6/iahXOmOpHV/ehld0inHtlK9A1fC8DDvvILEnKYgbC4j0PMD1IGDCsrjwu9I08LQjbnLnptYZbQX7fE3CAGjhe1IBOmUuTwodFedfsvr2a7zJW5kJX6wUaaDRLbVWgxSIaRTbwqw4c0wpWjDFwKDHgP695R2/DIhNgf/L5D3wxEeXX2VCX6XJLS/Y9357KRWDvuAiMAhsZ+/h5/OrTgHnumpzKRLcVdQl+EXBJ1bRkZiNmDQRIB/tBda2aeKVoHxKpqjQkHxz/PEtnwHMu/U1uQA/eTuODr8DPC37pnyuQmhCMvD9uqR41TS8HFI1kz44THXIHYQmKXpsyT3NRCZSuE+nH+KYPgCF1Z9eWTFQ4eAsFhy8z6EgjbkuwRokkifzFBSaNUB3eYdlAaV5hhDcfFqQy2IgKo6duG7urxWkl5Is165Cy3cOhwPXkbddrMSjQ5QIcfMPM8ICgG1O0XRux2k2Ew6pUK6t/JOcqxLy7bLO780H2NvPuLwCVumk50bkV0v8W9gO9nFMdxxh2biCuEcMhSH6IJdcUuMkLHfoUbCzFCRn1YgnZZargM8otD9zKNrFX5eMjboHKz6vaZzp2PPof8YmLGtXjpn5as8otiB9YGQlKANA+2sx+6uu2BH9rvfrjWcFqJ+XQNkCe7eDrrH/vJ23B0891sorn1PS/yULpFv4BJRMiwadl9YxE+v5yOeDNvkHO/306EizuxVq6IZi3XXhF+6UT0VBXVa+d5f1StCapPKNRCAaly+L4p06cGz0WZBUzJoOKA3VlCsEwbymxYP89B8MvKQXZ5mr94XQT/mIpiC0KD34BZoEOb6PR7K9/DUkW14MTy9QcWqraDxIeruGXbCSvzFapAjDszUw1fCRWtM33ra2yOrJaeYzScjHezFw68i4LeC3aMC89bKww1F6pX+zSZHy5X9T3CCexw4rLa6tl4gfwDAml711H2O1K3dRqZZeQlPa+gD2KPRn3y3UFCrRKHcoaiegCCE/ABqlsEzpdI1YMXHgHijMvAuw9lQRboimstdZm+h4hjLk/P0EOd4CtkOoYAAA"};
const LOOKS = [
  { id: 'pencil', name: 'pencil sketch', styles: ['pencil'], outline: 'last', motion: ['draw'] },
  { id: 'graffiti', name: 'graffiti', styles: ['graffiti'], outline: 'off', motion: ['draw'] },
  { id: 'water', name: 'watercolour', styles: ['watercolour'], outline: 'off', motion: ['draw'] },
  { id: 'ink', name: 'ink drawing', styles: ['sumi'], outline: 'last', motion: ['draw'] },
  { id: 'chrome', name: 'liquid chrome', styles: ['molten'], outline: 'off', motion: ['draw'] },
  { id: 'clay', name: 'hylics', styles: ['hylics'], outline: 'off', motion: ['draw'] }
];
const fireEl = (id, v, ev = 'change') => { const e = $(id); if (v !== undefined) { if (e.type === 'checkbox') e.checked = v; else e.value = v; } e.dispatchEvent(new Event(ev, { bubbles: true })); };
function setMode(m, keep = true) {
  const easy = m === 'easy'; document.body.classList.toggle('easy', easy); if (keep) store('cp-mode', easy ? 'easy' : 'console');
  for (const b of document.querySelectorAll('#uimode [data-m]')) b.classList.toggle('on', (b.dataset.m === 'easy') === easy);
  easySync(); fitStage();
}
function applyLook(L) {
  stylePick.set(L.styles, []);
  { const b = document.querySelector(`#stylepick input[value="${L.styles[0]}"]`); if (b) STYLE_TABS.show(b.closest('label').dataset.cat); }
  if ($('pallock').checked) fireEl('palpreset', '__off');          // (a look uses the picture's own colours)
  $('lines').checked = true; store('cp-lines', '1');
  $('outline').value = L.outline; store('cp-outline', L.outline);
  motionPick.set(L.motion);
  store('cp-look', L.id); easySync();
  $('hint').textContent = `Look: ${L.name}.`;
  if (S.mode === 'auto' && S.startArgs) restart(); else if (S.mode === 'idle') startAuto(demoPicture('jas'), 'demo · JAS.BLACK');
  else if (S.mode === 'replay') restart();
}
// the path in one word (easy mode, the phone): free · one line · spiral out · top to bottom
const pathNow = () => $('line').value === 'pen' ? 'line' : ['spiral', 'down'].includes($('order').value) ? $('order').value : 'free';
function setPath(p, repaint) {
  $('line').value = p === 'line' ? 'pen' : 'off'; $('order').value = p === 'spiral' || p === 'down' ? p : 'free';
  easySync();
  if (repaint && S.mode === 'auto' && S.startArgs) restart();
}
function easySync() {
  const cur = store('cp-look');
  for (const t of document.querySelectorAll('#elooks .elook')) t.classList.toggle('on', t.dataset.id === cur);
  const mv = motionPick.values();
  for (const b of document.querySelectorAll('#emotion [data-m]')) b.classList.toggle('on', b.dataset.m === 'off' ? !mv.length : mv.length === 1 && mv[0] === b.dataset.m);
  for (const b of document.querySelectorAll('#epath [data-p], #phpath [data-p]')) b.classList.toggle('on', b.dataset.p === pathNow());
  $('espeed').value = $('speed').value; $('eframe').value = $('layout').value;
  for (const [e, c] of [['epng', 'savepng'], ['ecode', 'savecode'], ['erec', 'rec']]) $(e).disabled = $(c).disabled;
  $('erec').textContent = $('rec').classList.contains('on') || S.rec ? '■ stop recording' : 'record video';
}
{
  const box = $('elooks');
  for (const L of LOOKS) {
    const t = document.createElement('button'); t.type = 'button'; t.className = 'elook'; t.dataset.id = L.id; t.title = `${L.name}: ${L.styles.join(' + ')}${L.outline !== 'off' ? ', with outlines' : ''}`;
    const th = LOOK_THUMBS[L.id];
    t.innerHTML = `<span class="ethumb"${th ? ` style="background-image:url('${th}')"` : ''}></span><span class="ename">${L.name}</span>`;
    t.onclick = () => applyLook(L); box.appendChild(t);
  }
  $('eex').innerHTML = $('example').innerHTML; $('eex').value = '';
  $('eex').onchange = e => { const v = e.target.value; e.target.value = ''; if (v) fireEl('example', v); };
  // the demo shows the painter's paths in turn: free, one line, spiral out, top to bottom
  const PATHS = ['free', 'line', 'spiral', 'down'], PATH_NAME = { free: 'free', line: 'one line', spiral: 'spiral out', down: 'top → bottom' };
  let demoN = 0;
  $('edemo').onclick = () => { const pth = PATHS[demoN++ % PATHS.length]; setPath(pth, false); stopLive(); const msg = `Demo ${(demoN - 1) % 4 + 1} of 4: the path is ${PATH_NAME[pth]} (press ▶ try a demo again for the next one).`; Promise.resolve(startAuto(demoPicture('jas'), 'demo · JAS.BLACK')).then(() => { $('hint').textContent = msg; }); };
  for (const b of document.querySelectorAll('#epath [data-p]')) b.onclick = () => setPath(b.dataset.p, true);
  $('eopen').onclick = () => $('file').click();
  $('ecam').onclick = () => fireEl('livein', 'camera');
  for (const b of document.querySelectorAll('#emotion [data-m]')) b.onclick = () => { motionPick.set(b.dataset.m === 'off' ? [] : [b.dataset.m]); easySync(); };
  $('espeed').oninput = () => fireEl('speed', $('espeed').value, 'input');
  $('eframe').onchange = () => fireEl('layout', $('eframe').value);
  $('epng').onclick = () => $('savepng').click(); $('ecode').onclick = () => $('savecode').click(); $('erec').onclick = () => $('rec').click();
  // "more ▸": the console, with the panel that has the rest of it lit up
  const where = { source: () => $('file').closest('.panel'), style: () => $('stylepick').closest('.panel'), motion: () => $('motionpick').closest('.panel'), out: () => $('savepng').closest('.panel') };
  for (const b of document.querySelectorAll('#easy [data-go]')) b.onclick = () => {
    setMode('console'); const p = where[b.dataset.go](); if (!p) return;
    p.scrollIntoView({ block: 'nearest' }); p.classList.add('flash'); setTimeout(() => p.classList.remove('flash'), 1600);
  };
  $('econsole').onclick = () => setMode('console');
  for (const b of document.querySelectorAll('#uimode [data-m]')) b.onclick = () => setMode(b.dataset.m);
  // first visit: easy; anyone who has used the console before keeps it
  setMode(store('cp-mode') || (FIRST_VISIT ? 'easy' : 'console'), false);
  setInterval(() => { if (document.body.classList.contains('easy')) easySync(); else for (const b of document.querySelectorAll('#phpath [data-p]')) b.classList.toggle('on', b.dataset.p === pathNow()); }, 400);
}
// the auto stroke count follows the size knob, random sizes and the styles
for (const id of ['ssize', 'ssizerand']) $(id).addEventListener('input', showAutoShapes), $(id).addEventListener('change', showAutoShapes);
$('stylepick').addEventListener('change', () => setTimeout(showAutoShapes));
showAutoShapes();
// the message line: when its text doesn't fit, hovering it shows all of it
{ const h = $('hint'), f = $('hintfull');
  h.addEventListener('mouseenter', () => { if (h.scrollWidth > h.clientWidth + 1) { f.textContent = h.textContent; f.hidden = false; } });
  h.addEventListener('mouseleave', () => { f.hidden = true; });
  new MutationObserver(() => { h.title = h.textContent; if (!f.hidden) f.textContent = h.textContent; }).observe(h, { childList: true, characterData: true, subtree: true }); }
window.STUDIO = { S, AU, OFF, LDANCE, tagFile, readMeta, presetGet, TIPG, startAuto, startReplay, loadAudio, setLiveAudio, startLive, autoProgram, codeSize, renderBig, RLF, LAG, _relief: { makeRelief, reliefAdd, reliefRender }, _draw: { drawQ, strokeAt, fillParts }, relief: () => ({ on: RLF.on, gl: !!reliefGL() }), relight, LIGHT, SHP_svg: () => SHP.svg(S.drawn, S.out.width, S.out.height, S.bgHex) };
})();
