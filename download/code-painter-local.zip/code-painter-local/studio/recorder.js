'use strict';
// ─────────────────────────────────────────────────────────────
//  MP4REC — records a canvas (+ optional audio) into a plain MP4 that video editors accept.
//
//  Browsers' own MediaRecorder writes *fragmented* MP4 with *variable* frame timing, which editors such as
//  DaVinci Resolve handle badly. This records at an exact, constant frame rate instead, and keeps picture and
//  sound locked to the clock however busy the page gets:
//    - every 1/fps s of wall time is one frame slot. The page hands the canvas over once per animation frame;
//      slots it missed (a slow frame, a stall) repeat the previous picture, which is what was on screen then.
//      Slots are never skipped, so the video is always exactly as long as the recording took.
//    - the encoders (WebCodecs, H.264 High + AAC-LC; the hardware encoder when there is one) run in a worker
//      (recorder-worker.js), so painting can't starve them.
//    - the sound is tapped on the audio thread (AudioWorklet) and sent straight to the worker, so no samples
//      are lost when the page is busy.
//    - it never hangs: the worker must say it's ready, and finishing reports its progress and gives up with an
//      error if the encoder stops answering.
//  The file is an ordinary MP4: ftyp, moov (index first, so it opens straight away), mdat.
//
//  MP4REC.supported(w, h, fps)       -> Promise<config | null>   (config.hw: a hardware encoder)
//  MP4REC.start(canvas, { fps, bitrate, audio: { ctx, node }, draw })   node: an AudioNode carrying the music;
//                                    draw(): called just before each frame is taken from the canvas
//  MP4REC.stop(onProgress)           -> Promise<Blob>  (video/mp4); onProgress(0..1) while it finishes
//  MP4REC.stats                      after stop: { drawnFps, repeated, longestHold, hw, finishSecs, … }
//  Offline (frame by frame, no clock):
//  MP4REC.startOffline(canvas, { fps, bitrate, audioRate }) -> Promise<r>   r.add(i): encode the canvas as frame i
//                                    (waits while the encoder is busy); r.audio(L, R): the sound, as samples; then stop()
//  MP4REC.cancel()                   drop a recording
// ─────────────────────────────────────────────────────────────
window.MP4REC = (() => {
  const AVC = ['avc1.640033', 'avc1.64002A', 'avc1.640028', 'avc1.4D0033', 'avc1.4D0028', 'avc1.42E01F'];
  const even = v => v - (v & 1);
  const HERE = (document.currentScript && document.currentScript.src) || location.href;
  // (a self-contained page carries the worker's code with it)
  const WORKER_URL = window.CP_REC_WORKER_SRC ? URL.createObjectURL(new Blob([window.CP_REC_WORKER_SRC], { type: 'text/javascript' })) : new URL('recorder-worker.js' + new URL(HERE).search, HERE).href;

  // hardware first (fast, and it leaves the processor to the painting), then whatever the browser has
  async function supported(w, h, fps = 30, bitrate = 16e6) {
    if (typeof VideoEncoder === 'undefined' || typeof VideoFrame === 'undefined' || typeof Worker === 'undefined') return null;
    for (const hw of ['prefer-hardware', 'no-preference']) {
      for (const codec of AVC) {
        const cfg = { codec, width: even(w), height: even(h), bitrate, framerate: fps, avc: { format: 'avc' }, latencyMode: 'realtime', hardwareAcceleration: hw };
        try { if ((await VideoEncoder.isConfigSupported(cfg)).supported) return { cfg, hw: hw === 'prefer-hardware' }; } catch (e) { /* try the next */ }
      }
    }
    return null;
  }

  // ── the sound tap: runs on the audio thread, sends ~2048-sample blocks (planar L|R) through a MessagePort ──
  const TAP = `registerProcessor('cp-rec-tap', class extends AudioWorkletProcessor {
  constructor() {
    super(); this.on = true; this.n = 0; this.L = new Float32Array(2048); this.R = new Float32Array(2048); this.out = null; this.wait = [];
    this.port.onmessage = e => {
      if (e.data && e.data.port) { this.out = e.data.port; for (const b of this.wait) this.out.postMessage(b, [b.buffer]); this.wait = []; }
      else if (e.data === 'stop') { this.flush(); this.on = false; if (this.out) this.out.postMessage('done'); }
      else if (e.data && e.data.hold !== undefined) this.hold = !!e.data.hold;
    };
  }
  flush() {
    if (!this.n) return;
    const b = new Float32Array(this.n * 2); b.set(this.L.subarray(0, this.n)); b.set(this.R.subarray(0, this.n), this.n); this.n = 0;
    if (this.out) this.out.postMessage(b, [b.buffer]); else this.wait.push(b);
  }
  process(inputs) {
    if (!this.on) return false;
    if (this.hold) return true;                  // (held: this stretch of sound is left out of the recording)
    const i = inputs[0], L = i && i[0], R = i && (i[1] || i[0]), m = L ? L.length : 128;   // no input = silence (time keeps running)
    for (let k = 0; k < m; k++) { this.L[this.n] = L ? L[k] : 0; this.R[this.n] = R ? R[k] : 0; if (++this.n === 2048) this.flush(); }
    return true;
  }
});`;
  const loaded = new WeakSet();
  async function tapAudio(ctx, node) {
    const ch = new MessageChannel();
    if (ctx.audioWorklet && typeof AudioWorkletNode !== 'undefined') {
      try {
        if (!loaded.has(ctx)) { await ctx.audioWorklet.addModule(URL.createObjectURL(new Blob([TAP], { type: 'text/javascript' }))); loaded.add(ctx); }
        const t = new AudioWorkletNode(ctx, 'cp-rec-tap', { numberOfInputs: 1, numberOfOutputs: 1, outputChannelCount: [2] });
        t.port.postMessage({ port: ch.port1 }, [ch.port1]);
        node.connect(t); t.connect(ctx.destination);                     // (it only runs when connected; it outputs silence)
        return { port: ch.port2, hold: on => t.port.postMessage({ hold: on }), stop: () => { t.port.postMessage('stop'); setTimeout(() => { try { node.disconnect(t); } catch (e) { /* gone */ } t.disconnect(); }, 200); } };
      } catch (e) { console.warn('audio worklet unavailable, using a script processor', e); }
    }
    // fallback (older browsers): a script processor on the page's thread
    const sp = ctx.createScriptProcessor(2048, 2, 2); let on = true, held = false;
    sp.onaudioprocess = ev => {
      for (let c = 0; c < ev.outputBuffer.numberOfChannels; c++) ev.outputBuffer.getChannelData(c).fill(0);   // the tap itself stays silent
      if (!on || held) return;
      const L = ev.inputBuffer.getChannelData(0), R = ev.inputBuffer.numberOfChannels > 1 ? ev.inputBuffer.getChannelData(1) : L, n = L.length;
      const b = new Float32Array(n * 2); b.set(L, 0); b.set(R, n); ch.port1.postMessage(b, [b.buffer]);
    };
    node.connect(sp); sp.connect(ctx.destination);
    return { port: ch.port2, hold: v => { held = v; }, stop: () => { on = false; ch.port1.postMessage('done'); try { node.disconnect(sp); } catch (e) { /* gone */ } sp.disconnect(); } };
  }

  // the worker must say it is ready (encoders configured) before anything is sent to it
  function whenReady(w) {
    return new Promise((ok, bad) => {
      const t = setTimeout(() => bad(new Error('the recorder did not start in time')), 4000);
      w.onmessage = e => { if (e.data.type === 'ready') { clearTimeout(t); ok(w); } else if (e.data.type === 'fail') { clearTimeout(t); bad(new Error(e.data.err)); } };
      w.onerror = e => { clearTimeout(t); e.preventDefault(); bad(new Error(e.message || 'the recorder could not load')); };
    });
  }

  let R = null;
  async function start(canvas, opts = {}) {
    const fps = opts.fps || 30, w = even(canvas.width), h = even(canvas.height);
    const sup = await supported(w, h, fps, opts.bitrate || 16e6);
    if (!sup) throw new Error('this browser has no H.264 encoder');
    let acfg = null, tap = null;
    const a = opts.audio;
    if (a && a.ctx && a.node && typeof AudioEncoder !== 'undefined') {
      const c = { codec: 'mp4a.40.2', sampleRate: a.ctx.sampleRate, numberOfChannels: 2, bitrate: 192000 };
      let ok = false; try { ok = (await AudioEncoder.isConfigSupported(c)).supported; } catch (e) { ok = false; }
      if (ok) { acfg = c; tap = await tapAudio(a.ctx, a.node); }
    }
    let worker;
    try {
      worker = new Worker(WORKER_URL);
      worker.postMessage({ type: 'init', vcfg: sup.cfg, acfg, fps, port: tap ? tap.port : null }, tap ? [tap.port] : []);
      await whenReady(worker);
    } catch (e) {
      if (worker) worker.terminate();
      if (tap) tap.stop();
      throw e;
    }
    const r = R = { fps, w, h, worker, tap, hw: sup.hw, codec: sup.cfg.codec, t0: 0, last: -1, queue: 0, stopped: false, skips: 0, failed: null, heard: performance.now(), progress: null };
    r.done = new Promise((res, rej) => {
      worker.onmessage = e => {
        const m = e.data; r.heard = performance.now();
        if (m.type === 'q') r.queue = m.q;
        else if (m.type === 'progress') { if (r.progress) r.progress(Math.min(1, m.done / Math.max(1, m.total))); }
        else if (m.type === 'done') res(m);
        else if (m.type === 'fail') { r.failed = m.err; rej(new Error(m.err)); }
      };
    });
    r.done.catch(() => {});                                   // (reported by stop)
    worker.onerror = e => { e.preventDefault(); r.failed = e.message || 'the recorder stopped'; };
    r.t0 = performance.now();
    // once per animation frame: hand the canvas to the worker as the frame for the slot that is showing now.
    // If the encoder is far behind, skip the capture: the worker repeats the last picture, so time still runs true.
    // (The browser stops animation frames for a hidden window: the page then calls MP4REC.capture() itself.)
    const grab = () => {
      if (r.stopped || r.failed) return false;
      if (r.holding) return true;                 // (held: no frames, and the clock waits)
      const slot = Math.floor((performance.now() - r.t0) / 1000 * fps);
      if (slot > r.last && r.queue < 24) {
        if (opts.draw) opts.draw();
        const vf = new VideoFrame(canvas, { timestamp: Math.round(slot * 1e6 / fps) });
        try { worker.postMessage({ type: 'frame', frame: vf, slot }, [vf]); r.last = slot; r.queue++; }
        catch (e) { vf.close(); r.failed = e.message; return false; }
      } else if (slot > r.last) r.skips++;
      return true;
    };
    const tick = () => { if (grab()) requestAnimationFrame(tick); };
    r.grab = grab;
    tick();
    return r;
  }

  // offline: no clock and no tap; the page hands over each frame with its number, and the sound as samples
  async function startOffline(canvas, opts = {}) {
    const fps = opts.fps || 30, w = even(canvas.width), h = even(canvas.height);
    const sup = await supported(w, h, fps, opts.bitrate || 16e6);
    if (!sup) throw new Error('this browser has no H.264 encoder');
    let acfg = null, ch = null;
    if (opts.audioRate && typeof AudioEncoder !== 'undefined') {
      const c = { codec: 'mp4a.40.2', sampleRate: opts.audioRate, numberOfChannels: 2, bitrate: 192000 };
      let ok = false; try { ok = (await AudioEncoder.isConfigSupported(c)).supported; } catch (e) { ok = false; }
      if (ok) { acfg = c; ch = new MessageChannel(); }
    }
    const worker = new Worker(WORKER_URL);
    try { worker.postMessage({ type: 'init', vcfg: sup.cfg, acfg, fps, port: ch ? ch.port2 : null }, ch ? [ch.port2] : []); await whenReady(worker); }
    catch (e) { worker.terminate(); throw e; }
    const r = R = { fps, w, h, worker, tap: null, aport: ch ? ch.port1 : null, offline: true, hw: sup.hw, codec: sup.cfg.codec, t0: performance.now(), frames: 0, queue: 0, stopped: false, skips: 0, failed: null, heard: performance.now(), progress: null, waiter: null };
    r.done = new Promise((res, rej) => {
      worker.onmessage = e => {
        const m = e.data; r.heard = performance.now();
        if (m.type === 'q') { r.queue = m.q; if (r.waiter) { const f = r.waiter; r.waiter = null; f(); } }
        else if (m.type === 'progress') { if (r.progress) r.progress(Math.min(1, m.done / Math.max(1, m.total))); }
        else if (m.type === 'done') res(m);
        else if (m.type === 'fail') { r.failed = m.err; rej(new Error(m.err)); }
      };
    });
    r.done.catch(() => {});
    worker.onerror = e => { e.preventDefault(); r.failed = e.message || 'the recorder stopped'; };
    // frame i, at exactly i / fps s; waits while the encoder has a few frames in hand
    r.add = async i => {
      while (r.queue > 6 && !r.failed) await new Promise(ok => { r.waiter = ok; setTimeout(ok, 200); });
      if (r.failed) return;
      const vf = new VideoFrame(canvas, { timestamp: Math.round(i * 1e6 / fps), duration: Math.round(1e6 / fps) });
      worker.postMessage({ type: 'frame', frame: vf, slot: i }, [vf]); r.queue++; r.frames = i + 1;
    };
    // the sound, as planar blocks (L | R) through the audio port
    r.audio = (L, Rr) => {
      if (!r.aport) return;
      for (let i = 0; i < L.length; i += 8192) {
        const n = Math.min(8192, L.length - i), b = new Float32Array(n * 2);
        b.set(L.subarray(i, i + n)); b.set(Rr.subarray(i, i + n), n); r.aport.postMessage(b, [b.buffer]);
      }
    };
    return r;
  }
  function cancel() { const r = R; if (!r) return; R = null; r.stopped = true; if (r.tap) r.tap.stop(); try { r.worker.terminate(); } catch (e) { /* gone */ } }

  async function stop(onProgress) {
    const r = R; if (!r) return null;
    r.stopped = true; R = null; r.progress = onProgress || null;
    // the video lasts exactly as long as the recording did (offline: as many frames as were rendered)
    if (r.holding) { r.t0 += performance.now() - r.holdAt; r.holding = false; }     // (stopped while held: the held stretch stays out)
    const slots = r.offline ? r.frames : Math.floor((performance.now() - r.t0) / 1000 * r.fps) + 1;
    if (r.tap) r.tap.stop();
    if (r.aport) r.aport.postMessage('done');
    const f0 = performance.now();
    let d;
    try {
      if (r.failed) throw new Error(r.failed);
      r.heard = performance.now();
      r.worker.postMessage({ type: 'end', slot: slots, audioWait: r.offline ? 30000 : 1500 });
      // wait while the worker keeps reporting; give up if it goes quiet for 20 s
      d = await new Promise((ok, bad) => {
        const iv = setInterval(() => { if (performance.now() - r.heard > 20000) { clearInterval(iv); bad(new Error('the video encoder stopped responding')); } }, 1000);
        r.done.then(v => { clearInterval(iv); ok(v); }, x => { clearInterval(iv); bad(x); });
      });
    } finally { r.worker.terminate(); }
    if (!d.video.length || !d.vDesc) throw new Error('no video frames were recorded');
    // how smooth it came out: slots the page didn't draw in time repeat the previous picture
    const st = d.stats;
    api.stats = { fps: r.fps, secs: st.slots / r.fps, drawnFps: r.fps * (st.slots - st.repeats) / Math.max(1, st.slots), repeated: st.repeats / Math.max(1, st.slots), longestHold: st.longest / r.fps,
      encoderBehind: r.skips, dropped: st.slots - st.chunks, audio: !!(d.audio.length && d.aDesc), hw: r.hw, codec: r.codec, finishSecs: (performance.now() - f0) / 1000, maxQueue: st.maxQueue };
    console.info('recording', api.stats);
    return new Blob([mux(d, r.w, r.h)], { type: 'video/mp4' });
  }

  // ── a minimal MP4 writer ──────────────────────────────────
  const u8 = (...a) => new Uint8Array(a);
  const u16 = v => u8(v >> 8 & 255, v & 255);
  const u32 = v => u8(v >>> 24 & 255, v >>> 16 & 255, v >>> 8 & 255, v & 255);
  const str = s => new Uint8Array([...s].map(c => c.charCodeAt(0)));
  const cat = parts => { let n = 0; for (const p of parts) n += p.length; const o = new Uint8Array(n); let i = 0; for (const p of parts) { o.set(p, i); i += p.length; } return o; };
  const box = (type, ...parts) => { const body = cat(parts); return cat([u32(body.length + 8), str(type), body]); };
  const full = (type, version, flags, ...parts) => box(type, u8(version, flags >> 16 & 255, flags >> 8 & 255, flags & 255), ...parts);
  const MATRIX = cat([u32(0x10000), u32(0), u32(0), u32(0), u32(0x10000), u32(0), u32(0), u32(0), u32(0x40000000)]);
  const zeros = n => new Uint8Array(n);

  // stts runs: [[count, delta], ...] (one run = constant frame rate)
  function stbl(entry, samples, runs, offsets, sync) {
    return box('stbl',
      full('stsd', 0, 0, u32(1), entry),
      full('stts', 0, 0, u32(runs.length), ...runs.flatMap(([n, d]) => [u32(n), u32(d)])),
      ...(sync ? [full('stss', 0, 0, u32(sync.length), ...sync.map(i => u32(i + 1)))] : []),
      full('stsc', 0, 0, u32(1), u32(1), u32(1), u32(1)),                                 // one sample per chunk
      full('stsz', 0, 0, u32(0), u32(samples.length), ...samples.map(s => u32(s.data.length))),
      full('stco', 0, 0, u32(offsets.length), ...offsets.map(o => u32(o))));
  }
  function trak(id, kind, timescale, duration, mvDuration, stblBox, w, h) {
    const vid = kind === 'vide';
    return box('trak',
      full('tkhd', 0, 3, u32(0), u32(0), u32(id), u32(0), u32(mvDuration), zeros(8), u16(0), u16(0), u16(vid ? 0 : 0x0100), u16(0), MATRIX, u32(vid ? w << 16 : 0), u32(vid ? h << 16 : 0)),
      box('mdia',
        full('mdhd', 0, 0, u32(0), u32(0), u32(timescale), u32(duration), u16(0x55c4), u16(0)),   // language 'und'
        full('hdlr', 0, 0, u32(0), str(kind), zeros(12), str(vid ? 'VideoHandler\0' : 'SoundHandler\0')),
        box('minf',
          vid ? full('vmhd', 0, 1, zeros(8)) : full('smhd', 0, 0, zeros(4)),
          box('dinf', full('dref', 0, 0, u32(1), full('url ', 0, 1))),
          stblBox)));
  }
  function avc1(r) {
    return box('avc1', zeros(6), u16(1), zeros(16), u16(r.w), u16(r.h), u32(0x480000), u32(0x480000), u32(0), u16(1),
      u8(10), str('Code Paint'), zeros(21), u16(0x18), u16(0xffff), box('avcC', r.vDesc));
  }
  // esds: ES descriptor -> decoder config (AAC, audio) -> decoder specific info (AudioSpecificConfig) + SL config
  function esds(asc) {
    const desc = (tag, body) => cat([u8(tag, body.length), body]);
    const dsi = desc(5, asc);
    const dcd = desc(4, cat([u8(0x40, 0x15), u8(0, 0x60, 0), u32(192000), u32(192000), dsi]));
    const es = desc(3, cat([u16(2), u8(0), dcd, desc(6, u8(2))]));
    return full('esds', 0, 0, es);
  }
  function mp4a(r) {
    return box('mp4a', zeros(6), u16(1), zeros(8), u16(2), u16(16), u16(0), u16(0), u32(r.rate << 16 >>> 0), esds(r.aDesc || u8(0x11, 0x90)));
  }
  // frame durations from the frames' own timestamps: normally all equal (one run, constant rate); if an encoder
  // ever dropped a frame, the one before it simply lasts longer, so sound and picture stay in step
  function videoRuns(r, VTS) {
    const t = r.video.map(c => Math.round(c.ts * VTS / 1e6)), nominal = Math.round(VTS / r.fps), runs = [];
    let total = 0;
    for (let i = 0; i < t.length; i++) {
      const d = i + 1 < t.length ? Math.max(1, t[i + 1] - t[i]) : nominal;
      total += d;
      if (runs.length && runs[runs.length - 1][1] === d) runs[runs.length - 1][0]++; else runs.push([1, d]);
    }
    return { runs, total };
  }
  function mux(d, w, h) {
    const r = { ...d, w, h };
    const VTS = 90000, hasA = r.audio.length && r.aDesc;
    const { runs, total: vDur } = videoRuns(r, VTS), aDur = hasA ? r.audio.length * 1024 : 0;
    const mvDur = Math.round(Math.max(vDur / VTS, hasA ? aDur / r.rate : 0) * 1000);
    const sync = r.video.map((s, i) => s.key ? i : -1).filter(i => i >= 0);
    const build = (vOff, aOff) => box('moov',
      full('mvhd', 0, 0, u32(0), u32(0), u32(1000), u32(mvDur), u32(0x10000), u16(0x0100), zeros(10), MATRIX, zeros(24), u32(hasA ? 3 : 2)),
      trak(1, 'vide', VTS, vDur, Math.round(vDur / VTS * 1000), stbl(avc1(r), r.video, runs, vOff, sync), r.w, r.h),
      ...(hasA ? [trak(2, 'soun', r.rate, aDur, Math.round(aDur / r.rate * 1000), stbl(mp4a(r), r.audio, [[r.audio.length, 1024]], aOff, null))] : []));
    const ftyp = box('ftyp', str('isom'), u32(512), str('isom'), str('iso2'), str('avc1'), str('mp41'));
    // offsets depend on the moov's size, which doesn't depend on the offsets' values: build once to measure
    const placeholder = build(r.video.map(() => 0), r.audio.map(() => 0));
    let at = ftyp.length + placeholder.length + 8;
    const vOff = r.video.map(s => { const o = at; at += s.data.length; return o; });
    const aOff = hasA ? r.audio.map(s => { const o = at; at += s.data.length; return o; }) : [];
    const moov = build(vOff, aOff);
    const payload = at - (ftyp.length + moov.length + 8);
    if (at > 0xffffffff) throw new Error('recording is over 4 GB');
    const parts = [ftyp, moov, u32(payload + 8), str('mdat')];
    for (const s of r.video) parts.push(s.data);
    if (hasA) for (const s of r.audio) parts.push(s.data);
    return new Blob(parts);
  }
  const capture = () => { if (R && R.grab) R.grab(); };
  // hold: leave a stretch out of a live recording (pictures and sound); the recording carries on afterwards as if it
  // had never stopped (used while a cut is pre-drawn, so the video has no frozen pause in it)
  function hold(on) {
    const r = R; if (!r || r.offline || r.stopped || !!on === !!r.holding) return;
    if (on) { r.holding = true; r.holdAt = performance.now(); }
    else { r.t0 += performance.now() - r.holdAt; r.holding = false; }
    if (r.tap && r.tap.hold) r.tap.hold(!!on);
  }
  const api = { supported, start, startOffline, stop, cancel, capture, hold, stats: null };
  return api;
})();
