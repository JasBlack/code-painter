'use strict';
// ─────────────────────────────────────────────────────────────
//  Auto-painter worker: rebuilds a target image one gradient shape at a time.
//  Each step samples candidate shapes where the error is largest; for each
//  candidate both gradient colours are solved exactly (weighted least squares
//  over the pixels it covers, with feathered alpha for soft blobs), the best is
//  hill-climbed, committed and posted to the page, which draws it and writes
//  its line of code. Sizes shrink as it goes: big washes first, fine textured
//  strokes last.
//  Smart mode (image analysis, computed once per painting):
//    flow   structure tensor -> edge direction + coherence per pixel; strokes are
//           grown along the flow like a brush following a contour, other shapes
//           align to it, gradients run across edges
//    focus  saliency from local contrast, edge density, skin tones and a centre
//           bias; errors there count more, so faces / focal points resolve first
//    edges  in the last part, half the strokes go to strong edges, thinner
// ─────────────────────────────────────────────────────────────
if (typeof SHP === 'undefined') importScripts('shapes.js');     // (a self-contained page puts the shapes in front of this)

let W = 0, H = 0, T = null, C = null, running = false, count = 0, maxShapes = 3000, seed = 1;
let errMap = null, cum = null, cumTotal = 0, sim = 0, gen = 0;
let abstract = false, smart = false, Tan = null, Coh = null, Edge = null, Wt = null, cumE = null, cumETotal = 0;
let Sub = null, Sal = null;       // subject mask (0 background … 1 subject), and the saliency it starts from
let spans = new Int32Array(3 * 8192), tBuf = new Float32Array(1), aBuf = new Float32Array(1);
const xs = new Float32Array(256);

const rnd = () => { seed ^= seed << 13; seed >>>= 0; seed ^= seed >>> 17; seed ^= seed << 5; seed >>>= 0; return seed / 4294967296; };
const gauss = () => { let u = 0, v = 0; while (!u) u = rnd(); while (!v) v = rnd(); return Math.sqrt(-2 * Math.log(u)) * Math.cos(6.2832 * v); };
const lerp = (a, b, t) => a + (b - a) * t;

// ── image analysis for smart mode ───────────────────────────
// separable box blur (applied twice ≈ gaussian)
function boxBlur(src, r) {
  const out = new Float32Array(W * H), tmp = new Float32Array(W * H);
  for (let y = 0; y < H; y++) {
    let s = 0; const row = y * W;
    for (let x = -r; x <= r; x++) s += src[row + Math.min(W - 1, Math.max(0, x))];
    for (let x = 0; x < W; x++) { tmp[row + x] = s / (2 * r + 1); s += src[row + Math.min(W - 1, x + r + 1)] - src[row + Math.max(0, x - r)]; }
  }
  for (let x = 0; x < W; x++) {
    let s = 0;
    for (let y = -r; y <= r; y++) s += tmp[Math.min(H - 1, Math.max(0, y)) * W + x];
    for (let y = 0; y < H; y++) { out[y * W + x] = s / (2 * r + 1); s += tmp[Math.min(H - 1, y + r + 1) * W + x] - tmp[Math.max(0, y - r) * W + x]; }
  }
  return out;
}
const blur2 = (a, r) => boxBlur(boxBlur(a, r), r);
function pctl(a, q) { const s = Float32Array.from(a).sort(); return s[Math.min(s.length - 1, Math.floor(q * s.length))] || 1e-6; }
function analyse() {
  const n = W * H, L = new Float32Array(n), Y = new Float32Array(n), Cb = new Float32Array(n), Cr = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    const r = T[i * 3], g = T[i * 3 + 1], b = T[i * 3 + 2];
    Y[i] = 0.299 * r + 0.587 * g + 0.114 * b; L[i] = Y[i] / 255;
    Cb[i] = 128 - 0.168736 * r - 0.331264 * g + 0.5 * b; Cr[i] = 128 + 0.5 * r - 0.418688 * g - 0.081312 * b;
  }
  // structure tensor from Sobel gradients -> edge tangent direction, coherence, edge strength
  const jxx = new Float32Array(n), jxy = new Float32Array(n), jyy = new Float32Array(n);
  const at = (x, y) => L[Math.min(H - 1, Math.max(0, y)) * W + Math.min(W - 1, Math.max(0, x))];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const gx = at(x + 1, y - 1) + 2 * at(x + 1, y) + at(x + 1, y + 1) - at(x - 1, y - 1) - 2 * at(x - 1, y) - at(x - 1, y + 1);
    const gy = at(x - 1, y + 1) + 2 * at(x, y + 1) + at(x + 1, y + 1) - at(x - 1, y - 1) - 2 * at(x, y - 1) - at(x + 1, y - 1);
    const i = y * W + x; jxx[i] = gx * gx; jxy[i] = gx * gy; jyy[i] = gy * gy;
  }
  const r = Math.max(2, Math.round(Math.max(W, H) / 110));
  const a = blur2(jxx, r), b = blur2(jxy, r), c = blur2(jyy, r);
  Tan = new Float32Array(n); Coh = new Float32Array(n); Edge = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    // (running-sum blurs can dip a hair below zero on flat areas; sqrt of that would be NaN and poison the maps)
    const d = a[i] - c[i], tr = Math.max(0, a[i] + c[i]);
    Tan[i] = 0.5 * Math.atan2(2 * b[i], d) + Math.PI / 2;           // along the edge (perpendicular to the gradient)
    Coh[i] = tr > 1e-6 ? Math.sqrt(d * d + 4 * b[i] * b[i]) / tr : 0;
    Edge[i] = Math.sqrt(tr);
  }
  const e98 = pctl(Edge, 0.98); for (let i = 0; i < n; i++) Edge[i] = Math.min(1, Edge[i] / e98);
  // focus map: local colour contrast + edge density + skin tones, with a gentle centre bias
  const R = Math.max(4, Math.round(Math.max(W, H) / 30));
  const bY = blur2(Y, R), bCb = blur2(Cb, R), bCr = blur2(Cr, R), con = new Float32Array(n), skin = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    con[i] = Math.abs(Y[i] - bY[i]) + 0.6 * (Math.abs(Cb[i] - bCb[i]) + Math.abs(Cr[i] - bCr[i]));
    skin[i] = Y[i] > 45 ? Math.exp(-(((Cb[i] - 102) / 16) ** 2) - (((Cr[i] - 153) / 14) ** 2)) : 0;
  }
  const conB = blur2(con, 3), skinB = blur2(skin, 3), edgeB = blur2(Edge, 3), c98 = pctl(conB, 0.98);
  Wt = new Float32Array(n); Sal = new Float32Array(n); let sum = 0;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, dx = (x / W - 0.5) * 2, dy = (y / H - 0.5) * 2;
    const sal = Math.min(1, 0.45 * Math.min(1, conB[i] / c98) + 0.35 * edgeB[i] + 0.6 * skinB[i]) * (1 - 0.2 * (dx * dx + dy * dy));
    Wt[i] = Number.isFinite(sal) ? 0.45 + 1.8 * sal : 1; sum += Wt[i]; Sal[i] = Number.isFinite(sal) ? sal : 0;
  }
  if (sum > 0) for (let i = 0; i < n; i++) Wt[i] *= n / sum;       // mean weight 1
  subject();
}
// subject / background: the focal parts (contrast, edges, skin, a little towards the middle) that don't share the colours
// found round the picture's border are the subject. Smoothed into whole regions, then split where the score naturally
// divides (Otsu), keeping the subject between 12% and 65% of the picture; a soft edge.
function subject() {
  const n = W * H, m = Math.max(2, Math.round(Math.min(W, H) * 0.04)), bs = [];
  for (let y = 0; y < H; y += 2) for (let x = 0; x < W; x += 2) if (x < m || y < m || x >= W - m || y >= H - m) { const o = (y * W + x) * 3; bs.push([T[o], T[o + 1], T[o + 2]]); }
  const K = Math.min(5, bs.length), C = [];
  for (let k = 0; k < K; k++) C.push(bs[Math.floor((k + 0.5) / K * bs.length)].slice());
  for (let it = 0; it < 8; it++) {
    const acc = C.map(() => [0, 0, 0, 0]);
    for (const b of bs) { let bk = 0, bd = 1e18; for (let k = 0; k < K; k++) { const d = (b[0] - C[k][0]) ** 2 + (b[1] - C[k][1]) ** 2 + (b[2] - C[k][2]) ** 2; if (d < bd) { bd = d; bk = k; } } const a = acc[bk]; a[0] += b[0]; a[1] += b[1]; a[2] += b[2]; a[3]++; }
    acc.forEach((a, k) => { if (a[3]) C[k] = [a[0] / a[3], a[1] / a[3], a[2] / a[3]]; });
  }
  const sc = new Float32Array(n), sig = 2 * 32 * 32;
  for (let i = 0; i < n; i++) {
    const o = i * 3; let dm = 1e18;
    for (let k = 0; k < K; k++) { const d = (T[o] - C[k][0]) ** 2 + (T[o + 1] - C[k][1]) ** 2 + (T[o + 2] - C[k][2]) ** 2; if (d < dm) dm = d; }
    const x = i % W, y = (i / W) | 0, dx = (x / W - 0.5) * 2, dy = (y / H - 0.5) * 2;
    sc[i] = 0.6 * Sal[i] + 0.8 * (1 - Math.exp(-dm / sig)) + 0.3 * (1 - Math.min(1, (dx * dx + dy * dy) / 1.6));
  }
  const sb = blur2(sc, Math.max(2, Math.round(Math.max(W, H) / 55)));
  let lo = 1e9, hi = -1e9; for (let i = 0; i < n; i++) { if (sb[i] < lo) lo = sb[i]; if (sb[i] > hi) hi = sb[i]; }
  const B = 64, hist = new Float64Array(B), span = Math.max(1e-6, hi - lo);
  for (let i = 0; i < n; i++) hist[Math.min(B - 1, Math.floor((sb[i] - lo) / span * B))]++;
  let tot = 0; for (let b = 0; b < B; b++) tot += b * hist[b];
  let w0 = 0, s0 = 0, best = -1, thb = B / 2;
  for (let b = 0; b < B; b++) { w0 += hist[b]; if (!w0 || w0 === n) continue; s0 += b * hist[b]; const m0 = s0 / w0, m1 = (tot - s0) / (n - w0), v = w0 * (n - w0) * (m0 - m1) ** 2; if (v > best) { best = v; thb = b + 1; } }
  const thr = Math.min(pctl(sb, 0.88), Math.max(pctl(sb, 0.35), lo + thb / B * span)), soft = 0.06 * span;
  Sub = new Float32Array(n);
  for (let i = 0; i < n; i++) { const t = Math.max(0, Math.min(1, (sb[i] - thr) / soft + 0.5)); Sub[i] = t * t * (3 - 2 * t); }
  // the background reaches the picture's edge: a "background" patch enclosed by the subject (a dark eye, a shadow
  // inside the face) is part of the subject
  const seen = new Uint8Array(n), q = new Int32Array(n); let head = 0, tail = 0;
  const push = i => { if (!seen[i] && Sub[i] < 0.5) { seen[i] = 1; q[tail++] = i; } };
  for (let x = 0; x < W; x++) { push(x); push((H - 1) * W + x); }
  for (let y = 0; y < H; y++) { push(y * W); push(y * W + W - 1); }
  while (head < tail) { const i = q[head++], x = i % W; if (x > 0) push(i - 1); if (x < W - 1) push(i + 1); if (i >= W) push(i - W); if (i < n - W) push(i + W); }
  for (let i = 0; i < n; i++) if (Sub[i] < 0.5 && !seen[i]) Sub[i] = 1;
}
// the mask as bytes, for the page (to show which part is which)
const maskBytes = () => { const b = new Uint8ClampedArray(W * H); for (let i = 0; i < b.length; i++) b[i] = Sub[i] * 255; return b; };
const pix = (x, y) => Math.min(H - 1, Math.max(0, y | 0)) * W + Math.min(W - 1, Math.max(0, x | 0));
// follow the flow field from (x, y) for `len` pixels in direction sgn (streamline, keeps a consistent heading)
function trace(x, y, sgn, len) {
  const i0 = pix(x, y); let dx = Math.cos(Tan[i0]) * sgn, dy = Math.sin(Tan[i0]) * sgn, d = 0;
  const st = Math.max(1, len / 24);
  while (d < len) {
    const j = pix(x, y);
    if (Coh[j] > 0.08) { let tx = Math.cos(Tan[j]), ty = Math.sin(Tan[j]); if (tx * dx + ty * dy < 0) { tx = -tx; ty = -ty; } dx = tx; dy = ty; }
    x += dx * st; y += dy * st; d += st;
  }
  return [x, y];
}
const cl255 = v => v < 0 ? 0 : v > 255 ? 255 : v;

// scanline fill of a flat polygon at pixel centres -> spans [y, x0, x1]
function raster(pts) {
  const n = pts.length >> 1; let y0 = 1e9, y1 = -1e9, ns = 0;
  for (let i = 1; i < pts.length; i += 2) { if (pts[i] < y0) y0 = pts[i]; if (pts[i] > y1) y1 = pts[i]; }
  y0 = Math.max(0, Math.ceil(y0 - 0.5)); y1 = Math.min(H - 1, Math.floor(y1 - 0.5));
  for (let y = y0; y <= y1; y++) {
    const yc = y + 0.5; let k = 0;
    for (let i = 0; i < n; i++) {
      const ax = pts[i * 2], ay = pts[i * 2 + 1], j = (i + 1) % n, bx = pts[j * 2], by = pts[j * 2 + 1];
      if ((ay <= yc && by > yc) || (by <= yc && ay > yc)) { if (k < 256) xs[k++] = ax + (yc - ay) * (bx - ax) / (by - ay); }
    }
    for (let a = 1; a < k; a++) { const v = xs[a]; let b = a - 1; while (b >= 0 && xs[b] > v) { xs[b + 1] = xs[b]; b--; } xs[b + 1] = v; }
    for (let j = 0; j + 1 < k; j += 2) {
      const xa = Math.max(0, Math.ceil(xs[j] - 0.5)), xb = Math.min(W - 1, Math.floor(xs[j + 1] - 0.5));
      if (xb >= xa && ns < spans.length / 3) { spans[ns * 3] = y; spans[ns * 3 + 1] = xa; spans[ns * 3 + 2] = xb; ns++; }
    }
  }
  return ns;
}
// per-pixel gradient parameter t and alpha for the shape (into tBuf/aBuf, in span order)
function field(s, ns) {
  const a = s.a; let j = 0;
  if (s.t === 'B') {
    const [ex, ey, rx, ry, r, f] = s.p, c = Math.cos(r), n = Math.sin(r);
    for (let i = 0; i < ns; i++) {
      const py = spans[i * 3] + 0.5;
      for (let x = spans[i * 3 + 1]; x <= spans[i * 3 + 2]; x++, j++) {
        const dx = x + 0.5 - ex, dy = py - ey, u = (dx * c + dy * n) / rx, v = (-dx * n + dy * c) / ry, k = Math.sqrt(u * u + v * v);
        tBuf[j] = k < 1 ? k : 1; aBuf[j] = k >= 1 ? 0 : a * Math.min(1, (1 - k) / f);
      }
    }
  } else {
    const [gx, gy, m, M] = SHP.axis(s), inv = 1 / Math.max(1e-6, M - m);
    for (let i = 0; i < ns; i++) {
      const py = spans[i * 3] + 0.5;
      for (let x = spans[i * 3 + 1]; x <= spans[i * 3 + 2]; x++, j++) {
        const t = s.fl ? 0 : ((x + 0.5) * gx + py * gy - m) * inv;
        tBuf[j] = t < 0 ? 0 : t > 1 ? 1 : t; aBuf[j] = a;
      }
    }
  }
  return j;
}
// solve both gradient colours, return the change in squared error if painted
// (in smart mode every pixel's error is weighted by the focus map)
function evaluate(s) {
  const ns = raster(SHP.poly(s)); if (!ns) return Infinity;
  const np = field(s, ns); if (np < 2) return Infinity;
  let A00 = 0, A01 = 0, A11 = 0, n = 0;
  const b0 = [0, 0, 0], b1 = [0, 0, 0], wmap = smart ? Wt : null;
  let j = 0;
  for (let i = 0; i < ns; i++) {
    const row = spans[i * 3] * W;
    for (let x = spans[i * 3 + 1]; x <= spans[i * 3 + 2]; x++, j++) {
      const ai = aBuf[j]; if (ai <= 0) continue;
      const wp = wmap ? wmap[row + x] : 1, t = tBuf[j], u = 1 - t, w = ai * ai * wp, ia = 1 - ai, o = (row + x) * 3;
      A00 += w * u * u; A01 += w * u * t; A11 += w * t * t; n++;
      for (let ch = 0; ch < 3; ch++) { const e = (T[o + ch] - C[o + ch] * ia) * ai * wp; b0[ch] += u * e; b1[ch] += t * e; }
    }
  }
  if (n < 2) return Infinity;
  // small ridge towards c0 == c1, so a gradient only appears when the pixels ask for one
  const lam = 0.02 * (A00 + A11) + 1e-6, a00 = A00 + lam, a01 = A01 - lam, a11 = A11 + lam, det = a00 * a11 - a01 * a01;
  let c0 = [0, 0, 0], c1 = [0, 0, 0];
  if (PAL) {
    // palette lock: the pair of palette colours that fits these pixels best (the same squared error, from the sums above)
    let best = Infinity, bi = 0, bj = 0;
    for (let i = 0; i < PAL.length; i++) for (let k = 0; k < PAL.length; k++) {
      if (s.fl && k !== i) continue;
      const P = PAL[i], Q = PAL[k]; let q = 0;
      for (let ch = 0; ch < 3; ch++) q += P[ch] * P[ch] * A00 + 2 * P[ch] * Q[ch] * A01 + Q[ch] * Q[ch] * A11 - 2 * P[ch] * b0[ch] - 2 * Q[ch] * b1[ch];
      if (q < best) { best = q; bi = i; bj = k; }
    }
    c0 = PAL[bi].slice(); c1 = PAL[bj].slice();
  } else for (let ch = 0; ch < 3; ch++) { c0[ch] = cl255((b0[ch] * a11 - b1[ch] * a01) / det); c1[ch] = cl255((a00 * b1[ch] - a01 * b0[ch]) / det); }
  // charcoal draws in greys (a breath of the colour left in), so it is scored in them too
  if (s.st === 'charcoal' && !PAL) for (const c of [c0, c1]) { const g = c[0] * 0.3 + c[1] * 0.59 + c[2] * 0.11; for (let ch = 0; ch < 3; ch++) c[ch] = g + (c[ch] - g) * 0.12; }
  let d = 0; j = 0;
  for (let i = 0; i < ns; i++) {
    const row = spans[i * 3] * W;
    for (let x = spans[i * 3 + 1]; x <= spans[i * 3 + 2]; x++, j++) {
      const ai = aBuf[j]; if (ai <= 0) continue;
      const t = tBuf[j], ia = 1 - ai, o = (row + x) * 3, wp = wmap ? wmap[row + x] : 1;
      for (let ch = 0; ch < 3; ch++) {
        const tv = T[o + ch], cv = C[o + ch], nv = cv * ia + (c0[ch] + (c1[ch] - c0[ch]) * t) * ai - tv;
        d += (nv * nv - (cv - tv) * (cv - tv)) * wp;
      }
    }
  }
  s.c0 = c0; s.c1 = c1;
  return d;
}
function commit(s) {   // call right after evaluate(s): reuses its spans / field
  const ns = raster(SHP.poly(s)); field(s, ns);
  let j = 0;
  for (let i = 0; i < ns; i++) {
    const row = spans[i * 3] * W;
    for (let x = spans[i * 3 + 1]; x <= spans[i * 3 + 2]; x++, j++) {
      const ai = aBuf[j]; if (ai <= 0) continue;
      const t = tBuf[j], ia = 1 - ai, o = (row + x) * 3;
      let e = 0;
      for (let ch = 0; ch < 3; ch++) { C[o + ch] = C[o + ch] * ia + (s.c0[ch] + (s.c1[ch] - s.c0[ch]) * t) * ai; e += Math.abs(C[o + ch] - T[o + ch]); }
      errMap[row + x] = e;
    }
  }
}
// sampling tables: where to try next (error², weighted by focus; a second table also favours strong edges)
let band = null;          // [firstRow, endRow): live modes with several painters; each only picks places in its own rows
function rebuildCum() {
  let t = 0, s = 0, te = 0;
  const b0 = band ? band[0] * W : 0, b1 = band ? band[1] * W : W * H;
  const ok = ORD ? ORD.key : null, lo = ORD ? passNo / ORD.K - 1e-6 : 0, hi = ORD ? (passNo >= ORD.K - 1 ? 2 : (passNo + 1) / ORD.K) : 2;
  for (let i = 0; i < W * H; i++) {
    const e = errMap[i] * errMap[i] + 1, w = (smart ? e * Wt[i] : e) * (i >= b0 && i < b1 ? 1 : 0) * (ok ? (ok[i] >= lo && ok[i] < hi ? 1 : 0) : 1);
    t += w; cum[i] = t; s += errMap[i];
    if (smart) { te += w * (0.15 + 3 * Edge[i] * Edge[i]); cumE[i] = te; }
  }
  cumTotal = t; cumETotal = te; sim = 100 * (1 - s / (3 * W * H) / 255);
}
function samplePos(edges) {
  if (abstract && !ORD && rnd() < 0.3) return [rnd() * W, band ? band[0] + rnd() * (band[1] - band[0]) : rnd() * H];     // abstract: some strokes go anywhere (in its band)
  const tab = edges ? cumE : cum, r = rnd() * (edges ? cumETotal : cumTotal); let lo = 0, hi = W * H - 1;
  while (lo < hi) { const m = (lo + hi) >> 1; if (tab[m] < r) lo = m + 1; else hi = m; }
  return [lo % W + rnd(), (lo / W | 0) + rnd()];
}
const MIX = {
  painterly: [['S', 0.45], ['B', 0.25], ['E', 0.15], ['T', 0.15]],
  soft: [['B', 0.75], ['S', 0.25]],
  mixed: [['E', 0.2], ['B', 0.2], ['T', 0.2], ['R', 0.15], ['S', 0.25]],
  geometric: [['T', 0.55], ['R', 0.45]],
  bubbles: [['B', 0.55], ['E', 0.45]],
  flat: [['S', 0.6], ['E', 0.25], ['T', 0.15]],
  points: [['E', 1]],                                  // pointillism: round dots
  hatch: [['S', 0.88], ['B', 0.12]],                   // pen cross-hatching (+ a few washes for the first coverage)
  calligraphy: [['S', 0.85], ['B', 0.15]],             // long flowing strokes of varying width
  watercolour: [['B', 0.7], ['E', 0.3]],               // thin transparent washes, layered
  confetti: [['R', 0.7], ['T', 0.3]],                  // small bright slips and flakes
  graffiti: [['S', 0.82], ['B', 0.18]],                // spray-can strokes and bursts (the page sprays them: haze, speckles, drips)
  clay: [['S', 0.55], ['B', 0.3], ['E', 0.15]],        // claymation: fat plasticine sausages and lumps (the page shades them)
  relief: [['S', 0.55], ['B', 0.2], ['E', 0.25]],      // 3D relief: strokes embossed into the surface (the page shades them)
  // the newer styles (the page draws each in its own way; here they are shaped so the scoring matches)
  mosaic: [['R', 1]],                                  // square tiles on a grid (halving sizes, so small tiles fit big ones)
  glass: [['T', 1]],                                   // stained-glass pieces
  scribble: [['B', 0.45], ['E', 0.35], ['T', 0.2]],    // areas the page scribbles in with a pen
  halftone: [['E', 0.35], ['B', 0.25], ['R', 0.2], ['T', 0.2]],
  string: [['S', 0.85], ['B', 0.15]],                  // long straight threads (a few washes first)
  glitch: [['R', 1]],                                  // level bars
  bokeh: [['E', 1]],                                   // round lights
  paper: [['T', 0.35], ['R', 0.3], ['E', 0.2], ['B', 0.15]],
  stitch: [['B', 0.5], ['E', 0.25], ['R', 0.25]],
  // drawing media (the page draws them; strokes for the line media, areas the page shades or washes)
  pencil: [['S', 1]],      // coloured pencil: grainy lines, areas shaded with close strokes
  pastel: [['S', 0.6], ['B', 0.25], ['E', 0.15]],      // soft pastel: chalky strokes, smudged patches
  pen: [['B', 0.35], ['E', 0.3], ['T', 0.2], ['S', 0.15]],   // fine-liner: outlines and contours over pale washes
  ink: [['S', 0.75], ['B', 0.25]],                     // ink brush: swelling, tapering strokes, ink pools
  wash: [['B', 0.55], ['E', 0.3], ['T', 0.15]],
  wet: [['B', 0.5], ['E', 0.28], ['S', 0.12], ['T', 0.1]],
  thread: [['S', 0.62], ['E', 0.16], ['R', 0.12], ['T', 0.1]],         // embroidery: satin stitches across strokes, rows of stitches filling shapes
  plast: [['B', 0.34], ['E', 0.24], ['S', 0.32], ['R', 0.1]],           // plasticine: matte pieces pressed on        // watercolour (wet-in-wet, tide lines): two-colour washes        // watercolour shapes: wet-edged washes
  charcoal: [['S', 1]]                   // charcoal: dusty, smudged greys
};
let stepProg = 0;
// several styles can be ticked at once: every candidate stroke picks one of them and is finished in it
let styles = ['painterly'], stepStyle = 'painterly';   // each committed stroke picks its style first, so the ticked mix is shared evenly
let bgStyles = [], stepBg = null;                       // background styles (none: the same styles everywhere)
const FLAT = new Set(['flat', 'points', 'confetti', 'hatch', 'graffiti', 'clay', 'relief', 'mosaic', 'scribble', 'string', 'bokeh', 'paper', 'stitch', 'pencil', 'pastel', 'pen', 'ink', 'wash', 'charcoal', 'thread', 'plast']);        // single-colour marks so dots / flakes / lines read as such
const SMALL = { points: 0.028, confetti: 0.04 };                      // dots and flakes stay small once the first washes are down
function pickType(st) {
  if ((st === 'hatch' || st === 'calligraphy' || st === 'string') && stepProg > 0.12) return 'S';
       // washes only for the first coverage
  const m = MIX[st] || MIX.painterly; let r = rnd(); for (const [t, w] of m) { if ((r -= w) <= 0) return t; } return m[0][0];
}
// a candidate shape: guided by the image's flow in smart mode (abstract mode sends half of them off unguided),
// then finished in its style
function randomShape(smin, smax, prog) {
  let st = stepStyle, pos = null;
  // subject / background styles: the candidate's spot decides which style it is painted in
  if (stepBg && Sub) {
    const edges = smart && prog > 0.55 && rnd() < 0.5; pos = samplePos(edges); pos.edges = edges;
    if (Sub[pix(pos[0], pos[1])] < 0.5) st = stepBg;
  }
  if (SMALL[st] && prog > 0.06) { const cap = Math.max(W, H) * SMALL[st]; if (smax > cap) { smin *= cap / smax; smax = cap; } }
  if (abstract) { const k = lerp(0.7, 1.9, rnd()); smin *= k; smax *= k; }
  const t = pickType(st), s = smart && !(abstract && rnd() < 0.5) ? guidedShape(smin, smax, prog, t, st, pos) : plainShape(smin, smax, t, pos);
  s.st = st; s.fl = FLAT.has(st);
  return styled(s, st);
}
// a stroke made k times longer about its middle (drawn strokes, not dabs)
function longer(p, k) { const cx = (p[0] + p[4]) / 2, cy = (p[1] + p[5]) / 2; for (const i of [0, 2, 4]) { p[i] = cx + (p[i] - cx) * k; p[i + 1] = cy + (p[i + 1] - cy) * k; } }
function styled(s, st) {
  const p = s.p;
  if (st === 'points' && s.t === 'E') { p[2] = p[3] = Math.max(1, Math.min(p[2], p[3])); s.a = 0.92; }
  else if (st === 'hatch' && s.t === 'S') {            // straight lines at ±45°, like pen hatching
    const cx = (p[0] + p[4]) / 2, cy = (p[1] + p[5]) / 2, len = Math.max(Math.hypot(p[4] - p[0], p[5] - p[1]) * 0.6, Math.max(W, H) * 0.03), ang = (rnd() < 0.5 ? 0.785 : 2.356) + gauss() * 0.08;
    p[0] = cx - Math.cos(ang) * len; p[1] = cy - Math.sin(ang) * len; p[4] = cx + Math.cos(ang) * len; p[5] = cy + Math.sin(ang) * len;
    p[2] = cx; p[3] = cy; p[6] = lerp(0.6, 1.5, rnd()); s.a = 0.9;     // thin pen lines
  } else if (st === 'calligraphy' && s.t === 'S') { p[6] = Math.max(1, p[6] * lerp(0.35, 1.4, rnd())); s.a = 0.95; }
  else if (st === 'watercolour') { s.a = lerp(0.3, 0.55, rnd()); if (s.t === 'B') p[5] = lerp(0.6, 1, rnd()); }
  else if (st === 'confetti') s.a = 0.95;
  else if (st === 'clay') { s.a = 1; if (s.t === 'S') p[6] = Math.max(2, p[6] * lerp(1.4, 2.1, rnd())); else if (s.t === 'B') p[5] = 0.18; }
  else if (st === 'relief') { s.a = 1; if (s.t === 'B') p[5] = 0.18; }
  else if (st === 'graffiti') { if (s.t === 'S') { p[6] = Math.max(1.5, p[6] * lerp(1.1, 1.7, rnd())); s.a = 0.92; } else if (s.t === 'B') { s.a = 0.85; p[5] = lerp(0.7, 1, rnd()); } }
  else if (st === 'mosaic' || st === 'glitch') s.a = 1;
  else if (st === 'glass') s.a = 0.9;
  else if (st === 'scribble' || st === 'paper' || st === 'stitch' || st === 'halftone') { s.a = 1; if (s.t === 'B') p[5] = 0.12; }
  else if (st === 'bokeh') { s.a = lerp(0.45, 0.75, rnd()); p[2] = p[3] = (p[2] + p[3]) / 2; }
  else if (st === 'pencil') { s.a = 0.85; if (s.t === 'S') { p[6] = Math.max(1, Math.min(4, p[6] * lerp(0.25, 0.5, rnd()))); longer(p, 1.5); } else if (s.t === 'B') p[5] = 0.12; }
  else if (st === 'pastel') { s.a = 0.92; if (s.t === 'S') p[6] = Math.max(2, p[6] * lerp(1.1, 1.5, rnd())); else if (s.t === 'B') p[5] = 0.2; }
  else if (st === 'pen') { s.a = 1; if (s.t === 'B') p[5] = 0.12; }
  else if (st === 'ink') { s.a = 0.95; if (s.t === 'S') p[6] = Math.max(1.5, p[6] * lerp(0.7, 1.5, rnd())); else if (s.t === 'B') p[5] = lerp(0.3, 0.6, rnd()); }
  else if (st === 'thread') { s.a = 1; if (s.t === 'S') p[6] = Math.max(3, p[6] * lerp(0.9, 1.6, rnd())); }
  else if (st === 'plast') { s.a = 1; if (s.t === 'S') p[6] = Math.max(3, p[6] * lerp(1.1, 1.9, rnd())); else if (s.t === 'B') p[5] = 0.12; }
  else if (st === 'wet') { s.a = lerp(0.5, 0.78, rnd()); if (s.t === 'B') p[5] = 0.15; else if (s.t === 'S') p[6] = Math.max(2, p[6] * lerp(1.1, 1.8, rnd())); }
  else if (st === 'wash') { s.a = lerp(0.45, 0.7, rnd()); if (s.t === 'B') p[5] = 0.15; }
  else if (st === 'charcoal') { s.a = 0.9; if (s.t === 'S') { p[6] = Math.max(2, p[6] * lerp(0.55, 0.9, rnd())); longer(p, 1.7); } else if (s.t === 'B') p[5] = 0.3; }
  else if (st === 'string' && s.t === 'S') {           // long and straight, through the point the painter picked
    const cx = (p[0] + p[4]) / 2, cy = (p[1] + p[5]) / 2, ang = Math.atan2(p[5] - p[1], p[4] - p[0]), half = Math.max(Math.hypot(p[4] - p[0], p[5] - p[1]) * 0.9, Math.max(W, H) * lerp(0.06, 0.2, rnd()));
    p[0] = cx - Math.cos(ang) * half; p[1] = cy - Math.sin(ang) * half; p[4] = cx + Math.cos(ang) * half; p[5] = cy + Math.sin(ang) * half; p[6] = lerp(0.9, 1.5, rnd()); s.a = 0.8;
  }
  if (st === 'glitch' && s.t === 'R') { const w = Math.max(p[2], p[3]); p[2] = w * lerp(1.8, 4.5, rnd()); p[3] = Math.max(1, Math.min(p[2], p[3], w) * lerp(0.1, 0.35, rnd())); }
  return constrain(s);
}
// shapes some styles need exactly, kept through the fine-tuning too: tiles on a grid, straight threads, level bars,
// round lights
function constrain(s) {
  const p = s.p, st = s.st, L = Math.max(W, H);
  if (st === 'mosaic' && s.t === 'R') {
    const k = Math.max(3, Math.min(8, Math.round(Math.log2(L / Math.max(1, p[2], p[3]))))), cell = Math.max(2, L / 2 ** k);
    p[2] = p[3] = cell; p[4] = 0; p[0] = (Math.floor(p[0] / cell) + 0.5) * cell; p[1] = (Math.floor(p[1] / cell) + 0.5) * cell;
  } else if (st === 'string' && s.t === 'S') {
    const dx = p[4] - p[0], dy = p[5] - p[1], d = Math.hypot(dx, dy) || 1, min = L * 0.1;
    if (d < min) { const cx = (p[0] + p[4]) / 2, cy = (p[1] + p[5]) / 2, k = min / d / 2; p[0] = cx - dx * k; p[1] = cy - dy * k; p[4] = cx + dx * k; p[5] = cy + dy * k; }
    p[2] = (p[0] + p[4]) / 2; p[3] = (p[1] + p[5]) / 2; p[6] = Math.max(0.9, Math.min(1.6, p[6]));
  } else if (st === 'glitch' && s.t === 'R') {
    p[4] = 0; p[5] = Math.cos(p[5]) >= 0 ? 0 : Math.PI; p[3] = Math.max(1, Math.min(p[3], p[2] * 0.35));
  } else if (st === 'bokeh' && s.t === 'E') p[3] = p[2];
  return s;
}
function plainShape(smin, smax, t, pos) {
  const [x, y] = pos || samplePos(), s = lerp(smin, smax, rnd()), r = rnd() * Math.PI, g = rnd() * Math.PI * 2;
  if (t === 'E') return { t, a: 0.8, p: [x, y, s * lerp(0.25, 1, rnd()), s * lerp(0.25, 1, rnd()), r, g] };
  if (t === 'B') return { t, a: 0.9, p: [x, y, s * lerp(0.35, 1.2, rnd()), s * lerp(0.35, 1.2, rnd()), r, lerp(0.25, 0.9, rnd())] };
  if (t === 'R') return { t, a: 0.8, p: [x, y, s * lerp(0.3, 1.6, rnd()), s * lerp(0.2, 1, rnd()), r, g] };
  if (t === 'T') { const p = [x, y, x, y, x, y, g]; for (let i = 0; i < 6; i++) p[i] += (rnd() - 0.5) * 2 * s; return { t, a: 0.8, p }; }
  const dx = Math.cos(r) * s, dy = Math.sin(r) * s, bend = (rnd() - 0.5) * s;
  return { t, a: 0.8, p: [x - dx, y - dy, x - dy / s * bend, y + dx / s * bend, x + dx, y + dy, Math.max(1, s * lerp(0.08, 0.35, rnd())), Math.atan2(dy, dx) + (rnd() < 0.5 ? 0 : Math.PI / 2)] };
}
// smart candidates: oriented by the flow field where the image has a clear direction,
// strokes grown along streamlines, gradients laid across edges; late on, half go to strong edges
function guidedShape(smin, smax, prog, t, st, pos) {
  const edges = pos ? pos.edges : prog > 0.55 && rnd() < 0.5;
  const [x, y] = pos || samplePos(edges), i = pix(x, y), coh = Coh[i];
  const s = lerp(smin, smax, rnd());
  const guided = rnd() < 0.3 + 0.65 * coh;
  const along = guided ? Tan[i] + gauss() * 0.12 : rnd() * Math.PI;         // edge tangent
  const across = guided ? along + Math.PI / 2 : rnd() * Math.PI * 2;         // gradient direction
  const long = guided ? lerp(0.55, 1.15, rnd()) : lerp(0.25, 1, rnd()), thin = guided ? lerp(0.18, 0.6, rnd()) : lerp(0.25, 1, rnd());
  if (t === 'E') return { t, a: 0.8, p: [x, y, s * long, s * thin, along, across] };
  if (t === 'B') return { t, a: 0.9, p: [x, y, s * lerp(0.4, 1.2, rnd()) * (guided ? 1.2 : 1), s * lerp(0.4, 1.2, rnd()) * (guided ? 0.6 : 1), along, lerp(0.25, 0.9, rnd())] };
  if (t === 'R') return { t, a: 0.8, p: [x, y, s * lerp(0.6, 1.6, rnd()), s * lerp(0.15, 0.6, rnd()), along, across] };
  if (t === 'T') { const p = [x, y, x, y, x, y, across]; for (let k = 0; k < 6; k++) p[k] += (rnd() - 0.5) * 2 * s; return { t, a: 0.8, p }; }
  const w = Math.max(1, s * (edges ? lerp(0.05, 0.16, rnd()) : lerp(0.08, 0.32, rnd())));
  if (guided) {
    const reach = st === 'calligraphy' ? s * 1.8 : s;    // calligraphy follows the flow much further
    const [x0, y0] = trace(x, y, -1, reach), [x2, y2] = trace(x, y, 1, reach);
    return { t, a: 0.8, p: [x0, y0, 2 * x - (x0 + x2) / 2, 2 * y - (y0 + y2) / 2, x2, y2, w, across] };   // quadratic through (x, y)
  }
  const dx = Math.cos(along) * s, dy = Math.sin(along) * s, bend = (rnd() - 0.5) * s;
  return { t, a: 0.8, p: [x - dx, y - dy, x - dy / s * bend, y + dx / s * bend, x + dx, y + dy, w, across] };
}
// how big a shape is (half its extent), to keep the fine-tuning inside the viewer's stroke-size range
function extentOf(s) {
  const p = s.p;
  if (s.t === 'T') return Math.max(Math.hypot(p[2] - p[0], p[3] - p[1]), Math.hypot(p[4] - p[2], p[5] - p[3]), Math.hypot(p[0] - p[4], p[1] - p[5])) / 2;
  if (s.t === 'S') return Math.max(Math.hypot(p[4] - p[0], p[5] - p[1]) / 2, p[6]);
  return Math.max(p[2], p[3]);
}
// which parameters are angles / sizes / feather for each type
const KIND = { E: 'ppssaa', B: 'ppssaf', T: 'pppppp' + 'a', R: 'ppssaa', S: 'pppppp' + 'sa' };
function mutate(s, smax) {
  const p = s.p.slice(), j = smax * 0.12, i = Math.floor(rnd() * p.length), k = KIND[s.t][i];
  if (k === 'p') p[i] += gauss() * j;
  else if (k === 's') p[i] = Math.max(1, p[i] * Math.exp(gauss() * 0.2));
  else if (k === 'a') p[i] += gauss() * 0.35;
  else if (k === 'f') p[i] = Math.max(0.12, Math.min(1, p[i] + gauss() * 0.12));
  return constrain({ t: s.t, a: s.a, p, st: s.st, fl: s.fl });
}

// rotate both colours' hue around the grey axis by the same random angle and push saturation a little
function shiftColours(s) {
  const th = gauss() * 0.4, c = Math.cos(th), n = Math.sin(th), k = 1 / Math.sqrt(3), sat = lerp(1.05, 1.35, rnd());
  for (const col of [s.c0, s.c1]) {
    const m = (col[0] + col[1] + col[2]) / 3, r = col[0] - m, g = col[1] - m, b = col[2] - m;
    const cr = k * (g - b), cg = k * (b - r), cb = k * (r - g);          // (axis × v); axis · v = 0 for a grey-centred colour
    col[0] = cl255(m + (r * c + cr * n) * sat); col[1] = cl255(m + (g * c + cg * n) * sat); col[2] = cl255(m + (b * c + cb * n) * sat);
  }
}
// ── order modes ───────────────────────────────────────────────
// Instead of attacking the biggest error wherever it is, the painter works through the picture in passes (top to
// bottom, round a spiral, …). Every pixel has a key 0…1; pass i only picks places whose key is in its slice, and
// within a pass the usual coarse-to-fine order applies (washes, then detail), so each slice is finished before the next.
let ORD = null, passNo = 0, passStart = 0, passLen = 1, passFails = 0;
function orderSetup(kind, c0) {
  ORD = null;
  const KINDS = ['down', 'up', 'right', 'left', 'diag', 'spiral', 'spiralin', 'rings', 'ringsin', 'clock'];
  if (!KINDS.includes(kind)) return;
  const key = new Float32Array(W * H), L = Math.max(W, H), cx = W / 2, cy = H / 2, short = Math.min(W, H), TURNS = 3;
  const spiral = kind === 'spiral' || kind === 'spiralin', rings = kind === 'rings' || kind === 'ringsin', clock = kind === 'clock';
  const K = Math.max(2, Math.min(spiral ? 30 : rings ? 10 : clock ? 16 : 12, Math.round(maxShapes / 20)));
  let thick = L / K;
  if (kind === 'down' || kind === 'up') thick = H / K; else if (kind === 'left' || kind === 'right') thick = W / K;
  else if (kind === 'diag') thick = (W + H) / (2 * K);
  else if (spiral) thick = short / (2 * TURNS); else if (rings) thick = short / (2 * K); else if (clock) thick = Math.sqrt(W * H / K);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    const i = y * W + x, u = (x + 0.5 - cx) / cx, v = (y + 0.5 - cy) / cy; let k;
    if (kind === 'down') k = (y + 0.5) / H; else if (kind === 'up') k = 1 - (y + 0.5) / H;
    else if (kind === 'right') k = (x + 0.5) / W; else if (kind === 'left') k = 1 - (x + 0.5) / W;
    else if (kind === 'diag') k = ((x + 0.5) / W + (y + 0.5) / H) / 2;
    else {
      const r = Math.pow(Math.pow(Math.abs(u), 4) + Math.pow(Math.abs(v), 4), 0.25) / 1.1892;         // 0 in the middle … 1 in the corners (a rounded square, like the picture)
      const phi = ((Math.atan2(u, -v) + 2 * Math.PI) % (2 * Math.PI)) / (2 * Math.PI);                   // 0 at 12 o'clock, clockwise
      if (clock) k = phi;
      else if (rings) k = Math.min(1, r);
      else { const lap = Math.round(Math.min(1, r) * TURNS - phi); k = Math.min(1, Math.max(0, (lap + phi) / TURNS)); }
    }
    key[i] = Math.min(0.9999, Math.max(0, kind === 'spiralin' || kind === 'ringsin' ? 1 - k : k));
  }
  ORD = { key, K, thick };
  passNo = Math.min(K - 1, Math.floor((c0 || 0) * K / Math.max(1, maxShapes))); passStart = c0 || 0; passFails = 0;
  passLen = Math.max(1, (maxShapes - passStart) / (K - passNo));
}
function advancePass() {
  passNo++; passStart = count; passFails = 0; passLen = Math.max(1, (maxShapes - count) / (ORD.K - passNo));
  rebuildCum();
}

// ── one line, painted: a pen that never lifts ──────────────────
// Every stroke starts exactly where the last one ended. The pen wanders where the picture is most wrong near it, in
// whatever styles are ticked (ink, graffiti, paint …), takes whatever colour the picture needs there (so the colour
// changes as it goes), and paints over itself freely; early strokes are long and broad, late ones short and fine.
let PEN = false, penPos = null;
const NO_STROKE = new Set(['mosaic', 'glitch']);      // styles that only know how to draw bars: the pen draws plain strokes instead
function penStep(prog, tag) {
  const L = Math.max(W, H); stepProg = prog; stepStyle = styles[Math.floor(rnd() * styles.length)] || 'painterly';
  if (NO_STROKE.has(stepStyle)) stepStyle = 'flat';
  const kk = sizeRand ? Math.pow(2, rnd() * 5.32 - 3.32) : sizeK;
  let smax = Math.min(L * 0.9, L * lerp(0.45, 0.012, Math.pow(prog, 0.5)) * kk);
  if (under) smax = Math.min(smax, L * 0.1 * Math.max(1, kk));
  if (ORD) smax = Math.min(smax, Math.max(ORD.thick, L * 0.02));
  const smin = smax * 0.3, reach = Math.max(8, smax * 2.4);
  if (count % 8 === 0) rebuildCum();
  const sx0 = penPos ? penPos[0] : 0, sy0 = penPos ? penPos[1] : 0;
  // where the pen could go next: spots near it, the ones with the most wrong picture first
  const spots = [];
  // (with an order: only spots in the part being worked on; the pen travels on to the next part as a thin line, like a scanner head)
  const lo = ORD ? passNo / ORD.K - 1e-6 : 0, hi = ORD ? (passNo >= ORD.K - 1 ? 2 : (passNo + 1) / ORD.K) : 2;
  const inWin = (x, y) => !ORD || (ORD.key[pix(x, y)] >= lo && ORD.key[pix(x, y)] < hi);
  for (let i = 0; i < 28 || (ORD && spots.length < 6 && i < 90); i++) {
    let x, y;
    if (!penPos || (ORD && i >= 28)) { [x, y] = samplePos(prog > 0.55 && rnd() < 0.5); }
    else { const a = rnd() * 6.2832, d = reach * Math.sqrt(rnd()) * (0.35 + 0.65 * rnd()); x = Math.min(W - 1, Math.max(0, sx0 + Math.cos(a) * d)); y = Math.min(H - 1, Math.max(0, sy0 + Math.sin(a) * d)); }
    if (!inWin(x, y)) continue;
    const k = pix(x, y); spots.push([x, y, (errMap[k] * errMap[k] + 1) * (smart ? Wt[k] : 1) * (0.4 + rnd())]);
  }
  if (penPos && ORD && spots.length > 1) { const near = (s) => Math.hypot(s[0] - sx0, s[1] - sy0); if (spots.every(s => near(s) > reach)) spots.sort((a, b) => near(a) - near(b)); }
  spots.sort((a, b) => b[2] - a[2]);
  let best = null, bd = Infinity;
  for (let i = 0; i < Math.min(10, spots.length); i++) {
    let sh;
    if (!penPos) { sh = guidedShape(smin, smax, prog, 'S', stepStyle, null); sh.st = stepStyle; sh.fl = FLAT.has(stepStyle); sh = styled(sh, stepStyle); }      // the very first stroke: free, but always a stroke
    else {
      const [tx, ty] = spots[i], dx = tx - sx0, dy = ty - sy0, len = Math.hypot(dx, dy) || 1, bend = (rnd() - 0.5) * len * 0.8;
      sh = { t: 'S', a: 0.8, p: [sx0, sy0, (sx0 + tx) / 2 - dy / len * bend, (sy0 + ty) / 2 + dx / len * bend, tx, ty, Math.max(1, lerp(smin, smax, rnd()) * lerp(0.1, 0.34, rnd())), Math.atan2(dy, dx) + (rnd() < 0.5 ? 0 : Math.PI / 2)] };
      sh.st = stepStyle; sh.fl = FLAT.has(stepStyle); sh = styled(sh, stepStyle);
      sh.p[0] = sx0; sh.p[1] = sy0;
    }
    if (sh.t !== 'S') continue;
    const d = evaluate(sh); if (d < bd) { bd = d; best = sh; }
  }
  if (!best) { if (++passFails > 30) penPos = null; return false; }
  for (let i = 0, fails = 0; i < 90 && fails < 30; i++) {
    const m = mutate(best, smax); if (penPos) { m.p[0] = sx0; m.p[1] = sy0; }
    const d = evaluate(m); if (d < bd) { bd = d; best = m; fails = 0; } else fails++;
  }
  if (bd >= 0 && penPos) { best.p[6] = 1; bd = evaluate(best); }       // nothing helps: the pen only travels, as thin as it can
  if (bd === Infinity) { penPos = null; return false; }
  evaluate(best);
  if (abstract && !PAL) shiftColours(best);
  commit(best); count++; passFails = 0; penPos = [best.p[4], best.p[5]];
  postMessage({ type: 'shape', s: best, count, sim, gen, L: tag });
  return true;
}
function step(prog = count / maxShapes, tag) {
  const L = Math.max(W, H);
  if (ORD) {
    if (passNo < ORD.K - 1 && (count - passStart >= passLen || passFails > 120 || cumTotal <= 0)) advancePass();
    prog = Math.min(1, (count - passStart) / passLen);
  }
  if (PEN) return penStep(prog, tag); stepProg = prog; stepStyle = styles[Math.floor(rnd() * styles.length)] || 'painterly';
  stepBg = bgStyles.length ? bgStyles[Math.floor(rnd() * bgStyles.length)] : null;
  const kk = sizeRand ? Math.pow(2, rnd() * 5.32 - 3.32) : sizeK;   // random: anywhere from ×0.1 to ×4, stroke by stroke
  let smax = Math.min(L * 0.9, L * lerp(0.45, 0.012, Math.pow(prog, 0.5)) * kk);
  if (under) smax = Math.min(smax, L * (endless ? 0.05 : 0.1) * Math.max(1, kk));      // with the source showing under the canvas: no big first washes, it gets covered bit by bit
  if (ORD) smax = Math.min(smax, Math.max(ORD.thick, L * 0.02));      // a pass works inside its own window: no washes bigger than it
  const smin = smax * 0.3;
  if (count % 8 === 0) rebuildCum();
  let best = null, bd = Infinity;
  const nc = prog < 0.15 ? 80 : 40;
  for (let i = 0; i < nc; i++) { const s = randomShape(smin, smax, prog), d = evaluate(s); if (d < bd) { bd = d; best = s; } }
  if (!best) { passFails++; return false; }                 // no candidate landed anywhere useful; try again next step
  let fails = 0;
  const keep = kk !== 1 || under, lo = smin * 0.4, hi = smax * 1.6;      // (a chosen stroke size stays chosen: no growing / shrinking out of it; under: no growing into big washes)
  for (let i = 0; i < 180 && fails < 50; i++) {
    const s = mutate(best, smax);
    if (keep) { const x = extentOf(s); if (x > hi || x < lo) { fails++; continue; } }
    const d = evaluate(s);
    if (d < bd) { bd = d; best = s; fails = 0; } else fails++;
  }
  if (!best || bd >= 0) { passFails++; return false; }      // nothing helps here; try elsewhere next step
  evaluate(best);
  if (abstract && !PAL) shiftColours(best);        // abstract: the colours wander a little from what the image asks for
  commit(best); count++; passFails = 0;
  postMessage({ type: 'shape', s: best, count, sim, gen, L: tag });
  return true;
}
function loop(g) {
  if (g !== gen || !running || endless) return;
  const t0 = performance.now();
  while (running && count < maxShapes && performance.now() - t0 < 25) { if (step()) stuck = 0; else if (++stuck > 3000) break; }
  // (a picture that can't be improved any further also counts as finished)
  if (count >= maxShapes || stuck > 3000) { running = false; rebuildCum(); postMessage({ type: 'done', count, sim, gen }); return; }
  setTimeout(() => loop(g), 0);
}

// ── endless mode (zooming canvas) ────────────────────────────
// The page sends a 'frame': the target as it looks right now (the camera keeps moving) and what is painted on
// screen right now. The painter makes a small batch of shapes against that view, tags them with the view's zoom
// level L (so the page can place them on the canvas however far it has moved since), then asks for the next view.
let anaN = 0;
let endless = false, todo = 0, tries = 0, frameL = 0, lastAnaL = null, paused = false, stuck = 0, triesMax = 400;
let sizeK = 1, sizeRand = false, under = false;
let PAL = null;                   // palette lock: [[r, g, b], …] — every stroke is painted in two of these colours   // stroke size: ×0.25 … ×4 of the usual range (the size within it stays random); random: every stroke picks its own
function loopEndless(g) {
  if (g !== gen || !running || !endless) return;
  const t0 = performance.now();
  while (todo > 0 && tries < triesMax && performance.now() - t0 < 25) {
    // mostly mid-to-fine shapes, now and then a big one for areas that are new or blown up by the zoom
    tries++; if (step(0.3 + 0.7 * rnd() ** 0.8, frameL)) todo--;
  }
  if (todo > 0 && tries < triesMax) { setTimeout(() => loopEndless(g), 0); return; }
  running = false; rebuildCum(); postMessage({ type: 'need', gen, sim, count });
}
function loadFrame(m) {
  for (let i = 0, n = W * H; i < n; i++) {
    const o = i * 3, q = i * 4;
    T[o] = m.target[q]; T[o + 1] = m.target[q + 1]; T[o + 2] = m.target[q + 2];
    C[o] = m.current[q]; C[o + 1] = m.current[q + 1]; C[o + 2] = m.current[q + 2];
    errMap[i] = Math.abs(C[o] - T[o]) + Math.abs(C[o + 1] - T[o + 1]) + Math.abs(C[o + 2] - T[o + 2]);
  }
  // re-read the image's structure only after the view has moved noticeably (it takes a moment)
  if (smart && (lastAnaL === null || Math.abs(m.L - lastAnaL) > 0.12 || (bgStyles.length && ++anaN % 20 === 0))) { analyse(); lastAnaL = m.L; }
  rebuildCum();
}

self.onmessage = (e) => {
  const m = e.data;
  if (m.type === 'start') {
    gen = m.gen; W = m.w; H = m.h; maxShapes = m.shapes; band = null; if (m.under !== undefined) under = !!m.under; if (m.size) sizeK = m.size; if (m.sizeRand !== undefined) sizeRand = !!m.sizeRand; styles = m.styles && m.styles.length ? m.styles : [m.style || 'painterly']; bgStyles = m.bgStyles || []; seed = m.seed || 12345; count = 0;
    endless = false; todo = 0; lastAnaL = 0; paused = false; stuck = 0; abstract = !!m.abstract;
    PEN = !!(m.line && m.line.kind === 'pen'); penPos = null; ORD = null;
    smart = !!m.smart;
    T = new Float32Array(W * H * 3); C = new Float32Array(W * H * 3); errMap = new Float32Array(W * H); cum = new Float64Array(W * H);
    cumE = smart ? new Float64Array(W * H) : null;
    tBuf = new Float32Array(W * H + 16); aBuf = new Float32Array(W * H + 16); spans = new Int32Array(3 * (H + 8) * 32);
    let br = 0, bg = 0, bb = 0;
    for (let i = 0; i < W * H; i++) { T[i * 3] = m.data[i * 4]; T[i * 3 + 1] = m.data[i * 4 + 1]; T[i * 3 + 2] = m.data[i * 4 + 2]; br += T[i * 3]; bg += T[i * 3 + 1]; bb += T[i * 3 + 2]; }
    PAL = m.palette && m.palette.length ? m.palette : null;
    let bgc = [br / (W * H), bg / (W * H), bb / (W * H)];
    if (PAL) bgc = PAL.reduce((b, p) => { const d = (p[0] - bgc[0]) ** 2 + (p[1] - bgc[1]) ** 2 + (p[2] - bgc[2]) ** 2; return d < b[0] ? [d, p] : b; }, [Infinity, PAL[0]])[1].slice();
    if (smart) { const t0 = performance.now(); analyse(); self.analysisMs = performance.now() - t0; }
    // (current: a canvas that is already partly painted — the painter carries on from it, stroke count0 onwards)
    const cur = m.current;
    for (let i = 0; i < W * H; i++) {
      if (cur) { C[i * 3] = cur[i * 4]; C[i * 3 + 1] = cur[i * 4 + 1]; C[i * 3 + 2] = cur[i * 4 + 2]; }
      else { C[i * 3] = bgc[0]; C[i * 3 + 1] = bgc[1]; C[i * 3 + 2] = bgc[2]; }
      errMap[i] = Math.abs(C[i * 3] - T[i * 3]) + Math.abs(C[i * 3 + 1] - T[i * 3 + 1]) + Math.abs(C[i * 3 + 2] - T[i * 3 + 2]);
    }
    if (cur) count = Math.min(maxShapes, m.count0 || 0);
    orderSetup(m.order, count);
    rebuildCum();
    postMessage({ type: 'bg', c: bgc, sim, gen, analysisMs: self.analysisMs || 0 });
    if (Sub) postMessage({ type: 'mask', gen, w: W, h: H, mask: maskBytes() });
    running = true; loop(gen);
  } else if (m.type === 'frame') {
    if (m.gen !== gen || !T) return;
    ORD = null; PEN = false; endless = true; frameL = m.L; todo = m.n; tries = 0; triesMax = Math.max(400, m.n * 16); if (m.abstract !== undefined) abstract = !!m.abstract;
    band = m.band || null; if (m.under !== undefined) under = !!m.under; if (m.size) sizeK = m.size; if (m.sizeRand !== undefined) sizeRand = !!m.sizeRand;
    loadFrame(m);
    if (!paused) { running = true; loopEndless(gen); }
  } else if (m.type === 'size') { sizeK = m.k; sizeRand = !!m.rand; }
  else if (m.type === 'under') under = !!m.on;
  else if (m.type === 'palette') PAL = m.pal && m.pal.length ? m.pal : null;
  else if (m.type === 'styles') { if (m.styles && m.styles.length) styles = m.styles; if (m.bg) bgStyles = m.bg; }
  else if (m.type === 'pause') { running = false; paused = true; }
  else if (m.type === 'resume') {
    paused = false;
    if (endless) { if (!running && todo > 0) { running = true; loopEndless(gen); } }
    else if (!running && count < maxShapes) { running = true; loop(gen); }
  }
  else if (m.type === 'stop') { running = false; gen = -1; endless = false; }
};
