'use strict';
// ─────────────────────────────────────────────────────────────
//  The recorder's worker (see recorder.js): owns the encoders and the frame clock, off the page's thread so
//  painting can't starve them.
//    init  { vcfg, acfg, fps, port }  -> ready | fail        (port: MessagePort carrying the sound, planar L|R blocks)
//    frame { frame: VideoFrame, slot } -> q (encoder queue)   slots the page missed repeat the previous picture
//    end   { slot, audioWait }         -> progress…, done { video, audio, vDesc, aDesc, rate, fps, stats } | fail
// ─────────────────────────────────────────────────────────────
let venc = null, aenc = null, fps = 30, slot = 0, last = null, rate = 0, samples = 0, err = null;
let ending = 0, audioDone = true, finishing = false, repeats = 0, run = 0, longest = 0, maxQueue = 0;
const video = [], audio = [];
let vDesc = null, aDesc = null;
const fail = e => { err = err || e; postMessage({ type: 'fail', err: String((e && e.message) || e) }); };
const put = (frame, n) => {                          // encode `frame` as slot n
  const vf = new VideoFrame(frame, { timestamp: Math.round(n * 1e6 / fps), duration: Math.round(1e6 / fps) });
  venc.encode(vf, { keyFrame: n % (fps * 2) === 0 }); vf.close();
  if (venc.encodeQueueSize > maxQueue) maxQueue = venc.encodeQueueSize;
};
const fillTo = n => { while (last && slot < n) { put(last, slot++); repeats++; longest = Math.max(longest, ++run); } };   // missed slots: the picture didn't change
const status = () => { if (venc) postMessage({ type: 'q', q: venc.encodeQueueSize }); };
function onAudio(e) {
  if (e.data === 'done') { audioDone = true; finish(); return; }
  if (!aenc || finishing || aenc.state !== 'configured') return;
  try {
    const d = e.data, n = d.length / 2;
    aenc.encode(new AudioData({ format: 'f32-planar', sampleRate: rate, numberOfFrames: n, numberOfChannels: 2, timestamp: Math.round(samples / rate * 1e6), data: d }));
    samples += n;
  } catch (x) { fail(x); }
}
async function finish() {
  if (!ending || !audioDone || finishing) return;
  finishing = true;
  try {
    fillTo(ending); if (last) { last.close(); last = null; }
    await venc.flush(); venc.close();
    if (aenc) { await aenc.flush(); aenc.close(); }
  } catch (e) { err = err || e; }
  if (err) { postMessage({ type: 'fail', err: String(err.message || err) }); return; }
  postMessage({ type: 'done', video, audio, vDesc, aDesc, rate, fps, stats: { slots: slot, repeats, longest: longest + 1, chunks: video.length, maxQueue } },
    [...video.map(c => c.data.buffer), ...audio.map(c => c.data.buffer)]);
}
onmessage = e => {
  const m = e.data;
  if (m.type === 'init') {
    try {
      fps = m.fps;
      venc = new VideoEncoder({
        output: (chunk, meta) => {
          if (meta && meta.decoderConfig && meta.decoderConfig.description) vDesc = new Uint8Array(meta.decoderConfig.description);
          const b = new Uint8Array(chunk.byteLength); chunk.copyTo(b); video.push({ data: b, key: chunk.type === 'key', ts: chunk.timestamp });
          if (finishing && video.length % 15 === 0) postMessage({ type: 'progress', done: video.length, total: ending });
        },
        error: x => fail(x)
      });
      venc.configure(m.vcfg);
      venc.addEventListener?.('dequeue', status);
      if (m.acfg && m.port) {
        rate = m.acfg.sampleRate; audioDone = false;
        aenc = new AudioEncoder({
          output: (chunk, meta) => { if (meta && meta.decoderConfig && meta.decoderConfig.description) aDesc = new Uint8Array(meta.decoderConfig.description); const b = new Uint8Array(chunk.byteLength); chunk.copyTo(b); audio.push({ data: b }); },
          error: x => fail(x)
        });
        aenc.configure(m.acfg);
        m.port.onmessage = onAudio;
      }
      postMessage({ type: 'ready' });
    } catch (x) { fail(x); }
  } else if (m.type === 'frame') {
    try {
      if (err || !venc || venc.state !== 'configured' || m.slot < slot) { m.frame.close(); status(); return; }
      fillTo(m.slot);
      put(m.frame, slot++); run = 0;
      if (last) last.close(); last = m.frame;
      status();
    } catch (x) { try { m.frame.close(); } catch (y) { /* closed */ } fail(x); }
  } else if (m.type === 'end') {
    if (err || !venc) { postMessage({ type: 'fail', err: String((err && err.message) || err || 'the recorder did not start') }); return; }
    ending = Math.max(m.slot, slot, 1);
    postMessage({ type: 'progress', done: video.length, total: ending });
    setTimeout(() => { audioDone = true; finish(); }, m.audioWait || 1500);          // don't wait forever for the audio's last word
    finish();
  }
};
