'use strict';
// ─────────────────────────────────────────────────────────────
//  Code Painter console: the controls' look.
//    - LED-ring knobs over the range inputs (drag up / down, scroll, arrow keys; double- or right-click resets; shift = fine)
//    - segmented switches and key grids built from <select data-seg> / <select data-keys>
//    - light / dark, and the live / audio / rec status LEDs
//  The original inputs stay in the page (hidden) and keep driving studio.js: turning a knob or pressing a
//  switch sets the input and fires the same 'input' / 'change' events a slider or menu would.
// ─────────────────────────────────────────────────────────────
(() => {
  const $ = id => document.getElementById(id);
  const fire = (el, type) => el.dispatchEvent(new Event(type, { bubbles: true }));

  // ── light / dark (remembered) ──
  const setUI = t => { document.body.dataset.ui = t; try { localStorage.setItem('cp-ui', t); } catch (e) { /* private window */ } };
  let saved = null; try { saved = localStorage.getItem('cp-ui'); } catch (e) { /* private window */ }
  setUI(saved === 'light' ? 'light' : 'dark');
  $('uitheme').onclick = () => setUI(document.body.dataset.ui === 'dark' ? 'light' : 'dark');

  // ── LED-ring knobs ──
  const N = 11, knobs = [];
  for (const wrap of document.querySelectorAll('.kn')) {
    const input = wrap.querySelector('input[type=range]'); if (!input) continue;
    input.classList.add('sr'); input.tabIndex = -1;
    const lk = document.createElement('div'); lk.className = 'lk' + (wrap.dataset.knob === 'p' ? ' p' : '');
    const leds = [];
    for (let j = 0; j < N; j++) { const d = document.createElement('span'); d.className = 'ld'; d.style.transform = `rotate(${-135 + j * 27}deg) translateY(-20px)`; lk.appendChild(d); leds.push(d); }
    const btn = document.createElement('button'); btn.type = 'button'; btn.className = 'k';
    btn.setAttribute('aria-label', input.getAttribute('aria-label') || 'knob');
    const ind = document.createElement('i'); btn.appendChild(ind); lk.appendChild(btn);
    wrap.insertBefore(lk, wrap.firstChild);
    const min = +input.min, max = +input.max, step = +input.step || 1, bip = min < 0 && max > 0;
    const K = { last: null, dis: null };
    K.render = () => {
      const v = +input.value;
      if (v === K.last && input.disabled === K.dis) return;
      K.last = v; K.dis = input.disabled;
      const a = -135 + 270 * (v - min) / (max - min), a0 = bip ? -135 + 270 * (0 - min) / (max - min) : -135;
      ind.style.transform = `rotate(${a}deg)`;
      leds.forEach((d, j) => {
        const b = -135 + j * 27;
        d.classList.toggle('on', bip ? Math.abs(a - a0) > 1 && b >= Math.min(a0, a) - 0.1 && b <= Math.max(a0, a) + 0.1 : v > min && b <= a + 0.1);
      });
      lk.classList.toggle('dis', input.disabled);
      btn.setAttribute('aria-valuenow', v);
    };
    const set = (v, change) => {
      v = Math.max(min, Math.min(max, Math.round(v / step) * step));
      if (+input.value !== v) { input.value = v; fire(input, 'input'); }
      if (change) fire(input, 'change');
      K.render();
    };
    const nudge = d => set(+input.value + d * Math.max(step, (max - min) / 50), true);
    let drag = null;
    btn.addEventListener('pointerdown', e => { if (input.disabled) return; drag = { y: e.clientY, v: +input.value }; try { btn.setPointerCapture(e.pointerId); } catch (x) { /* no live pointer */ } e.preventDefault(); });
    btn.addEventListener('pointermove', e => { if (drag) set(drag.v + (drag.y - e.clientY) / (e.shiftKey ? 700 : 170) * (max - min), false); });
    const end = () => { if (drag) { drag = null; fire(input, 'change'); } };
    btn.addEventListener('pointerup', end); btn.addEventListener('pointercancel', end);
    btn.addEventListener('wheel', e => { if (input.disabled) return; e.preventDefault(); nudge(e.deltaY < 0 ? 1 : -1); }, { passive: false });
    // double-click or right-click: back to the default (zoom off, size ×1 …)
    const reset = e => { e.preventDefault(); if (!input.disabled) set(+input.defaultValue, true); };
    btn.addEventListener('dblclick', reset); lk.addEventListener('contextmenu', reset);
    btn.addEventListener('keydown', e => { const d = { ArrowUp: 1, ArrowRight: 1, ArrowDown: -1, ArrowLeft: -1 }[e.key]; if (d && !input.disabled) { e.preventDefault(); nudge(d); } });
    input.addEventListener('input', K.render);
    knobs.push(K); K.render();
  }

  // ── segmented switches / key grids from selects ──
  const segs = [];
  for (const sel of document.querySelectorAll('select[data-seg], select[data-keys]')) {
    const keys = sel.hasAttribute('data-keys');
    const box = document.createElement('div'); box.className = keys ? 'grid g5' : 'seg' + (sel.hasAttribute('data-tight') ? ' tight' : '');
    box.setAttribute('role', 'group'); box.setAttribute('aria-label', sel.getAttribute('aria-label') || '');
    if (sel.title) box.title = sel.title;
    let render;
    const items = [...sel.options].map(o => {
      const b = document.createElement('button'); b.type = 'button'; b.title = o.textContent;
      if (keys) { b.className = 'key'; const l = document.createElement('span'); l.className = 'led'; b.appendChild(l); }
      b.appendChild(document.createTextNode(o.dataset.s || o.textContent));
      b.onclick = () => { if (sel.disabled || sel.value === o.value) return; sel.value = o.value; fire(sel, 'change'); render(); };
      box.appendChild(b); return { b, o };
    });
    render = () => { for (const { b, o } of items) b.classList.toggle('on', sel.value === o.value); box.classList.toggle('dis', sel.disabled); };
    sel.classList.add('sr'); sel.tabIndex = -1; sel.after(box);
    sel.addEventListener('change', render); segs.push(render); render();
  }

  // ── speed fader fill, status LEDs; values that studio.js sets directly are picked up here ──
  const speed = $('speed');
  const fill = () => speed.style.setProperty('--pct', ((speed.value - speed.min) / (speed.max - speed.min) * 100) + '%');
  speed.addEventListener('input', fill); fill();
  speed.addEventListener('contextmenu', e => { e.preventDefault(); speed.value = speed.defaultValue; fire(speed, 'input'); fire(speed, 'change'); });
  const led = (id, on, c) => { const el = $(id); const cls = 'led' + (on ? ' ' + c : ''); if (el.className !== cls) el.className = cls; };
  setInterval(() => {
    for (const K of knobs) K.render();
    for (const r of segs) r();
    fill();
    const st = window.STUDIO; if (!st) return;
    const S = st.S, AU = st.AU;
    led('ledlive', S.endless && S.endless.on, 'g');
    led('ledaudio', AU && ((AU.el && !AU.el.paused) || AU.live), 'p');
    led('ledrec', !!S.rec, 'p');
  }, 150);
})();
