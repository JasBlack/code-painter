#!/usr/bin/env python3
"""Code Painter by JAS.BLACK: a tiny web server for this folder, on this computer only, which opens the studio in your
browser. (Browsers need a web address for the 3D input and to talk to the Resolume bridge.) Close the window to stop."""
import http.server
import os
import socket
import threading
import webbrowser

os.chdir(os.path.dirname(os.path.abspath(__file__)))


def free_port(p=8765):                     # the first free port from 8765 up (an older copy may still be running)
    for port in range(p, p + 100):
        with socket.socket() as s:
            try:
                s.bind(('127.0.0.1', port))
                return port
            except OSError:
                continue
    raise SystemExit('No free port between 8765 and 8864.')


class Handler(http.server.SimpleHTTPRequestHandler):
    extensions_map = {**http.server.SimpleHTTPRequestHandler.extensions_map,
                      '.js': 'text/javascript', '.mjs': 'text/javascript', '.webp': 'image/webp', '.wasm': 'application/wasm'}

    def end_headers(self):
        self.send_header('Cache-Control', 'no-cache')
        super().end_headers()

    def log_message(self, *args):
        pass


port = free_port()
server = http.server.ThreadingHTTPServer(('127.0.0.1', port), Handler)
url = f'http://localhost:{port}/'
version = open('VERSION').read().strip() if os.path.exists('VERSION') else ''
print(f'Code Painter by JAS.BLACK {version} is running at {url}')
print('Keep this window open while you use it. Close it to stop.', flush=True)
if not os.environ.get('CP_NO_BROWSER'):            # (for tests)
    threading.Timer(0.8, lambda: webbrowser.open(url)).start()
try:
    server.serve_forever()
except KeyboardInterrupt:
    pass
